# TECHNICAL_DOCS.md — Quét & Chỉnh Sửa PDF (DocScanner)

> Tài liệu này ghi lại toàn bộ quyết định kỹ thuật, tiến độ, việc đã làm/chưa làm, và các cạm bẫy
> đã gặp của dự án. Mục đích: mở lại dự án sau này (kể cả người/AI khác) chỉ cần đọc file này,
> KHÔNG cần đọc lại lịch sử chat. Mỗi khi tiếp tục dự án, hãy đọc file này trước, code sau. Sau khi
> làm thêm việc gì, cập nhật lại file này (thêm mục vào đúng section, không xoá lịch sử cũ).

## 0. Trạng thái tóm tắt (đọc trước tiên)

- **Chưa build-test thật lần nào.** Toàn bộ project được viết trong môi trường không có Android
  SDK, không có mạng để chạy Gradle → mọi thứ được kiểm tra tĩnh (xem mục 9), chưa có bằng chứng
  thực tế là `./gradlew assembleDebug` / GitHub Actions chạy qua. **Việc ưu tiên số 1 khi tiếp tục:
  push code lên GitHub, chạy Actions, xem log lỗi đầu tiên (gần như chắc chắn sẽ có ít nhất 1 lỗi
  ở lần build đầu) rồi sửa tiếp.**
- Ngôn ngữ: Kotlin. Người dùng yêu cầu "so sánh cả 2 (Kotlin/Java)" ở bước đầu — **đã trả lời**, xem
  file riêng `KOTLIN_VS_JAVA.md` (tách riêng khỏi file này để không phình to với nội dung không phải
  nhật ký tiến độ). Kết luận: giữ Kotlin.
- Toàn bộ tính năng chính đã có code (xem mục 4), nhưng OCR mới chỉ đi kèm hoặc chưa được test.
- **Cập nhật (phiên làm việc tiếp theo, vẫn trong môi trường không có Android SDK/mạng — chưa
  build-test được lần nào, y hệt hạn chế đã nêu ở trên)**: đã mở rộng tự lưu/khôi phục (mục 4.13)
  sang 3 luồng còn lại — ghép PDF, quản lý trang PDF, soạn mục lục ebook (mục 4.14) — sửa cảnh báo
  xoá cặp EPUB+TXT (mục 6), thêm dọn cache định kỳ (mục 4.14), và **tìm + sửa 1 lỗi build thật** ở
  `PdfPageEditorActivity.kt` nhờ viết thêm 1 script rà soát tĩnh mới (đối chiếu số tham số gọi hàm
  với khai báo — mục 9) — đúng loại lỗi mục này đã dự đoán trước, chỉ khác là tìm được bằng rà soát
  tĩnh thay vì log CI thật.
- **Cập nhật (phiên làm việc thứ 3 — LỚN NHẤT từ trước đến giờ, đọc kỹ mục 4.15)**: người dùng mô
  tả 1 quy trình "Dự án" tuyến tính bắt buộc đi qua 8 bước (tạo dự án → chọn ảnh → chỉnh sửa ảnh →
  chọn kiểu quét → xuất PDF kèm mục lục → nén PDF → OCR → tạo ebook), yêu cầu xây đúng quy trình đó,
  **không xoá bỏ các công cụ độc lập đã có** (chúng trở thành lựa chọn/công cụ phụ, vẫn giữ nguyên
  100%), nhưng **các bước trong quy trình dự án thì bắt buộc phải đi qua, không được bỏ qua bước
  nào**. Đã xây xong toàn bộ: 1 model `Project`/`ProjectManager` mới, 9 màn hình mới (mục 4.15), có
  tính năng hoàn toàn mới chưa từng có trước đó — **tự động dò mục lục từ trang "Mục lục" của sách
  qua OCR** (`TocDetector`, mục 4.15) — và tái cấu trúc nhẹ 1 vài chỗ code cũ để dùng chung logic
  (không đổi hành vi của các công cụ cũ, xem mục 4.15 + mục 5 quyết định 21-25). Đây là khối lượng
  code MỚI lớn nhất trong 1 phiên làm việc, **chưa được build-test dù chỉ 1 dòng nào** (vẫn cùng hạn
  chế môi trường), rủi ro có lỗi build cao hơn hẳn các phiên trước — xem mục 9 "Rủi ro riêng của
  luồng Dự án".
- **Việc ưu tiên số 1 vẫn không đổi và vẫn KHÔNG làm được ở đây**: push code lên GitHub, chạy
  Actions, xem log lỗi đầu tiên — môi trường này cũng không có Android SDK/mạng để tự làm việc đó.
- **Cập nhật (phiên làm việc thứ 4, được yêu cầu "đọc kỹ tài liệu rồi hoàn thành việc dang dở" —
  vẫn cùng hạn chế môi trường như mọi phiên trước, không có SDK/mạng)**: đọc lại toàn bộ tài liệu
  này, rà lại đúng những gì mục 6/7/9/10 liệt kê là còn tồn đọng, rồi:
  - **Sửa nốt đường CUỐI CÙNG còn lại của lỗi `ASSUMED_DPI`** (mục 6/7 đã nêu rõ, cố ý để lại lần
    trước) — `MainActivity.importPdfForScanning()` → hàng đợi `PendingCropQueue` → `CropActivity`
    (chế độ queue) → `ScanSessionManager.addPage()`. Cách sửa đúng như mục 6 đã dự đoán: thêm
    `sourceDpi` (dùng chung cho cả lô) vào `PendingCropQueue`, truyền qua Intent extra
    `CropActivity.EXTRA_SOURCE_DPI` cho ảnh đầu tiên, `CropActivity` giữ lại trong 1 field suốt
    vòng đời Activity đó và gán vào MỌI `ScanPage` nó lưu ra (kể cả 2 nửa sau khi tách trang, vì
    cùng 1 Activity xử lý hết cả lô). Không đổi hành vi đường ảnh chụp/thư viện (vẫn `null` như cũ).
    Xem mục 7 để biết chi tiết đầy đủ, mục 6 mục này giờ đã gạch.
  - **Thêm backup/restore cho `ProjectEbookActivity`** (mục 6 đã nêu là còn thiếu) — file mới
    `ProjectEbookEditorState.kt`, đúng khuôn mẫu `EbookEditorState` (không lưu ảnh gốc/văn bản OCR,
    chỉ lưu tên sách + 2 checkbox định dạng + đánh dấu chương/tên chương từng trang), nhưng lưu
    THEO TỪNG DỰ ÁN (trong thư mục riêng của dự án đó, qua `FileUtils.projectDir`) thay vì 1 slot
    chung duy nhất, vì nhiều dự án có thể đang dang dở bước này ở nhiều thời điểm khác nhau. Không
    hiện hộp thoại "khôi phục hay làm lại" như công cụ độc lập — vì trang nguồn của 1 Dự án luôn cố
    định (`Project.pages`), nên hễ có trạng thái đã lưu khớp đúng danh sách trang là áp dụng luôn,
    không có gì mơ hồ cần hỏi lại người dùng. Xem mục 4.15/6.
  - **Chạy lại đủ cả 6 cách rà soát tĩnh ở mục 9 trên TOÀN BỘ code hiện tại** (kể cả code luồng Dự
    án ở mục 4.15 và `PdfObjectRecompressor.kt` — mục này trước đây có vẻ chưa được rà kỹ, xem ngay
    dưới đây) để tìm lỗi build tiềm ẩn trước khi có CI thật. Không phát hiện lỗi thật mới nào; cách
    rà số tham số hàm báo 41 chỗ nhưng kiểm tra tay xác nhận cả 41 đều là 1 loại báo động giả DUY
    NHẤT (gọi `Activity.finish()` — hàm kế thừa từ Android, 0 tham số — bị đối chiếu nhầm với hàm
    riêng không liên quan `PdfByteWriter.finish(catalogObjNum)` cùng tên nhưng khác hẳn ý nghĩa,
    vì cách rà này không biết hàm nào thuộc class nào). Xem mục 9 để biết chi tiết + cách nhận ra
    loại báo động giả này ở các lần rà sau.
  - **Sửa 2 chỗ chính tài liệu này bị thiếu/lỗi thời** (không phải lỗi code, chỉ là tài liệu): bản
    đồ file (mục 3) thiếu hẳn `PdfObjectRecompressor.kt` dù file này đã có code thật và đã được mô
    tả kỹ ở mục 4.11 — có thể do phiên viết file đó quên cập nhật mục 3; và mô tả `ScanPage.kt`/
    `PendingCropQueue.kt` ở mục 3 bị lỗi thời (chưa nhắc trường `sourceDpi` dù trường này đã có từ
    lâu, theo mục 7). Đã sửa cả 3.
  - Vẫn **chưa build-test được lần nào** — không có gì đổi ở điểm này, việc ưu tiên số 1 vẫn y
    nguyên như mọi phiên trước.
- **Cập nhật (phiên làm việc thứ 5)**: người dùng hỏi sâu thêm về `PdfObjectRecompressor` (mục
  4.11) — vì sao chỉ nén ảnh mà bỏ qua chữ/font/vector, và yêu cầu tra cứu xem có cách nào (kết hợp
  công nghệ có sẵn) giải quyết CCITT/JBIG2/JPX cũng như nén luôn phần chữ/font/vector không. Đã
  `web_search` thật (không đoán) rồi làm 2 việc có bằng chứng rõ ràng, rủi ro thấp:
  - **Bật nén cấu trúc PDF** (`WriterProperties.setFullCompressionMode` + `BEST_COMPRESSION` +
    `useSmartMode`, xác nhận là API có sẵn trong đúng `kernel-android` đang dùng, không cần thêm
    phụ thuộc) — nén object/xref stream + gộp resource trùng lặp, áp dụng cho TOÀN BỘ object trong
    file kể cả font/text/vector, không riêng ảnh. Đây là câu trả lời thật cho câu hỏi "font/text/
    vector có nén không" — nhưng nói rõ: đây là nén CẤU TRÚC LƯU TRỮ, không phải font subsetting
    thật (xoá glyph thừa) — cái đó chỉ có ở gói trả phí `pdfOptimizer` của iText, đã tra cứu xác
    nhận, không có sẵn trong thư viện miễn phí đang dùng.
  - **Thêm hỗ trợ Predictor kiểu PNG (10-15)** cho `PdfObjectRecompressor.decodeFlateRaster()` —
    phát hiện qua tra cứu: định dạng byte bên trong 1 stream FlateDecode+Predictor của PDF CHÍNH LÀ
    đúng nội dung 1 chunk IDAT của PNG (PDF spec dẫn chiếu thẳng cơ chế PNG). Nên thay vì tự viết
    thuật toán un-filter Sub/Up/Average/Paeth (rủi ro cao, không test được), bọc nguyên bytes vào 1
    file PNG tối giản tự dựng rồi đưa cho `BitmapFactory` — để bộ giải mã PNG có sẵn, đã kiểm chứng
    thật của Android tự làm phần khó. Xem mục 4.11 để biết đầy đủ.
  - **Tra cứu JBIG2/JPX, kết luận cuối là KHÔNG tích hợp (đảo ngược đánh giá lạc quan ban đầu trong
    cùng phiên này, sau khi đào sâu thêm)**: đợt tra đầu tìm được 1 thư viện JBIG2 mã nguồn mở thuần
    Java (`github.com/Borisvl/JBIG2-Image-Decoder`, nhánh mở của JPedal) có phần LÕI giải mã KHÔNG
    đụng AWT — tưởng khả thi hơn hẳn đánh giá cũ. Nhưng đào thêm 1 lớp thì phát hiện: (1) chính
    thư viện này có lịch sử lỗi thật đã ghi nhận độc lập (mô tả thẳng là "buggy", có 1 bản port
    khác ghi rõ "sửa lại" phần MMR decode vì bản gốc sai), và (2) thư viện thay thế đáng tin hơn
    (`levigo/jbig2-imageio`, do cộng đồng Apache PDFBox duy trì) lại gắn chặt AWT ở MỌI tầng API
    (`Raster`/`Rectangle`/`Dimension`), không tách được như thư viện đầu, VÀ cũng có báo lỗi thật.
    Do JBIG2 là chuẩn nhiều chế độ phức tạp và môi trường này không có cách nào đối chiếu kết quả
    decode với bất kỳ thứ gì đáng tin (khác hẳn CCITT G4 vốn có Python+libtiff để so trước khi tin)
    — rủi ro ra ảnh sai mà không biết là sai, không có lưới an toàn nào bắt được. Kết luận: KHÔNG
    tích hợp. Xem mục 6 để biết đầy đủ cả quá trình lật lại đánh giá này.
  - **JPEG2000 (JPX)**: xác nhận KHÔNG có lựa chọn thuần Java tốt nào (mọi lựa chọn thật đều bọc
    OpenJPEG qua JNI/WASM, khác hẳn kiểu phụ thuộc thuần Kotlin đã dùng xuyên suốt) — giữ nguyên
    quyết định không làm, giờ có bằng chứng tra cứu thay vì chỉ giả định. Xem mục 4.11/6.
  - Đã chạy lại đủ 6 cách rà soát tĩnh sau khi sửa — không phát hiện lỗi thật mới (chỉ thêm 7 báo
    động giả cùng loại đã biết, xem mục 9).
  - Vẫn **chưa build-test được lần nào** — không đổi.
- **Cập nhật (phiên làm việc thứ 6)**: người dùng yêu cầu thêm hộp thoại chọn cách nén CÓ ghi chú
  ưu/nhược điểm (không chỉ tên ngắn gọn như trước) ở CẢ 2 nơi — công cụ "Nén PDF" độc lập VÀ ngay
  trong luồng Quét khi xuất PDF (luồng Quét trước đây KHÔNG hề có lựa chọn nén nào, luôn xuất qua
  `PdfExporter`/`PdfDocument` của Android, không kiểm soát được cách nén). Đã làm:
  - **`CompressOptionsDialog`** (file mới, `util/`) — hộp thoại dùng chung cho cả 2 nơi, mỗi dòng
    có tiêu đề + tóm tắt + Ưu điểm + Nhược điểm thật (không phải placeholder), thay cho
    `AlertDialog.setItems()` cũ chỉ có tên. Dựng bằng `LinearLayout` điền động lúc chạy, không
    dùng RecyclerView vì danh sách luôn cố định 3-4 mục, không cần thêm phức tạp.
  - **Luồng Quét giờ CÓ lựa chọn nén khi xuất** (`PageListActivity`) — 3 lựa chọn: "Giữ nguyên chất
    lượng" (đúng hành vi cũ, không đổi gì), "An toàn (1-bit + Deflate)", "Nén sâu hơn (CCITT G4)" —
    2 cách sau đi qua ĐÚNG `PdfCompressor` mà công cụ "Nén PDF" độc lập đã dùng (không viết logic
    nén mới), chỉ khác là dựng PDF MỚI từ ảnh của phiên quét thay vì render lại 1 PDF có sẵn. Không
    có lựa chọn "Sửa trực tiếp" ở đây vì luồng Quét chưa có PDF nào tồn tại để sửa — không có ý
    nghĩa ở bước này.
  - **Mở rộng `PdfCompressor.compress()`** thêm tham số `pageDpis: List<Float?>?` (tuỳ chọn, mặc
    định `null` — không đổi hành vi 2 nơi gọi cũ) để nén PDF từ phiên quét vẫn giữ đúng DPI RIÊNG
    của từng trang — quan trọng vì 1 phiên quét có thể trộn trang chụp camera (không DPI thật) và
    trang import từ PDF (DPI thật, ví dụ 220) trong CÙNG 1 phiên (đúng con đường vừa sửa lỗi
    `ASSUMED_DPI` ở phiên thứ 4) — nếu không thêm tham số này, nén qua `PdfCompressor` sẽ ĐỘNG LẠI
    ĐÚNG lỗi khai sai kích thước trang đã dày công sửa trước đó.
  - **Tách hàm OCR ra khỏi `PdfExporter.exportSession()`** thành `PdfExporter.writeOcrTextFile()`
    dùng chung — để luồng nén mới (qua `PdfCompressor`, không tự làm OCR) vẫn giữ được checkbox
    "Nhận diện văn bản" y hệt trước. Đã cẩn thận giữ đúng tính chất "bộ nhớ giới hạn" (decode - OCR
    - giải phóng từng ảnh một, không giữ tất cả bitmap trong RAM cùng lúc) của hàm gốc khi tách ra —
    bản nháp đầu bị lỗi giữ hết bitmap trong RAM, đã tự phát hiện và sửa lại trước khi chạy check.
  - Toàn bộ nội dung Ưu/Nhược điểm viết dựa trên đúng hành vi thật đã xác nhận qua code + tra cứu ở
    các phiên trước (an toàn/G4/sửa trực tiếp — xem mục 4.11), không suy đoán.
  - Đã chạy lại đủ 6 cách rà soát tĩnh — không phát hiện lỗi thật mới (48 báo động, đúng bằng số cũ,
    toàn bộ đã xác nhận là 2 loại báo động giả đã biết — xem mục 9).
  - Vẫn **chưa build-test được lần nào** — không đổi.
- **Cập nhật (phiên làm việc thứ 7)**: người dùng yêu cầu thêm tính năng "chỉnh sửa trực tiếp nội
  dung PDF". Đã hỏi rõ trước khi làm (2 hướng rất khác độ khó/rủi ro: đánh dấu/chú thích lên trang,
  hay sửa lại đúng câu chữ gốc như Word) — người dùng chọn "cả 2, nhưng làm phần đánh dấu/chú thích
  trước". Đã làm xong phần đánh dấu/chú thích, PHẦN SỬA CHỮ GỐC CHƯA LÀM (việc lớn, rủi ro cao hơn
  nhiều — xem mục 6 để biết vì sao chưa làm và cần bàn gì trước khi làm).
  - **Tính năng mới: "Chú thích PDF"** — vẽ tay (bút), chèn chữ tự do, che/xoá 1 vùng (dán trắng)
    lên trang, rồi "làm phẳng" (flatten) kết quả vào ảnh trang — KHÔNG phải object chú thích PDF
    thật (`/Annots`) mà một trình đọc PDF có thể ẩn/hiện lại được, khớp đúng kiến trúc "mọi PDF đều
    là ảnh" của cả app từ trước tới giờ. 2 điểm vào:
    - Công cụ độc lập mới trên màn hình chính ("Chú thích PDF") — mở bất kỳ PDF nào, render từng
      trang, chú thích, xuất PDF mới.
    - Nút mới trên từng trang trong màn hình danh sách trang (`PageListActivity`) — chú thích 1
      trang đang quét dở, lưu lại vào đúng phiên quét đó (qua `ScanSessionManager.replaceFile`,
      giống hệt cách `CropActivity` trả trang đã cắt/lọc lại cho phiên).
  - File mới: `view/AnnotationCanvasView.kt` (View tự vẽ, có bút/chữ/che + hoàn tác, tự quy đổi toạ
    độ màn hình ↔ toạ độ ảnh gốc để nét vẽ không bị vỡ nét khi "làm phẳng" ở độ phân giải đầy đủ),
    `PdfAnnotateActivity.kt` (màn hình dùng chung cho cả 2 điểm vào ở trên).
  - **Tự rà lại bằng tay (không máy nào bắt được) và tìm ra 2 vấn đề thật trước khi coi là xong**:
    1. `AnnotationCanvasView.loadPage()` không giải phóng (`recycle()`) bitmap trang CŨ trước khi
       nhận bitmap MỚI — rò bộ nhớ tích luỹ dần mỗi lần chuyển trang trong 1 phiên chú thích dài
       (PDF nhiều trang). Đã sửa: giải phóng bitmap cũ trước khi gán bitmap mới (trừ khi cùng 1
       object).
    2. Chế độ PDF ngoài dùng riêng 1 thư mục làm việc (`FileUtils.annotatePagesDir`) cho các trang
       đã render — nhưng khi người dùng huỷ (thoát không lưu) hoặc xuất xong, các file trang trung
       gian đó KHÔNG được dọn, tích luỹ dần qua nhiều lần dùng tool. Đã sửa: dọn sạch thư mục này
       sau khi xuất thành công VÀ khi người dùng xác nhận huỷ.
  - **Cố tình KHÔNG làm ở phiên này** (đã ghi thẳng vào mục 6, không giấu): chưa có backup/restore
    qua chết tiến trình cho tool này (không theo khuôn mẫu `model.*State` như các tool nhiều bước
    khác) — chỉ có hộp thoại xác nhận "bỏ chú thích chưa lưu?" khi thoát, không phải lưu JSON đầy
    đủ. Chấp nhận cho bản đầu tiên, ghi rõ cách làm đúng nếu cần sau.
  - Đã chạy lại đủ 6 cách rà soát tĩnh — không phát hiện lỗi thật mới ngoài 2 lỗi tự tìm bằng tay ở
    trên (54 báo động giả, tăng đúng +6 so với trước vì file mới cũng gọi `finish()` — cùng loại đã
    biết, xem mục 9).
  - Vẫn **chưa build-test được lần nào** — không đổi. Tool có custom View (vẽ tay, toạ độ, Matrix)
    nên rủi ro "trông đúng trên giấy nhưng lệch/vỡ nét khi chạy thật" cao hơn các tool thuần logic
    khác — cần test tay kỹ trên máy thật trước khi tin, xem mục 6/10.
- **Cập nhật (phiên làm việc thứ 8) — TÍNH NĂNG RỦI RO CAO NHẤT TỪ TRƯỚC ĐẾN GIỜ, đọc kỹ mục này
  trước khi đụng vào `PdfTextEditor`/`PdfCanvasEditor`**: làm phần "sửa lại đúng câu chữ gốc trong
  PDF" mà phiên thứ 7 đã cố tình để lại (mục 6). Đã hỏi rõ phạm vi TRƯỚC khi viết dòng code nào —
  người dùng chọn "thử làm đúng nghĩa" (đọc/ghi object chữ thật) thay vì hướng an toàn hơn (dùng lại
  Che+Chèn chữ đã có ở `PdfAnnotateActivity`).
  - **Tra cứu kỹ trước khi viết** (không đoán): tìm và ĐỌC TOÀN BỘ 2 file mã nguồn thật từ
    `github.com/mkl-public/testarea-itext7` (tác giả là người trả lời câu hỏi iText content-stream
    nhiều nhất trên Stack Overflow) — `EditPageContent.java` (các ví dụ đã dùng kỹ thuật này: xoá
    chữ theo tên font, đổi màu chữ, xoá dòng theo vị trí) và `PdfCanvasEditor.java` (khung sửa
    content stream mà các ví dụ trên dùng chung) — KHÔNG suy luận từ đoạn trích, đã fetch trọn vẹn
    cả 2 file trước khi viết bất kỳ dòng Kotlin nào.
  - **`util/PdfCanvasEditor.kt`** (file mới) — port sang Kotlin gần như nguyên văn từ
    `PdfCanvasEditor.java` thật ở trên, không tự sáng tác thêm cơ chế nào. Ý tưởng cốt lõi: bọc MỌI
    operator PDF (không riêng chữ) qua `registerContentOperator`, mặc định ghi lại y nguyên qua
    chính bộ serialize object của iText (`PdfOutputStream.write(PdfObject)`) — nghĩa là 99% nội
    dung file (đường vẽ, màu, ảnh, đổi trạng thái...) KHÔNG BAO GIỜ bị app này diễn giải lại, chỉ có
    đúng phần bị override (`write()`) mới đổi. Đây là lý do chọn cách này thay vì tự viết 1 trình
    tokenize/serialize content stream từ đầu — rủi ro thấp hơn hẳn vì phần khó (hiểu đúng MỌI loại
    operator PDF) vẫn do iText lo, code app chỉ quyết định "operator NÀY có muốn đổi không".
  - **`util/PdfTextEditor.kt`** (file mới) — logic tìm (đọc) + sửa (ghi):
    - Đọc: dùng `PdfCanvasProcessor` + `TextRenderInfo` thật của iText (đúng cơ chế bất kỳ tính năng
      tìm-kiếm-chữ/copy-paste nào cũng dùng) — lấy đúng CHỮ ĐÃ GIẢI MÃ UNICODE (iText tự lo phần
      `/ToUnicode`/font encoding, app không tự viết) + font + kích thước chữ + ĐỘ RỘNG ĐÃ RENDER
      (`TextRenderInfo.getBaseline().getLength()` — đo tại đúng thời điểm đọc, không tính lại sau).
    - Sửa: dùng `PdfCanvasEditor`, chỉ can thiệp đúng operator hiện chữ (`Tj`/`'`/`"`/`TJ`), đúng
      "đoạn thứ N" đã xác định lúc đọc (đếm thống nhất — mỗi CHUỖI hiện chữ tính 1, kể cả từng phần
      tử chuỗi bên trong 1 mảng `TJ`, khớp đúng cách `TextRenderInfo` cũng bắn sự kiện theo từng
      chuỗi chứ không theo từng operator).
    - **Kiểm tra AN TOÀN TRƯỚC khi ghi, từ chối thay vì đoán** (đây là phần quan trọng nhất, xem
      doc comment đầy đủ trong chính file): (1) MỌI ký tự chữ mới phải có sẵn trong font đó
      (`PdfFont.containsGlyph(Int)` — font nhúng sẵn trong PDF thật hầu hết bị "subset", chỉ có
      đúng ký tự đã dùng, không thể tự thêm glyph mới); (2) độ co giãn ngang cần dùng để chữ mới
      vừa đúng độ rộng chữ cũ phải nằm trong 40%-250%, ngoài khoảng đó thì từ chối (không tự nén/
      giãn chữ tới mức không đọc được); (3) đoạn chữ đang sửa phải nằm TRỌN trong 1 chuỗi (không
      ghép được nếu 1 cụm chữ bị PDF chia làm nhiều mảnh `TJ` liền kề, thường gặp với chữ có canh
      kerning).
    - **Cơ chế co giãn** (`Tz` — horizontal scaling): bọc operator đã sửa trong 1 khối `q ... Tz
      ... Q` RIÊNG — không cần dò/khôi phục lại đúng giá trị `Tz` đang có trước đó (theo đúng chuẩn
      PDF, `q`/`Q` tự lưu/khôi phục toàn bộ text state kể cả `Tz`), nên phần trước/sau đoạn sửa
      không bị ảnh hưởng dù trước đó có `Tz` gì. Vì scale được tính CHÍNH XÁC để độ rộng render ra
      khớp bản gốc, vị trí con trỏ chữ sau khi hiện xong cũng khớp gần đúng bản gốc — chữ tiếp theo
      cùng dòng (nếu có, hiện bằng Tj/TJ tiếp theo không định vị lại) vẫn đúng chỗ.
  - **`PdfTextEditActivity`** (Activity mới) — chọn PDF ngoài, mở qua `PdfDocument(PdfReader,
    PdfWriter)` (stamping, giữ mở SUỐT phiên làm việc — giống hệt cách `PdfObjectRecompressor` giữ
    mở xuyên suốt nhiều ảnh trước khi đóng 1 lần), duyệt từng trang xem danh sách đoạn chữ tìm
    được, chạm 1 đoạn để sửa, Lưu đóng lại `PdfDocument` (tự hoàn thiện PDF). KHÔNG có lựa chọn
    "sửa cả đoạn văn/nhiều dòng" — chỉ sửa từng đoạn ngắn, đúng phạm vi đã thống nhất.
  - **1 lỗi thật tự tìm ra NHỜ ĐÚNG cách rà số tham số ở mục 9** (không phải nhờ đọc tay lần này) —
    hàm `trySubstituteAndWrite` được gọi kèm 1 lambda cuối (`{ ... }`) ở cả 2 chỗ gọi, nhưng khai
    báo hàm lại THIẾU hẳn tham số callback đó — lỗi sẽ khiến code KHÔNG BIÊN DỊCH ĐƯỢC (tham chiếu
    `substitute()` không tồn tại trong thân hàm). Cách rà "đếm lambda cuối +1 tham số" phát hiện
    đúng NGAY (báo lệch 6 tham số truyền vs 5 khai báo), không phải 1 trong 2 loại báo động giả đã
    biết — đã kiểm tra tay xác nhận là lỗi thật rồi sửa (thêm tham số `substitute: () -> Unit`).
  - **Nói thẳng mức độ tin cậy của các API iText đã dùng** (để phiên sau biết cái nào đã xác minh kỹ,
    cái nào chỉ dựa vào hiểu biết chung): ĐÃ XÁC NHẬN QUA TRA CỨU THẬT trong phiên này —
    `PdfFont.containsGlyph(Int)`, `PdfFont.convertToBytes(String)`, `PdfFont.getWidth(String,
    Float)`, `TextRenderInfo.getText()`/`getBaseline()`/`getFontSize()`, và toàn bộ cơ chế
    `PdfCanvasEditor`. CHƯA tra cứu riêng trong phiên này (dựa vào hiểu biết chung về iText, tin
    cậy cao nhưng không phải mức "đã đọc tài liệu thật"): `TextRenderInfo.getFont()`,
    `PdfArray.get/set/size`, `PdfNumber(Double)`. Nếu build lỗi đúng vào 1 trong 3 API này, đây là
    chỗ đầu tiên nên nghi ngờ.
  - **Giới hạn đã biết, nói thẳng không né** (xem thêm doc comment đầy đủ trong `PdfTextEditor.kt`):
    không sửa được chữ nằm trong Form XObject/pattern/annotation (chỉ đọc content stream CHÍNH của
    trang); không hỗ trợ font CID/Type0 phức tạp đã được test riêng; chưa có backup/restore qua
    chết tiến trình (giống `PdfAnnotateActivity`, cùng lý do, cùng mức chấp nhận được); và QUAN
    TRỌNG NHẤT — CHƯA TỪNG mở thử 1 file PDF thật nào qua tool này, vì môi trường này không build
    được (mục 9). Đây là tính năng DUY NHẤT trong toàn dự án trực tiếp ghi đè vào object chữ thật
    của 1 PDF có sẵn — nếu có lỗi, hậu quả là PDF hỏng/chữ sai vị trí, không phải "trông xấu" như
    lỗi UI thông thường. Bắt buộc phải tự test kỹ bằng nhiều PDF thật đa dạng (PDF từ Word, từ
    LaTeX, PDF quét có OCR text layer...) trước khi tin dùng thật.
  - Đã chạy lại đủ 6 cách rà soát tĩnh sau khi sửa lỗi tự tìm ra — 59 báo động, toàn bộ đã xác nhận
    thuộc 2 loại báo động giả đã biết (`finish`/`write`), không còn báo động chưa giải thích được.
  - Vẫn **chưa build-test được lần nào** — không đổi, và như đã nói ở trên, đây là tính năng CẦN
    test tay thật nhất trong toàn bộ dự án tính đến giờ.
- **Cập nhật (phiên làm việc thứ 9)**: người dùng hỏi thẳng vì sao 3 giới hạn của mục 4.17 không
  được tra cứu cách giải quyết (đúng tinh thần đã làm với JBIG2/font ở `PdfObjectRecompressor`).
  Tra cứu lại nghiêm túc cả 3 — kết quả KHÔNG đồng đều, nói rõ từng cái:
  - **Form XObject: hoá ra KHÔNG PHẢI chỉ là "thiếu tính năng" — là 1 LỖI THẬT nghiêm trọng hơn cả
    câu hỏi ban đầu, đã sửa ngay.** Tra ra API thật (`PdfCanvasProcessor.registerXObjectDoHandler`)
    và xác nhận qua đọc mã nguồn thật của chính iText (`FormXObjectDoHandler`) rằng
    `PdfCanvasProcessor` THƯỜNG (mặc định) TỰ ĐỘNG đi sâu vào Form XObject để bắt sự kiện
    `TextRenderInfo` — nghĩa là bước ĐỌC (`PdfTextEditor.extractChunks`, dùng `PdfCanvasProcessor`
    trơn) vẫn đếm cả chữ nằm trong Form XObject, trong khi bước GHI (`PdfCanvasEditor`, cố tình bỏ
    qua hẳn `Do`) thì KHÔNG — nghĩa là với bất kỳ trang nào có Form XObject chứa chữ (rất phổ biến:
    tiêu đề/chân trang lặp lại, logo, khối mẫu), 2 bộ đếm sẽ LỆCH NHAU ngay từ điểm đó trở đi, khiến
    MỌI đoạn chữ sau điểm lệch bị **sửa nhầm sang đúng đoạn khác** mà không có cảnh báo gì — đúng
    kiểu rủi ro "âm thầm sai" mà cả tính năng này được thiết kế để tránh. Đã sửa: `newProcessor()`
    (hàm mới trong `PdfTextEditor.kt`) đăng ký 1 `IXObjectDoHandler` rỗng cho `PdfName.Form`, buộc
    bước ĐỌC khớp đúng hành vi "không đi vào `Do`" của bước GHI — đánh đổi: chữ nằm trong Form
    XObject giờ CHẮC CHẮN không tìm/sửa được (đúng như tài liệu vốn đã nói), nhưng không còn nguy cơ
    lệch bộ đếm âm thầm nữa. Xem mã nguồn thật đã đọc: `PdfCanvasProcessor.registerXObjectDoHandler`
    + `IXObjectDoHandler.handleXObject(processor, Stack<CanvasTag>, PdfStream, PdfName)` (chữ ký 4
    tham số, đúng bản 7.2.5 dự án đang dùng, xác nhận qua tài liệu javadoc chính thức). **[Đã bị thay
    thế ở phiên thứ 10 — `newProcessor()` không còn tồn tại, giữ mục này làm lịch sử; xem phiên thứ 10
    phía dưới để biết cách sửa tận gốc hơn.]**
  - **Ghép match xuyên nhiều mảnh `TJ`: đã cân nhắc, QUYẾT ĐỊNH KHÔNG làm, không phải bỏ qua không
    nghĩ tới. [LẬP LUẬN NÀY SAI MỘT PHẦN — đã bị người dùng chỉ ra và sửa ở phiên thứ 10, xem ngay phía
    dưới; giữ nguyên nguyên văn ở đây làm lịch sử.]** Cách khả thi duy nhất nghĩ ra là DÒ HEURISTIC (gộp các đoạn liền kề nếu vị trí/font
    "có vẻ" liên tục) — nhưng heuristic tự nó có thể đoán sai (gộp nhầm 2 đoạn không liên quan, hoặc
    tính sai độ rộng gốc để ghép). Toàn bộ tính năng này được thiết kế theo triết lý "từ chối thay vì
    đoán" (xem mục 4.17) — thêm 1 heuristic dò-đoán ở chính bước TÌM sẽ đi ngược triết lý đó. Giữ
    nguyên giới hạn: 1 chuỗi tính 1 chunk, không ghép — nói thẳng đây là lựa chọn có cân nhắc, không
    phải thiếu sót chưa nghĩ tới.
  - **Backup/restore: KHÔNG cần tra cứu gì thêm — chỉ là chưa làm, nay đã làm.** Đây khác 2 mục
    trên (không phải câu hỏi "có cách nào không", mà chỉ là việc chưa bắt tay vào). Thêm
    `model/PdfTextEditState.kt` — nhưng KHÔNG theo đúng khuôn mẫu "lưu file đang dở rồi mở lại" như
    `PdfEditorState`/`EbookEditorState`, vì `PdfDocument`/`PdfWriter` ở chế độ stamping của iText
    XÂY DỰNG TOÀN BỘ file trong RAM, chỉ thật sự ghi ra đĩa lúc `close()` — tiến trình bị giết giữa
    chừng để lại file output RỖNG hoặc DỞ DANG, không phải 1 PDF một-phần-hợp-lệ có thể mở lại tiếp
    tục. Cách giải quyết: lưu bản sao NGUỒN GỐC (chưa sửa gì) ở thư mục durable
    (`FileUtils.textEditSourceDir`, MỚI thêm) + danh sách CÁC LẦN SỬA đã áp dụng thành công (trang,
    số thứ tự đoạn chữ, chữ mới) — khi mở lại, mở NGUYÊN bản sao gốc rồi ÁP LẠI LẦN LƯỢT từng lần
    sửa đã ghi (gọi lại đúng `PdfTextEditor.applyEdit()`, xác định lại đúng chunk cần sửa bằng cách
    trích lại chunk MỚI của trang đó mỗi lần — vì trang đã đổi sau mỗi lần sửa trước đó trong chuỗi
    replay) — không phải mở file dở dang, mà LÀM LẠI TỪ ĐẦU trên bản gốc, kết quả giống hệt lúc
    trước khi bị giết vì `applyEdit()` là hàm xác định (deterministic). `PdfTextEditActivity` phân
    biệt rõ "người dùng chủ động Bỏ" (dọn cả state lẫn bản sao gốc) với "thoát kiểu khác" (giữ
    nguyên state để lần sau khôi phục) qua cờ `explicitlyDiscarding` mới thêm.
  - Đã chạy lại đủ 6 cách rà soát tĩnh sau các thay đổi trên — vẫn đúng 59 báo động, cùng 2 loại đã
    biết, không có báo động mới.
  - Vẫn **chưa build-test được lần nào** — không đổi, và vẫn là tính năng cần test tay đầu tiên.
- **Cập nhật (phiên làm việc thứ 10) — người dùng chỉ ra 1 lỗi TRONG LẬP LUẬN của chính tôi, và đúng**:
  ở phiên thứ 9, tôi từ chối làm phần "ghép match xuyên nhiều mảnh `TJ`" với lý do "cần heuristic dò
  đoán, đi ngược triết lý từ chối-thay-vì-đoán". Người dùng hỏi thẳng: "tại sao phải đoán và từ chối,
  khi có thể tra cứu để biết chính xác cần làm gì" — và khi nghĩ lại, lập luận đó SAI: tôi đã NHẦM 2
  việc khác nhau hoàn toàn thành 1:
  - **Nhóm các mảnh chuỗi nằm trong CÙNG 1 mảng `TJ`** (ví dụ `[(Hel) -20 (lo)] TJ`) — đây KHÔNG PHẢI
    đoán, là **sự thật cấu trúc đọc thẳng từ chính PDF**: chúng LÀ phần tử của cùng 1 mảng, trong cùng
    1 lệnh. Không có gì mơ hồ ở đây cả. Đây mới là trường hợp phổ biến nhất của "chữ bị chia mảnh" (chữ
    canh kerning, canh đều 2 bên).
  - **Nhóm chữ giữa 2 operator KHÁC NHAU** (`Tj` cho "Hel", 1 `Tj` khác sau đó cho "lo", có thể có `Td`
    định vị lại ở giữa) — CÁI NÀY mới cần heuristic (xét vị trí/font gần nhau) vì hoàn toàn không phải
    sự thật cấu trúc, mà chỉ là "trông có vẻ liền nhau" — vẫn giữ nguyên quyết định KHÔNG làm cái này.
  Đã sửa đúng phần thứ nhất — **giờ 1 lệnh hiện chữ (kể cả `TJ` nhiều mảnh) là đúng 1 `TextChunk`**, nối
  chữ của mọi mảnh trong cùng mảng lại, không cần đoán gì.
  - **Đây cũng là dịp thiết kế lại đơn giản hơn hẳn, KHÔNG chỉ vá thêm 1 tính năng**: phiên thứ 9 vá
    lỗi lệch bộ đếm Form XObject bằng cách đăng ký `IXObjectDoHandler` rỗng để 2 đường ĐỌC/GHI (vốn
    dùng 2 cơ chế duyệt khác nhau: ĐỌC qua `TextRenderInfo` của iText, GHI qua `PdfCanvasEditor`)
    hành xử "giống nhau". Phiên này bỏ luôn việc có 2 cơ chế duyệt: **CẢ ĐỌC LẪN GHI giờ đều duyệt
    qua CÙNG 1 lớp `PdfCanvasEditor`** — ĐỌC dùng `PdfCanvasEditor.editContent()` (không phải
    `editPage()`, để tránh việc gán lại `/Contents` của trang dù chỉ để đọc) với 1 `PdfCanvas` bỏ
    đi làm đích ghi giả. Nhờ vậy chỉ còn ĐÚNG 1 chỗ quyết định "cái gì tính là 1 operator, theo thứ
    tự nào" — không thể lệch nhau được nữa, không cần cơ chế "ép cho khớp" riêng cho Form XObject
    (`newProcessor()` của phiên thứ 9 đã bị xoá vì không còn cần). Đây là cách sửa TẬN GỐC cả 1 LOẠI
    lỗi (2 đường duyệt lệch nhau), không chỉ 1 trường hợp cụ thể (Form XObject) — đúng hơn cách vá
    của phiên trước.
  - **`applyEdit()` đơn giản đi đáng kể** — bỏ hẳn vòng lặp duyệt từng phần tử trong mảng `TJ` +
    callback `trySubstituteAndWrite` phức tạp của bản cũ (chính chỗ từng có lỗi thiếu tham số ở phiên
    thứ 8). Giờ mọi trường hợp đều là "thay đúng 1 operator": `Tj`/`'`/`"` thay chuỗi operand cuối;
    `TJ` (dù nhiều mảnh) thay CẢ MẢNG bằng 1 mảng mới chỉ có 1 chuỗi (bỏ hết số kerning cũ — chúng
    được canh riêng cho đúng các ký tự của chữ CŨ, không có ý nghĩa gì với chữ mới khác). `[(chữ mới)]
    TJ` (mảng 1 phần tử) hợp lệ y hệt `(chữ mới) Tj`.
  - **1 giả định CHƯA kiểm chứng, nói thẳng**: cách đọc dùng `editContent()` + `PdfCanvas(PdfStream(),
    ...)` bỏ đi — dựa trên hiểu biết chung rằng 1 `PdfStream()` không gắn vào đâu trong cây đối tượng
    của tài liệu thì sẽ KHÔNG bị serialize vào PDF đầu ra (không rò object mồ côi) — chưa test thật.
    Nếu build xong thấy file PDF đầu ra to bất thường hoặc chứa nhiều object thừa sau nhiều lần mở/
    duyệt trang, đây là chỗ đầu tiên nên nghi ngờ.
  - **Bài học đáng ghi lại về chính cách làm việc**: cả 2 lần người dùng hỏi "sao không tra cứu" (phiên
    thứ 9, 10), lần đầu tra cứu ra 1 lỗi thật, lần sau lập luận lại thì ra 1 lỗi trong LẬP LUẬN của tôi
    — đều không phải kết quả của việc "tra cứu nhiều hơn" mà của việc hỏi lại giả định "cần đoán" có
    thật sự đúng không. Trước khi kết luận "không thể tránh khỏi đoán/từ chối", phải tự hỏi trước:
    đây là sự thật cấu trúc đọc được thẳng, hay thật sự chỉ là suy đoán?
  - Đã chạy lại đủ 6 cách rà soát tĩnh — vẫn đúng 59 báo động, cùng 2 loại đã biết, không có báo
    động mới. API công khai của `PdfTextEditor` KHÔNG ĐỔI (cùng tên/tham số/kiểu trả về) nên
    `PdfTextEditActivity` không phải sửa dòng nào.
  - Vẫn **chưa build-test được lần nào** — không đổi.

## 1. Yêu cầu gốc từ người dùng (theo đúng thứ tự đã nêu, để không sót)

1. Xây app Android kiểu CamScanner: chụp ảnh, scan ảnh, tạo PDF từ ảnh chụp.
2. Trả lời khảo sát ban đầu:
   - Ngôn ngữ: **muốn so sánh Kotlin vs Java** (chưa làm — xem mục 0).
   - Mức tính năng: **Đầy đủ** (gồm cả OCR nhận diện văn bản).
   - Môi trường: **không có PC, không có project sẵn**, cần **source code dạng zip để tự upload lên
     GitHub và build APK bằng GitHub Actions** (không dùng máy cá nhân).
3. Mở rộng phạm vi (rất quan trọng — đổi định hướng toàn bộ app):
   - App phải có **các tính năng chỉnh sửa PDF khác, ngang hàng** với tính năng camscanner — không
     phải tính năng phụ đính kèm.
   - Tính năng scan phải nhận ảnh từ **nhiều nguồn**: chụp camera, chọn từ thư viện ảnh máy, và
     **nhập từ 1 file PDF khác để scan lại**.
   - Hỏi: cách xử lý ảnh nào giúp tài liệu **dễ đọc nhất trên máy đọc sách e-ink**.
4. Phản hồi/điều chỉnh: chỉ ra rằng **e-ink màu (Kaleido 3...) đã phổ biến**, không còn chỉ có màn
   trắng đen như giả định ban đầu → cần xử lý cả 2 trường hợp trắng đen và màu cho e-ink.
5. Hỏi có chế độ **tự động nhận diện** trang trắng đen/màu để tự chọn preset e-ink phù hợp không
   (thay vì người dùng phải tự chọn 1 preset chung cho cả tài liệu) → đã làm (mục 4.6).
6. Yêu cầu viết tài liệu kỹ thuật này (file bạn đang đọc).
7. Mở rộng thêm 2 tính năng:
   - **Tạo ebook nhiều định dạng sau khi OCR**, có tuỳ chọn người dùng tự chọn mục lục (đánh dấu
     trang nào bắt đầu chương mới + đặt tên chương) → đã làm (mục 4.10).
   - **Tách ảnh chụp 2 trang sách thành 2 ảnh trang đơn**, thực hiện ở giai đoạn TRƯỚC khi crop ảnh
     → đã làm (mục 4.9).
8. Yêu cầu thêm tính năng **nén PDF đã quét**, mục tiêu "nén 10 lần nhưng chữ không vỡ ảnh" → đã
   làm (mục 4.11), gồm 2 cách chọn được: an toàn (1-bit+Deflate) và CCITT Group 4 (đúng công nghệ
   máy scan thật dùng, theo yêu cầu làm cả 2 cách để người dùng tự chọn).
9. Hỏi app có chuyển đổi được giữa các định dạng ebook không, rồi yêu cầu **"tất cả các loại convert
   document"** → đã làm 1 công cụ "Chuyển đổi định dạng" chung cho PDF/EPUB/TXT/Ảnh (mục 4.12).
10. Hỏi convert xong thì ebook gốc có mục lục có bị mất mục lục không → xác nhận có mất 1 phần, rồi
    yêu cầu sửa → đã sửa 2 điểm: đọc tên chương ưu tiên từ mục lục thật của EPUB nguồn (thay vì chỉ
    đoán qua `<h1>`), và thêm bookmark điều hướng thật vào PDF xuất ra (mục 4.12).
11. Hỏi phần scanner có backup/restore toàn bộ tiến trình không → xác nhận KHÔNG có (phiên quét chỉ
    ở bộ nhớ trong, mất khi app bị hệ thống tắt/crash/khởi động lại máy) → được yêu cầu làm → đã làm
    (mục 4.13): tự lưu phiên quét xuống đĩa sau mỗi thay đổi, hỏi khôi phục khi mở lại app.
12. Hỏi app hiện tại có đi đúng 1 quy trình cụ thể người dùng mô tả hay không (tạo dự án → chọn ảnh
    [cam hoặc thư viện, đa chọn] → chỉnh sửa ảnh [tự crop, tự gợi ý tách trang đôi, có duyệt lại] →
    chọn kiểu quét [preset cho e-ink/nén, có chỉnh tay] → xuất PDF [tự tạo mục lục từ mục lục sách,
    cho kiểm tra & sửa] → nén PDF → OCR → tạo ebook; mỗi bước thoát ra đều lưu trạng thái + có file
    dùng ngay, mở lại đúng chỗ đã dừng) → trả lời chi tiết: KHÔNG khớp — các kỹ thuật xử lý ảnh/PDF
    đã có sẵn nhưng nằm rời rạc ở các công cụ độc lập, không nối thành 1 luồng "dự án", và chưa hề có
    tính năng tự tạo mục lục từ mục lục sách. Được yêu cầu **xây đúng quy trình đó**, với 2 ràng buộc
    rõ: (a) không được xoá công cụ độc lập đã có — chúng trở thành lựa chọn/công cụ phụ, giữ nguyên;
    (b) các bước NẰM TRONG quy trình dự án thì bắt buộc phải đi tuần tự, không được bỏ qua bước nào
    → đã làm (mục 4.15): model `Project` mới + 9 màn hình mới đi đúng 8 bước, tái dùng tối đa logic
    xử lý ảnh/PDF/OCR/ebook đã có, cộng thêm tính năng mới hoàn toàn là tự động dò mục lục qua OCR
    (`TocDetector`).
13. Hỏi kỹ về cách nén PDF (bước nén trong luồng Dự án dùng thuật toán nào, có phải render trang
    thành ảnh không, so với cách các tool nén PDF khác — kiểu Ghostscript/qpdf — sửa thẳng object
    ảnh trong PDF mà không cần "chụp lại" từng trang). Xác nhận: đúng là app phải render vì không có
    thư viện đọc cấu trúc PDF; với PDF app tự quét thì không thiệt gì (mỗi trang vốn đã là ảnh), NHƯNG
    công cụ "Nén PDF" độc lập nhận PDF NGOÀI bất kỳ, kể cả PDF có chữ thật — cách render sẽ phá chữ
    thật và có thể làm file TO HƠN bản gốc, không có ý nghĩa. Yêu cầu: đổi công nghệ nén cho đúng
    trường hợp "PDF ngoài", còn bước nén trong luồng Dự án/Scanner GIỮ NGUYÊN không đổi → đã thêm 2
    lớp bảo vệ vào `MainActivity.compressExistingPdf()` (cảnh báo trước nếu nghi có chữ thật + không
    bao giờ trả về file nén to hơn bản gốc — xem mục 4.11 và mục 8 để biết vì sao KHÔNG đổi hẳn sang
    kiểu sửa-object-PDF-trực-tiếp như Ghostscript).

## 2. Kiến trúc tổng thể

- **Kotlin, Android Gradle Plugin, không dùng Gradle Wrapper** (lý do: xem mục 8.1). CI tự cài đặt
  Gradle qua action, không cần file `gradle-wrapper.jar` trong repo.
- **Không dùng thư viện PDF ngoài** (không iText/PDFBox) — mọi thao tác đọc/ghi PDF chỉ dùng 2 API
  có sẵn trong Android: `android.graphics.pdf.PdfRenderer` (đọc/rasterize PDF có sẵn thành bitmap
  từng trang) và `android.graphics.pdf.PdfDocument` (vẽ bitmap thành PDF mới). Đánh đổi: các công
  cụ ghép/tách/xoay/xoá trang đều là **rasterize rồi dựng lại** — chữ thật (chọn/copy được) trong
  PDF gốc sẽ thành ảnh, mất khả năng chọn/copy sau khi qua các công cụ này. Đây là đánh đổi **có
  chủ đích** để giảm rủi ro build (xem mục 8.2 lý do đầy đủ), không phải thiếu sót vô tình.
- **OpenCV** (`org.opencv:opencv:5.0.0.1`, xác nhận qua tra cứu là artifact chính thức trên Maven
  Central, không cần build NDK) dùng cho: phát hiện 4 góc tài liệu, làm phẳng phối cảnh (warp), các
  bộ lọc màu/xám/trắng đen, tăng bão hoà màu, và heuristic nhận diện trang màu/trắng đen.
- **ML Kit Text Recognition** (`com.google.mlkit:text-recognition:16.0.1`, bản **bundled** — không
  phải bản phụ thuộc Google Play Services tải model runtime) dùng cho OCR, chạy hoàn toàn offline.
- **CameraX** (`1.4.1`) cho màn hình chụp.
- **Luồng dữ liệu trong phiên quét hiện tại**: `ScanSessionManager` (object singleton, in-memory,
  KHÔNG dùng database) giữ danh sách trang đang xây dựng. Cố ý đơn giản hoá vì 1 phiên quét thường
  ngắn (chụp vài trang rồi xuất luôn).
- **`PendingCropQueue`** (object singleton riêng): hàng đợi ảnh chờ đưa qua màn hình crop, dùng khi
  nhập nhiều ảnh cùng lúc (chọn nhiều ảnh thư viện, hoặc mọi trang render từ 1 PDF nhập vào) — nhờ
  đó **camera / thư viện ảnh / nhập PDF đều dùng chung 1 màn hình `CropActivity`**, không phải viết
  3 màn hình riêng.
- **`CropActivity` có 2 chế độ điều hướng** (Intent extra `EXTRA_QUEUE_MODE`):
  - *Single* (camera): lưu xong → trả `RESULT_OK`/`RESULT_CANCELED` về cho `CaptureActivity` để nó
    tiếp tục vòng lặp xem trước camera.
  - *Queue* (thư viện ảnh / nhập PDF): lưu xong tự lấy ảnh kế tiếp trong hàng đợi; hết hàng đợi mới
    điều hướng sang `PageListActivity`.
- **Phát hiện góc tài liệu trả về `null` khi không tìm được contour 4 điểm đủ tin cậy** (diện tích
  ≥20% khung hình) → nơi gọi tự dùng `defaultCorners()` (toàn khung hình, lề 5%). Đây **không phải
  ca lỗi** mà là hành vi ĐÚNG cho ảnh đã phẳng sẵn (trang render từ PDF nhập vào) — nhờ vậy code
  phát hiện góc dùng chung được cho cả 3 nguồn ảnh mà không cần nhánh riêng.

## 3. Bản đồ file/package

```
app/src/main/java/com/example/docscanner/
├── DocScannerApp.kt           # Application, khởi tạo OpenCV + các *State manager + dọn cache (mục 4.14)
├── MainActivity.kt            # màn hình chính: thẻ "Dự án" (nổi bật nhất) + các công cụ độc lập + lịch sử
├── CaptureActivity.kt         # camera (CameraX); 2 chế độ - thường (mục 2) và "chế độ dự án" (mục 4.15)
├── CropActivity.kt            # 2 giai đoạn: kéo góc → chọn bộ lọc; single/queue mode (mục 2) - luồng THƯỜNG
├── PageListActivity.kt        # danh sách trang phiên hiện tại, bộ lọc hàng loạt, xuất PDF+OCR -
│                               # xuất giờ có 3 lựa chọn nén qua CompressOptionsDialog (mục 0/4.11,
│                               # phiên thứ 6), mặc định "Giữ nguyên" giữ đúng hành vi cũ; mỗi trang
│                               # có thêm nút "Chú thích" mở PdfAnnotateActivity (mục 0/4.16, phiên 7)
├── PdfAnnotateActivity.kt     # MỚI (phiên 7): vẽ tay/chữ/che lên trang PDF ngoài hoặc 1 trang đang
│                               # quét dở, "làm phẳng" rồi xuất PDF mới hoặc trả lại cho phiên quét -
│                               # xem mục 4.16
├── PdfTextEditActivity.kt     # MỚI (phiên 8): tìm & thay 1 đoạn chữ THẬT ngắn trong PDF ngoài,
│                               # không rasterize - RỦI RO CAO NHẤT dự án, xem mục 0/4.17/6/9 trước
│                               # khi đụng vào
├── PdfMergeActivity.kt        # ghép nhiều PDF (rasterize + rebuild)
├── PdfPageEditorActivity.kt   # xoay/xoá/sắp xếp/chọn-tách trang từ 1 PDF có sẵn
├── EbookExportActivity.kt     # chạy OCR, soạn mục lục (đánh dấu chương), xuất EPUB/TXT - luồng ĐỘC LẬP
├── ConvertDocumentActivity.kt # chuyển đổi định dạng chung: PDF/EPUB/TXT/Ảnh (mục 4.12)
├── TextResultActivity.kt      # xem + copy văn bản OCR (.txt)
├── ProjectFlow.kt             # điều hướng: stage của Project → Activity tương ứng (mục 4.15)
├── ProjectHubActivity.kt      # danh sách dự án, tạo mới/tiếp tục/xoá (mục 4.15, bước "tạo dự án")
├── ProjectPickImagesActivity.kt # Dự án bước 1: chọn ảnh - camera hoặc thư viện (mục 4.15)
├── ProjectEditActivity.kt     # Dự án bước 2: crop + tách trang đôi (mục 4.15)
├── ProjectScanActivity.kt     # Dự án bước 3: chọn preset quét bắt buộc (mục 4.15)
├── ProjectExportPdfActivity.kt # Dự án bước 4: xuất PDF + mục lục tự động/thủ công (mục 4.15)
├── ProjectCompressActivity.kt # Dự án bước 5: nén PDF (mục 4.15)
├── ProjectOcrActivity.kt      # Dự án bước 6: OCR bắt buộc (mục 4.15)
├── ProjectEbookActivity.kt    # Dự án bước 7 (cuối): tạo ebook (mục 4.15)
├── ProjectSummaryActivity.kt  # màn hình "Hoàn thành" - liệt kê mọi file thành phẩm (mục 4.15)
├── model/
│   ├── ScanPage.kt               # data class: id + filePath + sourceDpi (DPI thật nếu trang render
│   │                              # từ PDF, null nếu ảnh chụp - mục 7 "ASSUMED_DPI")
│   ├── ScanSessionManager.kt     # singleton in-memory, danh sách trang phiên hiện tại (luồng Quét độc lập)
│   ├── PendingCropQueue.kt       # singleton in-memory, hàng đợi ảnh chờ crop (có pushFront cho tách
│   │                              # trang) + sourceDpi dùng chung cho cả lô (mục 6/7, sửa ở phiên này)
│   ├── PdfEditorState.kt         # backup/restore cho PdfPageEditorActivity (mục 4.14)
│   ├── EbookEditorState.kt       # backup/restore cho EbookExportActivity, không lưu văn bản OCR (mục 4.14)
│   ├── PdfMergeState.kt          # backup/restore danh sách file chờ ghép cho PdfMergeActivity (mục 4.14)
│   ├── ProjectEbookEditorState.kt # backup/restore cho ProjectEbookActivity, 1 file JSON riêng theo
│   │                              # từng dự án trong thư mục dự án đó - cùng khuôn mẫu EbookEditorState
│   │                              # nhưng nhiều slot (nhiều dự án cùng lúc) thay vì 1 slot chung (mục 6)
│   ├── PdfTextEditState.kt       # MỚI (phiên 9): backup/restore cho PdfTextEditActivity - KHÁC
│   │                              # khuôn mẫu State khác (không lưu file dở dang mà lưu bản GỐC +
│   │                              # danh sách các lần sửa, khôi phục bằng cách áp lại từ đầu - lý do
│   │                              # kỹ thuật riêng của iText stamping mode, xem mục 0/4.17)
│   ├── Project.kt                # data class Project + ProjectStage + ProjectPage + ProjectTocEntry,
│   │                              # tự serialize/deserialize JSON (mục 4.15)
│   └── ProjectManager.kt         # CRUD Project trên đĩa (tạo/lưu/đọc/liệt kê/xoá) - THUẦN dữ liệu,
│                                  # không biết gì về Activity (mục 4.15, quyết định 22)
├── util/
│   ├── ImageProcessor.kt      # OpenCV: detect góc, warp, 4 filter, boostSaturation, isColorPage,
│   │                          # detectGutterX (gợi ý gáy sách), downscale
│   ├── OcrHelper.kt           # wrapper ML Kit (recognize: text phẳng; recognizeBlocks: theo đoạn)
│   ├── FileUtils.kt           # đường dẫn file (thường + Project), decode ảnh mẫu, decode có xử lý
│   │                          # EXIF, dọn cache định kỳ, openFile/shareFile dùng chung (mục 4.14, 4.15)
│   ├── PdfImportHelper.kt     # wrapper PdfRenderer: đếm trang, render-tất-cả-ra-file (có fileFactory
│   │                          # tuỳ chọn để đổi nơi lưu - mục 4.14), tên hiển thị
│   ├── PdfExporter.kt         # build PDF (từ session / từ đường dẫn ảnh, có thể kèm mục lục qua
│   │                          # PdfBookmarkInjector - mục 4.15 / merge nhiều PDF), xuất ảnh;
│   │                          # writeOcrTextFile() tách riêng từ exportSession() ở phiên thứ 6 để
│   │                          # dùng chung với luồng nén mới trong PageListActivity (mục 0)
│   ├── EbookBuilder.kt        # dựng EPUB (tự viết bằng java.util.zip, không thư viện ngoài) + TXT
│   ├── CompressOptionsDialog.kt # hộp thoại chọn cách nén dùng chung, mỗi dòng có Ưu/Nhược điểm
│   │                          # thật - dùng bởi cả công cụ "Nén PDF" (MainActivity) lẫn luồng Quét
│   │                          # lúc xuất (PageListActivity) - thêm ở phiên thứ 6, xem mục 0
│   ├── PdfCanvasEditor.kt     # MỚI (phiên 8): port Kotlin gần nguyên văn 1 class thật từ
│   │                          # mkl-public/testarea-itext7 - khung sửa content stream PDF, ghi lại
│   │                          # y nguyên MỌI operator qua bộ serialize của iText trừ khi bị override
│   │                          # - xem mục 0/4.17, đọc kỹ doc comment trong chính file trước khi sửa
│   ├── PdfTextEditor.kt       # MỚI (phiên 8): logic tìm/sửa đoạn chữ thật trong PDF, dùng
│   │                          # PdfCanvasEditor ở trên - RỦI RO CAO NHẤT dự án, xem mục 0/4.17/6/9;
│   │                          # viết lại ở phiên 10: ĐỌC lẫn GHI đều duyệt qua CÙNG 1 lớp
│   │                          # PdfCanvasEditor (1 operator hiện chữ = 1 chunk, TJ nhiều mảnh gộp
│   │                          # thành 1) - đọc mục 0 (phiên 9, 10) trước khi sửa file này
│   ├── PdfByteWriter.kt       # ghi object/xref PDF ở mức byte thô (dùng cho PdfCompressor)
│   ├── PdfCompressor.kt       # nén PDF đã quét: tự ghi PDF thô (không qua PdfDocument), chọn
│   │                          # 1-bit+Deflate hoặc CCITT G4 cho trang chữ, JPEG cho trang màu; có
│   │                          # thể ghi thẳng mục lục (Outline) cùng lúc - mục 4.15, quyết định 21;
│   │                          # tham số pageDpis (tuỳ chọn) thêm ở phiên thứ 6 để hỗ trợ DPI khác
│   │                          # nhau theo từng trang khi dùng cho luồng Quét (mục 0)
│   ├── PdfObjectRecompressor.kt # sửa thẳng object ảnh trong 1 PDF NGOÀI bất kỳ bằng iText (không
│   │                          # rasterize) - dùng cho trường hợp PDF có chữ thật, khác hẳn
│   │                          # PdfCompressor ở trên (chỉ dùng cho PDF app tự quét) - xem mục 4.11
│   ├── Ccitt4Encoder.kt       # mã hoá CCITT Group 4 (T.6/MMR) tự viết, đã kiểm chứng kỹ (mục 4.11)
│   ├── Ccitt4Decoder.kt       # giải mã lại để tự kiểm tra ngay trên máy trước khi dùng kết quả G4
│   ├── EpubReader.kt          # đọc lại 1 file EPUB có sẵn thành chapters (dùng cho mục 4.12)
│   ├── TextPdfBuilder.kt      # vẽ chapters thành PDF chữ thật (dùng PdfDocument bình thường - văn
│   │                          # bản không phải mối lo nén ảnh như PdfCompressor)
│   ├── PdfBookmarkInjector.kt # vá bookmark vào PDF do PdfDocument ghi (byte-patching, mục 4.12)
│   ├── ScanPresetApplier.kt   # 7 preset quét, tách ra từ PageListActivity để dùng chung với
│   │                          # ProjectScanActivity (mục 4.15, quyết định 23)
│   └── TocDetector.kt         # MỚI HOÀN TOÀN: dò trang "Mục lục" của sách qua OCR + regex, tự gợi ý
│                              # tên chương (mục 4.15 - đọc kỹ phần giới hạn của heuristic này)
├── view/
│   ├── CropOverlayView.kt        # custom View: 4 góc kéo-thả, tự quy đổi toạ độ bitmap<->view (dùng
│   │                              # chung cho cả CropActivity và ProjectEditActivity)
│   ├── SplitLineOverlayView.kt   # custom View: 1 đường kéo-thả để tách ảnh 2 trang thành 2 (dùng
│   │                              # chung cho cả CropActivity và ProjectEditActivity)
│   └── AnnotationCanvasView.kt   # MỚI (phiên 7): custom View vẽ tay/chữ/che lên 1 bitmap trang, có
│                                  # hoàn tác, cùng cách quy đổi toạ độ bitmap<->view như 2 View trên
│                                  # + hàm flatten() làm phẳng ra bitmap độ phân giải đầy đủ - dùng
│                                  # ở PdfAnnotateActivity (mục 4.16)
└── adapter/
    ├── PageListAdapter.kt    # grid trang phiên quét (xoá + kéo sắp xếp + chú thích - phiên 7)
    ├── HistoryAdapter.kt     # list PDF/EPUB/TXT đã xuất (icon theo loại file, chia sẻ/xoá/xem) -
    │                         # dùng lại nguyên cho ProjectSummaryActivity (mục 4.15)
    ├── PdfFileAdapter.kt     # list file PDF chờ ghép (kéo sắp xếp)
    ├── PdfPageAdapter.kt     # grid trang PDF đang chỉnh (xoay/chọn/xoá/kéo sắp xếp)
    ├── EbookPageAdapter.kt   # list trang cho màn soạn mục lục ebook (bật/tắt "chương mới" + tên
    │                         # chương) - dùng lại nguyên cho ProjectEbookActivity (mục 4.15)
    ├── ProjectAdapter.kt     # list dự án cho ProjectHubActivity - dùng lại layout item_history.xml
    ├── TocEntryAdapter.kt    # list mục lục có thể sửa cho ProjectExportPdfActivity (mục 4.15)
    └── SimpleThumbnailAdapter.kt  # grid thumbnail chỉ-xem, dùng cho ProjectScanActivity (mục 4.15)
```

Layout XML tương ứng 1-1 theo tên cho các file trên (ví dụ `activity_main.xml`,
`activity_capture.xml`, `activity_crop.xml`, `activity_page_list.xml`, `activity_pdf_merge.xml`,
`activity_pdf_page_editor.xml`, `activity_text_result.xml`, `item_page.xml`, `item_history.xml`,
`item_pdf_file.xml`, `item_pdf_page.xml`), CỘNG THÊM cho luồng Dự án (mục 4.15):
`activity_project_hub.xml`, `activity_project_pick_images.xml`, `activity_project_edit.xml`,
`activity_project_scan.xml`, `activity_project_export_pdf.xml`, `activity_project_compress.xml`,
`activity_project_ocr.xml`, `activity_project_summary.xml`, `item_toc_entry.xml`,
`item_thumbnail.xml`. `ProjectEbookActivity` KHÔNG có layout riêng - dùng lại nguyên
`activity_ebook_editor.xml`/`ActivityEbookEditorBinding` (xem mục 4.15).

Ngoài cây thư mục trên, còn có `KOTLIN_VS_JAVA.md` ở gốc dự án (câu trả lời cho mục 1, ý 1-đầu).

## 4. Đã hoàn thành (chi tiết)

### 4.1 Quét tài liệu (camscanner gốc)
- 3 nguồn ảnh đầu vào từ 1 dialog chọn nguồn trong `MainActivity`: camera / thư viện ảnh (Photo
  Picker, chọn nhiều) / nhập từ file PDF khác (SAF `OpenDocument`, render mọi trang bằng
  `PdfImportHelper`).
- Cả 3 nguồn đều đi qua chung `CropActivity`: tự phát hiện 4 góc (OpenCV), cho kéo tay chỉnh lại
  (`CropOverlayView`), làm phẳng phối cảnh, rồi chọn bộ lọc (xem 4.2) và lưu trang.
- Ảnh camera/thư viện được decode có xử lý **EXIF orientation** trước khi xử lý (xem mục 7 — đây là
  1 lỗi thật đã tìm và sửa, không phải làm ngay từ đầu).

### 4.2 Bộ lọc mỗi trang (lúc quét, trong `CropActivity`)
4 lựa chọn thủ công: Màu gốc / Tăng sáng / Xám / Trắng đen (ngưỡng thích ứng — `adaptiveThreshold`,
không phải ngưỡng cố định, để chịu được ánh sáng không đều). **Tự động gợi ý sẵn** 1 trong 2 lựa
chọn (Trắng đen nếu heuristic thấy trang không màu, Tăng sáng nếu thấy có màu) ngay sau khi warp
xong — người dùng vẫn bấm đổi được bằng tay.

### 4.3 Bộ lọc hàng loạt (trong `PageListActivity`, menu "Bộ lọc hàng loạt")
7 lựa chọn, mặc định chọn sẵn **Tự động**:
- Giữ màu gốc / Tăng sáng / Xám / Trắng đen (áp cho toàn bộ, không phân biệt từng trang)
- **E-ink – Văn bản**: trắng đen thích ứng + giảm còn ~2500px cạnh dài (≈300dpi cho khổ trang
  thường)
- **E-ink – Giữ màu**: tăng sáng/tương phản + tăng bão hoà màu (×1.35 trên kênh S của HSV) + giảm
  còn ~1300px cạnh dài (≈150dpi)
- **Tự động**: chạy `ImageProcessor.isColorPage()` cho TỪNG trang, trang nào bị coi là màu thì áp
  pipeline E-ink màu, còn lại áp E-ink văn bản; kết thúc hiện toast tổng kết
  ("Đã xử lý N trang: X trắng đen, Y giữ màu").

**Cơ sở số liệu cho 300dpi/150dpi**: tra cứu xác nhận công nghệ e-ink màu phổ biến nhất hiện nay
(Kaleido 3 — Kobo Libra/Clara Colour, Kindle Colorsoft, PocketBook Era Color...) hiển thị đen trắng
ở 300ppi nhưng giảm còn 150ppi khi hiển thị màu (do lớp lọc màu phủ trên nền panel đen trắng), và
màu thường bị nhạt/tối hơn thực tế trên loại màn này — đó là lý do preset màu có thêm bước tăng bão
hoà. Máy đọc sách trắng đen thuần (Kindle Paperwhite, Kobo Clara BW...) vẫn đang bán song song,
không phải toàn bộ thị trường đã chuyển sang màu.

### 4.4 Heuristic nhận diện trang màu/trắng đen — `ImageProcessor.isColorPage()`
Chuyển ảnh sang HSV, lấy kênh Saturation, tính tỉ lệ điểm ảnh có saturation > 40 (thang 0-255); nếu
tỉ lệ đó > 2% tổng số điểm ảnh → coi là trang có màu. Ảnh được resize nhỏ (cạnh dài ~300px) trước
khi tính để nhanh. Ngưỡng 40/2% là **suy đoán hợp lý, CHƯA từng test với ảnh thật** — xem mục 6 khi
cần tinh chỉnh.

### 4.5 OCR
`OcrHelper` bọc ML Kit Text Recognition (model bundled sẵn trong app, không cần tải thêm, chạy
offline). Khi bật checkbox "Nhận diện văn bản (OCR)" lúc xuất PDF, mỗi trang được nhận diện, kết quả
lưu thành file `.txt` cùng tên với PDF (không nhúng vào PDF — xem mục 6 giới hạn).

### 4.6 Ghép nhiều PDF — `PdfMergeActivity`
Chọn nhiều file PDF (SAF, có thể bấm "+ Thêm file" nhiều lần để gộp thêm), kéo sắp xếp thứ tự, ghép
bằng cách render từng trang mọi file (200dpi) rồi vẽ tuần tự vào 1 `PdfDocument` mới.

### 4.7 Quản lý trang PDF — `PdfPageEditorActivity`
Mở sẵn dialog chọn file PDF ngay khi vào màn hình. Sau khi tải (render 200dpi mọi trang), hiển thị
lưới trang cho: xoay từng trang (90°/lần), xoá trang, kéo sắp xếp lại (long-press, không có tay cầm
kéo riêng ở màn này), chạm vào ảnh để **chọn** trang (dùng cho tách/trích riêng — nếu không chọn gì,
xuất sẽ lấy TẤT CẢ trang theo thứ tự/góc xoay hiện tại). 2 nút xuất: "Xuất PDF" và "Xuất thành ảnh"
(JPG từng trang).

### 4.8 Lịch sử & chia sẻ (`MainActivity`)
Liệt kê mọi `*.pdf`/`*.epub`/`*.txt` (chỉ `.txt` ĐỘC LẬP, không phải file `.txt` đi kèm 1 `.pdf`
cùng tên) trong `Documents/` của app (external-files-dir riêng, không cần quyền storage). Icon khác
nhau theo loại file (PDF: icon tài liệu; EPUB/TXT: icon quyển sách). Mỗi dòng: chia sẻ (FileProvider
+ `ACTION_SEND`, mime type theo đúng đuôi file), xoá (kèm xoá `.txt` đi kèm cùng tên nếu có — xem
lưu ý ở mục 6 về trường hợp EPUB+TXT xuất cùng lúc dùng chung tên), chạm vào dòng: PDF → mở file
`.txt` OCR đi kèm nếu có; TXT độc lập (ebook) → mở luôn để xem/copy; EPUB → không xem trước được
trong app, chạm vào sẽ mở hộp thoại chia sẻ.

### 4.9 Tách ảnh chụp 2 trang sách (trước khi crop)
Trong `CropActivity`, giai đoạn 1 (chỉnh góc) có thêm nút **"Tách 2 trang"** (góc trên bên phải).
Bấm vào sẽ chuyển sang 1 giai đoạn phụ hiển thị đúng ảnh gốc (CHƯA crop/warp) kèm **1 đường thẳng
đứng kéo-thả được** (`SplitLineOverlayView`, cùng cách quy đổi toạ độ bitmap↔view như
`CropOverlayView`). Vị trí khởi tạo của đường thẳng được gợi ý tự động bằng
`ImageProcessor.detectGutterX()` — tìm dải cột dọc tối nhất (bóng gáy sách) trong khoảng giữa 30%-70%
chiều rộng ảnh (dùng `Core.reduce` lấy trung bình độ sáng từng cột). Đây chỉ là **gợi ý điểm bắt
đầu**, người dùng luôn kéo chỉnh lại được — không có cơ chế nào bắt buộc theo gợi ý tự động.

Bấm "Tách trang" sẽ: cắt ảnh gốc thành 2 bitmap (trái/phải) tại đúng vị trí đường thẳng, lưu nửa
**phải** ra file tạm rồi đẩy vào **đầu** hàng đợi `PendingCropQueue` (`pushFront`, xử lý ngay sau nửa
trái, trước mọi ảnh khác đang chờ), còn nửa **trái** được đưa thẳng vào lại quy trình bình thường
(phát hiện góc → chỉnh tay → chọn lọc → lưu) như thể vừa nạp ảnh mới. Từ thời điểm tách xảy ra,
`CropActivity` **luôn chuyển sang queueMode = true** dù ban đầu vào từ camera (single mode) hay
không — lý do: xem mục 5 (quyết định 11) và mục 8.

Áp dụng đồng nhất cho **cả 3 nguồn ảnh** (camera/thư viện/PDF nhập vào) vì nút này nằm ngay trong
giai đoạn crop dùng chung, không cần code riêng cho từng nguồn.

### 4.10 Tạo Ebook (EPUB/TXT có mục lục) — `EbookExportActivity`

Vào từ 2 chỗ: (a) thẻ công cụ "Tạo Ebook" ở màn hình chính (luôn xoá phiên hiện tại trước, bắt buộc
chọn 1 file PDF để nhập vào — giống công cụ E-ink), hoặc (b) menu "Xuất Ebook" trong `PageListActivity`
(dùng ngay danh sách trang của phiên quét đang có, không xoá, không cần nhập PDF).

Luồng xử lý:
1. Nếu chưa có ảnh (trường hợp (a)), mở SAF chọn file PDF, render toàn bộ trang (200dpi) bằng
   `PdfImportHelper` như các công cụ khác.
2. Chạy OCR cho **từng trang** bằng `OcrHelper.recognizeBlocks()` (khác với `recognize()` dùng cho
   PDF — hàm này trả về danh sách theo **block** ML Kit tự nhóm dòng gần nhau, cho ranh giới đoạn
   văn tốt hơn nhiều so với việc tự tách theo dấu xuống dòng thô của `recognize()`).
3. Hiện danh sách trang (`EbookPageAdapter`): mỗi trang có ảnh thu nhỏ, đoạn xem trước văn bản OCR,
   1 công tắc **"Bắt đầu chương mới tại đây"** (trang 1 luôn bật, không tắt được — luôn có ít nhất 1
   chương), và khi bật thì hiện thêm ô nhập **tên chương** (để trống sẽ tự đặt "Chương N"). Đây
   chính là cách "người dùng chọn mục lục" mà yêu cầu đã nêu.
4. Người dùng đặt tên sách, chọn định dạng muốn xuất (checkbox EPUB / TXT, mặc định cả 2 đều bật —
   đúng nghĩa "nhiều định dạng khác nhau" trong yêu cầu).
5. Bấm Xuất: gộp trang thành danh sách `Chapter(title, paragraphs)` theo đúng các mốc "chương mới"
   đã đánh dấu, rồi gọi `EbookBuilder.buildEpub()`/`buildTxt()` tương ứng, lưu vào `Documents/`
   cùng thư mục với PDF, tên file `ebook_<timestamp>.epub`/`.txt` (khác tiền tố `scan_` của PDF để
   không đụng tên).

**`EbookBuilder.buildEpub()`** tự dựng cấu trúc EPUB bằng `java.util.zip` (KHÔNG dùng thư viện EPUB
ngoài): `mimetype` (bắt buộc là entry ZIP đầu tiên, STORED không nén) + `META-INF/container.xml` +
`OEBPS/content.opf` (metadata + manifest + spine) + `OEBPS/nav.xhtml` (mục lục EPUB3) +
`OEBPS/toc.ncx` (mục lục EPUB2, thêm vào để tương thích ngược với app đọc sách cũ) +
1 file `.xhtml` riêng cho mỗi chương + `styles.css` cơ bản. Toàn bộ text được escape XML
(`&`, `<`, `>`, `"`, `'`) trước khi chèn vào — quan trọng vì văn bản OCR có thể chứa ký tự đặc biệt.

**Quyết định không làm MOBI/AZW3**: đã tra cứu xác nhận Amazon **ngừng nhận file MOBI hoàn toàn từ
18/3/2025**, và Kindle đã nhận EPUB trực tiếp qua Send-to-Kindle từ 2022 — nên EPUB vừa an toàn hơn
(tự viết bằng ZIP có sẵn, không cần đoán định dạng nhị phân độc quyền của Amazon mà không cách nào
kiểm chứng được) vừa là lựa chọn "tương lai" hơn MOBI. FB2 (định dạng ebook Nga phổ biến) cũng được
cân nhắc (dễ làm vì cũng chỉ là XML, tái dùng được cấu trúc `Chapter` có sẵn) nhưng **chưa làm**, để
dành nếu người dùng cần thêm.

### 4.11 Nén PDF đã quét — `PdfCompressor` (+ `Ccitt4Encoder`/`Ccitt4Decoder`)

Công cụ "Nén PDF" ở màn hình chính: chọn 1 file PDF có sẵn (bất kỳ, không riêng file app này tạo
ra), chọn cách nén cho trang chữ (dialog hỏi ngay trước khi chọn file), render lại toàn bộ trang ở
250dpi rồi ghi ra 1 PDF hoàn toàn mới **tự viết ở mức byte thô** (`PdfByteWriter`) — KHÔNG dùng
`android.graphics.pdf.PdfDocument` cho tính năng này, vì lý do quan trọng: đã tra cứu xác nhận (mã
nguồn/mailing list Skia — engine PDF Android dùng bên dưới) rằng `PdfDocument` lưu bitmap đưa vào
gần như nguyên trạng (không tự nén ảnh) trừ khi cắm thêm JPEG encoder qua API Skia cấp thấp mà
`PdfDocument` công khai của Android không hề lộ ra — nghĩa là KHÔNG có cách nào khiến `PdfDocument`
thật sự nén ảnh, nên nó vô dụng cho 1 tính năng mà mục đích chính là giảm dung lượng theo tỉ lệ cụ
thể. `PdfExporter` (các tính năng khác) vẫn tiếp tục dùng `PdfDocument` bình thường vì những tính
năng đó không cam kết tỉ lệ nén cụ thể nào.

Mỗi trang được tự động phân loại (dùng lại `ImageProcessor.isColorPage()`):
- **Trang màu/ảnh chụp**: giảm cạnh dài còn ≤1600px + nén JPEG chất lượng 55, nhúng thẳng bytes
  JPEG vào PDF qua `/Filter /DCTDecode` (có mất chi tiết, nhưng chỉ áp cho ảnh, không áp cho chữ).
- **Trang chữ** (đa số): nhị phân hoá đen trắng thật (trắng đen thích ứng, dùng lại bộ lọc "Trắng
  đen" đã có), sau đó nén bằng 1 trong 2 cách **hoàn toàn không mất dữ liệu** — người dùng tự chọn
  qua dialog trước khi bắt đầu:
  1. **An toàn (1-bit + Deflate)**: đóng gói 1-bit/điểm ảnh (giảm 8 lần ngay lập tức so với 8-bit
     xám) rồi nén thêm bằng Deflate (`java.util.zip`, có sẵn trong JDK, cùng công cụ dùng để viết
     EPUB). Nhúng qua `/Filter /FlateDecode`.
  2. **CCITT Group 4 (thử nghiệm)**: đúng công nghệ nén mà máy scan/phần mềm scan thật dùng cho
     trang chữ đen trắng, nén sâu hơn cách 1 nữa. Nhúng qua `/Filter /CCITTFaxDecode` với
     `/DecodeParms << /K -1 /Columns W /Rows H /BlackIs1 false /EndOfBlock false >>`.

**Vì sao có 2 lựa chọn**: người dùng hỏi trực tiếp "có làm CCITT G4 như máy scan thật không", được
báo trước rủi ro (codec nhị phân phức tạp, tự viết mà không có máy Android thật để build/test),
người dùng yêu cầu **làm cả 2 cách để tự chọn** — không chọn 1 trong 2 thay người dùng.

#### Cách đã kiểm chứng CCITT Group 4 (quan trọng — đọc trước khi sửa `Ccitt4Encoder`/`Ccitt4Decoder`)

Đây là phần rủi ro kỹ thuật cao nhất trong toàn bộ dự án (codec nhị phân thật, sai 1 bit trong bảng
mã Huffman là hỏng thầm lặng, không cách nào phát hiện bằng mắt). Vì môi trường viết code không có
Android thật để test, đã dùng cách khác: **dựng và kiểm chứng thuật toán trong Python trước, có đối
chiếu với 1 bộ giải/mã hoá CCITT G4 đáng tin cậy đã có sẵn (libtiff, qua thư viện Pillow của
Python)**, rồi mới chuyển (port) sang Kotlin:

1. Viết bảng mã Modified Huffman (run-length trắng/đen, terminating + makeup + extended makeup) và
   thuật toán 2D (Pass/Horizontal/Vertical mode, logic tìm b1/b2 theo chuẩn T.6) bằng Python, dựa
   trên hiểu biết có sẵn về chuẩn ITU-T T.4/T.6.
2. Viết bộ **giải mã** trước, test đối chiếu: mã hoá ảnh bằng `Pillow` (`Image.save(...,
   compression='group4')`, dùng libtiff bên dưới) → dùng bộ giải mã Python tự viết để giải mã lại →
   so khớp từng điểm ảnh với ảnh gốc. Test trên 11 mẫu ảnh khác nhau (hình chữ nhật, các dòng giống
   chữ, dòng giống nhau liên tiếp, checkerboard, nhiễu ngẫu nhiên, toàn trắng, toàn đen, cả 1 trang
   giả lập 400×300 điểm ảnh) — khớp 100%.
3. Viết bộ **mã hoá** bằng chính logic/bảng đã kiểm chứng ở bước 2, test đối chiếu ngược lại: mã
   hoá cùng 11 ảnh đó bằng code Python tự viết, so **khớp từng byte** với kết quả mã hoá của
   libtiff. Sau khi phát hiện thiếu 3 byte "EOFB" (2 mã EOL liên tiếp ở cuối luồng — nhiều bộ mã
   hoá thêm vào dù không bắt buộc với PDF) và thêm vào, cả 11/11 mẫu khớp **chính xác từng byte**
   với libtiff — mức xác nhận cao nhất có thể đạt được khi không có máy Android thật.
4. Bảng mã trong file Kotlin **không gõ tay lại lần 2** — dùng script Python xuất thẳng ra cú pháp
   Kotlin (`arrayOf(...)`, `mapOf(...)`) từ đúng dữ liệu Python đã kiểm chứng, để không có cơ hội
   gõ sai khi chuyển ngôn ngữ. Riêng phần logic thuật toán (vòng lặp mã hoá/giải mã, BitWriter/
   BitReader) được chuyển tay sang Kotlin (Python không tự sinh code Kotlin phức tạp được), có rà
   soát so sánh từng dòng với bản Python đã kiểm chứng.
5. **Lưới an toàn cuối cùng nằm ngay trong app**: `PdfCompressor` gọi `Ccitt4Encoder.encode()` rồi
   NGAY LẬP TỨC gọi `Ccitt4Decoder.verify()` giải mã lại và so khớp với ảnh gốc, TRƯỚC KHI quyết
   định dùng kết quả đó. Nếu không khớp (dù rất khó xảy ra sau bước kiểm chứng trên, nhưng đây là
   lưới an toàn cho đúng trang bị lỗi đó, không phải cho cả file) → tự động dùng lại cách an toàn
   (1-bit+Deflate) CHO ĐÚNG TRANG ĐÓ, các trang khác không ảnh hưởng. Nghĩa là: cho dù bảng mã hay
   thuật toán còn sót lỗi ở 1 tình huống nào đó chưa test tới, kết quả tệ nhất là trang đó nén kém
   hơn một chút — KHÔNG BAO GIỜ ra file PDF hỏng/không đọc được.

**Điều CHƯA thể xác nhận** (vì không có máy Android thật): code Kotlin (khác hoàn toàn code Python
đã test) có compile đúng và chạy đúng như bản Python hay không — bước rà soát tay từng dòng đã làm
kỹ, nhưng đây là lần đầu code này chạy trên Android thật. Do có lưới an toàn tự giải mã lại (bước
5), rủi ro cao nhất nếu có lỗi port là "nén CCITT G4 kém hơn dự kiến / tự rơi về cách an toàn nhiều
hơn dự kiến", KHÔNG phải "ra file hỏng".

#### Giới hạn thật khi nén 1 PDF NGOÀI (không phải PDF do chính app quét ra) — và lưới an toàn đã thêm

Người dùng hỏi thẳng: nhiều tool nén PDF ngoài kia (Ghostscript, qpdf...) sửa THẲNG vào cấu trúc PDF
— tìm đúng object ảnh đã nhúng sẵn, nén lại đúng object đó, không đụng gì khác — vậy sao app này lại
"chụp lại" (render) từng trang thành ảnh rồi dựng PDF mới từ đầu?

**Trả lời thẳng: vì app không có khả năng đọc/sửa cấu trúc PDF ở mức object** (không có thư viện
kiểu PDFBox, xem mục 6) — cách DUY NHẤT lấy được pixel ra từ 1 PDF bất kỳ là dùng `PdfRenderer` của
Android để "chụp" từng trang. Với PDF do CHÍNH app quét ra (mỗi trang vốn dĩ đã là 1 ảnh chụp), cách
này không thiệt gì — nhưng công cụ "Nén PDF" độc lập ở `MainActivity` cho phép chọn BẤT KỲ file PDF
nào trên máy, kể cả file có chữ thật/hình vector (PDF xuất từ Word chẳng hạn). Với loại file đó,
"chụp lại thành ảnh" là lựa chọn TỆ: vừa mất khả năng chọn/tìm chữ, vừa thường ra file TO HƠN bản
gốc (chữ vector vốn rất nhẹ, "chụp" thành ảnh rồi nén lại vẫn nặng hơn).

Việc chuyển hẳn sang cách sửa-object-PDF-trực-tiếp như Ghostscript đòi hỏi thêm 1 thư viện đọc/ghi
PDF thật vào dự án — rủi ro cao hơn hẳn mọi thứ đã làm từ trước tới giờ (kể cả CCITT G4 ở trên,
vốn còn kiểm chứng được qua Python/libtiff trước khi port; 1 thư viện ngoài thì KHÔNG có cách nào
kiểm chứng được gì trong môi trường này — không mạng, không SDK, không build thật). Vì rủi ro đó
quá lớn so với việc chỉ đang sửa 1 công cụ có sẵn, đã KHÔNG làm theo hướng đó. Thay vào đó, đã thêm
2 lớp bảo vệ vào đúng `MainActivity.compressExistingPdf()` (**chỉ cho công cụ "Nén PDF" độc lập —
bước Nén trong luồng Dự án ở `ProjectCompressActivity` GIỮ NGUYÊN không đổi gì**, vì nguồn vào của
nó luôn là ảnh app tự quét, không có rủi ro này):

1. **Cảnh báo trước khi nén** (`fileLikelyHasRealText()`) — quét thẳng byte thô của file PDF tìm
   chuỗi `/Font` (khoá xuất hiện trong mọi PDF có nhúng font chữ thật). Tìm thấy → hỏi lại người
   dùng có chắc muốn tiếp tục không, nói rõ lý do. Đây KHÔNG phải đọc PDF thật (không parse object,
   không giải nén stream) — chỉ là tìm chuỗi thô trong file, nên **có thể bỏ sót** (PDF hiện đại
   thường nén cả object vào "object stream", lúc đó chuỗi `/Font` nằm trong dữ liệu đã nén, tìm
   thô sẽ không thấy) — chấp nhận được vì hướng bỏ sót là hướng AN TOÀN hơn (không làm phiền người
   dùng đang nén 1 file scan thật với cảnh báo sai), không phải hướng nguy hiểm.
2. **Không bao giờ trả về file "nén" ra mà lại to hơn hoặc bằng bản gốc** — sau khi nén xong, so
   `compressedSize` với `originalSize`; nếu không nhỏ hơn, XOÁ file vừa nén, báo rõ cho người dùng
   là không nén được (không đổi gì cả), thay vì âm thầm đưa ra 1 kết quả tệ hơn lúc đầu. Đây là
   đảm bảo CHẮC CHẮN, không phụ thuộc heuristic nào — khác với mục (1) ở trên.

#### "Sửa trực tiếp" — `PdfObjectRecompressor` (phụ thuộc ngoài ĐẦU TIÊN của cả dự án, dùng iText)

Sau khi 2 lớp bảo vệ ở trên vẫn không giải quyết đúng gốc vấn đề, người dùng yêu cầu thẳng: xây
1 cách nén THẬT KHÁC — sửa object ảnh trong PDF trực tiếp, không render cả trang ra ảnh. Đã làm,
là **lựa chọn thứ 3** trong công cụ "Nén PDF" độc lập (không thay thế 2 cách cũ; luồng Dự án/
Scanner không đổi gì, tiếp tục dùng `PdfCompressor` như cũ, đúng yêu cầu người dùng).

**Thư viện dùng**: `com.itextpdf.android:kernel-android:7.2.5` (Maven repo riêng của iText:
`https://repo.itextsupport.com/android`, xác nhận qua trang cài đặt chính thức kb.itextpdf.com khi
làm việc này). Đây là **phụ thuộc ngoài đầu tiên của toàn bộ dự án** — mọi thứ khác từ trước tới
giờ đều tự viết (CCITT G4, ghi PDF thô, EPUB...) hoặc dùng thư viện có sẵn trong Android SDK.

**Vì sao chọn iText, không phải lựa chọn khác** (đã tra thật bằng web_search, không đoán):
- `TomRoush/PdfBox-Android`: Apache 2.0 (không ràng buộc), nhưng bản cuối cùng là 1/2023, hơn 3 năm
  không có bản mới, có bug report vẫn mở (8/2025), dependency (Bouncy Castle) có CVE chưa vá. Mọi
  fork khác của nó (rzimmer, tripplemac, needlessly, VivyTeam) đều cũ hơn hoặc chỉ là bản sao —
  không có lựa chọn nào trong dòng PdfBox-Android tốt hơn bản chính.
- `DroidPDF`: Kotlin-native, mới hơn, nhưng danh sách tính năng công khai (PDF Generation, Page
  Operations theo TRANG, Annotations, Forms, Encryption, Text Extraction) KHÔNG nhắc gì tới việc
  lấy ảnh đã nhúng ra rồi nén lại — đúng việc cần làm. Rủi ro "làm xong mới phát hiện thư viện
  không hỗ trợ" cao hơn hẳn rủi ro kỹ thuật thông thường.
- `iText 7/8`: được bảo trì thật, có Android build chính thức, và "lấy ảnh XObject ra, nén lại,
  nhét lại vào đúng chỗ" là chức năng "cơm bữa" của nó — có cả trang hướng dẫn chính thức
  ("Replacing images") kèm ví dụ mã nguồn thật trên GitHub (`itext/i7js-examples`). Đổi lại: AGPL
  hoặc phải mua giấy phép thương mại. **Người dùng đã chọn chấp nhận AGPL** (chỉ dùng cá nhân,
  không phát hành app dưới dạng đóng mã nguồn — nếu sau này đổi ý muốn phát hành, cần xem lại giấy
  phép này, không phải chuyện tự động ổn).

**Phát hiện quan trọng lúc viết code (tự tìm, không phải đoán) — ví dụ mẫu chính thức của iText
KHÔNG dùng được trên Android**: hàm mẫu chính thức để lấy pixel ảnh ra
(`PdfImageXObject.getBufferedImage()`) lấy được đúng SOURCE CODE của nó, bên trong gọi thẳng
`javax.imageio.ImageIO.read(...)` — API này **không tồn tại trên Android** (Android không có
`java.awt`/`javax.imageio`; có thư viện shim của bên thứ 3 chuyên vá lỗ hổng này, nhưng chính tác
giả thư viện đó ghi rõ "hackish, đừng dùng cho production"). **Đã né hoàn toàn** — dùng
`getImageBytes()` (không đụng AWT) thay vì `getBufferedImage()`, decode bằng `BitmapFactory` của
Android (đã dùng khắp app này rồi, không thêm rủi ro mới).

**Vì sao phạm vi lúc đầu chỉ có JPEG, sau đó mở rộng thêm đúng 1 trường hợp nữa (`FlateDecode` ảnh
thô)** — người dùng phản đối đúng: "chỉ JPEG" ban đầu là dừng lại quá sớm, chưa tra kỹ xem còn gì
làm được nữa không. Tra lại thì thấy: `getImageBytes()` ghi rõ 3 loại filter
(`DCTDecode`/`JBIG2Decode`/`JPXDecode`) được trả về NGUYÊN BYTE GỐC (không decode thêm ở tầng PDF)
— đúng thứ `BitmapFactory` của Android đọc được thẳng. Mọi filter KHÁC phải đi qua đường decode
tổng quát hơn của iText — tìm được 1 báo lỗi thật (StackOverflow, dùng iTextSharp — bản .NET cùng
kiến trúc xử lý ảnh với bản Java) là chính người viết code đó, có debug trực tiếp nhìn thấy ảnh,
vẫn tính SAI kích thước buffer (lệch đúng 1 byte) khiến ảnh ra bị méo/nhân đôi — phải thử lại nhiều
lần mới đúng. Đây là bằng chứng cụ thể, không phải phỏng đoán, cho thấy đường decode tổng quát dễ
sai ngay cả khi có thể NHÌN THẤY kết quả để sửa — ở đây thì không có cách nào nhìn thấy gì cả.

Thay vì né toàn bộ "không phải JPEG", đã tách riêng: **`FlateDecode` (không có predictor, 8-bit/
kênh màu, `DeviceGray` hoặc `DeviceRGB`) — TỰ giải nén bằng `java.util.zip.Inflater` (thư viện Java
chuẩn, không qua đường decode tổng quát của iText chút nào)**, rồi tự dựng lại từng pixel bằng tay,
với 1 điều kiện bắt buộc: số byte sau khi giải nén phải khớp CHÍNH XÁC `width*height*số_kênh_màu`
— không khớp thì bỏ qua ảnh đó luôn, không đoán. Đây chính là loại lỗi trong báo lỗi thật ở trên
(lệch 1 byte) nên kiểm tra này không phải phòng xa suông. Tìm thêm được 1 dự án mã nguồn mở độc lập
khác (`open-redact-pdf-redact`, Rust) làm đúng cùng bài toán "sửa ảnh trong PDF không cần cả bộ
codec" và TỰ CHỌN đúng phạm vi tương tự (8-bit/kênh, Gray/RGB, Flate+DCT, bỏ qua Indexed/JBIG2/
JPX/CCITT) — củng cố đây không phải cắt góc tuỳ tiện mà là ranh giới hợp lý nhiều dự án độc lập
khác cũng chọn.

**KHÔNG mở rộng thêm** (nói rõ lý do từng cái, không phải "khó quá bỏ qua"):
- ~~**`/DecodeParms /Predictor` >= 2**...~~ — **đã làm ở phiên thứ 5** cho đúng phần Predictor kiểu
  PNG (10-15), xem cập nhật "Predictor kiểu PNG" ngay dưới. Predictor kiểu TIFF (giá trị `2` — khác
  thuật toán hoàn toàn, không có tag lọc theo từng dòng như PNG) thì VẪN chưa làm, vẫn đúng lý do
  gốc (thuật toán khác, việc riêng).
- **`/CCITTFaxDecode`** (PDF scan đã dùng sẵn CCITT): app này đã có sẵn `Ccitt4Decoder` được kiểm
  chứng kỹ — về mặt kỹ thuật CÓ THỂ decode được — nhưng nén LẠI 1 ảnh đã ở dạng CCITT G4 (vốn đã gần
  tối ưu cho ảnh đen trắng) khó có khả năng nhỏ đi thêm được bao nhiêu, trong khi vẫn tốn công decode
  + risk. Không phải "không làm được", mà là "làm được nhưng lợi ích không rõ ràng đủ để đánh đổi
  rủi ro" — khác hẳn lý do bỏ qua Predictor/JBIG2/JPX. **Đã cân nhắc lại kỹ ở phiên thứ 5** (người
  dùng hỏi thẳng vì sao không làm) — kết luận vẫn giữ nguyên, xem mục 6 "Tra cứu JBIG2/JPX... phiên
  thứ 5" để biết đầy đủ lý do (không phải bỏ qua vì lười, mà vì tính lại thấy lợi ích thật sự rất
  nhỏ so với rủi ro tự giải mã sai `/BlackIs1`/`/K` của 1 PDF NGOÀI không do app tự tạo).
- **`/JBIG2Decode`** (JBIG2): **tra cứu lại kỹ ở phiên thứ 5, sau đó đào sâu thêm ở chính phiên này khi
  người dùng bảo "tiếp" — kết luận bị ĐẢO NGƯỢC so với đánh giá lạc quan lúc đầu, nói rõ ở đây để
  không ai (kể cả phiên sau) hiểu lầm là đã "gần xong"**. Đợt tra đầu chỉ xác nhận 1 thư viện thuần
  Java (nhánh mở của JPedal, `github.com/Borisvl/JBIG2-Image-Decoder`) có phần LÕI giải mã không
  đụng AWT — nghe có vẻ khả thi. Nhưng tra thêm 1 lớp nữa ra 2 việc quan trọng đổi hẳn kết luận:
  1. Thư viện NÀY (nhánh JPedal/Borisvl) có lịch sử lỗi thật, không phải suy đoán — 1 bài thảo luận
     độc lập trên nhóm Google (2012) mô tả thẳng đây là "buggy, open-source version of JPedal
     decoder", và có 1 bản port sang .NET khác ghi rõ trong chính tên repo là "with correct MMR
     decoding" — ý nói bản gốc decode SAI ở chế độ MMR (1 trong các kiểu mã hoá JBIG2 dùng cho
     generic region). Có hẳn 1 issue thật kèm file PDF thật tái hiện lỗi ("Quality of JBIG2 image
     in PDF file", trang 2 của 1 PDF từ archive.org bị lỗi chất lượng).
  2. Thư viện THỨ 2 (`levigo/jbig2-imageio`, tách biệt hoàn toàn với JPedal, giờ do cộng đồng Apache
     PDFBox duy trì, tự mô tả "Production quality, robust and well-tested" — người ta còn thấy 1
     thảo luận thật của người dùng đang MUỐN CHUYỂN từ JPedal-decoder buggy SANG đúng thư viện này)
     — tưởng sẽ đáng tin hơn, nhưng tra sâu vào API thật thì thấy hàm đọc dữ liệu thô của nó
     (`JBIG2ImageReader.readRaster()`) trả về thẳng `java.awt.image.Raster`, và constructor
     `JBIG2ReadParam` nhận tham số kiểu `java.awt.Rectangle`/`java.awt.Dimension` — nghĩa là API
     NÀY gắn chặt với AWT ở MỌI tầng, không tách được như JPedal (chỉ 1 lớp vỏ ngoài cùng đụng AWT,
     lõi thì sạch) — muốn dùng trên Android sẽ phải phẫu thuật sâu hơn hẳn dự tính ban đầu. VÀ thư
     viện này CŨNG có báo lỗi thật (`ArrayIndexOutOfBoundsException` trong `Bitmap.blitWithShift`/
     `TextRegion.insertIntoRegionBitmap`, gặp khi decode file JBIG2 thật).
  **Kết luận cuối cùng của phiên này**: CẢ 2 lựa chọn thực tế đều có lịch sử lỗi thật đã ghi nhận
  (không phải giả định) — khác hẳn CCITT G4 ở mục 4.11 phía trên, nơi có Python+libtiff để đối
  chiếu độc lập TRƯỚC khi tin. Ở đây, JBIG2 là chuẩn phức tạp nhiều chế độ (arithmetic coding, MMR,
  symbol dictionary + text region cho chế độ "văn bản" — đúng chế độ hay dùng nhất cho PDF quét chữ,
  vì đó là lý do JBIG2 nén tốt hơn CCITT cho trang chữ), và môi trường này **không có cách nào đối
  chiếu kết quả decode với bất kỳ thứ gì đáng tin** (không mạng trong container để cài thử 1 thư
  viện Python tham chiếu, không máy Android thật để tự mắt xem ảnh ra đúng hay sai). Tự porting 1
  trong 2 thư viện đã biết có lỗi thật, rồi không kiểm chứng được gì, rủi ro ra ảnh SAI (méo, thiếu
  vùng, lẫn lộn) mà KHÔNG BIẾT là sai — đây là loại rủi ro nghiêm trọng hơn hẳn "chỉ là chưa test
  trên máy thật" (như phần lớn dự án này), vì không có lưới an toàn nào bắt được lỗi loại này trước
  khi người dùng thật sự mở file ra xem. Vì vậy: **quyết định KHÔNG tích hợp JBIG2 trong phiên này**
  — đánh giá "khả thi hơn đã nghĩ" ở đầu mục này bị chính phiên sau (vẫn phiên thứ 5, cùng 1 lượt
  hỏi "tiếp") tự sửa lại sau khi đào sâu thêm, không phải phiên khác đảo ngược. Nếu người dùng vẫn
  muốn làm, cách hợp lý nhất là làm như 1 tính năng THỬ NGHIỆM rõ ràng (cảnh báo riêng, không bật
  mặc định) và bắt buộc tự test bằng nhiều file JBIG2 thật trên máy thật trước khi tin bất kỳ kết
  quả nào, không thể tin theo kiểu "có lưới an toàn" như những phần khác của dự án.
- **`/JPXDecode`** (JPEG2000): **tra cứu ở phiên thứ 5** — kết luận KHÔNG có lựa chọn thuần Java/
  Kotlin nào tốt. Mọi lựa chọn thật sự dùng được trên Android đều bọc thư viện gốc OpenJPEG qua JNI/
  WASM (`ThalesGroup/JP2ForAndroid`, `jpx-OpenJpegAndroid`, `keiji/jp2k-decoder-android`) — khác hẳn
  kiểu phụ thuộc thuần Kotlin/Java đã dùng xuyên suốt dự án, không cách nào kiểm chứng việc build/
  liên kết native trong môi trường này; lựa chọn thuần Java duy nhất tìm được (`JDeli`) là thư viện
  THƯƠNG MẠI, không phù hợp. Giữ nguyên quyết định KHÔNG làm, giờ có dữ liệu tra cứu thật để chứng
  minh thay vì chỉ giả định.
- **CMYK, Indexed/palette color space**: thêm 1 lớp chuyển đổi màu nữa (không đơn giản là đọc byte),
  và không có cách nào kiểm tra kết quả màu ra có đúng không ở đây.

**Predictor kiểu PNG (10-15) — đã thêm ở phiên thứ 5, KHÔNG tự viết thuật toán Sub/Up/Average/Paeth**:
người dùng hỏi thẳng "kết hợp công nghệ có sẵn để giải quyết được không" — tra cứu thì phát hiện 1
điều thú vị: định dạng `/Predictor` 10-15 của PDF ĐƯỢC CHUẨN PDF (ISO 32000) ĐỊNH NGHĨA THẲNG bằng
cách dẫn chiếu đúng cơ chế lọc thích ứng theo từng dòng của PNG (tag 1 byte đầu mỗi dòng + toàn bộ
nén zlib) — nghĩa là byte thô bên trong 1 stream `/FlateDecode` có `/Predictor` của PDF, xét ở mức
bit, CHÍNH LÀ đúng nội dung 1 chunk `IDAT` của file PNG, không cần chuyển đổi gì. Vậy thay vì tự viết
thuật toán un-filter (rủi ro cao, không cách nào test ở môi trường này), `PdfObjectRecompressor` bọc
nguyên bytes đó vào 1 file PNG tối giản (signature + IHDR + IDAT + IEND, tự viết ~40 dòng, cơ học,
dễ kiểm tra) rồi đưa thẳng cho `BitmapFactory` — để chính bộ giải mã PNG có sẵn, đã qua kiểm chứng
thật của Android tự làm phần thuật toán khó. Giá trị Predictor 10-15 chỉ là gợi ý phía ENCODER đã
dùng chiến lược nào để CHỌN filter mỗi dòng — không ảnh hưởng cách DECODE (luôn đọc đúng tag byte đã
ghi trong dữ liệu), nên cả 10-15 xử lý y hệt nhau bằng 1 đường code. Predictor `2` (kiểu TIFF, khác
thuật toán, không có tag theo dòng) vẫn KHÔNG được hỗ trợ. Vẫn giữ đúng phạm vi màu/bit-depth cũ
(Gray/RGB, 8-bit/kênh).

**Nén cấu trúc PDF (object stream + xref stream + smart mode) — đã thêm ở phiên thứ 5, đây là phần
trả lời trực tiếp câu hỏi "font/text/vector có được nén không"**: `PdfWriter` giờ được tạo với
`WriterProperties().setFullCompressionMode(true).setCompressionLevel(CompressionConstants.
BEST_COMPRESSION).useSmartMode()` — cả 3 đều là API CÓ SẴN trong đúng `kernel-android` đã dùng, xác
nhận qua tài liệu chính thức của iText (nhất quán từ bản 7.0 tới 9.1, không đổi qua các bản), không
cần thêm phụ thuộc nào. `setFullCompressionMode` nén CHÍNH CẤU TRÚC LƯU TRỮ của file (object stream +
xref stream, tính năng PDF 1.5+) — áp dụng cho MỌI object trong file, kể cả object chứa lệnh vẽ chữ/
font/vector, không riêng ảnh. `useSmartMode` gộp các resource giống hệt nhau (cùng 1 font/ảnh được
nhiều trang tham chiếu) thành 1 bản duy nhất. **Nói rõ giới hạn thật của hướng này, không phóng đại**:
đây KHÔNG phải font subsetting thật (không xoá glyph thừa chưa dùng khỏi font ĐÃ nhúng sẵn trong PDF
nguồn) — tra cứu xác nhận tính năng đó CHỈ có ở gói trả phí `pdfOptimizer` của iText (add-on riêng,
KHÔNG nằm trong `kernel-android` miễn phí đang dùng), không phải "chỉ cần bật 1 cờ là xong". Cũng
không nén lại vector graphics (đơn giản hoá đường path...) — iText không có tính năng này, và tự
viết sẽ đổi hình ảnh hiển thị nên không phù hợp làm mù trong môi trường không kiểm chứng được. Nghĩa
là: cấu trúc lưu trữ toàn file được nén thêm thật (đo được, không phải giả định), nhưng KHÔNG phải
"nén chữ/font/vector theo nội dung" như nén ảnh — 2 khái niệm khác nhau, đã nói rõ để không hiểu lầm.


**Cách hoạt động** (`PdfObjectRecompressor.recompress()`): mở PDF ở chế độ "stamping" (đúng cách
chuẩn của iText để sửa 1 phần, giữ nguyên phần còn lại — xác nhận qua ví dụ mã nguồn thật), `PdfWriter`
bật sẵn nén cấu trúc (xem "Nén cấu trúc PDF" ở trên), duyệt từng trang → từng object trong
`/Resources/XObject` → object nào là ảnh (`/Subtype /Image`) VÀ filter đúng `/DCTDecode` hoặc
`/FlateDecode` (không phải mảng nhiều filter chồng, có hoặc không Predictor kiểu PNG — xem ở trên)
→ lấy pixel ra theo đúng 1 trong các đường ở trên → nén lại ở chất lượng/kích thước y hệt trang màu
của `PdfCompressor` (JPEG quality 55, giới hạn cạnh dài 1600px — dùng lại đúng ngưỡng, không tự đặt số
mới) → nhét ngược vào đúng chỗ cũ trong dictionary. Mọi lỗi (ảnh hỏng, decode fail, sai kích
thước...) bị bắt riêng lẻ từng ảnh — bỏ qua đúng 1 ảnh đó, không làm hỏng cả file. Kết quả cuối vẫn
qua đúng lưới an toàn "không bao giờ trả về file to hơn/bằng bản gốc" (kiểm ở `MainActivity.
runDirectEditCompression`, so sánh kích thước FILE cuối cùng, không phải so từng ảnh — đáng tin
hơn vì không phụ thuộc chữ ký hàm chưa xác nhận được của `PdfStream`).

**Giới hạn đã biết, nói thẳng không né**:
- Chỉ nén được ảnh JPEG hoặc ảnh thô FlateDecode (8-bit, Gray/RGB, có hoặc không Predictor kiểu
  PNG — xem cập nhật phiên thứ 5 ở trên) — PDF scan dùng CCITT có sẵn, JBIG2, JPX, Predictor kiểu
  TIFF, hoặc PDF chỉ toàn chữ thật không có ảnh nào, sẽ báo "0 ảnh được nén" (không phải lỗi — đúng
  bản chất, không có gì làm được ở đó với phạm vi hiện tại). Cấu trúc file (object/xref stream,
  smart mode) vẫn được nén thêm dù báo "0 ảnh" — 2 việc độc lập nhau.
- Cả thư viện (chưa release 3 năm) lẫn code gọi nó (viết dựa trên tài liệu/ví dụ chính thức, KHÔNG
  compile/chạy được ở đây) đều CHƯA được kiểm chứng bằng máy/build thật — xem mục 9 phần rủi ro
  riêng của tính năng này, đây là rủi ro cao NHẤT trong toàn bộ dự án tính đến giờ.
- Repository Gradle của iText (`repo.itextsupport.com`) phải khai đúng trong `settings.gradle`
  (không phải `app/build.gradle`) vì dự án dùng `repositoriesMode.set(FAIL_ON_PROJECT_REPOS)` —
  khai sai chỗ sẽ làm build lỗi ngay từ bước resolve dependency, trước khi tới cả bước compile.

### 4.12 Chuyển đổi định dạng — `ConvertDocumentActivity` (+ `EpubReader`, `TextPdfBuilder`)

Công cụ chung ở màn hình chính: chọn định dạng nguồn (PDF/EPUB/TXT/Ảnh) → chọn định dạng đích (tuỳ
theo nguồn) → chuyển đổi. Để tránh viết trùng lặp, các cặp có liên quan tới PDF được **chuyển tiếp
sang đúng màn hình đã có sẵn** thay vì tự làm lại:
- Nguồn PDF, đích Ebook (EPUB/TXT) → mở `EbookExportActivity` (đã có OCR + soạn mục lục).
- Nguồn PDF, đích Ảnh → mở `PdfPageEditorActivity` (đã có nút "Xuất thành ảnh").

Phần thật sự mới (không có sẵn trước đó):
- **EPUB → PDF hoặc TXT**: `EpubReader.read()` tự đọc file EPUB (là 1 file ZIP) — mở
  `META-INF/container.xml` để tìm `content.opf`, đọc `content.opf` để lấy thứ tự spine (thứ tự đọc)
  + manifest (id → tên file chương), rồi đọc từng file `.xhtml` chương theo đúng thứ tự đó. Chỉ
  dùng `java.util.zip` (đọc ZIP) + `javax.xml.parsers.DocumentBuilderFactory` (đọc XML, có sẵn
  trong JDK/Android) + `android.text.Html.fromHtml()` (có sẵn trong Android, dùng để bỏ thẻ HTML
  lấy văn bản thuần) — không thêm thư viện đọc EPUB/HTML nào. Giới hạn: chỉ đọc được văn bản +
  tiêu đề chương, không giữ ảnh/CSS phức tạp/mục lục lồng nhau — đủ dùng để chuyển sang TXT/PDF,
  không phải trình đọc EPUB đầy đủ. Đọc lại đúng file EPUB mà `EbookBuilder` tự tạo ra thì chắc
  chắn đúng (cùng 1 cấu trúc đã biết trước); đọc EPUB từ nguồn khác thì tuỳ độ phức tạp của file đó.
  **Tên chương** được ưu tiên đọc từ mục lục thật của EPUB (`nav.xhtml` chuẩn EPUB3, nếu không có
  thì `toc.ncx` chuẩn EPUB2 — tìm qua `content.opf`: item có `properties="nav"` cho nav.xhtml, item
  có `media-type="application/x-dtbncx+xml"` cho toc.ncx), chỉ khi KHÔNG tìm được mục lục mới rơi về
  tìm `<h1>` trong nội dung chương, và cuối cùng mới là "Chương N". Sửa sau khi người dùng hỏi "EPUB
  gốc có mục lục, convert xong có mất không" — trước đó chỉ tìm `<h1>`, bỏ qua mục lục thật của file.
- **TXT → PDF hoặc EPUB**: đọc thẳng nội dung `.txt`, tách đoạn theo dòng trống, gộp thành 1
  "chương" duy nhất (không có UI đánh dấu chương như bên Ebook từ ảnh quét, vì TXT không có khái
  niệm "trang" để gắn công tắc chương vào) rồi đưa qua `EbookBuilder.buildEpub()`/`buildTxt()` như
  bình thường.
- **Ảnh → PDF**: copy thẳng các ảnh đã chọn (không crop, không OCR, không qua bước chọn bộ lọc —
  đây là đường nhanh cho người chỉ cần gộp ảnh có sẵn thành 1 PDF) rồi gọi thẳng
  `PdfExporter.exportImagePaths()` đã có sẵn.
- **`TextPdfBuilder`**: vẽ chapters thành PDF chữ thật (không phải ảnh) bằng `Canvas.drawText()`,
  tự ngắt dòng theo độ rộng trang (đo bằng `Paint.measureText()`, tách theo khoảng trắng — hoạt
  động tốt với tiếng Việt vì tiếng Việt có khoảng trắng giữa âm tiết, nhưng KHÔNG hoạt động tốt với
  ngôn ngữ không dùng khoảng trắng giữa từ như tiếng Trung/Nhật), tự sang trang mới khi hết chỗ
  (kể cả giữa 1 đoạn văn dài). Khác với `PdfCompressor`, ở đây dùng `PdfDocument` bình thường là
  ĐÚNG lựa chọn — vì đây là chữ thật (glyph/font PDF chuẩn), không phải bitmap cần kiểm soát cách
  nén, nên không gặp vấn đề "PdfDocument không nén" đã nêu ở mục 4.11/5 (quyết định 14).

- **`PdfBookmarkInjector`** (mới, để có mục lục điều hướng thật trong PDF): `PdfDocument` không có
  API công khai nào để thêm bookmark/outline, nên sau khi `PdfDocument` ghi xong file, công cụ này
  **vá thêm** vào bằng kỹ thuật "incremental update" chuẩn của PDF (cách các trình chỉnh sửa PDF
  thật hay dùng để thêm chú thích mà không đụng vào nội dung gốc) — nối thêm các object bookmark
  mới vào CUỐI file, định nghĩa lại đúng 1 object (Catalog) để trỏ tới bookmark mới, thêm 1 đoạn
  xref+trailer mới trỏ `/Prev` về xref gốc. Không đụng vào nội dung trang gốc.
  **Rủi ro thật cần biết**: để làm được việc này, code phải tự đọc lại 1 phần cấu trúc file PDF mà
  `PdfDocument` vừa ghi ra (tìm trailer → Catalog → Pages → Kids) — đây KHÔNG phải API công khai,
  không có gì đảm bảo Android sẽ luôn ghi đúng định dạng giả định (trailer cổ điển, không phải
  cross-reference stream PDF 1.5+). Toàn bộ quá trình bọc trong try/catch, hễ **bất kỳ bước nào**
  không đúng như kỳ vọng (không tìm thấy trailer, số trang đọc được không khớp số trang thực tế đã
  vẽ, v.v.) → trả về `null` → `TextPdfBuilder` tự động dùng file gốc CHƯA có bookmark, không có
  cách nào ra file hỏng. Nghĩa là: có thể có bookmark hoặc không (tuỳ Android có ghi PDF đúng như
  giả định hay không), nhưng không bao giờ làm hỏng file.

### 4.13 Tự lưu & khôi phục phiên quét — `ScanSessionManager` (backup/restore)

Trước bản này, `ScanSessionManager` (danh sách trang của phiên quét hiện tại) chỉ tồn tại **trong
bộ nhớ (RAM)** — mất sạch nếu app bị hệ thống Android tự tắt (rất hay xảy ra khi app chạy nền lâu
trên máy ít RAM), bị crash, hoặc điện thoại khởi động lại, dù đã chụp được bao nhiêu trang cũng
mất hết, chưa kịp xuất PDF/Ebook. Người dùng hỏi thẳng "có backup/restore không" → xác nhận không có
→ được yêu cầu thêm.

Cách làm: **mỗi lần danh sách trang thay đổi** (thêm/xoá/sắp xếp/đổi file trang, kể cả xoá sạch khi
xuất xong) `ScanSessionManager` tự ghi luôn 1 file JSON nhỏ (`session_state.json`, dùng
`org.json.JSONArray`/`JSONObject` có sẵn trong Android, không thêm thư viện) liệt kê id + đường dẫn
từng trang, vào **bộ nhớ trong thật (`context.filesDir`), không phải cache** — quan trọng vì thư mục
cache có thể bị hệ điều hành tự xoá bất cứ lúc nào để giải phóng dung lượng, ghi backup vào đó thì
coi như không backup. Vì lý do này, `FileUtils.sessionPagesDir()` cũng đổi từ `cacheDir` sang
`filesDir` — CHỈ đổi đúng thư mục này (nơi lưu ảnh trang đã xử lý xong của phiên quét); các thư mục
tạm khác (`capturesDir`, `importedDir` — ảnh thô/ảnh nhập chưa qua xử lý) vẫn ở `cacheDir` như cũ vì
đó chỉ là bước trung gian, dùng xong trong cùng 1 lượt thao tác là xoá, không cần bền.

Khi mở `MainActivity` (`onResume`), nếu bộ nhớ hiện tại KHÔNG có phiên nào đang hoạt động (`pages`
rỗng — nghĩa là process này chưa/không tự có sẵn dữ liệu) NHƯNG có phiên đã lưu trên đĩa còn sót lại
→ hiện hộp thoại hỏi "Phát hiện phiên quét dang dở (N trang) — Tiếp tục hay Xoá?". Chọn Tiếp tục sẽ
nạp lại đúng danh sách đó vào bộ nhớ rồi vào thẳng `PageListActivity`; chọn Xoá sẽ xoá cả file JSON
lẫn các ảnh trang nó trỏ tới. Vì mọi nơi bắt đầu phiên MỚI (chụp/nhập ảnh từ "Quét tài liệu",...) đều
gọi `ScanSessionManager.clear()` trước, và `clear()` cũng tự xoá luôn backup trên đĩa, nên không có
tình trạng hộp thoại này hiện ra sai lúc (chỉ hiện đúng khi thật sự có phiên dang dở bị bỏ lại).

**Giới hạn đã biết** (chưa làm, cân nhắc nếu cần):
- Chỉ áp dụng cho phiên quét (`ScanSessionManager`) đúng như câu hỏi — CHƯA áp dụng cho các luồng
  nhiều bước khác cũng có thể bị mất dở dang tương tự: danh sách file đang chờ ghép trong
  `PdfMergeActivity`, trạng thái đang chỉnh (xoay/chọn/sắp xếp) trong `PdfPageEditorActivity`, hay
  mục lục đang soạn trong `EbookExportActivity`. Nếu cần, làm thêm sau theo đúng khuôn mẫu này.
- Nếu app bị tắt đúng lúc đang ở giữa 1 lần crop (đã mở `CropActivity`, đang kéo 4 góc / chưa bấm
  "Xác nhận") thì đúng trang ĐANG crop dở đó vẫn mất — chỉ những trang đã bấm "Lưu trang" xong mới
  được backup. Chấp nhận được vì chỉ mất tối đa 1 trang thay vì mất cả phiên.
- Chưa test trên thiết bị thật kịch bản "hệ thống tự kill app giữa chừng" (khó giả lập chính xác
  khi không có máy) — logic đọc/ghi JSON thì đơn giản, rủi ro thấp hơn nhiều so với mục 4.11/4.12.

### 4.14 Tự lưu & khôi phục cho 3 luồng còn lại — `PdfEditorState` / `EbookEditorState` / `PdfMergeState`

Mở rộng đúng ý còn tồn đọng đã ghi ở mục 6 bản trước: mục 4.13 khi đó chỉ áp dụng cho phiên quét.
Giờ áp dụng thêm cho `PdfPageEditorActivity`, `EbookExportActivity`, `PdfMergeActivity`, theo đúng
khuôn mẫu JSON-trên-`filesDir` của `ScanSessionManager` (persist mỗi lần state đổi, hỏi khôi phục
khi mở lại màn hình nếu phát hiện có phiên dở). Khác biệt so với bản gốc:

- **Không dùng chung 1 manager** — mỗi màn hình có object riêng (`PdfEditorState`,
  `EbookEditorState`, `PdfMergeState`), vì dữ liệu cần lưu khác hẳn nhau (trang+xoay+chọn / trang+
  đánh dấu chương+tên sách+định dạng / danh sách Uri). Hỏi khôi phục được đặt ngay trong `onCreate`
  của từng Activity đó (không dồn cả 3 hộp thoại vào `MainActivity` như bản gốc làm với phiên quét —
  tránh phải xếp thứ tự ưu tiên khi nhiều phiên dở cùng lúc).
- **Trang render từ PDF nhập vào phải đổi từ cache sang `filesDir` mới backup được** — `PdfImportHelper.
  renderAllPagesToFiles()` trước đây luôn ghi vào `FileUtils.importedDir()` (cache, có thể bị hệ
  thống xoá bất cứ lúc nào — xem mục 2), nên dù có lưu state JSON, đường dẫn trỏ tới cũng có thể đã
  mất. Đã thêm tham số `fileFactory: ((Int) -> File)?` (mặc định `null` → giữ nguyên hành vi cũ cho
  mọi nơi gọi khác — `MainActivity` 3 chỗ, `ConvertDocumentActivity`) để 2 nơi cần bền
  (`PdfPageEditorActivity`, `EbookExportActivity`) tự trỏ sang thư mục riêng của mình dưới `filesDir`
  (`FileUtils.pdfEditorPagesDir()` / `ebookImportDir()`).
- **`EbookEditorState` cố tình KHÔNG lưu văn bản OCR** — chỉ lưu đường dẫn trang + đánh dấu chương +
  tên chương + tên sách + 2 checkbox định dạng. Lý do: OCR lại rẻ (vài chục trang, chạy offline —
  đúng như ghi chú gốc trong `EbookExportActivity`), trong khi văn bản OCR có thể khá dài; lưu lại
  vào JSON chỉ tốn dung lượng không cần thiết. Khi khôi phục: chạy lại OCR trên đúng các trang cũ,
  rồi khớp theo đường dẫn để áp lại đánh dấu chương đã lưu (`applySavedMarksIfMatching()`) — nếu
  đường dẫn không khớp (nguồn trang đã đổi), state cũ bị bỏ qua chứ không báo lỗi, và sẽ tự bị ghi
  đè bởi lần persist tiếp theo của phiên mới.
- **Lưu 1 "mốc" ngay khi vừa có `pagePaths`, trước khi vòng lặp OCR chạy** (`EbookExportActivity.
  runOcrAndShowEditor()`) — vì OCR nhiều trang có thể mất một lúc; không có bước này thì app bị tắt
  đúng lúc đang OCR sẽ không có gì để khôi phục dù các trang nguồn đã nằm sẵn trong thư mục bền.
- **`EbookEditorState.clear()` chỉ xoá file nó THỰC SỰ sở hữu** (so khớp thư mục cha với
  `ebookImportDir()`) — không đụng vào trang thuộc `ScanSessionManager` (khi ebook được soạn từ
  phiên quét đang có, không phải từ PDF nhập riêng). Xoá nhầm sẽ làm hỏng phiên quét đang hoạt động
  của 1 manager khác — xem quyết định 20, mục 5.
- **Dọn cache định kỳ** — `FileUtils.cleanOldCacheFiles()`, gọi 1 lần mỗi khi app khởi động (trên
  thread riêng trong `DocScannerApp.onCreate`, không chặn startup), xoá file cũ hơn 24h trong 3 thư
  mục cache tạm (`captures/`, `imported/`, `temp/`) — đúng việc còn tồn đọng đã ghi ở mục 6 bản
  trước ("File tạm trong cache không bao giờ tự dọn"). **Cố tình KHÔNG đụng tới** `session_pages/`,
  `pdf_editor_pages/`, `ebook_import/` (đều nằm dưới `filesDir`, không phải cache) — dọn nhầm các
  thư mục này sẽ phá luôn tính năng backup/restore vừa thêm.
- **Sửa kèm 1 lỗi UX đã ghi ở mục 6 bản trước**: xoá dòng lịch sử EPUB giờ báo rõ nếu có file
  `.txt` cùng tên (cùng 1 cuốn ebook) sẽ bị xoá theo, thay vì xoá âm thầm — chỉ áp dụng cảnh báo cho
  đúng trường hợp này (EPUB có cặp .txt cùng tên), không đổi hành vi khi xoá PDF (file .txt OCR đi
  kèm PDF vẫn bị xoá âm thầm như cũ vì nó không hiện thành dòng riêng trong lịch sử, không có gì
  "biến mất bất ngờ" trước mắt người dùng).

**Giới hạn đã biết (chưa xử lý, mức rủi ro thấp — chấp nhận được)**:
- `PdfPageEditorActivity`: nếu app bị tắt đúng lúc đang render trang từ PDF vừa chọn (trước khi
  `pages.addAll(...)` + lần persist đầu tiên chạy xong), các file đã render dở nằm trong
  `pdf_editor_pages/` sẽ mồ côi (không bị dọn vì không phải cache, nhưng cũng không có state JSON
  nào trỏ tới để khôi phục) — chỉ mất tối đa 1 lượt chọn file, không mất gì đã lưu trước đó.
- `EbookExportActivity`: mốc lưu sớm (nêu trên) thu hẹp rất nhiều nhưng không xoá hết cửa sổ rủi ro
  — nếu app bị tắt đúng giữa lúc ghi xong mốc đó nhưng trước khi ghi xong lần đầu, về lý thuyết vẫn
  có thể lệch; xác suất cực thấp, chưa test thật (cùng nhóm rủi ro "chưa build-test" ở mục 0/9).
- `PdfMergeState`: chỉ lưu Uri, không lưu file cục bộ nào — không có nguy cơ mồ côi file.

### 4.15 Luồng "Dự án" (Project) — quy trình tuyến tính bắt buộc 8 bước

Tính năng LỚN NHẤT trong dự án tính đến giờ (xem mục 0, mục 1 ý 12). Trước đây app chỉ có các
**công cụ độc lập** (Quét, Ghép PDF, Quản lý trang, Nén PDF, Tạo Ebook, Chuyển đổi định dạng) —
không công cụ nào nối với công cụ nào, người dùng tự làm xong 1 việc rồi tự vào công cụ khác chọn
lại file. Mục này thêm một lớp mới bên trên: **"Dự án"** — 1 thực thể duy nhất đi xuyên suốt cả 8
bước, KHÔNG được bỏ bước nào, nhưng KHÔNG xoá bất kỳ công cụ độc lập nào đã có (chúng vẫn nguyên
100%, giờ nằm dưới tiêu đề "Hoặc dùng riêng từng công cụ" trong `MainActivity`).

**Bấm vào đâu**: thẻ "Dự án quét sách" — giờ là thẻ ĐẦU TIÊN, kiểu highlight (nền xanh) mà trước đây
thuộc về thẻ "Quét" (thẻ "Quét" bị hạ xuống thành thẻ thường, xem quyết định 26 ở mục 5).

**8 bước, đúng thứ tự người dùng mô tả, không thể nhảy cóc** (mỗi `Project.stage` chỉ tiến, không
lùi; `ProjectFlow.open()` luôn mở đúng Activity khớp với `stage` hiện tại — dùng chung cho cả "mở
tiếp dự án dở" lẫn "vừa xong 1 bước, sang bước kế"):

1. **Tạo dự án** — không phải 1 màn hình riêng, chỉ là bấm "+ Dự án mới" ở `ProjectHubActivity` →
   `ProjectManager.createProject()` sinh `id` theo timestamp + tên mặc định "Dự án dd/MM HH:mm" →
   lưu JSON rỗng → mở luôn `ProjectPickImagesActivity`.
2. **Chọn ảnh** (`ProjectPickImagesActivity`) — ĐÚNG 2 lựa chọn như mô tả (camera hoặc thư viện,
   không có lựa chọn thứ 3 "nhập từ PDF" như công cụ Quét độc lập, vì 1 dự án được hiểu là bắt đầu
   từ ảnh chụp sách thật). Thư viện dùng `PickMultipleVisualMedia(20)` (đa chọn thật, tối đa
   20 ảnh/lần, giống hệt cơ chế đã có ở `MainActivity`). Camera: xem ý dưới.
3. **Chỉnh sửa ảnh** (`ProjectEditActivity`) — crop (tự phát hiện 4 góc) + tách trang đôi (tự gợi ý
   vị trí gáy sách), dùng LẠI NGUYÊN `CropOverlayView`/`SplitLineOverlayView` và các heuristic
   `detectDocumentCorners`/`detectGutterX` đã có — nhưng KHÔNG có bước chọn bộ lọc như
   `CropActivity` gốc, vì lọc ảnh giờ là 1 bước riêng, bắt buộc, ngay sau đây.
4. **Chọn kiểu quét** (`ProjectScanActivity`) — MỚI, chưa từng có dưới dạng 1 bước độc lập trước
   đây. Dùng lại đúng 7 preset đã có ở "Lọc hàng loạt" của `PageListActivity` (đã tách ra
   `ScanPresetApplier`, quyết định 23), NHƯNG bước này BẮT BUỘC: nút "Tiếp tục" chỉ bật sau khi
   người dùng đã chọn và áp dụng xong 1 preset (mặc định gợi ý "Tự động" giống công cụ gốc).
5. **Xuất PDF, có mục lục** (`ProjectExportPdfActivity`) — MỤC LỤC LÀ TÍNH NĂNG MỚI HOÀN TOÀN, xem
   phần riêng "TocDetector" bên dưới. Việc TẠO mục lục là tuỳ chọn (bật/tắt bằng 1 công tắc, đúng ý
   "có lựa chọn tạo mục lục" trong yêu cầu gốc) nhưng bước XUẤT PDF thì bắt buộc.
6. **Nén PDF** (`ProjectCompressActivity`) — dùng lại `PdfCompressor` đã có, nhưng KHÁC công cụ độc
   lập ở chỗ: công cụ độc lập phải render lại ảnh từ 1 PDF có sẵn (không có ảnh gốc), còn ở đây dự
   án vẫn giữ nguyên ảnh gốc trong `pages` nên nén thẳng từ đó, không phải render lại. Nếu bước 5 có
   mục lục, mục lục đó được GHI LẠI vào bản nén (xem quyết định 21 — nén tạo file hoàn toàn mới nên
   không thể "giữ" mục lục cũ, phải ghi lại).
7. **OCR** (`ProjectOcrActivity`) — bắt buộc, không có gì để người dùng chọn (OCR không có preset),
   tự chạy ngay khi vào màn hình, ra `.txt` đúng định dạng `--- Trang N ---` như công cụ Xuất PDF
   độc lập đã dùng (để nhất quán).
8. **Tạo ebook** (`ProjectEbookActivity`, bước cuối) — dùng lại NGUYÊN layout
   `activity_ebook_editor.xml`/`ActivityEbookEditorBinding` và `EbookPageAdapter` của công cụ độc
   lập `EbookExportActivity` (2 Activity khác nhau, CÙNG 1 file layout — ViewBinding không buộc
   1-layout-1-Activity, xem quyết định 24). Khác biệt duy nhất: đánh dấu chương được ĐIỀN SẴN từ
   mục lục đã duyệt ở bước 5 (khớp theo chỉ số trang), người dùng chỉ cần soát lại thay vì đánh dấu
   từ đầu — tận dụng lại đúng công sức người dùng đã bỏ ra, không bắt làm 2 lần.

Sau bước 8, `stage` chuyển `DONE`, `ProjectFlow` mở `ProjectSummaryActivity` — liệt kê MỌI file
thành phẩm đã ra trong suốt 8 bước (PDF gốc, PDF đã nén, `.txt` OCR, EPUB/TXT ebook), mỗi file có
thể mở/chia sẻ/xoá độc lập — đúng ý "cũng có file thành phẩm ngay chỗ thoát ra nếu người dùng chỉ
muốn dùng file ở bước đó thôi": người dùng có thể dừng lại ở bất kỳ bước nào và vẫn dùng được file
của (các) bước đã xong, không bắt buộc phải đi hết cả 8 bước mới có thứ gì đó dùng được.

**Chế độ "dự án" trong `CaptureActivity`**: thay vì viết 1 màn hình camera mới (trùng lặp toàn bộ
CameraX/preview/flash đã có), `CaptureActivity` được thêm 1 nhánh rẽ theo `ProjectFlow.EXTRA_
PROJECT_ID` có mặt trong Intent hay không — có thì mỗi tấm chụp được lưu thẳng vào
`Project.pendingRawPaths` (không qua `CropActivity`, vì crop là bước 3 riêng), không có thì giữ
NGUYÊN luồng cũ (chụp → `CropActivity` ngay → lặp lại). Hành vi cũ (không có project id) không đổi
1 dòng nào.

**Lưu trạng thái ở mức nào**: mỗi `Project` là 1 file JSON (`filesDir/projects/<id>/project.json`,
`ProjectManager`), lưu lại sau MỌI thay đổi có ý nghĩa (chọn xong ảnh, crop xong 1 trang, áp preset
xong, xuất PDF xong...) — không đợi xong cả bước mới lưu 1 lần, để khớp đúng yêu cầu "thoát bất kỳ
lúc nào cũng lưu, mở lại đúng chỗ": ví dụ đang crop dở trang 5/12, tắt app, mở lại dự án sẽ vào
thẳng `ProjectEditActivity` và tiếp tục đúng trang 5 (12-5=7 trang còn lại vẫn nằm nguyên trong
`pendingRawPaths` vì phần tử đầu chỉ bị `removeAt(0)` NGAY LÚC bắt đầu tải nó, không phải lúc xác
nhận xong — xem comment trong chính `ProjectEditActivity.loadNext()`).

**`TocDetector` — dò mục lục tự động (tính năng hoàn toàn mới, CHƯA từng có ở đâu khác trong app)**:
- Cách làm: OCR (phẳng, `OcrHelper.recognize`) tối đa 20 trang đầu (mục lục sách gần như luôn nằm ở
  đầu sách), tìm trang có nhiều dòng khớp mẫu `"<tên chương> <dấu chấm/khoảng trắng> <số trang>"`
  (regex `^(.{2,80}?)[\s.]{2,}(\d{1,4})\s*$` theo từng dòng) HOẶC có từ khoá "MỤC LỤC"/"CONTENTS",
  lấy trang khớp nhiều dòng nhất.
- **GIỚI HẠN QUAN TRỌNG, đọc kỹ trước khi coi đây là tính năng "chính xác"**: số trang lấy được từ
  mục lục là số trang IN TRÊN SÁCH, hầu như KHÔNG BAO GIỜ trùng với chỉ số trang quét thực tế (sách
  luôn có bìa/trang tên sách/trang bản quyền ở đầu, làm lệch số). `TocDetector` KHÔNG cố đoán độ
  lệch này (không OCR số trang in trên từng ảnh để đối chiếu — cân nhắc rồi bỏ, xem mục 8) — chỉ
  đơn giản CHIA ĐỀU các mục đã dò được ra khắp các trang còn lại làm điểm khởi đầu. Đây là lý do
  `ProjectExportPdfActivity` LUÔN bắt người dùng duyệt/sửa lại (`TocEntryAdapter`, có nút +/- chỉnh
  từng trang) trước khi xuất — phần thật sự đáng tự động hoá là TÊN chương (gõ tay rất mất công),
  không phải vị trí trang (chỉnh vài lần bấm là xong). Không được coi nhẹ bước duyệt này khi test.
- Chỉ hoạt động tốt với mục lục có "leader" (chấm/khoảng trắng) rõ ràng trước số trang — mục lục
  trình bày khác kiểu (ví dụ số trang ở đầu dòng, hoặc dùng bảng thật) nhiều khả năng không khớp
  được regex, khi đó trả về danh sách rỗng và màn hình hiện nút "Thêm mục" để tự thêm tay.

**Đã tái cấu trúc nhẹ 1 vài chỗ code CŨ để dùng chung với luồng Dự án** (không đổi hành vi của công
cụ độc lập tương ứng — xem quyết định 23, 25 ở mục 5 để biết lý do từng chỗ):
- `PageListActivity`: enum `BulkPreset` riêng + 2 hàm `einkTextResult`/`einkColorResult` riêng được
  chuyển thành `ScanPresetApplier` (dùng chung với `ProjectScanActivity`). Hành vi/chuỗi hiển thị
  giữ nguyên 100%.
- `PdfImportHelper.renderAllPagesToFiles()`: thêm tham số `fileFactory` (mục 4.14, dùng lại được
  cho luồng Dự án nếu sau này cần nhập PDF vào 1 dự án — hiện tại Dự án chỉ nhận ảnh, không dùng
  đường này).
- `PdfExporter.exportImagePaths()`: thêm 2 tham số tuỳ chọn `chapterTitles`/`chapterStartPageIndex`
  (mặc định rỗng → hành vi cũ không đổi) để gắn bookmark thật qua `PdfBookmarkInjector`.
- `PdfCompressor.compress()`: thêm 2 tham số tương tự, nhưng KHÔNG dùng `PdfBookmarkInjector` (viết
  thẳng object Outline cùng lúc với các trang, xem quyết định 21).
- `FileUtils`: thêm nhóm hàm thư mục cho Project (`projectsRootDir`/`projectDir`/`projectRawDir`/
  `projectPagesDir`/...), và `openFile`/`shareFile` dùng chung (tách từ logic đã có sẵn trong
  `MainActivity`, KHÔNG sửa `MainActivity.shareFile` gốc — xem quyết định 25).

**Giới hạn đã biết của riêng luồng Dự án (chưa xử lý, mức độ chấp nhận được — không chặn dùng
được, chỉ là chưa hoàn hảo)**:
- [x] ~~`ProjectEbookActivity` (bước 8) KHÔNG có backup/restore ở mức "đang gõ dở" như
  `EbookEditorState` làm cho công cụ độc lập — nếu app bị tắt đúng lúc đang soát lại tên chương ở
  bước này (sau khi OCR xong), mở lại dự án sẽ OCR lại từ đầu VÀ áp lại đúng mục lục gốc từ bước 5
  (không mất mục lục, chỉ mất các chỉnh sửa THỦ CÔNG thêm vào lúc soát ở bước 8 nếu có). Chấp nhận
  được vì đây là bước cuối, thời gian ở lại bước này thường ngắn.~~ — **đã làm ở phiên thứ 4**: file
  mới `model/ProjectEbookEditorState.kt`, đúng khuôn mẫu `EbookEditorState` nhưng lưu riêng theo
  từng dự án (trong `FileUtils.projectDir(id)`, không phải 1 slot chung) vì nhiều dự án có thể đang
  dang dở bước này ở nhiều thời điểm. `runOcrAndShowEditor()` giờ lưu 1 điểm khôi phục CƠ SỞ (marks
  suy từ mục lục bước 5) ngay trước khi vòng lặp OCR bắt đầu — cùng lý do phòng thủ như
  `EbookExportActivity` bản gốc (OCR nhiều trang có thể mất thời gian) — rồi sau khi OCR xong, áp
  lại trạng thái đã lưu (nếu khớp đúng danh sách trang) đè lên marks suy từ mục lục, và lưu lại mỗi
  khi người dùng sửa tay (qua `onChanged` của `EbookPageAdapter`, `TextWatcher` của ô tên sách, và
  2 checkbox định dạng — same wiring như bản gốc). Dọn file trạng thái này sau khi xuất ebook thành
  công (`ProjectEbookEditorState.clear()`), không cần dọn riêng khi xoá cả dự án vì file này nằm
  trong đúng thư mục dự án, `ProjectManager.delete()` đã xoá đệ quy cả thư mục rồi. KHÔNG hiện hộp
  thoại "khôi phục hay làm lại" như công cụ độc lập vì trang nguồn 1 Dự án luôn cố định
  (`Project.pages`) — có trạng thái khớp là áp dụng luôn, không có gì mơ hồ cần hỏi. Xem mục 0/3/6/9.
  Vẫn **chưa test thật** (cùng hạn chế môi trường).
- Toàn bộ 9 màn hình MỚI chưa được xem qua giao diện thật (đang ở môi trường không có Android
  SDK/máy ảo) — rủi ro lệch layout (chồng chéo, tràn chữ, nút bị che) cao hơn các phần cũ đã tồn tại
  lâu, dù đã rà soát tĩnh kỹ (mục 9).
- `TocDetector` chưa test với ảnh mục lục thật nào — hoàn toàn dựa trên suy luận về cấu trúc OCR
  text, có thể cần chỉnh regex sau khi thấy vài ví dụ thật.

### 4.16. "Chú thích PDF" - vẽ tay/chữ/che lên trang (phiên làm việc thứ 7)

Tính năng "chỉnh sửa trực tiếp nội dung PDF" — người dùng được hỏi rõ trước khi làm (xem mục 0) vì
cụm này có thể hiểu theo 2 hướng rất khác nhau: (a) đánh dấu/chú thích lên trang (không đổi nội
dung gốc), hoặc (b) sửa lại đúng câu chữ đã có sẵn trong PDF như Word (đổi thẳng nội dung gốc, khó
và rủi ro hơn nhiều). Người dùng chọn làm CẢ HAI nhưng ưu tiên (a) trước — phiên này chỉ làm (a).
Phần (b) xem mục 6 để biết vì sao chưa làm và cần bàn gì trước khi bắt đầu.

**`AnnotationCanvasView` (custom View, `view/`)** — hiển thị 1 bitmap trang + vẽ đè lên trên 3 loại
"phần tử": nét vẽ tay (`Stroke`), chữ đặt tự do (`TextStamp`), hình chữ nhật che đặc (`Redact`,
mặc định trắng). Điểm quan trọng nhất về mặt kỹ thuật: MỌI phần tử được lưu ở toạ độ KHÔNG GIAN
BITMAP GỐC (không phải toạ độ màn hình) ngay từ lúc chạm tay vào màn hình — quy đổi qua lại bằng 1
cặp `Matrix` (thuận: bitmap→view để hiển thị preview đúng tỉ lệ fit-center; nghịch: view→bitmap để
đổi điểm chạm) — cùng đúng kỹ thuật `CropOverlayView`/`SplitLineOverlayView` đã dùng trước đó cho
việc kéo góc crop/kéo đường tách trang. Nhờ vậy, `onDraw()` (xem trước trên màn hình, độ phân giải
thấp) và `flatten()` (làm phẳng ra file thật, độ phân giải gốc đầy đủ, có thể cao hơn màn hình rất
nhiều lần) dùng chung ĐÚNG 1 đoạn code vẽ phần tử, không có 2 đường tính toán riêng dễ lệch nhau —
những gì thấy trên màn hình chính là những gì ra file, không phải một bản xấp xỉ của nó. Độ dày nét
vẽ/cỡ chữ cũng định nghĩa theo tỉ lệ % chiều rộng bitmap (không phải số px cố định) nên tự động phù
hợp dù trang có độ phân giải bao nhiêu.

**"Làm phẳng" (flatten), không phải object chú thích PDF thật**: kết quả cuối là bitmap trang GỐC +
mọi phần tử được "nướng" (bake) trực tiếp vào từng pixel, ghi đè thành ảnh JPEG mới — KHÔNG phải
tạo ra các object `/Annots` (Text/Ink/Square...) thật sự trong cấu trúc PDF mà 1 trình đọc PDF có
thể ẩn/hiện/xoá lại độc lập với nội dung trang. Đây là lựa chọn CHỦ ĐÍCH, khớp đúng kiến trúc "mọi
PDF trong app này đều là ảnh" đã dùng xuyên suốt từ `PdfExporter`/`PdfCompressor` tới giờ — không
phải giới hạn kỹ thuật tình cờ.

**`PdfAnnotateActivity`** — 1 màn hình, 2 chế độ chọn qua Intent extra, dùng chung toàn bộ UI/logic:
- **Chế độ PDF ngoài** (không có extra nào, hoặc mở từ thẻ công cụ "Chú thích PDF" ở màn hình
  chính): tự bật picker chọn file PDF ngay khi `onCreate`, render mọi trang qua `PdfImportHelper`
  (dùng lại nguyên hàm đã có, không viết lại) ở 200dpi vào thư mục làm việc RIÊNG
  `FileUtils.annotatePagesDir` (mới thêm, tách khỏi `pdfEditorPagesDir` đã có vì là tool khác nhau).
  Lúc Lưu, ghi PDF mới bằng `PdfExporter.exportImagePaths()` — hàm NÀY ĐÃ CÓ SẴN TỪ TRƯỚC (dùng cho
  `PdfPageEditorActivity`), không cần viết thêm gì để xuất PDF từ danh sách ảnh.
- **Chế độ 1 trang trong phiên quét** (mở từ nút mới trên từng trang ở `PageListActivity`, qua
  Intent extra `EXTRA_IMAGE_PATH` + `EXTRA_SESSION_PAGE_INDEX`): chú thích đúng 1 ảnh, Lưu xong gọi
  `ScanSessionManager.replaceFile(index, path)` — CÙNG CÁCH `CropActivity` vẫn dùng để trả trang đã
  cắt/lọc lại cho phiên quét, không phát minh đường mới.
- **"Làm phẳng theo từng trang khi rời trang"**: với PDF nhiều trang, mỗi khi chuyển trang (Trước/
  Sau) hoặc bấm Lưu, trang ĐANG XEM được làm phẳng và ghi đè ngay vào đúng file của nó trên đĩa —
  không giữ toàn bộ lịch sử chỉnh sửa của MỌI trang trong RAM cùng lúc. Đánh đổi: rời khỏi 1 trang
  rồi thì không hoàn tác được nét vẽ đã thêm vào trang đó nữa (chỉ hoàn tác được trang ĐANG xem) —
  chấp nhận được, tránh được việc giữ trạng thái phức tạp nhiều trang cùng lúc.

**2 lỗi tự tìm ra bằng cách đọc lại tay** (không có công cụ nào trong mục 9 bắt được, vì cả 2 đều là
lỗi về hành vi lúc chạy — rò bộ nhớ và rác file — không phải lỗi cú pháp/tham chiếu tĩnh):
1. `AnnotationCanvasView.loadPage()` không giải phóng bitmap trang CŨ trước khi nhận bitmap MỚI —
   với 1 PDF nhiều chục trang, chuyển hết trang này sang trang khác sẽ giữ TẤT CẢ bitmap cũ trong bộ
   nhớ (không ai còn tham chiếu tới nhưng chưa được `recycle()` chủ động, chỉ chờ GC dọn tình cờ) —
   rủi ro hết bộ nhớ thật với phiên chú thích dài. Đã sửa.
2. Thư mục làm việc `annotatePagesDir` (chế độ PDF ngoài) không được dọn khi người dùng huỷ (thoát
   không lưu) hoặc xuất xong — file JPEG trung gian tích luỹ dần qua nhiều lần mở tool, không bao
   giờ tự mất. Đã sửa: dọn sạch thư mục này ở cả 2 thời điểm (xuất xong, xác nhận huỷ).

**Giới hạn đã biết, nói thẳng không né**:
- **Chưa có backup/restore qua chết tiến trình** — khác với `PdfPageEditorActivity`/
  `EbookExportActivity`/`ProjectEbookActivity` (đều theo khuôn mẫu `model.*State`, lưu JSON, tự
  khôi phục khi mở lại), tool này chỉ có 1 hộp thoại xác nhận "Bỏ các chú thích chưa lưu ở trang này
  và thoát?" khi bấm Back mà đang có gì chưa lưu — nếu app bị hệ điều hành giết ngầm (không phải
  người dùng tự thoát) giữa lúc chú thích dở PDF nhiều trang, mất hết các trang CHƯA làm phẳng (các
  trang ĐÃ làm phẳng, tức đã rời qua, vẫn còn nguyên trên đĩa vì được ghi ngay lúc rời trang — chỉ
  mất trang hiện đang xem). Cố tình chấp nhận cho bản đầu tiên (đã ghi thẳng ở đây, không giấu) vì
  đây không phải quy trình nhiều bước phức tạp như soạn ebook — làm lại vài nét vẽ ít tốn công hơn
  nhiều so với làm lại OCR/mục lục. Nếu cần làm đúng chuẩn, theo ĐÚNG khuôn mẫu `PdfEditorState`/
  `EbookEditorState` đã có sẵn, không cần phát minh cách mới.
- **Chưa test trên máy thật lần nào** (như mọi phần khác của dự án — mục 0/9) — nhưng RỦI RO Ở ĐÂY
  CAO HƠN các tool thuần logic khác: đây là tool DUY NHẤT có custom View xử lý cảm ứng + Matrix quy
  đổi toạ độ MỚI viết (không phải chỉnh sửa `CropOverlayView` có sẵn), nên khả năng "đúng trên giấy
  nhưng lệch/vỡ nét khi chạm tay thật" cao hơn hẳn — ưu tiên test tay kỹ tool này trước các phần
  khác nếu build được (mục 10).
- Cỡ nét vẽ/màu chỉ có 3 mức cố định (nhỏ/vừa/lớn) và 4 màu cố định (đen/đỏ/xanh dương/vàng dạ
  quang) — không có bánh xe chọn màu tự do hay điều chỉnh cỡ liên tục. Chấp nhận được cho bản đầu.
- Chữ chèn vào chỉ 1 dòng đơn giản (`Canvas.drawText`, không tự xuống dòng nếu dài) — gõ đoạn dài sẽ
  tràn ra ngoài lề thay vì tự ngắt dòng. Chưa xử lý.
- Không có công cụ tẩy RIÊNG (eraser) — muốn xoá 1 nét vẽ chỉ có cách Hoàn tác (undo) lần lượt từ
  nét mới nhất, không xoá được 1 nét cụ thể ở giữa nếu đã vẽ thêm nét khác sau đó.

### 4.17. "Sửa chữ PDF" - tìm/thay object chữ thật, không rasterize (phiên làm việc thứ 8)

**ĐỌC MỤC NÀY TRƯỚC KHI SỬA `PdfCanvasEditor.kt`/`PdfTextEditor.kt`.** Đây là tính năng khác biệt
nhất và rủi ro cao nhất trong toàn bộ dự án — mọi tool PDF khác (kể cả `PdfObjectRecompressor`) đều
theo kiến trúc raster (trang luôn là ảnh); đây là tool DUY NHẤT ghi trực tiếp vào object CHỮ THẬT
của 1 PDF có sẵn. Xem mục 0 (phiên thứ 8) để biết quá trình quyết định phạm vi trước khi làm — người
dùng đã được hỏi rõ và chọn "thử làm đúng nghĩa" thay vì hướng an toàn hơn.

**Cơ chế đọc — `PdfTextEditor.extractChunks()` (viết lại hoàn toàn ở phiên thứ 10)**: bản đầu dùng
`PdfCanvasProcessor` + lắng nghe sự kiện `TextRenderInfo` của iText (1 sự kiện MỖI CHUỖI — kể cả từng
phần tử chuỗi trong mảng `TJ`); phiên thứ 10 bỏ hẳn cách này. Giờ ĐỌC dùng CHÍNH `PdfCanvasEditor`
(cùng lớp mà bước GHI dùng — xem bên dưới), qua `walkTextOperators()`: 1 hàm duyệt CHỈ ĐỌC (gọi
`editContent()` — không phải `editPage()`, vì `editPage()` gán lại `/Contents` của trang dù mọi
operator được ghi lại y nguyên, không nên xảy ra chỉ để ĐỌC) với 1 `PdfCanvas` bỏ đi làm đích ghi giả.
Mỗi operator hiện chữ (`Tj`/`'`/`"`/`TJ`) là **đúng 1 `TextChunk`** — với `TJ`, nối chữ của MỌI phần
tử chuỗi trong mảng (`decodeOperatorText()`, bỏ qua các số kerning) thành 1 chuỗi duy nhất, dù mảng có
bao nhiêu mảnh. Việc nhóm này **KHÔNG phải heuristic đoán** — các mảnh chuỗi trong cùng 1 mảng `TJ`
là phần tử CỦA CÙNG 1 MẢNG, trong cùng 1 lệnh, đó là sự thật cấu trúc đọc thẳng từ PDF, không có gì mơ
hồ (khác với việc nhóm chữ GIỮA 2 operator khác nhau, cái đó mới cần đoán và vẫn không làm — xem "Giới
hạn đã biết"). Chữ giải mã qua `PdfFont.decode(PdfString)` (đã xác nhận có thật qua tra cứu). Mỗi
operator được đánh số (`TextChunk.index`) theo thứ tự xuất hiện, tính CẢ operator cho ra chữ trắng
(chỉ không đưa vào danh sách hiện cho người dùng) — số này quan trọng vì bước ghi tìm lại ĐÚNG operator
qua số này, không qua nội dung chữ (nội dung có thể trùng nhau ở nhiều chỗ trên trang). Độ rộng gốc
(`TextChunk.widthPt`) tính bằng `PdfFont.getWidth(text, size)` — xấp xỉ, KHÔNG tính chính xác khoảng
kerning giữa các mảnh của `TJ` nhiều mảnh — chấp nhận được vì kerning thường chỉ vài % tổng độ rộng,
và ngưỡng co giãn 40%-250% (bên dưới) đủ rộng để hấp thụ sai lệch nhỏ đó; nếu sai lệch đủ lớn để vượt
ngưỡng thì bị từ chối đúng như thiết kế, không ra kết quả sai âm thầm.

**Cơ chế ghi — `PdfCanvasEditor` + `PdfTextEditor.applyEdit()`**: `PdfCanvasEditor.kt` là bản port
Kotlin gần NGUYÊN VĂN 1 class thật, đã đọc trọn vẹn từ
`github.com/mkl-public/testarea-itext7/.../PdfCanvasEditor.java` (không suy đoán từ đoạn trích) —
tác giả `mkl` là người trả lời câu hỏi StackOverflow về content-stream iText nhiều nhất, dùng đúng
class này cho các ví dụ thật (xoá chữ theo tên font, đổi màu chữ, xoá dòng theo vị trí). Cách hoạt
động: bọc MỌI operator PDF (không riêng operator chữ) qua `registerContentOperator`, mặc định ghi
lại NGUYÊN VẸN qua chính bộ serialize object của iText (`PdfOutputStream.write(PdfObject)`) — nghĩa
là gần như toàn bộ nội dung file (đường vẽ, tô màu, ảnh, đổi trạng thái đồ hoạ...) KHÔNG BAO GIỜ bị
app này diễn giải lại, chỉ đúng phần operator bị `write()` override (chữ) mới có khả năng đổi. Đây
là lý do chọn cách này thay vì tự viết 1 trình tokenize/serialize content stream PDF từ đầu — phần
khó nhất (hiểu đúng MỌI loại operator PDF hợp lệ) vẫn hoàn toàn do iText lo.

`PdfTextEditor.applyEdit()` chỉ can thiệp khi gặp ĐÚNG operator ở ĐÚNG số thứ tự đã xác định lúc đọc.
**Vì ĐỌC và GHI giờ đều duyệt qua CÙNG 1 lớp `PdfCanvasEditor` (phiên thứ 10 — xem mục 0), chỉ còn
ĐÚNG 1 chỗ quyết định "cái gì tính là 1 operator, theo thứ tự nào" — không thể lệch bộ đếm giữa đọc và
ghi được nữa, kể cả với trang có Form XObject chứa chữ (`PdfCanvasEditor` vốn KHÔNG BAO GIỜ gọi thật
operator `Do` cho cả 2 đường, nên chữ trong Form XObject không bao giờ được đếm ở đâu cả). Đây là cách
sửa TẬN GỐC cả 1 loại lỗi (2 đường duyệt lệch nhau), thay cho cách vá riêng cho Form XObject của phiên
thứ 9 (`newProcessor()` + `IXObjectDoHandler` rỗng — ĐÃ BỊ XOÁ, không còn cần). Xem mục 0 (phiên thứ 9
và 10) để biết lịch sử đầy đủ của lỗi này.** Với operator `TJ` nhiều mảnh, **thay CẢ MẢNG bằng 1 mảng
mới chỉ có 1 chuỗi** (bỏ hết số kerning cũ — chúng được canh riêng cho đúng ký tự của chữ CŨ, không có ý
nghĩa gì với chữ mới khác; `[(chữ mới)] TJ` hợp lệ y hệt `(chữ mới) Tj`). Trước khi ghi, LUÔN kiểm tra 2
điều, **từ chối (không đổi gì) thay vì đoán** nếu không đạt:
1. **Mọi ký tự của chữ mới phải có sẵn trong đúng font đó** (`PdfFont.containsGlyph(Int)`) — font
   nhúng sẵn trong 1 PDF thật hầu hết bị "subset" (chỉ chứa đúng ký tự tài liệu gốc đã dùng), không
   có cách nào đáng tin để tự thêm 1 glyph mới vào font đã nhúng từ trong app này.
2. **Độ co giãn ngang cần dùng để chữ mới vừa đúng độ rộng chữ cũ phải nằm trong 40%-250%** — nếu
   ngoài khoảng này, từ chối thay vì tạo ra chữ bị nén/giãn tới mức không đọc được.

Cả 2 điều kiện này BIẾN NHỮNG GÌ KHÔNG KIỂM CHỨNG ĐƯỢC (font có đúng ký tự không, chữ có bị méo
không) thành nhị phân: hoặc chắc chắn an toàn theo đúng phép tính, hoặc từ chối rõ ràng — không có
trạng thái "chắc là ổn" ở giữa.

**Cơ chế co giãn cho vừa khung (`Tz` — horizontal scaling)**: thay vì thử làm reflow (không làm —
xem mục 6 để biết lý do phạm vi bị giới hạn ở đây), operator đã sửa được bọc trong 1 khối `q ... Tz
... Q` RIÊNG, độc lập — không cần dò/nhớ/khôi phục đúng giá trị `Tz` đang có trước đó ở vị trí này
(theo đúng chuẩn PDF ISO 32000, `q`/`Q` tự lưu/khôi phục TOÀN BỘ text state, `Tz` nằm trong đó), nên
phần TRƯỚC và SAU đoạn sửa không bao giờ bị ảnh hưởng, bất kể `Tz` gốc ở đó là gì. Vì tỉ lệ co giãn
được TÍNH CHÍNH XÁC sao cho độ rộng render ra khớp đúng độ rộng gốc (đo lúc đọc, không đo lại lúc
ghi — tránh trường hợp `Tz` gốc đã khác 100% làm sai tỉ lệ nếu đo lại bằng `PdfFont.getWidth()` đơn
thuần, vốn không tính `Tz`/CTM đang áp dụng), vị trí con trỏ chữ NGAY SAU khi hiện xong chữ mới cũng
khớp gần đúng vị trí gốc — đây là lý do chữ tiếp theo cùng dòng (nếu hiện bằng 1 lệnh Tj/TJ khác
không định vị lại) vẫn đứng đúng chỗ dù đoạn ngay trước nó vừa bị thay.

**`PdfTextEditActivity`**: chọn PDF ngoài → mở `PdfDocument(PdfReader, PdfWriter)` (stamping) → GIỮ
MỞ SUỐT CẢ PHIÊN làm việc (đúng cách `PdfObjectRecompressor` giữ mở xuyên suốt nhiều ảnh trước khi
đóng đúng 1 lần) → mỗi trang hiện danh sách đoạn chữ tìm được (RecyclerView, không phải danh sách cố
định vài mục như `CompressOptionsDialog` — 1 trang có thể có rất nhiều đoạn) → chạm 1 đoạn, sửa
trong hộp thoại, áp dụng ngay lên `PdfDocument` đang mở → Lưu đóng lại `PdfDocument` (iText tự hoàn
thiện toàn bộ file). Sau MỖI lần sửa thành công, danh sách đoạn chữ của trang đó được ĐỌC LẠI từ đầu
(không tự cập nhật list cũ) — vì nội dung/vị trí trang vừa đổi, an toàn hơn là tự suy luận list mới.

**1 lỗi thật tự tìm ra — nhờ ĐÚNG cách rà số tham số ở mục 9, không phải đọc tay lần này**: hàm nội
bộ `trySubstituteAndWrite` được gọi kèm 1 lambda cuối (`{ ... }`) ở cả 2 chỗ gọi (Tj và TJ), nhưng
khai báo hàm lại THIẾU hẳn tham số callback đó — lẽ ra sẽ không biên dịch được (`substitute()`
không tồn tại trong thân hàm). Cách rà "đếm số tham số truyền vào kể cả lambda cuối, so với số tham
số khai báo" bắt được NGAY (báo lệch 6 tham số truyền vs 5 khai báo) — không thuộc 2 loại báo động
giả đã biết (`finish`/`write`), nên được kiểm tra tay kỹ, xác nhận đúng là lỗi thật, và sửa (thêm
tham số `substitute: () -> Unit`). Đây là bằng chứng cụ thể cho việc mục 9 khuyên "chạy lại cách rà
này mỗi khi sửa xong 1 đợt code" — không phải hình thức.

**Mức độ tin cậy của các API iText đã dùng, nói thẳng để phiên sau biết chỗ nào chưa xác minh kỹ**:

| API | Đã tra cứu/đọc mã nguồn thật trong phiên này? |
|---|---|
| `PdfFont.containsGlyph(Int)`, `.convertToBytes(String)`, `.getWidth(String, Float)` | Có — tìm thấy trực tiếp qua tra cứu |
| `TextRenderInfo.getText()`, `.getBaseline()`, `.getFontSize()` | Có |
| Toàn bộ cơ chế `PdfCanvasEditor` (`registerContentOperator`, `write()`, `nextOperation()`) | Có — đọc trọn vẹn 2 file nguồn thật |
| `PdfCanvasProcessor.registerXObjectDoHandler`, `IXObjectDoHandler.handleXObject` (4 tham số) | Có — thêm ở phiên thứ 9, đọc cả mã nguồn thật `FormXObjectDoHandler` của chính iText lẫn javadoc bản 7.2.5 |
| `TextRenderInfo.getFont()` | Không — dựa hiểu biết chung, tin cậy cao nhưng chưa tra riêng |
| `PdfArray.get/set/size` | Không — dựa hiểu biết chung (quy ước đặt tên rất chuẩn cho kiểu list-like) |
| `PdfNumber(Double)` | Không — dựa hiểu biết chung |

Nếu build lỗi đúng vào 1 trong 3 dòng cuối, đây là chỗ đầu tiên nên nghi ngờ và tra cứu lại.

**Giới hạn đã biết, nói thẳng không né** (đầy đủ hơn trong chính doc comment của `PdfTextEditor.kt`):
- Không sửa được chữ nằm trong Form XObject/pattern/annotation lồng bên trong trang — **cập nhật phiên
  thứ 9 rồi 10**: từng bị mô tả nhầm là "chỉ thiếu tính năng"; thực ra khi ĐỌC và GHI dùng 2 cơ chế
  duyệt khác nhau (bản cũ), giới hạn này gây ra 1 LỖI THẬT (lệch bộ đếm giữa đọc/ghi khi trang có Form
  XObject chứa chữ — xem mục 0). Đã sửa TẬN GỐC ở phiên thứ 10 bằng cách cho cả ĐỌC lẫn GHI cùng đi
  qua 1 lớp duy nhất (`PdfCanvasEditor`, vốn không bao giờ gọi thật `Do`). Giới hạn "không sửa được
  chữ trong Form XObject" bản thân VẪN ĐÚNG — giờ là hành vi chủ đích, an toàn, nhất quán cho cả 2
  đường, không còn là nguồn lỗi.
- ~~Không hỗ trợ ghép match xuyên qua nhiều mảnh `TJ` liền kề~~ — **CHIA LÀM 2 TRƯỜNG HỢP KHÁC HẲN
  NHAU, cập nhật phiên thứ 10 sau khi người dùng chỉ ra lập luận sai của phiên thứ 9**:
  - **Nhiều mảnh chuỗi trong CÙNG 1 mảng `TJ`** (vd `[(Hel) -20 (lo)] TJ`): **ĐÃ LÀM, không còn là giới
    hạn** — đây là sự thật cấu trúc đọc thẳng từ PDF (các mảnh là phần tử của cùng 1 mảng trong cùng
    1 lệnh), không cần đoán gì cả. Giờ cả mảng là đúng 1 `TextChunk`. Phiên thứ 9 đã nhầm việc này
    với việc dưới đây và từ chối làm với lý do "cần heuristic" — lý do đó SAI cho trường hợp này.
  - **Chữ bị chia giữa 2 operator KHÁC NHAU** (vd 1 `Tj` cho "Hel", 1 `Tj` khác sau đó cho "lo", có thể
    có `Td` định vị lại ở giữa): **VẪN KHÔNG LÀM, lý do này mới ĐÚNG** — đây mới thật sự cần heuristic
    (xét vị trí/font gần nhau) để đoán 2 operator có phải 1 cụm chữ liền không, không phải sự thật
    cấu trúc; heuristic có thể tự đoán sai (gộp nhầm chữ không liên quan, hoặc tính sai độ rộng gộp)
    — đi ngược triết lý "từ chối thay vì đoán" của cả tính năng.
- ~~Chưa có backup/restore qua chết tiến trình~~ — **đã làm ở phiên thứ 9** (`model/PdfTextEditState.kt`
  + `FileUtils.textEditSourceDir`) — KHÁC khuôn mẫu thường dùng (`PdfEditorState`...) vì lý do kỹ
  thuật riêng của iText stamping mode, xem mục 0 (phiên thứ 9) để biết đầy đủ cơ chế "lưu bản gốc +
  danh sách các lần sửa, khôi phục bằng cách áp lại từ đầu" thay vì "mở file dở dang".
- **CHƯA TỪNG mở thử 1 file PDF thật nào qua tool này** — môi trường này không build được (mục 9).
  Đây là tính năng DUY NHẤT ghi trực tiếp vào object chữ của PDF có sẵn — lỗi ở đây nghĩa là PDF
  hỏng/chữ sai vị trí/lệch font, hậu quả nặng hơn hẳn 1 lỗi giao diện thông thường. Bắt buộc tự test
  bằng nhiều PDF thật đa dạng nguồn gốc (Word, LaTeX, PDF quét có lớp OCR...) trước khi tin dùng thật
  — xem mục 10.



## 5. Quyết định kỹ thuật quan trọng & lý do (đọc để không hỏi lại/làm lại)

1. **Không commit Gradle Wrapper** (`gradlew`, `gradle-wrapper.jar`). Lý do: môi trường viết code
   này không có mạng để tải file `.jar` nhị phân thật, không thể tự "gõ" ra 1 file jar hợp lệ. Giải
   pháp: workflow CI dùng action `gradle/actions/setup-gradle@v4` (input `gradle-version: 8.9`) để
   tự cài Gradle, chạy trực tiếp bằng lệnh `gradle` (không phải `./gradlew`). Đã tra cứu xác nhận
   action này hỗ trợ đúng kịch bản "project không có wrapper". Nếu sau này có mạng ổn định, có thể
   đổi lại sang wrapper thật (`gradle wrapper --gradle-version 8.9` chạy 1 lần rồi commit).
2. **Không dùng thư viện PDF thật (iText/PDFBox/...)** cho merge/split/rotate/page-manager. Lý do:
   giảm rủi ro sai tên artifact/API mà không ai kiểm tra được (không build được ngay lúc viết code)
   — chỉ dùng 2 API framework Android chắc chắn có sẵn (`PdfRenderer`, `PdfDocument`). Đánh đổi đã
   nêu ở mục 2. Nếu sau này người dùng cần giữ được chữ thật (không rasterize), cần đổi hướng này —
   `com.tom-roush:pdfbox-android` là ứng viên hay được dùng nhưng **CHƯA được tra cứu/xác minh** cho
   dự án này.
3. **OpenCV**: xác nhận qua tra cứu web (không đoán từ trí nhớ) rằng `org.opencv:opencv:5.0.0.1` là
   artifact chính thức trên Maven Central, khởi tạo bằng `OpenCVLoader.initLocal()` (API mới của
   nhánh 5.0, KHÔNG phải `initDebug()`/`initAsync()` của các hướng dẫn cũ trên mạng — dùng nhầm API
   cũ vẫn compile được nhưng dùng sai best-practice hiện tại). Chỉ dùng module `core`/`imgproc`/
   `android` (Utils) — các module `ml`, `objdetect` (Haar/HOG), `gapi`, `face` đã bị tách sang gói
   "Pro"/contrib riêng, KHÔNG có trong AAR miễn phí, nên code cố tình không đụng tới các API đó.
4. **ML Kit dùng bản bundled** (`com.google.mlkit:text-recognition`), không dùng bản
   `com.google.android.gms:play-services-mlkit-text-recognition` (bản unbundled cần tải model lần
   đầu qua Play Services, có thể lỗi nếu máy không có Play Services hoặc không có mạng lúc đó).
5. **Icon app**: dựng bằng script Python/PIL (chạy 1 lần lúc build project, KHÔNG có trong repo),
   xuất thẳng ra PNG ở cả 5 mật độ màn hình, KHÔNG dùng adaptive-icon XML — vì `minSdk=24` vẫn cần
   icon PNG thường cho API 24-25 (adaptive icon chỉ từ API 26), nên dùng PNG thường cho mọi API luôn
   cho đơn giản, chấp nhận mất hiệu ứng "adaptive shape" trên máy mới (thuần thẩm mỹ, không phải lỗi
   chức năng).
6. **Tránh mọi style resource Material3 không chắc chắn tồn tại** (vd.
   `Widget.Material3.Chip.Filter`, `Widget.Material3.Button.OutlinedButton/TonalButton`) — vì
   tham chiếu 1 style không tồn tại làm lỗi AAPT (link resource), hỏng cả build, mà không ai kiểm
   tra được lúc viết code. Giải pháp: Chip dùng mặc định (`android:checkable="true"`, không set
   `style=`), nút phụ dùng `MaterialButton` mặc định + `backgroundTint`/`textColor` thủ công thay vì
   named style.
7. **`ChipGroup.setOnCheckedChangeListener` (bản cũ, 1 checkedId)** được chọn thay vì
   `setOnCheckedStateChangeListener` (bản mới, `List<Int>`) — đã tra cứu tận source code Material
   Components (bản 1.14.0) xác nhận API cũ tuy `@Deprecated` nhưng vẫn tồn tại thật (chỉ delegate
   sang API mới bên trong) → chắc chắn compile được, an toàn hơn là đoán chữ ký API mới.
8. **`activity_main.xml` dùng `<ScrollView>` thường**, không dùng `CoordinatorLayout` +
   `NestedScrollView` như bản nháp đầu — để không phụ thuộc ngầm vào `androidx.coordinatorlayout`
   (dù nhiều khả năng có sẵn qua Material lib, dùng ScrollView thường loại bỏ hẳn nghi ngờ này).
9. **Không dùng database (Room/SQLite)** cho phiên quét hiện tại — `ScanSessionManager` in-memory
   là đủ vì 1 phiên quét ngắn hạn. Lịch sử các PDF đã xuất thì đọc thẳng từ thư mục
   `Documents/` (liệt kê file), không có bảng riêng.
10. Mọi phiên bản thư viện (AGP 8.5.2, Kotlin 2.0.20, Gradle 8.9, compileSdk/targetSdk 34, minSdk
    24, CameraX 1.4.1, coroutines 1.8.1...) được chọn vì là **bản chắc chắn đã tồn tại từ trước mốc
    kiến thức của Claude (khoảng đầu 2026)** — chọn kiểu này để dù có "phiên bản mới nhất" khác vào
    thời điểm build thật, các phiên bản cũ hơn vẫn luôn resolve được từ Maven Central (kho artifact
    không xoá bản cũ). Không cố tình dùng bản "mới nhất" vì không kiểm chứng được.
11. **EPUB tự viết bằng `java.util.zip`, không dùng thư viện ebook ngoài nào** — cùng triết lý với
    quyết định 2 (không PDF library ngoài): EPUB về bản chất chỉ là 1 file ZIP có cấu trúc XML quy
    định rõ ràng, hoàn toàn dựng được bằng `ZipOutputStream`/`ZipEntry` có sẵn trong JDK. Đã tra cứu
    xác nhận Amazon ngừng nhận MOBI từ 18/3/2025 và Kindle nhận EPUB thẳng qua Send-to-Kindle từ
    2022 → cố tình KHÔNG làm MOBI/AZW3 (định dạng nhị phân độc quyền phức tạp, không cách nào kiểm
    chứng đúng/sai khi không build-test được, và giờ cũng không còn cần thiết).
12. **`isColorPage`/`detectGutterX` chỉ dùng để GỢI Ý, không bao giờ tự áp dụng mà không cho chỉnh
    tay** — cả 2 heuristic OpenCV đều chưa test với ảnh thật (xem mục 6), nên mọi nơi dùng chúng đều
    thiết kế sao cho đoán sai vẫn không gây hại: `isColorPage` chỉ chọn sẵn 1 chip lọc (đổi được),
    `detectGutterX` chỉ đặt vị trí khởi tạo cho đường kéo-thả (kéo lại được). Đây là nguyên tắc
    chung nên giữ cho MỌI heuristic thêm sau này trong dự án.
13. **Tách 2 trang luôn chuyển `CropActivity` sang `queueMode = true`, kể cả khi bắt đầu từ camera
    (single mode)** — vì tách 1 ảnh ra 2 trang nghĩa là chắc chắn còn nhiều hơn 1 trang cần xử lý
    tiếp; cách đơn giản và ít rủi ro nhất là từ lúc đó luôn kết thúc bằng cách vào thẳng
    `PageListActivity` thay vì cố giữ hành vi "quay lại xem trước camera" của single mode — tránh
    phải theo dõi trạng thái phức tạp (đã cân nhắc & bỏ, xem mục 8).
14. **`PdfCompressor` tự viết PDF ở mức byte thô (`PdfByteWriter`), không dùng `PdfDocument`** —
    khác với MỌI tính năng PDF khác trong app (`PdfExporter` vẫn dùng `PdfDocument` bình thường).
    Lý do riêng cho tính năng này: đã tra cứu xác nhận `PdfDocument` (qua Skia PDF backend) không
    hề nén ảnh đưa vào — lưu gần như nguyên trạng trừ khi cắm JPEG encoder qua API Skia cấp thấp mà
    Android không lộ ra công khai. Một tính năng cam kết tỉ lệ nén cụ thể mà không kiểm soát được
    cách ảnh được lưu vào PDF thì vô nghĩa, nên bắt buộc phải tự viết object/xref PDF thay vì dùng
    `PdfDocument`.
15. **Kỹ thuật xác nhận thuật toán phức tạp khi không có môi trường build/test thật: viết bằng
    Python trước, đối chiếu với 1 thư viện đáng tin cậy đã có sẵn, rồi mới chuyển sang Kotlin** —
    áp dụng cho CCITT Group 4 (mục 4.11): viết encoder/decoder bằng Python, đối chiếu byte-for-byte
    với libtiff (qua Pillow) trên hàng chục mẫu ảnh, CHỈ SAU KHI khớp 100% mới chuyển bảng mã (sinh
    tự động bằng script, không gõ tay lại) và logic thuật toán (chuyển tay, rà soát kỹ) sang Kotlin.
    Đây là kỹ thuật NÊN DÙNG LẠI cho bất kỳ thuật toán/định dạng nhị phân phức tạp nào cần thêm vào
    dự án sau này, thay vì viết thẳng bằng Kotlin rồi hy vọng đúng.
16. **Khi phải dựa vào hành vi KHÔNG được tài liệu hoá công khai (vd. cấu trúc byte thật của file
    `PdfDocument` ghi ra) mà không có cách nào kiểm chứng trước (khác CCITT G4 — không có "libtiff"
    nào để đối chiếu cho trường hợp này): viết code thử làm việc đó, nhưng LUÔN bọc trong try/catch
    trả về `null`/rỗng ở BẤT KỲ bước nào không đúng như kỳ vọng, và nơi gọi PHẢI coi kết quả đó là
    "best-effort, có thể không xảy ra" chứ không phải "chắc chắn có" — không bao giờ để 1 giả định
    chưa kiểm chứng được có khả năng làm hỏng kết quả chính (ở đây: file PDF vẫn hợp lệ dù có hay
    không có bookmark). Áp dụng cho `PdfBookmarkInjector` (mục 4.12).
17. **`PdfImportHelper.renderAllPagesToFiles()` nhận thêm tham số `fileFactory` thay vì tách hàm
    riêng cho từng nơi gọi** — mặc định `null` giữ nguyên hành vi cũ (ghi vào cache qua
    `FileUtils.newImportedFile`), nơi nào cần bền thì tự truyền vào 1 lambda trỏ sang thư mục
    `filesDir` riêng của mình (mục 4.14). Chọn cách này thay vì viết 1 hàm
    `renderAllPagesToFilesDurable()` riêng để tránh trùng lặp gần như toàn bộ logic render/đóng
    `PdfRenderer` giữa 2 hàm — rủi ro thấp vì tham số có giá trị mặc định, mọi nơi gọi cũ không cần
    sửa gì vẫn chạy y hệt trước.
18. **Mỗi màn hình có backup/restore riêng (`PdfEditorState`/`EbookEditorState`/`PdfMergeState`),
    không dồn chung 1 object hay 1 hộp thoại ở `MainActivity`** — dù hơi lặp code JSON đọc/ghi so
    với gộp chung, nhưng dữ liệu cần lưu khác hẳn nhau giữa 3 màn hình và việc hỏi-khôi-phục đặt
    ngay trong `onCreate` của từng Activity liên quan tránh phải tự xếp thứ tự ưu tiên khi có nhiều
    phiên dở cùng lúc (mục 4.14).
19. **`EbookEditorState` không lưu văn bản OCR, chỉ lưu đánh dấu chương + đường dẫn trang** — vì
    OCR lại rẻ (offline, vài chục trang), lưu lại text sẽ tốn dung lượng JSON không cần thiết; khi
    khôi phục thì OCR lại rồi khớp theo đường dẫn để áp lại đánh dấu cũ (mục 4.14).
20. **`EbookEditorState.clear()` chỉ xoá file nằm trong đúng thư mục nó sở hữu
    (`ebookImportDir()`), không xoá mọi đường dẫn có trong state JSON** — vì trang nguồn của ebook
    có thể đến từ `ScanSessionManager` (thuộc phiên quét, do manager khác quản lý vòng đời) thay vì
    từ PDF nhập riêng; xoá không phân biệt nguồn sẽ có nguy cơ phá phiên quét đang hoạt động của
    manager kia (mục 4.14). Nguyên tắc chung nên áp dụng cho bất kỳ tính năng dọn-file nào thêm sau
    này có khả năng đụng tới file do nơi khác sở hữu: luôn kiểm tra quyền sở hữu trước khi xoá, chứ
    không suy luận từ việc "đường dẫn có xuất hiện trong state của mình".
21. **`PdfCompressor.compress()` tự viết object Outline (mục lục PDF) thẳng bằng `PdfByteWriter`,
    KHÔNG dùng lại `PdfBookmarkInjector`** — dù cả 2 đều là "thêm bookmark vào PDF", chúng ghi vào 2
    loại PDF khác nguồn: `PdfBookmarkInjector` viết riêng để vá PDF do `android.graphics.pdf.
    PdfDocument` xuất ra (byte-patching, vì lớp đó không có API bookmark - mục 4.12), còn
    `PdfCompressor` tự ghi toàn bộ PDF bằng `PdfByteWriter` nên ĐÃ BIẾT TRƯỚC số hiệu object của mọi
    trang → ghi object Outline cùng lúc, trỏ thẳng tới đúng object trang, không cần "vá" gì cả, an
    toàn hơn hẳn cách vá byte hậu kỳ (mục 4.15).
22. **`ProjectManager` (thuần dữ liệu) và `ProjectFlow` (điều hướng UI) tách làm 2 file, 2 package
    khác nhau, dù cùng phục vụ 1 tính năng** — theo đúng nguyên tắc đã có sẵn trong dự án: mọi file
    trong `model/` không được biết tới Activity nào cả (không file `model/` nào import 1 class
    Activity, trước giờ luôn vậy). `ProjectManager` (trong `model/`) chỉ lo đọc/ghi JSON; việc
    "stage nào mở Activity nào" là quyết định thuộc tầng UI, đặt ở `ProjectFlow.kt` (package gốc,
    ngang hàng với các Activity) (mục 4.15).
23. **Tách `PageListActivity`'s `BulkPreset`/`einkTextResult`/`einkColorResult` ra `util/
    ScanPresetApplier.kt`, sửa `PageListActivity` gọi lại object mới** — để `ProjectScanActivity`
    (bước 4 của Dự án) áp dụng ĐÚNG cùng 1 logic thay vì chép lại thành 2 bản dễ lệch nhau khi sửa
    sau này. Đã kiểm tra kỹ để hành vi công cụ "Lọc hàng loạt" gốc không đổi (mục 4.15).
24. **`ProjectEbookActivity` dùng lại NGUYÊN `activity_ebook_editor.xml`/
    `ActivityEbookEditorBinding`/`EbookPageAdapter` của `EbookExportActivity` thay vì tạo layout
    mới** — ViewBinding sinh ra theo TỪNG FILE layout, không buộc 1 layout chỉ được 1 Activity dùng;
    2 Activity khác nhau gọi `ActivityEbookEditorBinding.inflate(...)` là hợp lệ. Tiết kiệm hẳn 1
    layout gần như trùng lặp 100% (cùng cần: ô tên sách, 2 checkbox định dạng, list trang đánh dấu
    chương, nút xuất) (mục 4.15).
25. **`FileUtils.openFile()`/`shareFile()` mới được thêm để `ProjectSummaryActivity` dùng, KHÔNG
    sửa `MainActivity.shareFile()` gốc để gọi lại hàm chung** — dù hơi trùng lặp code, tránh đụng
    vào 1 Activity đã hoạt động ổn định (`MainActivity`) chỉ để đổi cách gọi nội bộ, rủi ro không
    đáng với lợi ích nhỏ thu được. `MainActivity.openTextResult()` KHÔNG được tái dùng cho
    `ProjectSummaryActivity` vì bản chất khác hẳn: hàm đó mở file `.txt` OCR ĐI KÈM 1 PDF, không
    phải mở chính file đó bằng app xem tương ứng - 2 hành vi khác nhau, dùng nhầm sẽ sai (mục 4.15).
26. **Thẻ "Dự án" được đặt vị trí ĐẦU TIÊN và mang kiểu highlight mà trước đây thuộc về thẻ "Quét";
    thẻ "Quét" bị hạ xuống thành thẻ thường, thêm dòng tiêu đề "Hoặc dùng riêng từng công cụ" phía
    trên các công cụ độc lập** — phản ánh đúng yêu cầu: quy trình Dự án giờ là con đường chính,
    trong khi "Quét" và mọi công cụ khác VẪN giữ nguyên 100% chức năng, chỉ đổi vị trí/kiểu hiển thị
    để phân biệt "luồng đầy đủ" với "công cụ dùng nhanh 1 việc" (mục 4.15).

## 6. Việc CÒN TỒN ĐỌNG / cố ý bỏ qua (làm tiếp từ đây)

- [x] ~~**"Sửa lại đúng câu chữ đã có sẵn trong PDF" (như Word) — phần người dùng đã chọn làm SAU
      phần đánh dấu/chú thích (mục 0/4.16, phiên thứ 7), CHƯA BẮT ĐẦU LÀM GÌ, kể cả thiết kế.**~~ —
      **đã làm ở phiên thứ 8, phạm vi ĐÃ ĐƯỢC THU HẸP RÕ RÀNG và người dùng đã xác nhận TRƯỚC khi
      code** (không phải "sửa tự do như Word" — tìm & thay 1 đoạn chữ NGẮN trong CÙNG 1 dòng, chỉ
      khi đủ ký tự trong font, tự co giãn ngang cho vừa khung, không tự xuống dòng lại). Xem mục
      4.17 để biết đầy đủ cơ chế (`PdfCanvasEditor`/`PdfTextEditor`, port từ mã nguồn thật
      `mkl-public/testarea-itext7`, không tự sáng tác). **VẪN CẦN TEST THẬT TRÊN NHIỀU PDF THẬT
      TRƯỚC KHI TIN DÙNG** — đây là tính năng DUY NHẤT trong dự án ghi trực tiếp vào object chữ của
      1 PDF có sẵn, chưa mở thử lần nào (môi trường này không build được), rủi ro sai sót nặng hơn
      hẳn (PDF hỏng/chữ lệch) so với 1 lỗi giao diện thông thường — xem mục 9/10 để biết cách test.
- [ ] **Chưa build-test thật lần nào** — việc quan trọng nhất, xem mục 0 và mục 9.
- [x] ~~`PdfAnnotateActivity` (tool mới "Chú thích PDF", phiên thứ 7) chưa có backup/restore qua
      chết tiến trình~~ — cố tình để vậy cho bản đầu, đã ghi rõ trong mục 4.16 (không phải quên).
      Có hộp thoại xác nhận trước khi mất chú thích chưa lưu, không phải lưu JSON đầy đủ như
      `PdfEditorState`/`EbookEditorState`. Đánh dấu `[x]` ở đây vì đây là quyết định đã chốt (chấp
      nhận), không phải việc đang chờ làm — khác các mục `[ ]` khác trong danh sách này.
- [x] ~~`PdfTextEditActivity` (tool mới "Sửa chữ PDF", phiên thứ 8) chưa có backup/restore qua chết
      tiến trình~~ — **cập nhật phiên thứ 9**: khác 2 mục `[x]` chấp nhận-là-được ở trên (annotate,
      Project ebook) — mục NÀY người dùng hỏi thẳng vì sao không tra cứu cách giải quyết, và câu
      trả lời là "không cần tra cứu, chỉ là chưa làm" — nên ĐÃ LÀM THẬT, không phải chấp nhận bỏ
      qua. Xem mục 0/4.17 (phiên thứ 9) để biết cơ chế riêng (lưu bản gốc + danh sách lần sửa, khôi
      phục bằng áp lại từ đầu, khác khuôn mẫu `PdfEditorState` thường dùng vì lý do kỹ thuật của
      iText stamping mode). Vẫn CHƯA test thật (cùng lý do môi trường như mọi phần khác).
- [ ] **`PdfTextEditActivity`/`PdfTextEditor` CHƯA TỪNG được test bằng 1 file PDF thật nào** — mục
      quan trọng NHẤT cần làm ngay khi build được (mục 9/10), ưu tiên cao hơn cả việc build-test các
      tool khác, vì đây là tính năng DUY NHẤT ghi trực tiếp vào object chữ của 1 PDF có sẵn — lỗi ở
      đây cho ra PDF hỏng/chữ sai vị trí/lệch font, không phải 1 lỗi giao diện thông thường có thể
      sửa nhẹ nhàng sau. Xem mục 4.17 (bảng "mức độ tin cậy API") để biết đúng 3 hàm iText nào chưa
      được tra cứu riêng trong phiên viết code này, nên nghi ngờ đầu tiên nếu build lỗi ở đây.
- [x] ~~Bài so sánh Kotlin vs Java mà người dùng hỏi ban đầu~~ — đã viết, xem `KOTLIN_VS_JAVA.md`.
- [x] ~~Tự lưu/khôi phục (mục 4.13) mới chỉ áp dụng cho phiên quét~~ — đã mở rộng sang cả 3 luồng
      còn lại (ghép PDF, quản lý trang PDF, soạn mục lục ebook), xem mục 4.14. Còn vài cửa sổ rủi ro
      hẹp chưa xử lý hết (mất trang đang render/OCR dở nếu app bị tắt đúng lúc đó) — xem "Giới hạn
      đã biết" cuối mục 4.14, chấp nhận được, không chặn gì.
- [ ] `isColorPage()` (ngưỡng saturation=40, tỉ lệ=2%) chưa test với ảnh/máy thật — nhiều khả năng
      cần chỉnh ngưỡng sau khi thấy kết quả thật (đặc biệt ảnh chụp bằng đèn vàng/flash dễ bị lệch
      màu, có thể bị nhận nhầm là "có màu").
- [ ] `detectGutterX()` (gợi ý vị trí gáy sách để tách 2 trang) **cũng chưa test với ảnh thật** —
      cùng rủi ro như `isColorPage()`. Vì chỉ là gợi ý ban đầu cho đường kéo tay (xem quyết định 12),
      đoán sai không hỏng tính năng, nhưng có thể cần tinh chỉnh vùng tìm kiếm (hiện cố định 30%-70%
      chiều rộng ảnh) sau khi thấy ảnh thật.
- [ ] Ebook (EPUB) **chưa từng mở thử bằng app đọc sách thật nào** (Google Play Books, Apple Books,
      calibre, gửi thử lên Kindle...) — cấu trúc XML/OPF/NCX được viết đúng theo chuẩn đã biết,
      nhưng chưa có xác nhận thực tế là file sinh ra mở được không lỗi. Việc ưu tiên khi test: mở
      thử 1 file EPUB xuất ra bằng vài app đọc sách khác nhau.
- [ ] Ebook không hỗ trợ MOBI/AZW3, và không hỗ trợ FB2 (cân nhắc rồi bỏ, xem mục 5.11) — nếu người
      dùng cần các định dạng này, cần làm thêm.
- [ ] **`Ccitt4Encoder`/`Ccitt4Decoder` (nén CCITT G4) chưa từng chạy trên Android thật** — thuật
      toán/bảng mã đã kiểm chứng rất kỹ bằng Python+libtiff (xem mục 4.11), nhưng code KOTLIN thực
      tế (chuyển tay từ Python) thì chưa. Có lưới an toàn tự giải mã lại trước khi dùng
      (`Ccitt4Decoder.verify()`), nên rủi ro cao nhất nếu có lỗi port là tự động rơi về cách an
      toàn (1-bit+Deflate) nhiều hơn dự kiến, không phải ra file hỏng — nhưng vẫn cần test thật để
      biết chế độ CCITT G4 có thực sự chạy được (không throw exception/crash) trên thiết bị.
      Việc ưu tiên khi test: bấm thử "Nén sâu hơn (CCITT G4)" với 1 PDF nhiều trang chữ, xem app có
      chạy được không và tỉ lệ nén thực tế đạt bao nhiêu so với "An toàn".
- [ ] `EpubReader` chỉ test đọc lại đúng EPUB mà `EbookBuilder` tự tạo ra (chưa test với EPUB từ
      nguồn khác — Calibre, Kindle export, v.v. — có thể có cấu trúc XHTML/CSS phức tạp hơn khiến
      `Html.fromHtml()` cho kết quả kém hơn, ví dụ mất định dạng bảng/danh sách phức tạp).
- [ ] `PdfBookmarkInjector` (bookmark thật trong PDF xuất từ EPUB/TXT) **chưa test trên thiết bị
      thật** — dựa vào giả định về cấu trúc byte PdfDocument ghi ra mà KHÔNG có cách nào kiểm chứng
      trước (khác CCITT G4 có libtiff để đối chiếu). Có lưới an toàn (trả `null` → dùng file gốc
      không bookmark) nên không thể ra file hỏng, nhưng chưa biết trên máy thật bookmark có thật sự
      xuất hiện hay không. Việc ưu tiên khi test: mở PDF xuất ra từ EPUB/TXT bằng 1 app đọc PDF có
      khung bookmark (Adobe Acrobat, hầu hết app đọc PDF trên Android) xem có thấy mục lục bấm được
      không.
- [ ] `TextPdfBuilder` ngắt dòng theo khoảng trắng — không hoạt động tốt với văn bản không có
      khoảng trắng giữa từ (tiếng Trung/Nhật/Hàn không cách âm); tiếng Việt/tiếng Anh không bị ảnh
      hưởng vì đều dùng khoảng trắng.
- [ ] Công cụ "Chuyển đổi định dạng" **chưa test trên thiết bị thật** cho cả 8 cặp chuyển đổi (PDF→
      Ebook, PDF→Ảnh chuyển tiếp sang màn có sẵn; EPUB→PDF, EPUB→TXT, TXT→PDF, TXT→EPUB, Ảnh→PDF
      tự làm mới).
- [x] ~~Trường hợp xuất CẢ EPUB lẫn TXT cùng lúc... UI không báo rõ cho người dùng biết cả 2 sẽ
      mất~~ — đã sửa: `MainActivity.confirmDeleteHistoryFile()` giờ kiểm tra riêng trường hợp xoá 1
      dòng `.epub` có file `.txt` cùng tên đang hiện thành dòng riêng trong lịch sử, và đổi nội dung
      hộp thoại xác nhận để nói rõ cả 2 sẽ bị xoá trước khi người dùng bấm Đồng ý. Hành vi xoá vẫn
      giữ nguyên (xoá cả cặp) — chỉ thêm cảnh báo, không đổi logic xoá.
- [ ] OCR chỉ xuất file `.txt` đi kèm, KHÔNG nhúng lớp văn bản có thể tìm kiếm vào trong PDF (PDF
      vẫn chỉ là ảnh quét). Muốn làm thật cần tự vẽ text bằng canvas ở chế độ gần như trong suốt
      đúng vị trí OCR trả về (phức tạp, chưa thử) hoặc đổi sang thư viện PDF thật.
- [ ] Công cụ Ghép PDF / Quản lý trang PDF làm mất chữ thật (chọn/copy được) của PDF gốc do
      rasterize — nếu cần giữ chữ thật, phải đổi hướng kỹ thuật (xem mục 5.2).
- [x] ~~File tạm trong cache không bao giờ tự dọn~~ — đã thêm `FileUtils.cleanOldCacheFiles()`,
      chạy 1 lần mỗi khi app khởi động (nền, không chặn startup), xoá file cũ hơn 24h trong
      `cache/captures/`, `cache/imported/`, `cache/temp/`. Lưu ý: `session_pages/` không còn nằm
      trong cache từ mục 4.13 (đã chuyển sang `filesDir`) nên tên thư mục trong dòng gốc phía trên
      không còn chính xác — giữ nguyên dòng gốc để không xoá lịch sử, đính chính ở đây.
- [ ] Không có test tự động (unit test/instrumented test) nào được viết, dù đã khai báo dependency
      `junit`/`espresso-core` trong `build.gradle`.
- [ ] Chỉ có build type `debug` (workflow CI chỉ chạy `assembleDebug`) — chưa cấu hình ký release,
      chưa build được bản release/AAB để đưa lên Play Store (đúng theo yêu cầu ban đầu là chỉ cần
      cài trực tiếp, nhưng cần nói rõ nếu sau này muốn public app).
- [ ] Icon app là icon tạm tự vẽ bằng code (hình chữ nhật xanh + trang giấy trắng + góc bẻ + móc góc
      vàng), chưa ai duyệt về mặt thiết kế.
- [ ] Chưa có `values-night` (dark theme riêng), chưa có layout riêng cho tablet/màn ngang.
- [ ] Chưa test go-through thực tế toàn bộ luồng nào (chụp→crop→lọc→xuất, ghép PDF, quản lý trang)
      trên thiết bị/emulator thật — mọi thứ mới chỉ được rà soát tĩnh (đọc code + đối chiếu resource,
      xem mục 9). Từ mục 4.14: thêm 3 hộp thoại khôi phục mới (page-editor/ebook/merge) cũng chưa
      test thật — cùng cách test như mục 4.13 đã gợi ý cho phiên quét (chụp/chọn vài thứ, force-stop
      app, mở lại xem hộp thoại có hiện đúng không), làm riêng cho từng màn hình trong 3 màn đó.
- [ ] **Toàn bộ luồng "Dự án" (mục 4.15) — 9 màn hình mới, CHƯA test go-through dù 1 lần.** Đây là
      việc test ưu tiên cao nhất sau khi build qua được (xem mục 10 đã xếp lại thứ tự). Test tối
      thiểu: 1 dự án đi hết cả 8 bước với 1 quyển sách thật (2-3 ảnh chụp trang đôi là đủ để test cả
      tách trang), có bật mục lục tự động 1 lần để xem `TocDetector` phản ứng ra sao với ảnh thật -
      gần như chắc chắn cần chỉnh lại regex sau lần test đầu (mục 4.15 đã nói rõ heuristic này chưa
      test với ảnh thật nào).
- [x] ~~`ProjectEbookActivity` (bước cuối của Dự án) không có backup/restore mức "đang gõ dở" như
      `EbookEditorState` làm cho công cụ độc lập tương ứng~~ — đã làm ở phiên thứ 4, file mới
      `ProjectEbookEditorState.kt` (backup theo từng dự án, xem mục 0/3/4.15). Vẫn CHƯA test thật
      (cùng hạn chế môi trường) — cách test gợi ý giống mục 4.13/4.14: làm dở vài đánh dấu chương ở
      bước 8, ép buộc dừng app, mở lại dự án xem có khôi phục đúng không.
- [x] ~~**Lỗi khai sai kích thước vật lý trang PDF (mục 7, "`ASSUMED_DPI` sai...") chưa được sửa
      hết** — còn đúng 1 đường: `MainActivity.importPdfForScanning()` (nút "Quét" → nguồn PDF) →
      hàng đợi crop ở `CropActivity` (chế độ queue) → `ScanSessionManager.addPage()` tại
      `CropActivity.kt` dòng có `ScanPage(ScanSessionManager.newPageId(), outFile.absolutePath)` —
      đang thiếu tham số `sourceDpi`.~~ — đã sửa ở phiên thứ 4, đúng theo cách mô tả ở đây (DPI
      truyền qua `PendingCropQueue` + Intent extra của `CropActivity`, giữ nguyên qua cả tách
      trang). Xem mục 0/7 để biết chi tiết. Vẫn CHƯA test thật trên thiết bị (cùng hạn chế môi
      trường) — cách test gợi ý: quét từ nguồn PDF, xuất ra, mở bằng app đọc PDF có hiện kích thước
      trang (hoặc so `/MediaBox` bằng tay) để xác nhận không còn bị khai to hơn thật ~1.47 lần
      (220/150) mỗi chiều.

## 7. Lỗi thật đã phát hiện & sửa trong lúc làm

- **EXIF orientation bị bỏ qua khi decode ảnh** (phát hiện lúc rà lại dependency
  `androidx.exifinterface` đã khai báo nhưng chưa dùng ở đâu — soi ra thiếu sót thật, không phải chủ
  động tìm bug). Ảnh chụp bằng camera hoặc lấy từ thư viện ảnh, nhất là ảnh chụp dọc máy, thường lưu
  ở hướng cảm biến gốc + thẻ EXIF ghi góc xoay, chứ không xoay vật lý pixel. `BitmapFactory.decodeFile`
  mặc định BỎ QUA thẻ EXIF này → ảnh có thể bị nạp sai hướng (nằm ngang dù chụp dọc), làm hỏng bước
  phát hiện góc + làm phẳng phối cảnh. **Đã sửa**: thêm `FileUtils.decodeBitmapWithExifOrientation()`
  (đọc `androidx.exifinterface.media.ExifInterface`, áp `Matrix` xoay/lật đúng chiều), dùng hàm này
  thay cho `BitmapFactory.decodeFile` thường tại đúng 1 điểm — `CropActivity.loadImage()` — vì đây
  là nơi DUY NHẤT ảnh "nguồn thô" (camera/thư viện/PDF) được nạp lần đầu, sửa 1 chỗ này là đủ cho cả
  3 nguồn ảnh (ảnh render từ PDF không có thẻ EXIF nên hàm này tự động là no-op, an toàn).
- **`PdfPageEditorActivity.setBusy()` gọi sai số tham số** (phát hiện ở phiên làm việc tiếp theo, lúc
  đang chuẩn bị sửa file này cho mục 4.14 — không phải tự nhiên soi ra, mà nhờ viết thêm 1 script
  Python đối chiếu số tham số bắt buộc của mọi hàm `fun` tự định nghĩa với số tham số thực tế truyền
  vào ở mọi lời gọi trong cùng file, xem mục 9). Hàm khai báo `setBusy(busy: Boolean, message:
  String?)` — không có giá trị mặc định cho `message` — nhưng lại được gọi ở 4 chỗ chỉ với 1 tham số
  (`setBusy(false)`). Đây CHẮC CHẮN sẽ là lỗi biên dịch thật (`Kotlin: No value passed for parameter
  'message'`) nếu build — đúng loại lỗi mục 0/9 đã dự đoán trước sẽ có ở lần build đầu tiên, chỉ khác
  là lần này tìm được bằng rà soát tĩnh trước khi có CI thật để báo. **Đã sửa**: thêm giá trị mặc
  định `message: String? = null` cho tham số đó (cách sửa ít thay đổi nhất — không phải sửa lại 4
  lời gọi). Đã quét lại toàn bộ file `.kt` khác bằng cùng script, không thấy trường hợp tương tự nào
  khác (chỉ có duy nhất hàm này bị lỗi).
- **`ASSUMED_DPI` sai cho mọi trang render từ 1 PDF có sẵn — làm trang xuất ra SAI KÍCH THƯỚC VẬT
  LÝ** (phát hiện khi trả lời câu hỏi của người dùng về so sánh cách nén "render ảnh" vs "sửa thẳng
  object PDF" cho trang scan — không phải câu hỏi về lỗi, nhưng đi sâu vào chi tiết thì lộ ra lỗi
  thật). `PdfExporter`/`PdfCompressor` đều có hằng số `ASSUMED_DPI = 150f`, dùng để suy ngược từ
  kích thước pixel của bitmap ra kích thước vật lý (point) khi ghi `/MediaBox` cho trang PDF xuất
  ra — hằng số này ĐÚNG cho ảnh chụp bằng camera (không có "DPI thật" nào để tham chiếu, 150 chỉ là
  quy ước hợp lý), nhưng SAI cho bitmap render từ 1 PDF có sẵn qua `PdfImportHelper.renderPage()` -
  nơi đó DPI thật đã biết chính xác (220/250/200 tuỳ chỗ gọi, không phải 150), vì
  `PdfRenderer`/`renderPage()` tính `scale = dpi/72f` dựa trên kích thước THẬT (point) của trang
  gốc. Dùng nhầm 150 thay vì DPI thật khi ghi ngược lại khiến trang xuất ra bị khai kích thước vật
  lý TO HƠN THẬT (to hơn đúng bằng tỉ lệ dpi_thật/150 — ví dụ trang A4 lúc render ở 250dpi rồi xuất
  với giả định 150dpi sẽ bị khai to gấp ~1.67 lần mỗi chiều). Hầu hết app xem PDF trên điện thoại tự
  fit-to-width nên không thấy gì bất thường, nhưng **nhiều máy đọc sách e-ink thật sự tôn trọng kích
  thước trang khai báo** — đúng use-case chính mà app này nhắm tới — nên đây là lỗi có ảnh hưởng thật
  tới đúng nhóm người dùng app phục vụ, không phải lỗi lý thuyết suông.
  **Đã sửa** cho các đường đi ĐÃ XÁC ĐỊNH RÕ DPI (không lẫn nguồn trong cùng 1 lần gọi):
  - `PdfCompressor.compress()` / `PdfExporter.exportSession()` / `exportImagePaths()`: thêm tham số
    tuỳ chọn (`assumedDpi`/`sourceDpi`, mặc định vẫn 150 — không đổi hành vi nơi nào chưa được sửa)
    để nơi gọi biết chắc DPI thật thì truyền vào đúng giá trị đó.
  - `ScanPage` thêm trường `sourceDpi: Float?` (mặc định `null` = ảnh chụp, dùng quy ước 150) để
    `ScanSessionManager`/`PdfExporter.exportSession()` biết DPI thật CHO TỪNG TRANG (1 phiên có thể
    trộn cả trang chụp camera lẫn trang import từ PDF) — có cập nhật cả lưu/khôi phục JSON (mục
    4.13) để không mất thông tin này khi backup/restore.
  - Đã sửa đúng 3 nơi biết chắc DPI: `MainActivity.importPdfForEink()` (250), `MainActivity`
    công cụ "Nén PDF" độc lập (250), `PdfPageEditorActivity` (200 — luôn nạp từ 1 PDF được chọn,
    không có nguồn camera nào khác trộn vào Activity này nên áp dụng chắc chắn cho cả file).
  - **CHƯA sửa (đã sửa ở phiên thứ 4 — xem cập nhật ngay dưới)**: đường
    `MainActivity.importPdfForScanning()` → hàng đợi crop (`PendingCropQueue`/`CropActivity` chế độ
    queue) → `ScanSessionManager.addPage()` ở `CropActivity.kt`. Đường này CŨNG bị lỗi tương tự
    (render ở 220dpi, `warpDocument()` đã xác nhận giữ nguyên mật độ pixel qua bước crop nên DPI
    220 vẫn đúng cho ảnh sau khi cắt — không phải lo ngại kỹ thuật, chỉ là CHƯA làm), nhưng cần
    truyền DPI qua `PendingCropQueue`/Intent extra của `CropActivity` — nhiều việc hơn, chưa làm
    trong lượt này để tránh sửa vội 1 luồng có logic phức tạp hơn (hàng đợi, tách trang) mà không
    kiểm chứng được gì trong môi trường này.
  - `ConvertDocumentActivity.convertImagesToPdf()` KHÔNG bị lỗi này — ảnh đầu vào ở đó là ảnh người
    dùng tự chọn trực tiếp (không phải render từ PDF), không có "DPI thật" nào để mất, quy ước 150
    vẫn hợp lý như với ảnh chụp camera.
  - **Cập nhật (phiên thứ 4)**: đã sửa nốt đường còn lại ở trên. `PendingCropQueue` thêm 1 thuộc
    tính `sourceDpi: Float?` DÙNG CHUNG cho cả lô đang xếp hàng (hợp lý vì 1 lần gọi `setAll()` luôn
    chỉ đến từ 1 nguồn duy nhất — hoặc toàn bộ ảnh thư viện, hoặc toàn bộ trang của 1 PDF đang import
    — không bao giờ trộn 2 nguồn trong cùng 1 lô, nên không cần lưu riêng theo từng ảnh). `MainActivity.
    startCropQueue()` nhận thêm tham số tuỳ chọn `sourceDpi` (mặc định `null`, không đổi hành vi nơi
    gọi cũ - `importGalleryImages()`), truyền vào `PendingCropQueue.setAll()` VÀ gắn vào Intent qua
    hằng số mới `CropActivity.EXTRA_SOURCE_DPI` (chỉ đặt khi khác `null`) - cần cả 2 đường vì ảnh ĐẦU
    TIÊN của lô đi thẳng qua Intent extra `EXTRA_IMAGE_PATH`, không qua `PendingCropQueue` (chỉ ảnh
    thứ 2 trở đi mới nằm trong hàng đợi). `importPdfForScanning()` gọi `startCropQueue(paths,
    sourceDpi = 220f)` (220 khớp đúng DPI đã render ở dòng `renderAllPagesToFiles(..., dpi = 220)`
    ngay phía trên). Phía `CropActivity`: đọc `EXTRA_SOURCE_DPI` đúng 1 lần trong `onCreate()`, giữ
    trong 1 field `sourceDpi: Float?` suốt vòng đời Activity (không đọc lại từ `PendingCropQueue` mỗi
    lần lấy ảnh tiếp theo trong hàng đợi - không cần thiết vì 1 Activity chỉ xử lý đúng 1 lô, kể cả
    khi tự xử lý tiếp ảnh trong hàng đợi qua `loadImage()` mà KHÔNG tạo Activity mới), rồi gán field
    này vào MỌI `ScanPage` được lưu ra ở `savePage()` - bao gồm cả 2 nửa sau khi tách trang, vì nửa
    phải được đẩy lại vào chính `PendingCropQueue` này (`pushFront()`) rồi cũng được nạp lại và lưu
    ra bởi CÙNG Activity, CÙNG field `sourceDpi` đó, nên tự động đúng mà không cần thêm code riêng
    cho trường hợp tách trang. Đường ảnh chụp máy ảnh (`CaptureActivity`, chế độ single) không đặt
    `EXTRA_SOURCE_DPI` nên `sourceDpi` vẫn là `null` như trước khi sửa - hành vi hoàn toàn không đổi
    cho 2 nguồn ảnh còn lại (thư viện, camera). Đã rà lại bằng đủ 6 cách ở mục 9 sau khi sửa, không
    phát hiện vấn đề gì mới. **Vẫn CHƯA test thật trên thiết bị** (cùng hạn chế môi trường mọi phiên).

## 8. Cạm bẫy / hướng đã cân nhắc rồi bỏ (để không thử lại mất công)

- Định dùng **adaptive-icon XML** (`mipmap-anydpi-v26` + vector foreground/background) cho icon app
  — bỏ vì `minSdk=24` vẫn cần fallback PNG cho API 24-25, nên chuyển hẳn sang PNG thường cho mọi
  API cho đỡ phức tạp (xem mục 5.5).
- Định dùng style `Widget.Material3.Chip.Filter` cho các Chip chọn bộ lọc — bỏ vì không chắc chắn
  100% tên style này tồn tại đúng như vậy trong bản Material Components đang dùng, mà sai thì hỏng
  cả build không ai sửa kịp lúc đó (xem mục 5.6).
- Định gộp toàn bộ 3 nguồn ảnh (camera/thư viện/PDF) kể cả bước chụp camera vào chung 1 hàng đợi
  `PendingCropQueue` để code gọn hơn nữa — bỏ vì sẽ phá vỡ trải nghiệm "chụp xong hiện crop ngay,
  xong quay lại xem trước camera liền" của luồng camera (vốn là luồng chính hay dùng nhất) — quyết
  định giữ camera dùng cơ chế "single mode" riêng (trả `ActivityResult`), chỉ dùng hàng đợi cho
  thư viện ảnh/nhập PDF (xem mục 2).
- Định tạo 3 màn hình riêng cho Tách trang / Xoá & Sắp xếp / Xoay trang PDF (đúng như đề xuất ban
  đầu với người dùng) — sau đó gộp lại thành 1 màn `PdfPageEditorActivity` duy nhất (có cả xoay +
  xoá + sắp xếp + chọn-để-tách) vì cả 3 việc đều dùng chung 1 kiểu dữ liệu (danh sách trang PDF) và
  cùng 1 kiểu thao tác trên lưới ảnh — gộp lại đỡ trùng lặp code, UX cũng gọn hơn là bắt người dùng
  nhảy qua lại nhiều màn hình cho cùng 1 file.
- Định để bộ lọc E-ink chỉ có 1 preset chung (trắng đen) — sau khi người dùng chỉ ra e-ink màu đã
  phổ biến, tách thành 2 preset (văn bản/màu), rồi lại thêm preset thứ 3 "Tự động" nhận diện theo
  từng trang — xem toàn bộ diễn tiến ở mục 4.3.
- Định làm tính năng tách 2 trang thành 1 **màn hình riêng hoàn toàn** (stage 0 chặn toàn màn hình
  trước khi vào crop) — bỏ, gộp thành 1 nút "Tách 2 trang" ngay trong giai đoạn crop hiện có, chỉ
  hiện UI tách khi người dùng chủ động bấm — đỡ phải hỏi "đây có phải ảnh 2 trang không" cho MỌI
  ảnh (đa số ảnh không phải cảnh 2 trang), giảm số bước cho trường hợp thường gặp nhất.
- Định giữ nguyên hành vi "single mode quay lại camera" ngay cả sau khi tách trang (tách xong quay
  lại xem trước camera, không nhảy sang page list) — bỏ vì phải theo dõi thêm trạng thái "mode gốc
  là gì, khi nào coi là xử lý xong" phức tạp không cần thiết; chuyển hẳn sang quy tắc đơn giản "đã
  tách thì luôn xem như queue mode" (quyết định 13, mục 5).
- Định tự động ÁP DỤNG LUÔN gợi ý của `detectGutterX`/`isColorPage` mà không cho chỉnh tay (để bớt 1
  bước bấm) — bỏ, vì cả 2 đều là heuristic OpenCV thuần, chưa test với ảnh thật (mục 6), tự động áp
  dụng cứng sẽ biến 1 lần đoán sai thành lỗi không sửa được; giữ nguyên tắc "gợi ý + luôn cho sửa
  tay" cho mọi heuristic trong dự án (quyết định 12, mục 5).
- Định làm thêm định dạng MOBI/AZW3/FB2 cho ebook — bỏ MOBI/AZW3 hẳn (lý do ở quyết định 11, mục 5),
  tạm bỏ FB2 dù kỹ thuật dễ thêm (cũng chỉ là XML, tái dùng được cấu trúc `Chapter`) để không dàn
  trải, ưu tiên làm đúng EPUB/TXT trước.
- Định để `PdfCompressor` cũng dùng `PdfDocument` như các tính năng khác cho gọn code — bỏ ngay khi
  phát hiện `PdfDocument` không hề nén ảnh (mục 5, quyết định 14) — đổi hẳn sang tự viết PDF thô.
- Định thử "nén ảnh JPEG trước rồi decode lại thành Bitmap rồi vẽ qua `PdfDocument`" để lách qua
  giới hạn trên — bỏ ngay khi nhận ra decode ngược lại mất hết lợi ích nén (PdfDocument vẫn lưu lại
  pixel thô sau khi decode, không "nhớ" được là ảnh từng qua JPEG) — đây chính là lý do phải tự
  viết PDF thô thay vì tìm cách vòng qua `PdfDocument`.
- Định chỉ làm 1 cách nén cho trang chữ (an toàn, 1-bit+Deflate) vì lo CCITT G4 tự viết rủi ro cao
  — sau khi người dùng hỏi kỹ và yêu cầu làm cả 2 để tự chọn, đã làm CCITT G4 thật nhưng kèm quy
  trình kiểm chứng nghiêm ngặt (mục 4.11) thay vì bỏ hẳn — bài học: rủi ro cao không có nghĩa là
  "không làm được", mà là "cần kiểm chứng kỹ hơn trước khi làm".
- Cân nhắc bỏ EOFB (3 byte cuối luồng CCITT G4) vì PDF không bắt buộc khi đã có `/Rows` +
  `/EndOfBlock false` — vẫn giữ lại vì chỉ tốn 3 byte, đổi lại tương thích rộng hơn với mọi đầu đọc
  PDF (kể cả loại không tôn trọng `/EndOfBlock false`).
- **[CẬP NHẬT — quyết định này đã ĐẢO NGƯỢC, xem mục 4.11 "Sửa trực tiếp"]** Ban đầu cân nhắc thêm 1
  thư viện đọc/sửa cấu trúc PDF thật (kiểu PDFBox) để công cụ "Nén PDF" độc lập có thể sửa thẳng
  object ảnh trong PDF thay vì phải render cả trang ra ảnh rồi dựng lại từ đầu (đúng cách Ghostscript/
  qpdf làm) — LÚC ĐẦU đã bỏ, với lý do: đây sẽ là phụ thuộc ngoài ĐẦU TIÊN của cả dự án mà không có
  cách nào kiểm chứng dù chỉ 1 phần trong môi trường này. Người dùng phản đối cách trả lời đó (đúng):
  chỉ nói "cần thêm thư viện" rồi dừng lại, không thật sự đi tìm xem thư viện đó có tồn tại hay
  không, là né tránh có giải thích chứ không phải không né tránh. Đã tra lại nghiêm túc bằng
  web_search (không đoán mò): tìm ra `TomRoush/PdfBox-Android` (Apache 2.0, nhưng 3 năm không có bản
  mới, có CVE chưa vá trong dependency), `iText 7/8` (được bảo trì thật, có Android build chính
  thức, nhưng AGPL/trả phí), `DroidPDF` (Kotlin-native, mới hơn, nhưng danh sách tính năng công khai
  không xác nhận hỗ trợ đúng việc lấy-ảnh-nhúng-ra-nén-lại cần làm). Người dùng chọn iText, chấp
  nhận AGPL. **Đã làm** — xem mục 4.11 "Sửa trực tiếp" để biết chi tiết, và bài học rút ra: "tao
  không kiểm chứng được" là lý do hợp lý để CẨN TRỌNG hơn, KHÔNG phải lý do để không thử — vẫn có thể
  làm với đầy đủ rà soát tài liệu chính thức + ví dụ thật thay vì đoán API, miễn là nói rõ phần nào
  đã xác nhận được, phần nào chưa.
- Cân nhắc bỏ EOFB (3 byte cuối luồng CCITT G4) vì PDF không bắt buộc khi đã có `/Rows` +
  `/EndOfBlock false` — vẫn giữ lại vì chỉ tốn 3 byte, đổi lại tương thích rộng hơn với mọi đầu đọc
  PDF (kể cả loại không tôn trọng `/EndOfBlock false`).

## 9. Rủi ro build & cách đã giảm thiểu (vì chưa build-test thật được)

**Trước hết, ưu tiên test khi build được lần đầu tiên**: `PdfTextEditActivity`/`PdfTextEditor` (mục
4.17, phiên thứ 8) — tính năng DUY NHẤT ghi trực tiếp vào object chữ thật của 1 PDF có sẵn, chưa mở
thử lần nào, lỗi ở đây cho ra PDF hỏng chứ không phải lỗi giao diện thông thường. Xem mục 6/10.

Vì môi trường viết code này **không có Android SDK, không có mạng để chạy Gradle**, không có cách
nào build thử thật. Để giảm rủi ro, đã làm các việc sau (viết script Python dùng 1 lần, không nằm
trong project, chỉ để tự rà soát):
- Parse toàn bộ layout XML để chắc chắn không lỗi cú pháp XML.
- Đối chiếu từng `binding.<tên>` dùng trong mỗi Activity/Adapter với đúng `android:id` có thật trong
  layout XML tương ứng — không thấy thiếu.
- Đối chiếu toàn bộ `R.string/id/drawable/color/menu/layout` dùng trong code Kotlin với resource
  thật sự tồn tại — không thấy thiếu.
- Đếm cân bằng ngoặc `{}`/`()` trong mọi file `.kt` — không thấy lệch.
- Kiểm tra trùng tên `<string name="...">` trong `strings.xml` — không có trùng.
- Tra cứu web (không đoán từ trí nhớ) để xác nhận: artifact OpenCV, API `OpenCVLoader.initLocal()`,
  cách dùng `gradle/actions/setup-gradle` không cần wrapper, `android-actions/setup-android` còn
  được bảo trì, API `ChipGroup.setOnCheckedChangeListener` còn tồn tại dù deprecated.
- **(Thêm ở phiên sau)** Đối chiếu số tham số BẮT BUỘC (không có giá trị mặc định) của mọi hàm `fun`
  tự định nghĩa trong từng file `.kt` với số tham số thực tế truyền vào ở mọi lời gọi cùng file (đếm
  dấu phẩy ở độ sâu ngoặc = 0, có bỏ qua string/char/comment) — cách này soi ra lỗi thật ở mục 7
  (`setBusy()` thiếu tham số) mà 5 cách rà soát phía trên KHÔNG bắt được (chúng chỉ đối chiếu
  resource/XML, không đối chiếu chữ ký hàm Kotlin với nhau). Nên chạy lại cách này mỗi khi sửa xong
  1 đợt code, giống các cách phía trên.
- **(Thêm ở phiên thứ 4)** Viết lại cách rà số tham số ở trên thành bản ĐỐI CHIẾU TOÀN DỰ ÁN (không
  chỉ trong cùng 1 file nữa): gom chữ ký MỌI hàm `fun`/constructor (kể cả data class) ở MỌI file
  `.kt` thành 1 bảng tra theo tên, rồi so với MỌI lời gọi ở MỌI file — bắt được cả lỗi gọi sai tham
  số CHÉO FILE (ví dụ 1 hàm ở `util/` bị gọi sai từ 1 Activity khác file), điều cách cũ (chỉ so trong
  cùng file) bỏ sót. Chạy trên toàn bộ 54 file `.kt` hiện tại (kể cả luồng Dự án ở mục 4.15 và
  `PdfObjectRecompressor.kt`), thu được 413 chữ ký cho 280 tên hàm khác nhau, đối chiếu 457 lượt gọi.
  Kết quả: 41 chỗ bị báo "lệch số tham số", nhưng kiểm tra tay xác nhận CẢ 41 CHỖ ĐỀU CÙNG 1 LOẠI BÁO
  ĐỘNG GIẢ — mọi Activity đều gọi `finish()` kế thừa từ `android.app.Activity` (0 tham số, đúng), tên
  này trùng với 1 hàm riêng không liên quan `PdfByteWriter.finish(catalogObjNum: Int)` (1 tham số bắt
  buộc, dùng nội bộ trong chính `PdfByteWriter.kt` để đóng object PDF) — vì cách rà này chỉ so tên
  hàm, không biết class/phạm vi (không phải trình biên dịch Kotlin thật), nó đối chiếu nhầm 2 hàm
  trùng tên nhưng khác class này với nhau. **Ghi chú cho lần rà sau**: nếu thấy lại đúng 41 báo động
  này (hoặc bất kỳ báo động nào có dạng "gọi `finish(...)` với 0 tham số nhưng cần 1..1") thì ĐÓ LÀ
  BÁO ĐỘNG GIẢ ĐÃ BIẾT, không cần kiểm tra lại - chỉ cần kiểm tra tay các báo động MỚI (tên hàm khác,
  hoặc file khác `PdfByteWriter.kt` cho `finish`). Không phát hiện lỗi thật nào mới ở lần chạy này.
- **(Thêm ở phiên thứ 5)** Sau khi thêm `PdfObjectRecompressor.wrapAsMinimalPng()` (mục 4.11, dựng
  file PNG tối giản để bọc byte Predictor), rà lại thấy thêm ĐÚNG 1 LOẠI báo động giả MỚI: 7 chỗ gọi
  `write(...)` (các lệnh ghi từng byte header PNG qua `ByteArrayOutputStream.write()` có sẵn của
  Java) bị đối chiếu nhầm với `Ccitt4Encoder.kt`'s `BitWriter.write(length, value)` — 1 hàm riêng
  không liên quan, chỉ trùng tên, khác hẳn class. Kiểm tra tay xác nhận cả 7 đều vô hại. **Ghi chú
  cho lần rà sau**: báo động dạng "gọi `write(...)` với 1 tham số nhưng cần 2..2 (theo
  `Ccitt4Encoder.kt`)" cũng là BÁO ĐỘNG GIẢ ĐÃ BIẾT, cùng loại với `finish()` ở trên — chỉ do trùng
  tên hàm giữa các class khác nhau, không phải lỗi thật.
- Cũng đã chạy lại cả 5 cách rà soát còn lại (XML, `binding.<id>`, `R.*`, cân bằng ngoặc, trùng tên
  string) trên TOÀN BỘ code hiện tại (không chỉ phần mới sửa) — không phát hiện gì.

**Rủi ro riêng của luồng Dự án (mục 4.15)** — khối lượng code mới lớn nhất từ trước đến giờ trong 1
phiên làm việc (9 Activity + 3 adapter + 10 layout + 2 file model + 1 file util hoàn toàn mới), nên
rủi ro có lỗi build cao hơn hẳn các phần trước, dù đã chạy đúng 6 cách rà soát tĩnh ở trên trên toàn
bộ code MỚI (không chỉ phần cũ) và đối chiếu tay chữ ký từng hàm dùng chéo file (`ImageProcessor`,
`PdfExporter`, `PdfCompressor`, `OcrHelper`, `EbookBuilder`, `CropOverlayView`, `SplitLineOverlayView`
...) so với định nghĩa gốc trước khi dùng — không dựa vào trí nhớ cho bất kỳ chữ ký hàm nào. Vẫn có
những thứ CHỈ build/chạy thật mới biết chắc, đặc biệt: `ItemHistoryBinding`/`ActivityEbookEditor
Binding` dùng lại ở 2 Activity khác nhau (`ProjectAdapter`/`ProjectSummaryActivity` và
`ProjectEbookActivity`) có build đúng như lý thuyết ViewBinding hay không; layout `activity_project_
edit.xml` tái dùng `CropOverlayView`/`SplitLineOverlayView` (vốn viết cho `CropActivity`) có hoạt
động đúng khi được nhúng trong 1 `ConstraintLayout` khác cấu trúc constraint không.

**Những gì KHÔNG được kiểm tra** (vì không thể, cần build thật mới biết):
- AGP/Kotlin/Gradle/thư viện có thật sự tương thích với nhau ở đúng phiên bản đã chọn hay không.
- OpenCV AAR có tải/link đúng trên môi trường CI (Ubuntu runner) hay không.
- Toàn bộ luồng runtime (permission camera, CameraX bind lifecycle, ML Kit model tải/chạy...) có
  chạy đúng trên thiết bị thật hay không.

→ **Khi build lần đầu có lỗi, đó là chuyện bình thường đã lường trước — gửi log lỗi để sửa tiếp,
không phải hiện tượng bất thường.**

## 10. Việc cần làm tiếp theo (gợi ý thứ tự ưu tiên)

1. Push code lên GitHub, chạy Actions, sửa lỗi build đầu tiên (nếu có) — xem mục 9. Khối lượng code
   mới nhất (mục 4.17, phiên thứ 8) làm bước này càng quan trọng hơn — xác suất build lỗi ngay lần
   đầu cao hơn các phiên trước, và đây là lần đầu dự án phụ thuộc sâu vào API nội bộ của iText
   (`PdfCanvasProcessor`/`registerContentOperator`) chứ không chỉ API công khai đơn giản.
2. **Test `PdfTextEditActivity` ("Sửa chữ PDF", mục 4.17) TRƯỚC MỌI THỨ KHÁC** — ưu tiên cao nhất
   trong toàn bộ mục này, xem lý do đầy đủ ở đầu mục 9. Test tối thiểu: chuẩn bị vài PDF CÓ CHỮ THẬT
   từ nhiều nguồn khác nhau (xuất từ Word, xuất từ Google Docs, 1 PDF từ LaTeX nếu có, 1 PDF có OCR
   text layer) — không dùng PDF app này tự quét ra (đó là ảnh, không có chữ thật để sửa). Với mỗi
   file: mở tool, thử sửa vài đoạn chữ ngắn (đổi vài ký tự, đổi 1 từ ngắn thành từ dài hơn/ngắn hơn
   để xem cơ chế co giãn `Tz` có ra kết quả đọc được không), xuất PDF, MỞ LẠI FILE XUẤT RA bằng 1
   trình đọc PDF khác (không phải app này) để xác nhận: (a) file không bị lỗi/hỏng, mở được bình
   thường; (b) đoạn đã sửa hiện đúng chữ mới, không bị chồng chữ cũ hoặc lệch vị trí rõ rệt; (c) phần
   còn lại của trang (chữ khác, ảnh, định dạng) không bị ảnh hưởng gì. Thử cả trường hợp NÊN bị từ
   chối (gõ 1 ký tự lạ chắc chắn không có trong font gốc, ví dụ ký tự Hàn/Nhật vào 1 PDF tiếng Anh)
   để xác nhận tool từ chối đúng như thiết kế thay vì âm thầm ghi sai.
3. **Test đi hết cả 8 bước của 1 "Dự án" thật (mục 4.15)** — tính năng lớn, chưa được ai chạm vào
   lần nào. Test tối thiểu: chụp/chọn vài
   ảnh (có ít nhất 1 ảnh 2 trang để test luôn bước tách trang), đi hết crop → chọn preset → xuất PDF
   (bật mục lục tự động 1 lần để xem `TocDetector` phản ứng ra sao với ảnh thật - gần như chắc chắn
   cần chỉnh regex) → nén → OCR → tạo ebook, xong thử thoát giữa chừng ở vài bước khác nhau rồi mở
   lại dự án xem có tiếp tục đúng chỗ không.
4. Cài APK debug lên máy thật, test đủ 3 luồng CÔNG CỤ ĐỘC LẬP còn lại: quét (cả 3 nguồn ảnh), ghép
   PDF, quản lý trang PDF, chú thích PDF (mục 4.16). Test riêng backup/restore cho cả 5 màn hình có
   (phiên quét, quản lý trang PDF, soạn ebook, ghép PDF, và từ phiên thứ 4: soạn ebook trong luồng Dự
   án — xem mục 4.13/4.14/6):
   làm dở vài thao tác, ép buộc dừng app (vuốt khỏi Recents hoặc Settings → Apps → Force stop), mở
   lại app/màn hình đó xem hộp thoại/trạng thái khôi phục có hiện đúng không, tiếp tục có ra đúng
   trạng thái cũ không. Riêng luồng "quét từ nguồn PDF" (bước 3 luồng độc lập), tiện thể kiểm tra
   luôn kích thước trang PDF xuất ra có đúng không (xem lỗi `ASSUMED_DPI` đã sửa ở mục 0/6/7, phiên
   thứ 4 — chưa có cách nào kiểm chứng được ngoài chạy thật).
5. Test riêng heuristic `isColorPage()` và `detectGutterX()` với vài ảnh thật (chữ đen thường, chữ
   có highlight màu, trang có ảnh chụp màu; ảnh chụp 2 trang sách mở phẳng) — chỉnh ngưỡng nếu
   nhận/gợi ý sai.
7. Mở thử file `.epub` xuất ra bằng vài app đọc sách khác nhau (Google Play Books/Apple
   Books/calibre/gửi thử Send-to-Kindle) để xác nhận cấu trúc EPUB thật sự hợp lệ.
8. Test công cụ "Nén PDF" cả 2 cách (An toàn / CCITT G4) trên vài PDF thật (tài liệu chữ nhiều
   trang, tài liệu có cả trang màu) — xem tỉ lệ nén thực tế đạt bao nhiêu, CCITT G4 có tự rơi về
   cách an toàn nhiều không (nếu có, xem log để biết `Ccitt4Decoder.verify()` fail ở đâu). Áp dụng
   luôn cho bước "Nén PDF" trong luồng Dự án (dùng chung `PdfCompressor`).
9. Test công cụ "Chuyển đổi định dạng" — đặc biệt EPUB→PDF/TXT (thử với cả EPUB do chính app tạo
   ra và 1 EPUB từ nguồn khác để xem `EpubReader` chịu được cấu trúc phức tạp hơn tới đâu), và mở
   PDF xuất ra bằng app có khung bookmark để xem `PdfBookmarkInjector` có thêm được mục lục thật
   không (không thấy bookmark cũng không sao — file vẫn dùng bình thường, chỉ là chưa thêm được).
10. ~~Bài so sánh Kotlin vs Java~~ — đã xong, xem `KOTLIN_VS_JAVA.md`.
11. ~~Dọn file cache tạm định kỳ~~ — đã xong (mục 4.14), chỉ cần xác nhận thật sự chạy đúng trên máy
   thật khi test (mục cần làm số 3 ở trên).
12. Nếu người dùng cần giữ chữ thật khi ghép/tách PDF (không rasterize) — nghiên cứu đổi sang
   `pdfbox-android` hoặc tương đương, đánh giá lại rủi ro build khi đó đã có thể build-test thật.
13. Nếu người dùng cần thêm định dạng ebook (FB2, hoặc MOBI/AZW3 dù không khuyến khích — xem quyết
    định 11) thì làm thêm khi được yêu cầu, tái dùng cấu trúc `EbookBuilder.Chapter` có sẵn.
