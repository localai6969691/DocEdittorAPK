# Kotlin vs Java cho dự án DocScanner

> Câu hỏi này được hỏi ở bước đầu tiên của dự án (cùng lúc với yêu cầu "mức tính năng đầy đủ") nhưng
> chưa từng được trả lời - Kotlin được chọn ngầm rồi code luôn (xem TECHNICAL_DOCS.md mục 0). File
> này trả lời câu hỏi đó, viết riêng để TECHNICAL_DOCS.md không phình to với nội dung không phải
> nhật ký tiến độ. Kết luận: **giữ nguyên Kotlin** (lý do ở cuối file) - đây là bài so sánh khách
> quan để tham khảo, không phải đề xuất đổi ngôn ngữ giữa chừng.

## Tóm tắt nhanh

| Tiêu chí | Kotlin | Java |
|---|---|---|
| An toàn null | Có ở mức compiler (`?`, `!!`, smart cast) | Không - `NullPointerException` là lỗi runtime phổ biến nhất trên Android |
| Độ ngắn gọn | Data class, extension function, `when`, string template | Verbose hơn nhiều - getter/setter/constructor/`equals`/`hashCode` phải tự viết hoặc dùng Lombok (không sẵn có trên Android) |
| Coroutines (bất đồng bộ) | Có sẵn (`suspend`, `launch`, `withContext`) | Không có cú pháp tương đương - phải dùng callback lồng nhau, `AsyncTask` (deprecated), hoặc thêm thư viện RxJava |
| Tương tác Java library (OpenCV, ML Kit) | 100% - gọi thẳng, không cần lớp chuyển đổi | Native, không cần bàn |
| Được Google khuyến nghị cho Android | Có, chính thức từ Google I/O 2019 ("Kotlin-first") | Vẫn được hỗ trợ đầy đủ, không bị "khai tử", nhưng tài liệu/ví dụ mới của Google phần lớn viết bằng Kotlin |
| Thời gian biên dịch | Chậm hơn Java một chút (đặc biệt lần build sạch đầu tiên) | Nhanh hơn |
| Độ dốc học tập với người quen Java | Thấp - cú pháp học nhanh trong vài ngày | N/A |
| Kotlin Multiplatform (nếu sau này muốn chia sẻ code với iOS/desktop) | Có | Không |

## Vì sao Kotlin phù hợp cụ thể cho dự án này

1. **OpenCV và ML Kit đều là thư viện Java/C++ gốc, không phải rào cản** - cả 2 đều expose Java API
   bình thường qua JNI/AAR, Kotlin gọi thẳng được không cần wrapper, nên "tương tác thư viện Java"
   không phải lý do để chọn Java thuần.
2. **Lượng code bất đồng bộ trong app rất lớn**: quét ảnh, OCR từng trang, render PDF, mã hoá
   CCITT G4, ghép/tách PDF - gần như mọi màn hình đều có tác vụ chạy nền + cập nhật UI khi xong.
   Coroutines (`lifecycleScope.launch { withContext(Dispatchers.IO) { ... } }`) diễn đạt đúng luồng
   "làm nền rồi quay lại UI thread" bằng code tuần tự, dễ đọc; viết lại bằng Java thuần sẽ cần
   callback lồng nhau nhiều tầng (hoặc thêm RxJava - tăng thêm 1 dependency + đường cong học tập
   riêng của nó) cho từng thao tác này.
3. **Nhiều lớp dữ liệu đơn giản** (`ScanPage`, `PdfPageItem`, `EbookPageData`, kết quả nén CCITT...) -
   `data class` của Kotlin tự sinh `equals`/`hashCode`/`toString`/`copy()` trong 1 dòng; Java cần
   IDE tự sinh ra hàng chục dòng boilerplate cho mỗi lớp như vậy (không có Lombok vì Lombok không
   được khuyến khích dùng chung với Android Gradle Plugin do vấn đề tương thích annotation processor).
4. **An toàn null quan trọng hơn bình thường** ở đúng những chỗ dự án này có nhiều: đọc file từ SAF
   (Uri có thể trỏ tới file đã bị xoá), decode bitmap (có thể trả về null nếu ảnh hỏng), kết quả OCR
   (có thể rỗng). Kotlin bắt các trường hợp `null` ngay lúc biên dịch (`Bitmap?`, `?.let`, `?:`) thay
   vì để lộ ra thành crash lúc chạy thật trên máy người dùng - quan trọng vì dự án này **chưa từng
   được build-test trên thiết bị thật** (xem TECHNICAL_DOCS.md mục 0/9), nên càng cần compiler bắt
   lỗi hộ nhiều nhất có thể thay vì trông chờ test runtime.

## Khi nào Java vẫn là lựa chọn hợp lý (để công bằng)

- Team/người duy trì code sau này quen Java hơn và không muốn học thêm cú pháp mới.
- Dự án cực nhỏ, ít async, ít null-handling phức tạp - lợi ích của Kotlin không đủ bù thời gian học.
- Cần thời gian build nhanh tuyệt đối (CI chạy hàng trăm lần/ngày) - Java biên dịch nhỉnh hơn về tốc độ.
- Muốn tránh phụ thuộc vào Kotlin stdlib/Kotlin Gradle Plugin (hiếm khi là vấn đề thật với Android
  hiện nay, nhưng về lý thuyết là 1 dependency ngoài Java/Android SDK thuần).

Không điều nào ở trên áp dụng cho dự án này (không có team cố định, lượng async lớn, cần null-safety,
CI chỉ chạy khi cần chứ không hàng trăm lần/ngày).

## Kết luận

Giữ nguyên Kotlin như đã code. Nếu muốn, có thể viết lại 1 module nhỏ bằng Java thuần để so sánh trực
tiếp trên chính dự án này (ví dụ `EbookBuilder` - không phụ thuộc Android framework, dễ tách ra thử
nghiệm nhất) - làm khi được yêu cầu, không phải việc ưu tiên.
