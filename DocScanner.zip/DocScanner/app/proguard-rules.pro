# Add project specific ProGuard rules here.
# minifyEnabled is off by default for this project (see app/build.gradle),
# so these rules only matter if you turn R8/ProGuard shrinking back on.

-keep class org.opencv.** { *; }
-keep class com.google.mlkit.** { *; }
