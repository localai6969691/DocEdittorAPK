package com.example.docscanner

import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.docscanner.adapter.EbookPageAdapter
import com.example.docscanner.adapter.EbookPageData
import com.example.docscanner.databinding.ActivityEbookEditorBinding
import com.example.docscanner.model.EbookEditorState
import com.example.docscanner.model.ScanSessionManager
import com.example.docscanner.util.EbookBuilder
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.OcrHelper
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfImportHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Builds an ebook (EPUB and/or plain text) out of the current scan session, or out of an
 * imported PDF if there is no active session. OCR always runs here regardless of whether the
 * user already ran OCR during a PDF export - an ebook needs the text either way, and re-running
 * per-page OCR is fast enough not to bother caching it across screens (that's also why chapter
 * marks are persisted for crash recovery - see [EbookEditorState] - but the OCR'd text itself is
 * deliberately not, since it's cheap to regenerate on restore).
 */
class EbookExportActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEbookEditorBinding
    private lateinit var adapter: EbookPageAdapter
    private var pagePaths: List<String> = emptyList()

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importPdf(uri) else finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEbookEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        adapter = EbookPageAdapter(onChanged = { persistEditorState() })
        binding.rvEbookPages.layoutManager = LinearLayoutManager(this)
        binding.rvEbookPages.adapter = adapter

        binding.etBookTitle.setText(getString(R.string.ebook_default_title))
        binding.btnExportEbook.setOnClickListener { exportEbook() }

        // Book title / format checkboxes live outside the per-page adapter, so they need their
        // own hooks into the same persistence call the adapter's onChanged uses for chapter marks.
        binding.etBookTitle.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = persistEditorState()
        })
        binding.cbFormatEpub.setOnCheckedChangeListener { _, _ -> persistEditorState() }
        binding.cbFormatTxt.setOnCheckedChangeListener { _, _ -> persistEditorState() }

        if (savedInstanceState == null) {
            if (EbookEditorState.hasSaved()) {
                offerRestore()
            } else {
                startFreshFlow(launchPickerIfNeeded = true)
            }
        } else {
            // Config change (e.g. rotation) mid-flow: the ScanSessionManager branch below safely
            // re-derives itself from the manager either way; not relaunching the picker here
            // (existing behavior, unchanged) avoids firing it a second time on every rotation.
            startFreshFlow(launchPickerIfNeeded = false)
        }
    }

    private fun startFreshFlow(launchPickerIfNeeded: Boolean) {
        if (ScanSessionManager.pages.isNotEmpty()) {
            pagePaths = ScanSessionManager.pages.map { it.filePath }
            runOcrAndShowEditor()
        } else if (launchPickerIfNeeded) {
            pdfPicker.launch(arrayOf("application/pdf"))
        }
    }

    /** If a previous process left an unfinished chapter-marking session on disk (killed by the
     *  OS, crashed, phone restarted...) ask whether to pick it back up - same idea as
     *  MainActivity's scan-session restore prompt and PdfPageEditorActivity's own. "Continue"
     *  re-runs OCR against the same source pages (cheap, see class doc comment) and re-applies
     *  the saved chapter marks + book title/format choices on top once OCR finishes. */
    private fun offerRestore() {
        val count = EbookEditorState.savedPageCount()
        AlertDialog.Builder(this)
            .setTitle(R.string.restore_ebook_title)
            .setMessage(getString(R.string.restore_ebook_message, count))
            .setCancelable(false)
            .setPositiveButton(R.string.restore_ebook_continue) { _, _ ->
                val saved = EbookEditorState.restore()
                if (saved == null) {
                    startFreshFlow(launchPickerIfNeeded = true)
                    return@setPositiveButton
                }
                pagePaths = saved.pages.map { it.path }
                runOcrAndShowEditor()
            }
            .setNegativeButton(R.string.restore_ebook_new) { _, _ ->
                EbookEditorState.clear(this)
                startFreshFlow(launchPickerIfNeeded = true)
            }
            .show()
    }

    private fun importPdf(uri: Uri) {
        setBusy(true, getString(R.string.loading_pdf))
        lifecycleScope.launch {
            pagePaths = withContext(Dispatchers.IO) {
                PdfImportHelper.renderAllPagesToFiles(this@EbookExportActivity, uri, dpi = 200) { i ->
                    FileUtils.newEbookImportFile(this@EbookExportActivity, i)
                }
            }
            if (pagePaths.isEmpty()) {
                Toast.makeText(this@EbookExportActivity, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
                finish()
                return@launch
            }
            runOcrAndShowEditor()
        }
    }

    private fun runOcrAndShowEditor() {
        if (pagePaths.isEmpty()) {
            binding.tvEmptyPages.visibility = View.VISIBLE
            return
        }
        // Save a baseline restore point (default marks, page 1 = chapter start) right away,
        // before the OCR loop below even starts - OCR across many pages can take a while, and
        // without this a process death mid-loop would leave nothing on disk to restore despite
        // the source pages themselves already being safely in durable storage. Cheap to overwrite
        // once real marks exist (see persistEditorState(), called again once OCR finishes).
        EbookEditorState.persist(
            EbookEditorState.SavedState(
                bookTitle = binding.etBookTitle.text?.toString().orEmpty(),
                wantEpub = binding.cbFormatEpub.isChecked,
                wantTxt = binding.cbFormatTxt.isChecked,
                pages = pagePaths.mapIndexed { i, p -> EbookEditorState.SavedPage(p, i == 0, "") }
            )
        )
        setBusy(true, getString(R.string.ebook_ocr_progress, 0, pagePaths.size))
        lifecycleScope.launch {
            val pages = mutableListOf<EbookPageData>()
            pagePaths.forEachIndexed { index, path ->
                binding.tvProgress.text = getString(R.string.ebook_ocr_progress, index + 1, pagePaths.size)
                val paragraphs = withContext(Dispatchers.Default) {
                    val bitmap = android.graphics.BitmapFactory.decodeFile(path)
                    val result = if (bitmap != null) OcrHelper.recognizeBlocks(bitmap) else emptyList()
                    bitmap?.recycle()
                    result
                }
                pages.add(EbookPageData(path = path, paragraphs = paragraphs, isChapterStart = index == 0))
            }
            applySavedMarksIfMatching(pages)
            adapter.submitList(pages)
            setBusy(false, null)
            persistEditorState()
        }
    }

    /** Re-applies chapter marks + book title/format checkboxes from a saved [EbookEditorState]
     *  onto a freshly-OCR'd page list, when the saved state's page paths line up exactly with
     *  what's showing now (same source pages -> the user's earlier manual chapter marking is
     *  still meaningful). If they don't line up, the saved state was for a different set of
     *  pages and is simply left untouched on disk - it'll be overwritten by this session's own
     *  first edit via [persistEditorState] regardless. */
    private fun applySavedMarksIfMatching(pages: MutableList<EbookPageData>) {
        val saved = EbookEditorState.restore() ?: return
        if (saved.pages.map { it.path } != pages.map { it.path }) return
        saved.pages.forEachIndexed { index, sp ->
            pages[index].isChapterStart = sp.isChapterStart
            pages[index].chapterTitle = sp.chapterTitle
        }
        binding.etBookTitle.setText(saved.bookTitle)
        binding.cbFormatEpub.isChecked = saved.wantEpub
        binding.cbFormatTxt.isChecked = saved.wantTxt
    }

    private fun persistEditorState() {
        if (pagePaths.isEmpty()) return
        val pages = adapter.currentList()
        if (pages.isEmpty()) return
        EbookEditorState.persist(
            EbookEditorState.SavedState(
                bookTitle = binding.etBookTitle.text?.toString().orEmpty(),
                wantEpub = binding.cbFormatEpub.isChecked,
                wantTxt = binding.cbFormatTxt.isChecked,
                pages = pages.map { EbookEditorState.SavedPage(it.path, it.isChapterStart, it.chapterTitle) }
            )
        )
    }

    private fun buildChapters(): List<EbookBuilder.Chapter> {
        val pages = adapter.currentList()
        val chapters = mutableListOf<EbookBuilder.Chapter>()
        var currentTitle = ""
        var currentParagraphs = mutableListOf<String>()
        var started = false

        pages.forEachIndexed { index, page ->
            if (page.isChapterStart || !started) {
                if (started) chapters.add(EbookBuilder.Chapter(currentTitle, currentParagraphs))
                currentTitle = page.chapterTitle.ifBlank { "Chương ${chapters.size + 1}" }
                currentParagraphs = mutableListOf()
                started = true
            }
            currentParagraphs.addAll(page.paragraphs)
        }
        if (started) chapters.add(EbookBuilder.Chapter(currentTitle, currentParagraphs))
        return chapters
    }

    private fun exportEbook() {
        val chapters = buildChapters()
        if (chapters.isEmpty()) return
        val wantEpub = binding.cbFormatEpub.isChecked
        val wantTxt = binding.cbFormatTxt.isChecked
        if (!wantEpub && !wantTxt) return

        val bookTitle = binding.etBookTitle.text?.toString()?.ifBlank { null }
            ?: getString(R.string.ebook_default_title)
        val baseName = FileUtils.defaultEbookName()
        val outDir = PdfExporter.exportDir(this)

        setBusy(true, null)
        lifecycleScope.launch {
            val outputs = withContext(Dispatchers.Default) {
                val created = mutableListOf<File>()
                if (wantEpub) {
                    val f = File(outDir, "$baseName.epub")
                    EbookBuilder.buildEpub(f, bookTitle, chapters)
                    created.add(f)
                }
                if (wantTxt) {
                    val f = File(outDir, "$baseName.txt")
                    EbookBuilder.buildTxt(f, bookTitle, chapters)
                    created.add(f)
                }
                created
            }
            setBusy(false, null)
            Toast.makeText(
                this@EbookExportActivity,
                getString(R.string.ebook_export_success, outputs.joinToString(", ") { it.name }),
                Toast.LENGTH_LONG
            ).show()
            EbookEditorState.clear(this@EbookExportActivity)
            finish()
        }
    }

    private fun setBusy(busy: Boolean, message: String?) {
        binding.progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        binding.tvProgress.visibility = if (busy && message != null) View.VISIBLE else View.GONE
        if (message != null) binding.tvProgress.text = message
        binding.btnExportEbook.isEnabled = !busy
    }
}
