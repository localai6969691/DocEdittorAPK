package com.example.docscanner.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.zip.Deflater

/**
 * Builds a compressed, image-based PDF by writing PDF objects directly (see [PdfByteWriter])
 * instead of going through `android.graphics.pdf.PdfDocument`. This is necessary, not just a
 * style choice: PdfDocument draws through Skia's PDF backend, which - per Skia's own source and
 * mailing list - stores whatever raw bitmap it's given losslessly unless the caller plugs in a
 * JPEG encoder through a lower-level Skia API that Android's public PdfDocument does not expose.
 * That means there is no way to get PdfDocument to actually compress page images, which makes it
 * useless for a feature whose entire point is a specific, predictable size reduction.
 *
 * Compression strategy, decided per page with [ImageProcessor.isColorPage]:
 *  - Text pages (the large majority of scanned book pages): binarize to true black/white with the
 *    same adaptive-threshold filter used elsewhere in the app, then compress with one of two fully
 *    lossless methods (user's choice, see [TextCompressionMethod]):
 *      - [TextCompressionMethod.SAFE_DEFLATE]: pack to 1 bit per pixel, compress with plain Deflate
 *        (java.util.zip - already in the JDK, same tool the EPUB writer uses).
 *      - [TextCompressionMethod.CCITT_G4]: the actual codec real scanner hardware/software uses for
 *        bitonal pages ([Ccitt4Encoder]), compressing further than 1-bit+Deflate. Every page is
 *        self-checked with [Ccitt4Decoder] right after encoding - decoded back and compared
 *        pixel-for-pixel against the source - and silently falls back to SAFE_DEFLATE for that one
 *        page if the check fails, so a bug in the from-scratch codec can degrade a page's
 *        compression ratio but can never corrupt the output.
 *    Both are fully lossless either way: the exact black/white pixels survive untouched, so text
 *    edges can never pick up the "ringing" halos a DCT codec like JPEG would cause on sharp edges.
 *  - Color/photo pages: downscaled and JPEG-compressed at a moderate quality, embedded as raw
 *    JPEG bytes (/DCTDecode). Lossy, but only ever applied to pages that actually carry color or
 *    photographic content - never to text.
 */
object PdfCompressor {

    enum class TextCompressionMethod { SAFE_DEFLATE, CCITT_G4 }

    data class CompressResult(val outFile: File, val originalSize: Long, val compressedSize: Long) {
        val ratio: Double get() = if (compressedSize > 0) originalSize.toDouble() / compressedSize else 0.0
    }

    // Matches PdfExporter's ASSUMED_DPI convention so page physical size looks the same either
    // way for a camera-captured page (see that constant's doc comment for the full explanation,
    // including why it's WRONG for a page rendered from an existing PDF at a known DPI - callers
    // with a known DPI should pass it via [compress]'s `assumedDpi` parameter instead).
    private const val ASSUMED_DPI = 150f
    private const val COLOR_PAGE_MAX_EDGE_PX = 1600
    private const val COLOR_PAGE_JPEG_QUALITY = 55

    /**
     * Reads each page image from [pageImagePaths] one at a time (bounded memory regardless of
     * page count), compresses it, and writes the resulting PDF to [outFile]. If [chapterTitles]
     * is non-empty, real PDF bookmarks (the Outline tree) are written directly alongside the page
     * objects, using the exact same [PdfByteWriter] instance and object-numbering scheme - unlike
     * [PdfBookmarkInjector] (written for patching `android.graphics.pdf.PdfDocument`'s output
     * after the fact, since that class exposes no bookmark API), there is no need to reverse-
     * engineer anything here: this function already knows every object number it hands out, so
     * the Catalog can point at `/Outlines` from the very first byte written.
     *
     * [pageDpis], when given, overrides [assumedDpi] per page (`pageDpis[i]` for page `i`, falling
     * back to [assumedDpi] for any index it doesn't cover) - for a source whose pages don't all
     * share one true DPI, e.g. the main "Quét" flow's session pages, which can freely mix
     * camera-captured pages (no true DPI - the [assumedDpi] convention applies) and pages rendered
     * from an imported PDF at a real, different DPI within the SAME session (see
     * [com.example.docscanner.model.ScanPage.sourceDpi]'s doc comment and TECHNICAL_DOCS.md,
     * "ASSUMED_DPI"). Every OTHER existing caller passes nothing here and keeps using one
     * [assumedDpi] for the whole file, unchanged.
     */
    fun compress(
        pageImagePaths: List<String>,
        outFile: File,
        originalSize: Long,
        textMethod: TextCompressionMethod = TextCompressionMethod.SAFE_DEFLATE,
        chapterTitles: List<String> = emptyList(),
        chapterStartPageIndex: List<Int> = emptyList(),
        assumedDpi: Float = ASSUMED_DPI,
        pageDpis: List<Float?>? = null,
        onProgress: (Int, Int) -> Unit = { _, _ -> }
    ): CompressResult {
        val writer = PdfByteWriter()
        val pageCount = pageImagePaths.size

        val pageObjNums = IntArray(pageCount) { 3 + it * 3 }
        val kids = pageObjNums.joinToString(" ") { "$it 0 R" }

        val itemCount = chapterTitles.size
        val hasToc = itemCount > 0
        // Next free object number right after the last page's 3 objects (page/contents/image).
        val outlinesObjNum = 3 + pageCount * 3
        val firstItemObjNum = outlinesObjNum + 1

        val catalogDict = if (hasToc) {
            "<< /Type /Catalog /Pages 2 0 R /Outlines $outlinesObjNum 0 R >>"
        } else {
            "<< /Type /Catalog /Pages 2 0 R >>"
        }
        writer.writeObject(1, catalogDict)
        writer.writeObject(2, "<< /Type /Pages /Kids [$kids] /Count $pageCount >>")

        pageImagePaths.forEachIndexed { index, path ->
            onProgress(index + 1, pageCount)
            val bitmap = BitmapFactory.decodeFile(path) ?: return@forEachIndexed
            val pageObj = 3 + index * 3
            val contentsObj = pageObj + 1
            val imageObj = pageObj + 2

            val widthPt = bitmap.width / (pageDpis?.getOrNull(index) ?: assumedDpi) * 72f
            val heightPt = bitmap.height / (pageDpis?.getOrNull(index) ?: assumedDpi) * 72f

            val (imageDict, imageBytes) = if (ImageProcessor.isColorPage(bitmap)) {
                buildColorImage(bitmap)
            } else {
                buildTextImage(bitmap, textMethod)
            }

            writer.writeObject(
                pageObj,
                "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${fmt(widthPt)} ${fmt(heightPt)}] " +
                    "/Resources << /XObject << /Im0 $imageObj 0 R >> >> /Contents $contentsObj 0 R >>"
            )

            val content = "q\n${fmt(widthPt)} 0 0 ${fmt(heightPt)} 0 0 cm\n/Im0 Do\nQ\n"
                .toByteArray(Charsets.ISO_8859_1)
            writer.writeStreamObject(contentsObj, "<< /Length ${content.size} >>", content)

            writer.writeStreamObject(imageObj, imageDict, imageBytes)
            bitmap.recycle()
        }

        if (hasToc) {
            writer.writeObject(
                outlinesObjNum,
                "<< /Type /Outlines /First $firstItemObjNum 0 R " +
                    "/Last ${firstItemObjNum + itemCount - 1} 0 R /Count $itemCount >>"
            )
            for (i in 0 until itemCount) {
                val itemObjNum = firstItemObjNum + i
                val pageIdx = chapterStartPageIndex.getOrElse(i) { 0 }.coerceIn(0, pageCount - 1)
                val destPageObj = pageObjNums[pageIdx]
                val titleHex = toPdfUtf16HexString(chapterTitles[i])
                val prevRef = if (i > 0) "/Prev ${itemObjNum - 1} 0 R " else ""
                val nextRef = if (i < itemCount - 1) "/Next ${itemObjNum + 1} 0 R " else ""
                writer.writeObject(
                    itemObjNum,
                    "<< /Title $titleHex /Parent $outlinesObjNum 0 R $prevRef$nextRef" +
                        "/Dest [$destPageObj 0 R /Fit] >>"
                )
            }
        }

        val fileBytes = writer.finish(catalogObjNum = 1)
        FileOutputStream(outFile).use { it.write(fileBytes) }
        return CompressResult(outFile, originalSize, outFile.length())
    }

    /** Same UTF-16BE-with-BOM hex-string encoding [PdfBookmarkInjector] uses for bookmark titles -
     *  duplicated rather than shared (that object is `internal` plumbing tied to its own byte-
     *  patching approach) since it's a single small pure function. */
    private fun toPdfUtf16HexString(s: String): String {
        val sb = StringBuilder("<FEFF")
        for (ch in s) sb.append(String.format(Locale.US, "%04X", ch.code))
        sb.append(">")
        return sb.toString()
    }

    private fun buildTextImage(bitmap: Bitmap, method: TextCompressionMethod): Pair<String, ByteArray> {
        val bw = ImageProcessor.applyFilter(bitmap, ImageProcessor.ScanFilter.BW)

        if (method == TextCompressionMethod.CCITT_G4) {
            val g4Bytes = Ccitt4Encoder.encode(bw)
            if (Ccitt4Decoder.verify(g4Bytes, bw)) {
                val dict = "<< /Type /XObject /Subtype /Image /Width ${bw.width} /Height ${bw.height} " +
                    "/ColorSpace /DeviceGray /BitsPerComponent 1 /Filter /CCITTFaxDecode " +
                    "/DecodeParms << /K -1 /Columns ${bw.width} /Rows ${bw.height} /BlackIs1 false " +
                    "/EndOfBlock false >> /Length ${g4Bytes.size} >>"
                if (bw !== bitmap) bw.recycle()
                return dict to g4Bytes
            }
            // Self-check failed (should not happen - see Ccitt4Encoder's doc comment - but this
            // page still gets a correct, if less compact, result instead of a corrupt image).
        }

        val packed = packBilevel(bw)
        val compressed = deflate(packed)
        val dict = "<< /Type /XObject /Subtype /Image /Width ${bw.width} /Height ${bw.height} " +
            "/ColorSpace /DeviceGray /BitsPerComponent 1 /Filter /FlateDecode /Length ${compressed.size} >>"
        if (bw !== bitmap) bw.recycle()
        return dict to compressed
    }

    private fun buildColorImage(bitmap: Bitmap): Pair<String, ByteArray> {
        val downscaled = ImageProcessor.downscaleTo(bitmap, COLOR_PAGE_MAX_EDGE_PX)
        val jpegBytes = ByteArrayOutputStream().also {
            downscaled.compress(Bitmap.CompressFormat.JPEG, COLOR_PAGE_JPEG_QUALITY, it)
        }.toByteArray()
        val dict = "<< /Type /XObject /Subtype /Image /Width ${downscaled.width} /Height ${downscaled.height} " +
            "/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpegBytes.size} >>"
        if (downscaled !== bitmap) downscaled.recycle()
        return dict to jpegBytes
    }

    /** Packs a black/white bitmap into 1 bit per pixel, MSB first, matching PDF's default
     *  DeviceGray Decode array (sample 0 = black, sample 1 = white) so no /Decode override is needed. */
    private fun packBilevel(bitmap: Bitmap): ByteArray {
        val w = bitmap.width
        val h = bitmap.height
        val rowBytes = (w + 7) / 8
        val out = ByteArray(rowBytes * h)
        val row = IntArray(w)
        for (y in 0 until h) {
            bitmap.getPixels(row, 0, w, 0, y, w, 1)
            var bitBuffer = 0
            var bitCount = 0
            var byteIndex = y * rowBytes
            for (x in 0 until w) {
                val p = row[x]
                val gray = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3
                val bit = if (gray >= 128) 1 else 0
                bitBuffer = (bitBuffer shl 1) or bit
                bitCount++
                if (bitCount == 8) {
                    out[byteIndex++] = bitBuffer.toByte()
                    bitBuffer = 0
                    bitCount = 0
                }
            }
            if (bitCount > 0) {
                out[byteIndex] = (bitBuffer shl (8 - bitCount)).toByte()
            }
        }
        return out
    }

    /** Raw zlib/Deflate stream (RFC 1950 - header + compressed data + Adler32), exactly what
     *  PDF's /FlateDecode filter expects. Deflater's default (nowrap = false) already produces this. */
    private fun deflate(data: ByteArray): ByteArray {
        val deflater = Deflater(Deflater.BEST_COMPRESSION)
        deflater.setInput(data)
        deflater.finish()
        val chunk = ByteArray(8192)
        val out = ByteArrayOutputStream()
        while (!deflater.finished()) {
            val n = deflater.deflate(chunk)
            out.write(chunk, 0, n)
        }
        deflater.end()
        return out.toByteArray()
    }

    private fun fmt(v: Float): String {
        val i = v.toInt()
        return if (v == i.toFloat()) i.toString() else String.format(Locale.US, "%.2f", v)
    }
}
