package com.example.docscanner.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream

/**
 * Reads pages out of an existing PDF using Android's built-in [PdfRenderer] - no third-party
 * PDF library needed. Pages are rasterized to bitmaps; this means any real selectable text in
 * the source PDF becomes a flat image once it passes through here (the OCR tool can be used
 * afterwards to get text back out as plain text, but it won't restore a searchable PDF).
 */
object PdfImportHelper {

    private fun openRenderer(context: Context, uri: Uri): Pair<ParcelFileDescriptor, PdfRenderer>? {
        return try {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return null
            pfd to PdfRenderer(pfd)
        } catch (e: Exception) {
            null
        }
    }

    fun getPageCount(context: Context, uri: Uri): Int {
        val opened = openRenderer(context, uri) ?: return 0
        val (pfd, renderer) = opened
        val count = renderer.pageCount
        renderer.close()
        pfd.close()
        return count
    }

    private fun renderPage(renderer: PdfRenderer, index: Int, dpi: Int): Bitmap {
        val page = renderer.openPage(index)
        val scale = dpi / 72f
        val width = (page.width * scale).toInt().coerceAtLeast(1)
        val height = (page.height * scale).toInt().coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        Canvas(bitmap).drawColor(Color.WHITE)
        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        page.close()
        return bitmap
    }

    /**
     * Renders every page of the PDF at [uri] to a JPEG file and returns their paths, in order.
     * By default each file lands in [FileUtils.importedDir] (transient cache - fine for the
     * usual "import then immediately process/export" callers). Pass [fileFactory] to redirect
     * output elsewhere - e.g. a *durable* files-storage dir - for a flow whose in-progress state
     * needs to survive process death (see `PdfPageEditorActivity`/`EbookExportActivity`, which
     * pass [FileUtils.newPdfEditorPageFile]/[FileUtils.newEbookImportFile] respectively).
     */
    fun renderAllPagesToFiles(
        context: Context,
        uri: Uri,
        dpi: Int = 200,
        fileFactory: ((Int) -> File)? = null
    ): List<String> {
        val opened = openRenderer(context, uri) ?: return emptyList()
        val (pfd, renderer) = opened
        val paths = mutableListOf<String>()
        try {
            for (i in 0 until renderer.pageCount) {
                val bitmap = renderPage(renderer, i, dpi)
                val file = fileFactory?.invoke(i) ?: FileUtils.newImportedFile(context, i)
                FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out) }
                bitmap.recycle()
                paths.add(file.absolutePath)
            }
        } finally {
            renderer.close()
            pfd.close()
        }
        return paths
    }

    fun displayName(context: Context, uri: Uri): String {
        var name = "document.pdf"
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && it.moveToFirst()) {
                name = it.getString(idx) ?: name
            }
        }
        return name
    }

    /** Size in bytes of the document at [uri], or 0 if it can't be determined. */
    fun fileSize(context: Context, uri: Uri): Long {
        var size = 0L
        val cursor = context.contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val idx = it.getColumnIndex(OpenableColumns.SIZE)
            if (idx >= 0 && it.moveToFirst() && !it.isNull(idx)) {
                size = it.getLong(idx)
            }
        }
        return size
    }
}
