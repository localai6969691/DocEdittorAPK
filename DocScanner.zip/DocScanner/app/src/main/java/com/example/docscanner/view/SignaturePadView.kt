package com.example.docscanner.view

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * A pad to draw a handwritten signature with a finger or stylus. Strokes are kept as point lists in VIEW space;
 * [toBitmap] cuts the result tight around the ink (plus a small margin) onto a TRANSPARENT background, so the
 * signature can be laid over a page without a white box around it.
 *
 * Smoothing: consecutive points are joined with quadratic curves through their midpoints (the usual cheap way to
 * turn a jittery touch trail into a pen-like line); a stroke of a single tap is drawn as a dot.
 */
class SignaturePadView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val strokes = mutableListOf<MutableList<PointF>>()
    private var active: MutableList<PointF>? = null
    private val strokeWidthPx = 4f * resources.displayMetrics.density

    private val inkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = INK
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = INK
        style = Paint.Style.FILL
    }
    private val guidePaint = Paint().apply {
        color = Color.argb(60, 0, 0, 0)
        strokeWidth = resources.displayMetrics.density
    }

    fun isEmpty(): Boolean = strokes.none { it.isNotEmpty() }

    fun clear() {
        strokes.clear()
        active = null
        invalidate()
    }

    fun undoStroke() {
        if (strokes.isNotEmpty()) strokes.removeAt(strokes.size - 1)
        invalidate()
    }

    private fun pathOf(points: List<PointF>, scale: Float, dx: Float, dy: Float): Path {
        val path = Path()
        path.moveTo((points[0].x + dx) * scale, (points[0].y + dy) * scale)
        for (i in 1 until points.size) {
            val prev = points[i - 1]
            val cur = points[i]
            val midX = (prev.x + cur.x) / 2f
            val midY = (prev.y + cur.y) / 2f
            path.quadTo((prev.x + dx) * scale, (prev.y + dy) * scale, (midX + dx) * scale, (midY + dy) * scale)
        }
        val last = points.last()
        path.lineTo((last.x + dx) * scale, (last.y + dy) * scale)
        return path
    }

    private fun drawStrokes(canvas: Canvas, scale: Float, dx: Float, dy: Float) {
        inkPaint.strokeWidth = strokeWidthPx * scale
        for (s in strokes + listOfNotNull(active)) {
            if (s.isEmpty()) continue
            if (s.size == 1) {
                canvas.drawCircle((s[0].x + dx) * scale, (s[0].y + dy) * scale, strokeWidthPx * scale / 2f, dotPaint)
            } else {
                canvas.drawPath(pathOf(s, scale, dx, dy), inkPaint)
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val y = height * 0.72f
        canvas.drawLine(width * 0.06f, y, width * 0.94f, y, guidePaint)
        drawStrokes(canvas, 1f, 0f, 0f)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                active = mutableListOf(PointF(event.x, event.y))
            }
            MotionEvent.ACTION_MOVE -> {
                val a = active ?: return true
                for (i in 0 until event.historySize) a.add(PointF(event.getHistoricalX(i), event.getHistoricalY(i)))
                a.add(PointF(event.x, event.y))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                active?.let { strokes.add(it) }
                active = null
            }
            else -> return super.onTouchEvent(event)
        }
        invalidate()
        return true
    }

    /** The signature cut tight around its ink, transparent background, about [targetWidth] px wide; null if empty. */
    fun toBitmap(targetWidth: Int = 900): Bitmap? {
        val all = strokes.flatten()
        if (all.isEmpty()) return null
        var minX = all[0].x; var maxX = all[0].x; var minY = all[0].y; var maxY = all[0].y
        for (p in all) {
            minX = min(minX, p.x); maxX = max(maxX, p.x)
            minY = min(minY, p.y); maxY = max(maxY, p.y)
        }
        val pad = strokeWidthPx * 2f
        val boxW = max(maxX - minX, 1f) + 2 * pad
        val boxH = max(maxY - minY, 1f) + 2 * pad
        val scale = (targetWidth / boxW).coerceIn(0.5f, 3f)
        val bmp = Bitmap.createBitmap((boxW * scale).toInt().coerceAtLeast(2), (boxH * scale).toInt().coerceAtLeast(2), Bitmap.Config.ARGB_8888)
        drawStrokes(Canvas(bmp), scale, pad - minX, pad - minY)
        return bmp
    }

    companion object {
        /** Dark blue: reads as "signed in ink" and still prints well in black and white. */
        val INK: Int = Color.rgb(13, 27, 107)
    }
}
