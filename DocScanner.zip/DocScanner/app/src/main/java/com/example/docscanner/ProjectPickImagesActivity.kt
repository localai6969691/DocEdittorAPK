package com.example.docscanner

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityProjectPickImagesBinding
import com.example.docscanner.model.Project
import com.example.docscanner.model.ProjectManager
import com.example.docscanner.model.ProjectStage
import com.example.docscanner.util.FileUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileOutputStream

/**
 * Project stage 1: pick images, from the camera or the gallery (multi-select) - exactly the 2
 * sources this workflow calls for. [CaptureActivity] is reused in "project mode" (see its own doc
 * comment) rather than duplicating a whole CameraX screen here; the gallery path is simple enough
 * to keep local to this Activity, same shape as `MainActivity.importGalleryImages` but copying
 * into this project's own raw dir instead of the shared cache.
 */
class ProjectPickImagesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProjectPickImagesBinding
    private lateinit var project: Project

    private val cameraLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            reloadAndRefresh()
        }

    private val galleryPicker =
        registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(20)) { uris ->
            if (uris.isNotEmpty()) importGalleryImages(uris)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProjectPickImagesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val projectId = intent.getStringExtra(ProjectFlow.EXTRA_PROJECT_ID)
        val loaded = projectId?.let { ProjectManager.load(this, it) }
        if (loaded == null) {
            finish()
            return
        }
        project = loaded
        title = project.name
        binding.tvStageIndicator.text = getString(R.string.project_stage_indicator_1)

        binding.cardPickCamera.setOnClickListener {
            cameraLauncher.launch(
                Intent(this, CaptureActivity::class.java).putExtra(ProjectFlow.EXTRA_PROJECT_ID, project.id)
            )
        }
        binding.cardPickGallery.setOnClickListener {
            galleryPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        binding.btnContinue.setOnClickListener { advance() }

        refreshCount()
    }

    override fun onResume() {
        super.onResume()
        reloadAndRefresh()
    }

    private fun reloadAndRefresh() {
        val reloaded = ProjectManager.load(this, project.id) ?: return
        project = reloaded
        refreshCount()
    }

    private fun refreshCount() {
        val count = project.pendingRawPaths.size
        binding.tvPickedCount.text = getString(R.string.project_picked_count, count)
        binding.btnContinue.isEnabled = count > 0
    }

    private fun importGalleryImages(uris: List<Uri>) {
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val startIndex = project.pendingRawPaths.size
            val newPaths = withContext(Dispatchers.IO) {
                uris.mapIndexedNotNull { i, uri -> copyUriToProjectRaw(uri, startIndex + i) }
            }
            project.pendingRawPaths.addAll(newPaths)
            ProjectManager.save(this@ProjectPickImagesActivity, project)
            binding.progressBar.visibility = View.GONE
            refreshCount()
        }
    }

    private fun copyUriToProjectRaw(uri: Uri, index: Int): String? {
        return try {
            val file = FileUtils.newProjectRawFile(this, project.id, index)
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            } ?: return null
            file.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    private fun advance() {
        if (project.pendingRawPaths.isEmpty()) return
        project.stage = ProjectStage.EDIT_IMAGES
        ProjectManager.save(this, project)
        ProjectFlow.open(this, project)
        finish()
    }
}
