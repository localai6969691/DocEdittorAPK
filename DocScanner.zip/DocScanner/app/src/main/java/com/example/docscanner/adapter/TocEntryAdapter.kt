package com.example.docscanner.adapter

import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.databinding.ItemTocEntryBinding
import com.example.docscanner.model.ProjectTocEntry

/**
 * Editable list of [ProjectTocEntry] for the "Xuất PDF" stage's table-of-contents review screen
 * (see `ProjectExportPdfActivity` and `TocDetector`). Same detach-before-rebind pattern as
 * [EbookPageAdapter] for the title [TextWatcher] - RecyclerView reuses views, so a stale listener
 * left attached would otherwise write into whichever entry happens to scroll into that slot.
 */
class TocEntryAdapter(
    private val pageCount: Int,
    private val onChanged: () -> Unit,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<TocEntryAdapter.ViewHolder>() {

    private val items = mutableListOf<ProjectTocEntry>()

    fun submitList(entries: List<ProjectTocEntry>) {
        items.clear()
        items.addAll(entries)
        notifyDataSetChanged()
    }

    fun currentList(): List<ProjectTocEntry> = items

    inner class ViewHolder(val binding: ItemTocEntryBinding) : RecyclerView.ViewHolder(binding.root) {
        var textWatcher: TextWatcher? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemTocEntryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val entry = items[position]

        holder.textWatcher?.let { holder.binding.etTocTitle.removeTextChangedListener(it) }
        holder.binding.etTocTitle.setText(entry.title)
        holder.binding.tvTocPageNumber.text = (entry.pageIndex + 1).toString()

        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val pos = holder.bindingAdapterPosition
                if (pos == RecyclerView.NO_POSITION) return
                items[pos].title = s?.toString().orEmpty()
                onChanged()
            }
        }
        holder.textWatcher = watcher
        holder.binding.etTocTitle.addTextChangedListener(watcher)

        holder.binding.btnTocPageMinus.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos == RecyclerView.NO_POSITION) return@setOnClickListener
            val item = items[pos]
            if (item.pageIndex > 0) {
                item.pageIndex -= 1
                notifyItemChanged(pos)
                onChanged()
            }
        }
        holder.binding.btnTocPagePlus.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos == RecyclerView.NO_POSITION) return@setOnClickListener
            val item = items[pos]
            if (item.pageIndex < pageCount - 1) {
                item.pageIndex += 1
                notifyItemChanged(pos)
                onChanged()
            }
        }
        holder.binding.btnTocDelete.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos == RecyclerView.NO_POSITION) return@setOnClickListener
            items.removeAt(pos)
            notifyItemRemoved(pos)
            onDelete(pos)
            onChanged()
        }
    }

    override fun getItemCount(): Int = items.size
}
