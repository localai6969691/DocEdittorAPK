package com.example.docscanner.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Draws office-style stamps ("ĐÃ DUYỆT", "BẢN SAO", a date) as transparent bitmaps: a rounded frame around bold
 * text in one colour. They go onto a page through [PdfStamper] exactly like a signature does. Android's own text
 * engine draws them, so Vietnamese diacritics need no PDF font.
 */
object StampRenderer {

    val RED: Int = Color.rgb(198, 40, 40)
    val BLUE: Int = Color.rgb(21, 101, 192)
    val GREEN: Int = Color.rgb(46, 125, 50)

    /** A framed text stamp, about 600-1200 px wide depending on the text. */
    fun textStamp(text: String, color: Int): Bitmap {
        val lines = text.trim().lines().filter { it.isNotBlank() }.ifEmpty { listOf(" ") }
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = 110f
        }
        val widest = lines.maxOf { paint.measureText(it) }
        // keep very long text from producing a huge bitmap: shrink the type, not the frame ratio
        if (widest > 1400f) paint.textSize = paint.textSize * 1400f / widest
        val fm = paint.fontMetrics
        val lineH = fm.descent - fm.ascent
        val textW = lines.maxOf { paint.measureText(it) }
        val padX = 40f
        val padY = 26f
        val frame = 10f
        val w = (textW + 2 * (padX + frame)).toInt().coerceAtLeast(40)
        val h = (lineH * lines.size + 2 * (padY + frame)).toInt().coerceAtLeast(40)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color
            style = Paint.Style.STROKE
            strokeWidth = frame
        }
        c.drawRoundRect(RectF(frame / 2, frame / 2, w - frame / 2, h - frame / 2), 28f, 28f, border)
        var y = frame + padY - fm.ascent
        for (line in lines) {
            val x = (w - paint.measureText(line)) / 2f
            c.drawText(line, x, y, paint)
            y += lineH
        }
        return bmp
    }

    /** "dd/MM/yyyy" for today, framed. */
    fun dateStamp(color: Int = BLUE, now: Date = Date()): Bitmap =
        textStamp(SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(now), color)
}
