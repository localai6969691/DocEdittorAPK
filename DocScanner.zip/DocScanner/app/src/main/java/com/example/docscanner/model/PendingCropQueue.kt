package com.example.docscanner.model

/**
 * Shared queue used when several images need to go through the crop/filter
 * screen one after another without user interaction in between calls
 * (multi-picked gallery photos, or pages rendered from an imported PDF).
 * CropActivity polls this after saving each page; when it is empty the
 * activity moves on to the page list instead of loading another image.
 *
 * [sourceDpi]: the known render DPI shared by every image in the current batch, or `null` when
 * there isn't one (gallery photos - same convention as a camera capture). One batch always comes
 * from a single source (all gallery picks, or every page of one imported PDF), so a single value
 * for the whole queue is enough - no need to track it per path. `CropActivity` reads this once
 * when it starts processing a queue and carries it through every page it saves from that queue,
 * including both halves of a split page (see TECHNICAL_DOCS.md, section 6/7, "ASSUMED_DPI").
 */
object PendingCropQueue {

    private val queue = ArrayDeque<String>()
    var sourceDpi: Float? = null
        private set

    fun setAll(paths: List<String>, sourceDpi: Float? = null) {
        queue.clear()
        queue.addAll(paths)
        this.sourceDpi = sourceDpi
    }

    /** Inserts [path] at the very front - used when a photo gets split into 2 pages: the 2nd
     *  half should be processed right after the 1st, ahead of anything already queued. */
    fun pushFront(path: String) {
        queue.addFirst(path)
    }

    fun pollNext(): String? = if (queue.isEmpty()) null else queue.removeFirst()

    fun hasNext(): Boolean = queue.isNotEmpty()

    fun remainingCount(): Int = queue.size

    fun clear() {
        queue.clear()
        sourceDpi = null
    }
}
