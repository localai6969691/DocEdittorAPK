package com.example.docscanner.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.R
import com.example.docscanner.databinding.ItemHistoryBinding
import com.example.docscanner.model.Project
import com.example.docscanner.model.ProjectStage
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Project hub list row. Reuses `item_history.xml` / [ItemHistoryBinding] (icon + title + meta
 * line + delete button is exactly what a project row needs too) instead of adding an almost
 * identical new layout - the share button just isn't a meaningful action for a project-in-
 * progress row, so it's hidden.
 */
class ProjectAdapter(
    private val onClick: (Project) -> Unit,
    private val onDelete: (Project) -> Unit
) : RecyclerView.Adapter<ProjectAdapter.ViewHolder>() {

    private val items = mutableListOf<Project>()

    fun submitList(projects: List<Project>) {
        items.clear()
        items.addAll(projects)
        notifyDataSetChanged()
    }

    inner class ViewHolder(val binding: ItemHistoryBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val project = items[position]
        val context = holder.binding.root.context
        holder.binding.tvFileName.text = project.name
        val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(project.updatedAt))
        holder.binding.tvFileMeta.text = "${stageLabel(context, project.stage)}  •  $dateStr"
        holder.binding.ivFileIcon.setImageResource(R.drawable.ic_flow)
        holder.binding.btnShare.visibility = View.GONE
        holder.binding.root.setOnClickListener { onClick(project) }
        holder.binding.btnDelete.setOnClickListener { onDelete(project) }
    }

    override fun getItemCount(): Int = items.size

    private fun stageLabel(context: Context, stage: ProjectStage): String {
        val resId = when (stage) {
            ProjectStage.PICK_IMAGES -> R.string.project_stage_pick_images
            ProjectStage.EDIT_IMAGES -> R.string.project_stage_edit_images
            ProjectStage.SCAN -> R.string.project_stage_scan
            ProjectStage.EXPORT_PDF -> R.string.project_stage_export_pdf
            ProjectStage.COMPRESS -> R.string.project_stage_compress
            ProjectStage.OCR -> R.string.project_stage_ocr
            ProjectStage.EBOOK -> R.string.project_stage_ebook
            ProjectStage.DONE -> R.string.project_stage_done
        }
        return context.getString(resId)
    }
}
