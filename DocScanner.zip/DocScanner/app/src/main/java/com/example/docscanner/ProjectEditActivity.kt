package com.example.docscanner

import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityProjectEditBinding
import com.example.docscanner.model.Project
import com.example.docscanner.model.ProjectManager
import com.example.docscanner.model.ProjectPage
import com.example.docscanner.model.ProjectStage
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.ImageProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileOutputStream

/**
 * Project stage 2: crop (auto-detected corners the user can drag to fix) and optional split (for
 * a 2-page book-spread photo), one raw image at a time, draining [Project.pendingRawPaths] into
 * [Project.pages]. Same crop/split UX and heuristics as the standalone `CropActivity` - same
 * corner auto-detection, same gutter-line auto-suggestion, same [com.example.docscanner.view]
 * overlay widgets - deliberately WITHOUT that screen's filter-chip step: which of the 7 scan
 * presets to apply is the next, separate mandatory stage in a project (`ProjectScanActivity`), not
 * decided per-photo here.
 *
 * The current item is popped off [Project.pendingRawPaths] (and saved) the moment it starts
 * loading, not when it's confirmed - so a split's second half can be pushed back to the front
 * without the original, now-consumed photo still sitting in the list too.
 */
class ProjectEditActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProjectEditBinding
    private lateinit var project: Project
    private var sourceBitmap: Bitmap? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProjectEditBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val projectId = intent.getStringExtra(ProjectFlow.EXTRA_PROJECT_ID)
        val loaded = projectId?.let { ProjectManager.load(this, it) }
        if (loaded == null) {
            finish()
            return
        }
        project = loaded
        title = project.name

        binding.btnSkipPage.setOnClickListener { loadNext() }
        binding.btnConfirmCrop.setOnClickListener { confirmCrop() }
        binding.btnSplitPages.setOnClickListener { showSplitStage() }
        binding.btnCancelSplit.setOnClickListener { showCropStage() }
        binding.btnConfirmSplit.setOnClickListener { confirmSplit() }

        loadNext()
    }

    private fun loadNext() {
        if (project.pendingRawPaths.isEmpty()) {
            advance()
            return
        }
        val path = project.pendingRawPaths.removeAt(0)
        ProjectManager.save(this, project)
        binding.tvStageIndicator.text = getString(
            R.string.project_edit_indicator,
            project.pages.size + 1,
            project.pages.size + project.pendingRawPaths.size + 1
        )
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.Default) { FileUtils.decodeBitmapWithExifOrientation(path) }
            if (bmp == null) {
                // Corrupt/unreadable file - already popped, just move on rather than getting stuck.
                loadNext()
                return@launch
            }
            proceedWithBitmap(bmp)
        }
    }

    private suspend fun proceedWithBitmap(bmp: Bitmap) {
        sourceBitmap = bmp
        val detected = withContext(Dispatchers.Default) {
            ImageProcessor.detectDocumentCorners(bmp)
        } ?: ImageProcessor.defaultCorners(bmp.width, bmp.height)
        binding.cropOverlayView.setImage(bmp, detected)
        binding.progressBar.visibility = View.GONE
        showCropStage()
    }

    private fun showCropStage() {
        binding.cropOverlayView.visibility = View.VISIBLE
        binding.bottomBar1.visibility = View.VISIBLE
        binding.splitLineOverlayView.visibility = View.GONE
        binding.bottomBarSplit.visibility = View.GONE
    }

    private fun showSplitStage() {
        val bmp = sourceBitmap ?: return
        binding.cropOverlayView.visibility = View.GONE
        binding.bottomBar1.visibility = View.GONE
        binding.splitLineOverlayView.visibility = View.VISIBLE
        binding.bottomBarSplit.visibility = View.VISIBLE
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val gutterX = withContext(Dispatchers.Default) { ImageProcessor.detectGutterX(bmp) }
            binding.splitLineOverlayView.setImage(bmp, gutterX)
            binding.progressBar.visibility = View.GONE
        }
    }

    private fun confirmSplit() {
        val source = sourceBitmap ?: return
        val splitX = binding.splitLineOverlayView.getSplitX().toInt().coerceIn(1, source.width - 1)
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val result = withContext(Dispatchers.Default) {
                val left = Bitmap.createBitmap(source, 0, 0, splitX, source.height)
                val right = Bitmap.createBitmap(source, splitX, 0, source.width - splitX, source.height)
                val rightFile = FileUtils.newProjectRawFile(this@ProjectEditActivity, project.id, 0)
                FileOutputStream(rightFile).use { out -> right.compress(Bitmap.CompressFormat.JPEG, 95, out) }
                right.recycle()
                left to rightFile.absolutePath
            }
            val (leftBitmap, rightPath) = result
            // Right half goes back in at the FRONT so it's cropped right after the left half,
            // the same order a reader would naturally encounter the 2 pages.
            project.pendingRawPaths.add(0, rightPath)
            ProjectManager.save(this@ProjectEditActivity, project)
            proceedWithBitmap(leftBitmap)
        }
    }

    private fun confirmCrop() {
        val bmp = sourceBitmap ?: return
        val quad = binding.cropOverlayView.getResultQuad()
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val outFile = withContext(Dispatchers.Default) {
                val warped = ImageProcessor.warpDocument(bmp, quad)
                val file = FileUtils.newProjectPageFile(this@ProjectEditActivity, project.id, project.pages.size)
                FileOutputStream(file).use { out -> warped.compress(Bitmap.CompressFormat.JPEG, 92, out) }
                warped.recycle()
                file
            }
            project.pages.add(ProjectPage(outFile.absolutePath))
            ProjectManager.save(this@ProjectEditActivity, project)
            binding.progressBar.visibility = View.GONE
            loadNext()
        }
    }

    private fun advance() {
        project.stage = ProjectStage.SCAN
        ProjectManager.save(this, project)
        ProjectFlow.open(this, project)
        finish()
    }
}
