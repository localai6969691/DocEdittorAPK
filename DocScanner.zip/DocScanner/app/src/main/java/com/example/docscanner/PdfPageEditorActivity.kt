package com.example.docscanner

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.adapter.PdfPageAdapter
import com.example.docscanner.adapter.PdfPageItem
import com.example.docscanner.databinding.ActivityPdfPageEditorBinding
import com.example.docscanner.model.PdfEditorState
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfImportHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PdfPageEditorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPdfPageEditorBinding
    private lateinit var adapter: PdfPageAdapter
    private val pages = mutableListOf<PdfPageItem>()
    private var hasLoadedOnce = false

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            loadPdf(uri)
        } else if (pages.isEmpty()) {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfPageEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.tool_pagemanager_title)

        adapter = PdfPageAdapter(
            onDelete = { position ->
                pages.removeAt(position)
                refreshList()
                persistEditorState()
            },
            onRotate = { position ->
                pages[position].rotationDeg = (pages[position].rotationDeg + 90) % 360
                adapter.submitList(pages)
                persistEditorState()
            },
            onToggleSelect = { position ->
                pages[position].selected = !pages[position].selected
                adapter.submitList(pages)
                persistEditorState()
            }
        )
        binding.rvPdfPages.layoutManager = GridLayoutManager(this, 2)
        binding.rvPdfPages.adapter = adapter

        val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = viewHolder.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
                val item = pages.removeAt(from)
                pages.add(to, item)
                adapter.moveItem(from, to)
                persistEditorState()
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}
        })
        touchHelper.attachToRecyclerView(binding.rvPdfPages)

        binding.btnExportPdf.setOnClickListener { export(asImages = false) }
        binding.btnExportImages.setOnClickListener { export(asImages = true) }

        if (savedInstanceState == null) {
            if (PdfEditorState.hasSaved()) {
                offerRestore()
            } else {
                pdfPicker.launch(arrayOf("application/pdf"))
            }
        }
    }

    /** If a previous process left an unfinished page-editor session on disk (killed by the OS,
     *  crashed, phone restarted...) ask whether to pick it back up instead of silently losing
     *  the rotate/delete/reorder work - same idea as MainActivity's scan-session restore prompt. */
    private fun offerRestore() {
        val count = PdfEditorState.savedPageCount()
        AlertDialog.Builder(this)
            .setTitle(R.string.restore_pageeditor_title)
            .setMessage(getString(R.string.restore_pageeditor_message, count))
            .setCancelable(false)
            .setPositiveButton(R.string.restore_pageeditor_continue) { _, _ ->
                val saved = PdfEditorState.restore()
                if (saved.isEmpty()) {
                    pdfPicker.launch(arrayOf("application/pdf"))
                    return@setPositiveButton
                }
                pages.clear()
                pages.addAll(saved.map { PdfPageItem(it.path, it.rotationDeg, it.selected) })
                hasLoadedOnce = true
                refreshList()
            }
            .setNegativeButton(R.string.restore_pageeditor_new) { _, _ ->
                PdfEditorState.clear()
                pdfPicker.launch(arrayOf("application/pdf"))
            }
            .show()
    }

    private fun persistEditorState() {
        PdfEditorState.persist(pages.map { PdfEditorState.SavedPage(it.path, it.rotationDeg, it.selected) })
    }

    private fun loadPdf(uri: Uri) {
        setBusy(true, getString(R.string.loading_pdf))
        lifecycleScope.launch {
            val paths = withContext(Dispatchers.IO) {
                PdfImportHelper.renderAllPagesToFiles(this@PdfPageEditorActivity, uri, dpi = 200) { i ->
                    FileUtils.newPdfEditorPageFile(this@PdfPageEditorActivity, i)
                }
            }
            hasLoadedOnce = true
            setBusy(false)
            if (paths.isEmpty()) {
                Toast.makeText(
                    this@PdfPageEditorActivity,
                    getString(R.string.export_failed, ""),
                    Toast.LENGTH_SHORT
                ).show()
                finish()
                return@launch
            }
            pages.clear()
            pages.addAll(paths.map { PdfPageItem(it) })
            refreshList()
            persistEditorState()
        }
    }

    private fun refreshList() {
        adapter.submitList(pages)
        title = getString(R.string.page_manager_title, pages.size)
        binding.tvEmptyPages.visibility = if (pages.isEmpty() && hasLoadedOnce) View.VISIBLE else View.GONE
    }

    private fun selectionOrAll(): List<PdfPageItem> {
        val selected = pages.filter { it.selected }
        return selected.ifEmpty { pages }
    }

    private fun export(asImages: Boolean) {
        if (pages.isEmpty()) return
        val chosen = selectionOrAll()
        val paths = chosen.map { it.path }
        val rotations = chosen.map { it.rotationDeg }
        setBusy(true, null)
        lifecycleScope.launch {
            try {
                if (asImages) {
                    val files = withContext(Dispatchers.Default) {
                        PdfExporter.exportAsImages(this@PdfPageEditorActivity, paths, rotations)
                    }
                    setBusy(false)
                    Toast.makeText(
                        this@PdfPageEditorActivity,
                        getString(R.string.export_images_success, files.size),
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    // Pages here always came from rendering a picked PDF at 200dpi (loadPdf() above) -
                    // never a camera capture - so the exported page must keep that real DPI to come
                    // out at the correct physical size (see PdfExporter.ASSUMED_DPI's doc comment).
                    val file = withContext(Dispatchers.Default) {
                        PdfExporter.exportImagePaths(this@PdfPageEditorActivity, paths, rotations, sourceDpi = 200f)
                    }
                    setBusy(false)
                    Toast.makeText(
                        this@PdfPageEditorActivity,
                        getString(R.string.export_success, file.name),
                        Toast.LENGTH_LONG
                    ).show()
                }
                PdfEditorState.clear()
                finish()
            } catch (e: Exception) {
                setBusy(false)
                Toast.makeText(
                    this@PdfPageEditorActivity,
                    getString(R.string.export_failed, e.message ?: ""),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun setBusy(busy: Boolean, message: String? = null) {
        binding.progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        binding.tvProgress.visibility = if (busy && message != null) View.VISIBLE else View.GONE
        if (message != null) binding.tvProgress.text = message
        binding.btnExportPdf.isEnabled = !busy
        binding.btnExportImages.isEnabled = !busy
    }
}
