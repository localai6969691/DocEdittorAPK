package com.example.docscanner

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityConvertDocumentBinding
import com.example.docscanner.model.ScanSessionManager
import com.example.docscanner.util.EbookBuilder
import com.example.docscanner.util.EpubReader
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.TextPdfBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * General "convert between formats" entry point. PDF-sourced conversions are delegated to the
 * screens that already do them well (OCR + chapter editing for PDF->EPUB/TXT, page export for
 * PDF->Images) rather than duplicating that logic here - this activity only implements the
 * genuinely new conversions: EPUB<->TXT<->PDF and Images->PDF.
 */
class ConvertDocumentActivity : AppCompatActivity() {

    private lateinit var binding: ActivityConvertDocumentBinding

    private val epubPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) convertEpub(uri, pendingTargetIsPdf) else finish()
    }
    private val txtPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) convertTxt(uri, pendingTargetIsPdf) else finish()
    }
    private val imagesPicker = registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(50)) { uris ->
        if (uris.isNotEmpty()) convertImagesToPdf(uris) else finish()
    }

    private var pendingTargetIsPdf = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConvertDocumentBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        if (savedInstanceState == null) {
            showSourceDialog()
        }
    }

    private fun showSourceDialog() {
        val options = arrayOf(
            getString(R.string.convert_source_pdf),
            getString(R.string.convert_source_epub),
            getString(R.string.convert_source_txt),
            getString(R.string.convert_source_images)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.convert_source_title)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showPdfTargetDialog()
                    1 -> showEpubTargetDialog()
                    2 -> showTxtTargetDialog()
                    3 -> imagesPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
            }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun showPdfTargetDialog() {
        val options = arrayOf(getString(R.string.convert_target_ebook_group), getString(R.string.convert_target_images))
        AlertDialog.Builder(this)
            .setTitle(R.string.convert_target_title)
            .setItems(options) { _, which ->
                if (which == 0) {
                    ScanSessionManager.clear()
                    startActivity(Intent(this, EbookExportActivity::class.java))
                } else {
                    startActivity(Intent(this, PdfPageEditorActivity::class.java))
                }
                finish()
            }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun showEpubTargetDialog() {
        val options = arrayOf(getString(R.string.convert_target_pdf), getString(R.string.convert_target_txt))
        AlertDialog.Builder(this)
            .setTitle(R.string.convert_target_title)
            .setItems(options) { _, which ->
                pendingTargetIsPdf = (which == 0)
                epubPicker.launch(arrayOf("application/epub+zip"))
            }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun showTxtTargetDialog() {
        val options = arrayOf(getString(R.string.convert_target_pdf), getString(R.string.convert_target_epub))
        AlertDialog.Builder(this)
            .setTitle(R.string.convert_target_title)
            .setItems(options) { _, which ->
                pendingTargetIsPdf = (which == 0)
                txtPicker.launch(arrayOf("text/plain"))
            }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun convertEpub(uri: Uri, toPdf: Boolean) {
        setBusy(true)
        lifecycleScope.launch {
            val outFile = withContext(Dispatchers.Default) {
                val temp = FileUtils.copyUriToTempFile(this@ConvertDocumentActivity, uri, ".epub")
                    ?: return@withContext null
                val chapters = EpubReader.read(temp)
                temp.delete()
                if (chapters.isEmpty()) return@withContext null
                val baseName = FileUtils.defaultConvertedName()
                if (toPdf) {
                    val f = File(PdfExporter.exportDir(this@ConvertDocumentActivity), "$baseName.pdf")
                    TextPdfBuilder.build(f, chapters)
                    f
                } else {
                    val f = File(PdfExporter.exportDir(this@ConvertDocumentActivity), "$baseName.txt")
                    EbookBuilder.buildTxt(f, getString(R.string.ebook_default_title), chapters)
                    f
                }
            }
            setBusy(false)
            finishWithResult(outFile)
        }
    }

    private fun convertTxt(uri: Uri, toPdf: Boolean) {
        setBusy(true)
        lifecycleScope.launch {
            val outFile = withContext(Dispatchers.Default) {
                val text = try {
                    contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.readText()
                } catch (e: Exception) {
                    null
                } ?: return@withContext null
                val paragraphs = text.split("\n").map { it.trim() }.filter { it.isNotBlank() }
                if (paragraphs.isEmpty()) return@withContext null
                val chapters = listOf(EbookBuilder.Chapter(getString(R.string.ebook_default_title), paragraphs))
                val baseName = FileUtils.defaultConvertedName()
                if (toPdf) {
                    val f = File(PdfExporter.exportDir(this@ConvertDocumentActivity), "$baseName.pdf")
                    TextPdfBuilder.build(f, chapters)
                    f
                } else {
                    val f = File(PdfExporter.exportDir(this@ConvertDocumentActivity), "$baseName.epub")
                    EbookBuilder.buildEpub(f, getString(R.string.ebook_default_title), chapters)
                    f
                }
            }
            setBusy(false)
            finishWithResult(outFile)
        }
    }

    private fun convertImagesToPdf(uris: List<Uri>) {
        setBusy(true)
        lifecycleScope.launch {
            val outFile = withContext(Dispatchers.Default) {
                val paths = uris.mapIndexedNotNull { index, uri ->
                    try {
                        val file = FileUtils.newImportedFile(this@ConvertDocumentActivity, index)
                        contentResolver.openInputStream(uri)?.use { input ->
                            FileOutputStream(file).use { output -> input.copyTo(output) }
                        }
                        file.absolutePath
                    } catch (e: Exception) {
                        null
                    }
                }
                if (paths.isEmpty()) return@withContext null
                val baseName = FileUtils.defaultConvertedName()
                PdfExporter.exportImagePaths(this@ConvertDocumentActivity, paths, List(paths.size) { 0 }, baseName)
            }
            setBusy(false)
            finishWithResult(outFile)
        }
    }

    private fun finishWithResult(outFile: File?) {
        if (outFile == null) {
            Toast.makeText(this, R.string.convert_no_text_found, Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, getString(R.string.convert_success, outFile.name), Toast.LENGTH_LONG).show()
        }
        finish()
    }

    private fun setBusy(busy: Boolean) {
        binding.progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        binding.tvStatus.visibility = if (busy) View.VISIBLE else View.GONE
        if (busy) binding.tvStatus.text = getString(R.string.convert_progress)
    }
}
