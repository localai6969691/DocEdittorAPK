package com.example.docscanner.util

import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSBase
import com.tom_roush.pdfbox.cos.COSBoolean
import com.tom_roush.pdfbox.cos.COSDictionary
import com.tom_roush.pdfbox.cos.COSFloat
import com.tom_roush.pdfbox.cos.COSInteger
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSNull
import com.tom_roush.pdfbox.cos.COSObject
import com.tom_roush.pdfbox.cos.COSStream
import com.tom_roush.pdfbox.cos.COSString
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.math.BigDecimal
import java.security.MessageDigest
import java.util.Collections
import java.util.IdentityHashMap
import java.util.zip.Deflater
import java.util.zip.Inflater

/**
 * Re-creates, on top of PdfBox-Android (Apache 2.0), the "structure compression" that iText's
 * `WriterProperties.setFullCompressionMode(true).useSmartMode()` used to give for free
 * (iText 7 is AGPL / paid-commercial and was removed - TECHNICAL_DOCS.md, phiên 11).
 * PdfBox 2.x's own `save()` writes every object plainly and never packs objects into object
 * streams, so without this the "Nén PDF → Sửa trực tiếp" tool would only ever shrink images.
 *
 * Written from the public PDF specification (ISO 32000-1: 7.5.7 object streams, 7.5.8 cross-reference
 * streams, 7.4.4 Flate) - NOT ported from iText's source. What it does, in order:
 *  1. walks the object graph reachable from the trailer (`/Root`, `/Info`) - unreferenced garbage
 *     objects left by earlier incremental updates simply are not written;
 *  2. Flate-compresses streams that have no filter (except XMP `/Metadata`), and re-deflates
 *     existing single-Flate streams at level 9 when that is smaller (the decoded bytes, and so any
 *     `/DecodeParms` predictor layout, stay identical);
 *  3. merges byte-identical streams whose dictionaries hold no indirect references (the same font
 *     file or image embedded twice, typical of merged PDFs) - "smart mode";
 *  4. packs every non-stream object into compressed object streams and writes a cross-reference
 *     stream (PDF 1.5+).
 * It never fixes or reinterprets anything: content streams are copied byte for byte.
 *
 * ## Refuse rather than guess
 * Unsupported input makes [writeOptimized] throw [Unsupported] and [save] falls back to PdfBox's
 * plain output: encrypted documents, non-ASCII `/Names` (re-encoding them would desynchronise
 * dictionary keys from names used inside content streams), or unknown COS types. (Streams that
 * PdfBox holds directly in a dictionary - content streams / ToUnicode tables created in memory
 * by features such as [SearchablePdfBuilder] - are supported: they get object numbers of their own.) On top of that [save] only keeps the optimized file when
 * [PdfVerify.sameAsDocument] passes (independent reader + per-page content hash) and it is really
 * smaller. So the worst case is "no extra compression", never a broken file.
 *
 * NOT run on a real device yet (no Android SDK where this was written) - see TECHNICAL_DOCS.md.
 */
object PdfStructureOptimizer {

    private const val OBJECTS_PER_OBJSTM = 100
    private const val MIN_STREAM_BYTES_TO_COMPRESS = 64
    /** Above this the whole graph + a second verification copy risk running out of memory. */
    private const val MAX_BYTES_FOR_OPTIMIZER = 40L * 1024 * 1024

    class Unsupported(message: String) : Exception(message)

    data class Outcome(val optimizedUsed: Boolean, val reason: String)

    /**
     * Saves [doc] to [outFile]: PdfBox's plain save first (always valid baseline), then tries the
     * optimized writer and swaps it in only when it verifies and is smaller.
     */
    fun save(doc: PDDocument, outFile: File): Outcome {
        doc.save(outFile)
        if (doc.isEncrypted) return Outcome(false, "encrypted")
        if (outFile.length() > MAX_BYTES_FOR_OPTIMIZER) return Outcome(false, "too large")
        val tmp = File(outFile.parentFile, outFile.name + ".opt")
        return try {
            FileOutputStream(tmp).buffered().use { writeOptimized(doc, it) }
            when {
                tmp.length() <= 0L || tmp.length() >= outFile.length() -> Outcome(false, "not smaller")
                !PdfVerify.sameAsDocument(tmp, doc) -> Outcome(false, "verification failed")
                else -> {
                    tmp.copyTo(outFile, overwrite = true)
                    Outcome(true, "ok")
                }
            }
        } catch (t: Throwable) {
            Outcome(false, t.message ?: t.javaClass.simpleName)
        } finally {
            runCatching { tmp.delete() }
        }
    }

    // ------------------------------------------------------------------------------------------
    // Graph discovery
    // ------------------------------------------------------------------------------------------

    private fun keyOf(o: COSObject): Long = (o.objectNumber shl 16) or o.generationNumber.toLong()

    /** [streams] holds EVERY stream reachable from the trailer, each exactly once (identity): those
     *  reached through an indirect reference AND those held directly by a dictionary - the latter is
     *  what PdfBox creates when a feature adds a content stream / ToUnicode table in memory (no
     *  `COSObject` wrapper exists for them until they are written). */
    private class Graph(val objects: List<COSObject>, val targets: Map<Long, COSBase?>, val streams: List<COSStream>)

    private fun discover(trailer: COSDictionary): Graph {
        val order = ArrayList<COSObject>()
        val targets = HashMap<Long, COSBase?>()
        val seen = HashSet<Long>()
        val streams = ArrayList<COSStream>()
        val seenStreams: MutableSet<COSStream> = Collections.newSetFromMap(IdentityHashMap<COSStream, Boolean>())
        val queue = ArrayDeque<COSBase>()

        fun enqueueChildren(b: COSBase) {
            when (b) {
                is COSDictionary -> for (entry in b.entrySet()) {
                    // a stream's /Length is rewritten as a direct number - do not drag an indirect one along
                    if (b is COSStream && entry.key == COSName.LENGTH) continue
                    entry.value?.let { queue.addLast(it) }
                }
                is COSArray -> for (i in 0 until b.size()) b.get(i)?.let { queue.addLast(it) }
                else -> {}
            }
        }

        fun visitStream(s: COSStream) {
            if (seenStreams.add(s)) {
                streams.add(s)
                enqueueChildren(s)
            }
        }

        for (k in listOf(COSName.ROOT, COSName.INFO)) trailer.getItem(k)?.let { queue.addLast(it) }
        while (queue.isNotEmpty()) {
            when (val b = queue.removeFirst()) {
                is COSObject -> {
                    val key = keyOf(b)
                    if (seen.add(key)) {
                        val target = b.getObject()
                        targets[key] = target
                        order.add(b)
                        when (target) {
                            null -> {}
                            is COSStream -> visitStream(target)
                            else -> enqueueChildren(target)
                        }
                    }
                }
                is COSStream -> visitStream(b)
                else -> enqueueChildren(b)
            }
        }
        return Graph(order, targets, streams)
    }

    // ------------------------------------------------------------------------------------------
    // Serialisation of direct objects
    // ------------------------------------------------------------------------------------------

    /** Returns the object number a reference should print, or null for "points at nothing". */
    private interface RefResolver {
        fun numberFor(o: COSObject): Int?
        /** number of a stream that is held DIRECTLY (not via a `COSObject`) */
        fun numberForStream(s: COSStream): Int?
    }

    private fun writeName(name: String, out: ByteArrayOutputStream) {
        out.write('/'.code)
        for (ch in name) {
            val c = ch.code
            if (c < 0x21 || c > 0x7E) throw Unsupported("non-ASCII name")
            if (ch in "()<>[]{}/%#") {
                out.write('#'.code)
                out.write("%02X".format(c).toByteArray(Charsets.US_ASCII))
            } else {
                out.write(c)
            }
        }
    }

    private fun formatFloat(v: Float): String {
        if (v.isNaN() || v.isInfinite()) return "0"
        return BigDecimal(java.lang.Float.toString(v)).toPlainString()
    }

    private fun ser(b: COSBase?, out: ByteArrayOutputStream, refs: RefResolver) {
        when (b) {
            null, is COSNull -> out.write("null".toByteArray(Charsets.US_ASCII))
            is COSObject -> {
                val n = refs.numberFor(b)
                out.write((if (n == null) "null" else "$n 0 R").toByteArray(Charsets.US_ASCII))
            }
            is COSName -> writeName(b.name, out)
            is COSInteger -> out.write(b.longValue().toString().toByteArray(Charsets.US_ASCII))
            is COSFloat -> out.write(formatFloat(b.floatValue()).toByteArray(Charsets.US_ASCII))
            is COSBoolean -> out.write((if (b.value) "true" else "false").toByteArray(Charsets.US_ASCII))
            is COSString -> {
                out.write('<'.code)
                out.write(b.bytes.joinToString("") { "%02x".format(it) }.toByteArray(Charsets.US_ASCII))
                out.write('>'.code)
            }
            is COSArray -> {
                out.write('['.code)
                for (i in 0 until b.size()) {
                    if (i > 0) out.write(' '.code)
                    ser(b.get(i), out, refs)
                }
                out.write(']'.code)
            }
            is COSStream -> {
                // a stream can only be an indirect object: print a reference to its own number
                val n = refs.numberForStream(b) ?: throw Unsupported("stream without an object number")
                out.write("$n 0 R".toByteArray(Charsets.US_ASCII))
            }
            is COSDictionary -> serDict(b, out, refs, skip = null, extra = null)
            else -> throw Unsupported("unknown COS type ${b.javaClass.simpleName}")
        }
    }

    /** [skip] keys are omitted (e.g. /Length); [extra] entries are appended verbatim (already-serialised value). */
    private fun serDict(
        d: COSDictionary,
        out: ByteArrayOutputStream,
        refs: RefResolver,
        skip: Set<COSName>?,
        extra: List<Pair<String, String>>?
    ) {
        out.write("<<".toByteArray(Charsets.US_ASCII))
        for (entry in d.entrySet()) {
            if (skip != null && entry.key in skip) continue
            writeName(entry.key.name, out)
            out.write(' '.code)
            ser(entry.value, out, refs)
            out.write('\n'.code)
        }
        if (extra != null) for ((k, v) in extra) {
            writeName(k, out); out.write(' '.code); out.write(v.toByteArray(Charsets.US_ASCII)); out.write('\n'.code)
        }
        out.write(">>".toByteArray(Charsets.US_ASCII))
    }

    // ------------------------------------------------------------------------------------------
    // Stream preparation (compress / re-deflate)
    // ------------------------------------------------------------------------------------------

    private class PreparedStream(val stream: COSStream, val data: ByteArray, val addFlateFilter: Boolean)

    private fun deflate(data: ByteArray): ByteArray {
        val d = Deflater(Deflater.BEST_COMPRESSION)
        try {
            d.setInput(data)
            d.finish()
            val out = ByteArrayOutputStream(maxOf(64, data.size / 2))
            val buf = ByteArray(16 * 1024)
            while (!d.finished()) {
                val n = d.deflate(buf)
                out.write(buf, 0, n)
            }
            return out.toByteArray()
        } finally {
            d.end()
        }
    }

    /** Fully inflates zlib [data]; null if it is not a complete, valid zlib stream. */
    private fun inflateStrict(data: ByteArray): ByteArray? {
        val inf = Inflater()
        return try {
            inf.setInput(data)
            val out = ByteArrayOutputStream(maxOf(64, data.size * 3))
            val buf = ByteArray(16 * 1024)
            while (!inf.finished()) {
                val n = inf.inflate(buf)
                if (n == 0 && (inf.needsInput() || inf.needsDictionary())) return null
                out.write(buf, 0, n)
            }
            out.toByteArray()
        } catch (e: Exception) {
            null
        } finally {
            inf.end()
        }
    }

    private fun isSingleFlate(filter: COSBase?): Boolean = when (filter) {
        COSName.FLATE_DECODE -> true
        is COSArray -> filter.size() == 1 && filter.getObject(0) == COSName.FLATE_DECODE
        else -> false
    }

    private fun prepare(s: COSStream): PreparedStream {
        val raw = s.createRawInputStream().use { it.readBytes() }
        val filter = s.getDictionaryObject(COSName.FILTER)
        if (filter == null) {
            val skip = s.getCOSName(COSName.TYPE) == COSName.METADATA ||
                s.containsKey(COSName.DECODE_PARMS) || raw.size < MIN_STREAM_BYTES_TO_COMPRESS
            if (!skip) {
                val d = deflate(raw)
                if (d.size < raw.size) return PreparedStream(s, d, addFlateFilter = true)
            }
        } else if (isSingleFlate(filter)) {
            val inflated = inflateStrict(raw)
            if (inflated != null) {
                val d = deflate(inflated)
                if (d.size < raw.size) return PreparedStream(s, d, addFlateFilter = false)
            }
        }
        return PreparedStream(s, raw, addFlateFilter = false)
    }

    private val SKIP_IN_STREAM_DICT = setOf(COSName.LENGTH)

    private fun serStreamDict(p: PreparedStream, out: ByteArrayOutputStream, refs: RefResolver) {
        val extra = ArrayList<Pair<String, String>>()
        if (p.addFlateFilter) extra.add("Filter" to "/FlateDecode")
        extra.add("Length" to p.data.size.toString())
        serDict(p.stream, out, refs, SKIP_IN_STREAM_DICT, extra)
    }

    private val NO_REFS = object : RefResolver {
        override fun numberFor(o: COSObject): Int? = throw Unsupported("has reference")
        override fun numberForStream(s: COSStream): Int? = throw Unsupported("has reference")
    }

    // ------------------------------------------------------------------------------------------
    // The writer
    // ------------------------------------------------------------------------------------------

    private class CountingOut(val target: OutputStream) {
        var pos = 0L
        fun write(b: ByteArray) { target.write(b); pos += b.size }
        fun write(s: String) = write(s.toByteArray(Charsets.ISO_8859_1))
    }

    fun writeOptimized(doc: PDDocument, sink: OutputStream) {
        if (doc.isEncrypted) throw Unsupported("encrypted")
        val trailer = doc.document.trailer
        val rootRef = trailer.getItem(COSName.ROOT) as? COSObject ?: throw Unsupported("no indirect /Root")
        val graph = discover(trailer)
        if (graph.targets[keyOf(rootRef)] !is COSDictionary) throw Unsupported("/Root is not a dictionary")

        // --- classify + prepare, assign new numbers (identical streams share one) -----------------
        val numberOf = HashMap<Long, Int>()                 // non-stream COSObject key -> new number
        val streamNumber = IdentityHashMap<COSStream, Int>() // every stream (identity) -> new number
        val streamsInOrder = ArrayList<Pair<Int, PreparedStream>>()
        val plainInOrder = ArrayList<Pair<Int, COSBase>>()
        val canonicalBySig = HashMap<String, Int>()
        var next = 1
        for (stream in graph.streams) {
            val prepared = prepare(stream)
            val sig = duplicateSignature(prepared)
            val existing = if (sig != null) canonicalBySig[sig] else null
            if (existing != null) {
                streamNumber[stream] = existing
            } else {
                val n = next++
                streamNumber[stream] = n
                streamsInOrder.add(n to prepared)
                if (sig != null) canonicalBySig[sig] = n
            }
        }
        for (ref in graph.objects) {
            val key = keyOf(ref)
            val target = graph.targets[key]
            if (target == null || target is COSNull || target is COSStream) continue // null / stream: handled above or "points at nothing"
            val n = next++
            numberOf[key] = n
            plainInOrder.add(n to target)
        }
        val refs = object : RefResolver {
            override fun numberFor(o: COSObject): Int? {
                val target = graph.targets[keyOf(o)]
                return if (target is COSStream) streamNumber[target] else numberOf[keyOf(o)]
            }
            override fun numberForStream(s: COSStream): Int? = streamNumber[s]
        }

        // --- header ----------------------------------------------------------------------------
        val out = CountingOut(sink)
        val version = maxOf(doc.version, 1.5f)
        out.write("%PDF-${"%.1f".format(java.util.Locale.US, version)}\n")
        out.write(byteArrayOf('%'.code.toByte(), 0xE2.toByte(), 0xE3.toByte(), 0xCF.toByte(), 0xD3.toByte(), '\n'.code.toByte()))

        val offsets = HashMap<Int, Long>()             // type-1 entries
        val inObjStm = HashMap<Int, Pair<Int, Int>>()  // type-2 entries: obj -> (objstm number, index)

        // --- stream objects, written as-is -------------------------------------------------------
        for ((n, p) in streamsInOrder) {
            offsets[n] = out.pos
            val head = ByteArrayOutputStream()
            head.write("$n 0 obj\n".toByteArray(Charsets.US_ASCII))
            serStreamDict(p, head, refs)
            head.write("\nstream\n".toByteArray(Charsets.US_ASCII))
            out.write(head.toByteArray())
            out.write(p.data)
            out.write("\nendstream\nendobj\n")
        }

        // --- all other objects, packed into object streams ---------------------------------------
        var nextObjNum = next
        for (chunk in plainInOrder.chunked(OBJECTS_PER_OBJSTM)) {
            val body = ByteArrayOutputStream()
            val header = StringBuilder()
            chunk.forEachIndexed { index, (n, value) ->
                header.append(n).append(' ').append(body.size()).append(' ')
                ser(value, body, refs)
                body.write('\n'.code)
                inObjStm[n] = nextObjNum to index
            }
            val headerBytes = (header.toString().trimEnd() + "\n").toByteArray(Charsets.US_ASCII)
            val packed = deflate(headerBytes + body.toByteArray())
            val stmNum = nextObjNum++
            offsets[stmNum] = out.pos
            out.write(
                "$stmNum 0 obj\n<< /Type /ObjStm /N ${chunk.size} /First ${headerBytes.size} " +
                    "/Filter /FlateDecode /Length ${packed.size} >>\nstream\n"
            )
            out.write(packed)
            out.write("\nendstream\nendobj\n")
        }

        // --- cross-reference stream --------------------------------------------------------------
        val xrefNum = nextObjNum++
        val xrefOffset = out.pos
        offsets[xrefNum] = xrefOffset
        val size = xrefNum + 1
        val rows = ByteArrayOutputStream(size * 7)
        fun row(type: Int, f2: Long, f3: Int) {
            rows.write(type)
            rows.write(((f2 ushr 24) and 0xFF).toInt()); rows.write(((f2 ushr 16) and 0xFF).toInt())
            rows.write(((f2 ushr 8) and 0xFF).toInt()); rows.write((f2 and 0xFF).toInt())
            rows.write((f3 ushr 8) and 0xFF); rows.write(f3 and 0xFF)
        }
        row(0, 0, 0xFFFF) // object 0: head of the free list
        for (n in 1 until size) {
            val off = offsets[n]
            val packedAt = inObjStm[n]
            when {
                off != null -> row(1, off, 0)
                packedAt != null -> row(2, packedAt.first.toLong(), packedAt.second)
                else -> row(0, 0, 0) // cannot happen; keeps the table well-formed if it ever did
            }
        }
        val xrefData = deflate(rows.toByteArray())
        val trailerText = ByteArrayOutputStream()
        trailerText.write("<< /Type /XRef /Size $size /W [1 4 2] /Root ${numberOf.getValue(keyOf(rootRef))} 0 R ".toByteArray(Charsets.US_ASCII))
        (trailer.getItem(COSName.INFO) as? COSObject)?.let { info ->
            numberOf[keyOf(info)]?.let { trailerText.write("/Info $it 0 R ".toByteArray(Charsets.US_ASCII)) }
        }
        (trailer.getDictionaryObject(COSName.ID) as? COSArray)?.let { id ->
            trailerText.write("/ID ".toByteArray(Charsets.US_ASCII)); ser(id, trailerText, refs); trailerText.write(' '.code)
        }
        trailerText.write("/Filter /FlateDecode /Length ${xrefData.size} >>".toByteArray(Charsets.US_ASCII))
        out.write("$xrefNum 0 obj\n")
        out.write(trailerText.toByteArray())
        out.write("\nstream\n")
        out.write(xrefData)
        out.write("\nendstream\nendobj\n")
        out.write("startxref\n$xrefOffset\n%%EOF\n")
        sink.flush()
    }

    /** Signature for de-duplication, or null when the stream must not be merged (its dictionary
     *  holds an indirect reference, so equal-looking streams might point at different things). */
    private fun duplicateSignature(p: PreparedStream): String? {
        return try {
            val dict = ByteArrayOutputStream()
            serStreamDict(p, dict, NO_REFS)
            val md = MessageDigest.getInstance("SHA-256")
            md.update(dict.toByteArray())
            md.update(0)
            md.update(p.data)
            md.digest().joinToString("") { "%02x".format(it) }
        } catch (e: Unsupported) {
            null
        }
    }
}
