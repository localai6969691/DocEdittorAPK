package com.example.docscanner.view

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PointF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import com.example.docscanner.R
import kotlin.math.abs

/**
 * Shows [bitmap] scaled to fit the view with one draggable vertical line on top, used to mark
 * where a photo of two facing book pages should be split into two separate page images. Reuses
 * the same bitmap<->view coordinate-matrix approach as [CropOverlayView] for consistency.
 */
class SplitLineOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var bitmap: Bitmap? = null
    private var lineX: Float = 0f // bitmap pixel space

    private val bitmapToView = Matrix()
    private val viewToBitmap = Matrix()
    private var dragging = false
    private val touchSlopPx = resources.displayMetrics.density * 28f

    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.overlay_line)
        style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density * 3f
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.overlay_handle)
        style = Paint.Style.FILL
    }
    private val handleStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.overlay_line)
        style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density * 2f
    }
    private val handleRadiusPx = resources.displayMetrics.density * 14f

    fun setImage(bmp: Bitmap, initialLineX: Double) {
        bitmap = bmp
        lineX = initialLineX.toFloat().coerceIn(0f, bmp.width.toFloat())
        recomputeMatrix()
        invalidate()
    }

    fun getSplitX(): Float = lineX

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        recomputeMatrix()
    }

    private fun recomputeMatrix() {
        val bmp = bitmap ?: return
        if (width == 0 || height == 0) return
        val scale = minOf(width.toFloat() / bmp.width, height.toFloat() / bmp.height)
        val dx = (width - bmp.width * scale) / 2f
        val dy = (height - bmp.height * scale) / 2f
        bitmapToView.reset()
        bitmapToView.postScale(scale, scale)
        bitmapToView.postTranslate(dx, dy)
        bitmapToView.invert(viewToBitmap)
    }

    private fun mapPoint(matrix: Matrix, p: PointF): PointF {
        val arr = floatArrayOf(p.x, p.y)
        matrix.mapPoints(arr)
        return PointF(arr[0], arr[1])
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = bitmap ?: return
        canvas.drawBitmap(bmp, bitmapToView, bitmapPaint)

        val topView = mapPoint(bitmapToView, PointF(lineX, 0f))
        val bottomView = mapPoint(bitmapToView, PointF(lineX, bmp.height.toFloat()))
        canvas.drawLine(topView.x, topView.y, bottomView.x, bottomView.y, linePaint)

        val midY = (topView.y + bottomView.y) / 2f
        canvas.drawCircle(topView.x, midY, handleRadiusPx, handlePaint)
        canvas.drawCircle(topView.x, midY, handleRadiusPx, handleStrokePaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val bmp = bitmap ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val lineViewX = mapPoint(bitmapToView, PointF(lineX, 0f)).x
                dragging = abs(event.x - lineViewX) <= touchSlopPx
                parent?.requestDisallowInterceptTouchEvent(dragging)
                return dragging
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) return false
                val pt = mapPoint(viewToBitmap, PointF(event.x, event.y))
                lineX = pt.x.coerceIn(0f, bmp.width.toFloat())
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
