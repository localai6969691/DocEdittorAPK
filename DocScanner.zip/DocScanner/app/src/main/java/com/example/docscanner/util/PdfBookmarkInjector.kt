package com.example.docscanner.util

import java.io.ByteArrayOutputStream
import java.util.Locale

/**
 * Adds real, clickable PDF bookmarks (the "Outline"/table-of-contents panel most PDF readers show
 * in a side drawer) to a PDF that `android.graphics.pdf.PdfDocument` already wrote - PdfDocument
 * itself has no public API for bookmarks, so this patches the finished file instead.
 *
 * How: PDF's "incremental update" mechanism, the same one real PDF editors use to add annotations
 * without touching existing content - new objects (the outline tree) are appended after the
 * original file, one existing object (the Catalog) is *redefined* at a new offset to point at the
 * new outline, and a new xref+trailer section (with `/Prev` pointing at the original one) ties it
 * together. The original page content is never touched.
 *
 * This requires finding a few things in PdfDocument's output first: the trailer, the Catalog
 * object, the Pages object, and its `/Kids` array (the page object numbers, in order) - none of
 * this is a *documented*, guaranteed-stable part of Android's PdfDocument output, so every step
 * is written defensively and the whole thing is wrapped in one try/catch. [TextPdfBuilder] treats
 * a null return as "skip bookmarks, ship the plain PDF" - this can only ever add bookmarks on top
 * of an already-valid PDF, never break one.
 */
internal object PdfBookmarkInjector {

    fun tryAddBookmarks(
        original: ByteArray,
        pageCount: Int,
        chapterTitles: List<String>,
        chapterStartPageIndex: List<Int>
    ): ByteArray? {
        return try {
            buildPatched(original, pageCount, chapterTitles, chapterStartPageIndex)
        } catch (e: Exception) {
            null
        }
    }

    private fun buildPatched(
        original: ByteArray,
        pageCount: Int,
        chapterTitles: List<String>,
        chapterStartPageIndex: List<Int>
    ): ByteArray? {
        val text = String(original, Charsets.ISO_8859_1) // 1 byte = 1 char - safe for byte-offset scanning

        val startXref = findLastInt(text, "startxref") ?: return null
        val trailerDict = extractLastDict(text, "trailer") ?: return null
        val rootNum = firstIntAfter(trailerDict, "/Root") ?: return null

        val catalogBody = extractObjectBody(text, rootNum) ?: return null
        val pagesNum = firstIntAfter(catalogBody, "/Pages") ?: return null

        val pagesBody = extractObjectBody(text, pagesNum) ?: return null
        val kidsNums = extractKids(pagesBody) ?: return null
        if (kidsNums.size != pageCount) return null // structure isn't what we expected - bail out safely

        val maxObjNum = Regex("(\\d+)\\s+0\\s+obj").findAll(text)
            .mapNotNull { it.groupValues[1].toIntOrNull() }
            .maxOrNull() ?: return null

        val outlinesObjNum = maxObjNum + 1
        val firstItemObjNum = outlinesObjNum + 1
        val itemCount = chapterTitles.size
        if (itemCount == 0) return null

        val out = ByteArrayOutputStream()
        out.write(original)

        val newOffsets = LinkedHashMap<Int, Int>() // objNum -> offset in the FINAL byte stream

        fun writeAscii(s: String) = out.write(s.toByteArray(Charsets.ISO_8859_1))
        fun currentOffset() = out.size()

        // Redefine the Catalog with an added /Outlines entry, preserving everything else in it.
        val newCatalogBody = insertBeforeDictClose(catalogBody, "/Outlines $outlinesObjNum 0 R")
        newOffsets[rootNum] = currentOffset()
        writeAscii("$rootNum 0 obj\n<<$newCatalogBody>>\nendobj\n")

        // Outline root.
        newOffsets[outlinesObjNum] = currentOffset()
        writeAscii(
            "$outlinesObjNum 0 obj\n<< /Type /Outlines /First $firstItemObjNum 0 R " +
                "/Last ${firstItemObjNum + itemCount - 1} 0 R /Count $itemCount >>\nendobj\n"
        )

        // One outline item per chapter, linked Prev/Next, each pointing at its chapter's page.
        for (i in 0 until itemCount) {
            val itemObjNum = firstItemObjNum + i
            val pageIdx = chapterStartPageIndex.getOrElse(i) { 0 }.coerceIn(0, kidsNums.size - 1)
            val destPageObj = kidsNums[pageIdx]
            val titleHex = toPdfUtf16HexString(chapterTitles[i])
            val prevRef = if (i > 0) "/Prev ${itemObjNum - 1} 0 R " else ""
            val nextRef = if (i < itemCount - 1) "/Next ${itemObjNum + 1} 0 R " else ""
            newOffsets[itemObjNum] = currentOffset()
            writeAscii(
                "$itemObjNum 0 obj\n<< /Title $titleHex /Parent $outlinesObjNum 0 R $prevRef$nextRef" +
                    "/Dest [$destPageObj 0 R /Fit] >>\nendobj\n"
            )
        }

        val newXrefOffset = currentOffset()
        val highestObjNum = maxOf(maxObjNum, firstItemObjNum + itemCount - 1)

        // Incremental-update xref: one subsection for the redefined Catalog, one contiguous
        // subsection for the newly appended outline objects.
        writeAscii("xref\n")
        writeAscii("$rootNum 1\n")
        writeAscii(String.format(Locale.US, "%010d 00000 n\r\n", newOffsets.getValue(rootNum)))
        writeAscii("$outlinesObjNum ${itemCount + 1}\n")
        for (num in outlinesObjNum..(outlinesObjNum + itemCount)) {
            writeAscii(String.format(Locale.US, "%010d 00000 n\r\n", newOffsets.getValue(num)))
        }
        writeAscii(
            "trailer\n<< /Size ${highestObjNum + 1} /Root $rootNum 0 R /Prev $startXref >>\n" +
                "startxref\n$newXrefOffset\n%%EOF"
        )

        return out.toByteArray()
    }

    private fun toPdfUtf16HexString(s: String): String {
        val sb = StringBuilder("<FEFF")
        for (ch in s) sb.append(String.format(Locale.US, "%04X", ch.code))
        sb.append(">")
        return sb.toString()
    }

    private fun findLastInt(text: String, keyword: String): Int? {
        val idx = text.lastIndexOf(keyword)
        if (idx < 0) return null
        val after = text.substring(idx + keyword.length)
        val match = Regex("\\d+").find(after) ?: return null
        return match.value.toIntOrNull()
    }

    /** Finds the LAST `keyword << ... >>` dictionary in [text] (handles nested `<< >>`). */
    private fun extractLastDict(text: String, keyword: String): String? {
        val idx = text.lastIndexOf(keyword)
        if (idx < 0) return null
        val dictStart = text.indexOf("<<", idx)
        if (dictStart < 0) return null
        var depth = 0
        var i = dictStart
        while (i < text.length - 1) {
            if (text[i] == '<' && text[i + 1] == '<') {
                depth++; i += 2; continue
            }
            if (text[i] == '>' && text[i + 1] == '>') {
                depth--
                i += 2
                if (depth == 0) return text.substring(dictStart + 2, i - 2)
                continue
            }
            i++
        }
        return null
    }

    private fun firstIntAfter(text: String, key: String): Int? {
        val idx = text.indexOf(key)
        if (idx < 0) return null
        val match = Regex("(\\d+)\\s+0\\s+R").find(text, idx + key.length) ?: return null
        return match.groupValues[1].toIntOrNull()
    }

    /** Finds `"N 0 obj" ... "endobj"` and returns the dictionary body between the `<<` and `>>`. */
    private fun extractObjectBody(text: String, num: Int): String? {
        val match = Regex("(?<![0-9])$num\\s+0\\s+obj").find(text) ?: return null
        val objStart = match.range.last + 1
        val end = text.indexOf("endobj", objStart)
        if (end < 0) return null
        val body = text.substring(objStart, end)
        val dictStart = body.indexOf("<<")
        val dictEnd = body.lastIndexOf(">>")
        if (dictStart < 0 || dictEnd < 0 || dictEnd <= dictStart) return null
        return body.substring(dictStart + 2, dictEnd)
    }

    private fun extractKids(pagesBody: String): List<Int>? {
        val match = Regex("/Kids\\s*\\[([^\\]]*)]").find(pagesBody) ?: return null
        val nums = Regex("(\\d+)\\s+0\\s+R").findAll(match.groupValues[1])
            .mapNotNull { it.groupValues[1].toIntOrNull() }
            .toList()
        return nums.ifEmpty { null }
    }

    private fun insertBeforeDictClose(dictBody: String, addition: String): String {
        return "$dictBody $addition "
    }
}
