package com.example.docscanner

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.adapter.PageListAdapter
import com.example.docscanner.databinding.ActivityPageListBinding
import com.example.docscanner.model.ScanSessionManager
import com.example.docscanner.util.CompressOptionsDialog
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfCompressor
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.ScanPresetApplier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/** Shows the pages captured/imported into the current session; lets the user reorder, delete,
 *  bulk re-filter, annotate an individual page (see [PdfAnnotateActivity]), and finally export the
 *  whole thing as a PDF (optionally running OCR). */
class PageListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPageListBinding
    private lateinit var adapter: PageListAdapter
    private lateinit var touchHelper: ItemTouchHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPageListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        adapter = PageListAdapter(
            onDelete = { position ->
                ScanSessionManager.removeAt(position)
                refreshList()
            },
            onAnnotate = { position ->
                val page = ScanSessionManager.pages.getOrNull(position)
                if (page != null) {
                    val intent = Intent(this, PdfAnnotateActivity::class.java).apply {
                        putExtra(PdfAnnotateActivity.EXTRA_IMAGE_PATH, page.filePath)
                        putExtra(PdfAnnotateActivity.EXTRA_SESSION_PAGE_INDEX, position)
                    }
                    startActivity(intent)
                }
            },
            onDragHandleTouch = { holder -> touchHelper.startDrag(holder) }
        )
        binding.rvPages.layoutManager = GridLayoutManager(this, 2)
        binding.rvPages.adapter = adapter

        touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = viewHolder.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
                ScanSessionManager.move(from, to)
                adapter.moveItem(from, to)
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}
        })
        touchHelper.attachToRecyclerView(binding.rvPages)

        binding.btnAddPage.setOnClickListener {
            startActivity(Intent(this, CaptureActivity::class.java))
        }
        binding.btnExportPdf.setOnClickListener { showExportMethodPicker() }

        refreshList()
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_page_list, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.action_bulk_filter) {
            showBulkFilterDialog()
            return true
        }
        if (item.itemId == R.id.action_export_ebook) {
            startActivity(Intent(this, EbookExportActivity::class.java))
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun refreshList() {
        val pages = ScanSessionManager.pages
        adapter.submitList(pages)
        title = getString(R.string.page_list_title, pages.size)
        binding.tvEmptyPages.visibility = if (pages.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun showBulkFilterDialog() {
        if (ScanSessionManager.pages.isEmpty()) return
        val labels = arrayOf(
            getString(R.string.preset_original),
            getString(R.string.preset_enhance),
            getString(R.string.preset_gray),
            getString(R.string.preset_bw),
            getString(R.string.preset_eink),
            getString(R.string.preset_eink_color),
            getString(R.string.preset_auto)
        )
        val presets = ScanPresetApplier.Preset.values()
        var selected = 6 // default to Auto - the best general-purpose choice for mixed documents
        AlertDialog.Builder(this)
            .setTitle(R.string.bulk_filter_title)
            .setSingleChoiceItems(labels, selected) { _, which -> selected = which }
            .setPositiveButton(R.string.dialog_yes) { dialog, _ ->
                applyBulkPreset(presets[selected])
                dialog.dismiss()
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun applyBulkPreset(preset: ScanPresetApplier.Preset) {
        val pages = ScanSessionManager.pages.toList()
        if (pages.isEmpty()) return
        setBusy(true)
        val autoStats = ScanPresetApplier.AutoStats()
        lifecycleScope.launch {
            pages.forEachIndexed { index, page ->
                binding.tvProgress.text = getString(R.string.bulk_filter_progress, index + 1, pages.size)
                withContext(Dispatchers.Default) {
                    val bitmap = BitmapFactory.decodeFile(page.filePath) ?: return@withContext
                    val out = ScanPresetApplier.apply(bitmap, preset, autoStats)
                    FileOutputStream(File(page.filePath)).use { fos ->
                        out.compress(Bitmap.CompressFormat.JPEG, 92, fos)
                    }
                    if (out !== bitmap) out.recycle()
                    bitmap.recycle()
                }
            }
            setBusy(false)
            refreshList()
            if (preset == ScanPresetApplier.Preset.AUTO) {
                Toast.makeText(
                    this@PageListActivity,
                    getString(R.string.auto_result_summary, pages.size, autoStats.textCount, autoStats.colorCount),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    /** Shows the 3-way pick ("keep as-is" / "safe" / "CCITT G4") before every export - see
     *  [CompressOptionsDialog]'s own doc comment for why this is a shared dialog with the
     *  standalone "Nén PDF" tool. Unlike that tool, "Sửa trực tiếp" is never offered here - there
     *  is no pre-existing PDF to edit in place yet at this point in the scan flow, every page is
     *  always encoded fresh from its saved image either way, so that 3rd method has nothing to
     *  mean here (see [PdfObjectRecompressor]'s own doc comment for what it actually does). */
    private fun showExportMethodPicker() {
        if (ScanSessionManager.pages.isEmpty()) return
        val options = listOf(
            CompressOptionsDialog.Option(
                title = getString(R.string.export_method_keep),
                summary = getString(R.string.compress_option_keep_summary),
                pros = getString(R.string.compress_option_keep_pros),
                cons = getString(R.string.compress_option_keep_cons)
            ),
            CompressOptionsDialog.Option(
                title = getString(R.string.compress_method_safe),
                summary = getString(R.string.compress_option_safe_summary),
                pros = getString(R.string.compress_option_safe_pros),
                cons = getString(R.string.compress_option_safe_cons)
            ),
            CompressOptionsDialog.Option(
                title = getString(R.string.compress_method_g4),
                summary = getString(R.string.compress_option_g4_summary),
                pros = getString(R.string.compress_option_g4_pros),
                cons = getString(R.string.compress_option_g4_cons)
            )
        )
        CompressOptionsDialog.show(this, R.string.export_method_title, options) { which ->
            val method = when (which) {
                1 -> PdfCompressor.TextCompressionMethod.SAFE_DEFLATE
                2 -> PdfCompressor.TextCompressionMethod.CCITT_G4
                else -> null // "keep as-is" - the original, unchanged export path
            }
            exportPdf(method)
        }
    }

    /** [compressMethod] null means the original, unchanged behavior: every page drawn as-is via
     *  [PdfExporter.exportSession] (`android.graphics.pdf.PdfDocument`, no re-classification or
     *  binarization of any page - see that function's own doc comment). Non-null routes through
     *  [PdfCompressor] instead - the SAME text/color auto-classification and encoding the
     *  standalone "Nén PDF" tool already uses, just building a brand-new PDF from the session's
     *  own page files instead of re-rendering an existing one. [PdfExporter.writeOcrTextFile] is
     *  reused either way for the OCR checkbox - already decoupled from how the PDF itself gets
     *  written (see that function's own doc comment), so this branch doesn't duplicate it. */
    private fun exportPdf(compressMethod: PdfCompressor.TextCompressionMethod?) {
        val pages = ScanSessionManager.pages
        if (pages.isEmpty()) return
        val withOcr = binding.cbOcr.isChecked
        setBusy(true)
        lifecycleScope.launch {
            try {
                if (compressMethod == null) {
                    val result = PdfExporter.exportSession(
                        context = this@PageListActivity,
                        pages = pages,
                        withOcr = withOcr,
                        onOcrProgress = { done, total ->
                            runOnUiThread {
                                binding.tvProgress.text = getString(R.string.ocr_progress, done, total)
                            }
                        }
                    )
                    setBusy(false)
                    Toast.makeText(
                        this@PageListActivity,
                        getString(R.string.export_success, result.pdfFile.name),
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    val baseName = FileUtils.defaultDocName()
                    val paths = pages.map { it.filePath }
                    val outFile = File(PdfExporter.exportDir(this@PageListActivity), "$baseName.pdf")
                    withContext(Dispatchers.Default) {
                        PdfCompressor.compress(
                            pageImagePaths = paths,
                            outFile = outFile,
                            originalSize = 0L,
                            textMethod = compressMethod,
                            pageDpis = pages.map { it.sourceDpi }
                        ) { done, total ->
                            runOnUiThread {
                                binding.tvProgress.text = getString(R.string.compress_progress, done, total)
                            }
                        }
                    }
                    if (withOcr) {
                        withContext(Dispatchers.Default) {
                            PdfExporter.writeOcrTextFile(this@PageListActivity, paths, baseName) { done, total ->
                                runOnUiThread {
                                    binding.tvProgress.text = getString(R.string.ocr_progress, done, total)
                                }
                            }
                        }
                    }
                    setBusy(false)
                    Toast.makeText(
                        this@PageListActivity,
                        getString(R.string.export_success_sized, outFile.name, FileUtils.humanFileSize(outFile.length())),
                        Toast.LENGTH_LONG
                    ).show()
                }
                ScanSessionManager.clear()
                startActivity(Intent(this@PageListActivity, MainActivity::class.java))
                finish()
            } catch (e: Exception) {
                setBusy(false)
                Toast.makeText(
                    this@PageListActivity,
                    getString(R.string.export_failed, e.message ?: ""),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun setBusy(busy: Boolean) {
        binding.progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        binding.tvProgress.visibility = if (busy) View.VISIBLE else View.GONE
        binding.btnExportPdf.isEnabled = !busy
        binding.btnAddPage.isEnabled = !busy
    }
}
