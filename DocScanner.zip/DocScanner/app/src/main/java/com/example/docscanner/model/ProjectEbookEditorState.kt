package com.example.docscanner.model

import android.content.Context
import com.example.docscanner.util.FileUtils
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Persists the in-progress state of [com.example.docscanner.ProjectEbookActivity] (Project stage
 * 8, the final step) - specifically the manual chapter-mark/title touch-ups the user makes on top
 * of the table of contents carried over from stage 5 ([Project.tocEntries]), plus this screen's
 * own book-title field and output-format checkboxes.
 *
 * This fills the gap TECHNICAL_DOCS.md section 4.15/6 flagged: unlike its standalone counterpart
 * ([EbookEditorState]), this stage previously had no backup/restore at all for edits made after
 * OCR finishes - a process death while reviewing chapter marks here lost only the just-made manual
 * touch-ups (the source pages and the original TOC always survived fine, being part of [Project]
 * itself), but that was still a real, avoidable loss. Same reasoning as [EbookEditorState] for what
 * is and isn't persisted:
 * - Source pages are NOT duplicated here - they always come from [Project.pages], which is already
 *   durable on its own via [ProjectManager].
 * - OCR'd paragraph text is NOT persisted - re-running OCR on restore is cheap (see
 *   [com.example.docscanner.ProjectEbookActivity]'s class doc comment), so there's no reason to
 *   duplicate potentially large recognized text into this JSON file.
 *
 * Kept as its OWN file per project (under [FileUtils.projectDir]) rather than reusing
 * [EbookEditorState]'s single global slot: several projects can each be sitting mid-way through
 * this stage at different times, and each project already owns its own directory that gets swept
 * up automatically by [ProjectManager.delete] - no extra cleanup wiring needed here for that case.
 * Unlike the other `model.*State` singletons, this takes [Context] and a project id explicitly on
 * every call instead of a stored `init()`-time context - same reasoning as [ProjectManager] itself
 * (every caller is a `Project*Activity`, which always has both at hand).
 */
object ProjectEbookEditorState {

    data class SavedPage(val path: String, val isChapterStart: Boolean, val chapterTitle: String)
    data class SavedState(
        val bookTitle: String,
        val wantEpub: Boolean,
        val wantTxt: Boolean,
        val pages: List<SavedPage>
    )

    private fun stateFile(context: Context, projectId: String): File =
        File(FileUtils.projectDir(context, projectId), "ebook_editor_state.json")

    fun persist(context: Context, projectId: String, state: SavedState) {
        val file = stateFile(context, projectId)
        try {
            val pagesArr = JSONArray()
            state.pages.forEach { p ->
                pagesArr.put(
                    JSONObject()
                        .put("path", p.path)
                        .put("chapterStart", p.isChapterStart)
                        .put("chapterTitle", p.chapterTitle)
                )
            }
            val root = JSONObject()
                .put("bookTitle", state.bookTitle)
                .put("wantEpub", state.wantEpub)
                .put("wantTxt", state.wantTxt)
                .put("pages", pagesArr)
            file.writeText(root.toString())
        } catch (e: Exception) {
            // Best-effort only - a failed save just means nothing to restore later, never crash over it.
        }
    }

    /** Loads the saved state for this project, dropping any page whose source file no longer
     *  exists on disk. Returns null if nothing usable is left, or nothing was ever saved. */
    fun restore(context: Context, projectId: String): SavedState? {
        val file = stateFile(context, projectId)
        if (!file.exists()) return null
        return try {
            val root = JSONObject(file.readText())
            val pagesArr = root.optJSONArray("pages") ?: return null
            val pages = (0 until pagesArr.length()).mapNotNull { i ->
                val obj = pagesArr.getJSONObject(i)
                val path = obj.optString("path")
                if (path.isNotBlank() && File(path).exists()) {
                    SavedPage(
                        path,
                        obj.optBoolean("chapterStart", false),
                        obj.optString("chapterTitle", "")
                    )
                } else null
            }
            if (pages.isEmpty()) return null
            SavedState(
                bookTitle = root.optString("bookTitle"),
                wantEpub = root.optBoolean("wantEpub", true),
                wantTxt = root.optBoolean("wantTxt", true),
                pages = pages
            )
        } catch (e: Exception) {
            null
        }
    }

    /** Discards the saved state on disk for this project. Never touches the page files themselves
     *  - those belong to [Project.pages], owned and cleaned up only by [ProjectManager]. Safe to
     *  call even if nothing was ever saved for this project. */
    fun clear(context: Context, projectId: String) {
        runCatching { stateFile(context, projectId).delete() }
    }
}
