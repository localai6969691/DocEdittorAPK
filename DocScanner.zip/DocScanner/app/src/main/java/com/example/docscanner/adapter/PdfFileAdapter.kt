package com.example.docscanner.adapter

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.databinding.ItemPdfFileBinding
import com.example.docscanner.util.PdfImportHelper

class PdfFileAdapter(
    private val context: Context,
    private val onRemove: (Int) -> Unit,
    private val onDragHandleTouch: (RecyclerView.ViewHolder) -> Unit
) : RecyclerView.Adapter<PdfFileAdapter.ViewHolder>() {

    private val items = mutableListOf<Uri>()

    fun submitList(uris: List<Uri>) {
        items.clear()
        items.addAll(uris)
        notifyDataSetChanged()
    }

    fun moveItem(from: Int, to: Int) {
        if (from < 0 || to < 0 || from >= items.size || to >= items.size) return
        val item = items.removeAt(from)
        items.add(to, item)
        notifyItemMoved(from, to)
    }

    inner class ViewHolder(val binding: ItemPdfFileBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPdfFileBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val uri = items[position]
        holder.binding.tvOrder.text = (position + 1).toString()
        holder.binding.tvFileName.text = PdfImportHelper.displayName(context, uri)
        holder.binding.btnRemove.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onRemove(pos)
        }
        holder.binding.ivDragHandle.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) onDragHandleTouch(holder)
            false
        }
    }

    override fun getItemCount(): Int = items.size
}
