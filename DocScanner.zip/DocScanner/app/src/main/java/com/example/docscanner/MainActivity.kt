package com.example.docscanner

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.docscanner.adapter.HistoryAdapter
import com.example.docscanner.databinding.ActivityMainBinding
import com.example.docscanner.model.PendingCropQueue
import com.example.docscanner.model.ScanPage
import com.example.docscanner.model.ScanSessionManager
import com.example.docscanner.util.CompressOptionsDialog
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfCompressor
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfImportHelper
import com.example.docscanner.util.OcrHelper
import com.example.docscanner.util.PdfObjectRecompressor
import com.example.docscanner.util.PdfSecurityTools
import com.example.docscanner.util.SearchablePdfBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var historyAdapter: HistoryAdapter
    private var importingDialog: ProgressDialog? = null
    /** Which of the 3 compression approaches the user picked in [showCompressMethodPicker], kept
     *  as this small local enum (rather than reusing [PdfCompressor.TextCompressionMethod]
     *  directly) since DIRECT_EDIT doesn't correspond to a `PdfCompressor` method at all - it
     *  routes to `PdfObjectRecompressor` instead. See [compressExistingPdf]'s doc comment. */
    private enum class CompressChoice { SAFE, G4, DIRECT_EDIT }
    private var pendingCompressionMethod = CompressChoice.SAFE

    private val galleryPicker =
        registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(20)) { uris ->
            if (uris.isNotEmpty()) importGalleryImages(uris)
        }

    private val scanPdfPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { importPdfForScanning(it) }
        }

    private val einkPdfPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { importPdfForEink(it) }
        }

    private var searchableScript = OcrHelper.OcrScript.LATIN

    private val searchablePdfPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { makeSearchablePdf(it) }
        }

    private val backupCreator =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            uri?.let { runBackup(it) }
        }

    private val restorePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { runRestore(it) }
        }

    private val securityPdfPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { showSecurityMenu(it) }
        }

    private val compressPdfPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { compressExistingPdf(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        historyAdapter = HistoryAdapter(
            onClick = { file -> openTextResult(file) },
            onShare = { file -> shareFile(file) },
            onPrint = { file -> com.example.docscanner.util.PdfPrintAdapter.print(this, file) },
            onDelete = { file -> confirmDeleteHistoryFile(file) }
        )
        binding.rvHistory.layoutManager = LinearLayoutManager(this)
        binding.rvHistory.adapter = historyAdapter

        binding.cardToolProject.setOnClickListener {
            startActivity(Intent(this, ProjectHubActivity::class.java))
        }
        binding.cardToolScan.setOnClickListener { showScanSourcePicker() }
        binding.cardToolMerge.setOnClickListener {
            startActivity(Intent(this, PdfMergeActivity::class.java))
        }
        binding.cardToolPageManager.setOnClickListener {
            startActivity(Intent(this, PdfPageEditorActivity::class.java))
        }
        binding.cardToolEink.setOnClickListener {
            einkPdfPicker.launch(arrayOf("application/pdf"))
        }
        binding.cardToolEbook.setOnClickListener {
            ScanSessionManager.clear()
            startActivity(Intent(this, EbookExportActivity::class.java))
        }
        binding.cardToolCompress.setOnClickListener {
            showCompressMethodPicker()
        }
        binding.cardToolConvert.setOnClickListener {
            startActivity(Intent(this, ConvertDocumentActivity::class.java))
        }
        binding.cardToolAnnotate.setOnClickListener {
            startActivity(Intent(this, PdfAnnotateActivity::class.java))
        }
        setupAppLockSwitch()
        binding.cardToolBackup.setOnClickListener { showBackupDialog() }
        binding.cardToolSign.setOnClickListener {
            startActivity(Intent(this, PdfSignActivity::class.java))
        }
        binding.cardToolDecorate.setOnClickListener {
            startActivity(Intent(this, PdfDecorateActivity::class.java))
        }
        binding.cardToolTextEdit.setOnClickListener {
            startActivity(Intent(this, PdfTextEditActivity::class.java))
        }
        binding.cardToolSecurity.setOnClickListener {
            securityPdfPicker.launch(arrayOf("application/pdf"))
        }
        binding.cardToolSearchable.setOnClickListener {
            // ML Kit reads one script family per recognizer: ask which one before picking the file
            val scripts = OcrHelper.OcrScript.values()
            val labels = arrayOf(
                getString(R.string.ocr_script_latin), getString(R.string.ocr_script_chinese), getString(R.string.ocr_script_japanese),
                getString(R.string.ocr_script_korean), getString(R.string.ocr_script_devanagari)
            )
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(R.string.ocr_script_title)
                .setItems(labels) { _, which ->
                    searchableScript = scripts[which]
                    searchablePdfPicker.launch(arrayOf("application/pdf"))
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
        binding.tvLicensesLink.setOnClickListener {
            startActivity(Intent(this, LicensesActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshHistory()
        maybeOfferSessionRestore()
    }

    /** If a previous process left an unfinished, unexported scan session on disk (killed by the
     *  OS, crashed, phone restarted...) and this process doesn't already have one active in
     *  memory, ask whether to pick it back up instead of silently losing it. */
    private fun maybeOfferSessionRestore() {
        if (ScanSessionManager.pages.isNotEmpty()) return
        val count = ScanSessionManager.savedSessionPageCount()
        if (count <= 0) return
        AlertDialog.Builder(this)
            .setTitle(R.string.restore_session_title)
            .setMessage(getString(R.string.restore_session_message, count))
            .setCancelable(false)
            .setPositiveButton(R.string.restore_session_continue) { _, _ ->
                ScanSessionManager.restoreSavedSession()
                startActivity(Intent(this, PageListActivity::class.java))
            }
            .setNegativeButton(R.string.restore_session_discard) { _, _ ->
                ScanSessionManager.discardSavedSession()
            }
            .show()
    }

    private fun refreshHistory() {
        val dir = PdfExporter.exportDir(this)
        val allFiles = dir.listFiles { f -> f.isFile } ?: emptyArray()
        val pdfBaseNames = allFiles
            .filter { it.extension.equals("pdf", ignoreCase = true) }
            .map { it.nameWithoutExtension }
            .toSet()
        // A .txt is shown on its own only if it's a standalone ebook export, not the OCR
        // companion file that rides along with a same-named .pdf (that one opens from the PDF row).
        val displayFiles = allFiles.filter { f ->
            when (f.extension.lowercase()) {
                "pdf", "epub" -> true
                "txt" -> f.nameWithoutExtension !in pdfBaseNames
                else -> false
            }
        }.sortedByDescending { it.lastModified() }
        historyAdapter.submitList(displayFiles)
        binding.tvEmptyHistory.visibility = if (displayFiles.isEmpty()) View.VISIBLE else View.GONE
        binding.rvHistory.visibility = if (displayFiles.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun showScanSourcePicker() {
        val options = arrayOf(
            getString(R.string.source_camera),
            getString(R.string.source_gallery),
            getString(R.string.source_pdf)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.source_picker_title)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        ScanSessionManager.clear()
                        startActivity(Intent(this, CaptureActivity::class.java))
                    }
                    1 -> galleryPicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                    2 -> scanPdfPicker.launch(arrayOf("application/pdf"))
                }
            }
            .show()
    }

    private fun importGalleryImages(uris: List<Uri>) {
        setImporting(true)
        lifecycleScope.launch {
            val paths = withContext(Dispatchers.IO) {
                uris.mapIndexedNotNull { index, uri -> copyUriToFile(uri, index) }
            }
            setImporting(false)
            startCropQueue(paths)
        }
    }

    /** Renders every page of the chosen PDF at a known DPI (220) and sends them through the same
     *  crop/filter queue as gallery imports - but, unlike gallery imports, this source DOES have a
     *  real DPI, so it's passed through to [startCropQueue] to keep the PDF this session eventually
     *  exports to at the correct physical page size (see [PdfExporter]'s `ASSUMED_DPI` doc comment,
     *  and TECHNICAL_DOCS.md section 6/7 - this was the one remaining unfixed `ASSUMED_DPI` spot). */
    private fun importPdfForScanning(uri: Uri) {
        setImporting(true)
        lifecycleScope.launch {
            val paths = withContext(Dispatchers.IO) {
                PdfImportHelper.renderAllPagesToFiles(this@MainActivity, uri, dpi = 220)
            }
            setImporting(false)
            startCropQueue(paths, sourceDpi = 220f)
        }
    }

    /** [sourceDpi]: the known render DPI for every page in [paths], or `null` for a source with no
     *  "true" DPI (gallery photos - same convention as a camera capture). Carried through
     *  [PendingCropQueue] and the first image's Intent extra so `CropActivity` can stamp it onto
     *  every [ScanPage] it saves from this batch, including split-page halves. */
    private fun startCropQueue(paths: List<String>, sourceDpi: Float? = null) {
        if (paths.isEmpty()) {
            Toast.makeText(this, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
            return
        }
        ScanSessionManager.clear()
        PendingCropQueue.setAll(paths.drop(1), sourceDpi)
        val intent = Intent(this, CropActivity::class.java).apply {
            putExtra(CropActivity.EXTRA_IMAGE_PATH, paths.first())
            putExtra(CropActivity.EXTRA_QUEUE_MODE, true)
            if (sourceDpi != null) putExtra(CropActivity.EXTRA_SOURCE_DPI, sourceDpi)
        }
        startActivity(intent)
    }

    /** Bulk tool: renders every page straight into a session (no interactive crop - a digital
     *  PDF page is already flat) so the user can jump right to the bulk e-ink filter. Passes the
     *  actual render DPI (250, matching the call below) as each page's `sourceDpi` so the PDF this
     *  session eventually exports to keeps the correct physical page size - see
     *  `PdfExporter.ASSUMED_DPI`'s doc comment for why that matters. */
    private fun importPdfForEink(uri: Uri) {
        setImporting(true)
        lifecycleScope.launch {
            val paths = withContext(Dispatchers.IO) {
                PdfImportHelper.renderAllPagesToFiles(this@MainActivity, uri, dpi = 250)
            }
            setImporting(false)
            if (paths.isEmpty()) {
                Toast.makeText(this@MainActivity, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
                return@launch
            }
            ScanSessionManager.clear()
            paths.forEach { ScanSessionManager.addPage(ScanPage(ScanSessionManager.newPageId(), it, sourceDpi = 250f)) }
            startActivity(Intent(this@MainActivity, PageListActivity::class.java))
        }
    }

    private fun showCompressMethodPicker() {
        val options = listOf(
            CompressOptionsDialog.Option(
                title = getString(R.string.compress_method_safe),
                summary = getString(R.string.compress_option_safe_summary),
                pros = getString(R.string.compress_option_safe_pros),
                cons = getString(R.string.compress_option_safe_cons)
            ),
            CompressOptionsDialog.Option(
                title = getString(R.string.compress_method_g4),
                summary = getString(R.string.compress_option_g4_summary),
                pros = getString(R.string.compress_option_g4_pros),
                cons = getString(R.string.compress_option_g4_cons)
            ),
            CompressOptionsDialog.Option(
                title = getString(R.string.compress_method_direct_edit),
                summary = getString(R.string.compress_option_direct_edit_summary),
                pros = getString(R.string.compress_option_direct_edit_pros),
                cons = getString(R.string.compress_option_direct_edit_cons)
            )
        )
        CompressOptionsDialog.show(this, R.string.compress_method_title, options) { which ->
            pendingCompressionMethod = when (which) {
                1 -> CompressChoice.G4
                2 -> CompressChoice.DIRECT_EDIT
                else -> CompressChoice.SAFE
            }
            compressPdfPicker.launch(arrayOf("application/pdf"))
        }
    }

    /**
     * Standalone "Nén PDF" tool: the input can be ANY PDF the user picks, not necessarily one
     * this app scanned - unlike the Project flow's compress stage (`ProjectCompressActivity`),
     * which only ever compresses this app's own freshly-scanned images and is left untouched (see
     * TECHNICAL_DOCS.md). Offers 3 methods now (`showCompressMethodPicker`): the original 2
     * (`PdfCompressor` - rasterize every page, rebuild the PDF from scratch; fine for an
     * already-scanned PDF, HARMFUL for one with real vector text - see [fileLikelyHasRealText])
     * plus a newer 3rd ("Sửa trực tiếp") that edits the existing PDF's own embedded JPEG images in
     * place via PdfBox-Android (`PdfObjectRecompressor`), never touching real text/vector content at all -
     * see that class's own doc comment for the full picture, including its narrow, deliberate
     * scope and TECHNICAL_DOCS.md (phiên 11) for why the engine is PdfBox-Android (Apache 2.0)
     * rather than iText (AGPL / paid licence). [fileLikelyHasRealText]'s warning is skipped for that 3rd method - it exists to
     * protect against the other 2 rasterizing real text away, which the direct-edit method never
     * does in the first place.
     * After compressing (any of the 3 methods), if the result isn't actually smaller than the
     * original, the output is discarded and the user is told plainly instead of handing back a
     * "compressed" file that's worse than what they started with - a hard guarantee, not a
     * heuristic, and the same rule for all 3.
     */
    private fun compressExistingPdf(uri: Uri) {
        if (pendingCompressionMethod == CompressChoice.DIRECT_EDIT) {
            // This method never rasterizes real text away in the first place - the warning below
            // exists specifically to protect against the other 2 methods doing that, so it does
            // not apply here.
            runCompression(uri)
            return
        }
        lifecycleScope.launch {
            val looksLikeRealText = withContext(Dispatchers.IO) { fileLikelyHasRealText(uri) }
            if (looksLikeRealText) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(R.string.compress_text_warning_title)
                    .setMessage(R.string.compress_text_warning_message)
                    .setPositiveButton(R.string.compress_text_warning_continue) { _, _ -> runCompression(uri) }
                    .setNegativeButton(R.string.dialog_cancel, null)
                    .show()
            } else {
                runCompression(uri)
            }
        }
    }

    /** Best-effort, NOT real PDF parsing: just checks whether the raw file bytes contain the
     *  literal `/Font` dictionary key PDF producers write for any embedded font resource. A
     *  genuine scan (every page a photographed image, no fonts anywhere) will never contain this
     *  string; a text document almost always will, UNLESS its objects happen to be packed inside
     *  compressed object streams (common in some modern PDF producers) - in that case this misses
     *  it and simply skips the warning, same as if the check had never run. Skips the check
     *  entirely for very large files (>50MB) to avoid loading something huge into memory just for
     *  a heuristic. */
    private fun fileLikelyHasRealText(uri: Uri): Boolean {
        return try {
            val size = PdfImportHelper.fileSize(this, uri)
            if (size <= 0 || size > 50_000_000L) return false
            contentResolver.openInputStream(uri)?.use { input ->
                String(input.readBytes(), Charsets.ISO_8859_1).contains("/Font")
            } ?: false
        } catch (e: Exception) {
            false
        }
    }

    private fun runCompression(uri: Uri) {
        val method = pendingCompressionMethod
        if (method == CompressChoice.DIRECT_EDIT) {
            runDirectEditCompression(uri)
            return
        }
        val textMethod = if (method == CompressChoice.G4) {
            PdfCompressor.TextCompressionMethod.CCITT_G4
        } else {
            PdfCompressor.TextCompressionMethod.SAFE_DEFLATE
        }
        setImporting(true)
        lifecycleScope.launch {
            val originalSize = withContext(Dispatchers.IO) { PdfImportHelper.fileSize(this@MainActivity, uri) }
            val paths = withContext(Dispatchers.IO) {
                PdfImportHelper.renderAllPagesToFiles(this@MainActivity, uri, dpi = 250)
            }
            if (paths.isEmpty()) {
                setImporting(false)
                Toast.makeText(this@MainActivity, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
                return@launch
            }
            val outFile = File(PdfExporter.exportDir(this@MainActivity), "${FileUtils.defaultCompressedName()}.pdf")
            val result = withContext(Dispatchers.Default) {
                // paths here always came from rendering the picked PDF at 250dpi (just above) -
                // pass that real DPI through so the compressed page keeps the correct physical
                // size instead of coming out oversized (see PdfCompressor.ASSUMED_DPI's doc comment).
                PdfCompressor.compress(paths, outFile, originalSize, textMethod, assumedDpi = 250f) { done, total ->
                    runOnUiThread {
                        importingDialog?.setMessage(getString(R.string.compress_progress, done, total))
                    }
                }
            }
            paths.forEach { runCatching { File(it).delete() } }
            setImporting(false)
            if (result.compressedSize >= result.originalSize) {
                // Never hand back a "compressed" file that's actually not smaller - see the class
                // doc comment on compressExistingPdf(). Original file is untouched either way
                // (this tool only ever reads it, via SAF); only the failed output gets deleted.
                runCatching { outFile.delete() }
                Toast.makeText(this@MainActivity, getString(R.string.compress_no_benefit), Toast.LENGTH_LONG).show()
                return@launch
            }
            val ratioStr = String.format(Locale.getDefault(), "%.1f", result.ratio)
            Toast.makeText(
                this@MainActivity,
                getString(
                    R.string.compress_success,
                    FileUtils.humanFileSize(result.originalSize),
                    FileUtils.humanFileSize(result.compressedSize),
                    ratioStr
                ),
                Toast.LENGTH_LONG
            ).show()
            refreshHistory()
        }
    }

    /** "Sửa trực tiếp" - see [PdfObjectRecompressor]'s own doc comment for the full picture. This
     *  never renders anything (no [PdfImportHelper] call at all) - the DPI-mismatch concern that
     *  matters for the other 2 methods (see [PdfCompressor.ASSUMED_DPI]) simply does not apply
     *  here, since the page objects themselves - MediaBox included - are never touched. */
    private fun runDirectEditCompression(uri: Uri) {
        setImporting(true)
        lifecycleScope.launch {
            val srcFile = withContext(Dispatchers.IO) { copyUriToTempPdfFile(uri) }
            if (srcFile == null) {
                setImporting(false)
                Toast.makeText(this@MainActivity, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
                return@launch
            }
            val originalSize = srcFile.length()
            val outFile = File(PdfExporter.exportDir(this@MainActivity), "${FileUtils.defaultCompressedName()}.pdf")
            val result = runCatching {
                withContext(Dispatchers.Default) {
                    PdfObjectRecompressor.recompress(srcFile, outFile) { done, total ->
                        runOnUiThread {
                            importingDialog?.setMessage(getString(R.string.compress_progress, done, total))
                        }
                    }
                }
            }
            runCatching { srcFile.delete() }
            setImporting(false)
            val recompressResult = result.getOrNull()
            if (recompressResult == null) {
                // The PDF itself couldn't even be opened/parsed by PdfBox - leave the user with a
                // plain, honest failure message rather than a half-written or misleading output.
                runCatching { outFile.delete() }
                Toast.makeText(this@MainActivity, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
                return@launch
            }
            val compressedSize = outFile.length()
            if (compressedSize >= originalSize || compressedSize <= 0) {
                runCatching { outFile.delete() }
                Toast.makeText(this@MainActivity, getString(R.string.compress_no_benefit), Toast.LENGTH_LONG).show()
                return@launch
            }
            val ratioStr = String.format(Locale.getDefault(), "%.1f", originalSize.toDouble() / compressedSize)
            Toast.makeText(
                this@MainActivity,
                getString(
                    R.string.compress_direct_edit_success,
                    FileUtils.humanFileSize(originalSize),
                    FileUtils.humanFileSize(compressedSize),
                    ratioStr,
                    recompressResult.imagesRecompressed,
                    recompressResult.imagesRecompressed + recompressResult.imagesSkipped
                ) + if (recompressResult.structureOptimized) getString(R.string.compress_structure_note) else "",
                Toast.LENGTH_LONG
            ).show()
            refreshHistory()
        }
    }

    /** What to do with the picked PDF: set a password, remove one, or stamp a text watermark. */
    private fun showSecurityMenu(uri: Uri) {
        val labels = arrayOf(
            getString(R.string.security_set_password),
            getString(R.string.security_remove_password),
            getString(R.string.security_watermark),
            getString(R.string.security_edit_info),
            getString(R.string.security_strip_info)
        )
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.tool_security_title)
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> askText(R.string.security_set_password, R.string.security_password_hint, secret = true) { runSecurity(uri, SecurityAction.PROTECT, it) }
                    1 -> askText(R.string.security_remove_password, R.string.security_password_hint, secret = true) { runSecurity(uri, SecurityAction.UNPROTECT, it) }
                    2 -> askText(R.string.security_watermark, R.string.security_watermark_hint, secret = false) { runSecurity(uri, SecurityAction.WATERMARK, it) }
                    3 -> runMetadata(uri, strip = false)
                    else -> runMetadata(uri, strip = true)
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---- PDF properties (title/author/subject/keywords) - see util.PdfMetadataTools ----

    private fun runMetadata(uri: Uri, strip: Boolean) {
        setImporting(true)
        lifecycleScope.launch {
            val src = withContext(Dispatchers.IO) { copyUriToTempPdfFile(uri) }
            if (src == null) {
                setImporting(false)
                Toast.makeText(this@MainActivity, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
                return@launch
            }
            if (strip) {
                applyMetadata(src, null)
                return@launch
            }
            val info = runCatching {
                withContext(Dispatchers.IO) { com.example.docscanner.util.PdfMetadataTools.read(src) }
            }
            setImporting(false)
            val current = info.getOrNull()
            if (current == null) {
                runCatching { src.delete() }
                val encrypted = info.exceptionOrNull()?.message == "encrypted"
                Toast.makeText(this@MainActivity, if (encrypted) R.string.sign_encrypted else R.string.metadata_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            showMetadataDialog(src, current)
        }
    }

    private fun showMetadataDialog(src: File, current: com.example.docscanner.util.PdfMetadataTools.Info) {
        val pad = (20 * resources.displayMetrics.density).toInt()
        fun field(hint: Int, value: String) = android.widget.EditText(this).apply {
            setHint(hint)
            setText(value)
            setSingleLine()
        }
        val title = field(R.string.metadata_title, current.title)
        val author = field(R.string.metadata_author, current.author)
        val subject = field(R.string.metadata_subject, current.subject)
        val keywords = field(R.string.metadata_keywords, current.keywords)
        val column = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            listOf(title, author, subject, keywords).forEach { addView(it) }
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.security_edit_info)
            .setView(android.widget.ScrollView(this).apply { addView(column) })
            .setNegativeButton(R.string.dialog_cancel) { _, _ -> runCatching { src.delete() } }
            .setOnCancelListener { runCatching { src.delete() } }
            .setPositiveButton(R.string.dialog_ok) { _, _ ->
                applyMetadata(
                    src,
                    com.example.docscanner.util.PdfMetadataTools.Info(
                        title.text.toString(), author.text.toString(), subject.text.toString(), keywords.text.toString()
                    )
                )
            }
            .show()
    }

    /** [info] null = remove all document labels. Deletes [src] when done either way. */
    private fun applyMetadata(src: File, info: com.example.docscanner.util.PdfMetadataTools.Info?) {
        setImporting(true)
        val prefix = if (info == null) "clean" else "info"
        val outFile = File(PdfExporter.exportDir(this), "${FileUtils.defaultSecurityName(prefix)}.pdf")
        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.Default) {
                    if (info == null) com.example.docscanner.util.PdfMetadataTools.strip(src, outFile)
                    else com.example.docscanner.util.PdfMetadataTools.write(src, outFile, info)
                }
            }
            runCatching { src.delete() }
            setImporting(false)
            if (result.isFailure) {
                runCatching { outFile.delete() }
                val encrypted = result.exceptionOrNull()?.message == "encrypted"
                Toast.makeText(this@MainActivity, if (encrypted) R.string.sign_encrypted else R.string.metadata_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            Toast.makeText(this@MainActivity, getString(R.string.metadata_done, outFile.name), Toast.LENGTH_LONG).show()
            refreshHistory()
        }
    }

    private fun askText(title: Int, hint: Int, secret: Boolean, onOk: (String) -> Unit) {
        val input = android.widget.EditText(this).apply {
            setHint(hint)
            inputType = if (secret) {
                android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            } else android.text.InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = android.widget.FrameLayout(this).apply { setPadding(pad, pad / 2, pad, 0); addView(input) }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setView(holder)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val text = input.text.toString()
                if (text.isBlank()) Toast.makeText(this, R.string.security_empty_input, Toast.LENGTH_SHORT).show() else onOk(text)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private enum class SecurityAction(val prefix: String) { PROTECT("protected"), UNPROTECT("unlocked"), WATERMARK("watermark") }

    private fun runSecurity(uri: Uri, action: SecurityAction, text: String) {
        setImporting(true)
        lifecycleScope.launch {
            val srcFile = withContext(Dispatchers.IO) { copyUriToTempPdfFile(uri) }
            if (srcFile == null) {
                setImporting(false)
                Toast.makeText(this@MainActivity, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
                return@launch
            }
            val outFile = File(PdfExporter.exportDir(this@MainActivity), "${FileUtils.defaultSecurityName(action.prefix)}.pdf")
            val result = runCatching {
                withContext(Dispatchers.Default) {
                    when (action) {
                        SecurityAction.PROTECT -> PdfSecurityTools.protect(srcFile, outFile, text)
                        SecurityAction.UNPROTECT -> PdfSecurityTools.unprotect(srcFile, outFile, text)
                        SecurityAction.WATERMARK -> PdfSecurityTools.watermark(srcFile, outFile, text)
                    }
                }
            }
            runCatching { srcFile.delete() }
            setImporting(false)
            val pages = result.getOrNull()
            if (pages == null) {
                runCatching { outFile.delete() }
                val wrong = result.exceptionOrNull() is PdfSecurityTools.WrongPassword
                Toast.makeText(
                    this@MainActivity,
                    getString(if (wrong) R.string.security_wrong_password else R.string.security_failed),
                    Toast.LENGTH_LONG
                ).show()
                return@launch
            }
            Toast.makeText(
                this@MainActivity,
                getString(
                    when (action) {
                        SecurityAction.PROTECT -> R.string.security_done_protect
                        SecurityAction.UNPROTECT -> R.string.security_done_unprotect
                        SecurityAction.WATERMARK -> R.string.security_done_watermark
                    },
                    pages
                ),
                Toast.LENGTH_LONG
            ).show()
            refreshHistory()
        }
    }

    /**
     * "PDF tìm kiếm được" - OCR every page that has no real text and lays an invisible text layer over
     * it (see [SearchablePdfBuilder]'s doc comment). The source PDF is only read; the result goes to the
     * export folder like every other tool's output, and a result that ended up with no text layer at all
     * is deleted instead of being handed back as if it were something new.
     */
    private fun makeSearchablePdf(uri: Uri) {
        setImporting(true)
        lifecycleScope.launch {
            val srcFile = withContext(Dispatchers.IO) { copyUriToTempPdfFile(uri) }
            if (srcFile == null) {
                setImporting(false)
                Toast.makeText(this@MainActivity, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
                return@launch
            }
            val outFile = File(PdfExporter.exportDir(this@MainActivity), "${FileUtils.defaultSearchableName()}.pdf")
            val result = runCatching {
                withContext(Dispatchers.Default) {
                    SearchablePdfBuilder.build(srcFile, outFile, searchableScript) { done, total ->
                        runOnUiThread {
                            importingDialog?.setMessage(getString(R.string.searchable_progress, done, total))
                        }
                    }
                }
            }
            runCatching { srcFile.delete() }
            setImporting(false)
            val r = result.getOrNull()
            if (r == null) {
                runCatching { outFile.delete() }
                Toast.makeText(this@MainActivity, getString(R.string.searchable_failed), Toast.LENGTH_LONG).show()
                return@launch
            }
            if (r.pagesOcr == 0) {
                // Nothing was added: do not leave a copy of the input lying around as a "new" file.
                runCatching { outFile.delete() }
                val msg = if (r.pagesSkippedHadText > 0 && r.pagesWithoutText == 0) R.string.searchable_all_have_text
                else R.string.searchable_nothing
                Toast.makeText(this@MainActivity, getString(msg), Toast.LENGTH_LONG).show()
                return@launch
            }
            val sb = StringBuilder(getString(R.string.searchable_success, r.pagesOcr, r.words))
            if (r.pagesSkippedHadText > 0) sb.append(getString(R.string.searchable_skipped_suffix, r.pagesSkippedHadText))
            if (r.structureOptimized) sb.append(getString(R.string.compress_structure_note))
            val check = r.extractionCheckPercent
            if (check != null) {
                sb.append(
                    if (check >= 70) getString(R.string.searchable_check_ok, check)
                    else getString(R.string.searchable_check_low, check)
                )
            }
            Toast.makeText(this@MainActivity, sb.toString(), Toast.LENGTH_LONG).show()
            refreshHistory()
        }
    }

    /** PdfBox's PDDocument.load(File) needs a real file path to read from (unlike the rest of this app, which mostly reads
     *  SAF [Uri]s straight via [android.content.ContentResolver]) - copies the picked PDF into the
     *  app's own temp dir first. Deleted right after [runDirectEditCompression] finishes with it. */
    private fun copyUriToTempPdfFile(uri: Uri): File? {
        return try {
            val file = File(FileUtils.tempDir(this), "COMPRESS_SRC_${System.currentTimeMillis()}.pdf")
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            } ?: return null
            file
        } catch (e: Exception) {
            null
        }
    }

    private fun copyUriToFile(uri: Uri, index: Int): String? {
        return try {
            val file = FileUtils.newImportedFile(this, index)
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            }
            file.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    private fun setImporting(show: Boolean) {
        if (show) {
            importingDialog = ProgressDialog.show(this, null, getString(R.string.importing_progress), true, false)
        } else {
            importingDialog?.dismiss()
            importingDialog = null
        }
    }

    /**
     * The "Khoá ứng dụng" switch. Turning it ON needs a screen lock or a biometric on the device (otherwise nothing
     * could ever answer the prompt) and a successful authentication first, so the user knows it works before it can
     * lock them out; turning it OFF needs an authentication too, so someone who merely picks up an unlocked phone
     * cannot remove the protection. [lockSwitchBusy] stops the programmatic revert from re-triggering the listener.
     */
    private var lockSwitchBusy = false

    private fun setupAppLockSwitch() {
        binding.switchAppLock.isChecked = com.example.docscanner.util.AppLock.isEnabled(this)
        binding.switchAppLock.setOnCheckedChangeListener { button, checked ->
            if (lockSwitchBusy) return@setOnCheckedChangeListener
            fun revert(to: Boolean) {
                lockSwitchBusy = true
                button.isChecked = to
                lockSwitchBusy = false
            }
            if (checked) {
                if (!com.example.docscanner.util.AppLock.isSupported(this)) {
                    Toast.makeText(this, R.string.lock_not_supported, Toast.LENGTH_LONG).show()
                    revert(false)
                    return@setOnCheckedChangeListener
                }
                com.example.docscanner.util.AppLock.authenticate(this, getString(R.string.lock_enable_prompt)) { ok ->
                    if (ok) {
                        com.example.docscanner.util.AppLock.setEnabled(this, true)
                        com.example.docscanner.util.AppLock.markUnlocked()
                        window.setFlags(
                            android.view.WindowManager.LayoutParams.FLAG_SECURE,
                            android.view.WindowManager.LayoutParams.FLAG_SECURE
                        )
                    } else {
                        revert(false)
                    }
                }
            } else {
                com.example.docscanner.util.AppLock.authenticate(this, getString(R.string.lock_disable_prompt)) { ok ->
                    if (ok) {
                        com.example.docscanner.util.AppLock.setEnabled(this, false)
                        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
                    } else {
                        revert(true)
                    }
                }
            }
        }
    }

    // ---- backup / restore (see util.BackupManager for what is and is not included, and why) ----

    private fun showBackupDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.backup_dialog_title)
            .setMessage(R.string.backup_dialog_message)
            .setPositiveButton(R.string.backup_action_backup) { _, _ ->
                backupCreator.launch("docscanner_backup_${FileUtils.defaultDocName().removePrefix("scan_")}.zip")
            }
            .setNeutralButton(R.string.backup_action_restore) { _, _ ->
                restorePicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun runBackup(uri: Uri) {
        setImporting(true)
        lifecycleScope.launch {
            val count = runCatching {
                withContext(Dispatchers.IO) {
                    val out = contentResolver.openOutputStream(uri) ?: throw java.io.IOException("no stream")
                    com.example.docscanner.util.BackupManager.backup(this@MainActivity, out)
                }
            }
            setImporting(false)
            val n = count.getOrNull()
            when {
                n == null -> {
                    runCatching { android.provider.DocumentsContract.deleteDocument(contentResolver, uri) }   // do not leave a half ZIP behind
                    Toast.makeText(this@MainActivity, R.string.backup_failed, Toast.LENGTH_LONG).show()
                }
                n == 0 -> Toast.makeText(this@MainActivity, R.string.backup_empty, Toast.LENGTH_LONG).show()
                else -> Toast.makeText(this@MainActivity, getString(R.string.backup_done, n), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun runRestore(uri: Uri) {
        setImporting(true)
        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val input = contentResolver.openInputStream(uri) ?: throw java.io.IOException("no stream")
                    com.example.docscanner.util.BackupManager.restore(this@MainActivity, input)
                }
            }
            setImporting(false)
            val r = result.getOrNull()
            if (r == null) {
                val notBackup = result.exceptionOrNull() is IllegalArgumentException
                Toast.makeText(this@MainActivity, if (notBackup) R.string.restore_not_backup else R.string.restore_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            Toast.makeText(this@MainActivity, getString(R.string.restore_done, r.written, r.skipped, r.rejected), Toast.LENGTH_LONG).show()
            refreshHistory()
        }
    }

    private fun shareFile(file: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val mime = when (file.extension.lowercase()) {
            "pdf" -> "application/pdf"
            "epub" -> "application/epub+zip"
            else -> "text/plain"
        }
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.action_share)))
    }

    private fun confirmDeleteHistoryFile(file: File) {
        val companionTxt = File(file.parentFile, file.nameWithoutExtension + ".txt")
        // Deleting a PDF also silently cleans up its OCR .txt sidecar - that one is deliberately
        // hidden from the history list (see refreshHistory()), so nothing the user can see
        // disappears unexpectedly. An ebook's EPUB+TXT pair shares the same base name too, but
        // BOTH are shown as their own separate rows - so deleting the EPUB row would otherwise
        // make a second, still-visible row vanish with no warning. Only that case needs calling
        // out explicitly (see TECHNICAL_DOCS.md §6).
        val warnAboutPair = file.extension.equals("epub", ignoreCase = true) &&
            companionTxt.exists() && companionTxt.absolutePath != file.absolutePath
        val message = if (warnAboutPair) {
            getString(R.string.confirm_delete_file_with_txt_pair, file.name, companionTxt.name)
        } else {
            getString(R.string.confirm_delete_file, file.name)
        }
        AlertDialog.Builder(this)
            .setMessage(message)
            .setPositiveButton(R.string.dialog_yes) { _, _ ->
                file.delete()
                companionTxt.delete()
                refreshHistory()
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun openTextResult(file: File) {
        when (file.extension.lowercase()) {
            "pdf" -> {
                val txtFile = File(file.parentFile, file.nameWithoutExtension + ".txt")
                if (!txtFile.exists()) {
                    Toast.makeText(this, R.string.no_text_found, Toast.LENGTH_SHORT).show()
                    return
                }
                startActivity(Intent(this, TextResultActivity::class.java).apply {
                    putExtra(TextResultActivity.EXTRA_TEXT_FILE_PATH, txtFile.absolutePath)
                })
            }
            "txt" -> {
                startActivity(Intent(this, TextResultActivity::class.java).apply {
                    putExtra(TextResultActivity.EXTRA_TEXT_FILE_PATH, file.absolutePath)
                })
            }
            else -> {
                // .epub - nothing to preview in-app; share/open it with a reading app instead.
                shareFile(file)
            }
        }
    }
}
