package com.example.docscanner.model

import org.json.JSONArray
import org.json.JSONObject

/**
 * The mandatory stages of a "Dự án" (Project), in order - see `ProjectManager` and
 * TECHNICAL_DOCS.md for the full picture. A project always moves forward through every stage in
 * this exact order; there is no skipping one. What's optional is *within* a stage (which scan
 * preset, which compression method, whether to bother with a table of contents at all) - the
 * already-existing standalone tools (page manager, merge, convert...) are untouched and still
 * reachable on their own for anyone who just wants a single one-off operation instead of the full
 * pipeline.
 */
enum class ProjectStage {
    PICK_IMAGES, EDIT_IMAGES, SCAN, EXPORT_PDF, COMPRESS, OCR, EBOOK, DONE
}

/** One working page image, from EDIT_IMAGES onward. Rotation is kept separate from the pixels
 *  (same reasoning as `PdfPageItem`) so re-rotating never re-compresses a JPEG repeatedly. */
data class ProjectPage(var path: String, var rotationDeg: Int = 0)

/** One table-of-contents entry: a chapter title and which of the project's pages (0-based) it
 *  starts on. See `TocDetector` for how these are first suggested, and `ProjectExportPdfActivity`
 *  for where the user reviews/corrects them before they become real PDF bookmarks. */
data class ProjectTocEntry(var title: String, var pageIndex: Int)

class Project(
    val id: String,
    var name: String,
    var stage: ProjectStage = ProjectStage.PICK_IMAGES,
    /** Raw, not-yet-cropped images still waiting in the EDIT_IMAGES queue (see
     *  `FileUtils.projectRawDir`). Draining into [pages] one at a time as the user gets through
     *  them is what lets EDIT_IMAGES resume mid-queue instead of restarting the whole batch. */
    var pendingRawPaths: MutableList<String> = mutableListOf(),
    var pages: MutableList<ProjectPage> = mutableListOf(),
    var scanPresetLabel: String? = null,
    var pdfPath: String? = null,
    var wantToc: Boolean = false,
    var tocEntries: MutableList<ProjectTocEntry> = mutableListOf(),
    var compressMethodLabel: String? = null,
    var compressedPdfPath: String? = null,
    var ocrTextPath: String? = null,
    var ebookPaths: MutableList<String> = mutableListOf(),
    var createdAt: Long = System.currentTimeMillis(),
    var updatedAt: Long = System.currentTimeMillis()
) {

    fun toJson(): JSONObject {
        val obj = JSONObject()
        obj.put("id", id)
        obj.put("name", name)
        obj.put("stage", stage.name)
        obj.put("pendingRawPaths", JSONArray(pendingRawPaths))
        obj.put("pages", JSONArray().apply {
            pages.forEach { p -> put(JSONObject().put("path", p.path).put("rotation", p.rotationDeg)) }
        })
        obj.put("scanPresetLabel", scanPresetLabel ?: JSONObject.NULL)
        obj.put("pdfPath", pdfPath ?: JSONObject.NULL)
        obj.put("wantToc", wantToc)
        obj.put("tocEntries", JSONArray().apply {
            tocEntries.forEach { t -> put(JSONObject().put("title", t.title).put("pageIndex", t.pageIndex)) }
        })
        obj.put("compressMethodLabel", compressMethodLabel ?: JSONObject.NULL)
        obj.put("compressedPdfPath", compressedPdfPath ?: JSONObject.NULL)
        obj.put("ocrTextPath", ocrTextPath ?: JSONObject.NULL)
        obj.put("ebookPaths", JSONArray(ebookPaths))
        obj.put("createdAt", createdAt)
        obj.put("updatedAt", updatedAt)
        return obj
    }

    companion object {

        private fun JSONObject.stringOrNull(key: String): String? =
            if (has(key) && !isNull(key)) getString(key) else null

        fun fromJson(obj: JSONObject): Project {
            val pendingRaw = mutableListOf<String>()
            obj.optJSONArray("pendingRawPaths")?.let { arr ->
                for (i in 0 until arr.length()) pendingRaw.add(arr.getString(i))
            }
            val pages = mutableListOf<ProjectPage>()
            obj.optJSONArray("pages")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val p = arr.getJSONObject(i)
                    pages.add(ProjectPage(p.getString("path"), p.optInt("rotation", 0)))
                }
            }
            val tocEntries = mutableListOf<ProjectTocEntry>()
            obj.optJSONArray("tocEntries")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val t = arr.getJSONObject(i)
                    tocEntries.add(ProjectTocEntry(t.getString("title"), t.optInt("pageIndex", 0)))
                }
            }
            val ebookPaths = mutableListOf<String>()
            obj.optJSONArray("ebookPaths")?.let { arr ->
                for (i in 0 until arr.length()) ebookPaths.add(arr.getString(i))
            }
            return Project(
                id = obj.getString("id"),
                name = obj.optString("name", obj.getString("id")),
                stage = runCatching { ProjectStage.valueOf(obj.optString("stage")) }
                    .getOrDefault(ProjectStage.PICK_IMAGES),
                pendingRawPaths = pendingRaw,
                pages = pages,
                scanPresetLabel = obj.stringOrNull("scanPresetLabel"),
                pdfPath = obj.stringOrNull("pdfPath"),
                wantToc = obj.optBoolean("wantToc", false),
                tocEntries = tocEntries,
                compressMethodLabel = obj.stringOrNull("compressMethodLabel"),
                compressedPdfPath = obj.stringOrNull("compressedPdfPath"),
                ocrTextPath = obj.stringOrNull("ocrTextPath"),
                ebookPaths = ebookPaths,
                createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
            )
        }
    }
}
