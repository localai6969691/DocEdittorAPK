package com.example.docscanner.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object FileUtils {

    private fun timestamp(): String =
        SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())

    /** Committed session pages live in internal *files* storage, not cache - the OS can clear
     *  the cache dir at any time under storage pressure, which would silently break session
     *  backup/restore (see ScanSessionManager). Raw/transient captures below stay in cache since
     *  they're normally consumed and deleted within the same short flow anyway. */
    fun sessionPagesDir(context: Context): File {
        val dir = File(context.filesDir, "session_pages")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun capturesDir(context: Context): File {
        val dir = File(context.cacheDir, "captures")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun importedDir(context: Context): File {
        val dir = File(context.cacheDir, "imported")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun tempDir(context: Context): File {
        val dir = File(context.cacheDir, "temp")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /** Durable (survives process death / OS cache clears - unlike [importedDir]) working
     *  directory for pages rendered inside the PDF page-manager tool, so an in-progress
     *  rotate/reorder/delete session can be persisted and restored the same way
     *  [sessionPagesDir] backs up the scan session. See `model.PdfEditorState` and
     *  TECHNICAL_DOCS.md (backup/restore section) for the rest of the picture. */
    fun pdfEditorPagesDir(context: Context): File {
        val dir = File(context.filesDir, "pdf_editor_pages")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /** Durable home for `PdfTextEditActivity`'s source PDF copy + its backup/restore state JSON
     *  (`model.PdfTextEditState`) - must be *files* storage, not cache, for the same reason as
     *  [pdfEditorPagesDir]: a restore needs the exact source bytes still there later, and the OS
     *  can clear `cacheDir` at any time regardless of whether the app is still running. */
    fun textEditSourceDir(context: Context): File {
        val dir = File(context.filesDir, "text_edit_source")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /** Durable working directory for pages imported directly (via file picker, not via
     *  [com.example.docscanner.model.ScanSessionManager]) inside the ebook editor tool - same
     *  reasoning as [pdfEditorPagesDir]. See `model.EbookEditorState`. */
    fun ebookImportDir(context: Context): File {
        val dir = File(context.filesDir, "ebook_import")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /** Root of all "Dự án" (Project) storage - one subdirectory per project, named by
     *  [com.example.docscanner.model.Project.id]. Everything under here is durable (`filesDir`,
     *  not cache) since a project is explicitly meant to survive being closed and reopened days
     *  later - see `model.ProjectManager` and TECHNICAL_DOCS.md. */
    fun projectsRootDir(context: Context): File {
        val dir = File(context.filesDir, "projects")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun projectDir(context: Context, projectId: String): File {
        val dir = File(projectsRootDir(context), projectId)
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /** Raw, not-yet-cropped images for a project (fresh camera captures / gallery picks waiting
     *  in the edit queue - see `model.Project.pendingRawPaths`). */
    fun projectRawDir(context: Context, projectId: String): File {
        val dir = File(projectDir(context, projectId), "raw")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    /** Cropped/split/scanned working pages for a project (see `model.Project.pages`) - this is
     *  what every later stage (export/compress/OCR/ebook) reads from. */
    fun projectPagesDir(context: Context, projectId: String): File {
        val dir = File(projectDir(context, projectId), "pages")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun newProjectRawFile(context: Context, projectId: String, index: Int): File =
        File(projectRawDir(context, projectId), "RAW_${timestamp()}_$index.jpg")

    fun newProjectPageFile(context: Context, projectId: String, index: Int): File =
        File(projectPagesDir(context, projectId), "PAGE_${timestamp()}_$index.jpg")

    fun newCaptureFile(context: Context): File =
        File(capturesDir(context), "IMG_${timestamp()}.jpg")

    /** Temp file for the 2nd half of a photo split into 2 pages - conceptually a fresh "source"
     *  image awaiting its own crop/filter cycle, just like a camera capture. */
    fun newSplitPageFile(context: Context): File =
        File(capturesDir(context), "SPLIT_${timestamp()}.jpg")

    fun newSessionPageFile(context: Context): File =
        File(sessionPagesDir(context), "PAGE_${timestamp()}.jpg")

    fun newImportedFile(context: Context, index: Int): File =
        File(importedDir(context), "IMPORT_${timestamp()}_$index.jpg")

    fun newPdfEditorPageFile(context: Context, index: Int): File =
        File(pdfEditorPagesDir(context), "EDITPAGE_${timestamp()}_$index.jpg")

    fun newEbookImportFile(context: Context, index: Int): File =
        File(ebookImportDir(context), "EBOOKIMPORT_${timestamp()}_$index.jpg")

    /** Durable working directory for the "Chú thích PDF" tool's rendered pages (external-PDF mode
     *  only - the single-scanned-page mode, opened from `PageListActivity`, reuses
     *  [sessionPagesDir] like any other saved scan page, since its result becomes a first-class
     *  session page going forward, not a throwaway working copy). No backup/restore across
     *  process death for this tool yet (see TECHNICAL_DOCS.md, "Giới hạn đã biết" for
     *  `PdfAnnotateActivity`) - `filesDir` is still used rather than cache purely so an in-progress
     *  multi-page session isn't at risk of the OS reclaiming cache space mid-edit, same reasoning
     *  as [pdfEditorPagesDir], not because this one persists across restarts today. */
    fun annotatePagesDir(context: Context): File {
        val dir = File(context.filesDir, "annotate_pages")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun newAnnotatePageFile(context: Context, index: Int): File =
        File(annotatePagesDir(context), "ANNOTATE_${timestamp()}_$index.jpg")

    fun defaultDocName(): String = "scan_${timestamp()}"

    fun defaultEbookName(): String = "ebook_${timestamp()}"

    fun defaultCompressedName(): String = "compressed_${timestamp()}"

    fun defaultSearchableName(): String = "searchable_${timestamp()}"

    fun defaultSecurityName(kind: String): String = "${kind}_${timestamp()}"

    fun defaultConvertedName(): String = "converted_${timestamp()}"

    fun humanFileSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format(Locale.getDefault(), "%.0f KB", kb)
        val mb = kb / 1024.0
        return String.format(Locale.getDefault(), "%.1f MB", mb)
    }

    /** Decodes [path] downsampled to roughly [reqWidth]x[reqHeight] - avoids loading full-res
     *  scan images just to show a small RecyclerView thumbnail. */
    fun decodeSampledBitmap(path: String, reqWidth: Int, reqHeight: Int): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

        var sample = 1
        val halfHeight = bounds.outHeight / 2
        val halfWidth = bounds.outWidth / 2
        while (halfHeight / sample >= reqHeight && halfWidth / sample >= reqWidth) {
            sample *= 2
        }

        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(path, opts)
    }

    /**
     * Decodes the full-resolution bitmap at [path] and applies its EXIF orientation, if any.
     * Camera photos (and photos copied from the gallery) are very often saved with the pixel
     * data in the sensor's native orientation plus an EXIF rotation tag rather than physically
     * rotated - [BitmapFactory] alone ignores that tag, so a plain decode can come out sideways.
     * PDF-rendered pages have no such tag, so this is a safe no-op for them.
     */
    fun decodeBitmapWithExifOrientation(path: String): Bitmap? {
        val bitmap = BitmapFactory.decodeFile(path) ?: return null
        val orientation = try {
            ExifInterface(path).getAttributeInt(
                ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
            )
        } catch (e: Exception) {
            ExifInterface.ORIENTATION_NORMAL
        }

        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> {
                matrix.postRotate(90f)
                matrix.postScale(-1f, 1f)
            }
            ExifInterface.ORIENTATION_TRANSVERSE -> {
                matrix.postRotate(270f)
                matrix.postScale(-1f, 1f)
            }
            else -> return bitmap
        }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        if (rotated !== bitmap) bitmap.recycle()
        return rotated
    }

    /** Copies the content at [uri] into a fresh temp file under a generic "temp" cache dir, with
     *  [suffix] appended to the generated name (e.g. ".epub", ".txt") so downstream code that
     *  cares about file extension (like [java.util.zip.ZipFile] for EPUB) can rely on it. */
    fun copyUriToTempFile(context: Context, uri: Uri, suffix: String): File? {
        return try {
            val file = File(tempDir(context), "IN_${timestamp()}$suffix")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            } ?: return null
            file
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Deletes files older than [maxAgeMillis] (default 24h) under the app's *transient* cache
     * directories - [capturesDir], [importedDir], [tempDir]. These were never cleaned up before
     * (see TECHNICAL_DOCS.md §6): each is only meant to hold files for the duration of a single
     * short-lived flow (capture-then-crop, PDF-import-then-process, etc.), but nothing ever
     * removed them afterwards, so they'd only ever grow until Android decided to clear the whole
     * cache under storage pressure. Meant to be called once per app process start (see
     * [com.example.docscanner.DocScannerApp]). Deliberately only ever touches these 3 cache
     * dirs - never [sessionPagesDir]/[pdfEditorPagesDir]/[ebookImportDir]/[projectsRootDir], which
     * live in *files* storage specifically so nothing (including this function) sweeps them away
     * underneath an in-progress, not-yet-exported session. Best-effort: a file that's mid-write or
     * otherwise briefly unreadable just gets skipped over, never causes a crash.
     */
    fun cleanOldCacheFiles(context: Context, maxAgeMillis: Long = 24L * 60 * 60 * 1000) {
        val now = System.currentTimeMillis()
        listOf(capturesDir(context), importedDir(context), tempDir(context)).forEach { dir ->
            runCatching {
                dir.listFiles()?.forEach { f ->
                    if (f.isFile && now - f.lastModified() > maxAgeMillis) {
                        runCatching { f.delete() }
                    }
                }
            }
        }
    }

    fun mimeTypeFor(file: File): String = when (file.extension.lowercase()) {
        "pdf" -> "application/pdf"
        "epub" -> "application/epub+zip"
        else -> "text/plain"
    }

    /** Opens [file] with whatever app the device has for its type (PDF viewer, EPUB reader,
     *  text viewer...) via a plain `ACTION_VIEW`. Used by [com.example.docscanner.ProjectSummaryActivity]
     *  to let the user jump straight into a finished artifact. Silently does nothing if no app on
     *  the device can handle it - the caller already offers Share as a fallback way to get the
     *  file out, so there's no good in-app message to show here either. */
    fun openFile(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeTypeFor(file))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        runCatching { context.startActivity(intent) }
    }

    /** Same share-sheet mechanism as `MainActivity.shareFile` (kept separate rather than having
     *  that one delegate here, to avoid touching an already-working screen for this) - a second,
     *  reusable copy for [com.example.docscanner.ProjectSummaryActivity]. */
    fun shareFile(context: Context, file: File, chooserTitle: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeTypeFor(file)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, chooserTitle))
    }
}
