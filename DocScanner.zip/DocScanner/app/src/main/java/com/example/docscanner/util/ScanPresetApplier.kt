package com.example.docscanner.util

import android.graphics.Bitmap

/**
 * The 7 "how should this page look" presets, extracted out of `PageListActivity`'s bulk-filter
 * tool (originally private there) so the Project flow's mandatory "Scan" stage
 * (`ProjectScanActivity`) can apply the exact same processing instead of a second copy that could
 * quietly drift out of sync. See TECHNICAL_DOCS.md for the full picture.
 */
object ScanPresetApplier {

    enum class Preset { ORIGINAL, ENHANCE, GRAY, BW, EINK_TEXT, EINK_COLOR, AUTO }

    /** Running tally for [Preset.AUTO], so a caller can show a summary ("N trang chữ, M trang
     *  màu") the same way `PageListActivity`'s bulk filter already does. */
    class AutoStats {
        var textCount: Int = 0
        var colorCount: Int = 0
    }

    private fun einkTextResult(bitmap: Bitmap): Bitmap {
        val bw = ImageProcessor.applyFilter(bitmap, ImageProcessor.ScanFilter.BW)
        return ImageProcessor.downscaleTo(bw, 2500)
    }

    private fun einkColorResult(bitmap: Bitmap): Bitmap {
        val enhanced = ImageProcessor.applyFilter(bitmap, ImageProcessor.ScanFilter.ENHANCE)
        val saturated = ImageProcessor.boostSaturation(enhanced)
        if (enhanced !== bitmap) enhanced.recycle()
        return ImageProcessor.downscaleTo(saturated, 1300)
    }

    /** Applies [preset] to [bitmap], returning the resulting bitmap (the same instance for
     *  [Preset.ORIGINAL]). The caller owns recycling of the input (if a different instance was
     *  returned) and of the output once done with it. [autoStats], if given, is updated when
     *  [preset] is [Preset.AUTO]. */
    fun apply(bitmap: Bitmap, preset: Preset, autoStats: AutoStats? = null): Bitmap = when (preset) {
        Preset.ORIGINAL -> bitmap
        Preset.ENHANCE -> ImageProcessor.applyFilter(bitmap, ImageProcessor.ScanFilter.ENHANCE)
        Preset.GRAY -> ImageProcessor.applyFilter(bitmap, ImageProcessor.ScanFilter.GRAY)
        Preset.BW -> ImageProcessor.applyFilter(bitmap, ImageProcessor.ScanFilter.BW)
        Preset.EINK_TEXT -> einkTextResult(bitmap)
        Preset.EINK_COLOR -> einkColorResult(bitmap)
        Preset.AUTO -> {
            if (ImageProcessor.isColorPage(bitmap)) {
                autoStats?.let { it.colorCount++ }
                einkColorResult(bitmap)
            } else {
                autoStats?.let { it.textCount++ }
                einkTextResult(bitmap)
            }
        }
    }
}
