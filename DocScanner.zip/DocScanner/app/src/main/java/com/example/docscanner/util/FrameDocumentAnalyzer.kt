package com.example.docscanner.util

import android.graphics.Bitmap
import android.os.SystemClock
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.max
import kotlin.math.min

/**
 * CameraX analyzer behind "Tự động chụp": about 5 times a second it turns the camera frame's luminance
 * plane into a small grey picture, looks for the document outline ([ImageProcessor.detectDocumentCorners])
 * and measures how sharp the frame is (variance of the Laplacian, the same focus measure as [ScanQuality]),
 * then hands both to [CaptureStability]. [onState] is called on the analysis thread.
 *
 * Only the Y (luminance) plane is used: no YUV->RGB conversion of the whole frame. Rows are copied one
 * by one because the plane's rowStride can be larger than the image width. The frame is rotated upright
 * with `imageInfo.rotationDegrees` so the corners match what the person sees.
 */
class FrameDocumentAnalyzer(
    private val stability: CaptureStability,
    private val onState: (CaptureStability.State, Double) -> Unit
) : ImageAnalysis.Analyzer {

    private var lastRunMs = 0L

    override fun analyze(image: ImageProxy) {
        try {
            val now = SystemClock.elapsedRealtime()
            if (now - lastRunMs < MIN_INTERVAL_MS) return
            lastRunMs = now

            val plane = image.planes[0]
            val w = image.width
            val h = image.height
            val rowStride = plane.rowStride
            val buf = plane.buffer
            val bytes = ByteArray(w * h)
            for (row in 0 until h) {
                buf.position(row * rowStride)
                buf.get(bytes, row * w, w)
            }
            val gray = Mat(h, w, CvType.CV_8UC1)
            gray.put(0, 0, bytes)

            val upright = Mat()
            when (image.imageInfo.rotationDegrees) {
                90 -> Core.rotate(gray, upright, Core.ROTATE_90_CLOCKWISE)
                180 -> Core.rotate(gray, upright, Core.ROTATE_180)
                270 -> Core.rotate(gray, upright, Core.ROTATE_90_COUNTERCLOCKWISE)
                else -> gray.copyTo(upright)
            }
            gray.release()

            val scale = min(1.0, WORK_EDGE / max(upright.cols(), upright.rows()).toDouble())
            val small = Mat()
            Imgproc.resize(upright, small, Size(), scale, scale, Imgproc.INTER_AREA)
            upright.release()

            // focus measure: variance of the Laplacian over the whole small frame
            val lap = Mat()
            Imgproc.Laplacian(small, lap, CvType.CV_64F)
            val mean = org.opencv.core.MatOfDouble()
            val std = org.opencv.core.MatOfDouble()
            Core.meanStdDev(lap, mean, std)
            val sd = std.get(0, 0)[0]
            val sharpness = sd * sd
            lap.release(); mean.release(); std.release()

            val rgba = Mat()
            Imgproc.cvtColor(small, rgba, Imgproc.COLOR_GRAY2RGBA)
            val bmp = Bitmap.createBitmap(small.cols(), small.rows(), Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(rgba, bmp)
            val fw = small.cols().toDouble()
            val fh = small.rows().toDouble()
            small.release(); rgba.release()

            val quad = ImageProcessor.detectDocumentCorners(bmp)
            bmp.recycle()
            val normalized = quad?.let {
                doubleArrayOf(it.tl.x / fw, it.tl.y / fh, it.tr.x / fw, it.tr.y / fh, it.br.x / fw, it.br.y / fh, it.bl.x / fw, it.bl.y / fh)
            }
            onState(stability.update(normalized, sharpness, now, fw / fh), stability.holdProgress(now))
        } catch (t: Throwable) {
            // one bad frame must never crash the camera screen
        } finally {
            image.close()
        }
    }

    companion object {
        private const val MIN_INTERVAL_MS = 200L
        private const val WORK_EDGE = 480.0
    }
}
