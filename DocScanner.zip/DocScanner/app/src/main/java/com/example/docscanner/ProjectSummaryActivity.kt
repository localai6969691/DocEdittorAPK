package com.example.docscanner

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.docscanner.adapter.HistoryAdapter
import com.example.docscanner.databinding.ActivityProjectSummaryBinding
import com.example.docscanner.model.Project
import com.example.docscanner.model.ProjectManager
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfPrintAdapter
import java.io.File

/**
 * Shown once a project reaches [com.example.docscanner.model.ProjectStage.DONE]: every artifact
 * the pipeline produced along the way (the plain PDF, the compressed PDF, the OCR text, the
 * ebook file(s)) in one place, each independently openable/shareable - "cũng có file thành phẩm
 * ngay chỗ thoát ra nếu người dùng chỉ muốn dùng file ở bước đó thôi" applies here too: nothing
 * stops the user from only ever caring about, say, the compressed PDF and ignoring the rest.
 * Reuses [HistoryAdapter] (open/share/delete on a plain [File] is exactly what this list needs).
 */
class ProjectSummaryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProjectSummaryBinding
    private lateinit var project: Project
    private lateinit var adapter: HistoryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProjectSummaryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val projectId = intent.getStringExtra(ProjectFlow.EXTRA_PROJECT_ID)
        val loaded = projectId?.let { ProjectManager.load(this, it) }
        if (loaded == null) {
            finish()
            return
        }
        project = loaded
        title = project.name

        adapter = HistoryAdapter(
            onClick = { file -> FileUtils.openFile(this, file) },
            onShare = { file -> FileUtils.shareFile(this, file, getString(R.string.action_share)) },
            onPrint = { file -> PdfPrintAdapter.print(this, file) },
            onDelete = { file -> confirmDelete(file) }
        )
        binding.rvArtifacts.layoutManager = LinearLayoutManager(this)
        binding.rvArtifacts.adapter = adapter

        binding.btnBackToHub.setOnClickListener {
            startActivity(Intent(this, ProjectHubActivity::class.java))
            finish()
        }

        refreshArtifacts()
    }

    private fun refreshArtifacts() {
        val files = listOfNotNull(
            project.pdfPath,
            project.compressedPdfPath,
            project.ocrTextPath
        ).map { File(it) } + project.ebookPaths.map { File(it) }
        adapter.submitList(files.filter { it.exists() })
    }

    private fun confirmDelete(file: File) {
        AlertDialog.Builder(this)
            .setMessage(getString(R.string.confirm_delete_file, file.name))
            .setPositiveButton(R.string.dialog_yes) { _, _ ->
                file.delete()
                refreshArtifacts()
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }
}
