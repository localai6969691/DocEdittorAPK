package com.example.docscanner.util

import android.content.Context
import android.view.LayoutInflater
import androidx.appcompat.app.AlertDialog
import com.example.docscanner.R
import com.example.docscanner.databinding.DialogCompressOptionsBinding
import com.example.docscanner.databinding.ItemCompressOptionBinding

/**
 * Shared "pick a compression method" dialog - one row per method, each with a title, a 1-line
 * summary, and real Ưu điểm/Nhược điểm (pros/cons) text, instead of a bare
 * `AlertDialog.setItems()` list of names. Used by BOTH the standalone "Nén PDF" tool
 * ([com.example.docscanner.MainActivity.showCompressMethodPicker]) and the main "Quét" flow's
 * export step ([com.example.docscanner.PageListActivity]) - same widget, same look, so a person
 * only has to learn what each method means once, even though the two screens offer a different
 * SET of methods (the scan flow adds a "keep as-is" choice and never offers "Sửa trực tiếp",
 * which only makes sense for an already-existing PDF - see each call site's own comment).
 *
 * Deliberately not a full custom DialogFragment or RecyclerView - the option list is always short
 * (3-4 fixed items, known at call time, never paginated or updated after showing), so a plain
 * LinearLayout filled once in [show] is simpler and has less that could go wrong than a
 * RecyclerView+Adapter would, for no real benefit at this list length.
 */
object CompressOptionsDialog {

    data class Option(
        val title: String,
        val summary: String,
        val pros: String,
        val cons: String
    )

    /** [onSelected] receives the index into [options] the person tapped. Never called if they
     *  dismiss the dialog (back button, tap outside, or the Cancel button) - callers don't need
     *  to handle a "no selection" case beyond simply not acting, same as any other cancellable
     *  picker dialog in this app. */
    fun show(context: Context, titleRes: Int, options: List<Option>, onSelected: (Int) -> Unit) {
        val inflater = LayoutInflater.from(context)
        val dialogBinding = DialogCompressOptionsBinding.inflate(inflater)
        val dialog = AlertDialog.Builder(context)
            .setTitle(titleRes)
            .setView(dialogBinding.root)
            .setNegativeButton(R.string.dialog_cancel, null)
            .create()
        options.forEachIndexed { index, option ->
            val itemBinding = ItemCompressOptionBinding.inflate(inflater, dialogBinding.containerOptions, false)
            itemBinding.tvOptionTitle.text = option.title
            itemBinding.tvOptionSummary.text = option.summary
            itemBinding.tvOptionPros.text = context.getString(R.string.compress_option_pros_prefix, option.pros)
            itemBinding.tvOptionCons.text = context.getString(R.string.compress_option_cons_prefix, option.cons)
            itemBinding.root.setOnClickListener {
                dialog.dismiss()
                onSelected(index)
            }
            dialogBinding.containerOptions.addView(itemBinding.root)
        }
        dialog.show()
    }
}
