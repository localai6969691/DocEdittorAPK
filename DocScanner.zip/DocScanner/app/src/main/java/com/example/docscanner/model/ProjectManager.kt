package com.example.docscanner.model

import android.content.Context
import com.example.docscanner.util.FileUtils
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Persistence/CRUD for [Project]. Deliberately takes [Context] explicitly on every call (like
 * `FileUtils`, which this wraps) rather than a stored `init()`-time context like the other
 * `model.*State` singletons - every caller here is a `Project*Activity`, which always has one at
 * hand, so there is no need to depend on `DocScannerApp.onCreate` having already run.
 *
 * One JSON file per project (`projects/<id>/project.json`, see `FileUtils.projectDir`), the same
 * one-file-per-thing approach as `ScanSessionManager`/`PdfEditorState`/etc. Kept intentionally
 * separate from `ProjectFlow` (which owns "which Activity does stage X open" - a UI concern) so
 * this file has no dependency on the Activity layer, matching every other file under `model/`.
 */
object ProjectManager {

    private fun projectJsonFile(context: Context, id: String): File =
        File(FileUtils.projectDir(context, id), "project.json")

    fun createProject(context: Context): Project {
        val id = SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())
        val name = "Dự án ${SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())}"
        val project = Project(id = id, name = name)
        save(context, project)
        return project
    }

    fun save(context: Context, project: Project) {
        project.updatedAt = System.currentTimeMillis()
        runCatching {
            projectJsonFile(context, project.id).writeText(project.toJson().toString())
        }
    }

    fun load(context: Context, id: String): Project? {
        val file = projectJsonFile(context, id)
        if (!file.exists()) return null
        return runCatching { Project.fromJson(JSONObject(file.readText())) }.getOrNull()
    }

    /** All projects, most recently updated first - for the project hub list. */
    fun listProjects(context: Context): List<Project> {
        val dirs = FileUtils.projectsRootDir(context).listFiles { f -> f.isDirectory } ?: emptyArray()
        return dirs.mapNotNull { dir -> load(context, dir.name) }.sortedByDescending { it.updatedAt }
    }

    /** Deletes a project entirely - its JSON state and every page/PDF/ebook file under its own
     *  directory. Only ever called from an explicit user action (see `ProjectHubActivity`),
     *  never automatically. */
    fun delete(context: Context, id: String) {
        runCatching { FileUtils.projectDir(context, id).deleteRecursively() }
    }
}
