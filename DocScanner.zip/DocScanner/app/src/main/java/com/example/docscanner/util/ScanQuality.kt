package com.example.docscanner.util

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.MatOfDouble
import org.opencv.core.Rect
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.max
import kotlin.math.min

/**
 * "Kiểm tra chất lượng ảnh" - the free counterpart of the Blur Estimator / Document Quality Analyzer
 * that Scanbot's commercial SDK sells (their DQA rates OCR-detected text; this one measures the
 * image itself, so it is cheaper and language-independent but blunter).
 *
 * Sharpness: variance of the Laplacian, the focus measure of J. L. Pech-Pacheco, G. Cristóbal,
 * J. Chamorro-Martínez, J. Fernández-Valdivia, "Diatom autofocusing in brightfield microscopy: a
 * comparative study", ICPR 2000, pp. 314-317 (also among the better operators compared in S. Pertuz,
 * D. Puig, M. Á. García, "Analysis of focus measure operators for shape-from-focus", Pattern
 * Recognition 46(5), 2013). A whole-page variance depends heavily on how much of the page is ink, so
 * the page is cut into an 8x8 grid and only the busiest quarter of the tiles is judged - a sharp page
 * with a lot of white margin must not look "blurry".
 *
 * The thresholds are starting values chosen WITHOUT test photos (see TECHNICAL_DOCS.md phiên 12):
 * the result is only ever shown as a dismissible hint, never used to block or alter a page.
 */
object ScanQuality {

    /** Tile-variance of a sharp text page at [WORK_EDGE] px is typically in the thousands; below this
     *  the strokes have visibly lost their edges. Tune with real photos. */
    private const val BLUR_VARIANCE_THRESHOLD = 90.0
    private const val WORK_EDGE = 1200.0
    private const val GRID = 8
    private const val DARK_MEAN = 70.0
    private const val LOW_CONTRAST_RANGE = 60

    data class Report(
        val sharpness: Double,
        val isBlurry: Boolean,
        val isTooDark: Boolean,
        val isLowContrast: Boolean,
        /** false for an (almost) empty page: no ink, so sharpness cannot be judged */
        val hasContent: Boolean
    ) {
        val hasProblem: Boolean get() = isBlurry || isTooDark || isLowContrast
    }

    fun analyze(bitmap: Bitmap): Report {
        val neutral = Report(0.0, isBlurry = false, isTooDark = false, isLowContrast = false, hasContent = false)
        val mats = ArrayList<Mat>()
        fun track(m: Mat): Mat { mats.add(m); return m }
        return try {
            val rgba = track(Mat())
            Utils.bitmapToMat(bitmap, rgba)
            val gray = track(Mat())
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
            val scale = min(1.0, WORK_EDGE / max(gray.cols(), gray.rows()).toDouble())
            val small = track(Mat())
            Imgproc.resize(gray, small, Size(), scale, scale, Imgproc.INTER_AREA)

            // --- exposure / contrast from the grey histogram ------------------------------------
            val pixels = ByteArray(small.rows() * small.cols())
            small.get(0, 0, pixels)
            val hist = IntArray(256)
            var sum = 0L
            for (b in pixels) { val v = b.toInt() and 0xFF; hist[v]++; sum += v }
            val mean = sum.toDouble() / pixels.size
            fun percentile(p: Double): Int {
                val target = (pixels.size * p).toLong()
                var acc = 0L
                for (v in 0..255) { acc += hist[v]; if (acc >= target) return v }
                return 255
            }
            val range = percentile(0.95) - percentile(0.05)
            val hasContent = range >= 25

            // --- sharpness: variance of Laplacian on the busiest tiles ---------------------------
            val lap = track(Mat())
            Imgproc.Laplacian(small, lap, CvType.CV_64F)
            val tileW = small.cols() / GRID
            val tileH = small.rows() / GRID
            val variances = ArrayList<Double>()
            if (tileW >= 8 && tileH >= 8) {
                for (gy in 0 until GRID) for (gx in 0 until GRID) {
                    val tile = lap.submat(Rect(gx * tileW, gy * tileH, tileW, tileH))
                    val m = MatOfDouble()
                    val s = MatOfDouble()
                    Core.meanStdDev(tile, m, s)
                    val sd = s.get(0, 0)[0]
                    variances.add(sd * sd)
                    m.release(); s.release(); tile.release()
                }
            }
            val busiest = variances.sortedDescending().take(max(1, variances.size / 4))
            val sharpness = if (busiest.isEmpty()) 0.0 else busiest.average()

            Report(
                sharpness = sharpness,
                isBlurry = hasContent && sharpness < BLUR_VARIANCE_THRESHOLD,
                isTooDark = mean < DARK_MEAN,
                isLowContrast = hasContent && range < LOW_CONTRAST_RANGE,
                hasContent = hasContent
            )
        } catch (t: Throwable) {
            neutral
        } finally {
            mats.forEach { runCatching { it.release() } }
        }
    }
}
