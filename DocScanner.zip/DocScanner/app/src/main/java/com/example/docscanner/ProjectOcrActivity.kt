package com.example.docscanner

import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityProjectOcrBinding
import com.example.docscanner.model.Project
import com.example.docscanner.model.ProjectManager
import com.example.docscanner.model.ProjectStage
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.OcrHelper
import com.example.docscanner.util.PdfExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Project stage 7: mandatory OCR over every page, producing a plain-text file - the same
 * "--- Trang N ---" format `PdfExporter.exportSession`'s optional OCR checkbox already writes, so
 * a project's .txt output looks like the standalone tool's. Nothing for the user to configure
 * (OCR has no presets), so this runs automatically on entering the stage; Continue just enables
 * once it's done. If the project already has OCR text (resumed after this stage already
 * finished), it's shown immediately instead of re-running.
 */
class ProjectOcrActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProjectOcrBinding
    private lateinit var project: Project

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProjectOcrBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val projectId = intent.getStringExtra(ProjectFlow.EXTRA_PROJECT_ID)
        val loaded = projectId?.let { ProjectManager.load(this, it) }
        if (loaded == null) {
            finish()
            return
        }
        project = loaded
        title = project.name
        binding.tvStageIndicator.text = getString(R.string.project_stage_indicator_6)

        binding.btnContinue.setOnClickListener { advance() }

        val existingPath = project.ocrTextPath
        if (existingPath != null && File(existingPath).exists()) {
            showDone(File(existingPath).readText())
        } else {
            runOcr()
        }
    }

    private fun runOcr() {
        val pages = project.pages
        binding.tvProgress.text = getString(R.string.project_ocr_progress, 0, pages.size)
        lifecycleScope.launch {
            val texts = mutableListOf<String>()
            pages.forEachIndexed { index, page ->
                binding.tvProgress.text = getString(R.string.project_ocr_progress, index + 1, pages.size)
                binding.progressBar.progress = if (pages.isNotEmpty()) (index + 1) * 100 / pages.size else 0
                val text = withContext(Dispatchers.Default) {
                    val bitmap = BitmapFactory.decodeFile(page.path)
                    val result = if (bitmap != null) OcrHelper.recognize(bitmap) else ""
                    bitmap?.recycle()
                    result
                }
                texts.add(text)
            }
            val placeholder = getString(R.string.ocr_no_text_placeholder)
            val outFile = File(PdfExporter.exportDir(this@ProjectOcrActivity), "${FileUtils.defaultDocName()}.txt")
            withContext(Dispatchers.IO) {
                outFile.bufferedWriter().use { w ->
                    texts.forEachIndexed { i, text ->
                        w.write("--- Trang ${i + 1} ---\n")
                        w.write(text.ifBlank { placeholder })
                        w.write("\n\n")
                    }
                }
            }
            project.ocrTextPath = outFile.absolutePath
            ProjectManager.save(this@ProjectOcrActivity, project)
            showDone(outFile.readText())
        }
    }

    private fun showDone(fullText: String) {
        binding.progressBar.progress = 100
        binding.tvProgress.text = getString(R.string.project_ocr_done)
        binding.tvOcrPreview.text = fullText.take(4000)
        binding.btnContinue.isEnabled = true
    }

    private fun advance() {
        project.stage = ProjectStage.EBOOK
        ProjectManager.save(this, project)
        ProjectFlow.open(this, project)
        finish()
    }
}
