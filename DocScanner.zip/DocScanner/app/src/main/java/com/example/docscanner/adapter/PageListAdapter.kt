package com.example.docscanner.adapter

import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.databinding.ItemPageBinding
import com.example.docscanner.model.ScanPage
import com.example.docscanner.util.FileUtils

class PageListAdapter(
    private val onDelete: (Int) -> Unit,
    private val onAnnotate: (Int) -> Unit,
    private val onDragHandleTouch: (RecyclerView.ViewHolder) -> Unit
) : RecyclerView.Adapter<PageListAdapter.ViewHolder>() {

    private val items = mutableListOf<ScanPage>()

    fun submitList(pages: List<ScanPage>) {
        items.clear()
        items.addAll(pages)
        notifyDataSetChanged()
    }

    fun moveItem(from: Int, to: Int) {
        if (from < 0 || to < 0 || from >= items.size || to >= items.size) return
        val item = items.removeAt(from)
        items.add(to, item)
        notifyItemMoved(from, to)
    }

    inner class ViewHolder(val binding: ItemPageBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val page = items[position]
        holder.binding.tvPageNumber.text = (position + 1).toString()
        holder.binding.ivPageThumb.setImageBitmap(
            FileUtils.decodeSampledBitmap(page.filePath, 400, 600)
        )
        holder.binding.btnDeletePage.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onDelete(pos)
        }
        holder.binding.btnAnnotatePage.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onAnnotate(pos)
        }
        holder.binding.ivDragHandle.setOnTouchListener { _, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                onDragHandleTouch(holder)
            }
            false
        }
    }

    override fun getItemCount(): Int = items.size
}
