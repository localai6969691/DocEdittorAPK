package com.example.docscanner.util

import android.text.Html
import java.io.File
import java.io.InputStream
import java.util.zip.ZipFile
import javax.xml.parsers.DocumentBuilderFactory
import org.w3c.dom.Document
import org.w3c.dom.Element

/**
 * Reads an existing EPUB file back into chapters - the inverse of [EbookBuilder.buildEpub]. Uses
 * only `java.util.zip` and the JDK's built-in DOM XML parser (`javax.xml.parsers`), plus Android's
 * built-in [Html] class to strip the XHTML chapter markup down to plain paragraphs - no EPUB or
 * HTML-parsing library.
 *
 * This only reads what [EbookBuilder]-style EPUBs (and most other reasonably simple ones) contain:
 * the spine reading order and each chapter's text. It does not preserve images, complex CSS
 * layout, or nested table-of-contents structure - good enough for round-tripping into TXT/PDF,
 * not a general-purpose EPUB renderer.
 */
object EpubReader {

    fun read(epubFile: File): List<EbookBuilder.Chapter> {
        ZipFile(epubFile).use { zip ->
            val containerEntry = zip.getEntry("META-INF/container.xml") ?: return emptyList()
            val containerDoc = parseXml(zip.getInputStream(containerEntry))
            val rootfileNode = containerDoc.getElementsByTagName("rootfile").item(0) as? Element
                ?: return emptyList()
            val opfPath = rootfileNode.getAttribute("full-path")
            if (opfPath.isBlank()) return emptyList()

            val opfEntry = zip.getEntry(opfPath) ?: return emptyList()
            val opfDoc = parseXml(zip.getInputStream(opfEntry))
            val opfDir = opfPath.substringBeforeLast('/', "")

            val manifest = HashMap<String, String>()
            val itemNodes = opfDoc.getElementsByTagName("item")
            for (i in 0 until itemNodes.length) {
                val el = itemNodes.item(i) as? Element ?: continue
                val id = el.getAttribute("id")
                val href = el.getAttribute("href")
                if (id.isNotBlank() && href.isNotBlank()) manifest[id] = href
            }

            val spineOrder = mutableListOf<String>()
            val itemrefNodes = opfDoc.getElementsByTagName("itemref")
            for (i in 0 until itemrefNodes.length) {
                val el = itemrefNodes.item(i) as? Element ?: continue
                val idref = el.getAttribute("idref")
                if (idref.isNotBlank()) spineOrder.add(idref)
            }

            // Prefer real chapter titles from the book's own table of contents (EPUB3 nav.xhtml,
            // falling back to the EPUB2 toc.ncx) over guessing from an <h1> inside the chapter -
            // some EPUBs only state the title in the TOC, not repeated in the chapter body.
            val tocTitles = readTocTitles(zip, opfDoc, opfDir)

            val chapters = mutableListOf<EbookBuilder.Chapter>()
            spineOrder.forEachIndexed { index, idref ->
                val href = manifest[idref] ?: return@forEachIndexed
                val fullPath = if (opfDir.isEmpty()) href else "$opfDir/$href"
                val entry = zip.getEntry(fullPath) ?: return@forEachIndexed
                val html = zip.getInputStream(entry).bufferedReader(Charsets.UTF_8).readText()
                val paragraphs = htmlToParagraphs(html)
                val title = tocTitles[href] ?: extractTitle(html) ?: "Chương ${index + 1}"
                chapters.add(EbookBuilder.Chapter(title, paragraphs))
            }
            return chapters
        }
    }

    /** href (relative to the OPF directory) -> chapter title, read from the book's real TOC. */
    private fun readTocTitles(zip: ZipFile, opfDoc: Document, opfDir: String): Map<String, String> {
        val navHref = findManifestHrefByAttribute(opfDoc, "properties", "nav")
        if (navHref != null) {
            val path = if (opfDir.isEmpty()) navHref else "$opfDir/$navHref"
            val fromNav = readNavXhtmlTitles(zip, path)
            if (fromNav.isNotEmpty()) return fromNav
        }
        val ncxHref = findManifestHrefByAttribute(opfDoc, "media-type", "application/x-dtbncx+xml")
        if (ncxHref != null) {
            val path = if (opfDir.isEmpty()) ncxHref else "$opfDir/$ncxHref"
            return readNcxTitles(zip, path)
        }
        return emptyMap()
    }

    private fun findManifestHrefByAttribute(opfDoc: Document, attrName: String, attrValueContains: String): String? {
        val items = opfDoc.getElementsByTagName("item")
        for (i in 0 until items.length) {
            val el = items.item(i) as? Element ?: continue
            if (el.getAttribute(attrName).contains(attrValueContains)) {
                val href = el.getAttribute("href")
                if (href.isNotBlank()) return href
            }
        }
        return null
    }

    private fun readNavXhtmlTitles(zip: ZipFile, path: String): Map<String, String> {
        val entry = zip.getEntry(path) ?: return emptyMap()
        val doc = try { parseXml(zip.getInputStream(entry)) } catch (e: Exception) { return emptyMap() }
        val titles = LinkedHashMap<String, String>()
        val anchors = doc.getElementsByTagName("a")
        for (i in 0 until anchors.length) {
            val el = anchors.item(i) as? Element ?: continue
            val href = el.getAttribute("href")
            val title = el.textContent?.trim()
            if (href.isNotBlank() && !title.isNullOrBlank()) {
                titles.putIfAbsent(href.substringBefore('#'), title)
            }
        }
        return titles
    }

    private fun readNcxTitles(zip: ZipFile, path: String): Map<String, String> {
        val entry = zip.getEntry(path) ?: return emptyMap()
        val doc = try { parseXml(zip.getInputStream(entry)) } catch (e: Exception) { return emptyMap() }
        val titles = LinkedHashMap<String, String>()
        val navPoints = doc.getElementsByTagName("navPoint")
        for (i in 0 until navPoints.length) {
            val navPoint = navPoints.item(i) as? Element ?: continue
            val textNode = navPoint.getElementsByTagName("text").item(0)
            val contentNode = navPoint.getElementsByTagName("content").item(0) as? Element
            val title = textNode?.textContent?.trim()
            val src = contentNode?.getAttribute("src")
            if (!title.isNullOrBlank() && !src.isNullOrBlank()) {
                titles.putIfAbsent(src.substringBefore('#'), title)
            }
        }
        return titles
    }

    private fun parseXml(input: InputStream): Document {
        val factory = DocumentBuilderFactory.newInstance()
        val builder = factory.newDocumentBuilder()
        return builder.parse(input)
    }

    private fun htmlToParagraphs(html: String): List<String> {
        val plain = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString()
        return plain.split("\n").map { it.trim() }.filter { it.isNotBlank() }
    }

    private fun extractTitle(html: String): String? {
        val match = Regex("<h1[^>]*>(.*?)</h1>", RegexOption.DOT_MATCHES_ALL).find(html)
            ?: Regex("<title[^>]*>(.*?)</title>", RegexOption.DOT_MATCHES_ALL).find(html)
            ?: return null
        val text = Html.fromHtml(match.groupValues[1], Html.FROM_HTML_MODE_LEGACY).toString().trim()
        return text.ifBlank { null }
    }
}
