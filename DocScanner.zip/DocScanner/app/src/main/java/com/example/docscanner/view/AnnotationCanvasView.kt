package com.example.docscanner.view

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * Draws a page bitmap plus a stack of user-added annotation elements (pen strokes, text stamps,
 * whiteout rectangles) on top of it, and can [flatten] the two into one final bitmap.
 *
 * Elements are stored in BITMAP-space coordinates (the page image's own pixel grid), never in
 * view/screen space, so [flatten] can draw them straight onto the original-resolution bitmap with
 * no rescaling math of its own. [onDraw] achieves the on-screen preview by concatenating the
 * bitmap->view scale/offset matrix onto the canvas ONCE, then drawing every element with the exact
 * same paint/path values [flatten] would use - what's on screen is what ends up in the file, not
 * an approximation of it. A stroke width or text size chosen once (see [strokeWidthBitmapSpace])
 * is defined directly in bitmap-space units (proportional to the bitmap's own width), so it comes
 * out the same relative thickness on a small or a large scanned page, and looks identical at
 * preview scale and at full flattened resolution - only ever set/read in that one space, never
 * converted back and forth.
 *
 * This produces a FLATTENED result only - annotations are baked permanently into the page's pixels
 * once [flatten] is called, not kept as separate, later-removable PDF annotation objects. That
 * matches this app's image-first architecture everywhere else (see TECHNICAL_DOCS.md) - the
 * alternative (real `/Annots` dictionary entries a PDF viewer could toggle) would need a
 * genuinely different, PDF-object-level approach this class does not attempt.
 */
class AnnotationCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Mode { PEN, TEXT, REDACT }

    private sealed class Element {
        data class Stroke(val points: MutableList<PointF>, val color: Int, val width: Float) : Element()
        data class TextStamp(val text: String, val x: Float, val y: Float, val color: Int, val textSize: Float) : Element()
        data class Redact(val rect: RectF) : Element()
    }

    private var pageBitmap: Bitmap? = null
    private val elements = mutableListOf<Element>()

    /** bitmap-space -> view-space, recomputed whenever the bitmap or the view's own size changes -
     *  fit-center, same idea as ImageView's own centerInside scale type. */
    private val bitmapToView = Matrix()
    private val viewToBitmap = Matrix()

    var mode: Mode = Mode.PEN
    var currentColor: Int = Color.RED
    /** One of 3 relative sizes (small/medium/large), expressed as a fraction of the bitmap's own
     *  width so it scales with page resolution - see the class doc comment. */
    var strokeWidthBitmapSpace: Float = 0f
        private set
    private var strokeSizeFraction = 0.006f // "medium" default

    private var activeStroke: Element.Stroke? = null
    private var redactStart: PointF? = null
    private var redactCurrent: RectF? = null

    /** Set by the Activity; called on a single tap while [mode] is [Mode.TEXT], with the tap
     *  point already converted to bitmap-space - the Activity owns showing a text-input dialog
     *  and, once the user submits something, is expected to call [addText] itself. This class
     *  never shows dialogs on its own - a custom View popping its own AlertDialog would make it
     *  much harder to reason about from the Activity side, for no real benefit here. */
    var onTextTap: ((PointF) -> Unit)? = null

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val redactPaint = Paint().apply { style = Paint.Style.FILL; color = Color.WHITE }
    private val redactPreviewPaint = Paint().apply {
        style = Paint.Style.FILL
        color = Color.argb(120, 255, 255, 255)
    }

    fun setSizePreset(small: Boolean? = null, medium: Boolean? = null, large: Boolean? = null) {
        // Called with exactly one of the 3 non-null - a tiny helper so the Activity's 3 size
        // buttons can each make one plain call without needing to know the fraction constants.
        strokeSizeFraction = when {
            small == true -> 0.003f
            large == true -> 0.014f
            else -> 0.006f
        }
        recomputeStrokeWidth()
    }

    /** Loads a new page - resets elements and undo history, since each page's annotations are
     *  flattened into its own file as soon as the Activity navigates away from it (see
     *  `PdfAnnotateActivity`'s own doc comment for why: this keeps per-page state entirely out of
     *  this class, so there is nothing here that needs to survive a page switch). Recycles the
     *  PREVIOUS page's bitmap first (unless [bitmap] is literally the same object) - without this,
     *  repeated navigation across a long multi-page session would leak one bitmap per page visited,
     *  since nothing else in this class or its caller ever lets go of the old one. */
    fun loadPage(bitmap: Bitmap) {
        if (pageBitmap !== bitmap) pageBitmap?.recycle()
        pageBitmap = bitmap
        elements.clear()
        activeStroke = null
        redactStart = null
        redactCurrent = null
        recomputeStrokeWidth()
        recomputeMatrices()
        invalidate()
    }

    fun canUndo(): Boolean = elements.isNotEmpty()

    fun undo() {
        if (elements.isNotEmpty()) {
            elements.removeAt(elements.size - 1)
            invalidate()
        }
    }

    fun hasUnsavedEdits(): Boolean = elements.isNotEmpty()

    /** Called by the Activity once the user has typed something into the text-input dialog shown
     *  after [onTextTap] fires. [point] must be in bitmap-space (exactly what [onTextTap] handed
     *  the Activity - never re-derive it from a fresh touch event, the user may have scrolled/
     *  zoomed nothing here but keeping the contract explicit avoids ever mixing spaces). */
    fun addText(text: String, point: PointF) {
        if (text.isBlank()) return
        elements.add(Element.TextStamp(text, point.x, point.y, currentColor, strokeWidthBitmapSpace * 6f))
        invalidate()
    }

    /** Draws every element plus the original bitmap onto a fresh, full-resolution copy of
     *  [pageBitmap] and returns it. Does not mutate the bitmap this view is currently showing -
     *  the caller decides what to do with the result (write it to a new file, etc.). Returns null
     *  if no page has been loaded yet. */
    fun flatten(): Bitmap? {
        val src = pageBitmap ?: return null
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(out)
        elements.forEach { drawElement(canvas, it) }
        return out
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        recomputeMatrices()
    }

    private fun recomputeStrokeWidth() {
        val bmp = pageBitmap ?: return
        strokeWidthBitmapSpace = bmp.width * strokeSizeFraction
    }

    private fun recomputeMatrices() {
        val bmp = pageBitmap ?: return
        if (width == 0 || height == 0) return
        val scale = minOf(width.toFloat() / bmp.width, height.toFloat() / bmp.height)
        val dx = (width - bmp.width * scale) / 2f
        val dy = (height - bmp.height * scale) / 2f
        bitmapToView.reset()
        bitmapToView.postScale(scale, scale)
        bitmapToView.postTranslate(dx, dy)
        bitmapToView.invert(viewToBitmap)
    }

    private fun viewPointToBitmap(x: Float, y: Float): PointF {
        val pts = floatArrayOf(x, y)
        viewToBitmap.mapPoints(pts)
        return PointF(pts[0], pts[1])
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = pageBitmap ?: return
        canvas.save()
        canvas.concat(bitmapToView)
        canvas.drawBitmap(bmp, 0f, 0f, null)
        elements.forEach { drawElement(canvas, it) }
        activeStroke?.let { drawElement(canvas, it) }
        redactCurrent?.let { canvas.drawRect(it, redactPreviewPaint) }
        canvas.restore()
    }

    private fun drawElement(canvas: Canvas, element: Element) {
        when (element) {
            is Element.Stroke -> {
                if (element.points.size < 2) return
                val path = Path()
                path.moveTo(element.points[0].x, element.points[0].y)
                for (i in 1 until element.points.size) path.lineTo(element.points[i].x, element.points[i].y)
                strokePaint.color = element.color
                strokePaint.strokeWidth = element.width
                canvas.drawPath(path, strokePaint)
            }
            is Element.TextStamp -> {
                textPaint.color = element.color
                textPaint.textSize = element.textSize
                canvas.drawText(element.text, element.x, element.y, textPaint)
            }
            is Element.Redact -> canvas.drawRect(element.rect, redactPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (pageBitmap == null) return false
        val bmpPoint = viewPointToBitmap(event.x, event.y)
        when (mode) {
            Mode.PEN -> when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    activeStroke = Element.Stroke(mutableListOf(bmpPoint), currentColor, strokeWidthBitmapSpace)
                    invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    activeStroke?.points?.add(bmpPoint)
                    invalidate()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    activeStroke?.let { if (it.points.size >= 2) elements.add(it) }
                    activeStroke = null
                    invalidate()
                }
            }
            Mode.REDACT -> when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    redactStart = bmpPoint
                    redactCurrent = RectF(bmpPoint.x, bmpPoint.y, bmpPoint.x, bmpPoint.y)
                    invalidate()
                }
                MotionEvent.ACTION_MOVE -> {
                    redactStart?.let { start ->
                        redactCurrent = RectF(
                            minOf(start.x, bmpPoint.x), minOf(start.y, bmpPoint.y),
                            maxOf(start.x, bmpPoint.x), maxOf(start.y, bmpPoint.y)
                        )
                    }
                    invalidate()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    redactCurrent?.let { if (it.width() > 2f && it.height() > 2f) elements.add(Element.Redact(RectF(it))) }
                    redactStart = null
                    redactCurrent = null
                    invalidate()
                }
            }
            Mode.TEXT -> if (event.actionMasked == MotionEvent.ACTION_UP) {
                onTextTap?.invoke(bmpPoint)
            }
        }
        return true
    }
}
