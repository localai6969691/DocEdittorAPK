package com.example.docscanner.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.databinding.ItemTextChunkBinding
import com.example.docscanner.util.PdfTextEditor

class TextChunkAdapter(
    private val onTap: (PdfTextEditor.TextChunk) -> Unit
) : RecyclerView.Adapter<TextChunkAdapter.ViewHolder>() {

    private var chunks: List<PdfTextEditor.TextChunk> = emptyList()

    fun submitList(newChunks: List<PdfTextEditor.TextChunk>) {
        chunks = newChunks
        notifyDataSetChanged()
    }

    class ViewHolder(val binding: ItemTextChunkBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemTextChunkBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val chunk = chunks[position]
        holder.binding.tvChunkText.text = chunk.text
        holder.binding.root.setOnClickListener { onTap(chunk) }
    }

    override fun getItemCount(): Int = chunks.size
}
