package com.example.docscanner.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSDictionary
import com.tom_roush.pdfbox.cos.COSFloat
import com.tom_roush.pdfbox.cos.COSInteger
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.PDResources
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.io.File
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

/**
 * "PDF có thể tìm kiếm" - puts an INVISIBLE text layer (text rendering mode 3) over the pages of a
 * scanned PDF, so the file can be searched and copied from in any PDF viewer. Commercial scanner SDKs
 * (Scanbot, Apryse, ABBYY...) sell exactly this "OCR text layer / searchable PDF" feature; ML Kit only
 * returns text and PdfBox only writes PDFs, so the two are joined here. The pages' pictures are never
 * touched.
 *
 * ## The one non-obvious design decision: a glyph-less Type3 font
 * A text layer needs a font, and a `/ToUnicode` table can only exist attached to a font (ISO 32000-1,
 * 9.10.3). Tesseract's PDF renderer solves this with an embedded dummy TrueType font; its own
 * developers and Ghostscript's maintainers document that this font is technically invalid (missing
 * required tables, wrong checksums, empty `glyf`) and that PDFium (Chrome, and Android's PdfRenderer)
 * mishandles its `/W` widths (tesseract-ocr issue #2879, Ghostscript bug 695869). To avoid shipping any
 * font FILE at all, this uses a **Type3 font whose glyph procedures draw nothing** (`500 0 d0`, ISO
 * 32000-1, 9.6.5): a perfectly ordinary, valid font object that every reader accepts, with widths given
 * in `/Widths` and the Unicode meaning in `/ToUnicode`. A Type3 font can address only 255 codes, so the
 * characters found in the whole document are split over as many such fonts as needed (in practice one).
 *
 * ## Geometry
 * One text run per OCR word. Font size = word height; the font's ascent/descent (800/-200) make the
 * selection rectangle equal to the box. Every glyph advances 0.5 em (space: 0.2 em), and horizontal
 * scaling (`Tz`) stretches the run to the measured word width. The rendering-time page rotation and
 * crop box are honoured (the text matrix is rotated to match), because the OCR image comes from
 * [PdfRenderer], which renders the page as displayed.
 *
 * ## Safety
 * Pages that already contain real text (also: an earlier run of this builder) are skipped, never
 * doubled. The result must open in [PdfVerify.opensAsPdf]; afterwards one page is read back with
 * PdfBox's own text extractor and the share of OCR words found in the extracted text is reported
 * (that check uses PdfBox's reader, not Chrome's or Acrobat's - see TECHNICAL_DOCS.md phiên 12).
 */
object SearchablePdfBuilder {

    private const val OCR_DPI = 200f
    private const val OCR_MAX_EDGE_PX = 2600f
    private const val CODES_PER_FONT = 250
    private const val GLYPH_WIDTH = 500
    private const val SPACE_WIDTH = 200

    data class Result(
        val pagesOcr: Int,
        val pagesSkippedHadText: Int,
        val pagesWithoutText: Int,
        val words: Int,
        /** % of OCR words found again by PdfBox's text extractor on a sample page; null = check failed to run */
        val extractionCheckPercent: Int?,
        val structureOptimized: Boolean
    )

    private class PageOcr(val bitmapW: Int, val bitmapH: Int, val lines: List<OcrHelper.OcrLine>)

    suspend fun build(
        srcFile: File,
        outFile: File,
        script: OcrHelper.OcrScript = OcrHelper.OcrScript.LATIN,
        onProgress: (Int, Int) -> Unit
    ): Result {
        val memory = MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(srcFile.parentFile)
        val doc = PDDocument.load(srcFile, memory)
        try {
            if (doc.isEncrypted && !doc.currentAccessPermission.canModify()) {
                throw SecurityException("PDF does not permit modification")
            }
            val pageCount = doc.numberOfPages
            if (pageCount == 0) throw IllegalStateException("empty PDF")

            // ---- 1) OCR every page that has no real text yet -------------------------------------
            val ocr = arrayOfNulls<PageOcr>(pageCount)
            var skipped = 0
            var withoutText = 0
            val pfd = ParcelFileDescriptor.open(srcFile, ParcelFileDescriptor.MODE_READ_ONLY)
            val renderer = PdfRenderer(pfd)
            try {
                if (renderer.pageCount != pageCount) throw IllegalStateException("page count mismatch")
                for (i in 0 until pageCount) {
                    currentCoroutineContext().ensureActive()
                    onProgress(i + 1, pageCount)
                    val hasText = runCatching { PdfTextEditor.extractChunks(doc, i + 1).isNotEmpty() }.getOrDefault(false)
                    if (hasText) { skipped++; continue }
                    val bitmap = renderForOcr(renderer, i)
                    val w = bitmap.width
                    val h = bitmap.height
                    val lines = try { OcrHelper.recognizeLines(bitmap, script) } finally { bitmap.recycle() }
                    if (lines.isEmpty()) withoutText++ else ocr[i] = PageOcr(w, h, lines)
                }
            } finally {
                runCatching { renderer.close() }
                runCatching { pfd.close() }
            }

            // ---- 2) fonts: one code per distinct character in the whole document ---------------
            val counts = HashMap<Int, Int>()
            for (page in ocr) page?.lines?.forEach { line -> line.words.forEach { word ->
                word.text.codePoints().forEach { cp -> if (isUsable(cp)) counts.merge(cp, 1, Int::plus) }
            } }
            counts.merge(0x20, 1, Int::plus) // the separator between words
            val totalWords = ocr.sumOf { it?.lines?.sumOf { l -> l.words.size } ?: 0 }
            if (totalWords == 0) {
                return Result(0, skipped, withoutText, 0, null, false)
            }
            val ordered = counts.entries.sortedByDescending { it.value }.map { it.key }
            val indexOf = HashMap<Int, Int>()
            ordered.forEachIndexed { i, cp -> indexOf[cp] = i }
            val fontDicts = ordered.chunked(CODES_PER_FONT).map { buildType3Font(doc, it) }

            // ---- 3) write the invisible layer page by page -----------------------------------------
            var pagesDone = 0
            var samplePage = -1
            for (i in 0 until pageCount) {
                val page = ocr[i] ?: continue
                val pdPage = doc.getPage(i)
                val content = buildPageContent(pdPage, page, indexOf, script.usesWordSpaces) ?: continue
                registerFonts(pdPage, fontDicts)
                PDPageContentStream(doc, pdPage, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    cs.appendRawCommands(content)
                }
                pagesDone++
                if (samplePage < 0) samplePage = i
            }

            // ---- 4) save (+ structure pass), then verify ------------------------------------------
            val outcome = PdfStructureOptimizer.save(doc, outFile)
            if (!PdfVerify.opensAsPdf(outFile, pageCount)) {
                runCatching { outFile.delete() }
                throw IllegalStateException("output failed verification")
            }
            val percent = if (samplePage >= 0) extractionCheck(outFile, samplePage, ocr[samplePage]!!) else null
            return Result(pagesDone, skipped, withoutText, totalWords, percent, outcome.optimizedUsed)
        } finally {
            runCatching { doc.close() }
        }
    }

    private fun isUsable(cp: Int): Boolean = cp >= 0x20 && cp != 0x7F && !(cp in 0x80..0x9F)

    private fun renderForOcr(renderer: PdfRenderer, index: Int): Bitmap {
        val page = renderer.openPage(index)
        try {
            val scale = min(OCR_DPI / 72f, OCR_MAX_EDGE_PX / max(page.width, page.height).toFloat())
            val w = (page.width * scale).toInt().coerceAtLeast(1)
            val h = (page.height * scale).toInt().coerceAtLeast(1)
            val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            Canvas(bitmap).drawColor(Color.WHITE)
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            return bitmap
        } finally {
            page.close()
        }
    }

    // ------------------------------------------------------------------------------------------
    // Type3 glyph-less font
    // ------------------------------------------------------------------------------------------

    private fun int(v: Int) = COSInteger.get(v.toLong())

    private fun buildType3Font(doc: PDDocument, codePoints: List<Int>): COSDictionary {
        // One shared, empty glyph procedure: "wx wy d0" declares a coloured glyph of width 500 that paints nothing.
        val glyph = doc.document.createCOSStream()
        glyph.createOutputStream().use { it.write("$GLYPH_WIDTH 0 d0\n".toByteArray(Charsets.US_ASCII)) }

        val charProcs = COSDictionary()
        val differences = COSArray().apply { add(int(1)) }
        val widths = COSArray()
        codePoints.forEachIndexed { i, cp ->
            val name = "g${i + 1}"
            charProcs.setItem(name, glyph)
            differences.add(COSName.getPDFName(name))
            widths.add(int(if (cp == 0x20) SPACE_WIDTH else GLYPH_WIDTH))
        }
        val encoding = COSDictionary().apply {
            setItem(COSName.TYPE, COSName.getPDFName("Encoding"))
            setItem("Differences", differences)
        }
        val toUnicode = doc.document.createCOSStream()
        toUnicode.createOutputStream(COSName.FLATE_DECODE).use { it.write(toUnicodeCMap(codePoints)) }

        return COSDictionary().apply {
            setItem(COSName.TYPE, COSName.FONT)
            setItem(COSName.SUBTYPE, COSName.getPDFName("Type3"))
            setItem("FontBBox", COSArray().apply { add(int(0)); add(int(-200)); add(int(GLYPH_WIDTH)); add(int(800)) })
            setItem("FontMatrix", COSArray().apply {
                add(COSFloat(0.001f)); add(int(0)); add(int(0)); add(COSFloat(0.001f)); add(int(0)); add(int(0))
            })
            setItem("CharProcs", charProcs)
            setItem("Encoding", encoding)
            setItem("FirstChar", int(1))
            setItem("LastChar", int(codePoints.size))
            setItem("Widths", widths)
            setItem("ToUnicode", toUnicode)
        }
    }

    private fun utf16Hex(cp: Int): String =
        String(Character.toChars(cp)).toByteArray(Charsets.UTF_16BE).joinToString("") { "%02X".format(it) }

    /** ToUnicode CMap (ISO 32000-1, 9.10.3): code i+1 -> code point i. bfchar sections hold <= 100 entries. */
    private fun toUnicodeCMap(codePoints: List<Int>): ByteArray {
        val sb = StringBuilder()
        sb.append("/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n")
        sb.append("/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n")
        sb.append("/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n")
        sb.append("1 begincodespacerange\n<01> <FF>\nendcodespacerange\n")
        codePoints.withIndex().chunked(100).forEach { chunk ->
            sb.append(chunk.size).append(" beginbfchar\n")
            for ((i, cp) in chunk) sb.append("<%02X> <%s>\n".format(i + 1, utf16Hex(cp)))
            sb.append("endbfchar\n")
        }
        sb.append("endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend\n")
        return sb.toString().toByteArray(Charsets.US_ASCII)
    }

    private fun fontResourceName(fontIndex: Int) = "OcrF${fontIndex + 1}"

    private fun registerFonts(page: PDPage, fonts: List<COSDictionary>) {
        val resources = page.resources ?: PDResources().also { page.resources = it }
        val fontMap = resources.cosObject.getDictionaryObject(COSName.FONT) as? COSDictionary
            ?: COSDictionary().also { resources.cosObject.setItem(COSName.FONT, it) }
        fonts.forEachIndexed { i, dict -> fontMap.setItem(fontResourceName(i), dict) }
    }

    // ------------------------------------------------------------------------------------------
    // Page geometry + content stream
    // ------------------------------------------------------------------------------------------

    /** Maps a point of the DISPLAYED page (points, origin top-left, y down) into the page's user space. */
    private class PageGeometry(page: PDPage) {
        private val crop = page.cropBox
        private val cw = crop.width
        private val ch = crop.height
        private val rotation = ((page.rotation % 360) + 360) % 360
        val visibleWidth: Float = if (rotation == 90 || rotation == 270) ch else cw
        val visibleHeight: Float = if (rotation == 90 || rotation == 270) cw else ch

        fun toUser(u: Float, v: Float): Pair<Float, Float> {
            val (x, y) = when (rotation) {
                90 -> v to u
                180 -> (cw - u) to v
                270 -> (cw - v) to (ch - u)
                else -> u to (ch - v)
            }
            return (x + crop.lowerLeftX) to (y + crop.lowerLeftY)
        }
    }

    private fun fmt(v: Float): String = String.format(Locale.US, "%.3f", v)
    private fun fmtM(v: Float): String = String.format(Locale.US, "%.5f", v)

    /**
     * One text run per OCR word. With ML Kit's four corner points the run follows a tilted line
     * exactly: width/height are the distances top-left -> top-right and top-left -> bottom-left, the
     * baseline starts 0.2 em above the bottom-left corner, and the text matrix is built from where the
     * baseline direction and the "up" direction land in the page's user space (which also handles
     * `/Rotate`). Without corners the axis-aligned box is used - the same thing for an upright word.
     * [spaceBetweenWords] is false for Chinese/Japanese, which are written without spaces.
     */
    private fun buildPageContent(pdPage: PDPage, ocr: PageOcr, indexOf: Map<Int, Int>, spaceBetweenWords: Boolean): String? {
        val geo = PageGeometry(pdPage)
        val sx = geo.visibleWidth / ocr.bitmapW
        val sy = geo.visibleHeight / ocr.bitmapH
        val sb = StringBuilder("q\nBT\n3 Tr\n")
        var any = false
        for (line in ocr.lines) {
            for ((wi, word) in line.words.withIndex()) {
                // corners in displayed-page points (origin top-left, y down): TL, TR, BR, BL
                val c = word.corners
                val tlx: Float; val tly: Float; val trx: Float; val try_: Float; val blx: Float; val bly: Float
                if (c != null) {
                    tlx = c[0] * sx; tly = c[1] * sy; trx = c[2] * sx; try_ = c[3] * sy; blx = c[6] * sx; bly = c[7] * sy
                } else {
                    tlx = word.box.left * sx; tly = word.box.top * sy; trx = word.box.right * sx; try_ = tly
                    blx = tlx; bly = word.box.bottom * sy
                }
                val width = kotlin.math.hypot(trx - tlx, try_ - tly)
                val height = kotlin.math.hypot(blx - tlx, bly - tly)
                if (height < 1f || width < 1f) continue
                val cps = word.text.codePoints().toArray().filter { isUsable(it) && indexOf.containsKey(it) }.toMutableList()
                if (cps.isEmpty()) continue

                val dirU = (trx - tlx) / width; val dirV = (try_ - tly) / width           // along the baseline
                val upU = (tlx - blx) / height; val upV = (tly - bly) / height            // towards the top of the letters
                val originU = blx + 0.2f * height * upU
                val originV = bly + 0.2f * height * upV
                val (ox0, oy0) = geo.toUser(originU, originV)
                val (dx1, dy1) = geo.toUser(originU + dirU, originV + dirV)
                val (ux1, uy1) = geo.toUser(originU + upU, originV + upV)
                val a = dx1 - ox0; val b = dy1 - oy0; val cc = ux1 - ox0; val d = uy1 - oy0

                val fontSize = height
                val tz = (100f * width / (cps.size * 0.5f * fontSize)).coerceIn(1f, 5000f)
                if (spaceBetweenWords && wi < line.words.size - 1) cps.add(0x20)
                var advanceUnits = 0
                var i = 0
                while (i < cps.size) {
                    val fontIndex = indexOf.getValue(cps[i]) / CODES_PER_FONT
                    val hex = StringBuilder()
                    var runUnits = 0
                    while (i < cps.size && indexOf.getValue(cps[i]) / CODES_PER_FONT == fontIndex) {
                        val cp = cps[i]
                        hex.append("%02X".format(indexOf.getValue(cp) % CODES_PER_FONT + 1))
                        runUnits += if (cp == 0x20) SPACE_WIDTH else GLYPH_WIDTH
                        i++
                    }
                    val advancePt = advanceUnits / 1000f * fontSize * tz / 100f
                    val px = ox0 + a * advancePt
                    val py = oy0 + b * advancePt
                    sb.append('/').append(fontResourceName(fontIndex)).append(' ').append(fmt(fontSize)).append(" Tf ")
                        .append(fmt(tz)).append(" Tz ")
                        .append(fmtM(a)).append(' ').append(fmtM(b)).append(' ').append(fmtM(cc)).append(' ').append(fmtM(d)).append(' ')
                        .append(fmt(px)).append(' ').append(fmt(py)).append(" Tm <").append(hex).append("> Tj\n")
                    advanceUnits += runUnits
                    any = true
                }
            }
        }
        sb.append("ET\nQ\n")
        return if (any) sb.toString() else null
    }

    // ------------------------------------------------------------------------------------------
    // Read-back check
    // ------------------------------------------------------------------------------------------

    private fun letters(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    private fun extractionCheck(file: File, pageIndex: Int, ocr: PageOcr): Int? {
        return try {
            val memory = MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(file.parentFile)
            PDDocument.load(file, memory).use { reloaded ->
                val stripper = PDFTextStripper()
                stripper.startPage = pageIndex + 1
                stripper.endPage = pageIndex + 1
                val extracted = letters(stripper.getText(reloaded))
                val expected = ocr.lines.flatMap { it.words }.map { letters(it.text) }.filter { it.length >= 3 }
                if (expected.isEmpty()) null else expected.count { extracted.contains(it) } * 100 / expected.size
            }
        } catch (t: Throwable) {
            null
        }
    }
}
