package com.example.docscanner.util

import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDDocumentInformation
import java.io.File

/**
 * Document properties of a PDF - title, author, subject, keywords - read, edited, or wiped.
 *
 * Why it matters for a scanner app: the title is what a file manager, a mail client and a search index show for the
 * file; and a PDF quietly carries who made it and with what ("Author", "Creator", "Producer", dates), which people
 * sending a scanned contract or ID often want gone before it leaves the phone.
 *
 * A PDF can hold these twice: in the classic Info dictionary and in an XMP packet (the catalog's /Metadata stream).
 * Many viewers prefer the XMP copy, so editing only the Info dictionary can leave the OLD title showing. Both
 * [write] and [strip] therefore also drop the XMP packet, which makes every viewer fall back to the Info dictionary
 * (the idea is checked with poppler in tools/verify/metadata_check.py: the old title stays visible if the XMP is
 * left, and the new one shows once it is removed). What [strip] clears is exactly: the Info dictionary and the
 * document-level XMP. It does NOT touch the content of the pages, per-page metadata, attachments or embedded
 * fonts' names - it is "remove the author/software/date labels", not forensic sanitising.
 * Writes a NEW file; the input is only read.
 */
object PdfMetadataTools {

    data class Info(
        val title: String = "",
        val author: String = "",
        val subject: String = "",
        val keywords: String = ""
    )

    private fun load(src: File): PDDocument {
        val doc = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
        if (doc.isEncrypted) {
            runCatching { doc.close() }
            throw IllegalStateException("encrypted")
        }
        return doc
    }

    fun read(src: File): Info {
        val doc = load(src)
        try {
            val i = doc.documentInformation
            return Info(i?.title.orEmpty(), i?.author.orEmpty(), i?.subject.orEmpty(), i?.keywords.orEmpty())
        } finally {
            runCatching { doc.close() }
        }
    }

    /** Sets the four fields (a blank one is removed, not stored as empty text). Other Info entries are kept. */
    fun write(src: File, out: File, info: Info) {
        val doc = load(src)
        try {
            val pages = doc.numberOfPages
            val di = doc.documentInformation ?: PDDocumentInformation()
            di.title = info.title.trim().ifEmpty { null }
            di.author = info.author.trim().ifEmpty { null }
            di.subject = info.subject.trim().ifEmpty { null }
            di.keywords = info.keywords.trim().ifEmpty { null }
            doc.documentInformation = di
            doc.documentCatalog.metadata = null          // stale XMP would override what we just wrote
            PdfStructureOptimizer.save(doc, out)
            verify(out, pages)
        } finally {
            runCatching { doc.close() }
        }
    }

    /** Removes the whole Info dictionary (author, creator, producer, dates, title...) and the XMP packet. */
    fun strip(src: File, out: File) {
        val doc = load(src)
        try {
            val pages = doc.numberOfPages
            doc.documentInformation = PDDocumentInformation()
            doc.documentCatalog.metadata = null
            PdfStructureOptimizer.save(doc, out)
            verify(out, pages)
        } finally {
            runCatching { doc.close() }
        }
    }

    private fun verify(out: File, pages: Int) {
        if (!PdfVerify.opensAsPdf(out, pages)) {
            runCatching { out.delete() }
            throw IllegalStateException("output failed verification")
        }
    }
}
