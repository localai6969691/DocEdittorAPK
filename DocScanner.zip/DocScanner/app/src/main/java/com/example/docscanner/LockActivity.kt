package com.example.docscanner

import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.example.docscanner.databinding.ActivityLockBinding
import com.example.docscanner.util.AppLock

/**
 * The screen shown over the app while [AppLock] is waiting for the user. DocScannerApp's lifecycle callbacks start
 * it; it asks for the fingerprint / PIN by itself when it comes to the front, and finishes (revealing whatever
 * screen was underneath) once authentication succeeds.
 *
 * Back does NOT leave this screen for the content below - it sends the app to the background instead, otherwise
 * Back would be a way around the lock. If the user cancels the system prompt, the screen stays with an
 * "Mở khoá" button: the prompt is shown automatically ONCE per visit ([promptedThisVisit], reset in [onStop]),
 * because the prompt closing resumes this activity again and re-prompting on every resume would trap the user in
 * a loop of prompts they cannot cancel out of.
 */
class LockActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLockBinding
    private var prompting = false
    private var promptedThisVisit = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLockBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnUnlock.setOnClickListener { prompt() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                moveTaskToBack(true)
            }
        })
    }

    override fun onResume() {
        super.onResume()
        if (AppLock.unlocked) {
            finish()
        } else if (!promptedThisVisit) {
            promptedThisVisit = true
            prompt()
        }
    }

    override fun onStop() {
        super.onStop()
        promptedThisVisit = false
    }

    private fun prompt() {
        if (prompting) return
        prompting = true
        AppLock.authenticate(this, getString(R.string.lock_prompt_title)) { ok ->
            prompting = false
            if (ok) {
                AppLock.markUnlocked()
                finish()
            }
        }
    }
}
