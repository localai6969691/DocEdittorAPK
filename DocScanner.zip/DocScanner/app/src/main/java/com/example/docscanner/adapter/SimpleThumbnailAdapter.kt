package com.example.docscanner.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.databinding.ItemThumbnailBinding
import com.example.docscanner.util.FileUtils

/** Read-only grid of page thumbnails - no rotate/delete/select controls, just a preview. Used by
 *  `ProjectScanActivity` to show the effect of the chosen preset on every page. */
class SimpleThumbnailAdapter : RecyclerView.Adapter<SimpleThumbnailAdapter.ViewHolder>() {

    private val items = mutableListOf<String>()

    fun submitList(paths: List<String>) {
        items.clear()
        items.addAll(paths)
        notifyDataSetChanged()
    }

    /** Call after overwriting the files at the same paths (e.g. a preset was just applied in
     *  place) so thumbnails reflect the new pixels instead of a stale decode. */
    fun refreshThumbnails() = notifyDataSetChanged()

    inner class ViewHolder(val binding: ItemThumbnailBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemThumbnailBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.ivThumbnail.setImageBitmap(FileUtils.decodeSampledBitmap(items[position], 200, 260))
    }

    override fun getItemCount(): Int = items.size
}
