package com.example.docscanner

import android.app.Application
import android.util.Log
import com.example.docscanner.model.EbookEditorState
import com.example.docscanner.model.PdfEditorState
import com.example.docscanner.model.PdfMergeState
import com.example.docscanner.model.ScanSessionManager
import com.example.docscanner.util.FileUtils
import org.opencv.android.OpenCVLoader

class DocScannerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val loaded = OpenCVLoader.initLocal()
        Log.d("DocScannerApp", "OpenCV loaded: $loaded")
        ScanSessionManager.init(this)
        PdfEditorState.init(this)
        EbookEditorState.init(this)
        PdfMergeState.init(this)

        // Best-effort cleanup of temp cache dirs that nothing else ever sweeps (see
        // FileUtils.cleanOldCacheFiles). Off the main thread so a slow filesystem never delays
        // app startup - this is pure housekeeping, nothing else depends on it finishing first.
        Thread { FileUtils.cleanOldCacheFiles(this) }.start()
    }
}
