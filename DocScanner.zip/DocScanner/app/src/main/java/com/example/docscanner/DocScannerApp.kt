package com.example.docscanner

import android.app.Activity
import android.app.Application
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.util.Log
import android.view.WindowManager
import android.view.View
import android.view.ViewGroup
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.example.docscanner.model.EbookEditorState
import com.example.docscanner.model.PdfEditorState
import com.example.docscanner.model.PdfMergeState
import com.example.docscanner.model.ScanSessionManager
import com.example.docscanner.util.AppLock
import com.example.docscanner.util.FileUtils
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import org.opencv.android.OpenCVLoader

class DocScannerApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val loaded = OpenCVLoader.initLocal()
        Log.d("DocScannerApp", "OpenCV loaded: $loaded")
        // PdfBox-Android (Apache 2.0) must have its resource loader initialised before ANY PDFBox
        // call (fonts, glyph lists...). Cheap: it only keeps the application context.
        PDFBoxResourceLoader.init(applicationContext)
        ScanSessionManager.init(this)
        PdfEditorState.init(this)
        EbookEditorState.init(this)
        PdfMergeState.init(this)

        registerActivityLifecycleCallbacks(EdgeToEdgeInsetsCallbacks)
        registerActivityLifecycleCallbacks(AppLockCallbacks)

        // Best-effort cleanup of temp cache dirs that nothing else ever sweeps (see
        // FileUtils.cleanOldCacheFiles). Off the main thread so a slow filesystem never delays
        // app startup - this is pure housekeeping, nothing else depends on it finishing first.
        Thread { FileUtils.cleanOldCacheFiles(this) }.start()
    }
}

/**
 * ONE central fix for "targetSdk 35+ forces edge-to-edge" (Google Play requires targetSdk 36 since
 * 2026-08-31): on Android 15+ the window is drawn UNDER the status/navigation bars and the old
 * opt-out attribute is ignored. Every screen here was laid out assuming the system bars take their
 * own space, so instead of editing ~25 layouts this callback fixes it once per Activity:
 *  - screens with a `toolbar` (all but the camera, crop and main screens): the toolbar grows by the
 *    status-bar height and pads its content down, so its colour continues under the status bar;
 *    other insets (sides, navigation bar, keyboard) become padding on the content root;
 *  - screens without one: the whole content root is padded on every side.
 * The keyboard (IME) is part of the bottom inset, because `adjustResize` no longer resizes an
 * edge-to-edge window by itself.
 * Only Android 15+ (API 35) needs this: below that the platform still reserves the bar space, and
 * adding padding there would double the gap - so the callback does nothing.
 */
private object EdgeToEdgeInsetsCallbacks : Application.ActivityLifecycleCallbacks {

    // setContentView() has usually NOT run yet when onActivityCreated fires (it is called from
    // Activity.super.onCreate), so the real content view is hooked lazily in onActivityStarted.
    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}

    override fun onActivityStarted(activity: Activity) {
        if (Build.VERSION.SDK_INT < 35) return
        val content = activity.findViewById<ViewGroup>(android.R.id.content) ?: return
        if (content.getTag(R.id.tag_insets_applied) == true) return
        content.setTag(R.id.tag_insets_applied, true)

        val toolbar: View? = activity.findViewById(R.id.toolbar)
        val toolbarBaseHeight = toolbar?.layoutParams?.height ?: 0
        val toolbarBaseTop = toolbar?.paddingTop ?: 0
        val toolbarHasFixedHeight = toolbarBaseHeight > 0

        // The toolbar is dark blue (@color/primary): light status-bar icons stay readable on it.
        if (toolbar != null) {
            WindowCompat.getInsetsController(activity.window, content).isAppearanceLightStatusBars = false
        }

        val baseLeft = content.paddingLeft
        val baseTop = content.paddingTop
        val baseRight = content.paddingRight
        val baseBottom = content.paddingBottom
        ViewCompat.setOnApplyWindowInsetsListener(content) { view, windowInsets ->
            val bars = windowInsets.getInsets(
                WindowInsetsCompat.Type.systemBars() or
                    WindowInsetsCompat.Type.displayCutout() or
                    WindowInsetsCompat.Type.ime()
            )
            val topForToolbar = toolbar != null && toolbarHasFixedHeight
            view.setPadding(
                baseLeft + bars.left,
                baseTop + if (topForToolbar) 0 else bars.top,
                baseRight + bars.right,
                baseBottom + bars.bottom
            )
            if (topForToolbar && toolbar != null) {
                val lp = toolbar.layoutParams
                lp.height = toolbarBaseHeight + bars.top
                toolbar.layoutParams = lp
                toolbar.setPadding(toolbar.paddingLeft, toolbarBaseTop + bars.top, toolbar.paddingRight, toolbar.paddingBottom)
            }
            WindowInsetsCompat.CONSUMED
        }
        ViewCompat.requestApplyInsets(content)
    }

    override fun onActivityResumed(activity: Activity) {}
    override fun onActivityPaused(activity: Activity) {}
    override fun onActivityStopped(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityDestroyed(activity: Activity) {}
}

/**
 * Connects [AppLock] to the activity lifecycle, once for the whole app:
 *  - counts started activities, so "the app went out of sight" is when the count falls to 0 (moving between this
 *    app's own screens never reaches 0: the next screen starts before the previous one stops);
 *  - whenever a screen other than [LockActivity] becomes visible, asks [AppLock.onActivityVisible] and, if the
 *    lock must show, starts [LockActivity] on top;
 *  - while a lock is enabled, creates every window with FLAG_SECURE.
 */
private object AppLockCallbacks : Application.ActivityLifecycleCallbacks {

    private var started = 0

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        if (AppLock.isEnabled(activity)) {
            activity.window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    override fun onActivityStarted(activity: Activity) {
        started++
        if (activity is LockActivity) return
        if (AppLock.onActivityVisible(activity)) {
            activity.startActivity(Intent(activity, LockActivity::class.java))
        }
    }

    override fun onActivityStopped(activity: Activity) {
        if (started > 0) started--
        if (started == 0) AppLock.onAppBackgrounded()
    }

    override fun onActivityResumed(activity: Activity) {}
    override fun onActivityPaused(activity: Activity) {}
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityDestroyed(activity: Activity) {}
}
