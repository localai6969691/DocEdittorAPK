package com.example.docscanner.util

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * "Duỗi thẳng dòng chữ cong" - flattens a photographed book page: the curled text lines AND the
 * horizontal squeeze of the letters towards the gutter. Commercial SDKs and CamScanner-class apps sell
 * "page dewarp / book mode"; the deep-learning versions (DocUNet, DewarpNet, UVDoc) need a model file, so
 * this is the classical text-line family instead: on a flat page every text line is straight and the lines
 * are equally spaced, so curled lines and changing spacing tell how the page was bent
 * (A. Ulges, C. Lampert, T. Breuel, "Document image dewarping using robust estimation of curled text
 * lines", ICDAR 2005; the cylinder / arc-length idea for the horizontal part follows H. Cao, X. Ding,
 * C. Liu, "Rectifying the bound document image captured by the camera: a model based approach", ICDAR 2003).
 *
 * VERTICAL part (since phiên 12):
 *  1. find glyph blobs, join them horizontally into text-line blobs, sample each blob's centre line;
 *  2. fit every line with a cubic polynomial by iteratively re-weighted least squares (outliers are
 *     dropped by a median-absolute-deviation rule);
 *  3. each line gets the displacement that moves it onto its own mean height; between lines the
 *     displacement is interpolated linearly (constant above the first / below the last line).
 *
 * HORIZONTAL part (phiên 14 - the "co ngang gần gáy sách" limit):
 *  4. the gap between neighbouring lines at column x is proportional to the local magnification, i.e.
 *     to 1 / depth of the page surface at x. Take the median gap per column, smooth it: s(x);
 *  5. depth Z(x) = 1 / s(x); with a pinhole camera the surface point is X = (x - cx) * Z / f. Walking
 *     along that curve, arc length u(x) = integral of sqrt(dX^2 + dZ^2) is the page coordinate of column x
 *     (this is where the extra squeeze caused by the page TILT, not only by distance, is undone);
 *  6. columns are re-spaced so u becomes linear and the width stays the same.
 * f is unknown (nothing in the page says which phone took the photo): it is assumed to be 0.7 x the page
 * image width. Measured on a physically simulated curled page with ground truth (tools/verify/
 * dewarp_horizontal_check.py: 27 combinations of curl strength, curl width and camera distance;
 * error = RMS deviation of a printed dot grid from a perfect grid, as % of page width):
 *    raw photo 2.36 -> vertical part only 1.21 -> with horizontal part 0.62 (median 0.69 -> 0.28);
 * any assumed f from 0.6 to 0.9 x width lands within 5% of the best, 1.1 x is clearly worse (so the value
 * errs low). The horizontal part switches on gradually: it needs the spacing profile to vary by more than 5%
 * (flat pages measure <= 5.3%, even mildly curled ones >= 7%) and is fully on at 9%.
 *
 * It refuses to touch a page unless (measured, tools/verify/dewarp_check.py):
 *  - at least 4 clean text lines, each wider than 22% of the page, were found;
 *  - the largest vertical correction is >= 2 px (otherwise it is a flat page and resampling would only
 *    blur) and <= 12% of the page height (larger means the "lines" were pictures / tables, not text);
 *  - the correction makes the lines it was estimated from measurably straighter (mean residual must
 *    drop by at least 15%);
 *  - the horizontal re-spacing never moves a column by more than 12% of the width.
 * On any failure it returns null and the caller keeps the original page. Not corrected: the horizontal
 * part assumes the gutter runs vertically (photo taken upright) and one smooth curl; a page curled in
 * several places, or a camera strongly tilted, is only partly fixed. The three weakest simulated cases
 * (an unrealistically strong curl: the page rising to half the camera distance) still leave ~3% error.
 *
 * The output is capped at [MAX_EDGE] px on the long side, because the two float remap tables cost
 * 8 bytes per pixel.
 */
object TextLineDewarp {

    private const val WORK_EDGE = 1000.0
    private const val MAX_EDGE = 2600
    private const val POLY_DEGREE = 3
    private const val MIN_LINES = 4
    private const val MAX_DISP_FRACTION = 0.12
    private const val MIN_DISP_PX = 2.0
    private const val MIN_GAIN = 0.85
    /** assumed camera focal length as a fraction of the page-image width (see class comment) */
    private const val F_REL = 0.7
    private const val ACT_LO = 0.05
    private const val ACT_HI = 0.09
    private const val MAX_SHIFT_FRACTION = 0.12

    private class LineModel(val x0: Double, val x1: Double, val coef: DoubleArray, val xm: Double) {
        fun at(x: Double): Double {
            val t = x - xm
            var y = 0.0
            for (c in coef) y = y * t + c // Horner, coef[0] = highest power
            return y
        }
    }

    /** The dewarped page, or null when the page should be left alone (see class comment). */
    fun dewarp(bitmap: Bitmap): Bitmap? {
        val mats = ArrayList<Mat>()
        fun track(m: Mat): Mat { mats.add(m); return m }
        return try {
            val src = if (max(bitmap.width, bitmap.height) > MAX_EDGE) ImageProcessor.downscaleTo(bitmap, MAX_EDGE) else bitmap
            val rgba = track(Mat())
            Utils.bitmapToMat(src, rgba)
            val gray = track(Mat())
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)

            val sc = min(1.0, WORK_EDGE / max(gray.cols(), gray.rows()).toDouble())
            val small = track(Mat())
            Imgproc.resize(gray, small, Size(), sc, sc, Imgproc.INTER_AREA)
            val ink = track(Mat())
            Imgproc.adaptiveThreshold(small, ink, 255.0, Imgproc.ADAPTIVE_THRESH_MEAN_C, Imgproc.THRESH_BINARY_INV, 31, 12.0)

            val lines = findLines(ink, ::track) ?: return null
            if (lines.size < MIN_LINES) return null
            val models = ArrayList<LineModel>()
            for ((xs, cs) in lines) fitRobust(xs, cs)?.let { models.add(LineModel(xs.first(), xs.last(), it.first, it.second)) }
            if (models.size < MIN_LINES) return null

            val wd = small.cols()
            val hd = small.rows()
            // displacement of each line at each column (NaN outside the line's extent)
            val lineY = Array(models.size) { DoubleArray(wd) { Double.NaN } }
            val lineD = Array(models.size) { DoubleArray(wd) { Double.NaN } }
            var maxDisp = 0.0
            var residualBefore = 0.0
            var residualAfter = 0.0
            for ((k, m) in models.withIndex()) {
                val a = max(0, m.x0.toInt())
                val b = min(wd - 1, m.x1.toInt())
                if (b - a < 8) continue
                var sum = 0.0
                for (x in a..b) { val f = m.at(x.toDouble()); lineY[k][x] = f; sum += f }
                val target = sum / (b - a + 1)
                val ys = DoubleArray(b - a + 1) { lineY[k][a + it] }
                val corrected = DoubleArray(ys.size)
                for (x in a..b) {
                    val d = target - lineY[k][x]
                    lineD[k][x] = d
                    maxDisp = max(maxDisp, abs(d))
                    corrected[x - a] = lineY[k][x] + d
                }
                residualBefore += linearResidual(ys)
                residualAfter += linearResidual(corrected)
            }
            if (maxDisp > MAX_DISP_FRACTION * hd) return null // "lines" were pictures / tables: do not tear the page
            if (maxDisp < MIN_DISP_PX) return null            // already straight: resampling would only blur
            if (residualAfter > MIN_GAIN * residualBefore) return null

            // displacement field D(y, x): linear between line centres, constant outside the first / last line
            val field = FloatArray(hd * wd)
            val centres = ArrayList<Double>(models.size)
            val disps = ArrayList<Double>(models.size)
            for (x in 0 until wd) {
                centres.clear(); disps.clear()
                val order = ArrayList<Int>()
                for (k in models.indices) if (!lineY[k][x].isNaN()) order.add(k)
                if (order.size < 2) continue
                order.sortBy { lineY[it][x] }
                for (k in order) { centres.add(lineY[k][x]); disps.add(lineD[k][x]) }
                var seg = 0
                for (y in 0 until hd) {
                    val yy = y.toDouble()
                    while (seg < centres.size - 2 && yy > centres[seg + 1]) seg++
                    val c0 = centres[seg]; val c1 = centres[seg + 1]
                    val t = if (c1 - c0 < 1e-6) 0.0 else ((yy - c0) / (c1 - c0)).coerceIn(0.0, 1.0)
                    field[y * wd + x] = (disps[seg] + t * (disps[seg + 1] - disps[seg])).toFloat()
                }
            }

            // horizontal re-spacing: source column g[x'] for every OUTPUT column x' (identity when not needed)
            val g = horizontalSource(lineY, wd) ?: DoubleArray(wd) { it.toDouble() }

            // backward map at work scale: for output column x' the source column is g[x'];
            // source row s with s + D(g[x'], s) = output row y  (3 fixed-point steps)
            val mapSmall = FloatArray(hd * wd)
            for (x in 0 until wd) {
                val c0 = g[x].toInt().coerceIn(0, wd - 1)
                val c1 = min(wd - 1, c0 + 1)
                val tc = (g[x] - c0).toFloat().coerceIn(0f, 1f)
                for (y in 0 until hd) {
                    var s = y.toFloat()
                    repeat(3) { s = y - sampleColumn(field, wd, hd, c0, c1, tc, s) }
                    mapSmall[y * wd + x] = s
                }
            }
            val mapYSmall = track(Mat(hd, wd, CvType.CV_32F))
            mapYSmall.put(0, 0, mapSmall)
            val fullW = gray.cols()
            val fullH = gray.rows()
            val mapY = track(Mat())
            Imgproc.resize(mapYSmall, mapY, Size(fullW.toDouble(), fullH.toDouble()), 0.0, 0.0, Imgproc.INTER_LINEAR)
            Core.multiply(mapY, org.opencv.core.Scalar(1.0 / sc), mapY)
            val mapX = track(Mat(fullH, fullW, CvType.CV_32F))
            val row = FloatArray(fullW) { fx ->
                val wx = (fx * sc).coerceIn(0.0, (wd - 1).toDouble())
                val i0 = wx.toInt().coerceIn(0, wd - 1)
                val i1 = min(wd - 1, i0 + 1)
                ((g[i0] + (g[i1] - g[i0]) * (wx - i0)) / sc).toFloat()
            }
            for (y in 0 until fullH) mapX.put(y, 0, row)

            val out = track(Mat())
            Imgproc.remap(rgba, out, mapX, mapY, Imgproc.INTER_LINEAR, Core.BORDER_REPLICATE)
            val result = Bitmap.createBitmap(fullW, fullH, Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(out, result)
            result
        } catch (t: Throwable) {
            null
        } finally {
            mats.forEach { runCatching { it.release() } }
        }
    }

    /** D at fractional column c0 + [tc] (between columns [c0] and [c1]) and row [y], linear in both (y clamped). */
    private fun sampleColumn(field: FloatArray, wd: Int, hd: Int, c0: Int, c1: Int, tc: Float, y: Float): Float {
        val yc = y.coerceIn(0f, (hd - 1).toFloat())
        val y0 = yc.toInt()
        val y1 = min(hd - 1, y0 + 1)
        val ty = yc - y0
        val a = field[y0 * wd + c0] * (1 - ty) + field[y1 * wd + c0] * ty
        val b = field[y0 * wd + c1] * (1 - ty) + field[y1 * wd + c1] * ty
        return a * (1 - tc) + b * tc
    }

    /**
     * Normalised local line spacing s(x) (median gap between neighbouring lines at column x, smoothed,
     * divided by its median), or null when it cannot be measured reliably. [lineY] holds each line's fitted
     * centre at every column (NaN outside the line's extent).
     */
    private fun spacingProfile(lineY: Array<DoubleArray>, wd: Int): DoubleArray? {
        val gapsAll = ArrayList<Double>()
        var x = 0
        while (x < wd) {
            val col = lineY.map { it[x] }.filter { !it.isNaN() }.sorted()
            if (col.size >= 3) for (i in 1 until col.size) gapsAll.add(col[i] - col[i - 1])
            x += 8
        }
        if (gapsAll.size < 20) return null
        gapsAll.sort()
        val med = gapsAll[gapsAll.size / 2]
        val raw = DoubleArray(wd) { Double.NaN }
        var valid = 0
        for (xx in 0 until wd) {
            val col = lineY.map { it[xx] }.filter { !it.isNaN() }.sorted()
            if (col.size < 2) continue
            val gaps = ArrayList<Double>()
            for (i in 1 until col.size) {
                val d = col[i] - col[i - 1]
                if (d > 0.5 * med && d < 1.8 * med) gaps.add(d)
            }
            if (gaps.size >= 2) { gaps.sort(); raw[xx] = gaps[gaps.size / 2]; valid++ }
        }
        if (valid < 0.6 * wd) return null
        // fill the holes by linear interpolation, constant at both ends
        val filled = DoubleArray(wd)
        var prev = -1
        for (i in 0 until wd) {
            if (!raw[i].isNaN()) {
                if (prev < 0) { for (j in 0 until i) filled[j] = raw[i] }
                else for (j in prev + 1 until i) filled[j] = raw[prev] + (raw[i] - raw[prev]) * (j - prev) / (i - prev)
                filled[i] = raw[i]; prev = i
            }
        }
        for (j in prev + 1 until wd) filled[j] = raw[prev]
        // Gaussian smoothing, sigma = 4% of the width
        val sigma = max(2.0, 0.04 * wd)
        val half = (3 * sigma).toInt()
        val kernel = DoubleArray(2 * half + 1) { Math.exp(-0.5 * ((it - half) / sigma) * ((it - half) / sigma)) }
        val ks = kernel.sum()
        val smooth = DoubleArray(wd) { i ->
            var acc = 0.0
            for (k in kernel.indices) acc += kernel[k] * filled[(i + k - half).coerceIn(0, wd - 1)]
            acc / ks
        }
        val sorted = smooth.sortedArray()
        val m = sorted[wd / 2]
        if (m <= 0.0) return null
        return DoubleArray(wd) { smooth[it] / m }
    }

    /**
     * Source column for every output column, from the arc length of the page surface implied by s(x)
     * (class comment, steps 4-6); null when the page does not look curled enough, or the correction would
     * be implausibly large.
     */
    private fun horizontalSource(lineY: Array<DoubleArray>, wd: Int): DoubleArray? {
        val s = spacingProfile(lineY, wd) ?: return null
        val range = s.max() - s.min()
        val w = ((range - ACT_LO) / (ACT_HI - ACT_LO)).coerceIn(0.0, 1.0)
        if (w <= 0.0) return null
        val z = DoubleArray(wd) { 1.0 / (1.0 + w * (s[it] - 1.0)) }
        val f = F_REL * wd
        val cx = 0.5 * wd
        val xs = DoubleArray(wd) { (it - cx) * z[it] / f }
        val u = DoubleArray(wd)
        var acc = 0.0
        for (i in 0 until wd) {
            val dx = gradient(xs, i)
            val dz = gradient(z, i)
            acc += sqrt(dx * dx + dz * dz) * f
            u[i] = acc
        }
        val total = u[wd - 1] - u[0]
        if (total <= 1e-9) return null
        for (i in 0 until wd) u[i] = (u[i] - u[0]) / total * (wd - 1)
        // invert the monotone map u(source) -> output column
        val g = DoubleArray(wd)
        var j = 0
        for (x in 0 until wd) {
            while (j < wd - 2 && u[j + 1] < x) j++
            val span = u[j + 1] - u[j]
            g[x] = if (span < 1e-9) j.toDouble() else (j + (x - u[j]) / span).coerceIn(0.0, (wd - 1).toDouble())
        }
        var shift = 0.0
        for (x in 0 until wd) shift = max(shift, abs(g[x] - x))
        return if (shift <= MAX_SHIFT_FRACTION * wd) g else null
    }

    /** numpy.gradient: central difference inside, one-sided at the ends. */
    private fun gradient(a: DoubleArray, i: Int): Double = when (i) {
        0 -> a[1] - a[0]
        a.size - 1 -> a[i] - a[i - 1]
        else -> (a[i + 1] - a[i - 1]) / 2.0
    }

    /** RMS distance of [ys] (sampled at consecutive columns) from its own least-squares straight line. */
    private fun linearResidual(ys: DoubleArray): Double {
        val n = ys.size
        if (n < 3) return 0.0
        var sx = 0.0; var sy = 0.0; var sxx = 0.0; var sxy = 0.0
        for (i in 0 until n) { sx += i; sy += ys[i]; sxx += i.toDouble() * i; sxy += i * ys[i] }
        val den = n * sxx - sx * sx
        val slope = if (abs(den) < 1e-9) 0.0 else (n * sxy - sx * sy) / den
        val icpt = (sy - slope * sx) / n
        var acc = 0.0
        for (i in 0 until n) { val e = ys[i] - (slope * i + icpt); acc += e * e }
        return sqrt(acc / n)
    }

    /**
     * Text-line blobs of [ink] as (column x positions, centre-line y positions). Returns null when the page
     * has too few glyph-sized blobs to say anything.
     */
    private fun findLines(ink: Mat, track: (Mat) -> Mat): List<Pair<DoubleArray, DoubleArray>>? {
        val labels = track(Mat())
        val stats = track(Mat())
        val cents = track(Mat())
        val n = Imgproc.connectedComponentsWithStats(ink, labels, stats, cents, 8, CvType.CV_32S)
        val heights = ArrayList<Int>()
        val boxes = IntArray(n * 5)
        for (i in 1 until n) {
            val x = stats.get(i, Imgproc.CC_STAT_LEFT)[0].toInt(); val y = stats.get(i, Imgproc.CC_STAT_TOP)[0].toInt()
            val w = stats.get(i, Imgproc.CC_STAT_WIDTH)[0].toInt(); val h = stats.get(i, Imgproc.CC_STAT_HEIGHT)[0].toInt()
            val a = stats.get(i, Imgproc.CC_STAT_AREA)[0].toInt()
            boxes[i * 5] = x; boxes[i * 5 + 1] = y; boxes[i * 5 + 2] = w; boxes[i * 5 + 3] = h; boxes[i * 5 + 4] = a
            if (h in 3..(ink.rows() / 8) && a >= 6) heights.add(h)
        }
        if (heights.size < 30) return null
        heights.sort()
        val glyphH = heights[heights.size / 2].toDouble()

        // keep glyph-sized blobs only (drops pictures, rules, huge dark areas), then join them horizontally
        val labelData = IntArray(ink.rows() * ink.cols())
        labels.get(0, 0, labelData)
        val keep = BooleanArray(n)
        for (i in 1 until n) {
            val w = boxes[i * 5 + 2]; val h = boxes[i * 5 + 3]; val a = boxes[i * 5 + 4]
            keep[i] = h >= 2 && h <= 4.5 * glyphH && w <= 12 * glyphH && a >= 4
        }
        val textBytes = ByteArray(labelData.size)
        for (i in labelData.indices) if (labelData[i] > 0 && keep[labelData[i]]) textBytes[i] = 255.toByte()
        val text = track(Mat(ink.rows(), ink.cols(), CvType.CV_8U))
        text.put(0, 0, textBytes)

        val kx = max(9, (2.2 * glyphH).toInt()); val ky = max(1, (0.25 * glyphH).toInt())
        val kernel = track(Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(kx.toDouble(), ky.toDouble())))
        val merged = track(Mat())
        Imgproc.dilate(text, merged, kernel)
        val labels2 = track(Mat())
        val stats2 = track(Mat())
        val cents2 = track(Mat())
        val n2 = Imgproc.connectedComponentsWithStats(merged, labels2, stats2, cents2, 8, CvType.CV_32S)
        val labelData2 = IntArray(ink.rows() * ink.cols())
        labels2.get(0, 0, labelData2)

        val cols = ink.cols()
        val result = ArrayList<Pair<DoubleArray, DoubleArray>>()
        val step = max(1, (glyphH / 2).toInt())
        for (i in 1 until n2) {
            val x = stats2.get(i, Imgproc.CC_STAT_LEFT)[0].toInt(); val y = stats2.get(i, Imgproc.CC_STAT_TOP)[0].toInt()
            val w = stats2.get(i, Imgproc.CC_STAT_WIDTH)[0].toInt(); val h = stats2.get(i, Imgproc.CC_STAT_HEIGHT)[0].toInt()
            if (w < 0.22 * cols || h > 3.2 * glyphH + 0.10 * ink.rows()) continue // too short / several lines merged
            val xs = ArrayList<Double>(); val cs = ArrayList<Double>(); val ext = ArrayList<Int>()
            var cx = 0
            while (cx < w) {
                var top = Int.MAX_VALUE; var bottom = -1; var hits = 0
                for (yy in y until y + h) {
                    val rowBase = yy * cols
                    var any = false
                    for (xx in (x + cx) until min(x + cx + step, x + w)) {
                        val idx = rowBase + xx
                        if (labelData2[idx] == i && textBytes[idx] != 0.toByte()) { any = true; break }
                    }
                    if (any) { hits++; if (yy < top) top = yy; if (yy > bottom) bottom = yy }
                }
                if (hits >= 2) { xs.add(x + cx + step / 2.0); cs.add((top + bottom) / 2.0); ext.add(bottom - top) }
                cx += step
            }
            if (xs.size >= 8) {
                ext.sort()
                if (ext[ext.size / 2] <= 2.4 * glyphH) result.add(xs.toDoubleArray() to cs.toDoubleArray()) // thin at every column = one line
            }
        }
        return result
    }

    /** Robust cubic fit: returns (coefficients highest power first, x-shift) or null. */
    private fun fitRobust(xs: DoubleArray, ys: DoubleArray): Pair<DoubleArray, Double>? {
        var keep = BooleanArray(xs.size) { true }
        var coef: DoubleArray? = null
        var xm = 0.0
        repeat(3) {
            val count = keep.count { it }
            if (count < POLY_DEGREE + 2) return null
            var sum = 0.0
            for (i in xs.indices) if (keep[i]) sum += xs[i]
            xm = sum / count
            coef = polyFit(xs, ys, keep, xm) ?: return null
            val res = DoubleArray(xs.size) { i ->
                var y = 0.0
                for (c in coef!!) y = y * (xs[i] - xm) + c
                ys[i] - y
            }
            val absRes = res.map { abs(it) }.sorted()
            val sigma = absRes[absRes.size / 2] * 1.4826 + 1e-6
            val limit = max(2.5 * sigma, 1.5)
            keep = BooleanArray(xs.size) { abs(res[it]) < limit }
        }
        return coef?.let { it to xm }
    }

    /** Least-squares polynomial of degree [POLY_DEGREE] through the kept points (normal equations, Gauss elimination). */
    private fun polyFit(xs: DoubleArray, ys: DoubleArray, keep: BooleanArray, xm: Double): DoubleArray? {
        val n = POLY_DEGREE + 1
        val a = Array(n) { DoubleArray(n + 1) }
        for (i in xs.indices) {
            if (!keep[i]) continue
            val t = xs[i] - xm
            val pw = DoubleArray(2 * n) // t^0 .. t^(2n-1)
            pw[0] = 1.0
            for (k in 1 until 2 * n) pw[k] = pw[k - 1] * t
            for (r in 0 until n) {
                for (c in 0 until n) a[r][c] += pw[r + c]
                a[r][n] += pw[r] * ys[i]
            }
        }
        for (col in 0 until n) {
            var piv = col
            for (r in col + 1 until n) if (abs(a[r][col]) > abs(a[piv][col])) piv = r
            if (abs(a[piv][col]) < 1e-12) return null
            val tmp = a[col]; a[col] = a[piv]; a[piv] = tmp
            for (r in 0 until n) {
                if (r == col) continue
                val f = a[r][col] / a[col][col]
                for (c in col..n) a[r][c] -= f * a[col][c]
            }
        }
        val low = DoubleArray(n) { a[it][n] / a[it][it] } // low[k] = coefficient of t^k
        return DoubleArray(n) { low[n - 1 - it] }         // highest power first, for Horner
    }
}
