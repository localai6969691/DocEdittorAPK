package com.example.docscanner

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityPdfDecorateBinding
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfDecorator
import com.example.docscanner.util.PdfExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * "Số trang & đầu/chân trang" - page numbers, a header and a footer, and Bates numbering (a running identifier such
 * as ABC-000123 on every page, used to label documents for legal and accounting work) written onto an existing PDF
 * by [PdfDecorator] without rasterizing it.
 *
 * Positions: the header is fixed top-centre and the footer bottom-left; the page number and the Bates number each
 * have their own position picker. Two labels on the same spot would be printed over each other, so [apply] refuses
 * that combination up front instead of producing a smudge.
 *
 * Header/footer text may use the tokens `{n}` (page number), `{N}` (page count) and `{b}` (Bates number) - the
 * layout shows a one-line reminder.
 */
class PdfDecorateActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPdfDecorateBinding
    private var srcFile: File? = null
    private var busy = false

    private val places = PdfDecorator.Place.values()
    private val numberTemplates = arrayOf("{n}", "Trang {n}", "{n} / {N}", "Trang {n} / {N}")

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) loadSource(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfDecorateBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.decorate_title)

        val positionLabels = resources.getStringArray(R.array.decorate_positions)
        val formatLabels = resources.getStringArray(R.array.decorate_number_formats)
        binding.spNumberPosition.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, positionLabels)
        binding.spBatesPosition.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, positionLabels)
        binding.spNumberFormat.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, formatLabels)
        binding.spNumberPosition.setSelection(places.indexOf(PdfDecorator.Place.BOTTOM_RIGHT))
        binding.spBatesPosition.setSelection(places.indexOf(PdfDecorator.Place.TOP_RIGHT))

        binding.btnDecoratePick.setOnClickListener { pdfPicker.launch(arrayOf("application/pdf")) }
        binding.btnDecorateApply.setOnClickListener { apply() }

        val restored = savedInstanceState?.getString(STATE_SRC)?.let { File(it) }?.takeIf { it.isFile }
        if (restored != null) {
            srcFile = restored
            binding.tvDecorateFile.text = savedInstanceState.getString(STATE_NAME) ?: restored.name
        } else {
            pdfPicker.launch(arrayOf("application/pdf"))
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        srcFile?.let {
            outState.putString(STATE_SRC, it.absolutePath)
            outState.putString(STATE_NAME, binding.tvDecorateFile.text.toString())
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) srcFile?.let { runCatching { it.delete() } }
    }

    private fun displayName(uri: Uri): String? = runCatching {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()

    private fun loadSource(uri: Uri) {
        setBusy(true)
        lifecycleScope.launch {
            val copy = withContext(Dispatchers.IO) { FileUtils.copyUriToTempFile(this@PdfDecorateActivity, uri, ".pdf") }
            val name = withContext(Dispatchers.IO) { displayName(uri) }
            setBusy(false)
            if (copy == null) {
                Toast.makeText(this@PdfDecorateActivity, R.string.sign_open_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            srcFile?.let { runCatching { it.delete() } }
            srcFile = copy
            binding.tvDecorateFile.text = name ?: copy.name
        }
    }

    private fun setBusy(value: Boolean) {
        busy = value
        binding.decorateProgress.visibility = if (value) View.VISIBLE else View.GONE
        binding.btnDecorateApply.isEnabled = !value
        binding.btnDecoratePick.isEnabled = !value
    }

    private fun intOf(text: CharSequence?, default: Int): Int = text?.toString()?.trim()?.toIntOrNull() ?: default

    private fun apply() {
        val src = srcFile
        if (busy) return
        if (src == null) {
            Toast.makeText(this, R.string.decorate_no_file, Toast.LENGTH_SHORT).show()
            return
        }
        val labels = mutableListOf<PdfDecorator.Label>()
        val used = HashSet<PdfDecorator.Place>()
        var clash = false
        fun add(place: PdfDecorator.Place, template: String) {
            if (!used.add(place)) clash = true
            labels.add(PdfDecorator.Label(place, template))
        }
        val header = binding.etHeader.text.toString().trim()
        val footer = binding.etFooter.text.toString().trim()
        if (header.isNotEmpty()) add(PdfDecorator.Place.TOP_CENTER, header)
        if (footer.isNotEmpty()) add(PdfDecorator.Place.BOTTOM_LEFT, footer)
        if (binding.cbPageNumber.isChecked) {
            add(places[binding.spNumberPosition.selectedItemPosition.coerceIn(0, places.size - 1)],
                numberTemplates[binding.spNumberFormat.selectedItemPosition.coerceIn(0, numberTemplates.size - 1)])
        }
        if (binding.cbBates.isChecked) {
            add(places[binding.spBatesPosition.selectedItemPosition.coerceIn(0, places.size - 1)], "{b}")
        }
        if (labels.isEmpty()) {
            Toast.makeText(this, R.string.decorate_nothing, Toast.LENGTH_SHORT).show()
            return
        }
        if (clash) {
            Toast.makeText(this, R.string.decorate_clash, Toast.LENGTH_LONG).show()
            return
        }
        val options = PdfDecorator.Options(
            labels = labels,
            startNumber = intOf(binding.etStartNumber.text, 1).coerceAtLeast(0),
            batesPrefix = binding.etBatesPrefix.text.toString().trim(),
            batesDigits = intOf(binding.etBatesDigits.text, 6).coerceIn(1, 12),
            skipFirstPages = intOf(binding.etSkipFirst.text, 0).coerceAtLeast(0)
        )
        setBusy(true)
        val out = File(PdfExporter.exportDir(this), "${FileUtils.defaultSecurityName("numbered")}.pdf")
        lifecycleScope.launch {
            val result = runCatching { withContext(Dispatchers.Default) { PdfDecorator.decorate(src, out, options) } }
            setBusy(false)
            val pages = result.getOrNull()
            if (pages == null) {
                runCatching { out.delete() }
                val encrypted = result.exceptionOrNull()?.message == "encrypted"
                Toast.makeText(this@PdfDecorateActivity, if (encrypted) R.string.sign_encrypted else R.string.decorate_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            Toast.makeText(this@PdfDecorateActivity, getString(R.string.decorate_done, out.name, pages), Toast.LENGTH_LONG).show()
            finish()
        }
    }

    companion object {
        private const val STATE_SRC = "decorate_src"
        private const val STATE_NAME = "decorate_name"
    }
}
