package com.example.docscanner.util

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Point
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.max
import kotlin.math.sqrt

/**
 * All the OpenCV work lives here: finding the 4 corners of a document in a
 * photo, warping that quadrilateral into a flat top-down rectangle, and
 * applying a handful of "scan style" filters to the result.
 */
object ImageProcessor {

    /** Four corners in BITMAP PIXEL space, ordered top-left, top-right, bottom-right, bottom-left. */
    data class Quad(val tl: Point, val tr: Point, val br: Point, val bl: Point)

    enum class ScanFilter {
        ORIGINAL, ENHANCE, GRAY, BW,
        /** "Trắng đen nâng cao" - Sauvola local binarization, see [DocumentEnhancer.sauvolaBinarize]. */
        BW_SAUVOLA,
        /** "Xóa bóng" - keeps colour, whitens the paper and evens out shadows, see [DocumentEnhancer.normalizeBackground]. */
        CLEAN
    }

    /** A safe fallback quad (whole image with a small margin) used when no document contour is found. */
    fun defaultCorners(width: Int, height: Int): Quad {
        val marginX = width * 0.05
        val marginY = height * 0.05
        return Quad(
            Point(marginX, marginY),
            Point(width - marginX, marginY),
            Point(width - marginX, height - marginY),
            Point(marginX, height - marginY)
        )
    }

    /**
     * Tries to find a 4-sided document contour in [bitmap]. Returns null if nothing convincing
     * was found (caller should fall back to [defaultCorners]) - this is also the expected result
     * for an already-flat digital page (e.g. rendered from an existing PDF), which is fine since
     * the default full-frame corners are exactly correct for that case.
     */
    fun detectDocumentCorners(bitmap: Bitmap): Quad? {
        val src = Mat()
        Utils.bitmapToMat(bitmap, src)

        val maxDim = max(src.rows(), src.cols()).toDouble()
        val scale = if (maxDim > 900.0) 900.0 / maxDim else 1.0
        val resized = Mat()
        Imgproc.resize(src, resized, Size(src.cols() * scale, src.rows() * scale))

        val gray = Mat()
        Imgproc.cvtColor(resized, gray, Imgproc.COLOR_RGBA2GRAY)
        Imgproc.GaussianBlur(gray, gray, Size(5.0, 5.0), 0.0)

        val edged = Mat()
        Imgproc.Canny(gray, edged, 50.0, 150.0)
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(3.0, 3.0))
        Imgproc.dilate(edged, edged, kernel)

        val contours = mutableListOf<MatOfPoint>()
        val hierarchy = Mat()
        Imgproc.findContours(edged, contours, hierarchy, Imgproc.RETR_LIST, Imgproc.CHAIN_APPROX_SIMPLE)

        val minArea = resized.rows() * resized.cols() * 0.2
        var result: Quad? = null

        for (contour in contours.sortedByDescending { Imgproc.contourArea(it) }.take(5)) {
            val area = Imgproc.contourArea(contour)
            if (area < minArea) continue
            val contour2f = MatOfPoint2f(*contour.toArray())
            val peri = Imgproc.arcLength(contour2f, true)
            val approx = MatOfPoint2f()
            Imgproc.approxPolyDP(contour2f, approx, 0.02 * peri, true)
            if (approx.total() == 4L) {
                val scaledBack = approx.toArray().map { Point(it.x / scale, it.y / scale) }
                result = orderPoints(scaledBack.toTypedArray())
                contour2f.release()
                approx.release()
                break
            }
            contour2f.release()
            approx.release()
        }

        contours.forEach { it.release() }
        src.release()
        resized.release()
        gray.release()
        edged.release()
        hierarchy.release()
        kernel.release()
        return result
    }

    private fun orderPoints(pts: Array<Point>): Quad {
        val tl = pts.minByOrNull { it.x + it.y }!!
        val br = pts.maxByOrNull { it.x + it.y }!!
        val tr = pts.minByOrNull { it.y - it.x }!!
        val bl = pts.maxByOrNull { it.y - it.x }!!
        return Quad(tl, tr, br, bl)
    }

    private fun distance(a: Point, b: Point): Double {
        val dx = a.x - b.x
        val dy = a.y - b.y
        return sqrt(dx * dx + dy * dy)
    }

    /** Warps the [quad] region of [bitmap] into a flat, top-down rectangular bitmap. */
    fun warpDocument(bitmap: Bitmap, quad: Quad): Bitmap {
        val src = Mat()
        Utils.bitmapToMat(bitmap, src)

        val maxWidth = max(distance(quad.tl, quad.tr), distance(quad.bl, quad.br)).toInt().coerceAtLeast(1)
        val maxHeight = max(distance(quad.tl, quad.bl), distance(quad.tr, quad.br)).toInt().coerceAtLeast(1)

        val srcPoints = MatOfPoint2f(quad.tl, quad.tr, quad.br, quad.bl)
        val dstPoints = MatOfPoint2f(
            Point(0.0, 0.0),
            Point((maxWidth - 1).toDouble(), 0.0),
            Point((maxWidth - 1).toDouble(), (maxHeight - 1).toDouble()),
            Point(0.0, (maxHeight - 1).toDouble())
        )

        val transform = Imgproc.getPerspectiveTransform(srcPoints, dstPoints)
        val dst = Mat()
        Imgproc.warpPerspective(src, dst, transform, Size(maxWidth.toDouble(), maxHeight.toDouble()))

        val result = Bitmap.createBitmap(maxWidth, maxHeight, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(dst, result)

        src.release()
        dst.release()
        transform.release()
        srcPoints.release()
        dstPoints.release()
        return result
    }

    /** Applies one of the scan-style filters. [ScanFilter.ORIGINAL] is a no-op (returns [bitmap] as-is). */
    fun applyFilter(bitmap: Bitmap, filter: ScanFilter): Bitmap {
        if (filter == ScanFilter.ORIGINAL) return bitmap
        // The two newer filters have their own, self-contained pipelines (they return the input
        // bitmap unchanged on any failure) - see DocumentEnhancer.
        if (filter == ScanFilter.BW_SAUVOLA) return DocumentEnhancer.sauvolaBinarize(bitmap)
        if (filter == ScanFilter.CLEAN) return DocumentEnhancer.normalizeBackground(bitmap)

        val src = Mat()
        Utils.bitmapToMat(bitmap, src)

        when (filter) {
            ScanFilter.GRAY -> {
                Imgproc.cvtColor(src, src, Imgproc.COLOR_RGBA2GRAY)
                Imgproc.cvtColor(src, src, Imgproc.COLOR_GRAY2RGBA)
            }
            ScanFilter.BW -> {
                val gray = Mat()
                Imgproc.cvtColor(src, gray, Imgproc.COLOR_RGBA2GRAY)
                // Adaptive (local) threshold: robust to uneven lighting across the page,
                // gives crisp black text on white without needing a uniform scan setup.
                Imgproc.adaptiveThreshold(
                    gray, gray, 255.0,
                    Imgproc.ADAPTIVE_THRESH_GAUSSIAN_C, Imgproc.THRESH_BINARY,
                    25, 15.0
                )
                Imgproc.cvtColor(gray, src, Imgproc.COLOR_GRAY2RGBA)
                gray.release()
            }
            ScanFilter.ENHANCE -> {
                src.convertTo(src, -1, 1.15, 12.0)
            }
            ScanFilter.ORIGINAL, ScanFilter.BW_SAUVOLA, ScanFilter.CLEAN -> {} // handled above
        }

        val result = Bitmap.createBitmap(src.cols(), src.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(src, result)
        src.release()
        return result
    }

    /**
     * Boosts color saturation a bit. Color e-ink panels (the common Kaleido-style ones) render
     * color noticeably more muted than an LCD because color is produced by a filter layer sitting
     * on top of the grayscale panel, so a small saturation boost helps colors stay distinguishable.
     */
    fun boostSaturation(bitmap: Bitmap, factor: Double = 1.35): Bitmap {
        val src = Mat()
        Utils.bitmapToMat(bitmap, src)
        val rgb = Mat()
        Imgproc.cvtColor(src, rgb, Imgproc.COLOR_RGBA2RGB)
        val hsv = Mat()
        Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)
        val channels = ArrayList<Mat>()
        Core.split(hsv, channels)
        channels[1].convertTo(channels[1], -1, factor, 0.0)
        Core.merge(channels, hsv)
        Imgproc.cvtColor(hsv, rgb, Imgproc.COLOR_HSV2RGB)
        Imgproc.cvtColor(rgb, src, Imgproc.COLOR_RGB2RGBA)

        val result = Bitmap.createBitmap(src.cols(), src.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(src, result)
        src.release()
        rgb.release()
        hsv.release()
        channels.forEach { it.release() }
        return result
    }

    /**
     * Heuristic: is this page meaningfully colorful, or effectively grayscale/black-and-white?
     * Used to auto-pick between the e-ink "text" (B&W) and "color" presets per page. Looks at
     * the fraction of pixels with non-trivial saturation - a plain scanned text page still has a
     * little color noise from the camera sensor and lighting, so a small saturated fraction is
     * treated as noise rather than real color content.
     */
    fun isColorPage(bitmap: Bitmap, saturationThreshold: Int = 40, colorPixelFraction: Double = 0.02): Boolean {
        val src = Mat()
        Utils.bitmapToMat(bitmap, src)

        // Classification doesn't need full resolution - downscale first for speed.
        val maxDim = max(src.rows(), src.cols()).toDouble()
        val scale = if (maxDim > 300.0) 300.0 / maxDim else 1.0
        val small = Mat()
        Imgproc.resize(src, small, Size(src.cols() * scale, src.rows() * scale))

        val rgb = Mat()
        Imgproc.cvtColor(small, rgb, Imgproc.COLOR_RGBA2RGB)
        val hsv = Mat()
        Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)
        val channels = ArrayList<Mat>()
        Core.split(hsv, channels)
        val satChannel = channels[1]

        val totalPixels = satChannel.rows() * satChannel.cols()
        val coloredMask = Mat()
        Imgproc.threshold(satChannel, coloredMask, saturationThreshold.toDouble(), 255.0, Imgproc.THRESH_BINARY)
        val coloredCount = Core.countNonZero(coloredMask)

        src.release()
        small.release()
        rgb.release()
        hsv.release()
        coloredMask.release()
        channels.forEach { it.release() }

        if (totalPixels == 0) return false
        return (coloredCount.toDouble() / totalPixels) > colorPixelFraction
    }

    /**
     * Suggests where the book gutter (the shadowed fold between two facing pages) sits in a photo
     * of an open book, as an X coordinate in bitmap pixel space. Looks for the darkest vertical
     * strip within the middle 40% of the image width (the gutter shadow is reliably somewhere near
     * the horizontal center, and reliably darker than the flat page surface around it). This is
     * only ever used as a *starting position* for a draggable line the user can correct by hand -
     * it does not need to be perfect, just a reasonable default.
     */
    fun detectGutterX(bitmap: Bitmap): Double {
        val src = Mat()
        Utils.bitmapToMat(bitmap, src)
        val gray = Mat()
        Imgproc.cvtColor(src, gray, Imgproc.COLOR_RGBA2GRAY)

        val searchStart = (gray.cols() * 0.3).toInt()
        val searchEnd = (gray.cols() * 0.7).toInt()
        if (searchEnd <= searchStart) {
            src.release()
            gray.release()
            return bitmap.width / 2.0
        }

        val region = gray.submat(0, gray.rows(), searchStart, searchEnd)
        val colMeans = Mat()
        Core.reduce(region, colMeans, 0, Core.REDUCE_AVG)

        var minVal = Double.MAX_VALUE
        var minIdx = (searchEnd - searchStart) / 2
        for (i in 0 until colMeans.cols()) {
            val v = colMeans.get(0, i)[0]
            if (v < minVal) {
                minVal = v
                minIdx = i
            }
        }

        src.release()
        gray.release()
        region.release()
        colMeans.release()
        return (searchStart + minIdx).toDouble()
    }

    /**
     * Downscales [bitmap] so its longest edge doesn't exceed [maxLongEdgePx], keeping aspect
     * ratio. Used by the e-ink presets: e-ink panels can't render more detail than their native
     * resolution (and color mode on common color panels is native res anyway), so keeping a much
     * bigger image only bloats the file and slows page turns without any visible benefit.
     */
    fun downscaleTo(bitmap: Bitmap, maxLongEdgePx: Int): Bitmap {
        val longEdge = max(bitmap.width, bitmap.height)
        if (longEdge <= maxLongEdgePx) return bitmap
        val scale = maxLongEdgePx.toFloat() / longEdge
        val newWidth = (bitmap.width * scale).toInt().coerceAtLeast(1)
        val newHeight = (bitmap.height * scale).toInt().coerceAtLeast(1)
        return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true)
    }
}
