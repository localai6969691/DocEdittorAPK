package com.example.docscanner.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Environment
import com.example.docscanner.model.ScanPage
import java.io.File
import java.io.FileOutputStream

/**
 * Builds output PDFs for every tool in the app. Pages are always drawn as images onto a
 * [PdfDocument] using only Android's built-in APIs - no third-party PDF library. That keeps the
 * dependency list (and therefore the CI build) simple, at the cost of always producing an
 * image-based PDF: any real, selectable text from an imported source PDF will not survive as
 * selectable text after passing through the merge/page-editor tools.
 */
object PdfExporter {

    data class ExportResult(val pdfFile: File, val textFile: File?)

    // Used to convert a bitmap's pixel size into a PDF page size (in points, 72pt = 1 inch) that
    // keeps a sensible physical page size instead of a huge or tiny page. This is the right thing
    // to assume for a camera-captured (cropped) page - there's no "true" DPI for a photo, so any
    // convention is as good as another. It is WRONG, though, for a page that was itself rendered
    // from an existing PDF at a known DPI (see PdfImportHelper.renderPage): that render already
    // has a real, correct pixel-to-inch ratio, and re-guessing 150 instead of using the actual
    // render DPI makes the output page's declared physical size wrong (too large, since every
    // render DPI this app uses is > 150) - readers/viewers that respect the declared page size
    // (many dedicated e-readers do, unlike most phone apps which auto-fit) would show it oversized
    // or scaled oddly. [addBitmapAsPage]'s optional `dpi` param, [exportSession]'s per-page
    // [ScanPage.sourceDpi], and [exportImagePaths]'s `sourceDpi` param all exist to let a caller
    // that DOES know the true DPI (see MainActivity's import/compress functions) override this
    // default instead of silently getting the wrong physical size. See TECHNICAL_DOCS.md.
    private const val ASSUMED_DPI = 150f

    fun exportDir(context: Context): File {
        val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun addBitmapAsPage(document: PdfDocument, bitmap: Bitmap, pageNumber: Int, dpi: Float = ASSUMED_DPI) {
        val widthPt = (bitmap.width / dpi * 72f).toInt().coerceAtLeast(1)
        val heightPt = (bitmap.height / dpi * 72f).toInt().coerceAtLeast(1)
        val pageInfo = PdfDocument.PageInfo.Builder(widthPt, heightPt, pageNumber).create()
        val page = document.startPage(pageInfo)
        val scaled = if (bitmap.width == pageInfo.pageWidth && bitmap.height == pageInfo.pageHeight) {
            bitmap
        } else {
            Bitmap.createScaledBitmap(bitmap, pageInfo.pageWidth, pageInfo.pageHeight, true)
        }
        page.canvas.drawBitmap(scaled, 0f, 0f, null)
        document.finishPage(page)
        if (scaled !== bitmap) scaled.recycle()
    }

    fun rotateBitmap(bitmap: Bitmap, degrees: Int): Bitmap {
        if (degrees % 360 == 0) return bitmap
        val matrix = Matrix().apply { postRotate(degrees.toFloat()) }
        val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        if (rotated !== bitmap) bitmap.recycle()
        return rotated
    }

    /** Main scan flow export: session pages -> one PDF, optionally with a companion OCR .txt file. */
    suspend fun exportSession(
        context: Context,
        pages: List<ScanPage>,
        withOcr: Boolean,
        baseName: String = FileUtils.defaultDocName(),
        onOcrProgress: (Int, Int) -> Unit = { _, _ -> }
    ): ExportResult {
        val document = PdfDocument()

        pages.forEachIndexed { index, page ->
            val bitmap = BitmapFactory.decodeFile(page.filePath) ?: return@forEachIndexed
            addBitmapAsPage(document, bitmap, index + 1, dpi = page.sourceDpi ?: ASSUMED_DPI)
            bitmap.recycle()
        }

        val outDir = exportDir(context)
        val pdfFile = File(outDir, "$baseName.pdf")
        FileOutputStream(pdfFile).use { document.writeTo(it) }
        document.close()

        val textFile = if (withOcr) {
            writeOcrTextFile(context, pages.map { it.filePath }, baseName, onOcrProgress)
        } else {
            null
        }
        return ExportResult(pdfFile, textFile)
    }

    /** Decodes each of [imagePaths] one at a time (same bounded-memory shape as the PDF-page loop
     *  above - never more than 1 page's bitmap resident at once, regardless of page count), runs
     *  OCR on it, and writes a companion `<baseName>.txt` transcript - NOT a searchable text layer
     *  inside any PDF (this app writes every PDF as image-only pages, see the class doc comment
     *  and TECHNICAL_DOCS.md's "OCR text embedding into PDF" limitation) - just a plain-text side
     *  file next to it. Split out of [exportSession] so the main "Quét" flow's NEW
     *  compressed-export path (`PageListActivity`, via [PdfCompressor] instead of this class's own
     *  [PdfDocument]-based page writing) can still offer the same OCR checkbox without duplicating
     *  this loop. Takes paths rather than already-decoded bitmaps specifically so it can decode
     *  each page on its own and let it go before moving to the next, rather than requiring every
     *  caller to hold the whole session's bitmaps in memory at once just to call this - the PDF
     *  write and the OCR pass were already two independent steps sharing nothing but the source
     *  file paths and the output [baseName], so re-decoding each JPEG a second time here (once
     *  more than [exportSession]'s own PDF-writing loop does) trades a small, cheap amount of
     *  repeated JPEG decoding for that bounded-memory guarantee - worth it since OCR itself is far
     *  more expensive per page than a JPEG decode. Returns null if OCR produced nothing worth
     *  keeping (every page blank) - matches [exportSession]'s previous inline behavior exactly. */
    suspend fun writeOcrTextFile(
        context: Context,
        imagePaths: List<String>,
        baseName: String,
        onOcrProgress: (Int, Int) -> Unit = { _, _ -> }
    ): File? {
        val ocrTexts = imagePaths.mapIndexed { index, path ->
            onOcrProgress(index + 1, imagePaths.size)
            val bitmap = BitmapFactory.decodeFile(path)
            val text = if (bitmap != null) OcrHelper.recognize(bitmap) else ""
            bitmap?.recycle()
            text
        }
        if (ocrTexts.none { it.isNotBlank() }) return null
        val textFile = File(exportDir(context), "$baseName.txt")
        textFile.bufferedWriter().use { w ->
            ocrTexts.forEachIndexed { i, text ->
                w.write("--- Trang ${i + 1} ---\n")
                w.write(text.ifBlank { "(không nhận diện được văn bản)" })
                w.write("\n\n")
            }
        }
        return textFile
    }

    /** Builds a PDF from a list of image file paths with a per-page rotation (Page manager tool,
     *  and the Project flow's Export-PDF stage). If [chapterTitles] is non-empty, real PDF
     *  bookmarks are added on top via [PdfBookmarkInjector] - a best-effort patch of the file this
     *  function already wrote, so a failure there (should not normally happen - see that class's
     *  doc comment) just means the plain PDF ships without bookmarks, never a broken file.
     *  [sourceDpi] defaults to the camera-capture convention ([ASSUMED_DPI]) - pass the actual
     *  render DPI when [imagePaths] came from rendering an existing PDF (see [ASSUMED_DPI]'s doc
     *  comment for why this matters; `PdfPageEditorActivity` does this since it always loads from
     *  a picked PDF, never a camera capture). */
    fun exportImagePaths(
        context: Context,
        imagePaths: List<String>,
        rotations: List<Int>,
        baseName: String = FileUtils.defaultDocName(),
        chapterTitles: List<String> = emptyList(),
        chapterStartPageIndex: List<Int> = emptyList(),
        sourceDpi: Float = ASSUMED_DPI
    ): File {
        val document = PdfDocument()
        imagePaths.forEachIndexed { index, path ->
            val decoded = BitmapFactory.decodeFile(path) ?: return@forEachIndexed
            val rotation = rotations.getOrElse(index) { 0 }
            val bitmap = if (rotation != 0) rotateBitmap(decoded, rotation) else decoded
            addBitmapAsPage(document, bitmap, index + 1, dpi = sourceDpi)
            bitmap.recycle()
        }
        val outDir = exportDir(context)
        val pdfFile = File(outDir, "$baseName.pdf")
        FileOutputStream(pdfFile).use { document.writeTo(it) }
        document.close()
        if (chapterTitles.isNotEmpty()) {
            val patched = PdfBookmarkInjector.tryAddBookmarks(
                pdfFile.readBytes(), imagePaths.size, chapterTitles, chapterStartPageIndex
            )
            if (patched != null) pdfFile.writeBytes(patched)
        }
        return pdfFile
    }

    /** Saves each page as its own JPEG under Documents/<baseName>/page_N.jpg. */
    fun exportAsImages(
        context: Context,
        imagePaths: List<String>,
        rotations: List<Int>,
        baseName: String = FileUtils.defaultDocName()
    ): List<File> {
        val outDir = File(exportDir(context), baseName)
        if (!outDir.exists()) outDir.mkdirs()
        val results = mutableListOf<File>()
        imagePaths.forEachIndexed { index, path ->
            val decoded = BitmapFactory.decodeFile(path) ?: return@forEachIndexed
            val rotation = rotations.getOrElse(index) { 0 }
            val bitmap = if (rotation != 0) rotateBitmap(decoded, rotation) else decoded
            val file = File(outDir, "page_${index + 1}.jpg")
            FileOutputStream(file).use { out -> bitmap.compress(Bitmap.CompressFormat.JPEG, 92, out) }
            bitmap.recycle()
            results.add(file)
        }
        return results
    }

    /** Merges several source PDFs (as content Uris) into one new PDF by rasterizing every page. */
    fun mergePdfs(
        context: Context,
        uris: List<Uri>,
        dpi: Int = 200,
        baseName: String = "merged_${FileUtils.defaultDocName()}",
        onFileProgress: (Int, Int) -> Unit = { _, _ -> }
    ): File {
        val document = PdfDocument()
        var pageNumber = 1
        uris.forEachIndexed { fileIndex, uri ->
            onFileProgress(fileIndex + 1, uris.size)
            val paths = PdfImportHelper.renderAllPagesToFiles(context, uri, dpi)
            paths.forEach { path ->
                val bitmap = BitmapFactory.decodeFile(path)
                if (bitmap != null) {
                    addBitmapAsPage(document, bitmap, pageNumber++)
                    bitmap.recycle()
                }
                runCatching { File(path).delete() }
            }
        }
        val outDir = exportDir(context)
        val pdfFile = File(outDir, "$baseName.pdf")
        FileOutputStream(pdfFile).use { document.writeTo(it) }
        document.close()
        return pdfFile
    }
}
