package com.example.docscanner.util

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.geometry.Geometry
import org.opencv.imgproc.Imgproc
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * "Tự xoay đúng chiều": finds out whether a page photo is upright, upside down or turned 90 degrees.
 * Paid OCR/scanner SDKs sell this as page-orientation detection; the method here is the classic one from
 * D. Bloomberg, G. Kopec, L. Dasari, "Measuring document image skew and orientation", SPIE 2422, 1995
 * (also the basis of the free Leptonica library), written from the paper and from the description in the
 * Xerox patent US 5,276,742 (Google Patents lists it as expired; that is not legal advice):
 * in Roman-alphabet text there are clearly more strokes that rise above the x-height band (b d f h k l t,
 * capitals, and the accents of Vietnamese) than strokes that drop below the baseline (g j p q y), so
 * counting them tells up from down. The 90-degree question is answered first, by comparing the text-line
 * profile score of the page with the same page turned 90 degrees.
 *
 * Differences from the paper, all measured on synthetic pages (tools/verify/orientation_check.py):
 *  - strokes are found per text line from the line's own row profile instead of hit-or-miss
 *    structuring elements, so it does not depend on the scan resolution;
 *  - only strokes taller than 0.35 x-height count, otherwise the commas of a table of numbers look like
 *    descenders and a page of figures is read as "upside down" with high confidence (measured!);
 *  - it DECLINES (returns null) unless the count is statistically significant (the paper's 3-sigma test),
 *    large enough, large relative to the glyph bodies, and clearly one-sided. Digits-only pages, ALL-CAPS
 *    text, photos, blank pages and non-Latin scripts therefore give "unsure", never a wrong turn.
 * Measured (tools/verify/orientation_check.py): 0 wrong out of 480 synthetic pages (English and Vietnamese text, 4 fonts,
 * 3 sizes, all four rotations, skew of 0/+3/-4/+6 degrees, noise); 75-90% were decided, the rest declined;
 * ALL-CAPS, digits-only, blank and noise pages were declined too.
 */
object PageOrientation {

    private const val WORK_EDGE = 1100.0
    private const val MIN_COUNT = 40
    private const val MIN_FRACTION = 0.12
    private const val MIN_CONF = 0.2
    private const val MIN_LINES = 3

    /** Degrees the page must be rotated COUNTER-clockwise (0, 90, 180 or 270) to be upright, or null. */
    fun detectCcwDegrees(bitmap: Bitmap): Int? {
        val mats = ArrayList<Mat>()
        fun track(m: Mat): Mat { mats.add(m); return m }
        return try {
            val rgba = track(Mat())
            Utils.bitmapToMat(bitmap, rgba)
            val gray = track(Mat())
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
            val scale = min(1.0, WORK_EDGE / max(gray.cols(), gray.rows()).toDouble())
            val small = track(Mat())
            Imgproc.resize(gray, small, Size(), scale, scale, Imgproc.INTER_AREA)

            val ink0 = track(inkMask(small))
            val frac = Core.countNonZero(ink0).toDouble() / (ink0.rows().toDouble() * ink0.cols())
            if (frac < 0.004 || frac > 0.5) return null

            val turned = track(Mat())
            Core.rotate(small, turned, Core.ROTATE_90_COUNTERCLOCKWISE)
            val h = DocumentEnhancer.analyzeSkew(small)
            val v = DocumentEnhancer.analyzeSkew(turned)
            if (max(h.score, v.score) <= 0.0 || max(h.prominence, v.prominence) < 1.25) return null

            val vertical = v.score > 1.5 * h.score
            val base = if (vertical) turned else small
            val angle = if (vertical) v.degrees else h.degrees
            val upright = track(Mat())
            if (angle != 0.0) {
                val m = Geometry.getRotationMatrix2D(Point(base.cols() / 2.0, base.rows() / 2.0), angle, 1.0)
                Imgproc.warpAffine(base, upright, m, base.size(), Imgproc.INTER_LINEAR, Core.BORDER_CONSTANT, Scalar(255.0))
                m.release()
            } else {
                base.copyTo(upright)
            }
            val ink = track(inkMask(upright))
            val sign = vote(ink)
            if (sign == 0) return null
            if (vertical) (if (sign > 0) 90 else 270) else (if (sign > 0) 0 else 180)
        } catch (t: Throwable) {
            null
        } finally {
            mats.forEach { runCatching { it.release() } }
        }
    }

    private fun inkMask(gray: Mat): Mat {
        val ink = Mat()
        Imgproc.adaptiveThreshold(gray, ink, 255.0, Imgproc.ADAPTIVE_THRESH_MEAN_C, Imgproc.THRESH_BINARY_INV, 31, 12.0)
        return ink
    }

    /** +1 = text is upright, -1 = upside down, 0 = cannot tell. */
    private fun vote(ink: Mat): Int {
        val counts = countStrokes(ink) ?: return 0
        val (na, nd, nx, lines) = counts
        val total = na + nd
        if (lines < MIN_LINES || total < MIN_COUNT || nx <= 0 || total < MIN_FRACTION * nx) return 0
        if (abs(na - nd) <= 3.0 * (sqrt(na.toDouble()) + sqrt(nd.toDouble())) / sqrt(2.0)) return 0
        val conf = (na - nd).toDouble() / total
        if (abs(conf) < MIN_CONF) return 0
        return if (conf > 0) 1 else -1
    }

    private data class Counts(val up: Int, val down: Int, val bodies: Int, val lines: Int)

    private fun lineBands(ink: Mat): List<IntArray> {
        val smeared = Mat()
        val profile = Mat()
        try {
            val k = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(25.0, 1.0))
            Imgproc.dilate(ink, smeared, k)
            k.release()
            Core.reduce(smeared, profile, 1, Core.REDUCE_SUM, CvType.CV_32F)
            val n = ink.rows()
            val prof = FloatArray(n)
            profile.get(0, 0, prof)
            val sm = FloatArray(n)
            var maxV = 0f
            for (i in 0 until n) {
                val a = prof[max(0, i - 1)]; val b = prof[i]; val c = prof[min(n - 1, i + 1)]
                sm[i] = (a + b + c) / 3f
                if (sm[i] > maxV) maxV = sm[i]
            }
            if (maxV <= 0f) return emptyList()
            val thr = 0.12f * maxV
            val bands = ArrayList<IntArray>()
            var inBand = false
            var start = 0
            for (y in 0 until n) {
                if (sm[y] > thr && !inBand) { inBand = true; start = y }
                else if (sm[y] <= thr && inBand) {
                    inBand = false
                    if (y - start >= 6) bands.add(intArrayOf(start, y))
                }
            }
            if (inBand && n - start >= 6) bands.add(intArrayOf(start, n))
            return bands
        } finally {
            smeared.release(); profile.release()
        }
    }

    /** Number of separate connected strokes in [mask] with area >= [minArea] and height >= [minHeight]. */
    private fun components(mask: Mat, minArea: Int, minHeight: Int): Int {
        if (mask.rows() == 0 || mask.cols() == 0) return 0
        val labels = Mat()
        val stats = Mat()
        val centroids = Mat()
        try {
            val n = Imgproc.connectedComponentsWithStats(mask, labels, stats, centroids, 8, CvType.CV_32S)
            var count = 0
            for (i in 1 until n) {
                val area = stats.get(i, Imgproc.CC_STAT_AREA)[0].toInt()
                val height = stats.get(i, Imgproc.CC_STAT_HEIGHT)[0].toInt()
                if (area >= minArea && height >= minHeight) count++
            }
            return count
        } finally {
            labels.release(); stats.release(); centroids.release()
        }
    }

    private fun countStrokes(ink: Mat): Counts? {
        var up = 0; var down = 0; var bodies = 0; var used = 0
        for (band in lineBands(ink)) {
            val a = band[0]; val b = band[1]
            val rowsMat = Mat()
            val strip = ink.rowRange(a, b)
            Core.reduce(strip, rowsMat, 1, Core.REDUCE_SUM, CvType.CV_32F)
            val p = FloatArray(b - a)
            rowsMat.get(0, 0, p)
            rowsMat.release()
            val maxP = p.max()
            if (maxP <= 0f) continue
            var xt = -1; var base = -1
            for (i in p.indices) if (p[i] >= 0.5f * maxP) { if (xt < 0) xt = i; base = i }
            val xh = base - xt + 1
            if (xh < 4 || (b - a) > 6 * xh) continue // not a text line (picture / table / several lines merged)

            val lo = max(a, a + xt - (0.9 * xh).toInt())
            val hi = a + xt
            val upMask = ink.rowRange(lo, hi)
            val bodyMask = ink.rowRange(a + xt, a + base + 1)
            val dnFrom = a + base + 1
            val dnTo = min(b, dnFrom + (0.9 * xh).toInt())
            val downMask = if (dnTo > dnFrom) ink.rowRange(dnFrom, dnTo) else null

            val minArea = max(2, (0.12 * xh * xh / 4).toInt())
            val minHeight = max(2, (0.35 * xh).toInt()) // commas, periods and specks are shorter than a real stroke
            up += components(upMask, minArea, minHeight)
            if (downMask != null) down += components(downMask, minArea, minHeight)
            val opened = Mat()
            val k = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(1.0, max(2, xh / 3).toDouble()))
            Imgproc.morphologyEx(bodyMask, opened, Imgproc.MORPH_OPEN, k)
            bodies += components(opened, minArea * 2, 0)
            k.release(); opened.release()
            used++
        }
        return Counts(up, down, bodies, used)
    }
}
