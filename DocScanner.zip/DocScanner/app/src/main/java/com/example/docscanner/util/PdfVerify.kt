package com.example.docscanner.util

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.File
import java.security.MessageDigest

/**
 * Independent "does this PDF really open?" checks - the safety net behind every feature that writes
 * PDF structure by itself ([PdfStructureOptimizer], [PdfTextEditor]).
 *
 * Why this exists (phiên 11): the iText version of these features was never verified by anything,
 * and the replacement writes bytes we produce ourselves. Instead of trusting our own writer to
 * validate our own output, a second, UNRELATED reader is asked to open the result:
 *  - Android's own [PdfRenderer] (PDFium underneath) - has nothing in common with PdfBox, so a
 *    structural mistake PdfBox happens to tolerate is still likely to be caught here;
 *  - PdfBox reloading the file, compared page by page with the original document (page count and
 *    a SHA-256 of every page's decoded content stream) - catches a writer that produces a file that
 *    opens but says something different.
 * Every function returns false instead of throwing; callers treat false as "do not ship this
 * output, fall back to the plain save".
 */
object PdfVerify {

    private const val SAMPLE_PAGES = 6
    private const val THUMB_WIDTH = 240

    /** Opens [file] with [PdfRenderer], checks the page count and renders a few sampled pages
     *  (first, last, evenly spread) at thumbnail size. [expectedPages] <= 0 skips the count check. */
    fun opensAsPdf(file: File, expectedPages: Int): Boolean {
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        return try {
            if (!file.exists() || file.length() <= 0L) return false
            val openedPfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            pfd = openedPfd
            val openedRenderer = PdfRenderer(openedPfd)
            renderer = openedRenderer
            val count = openedRenderer.pageCount
            if (count <= 0) return false
            if (expectedPages > 0 && count != expectedPages) return false
            for (index in samplePageIndexes(count)) {
                val page = openedRenderer.openPage(index)
                try {
                    val w = THUMB_WIDTH
                    val h = (THUMB_WIDTH * page.height.toFloat() / page.width.coerceAtLeast(1)).toInt().coerceIn(1, 600)
                    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bitmap.eraseColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bitmap.recycle()
                } finally {
                    page.close()
                }
            }
            true
        } catch (t: Throwable) {
            false
        } finally {
            runCatching { renderer?.close() }
            runCatching { pfd?.close() }
        }
    }

    private fun samplePageIndexes(count: Int): List<Int> {
        if (count <= SAMPLE_PAGES) return (0 until count).toList()
        val set = linkedSetOf(0, count - 1)
        for (i in 1 until SAMPLE_PAGES - 1) set.add(i * (count - 1) / (SAMPLE_PAGES - 1))
        return set.toList()
    }

    /** True when [candidate] opens in an independent reader ([opensAsPdf]) AND, reloaded with PdfBox,
     *  has the same page count as [original] and byte-identical decoded content for every page.
     *  Image recompression does not change page content streams, so a legitimate optimized file
     *  always passes; a writer bug that scrambles object references does not. */
    fun sameAsDocument(candidate: File, original: PDDocument): Boolean {
        return try {
            val expected = original.numberOfPages
            if (!opensAsPdf(candidate, expected)) return false
            val mem = MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(candidate.parentFile)
            PDDocument.load(candidate, mem).use { reloaded ->
                if (reloaded.numberOfPages != expected) return false
                for (i in 0 until expected) {
                    val a = original.getPage(i)
                    val b = reloaded.getPage(i)
                    if (a.mediaBox.width != b.mediaBox.width || a.mediaBox.height != b.mediaBox.height) return false
                    if (contentDigest(a) != contentDigest(b)) return false
                }
            }
            true
        } catch (t: Throwable) {
            false
        }
    }

    private fun contentDigest(page: com.tom_roush.pdfbox.pdmodel.PDPage): String {
        if (!page.hasContents()) return "-"
        val md = MessageDigest.getInstance("SHA-256")
        page.contents.use { input ->
            val buf = ByteArray(16 * 1024)
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }
}
