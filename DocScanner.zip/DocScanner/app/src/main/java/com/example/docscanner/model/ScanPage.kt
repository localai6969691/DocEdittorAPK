package com.example.docscanner.model

/**
 * One page inside the current in-memory scan session.
 * [filePath] always points at a JPEG file under the app cache dir.
 * [sourceDpi]: null for a camera-captured (cropped) page - there's no "true" DPI for a photo, so
 * `PdfExporter`'s ASSUMED_DPI convention is used. Non-null when this page came from rendering an
 * existing PDF at a known DPI (see `MainActivity.importPdfForEink`) - carrying that real DPI
 * forward is what lets the exported PDF's page keep the correct physical size instead of coming
 * out oversized (see `PdfExporter.ASSUMED_DPI`'s doc comment, and TECHNICAL_DOCS.md).
 */
data class ScanPage(
    val id: String,
    var filePath: String,
    var sourceDpi: Float? = null
)
