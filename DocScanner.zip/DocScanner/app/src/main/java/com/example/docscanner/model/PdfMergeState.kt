package com.example.docscanner.model

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import java.io.File

/**
 * Persists the list of PDF files the user has picked (but not yet merged) in
 * [com.example.docscanner.PdfMergeActivity], so choosing several files back-to-back survives the
 * process being killed in between picks.
 *
 * Lower value than [PdfEditorState]/[EbookEditorState] - re-picking files again just costs a few
 * taps, it isn't lost work the way an OCR/chapter-marking or rotate/reorder session would be -
 * but still simple to add, so included for completeness (see TECHNICAL_DOCS.md).
 *
 * Only stores the content [Uri]s themselves (with already-persisted read permission - see
 * `PdfMergeActivity.addPdfLauncher`). There's no local copy of anything to manage or clean up
 * here, unlike the other 2 editor-state objects.
 */
object PdfMergeState {

    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    private fun stateFile(): File? = appContext?.let { File(it.filesDir, "pdf_merge_state.json") }

    fun persist(uris: List<Uri>) {
        val file = stateFile() ?: return
        try {
            val arr = JSONArray()
            uris.forEach { arr.put(it.toString()) }
            file.writeText(arr.toString())
        } catch (e: Exception) {
            // Best-effort only - a failed save just means nothing to restore later, never crash over it.
        }
    }

    fun savedCount(): Int {
        val file = stateFile() ?: return 0
        if (!file.exists()) return 0
        return try {
            JSONArray(file.readText()).length()
        } catch (e: Exception) {
            0
        }
    }

    fun hasSaved(): Boolean = savedCount() > 0

    /** Loads the saved Uris, dropping any this process can no longer actually read - SAF
     *  permission can in principle be revoked between runs, so never trust a persisted Uri
     *  blindly; each one is probed with a real open before being handed back. */
    fun restore(context: Context): List<Uri> {
        val file = stateFile() ?: return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).mapNotNull { i ->
                val uri = runCatching { Uri.parse(arr.getString(i)) }.getOrNull()
                    ?: return@mapNotNull null
                val readable = runCatching {
                    context.contentResolver.openFileDescriptor(uri, "r")?.use { }
                    true
                }.getOrDefault(false)
                if (readable) uri else null
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun clear() {
        runCatching { stateFile()?.delete() }
    }
}
