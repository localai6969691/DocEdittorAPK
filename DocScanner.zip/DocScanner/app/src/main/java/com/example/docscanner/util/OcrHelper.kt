package com.example.docscanner.util

import android.graphics.Bitmap
import android.graphics.Rect
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

/**
 * Thin wrapper around ML Kit's on-device (bundled model) text recognizers. Works fully offline.
 *
 * ML Kit recognises ONE script family per recognizer, so the Latin one (Vietnamese, English, French...)
 * that everything used until now could never read Chinese, Japanese, Korean or Devanagari (Hindi...).
 * Google ships each of the other four as its own free artifact (about 4 MB per script per CPU
 * architecture when bundled - developers.google.com/ml-kit/vision/text-recognition/v2/android), so
 * [OcrScript] lets the caller pick one; the default stays Latin so every existing call site is unchanged.
 * Recognizers are created lazily, only for scripts that are actually used.
 */
object OcrHelper {

    enum class OcrScript(
        /** CJK text is written without spaces between words; the others are separated by spaces */
        val usesWordSpaces: Boolean
    ) {
        LATIN(true), CHINESE(false), JAPANESE(false), KOREAN(true), DEVANAGARI(true)
    }

    private val recognizers = HashMap<OcrScript, TextRecognizer>()

    @Synchronized
    private fun recognizerFor(script: OcrScript): TextRecognizer = recognizers.getOrPut(script) {
        TextRecognition.getClient(
            when (script) {
                OcrScript.LATIN -> TextRecognizerOptions.DEFAULT_OPTIONS
                OcrScript.CHINESE -> ChineseTextRecognizerOptions.Builder().build()
                OcrScript.JAPANESE -> JapaneseTextRecognizerOptions.Builder().build()
                OcrScript.KOREAN -> KoreanTextRecognizerOptions.Builder().build()
                OcrScript.DEVANAGARI -> DevanagariTextRecognizerOptions.Builder().build()
            }
        )
    }

    suspend fun recognize(bitmap: Bitmap, script: OcrScript = OcrScript.LATIN): String {
        return try {
            val image = InputImage.fromBitmap(bitmap, 0)
            val result = recognizerFor(script).process(image).await()
            result.text
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * Same recognition pass, but returns ML Kit's text *blocks* instead of one flat string.
     * ML Kit groups nearby lines into blocks based on layout, which lines up with paragraphs on a
     * typical printed page far better than splitting the flat text on newlines would - useful for
     * building ebook chapters that read like actual paragraphs instead of one line per `<p>`.
     */
    suspend fun recognizeBlocks(bitmap: Bitmap, script: OcrScript = OcrScript.LATIN): List<String> {
        return try {
            val image = InputImage.fromBitmap(bitmap, 0)
            val result = recognizerFor(script).process(image).await()
            result.textBlocks.map { it.text.trim() }.filter { it.isNotBlank() }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * One recognised word: its text, its axis-aligned [box] and - when ML Kit reports them - the four
     * [corners] (x0,y0,...,x3,y3 = top-left, top-right, bottom-right, bottom-left of the text as it
     * reads), which follow a tilted or rotated line exactly where the box cannot.
     */
    class OcrWord(val text: String, val box: Rect, val corners: IntArray?)

    /** Words of one text line, left to right. */
    class OcrLine(val words: List<OcrWord>)

    /**
     * Same recognition pass, but keeps ML Kit's line -> word (`Text.Element`) structure together
     * with the geometry - what [SearchablePdfBuilder] needs to place an invisible text layer exactly
     * over the printed words, including slightly tilted lines.
     */
    suspend fun recognizeLines(bitmap: Bitmap, script: OcrScript = OcrScript.LATIN): List<OcrLine> {
        return try {
            val image = InputImage.fromBitmap(bitmap, 0)
            val result = recognizerFor(script).process(image).await()
            result.textBlocks.flatMap { block ->
                block.lines.mapNotNull { line ->
                    val words = line.elements.mapNotNull { el ->
                        val box = el.boundingBox
                        if (box == null || el.text.isBlank()) null
                        else {
                            val pts = el.cornerPoints
                            val corners = if (pts != null && pts.size == 4) {
                                intArrayOf(pts[0].x, pts[0].y, pts[1].x, pts[1].y, pts[2].x, pts[2].y, pts[3].x, pts[3].y)
                            } else null
                            OcrWord(el.text, box, corners)
                        }
                    }
                    if (words.isEmpty()) null else OcrLine(words)
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
