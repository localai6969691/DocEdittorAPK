package com.example.docscanner.util

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

/** Thin wrapper around ML Kit's on-device (bundled model) text recognizer. Works fully offline. */
object OcrHelper {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    suspend fun recognize(bitmap: Bitmap): String {
        return try {
            val image = InputImage.fromBitmap(bitmap, 0)
            val result = recognizer.process(image).await()
            result.text
        } catch (e: Exception) {
            ""
        }
    }

    /**
     * Same recognition pass, but returns ML Kit's text *blocks* instead of one flat string.
     * ML Kit groups nearby lines into blocks based on layout, which lines up with paragraphs on a
     * typical printed page far better than splitting the flat text on newlines would - useful for
     * building ebook chapters that read like actual paragraphs instead of one line per `<p>`.
     */
    suspend fun recognizeBlocks(bitmap: Bitmap): List<String> {
        return try {
            val image = InputImage.fromBitmap(bitmap, 0)
            val result = recognizer.process(image).await()
            result.textBlocks.map { it.text.trim() }.filter { it.isNotBlank() }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
