package com.example.docscanner.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfRenderer
import android.os.Bundle
import android.os.CancellationSignal
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.print.pdf.PrintedPdfDocument
import java.io.File
import java.io.FileOutputStream

/**
 * Sends a PDF to the system print dialog (any printer or "Save as PDF" the device offers) with
 * [android.print.PrintManager.print]. Android's print framework wants a document that is laid out for the paper size
 * the user picks, so every requested page is rendered with [PdfRenderer] at [PRINT_DPI] and fitted - keeping its
 * proportions, centred - inside the printable area of a [PrintedPdfDocument] page. Pages are rendered one at a time
 * on a worker thread and the bitmap is freed before the next one, so a 200-page file does not need 200 bitmaps.
 *
 * What this cannot do: [PdfRenderer] cannot open a password-protected PDF, so those fail at layout time and the
 * print framework shows its own error (remove the password first, with the "Bỏ mật khẩu" tool).
 * Print output goes through a real printer/spooler, which is not something the desktop checks in tools/verify can
 * exercise: the page-range logic ([isSelected]) is pure and checked there, the rest is exercised on a device.
 */
class PdfPrintAdapter(
    private val context: Context,
    private val file: File,
    private val jobName: String
) : PrintDocumentAdapter() {

    private var printed: PrintedPdfDocument? = null
    private var pageCount = -1
    private val main = Handler(Looper.getMainLooper())

    private fun countPages(): Int {
        var fd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        return try {
            fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(fd)
            renderer.pageCount
        } catch (e: Throwable) {
            -1
        } finally {
            runCatching { renderer?.close() }
            runCatching { fd?.close() }
        }
    }

    override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes,
        cancellationSignal: CancellationSignal?,
        callback: LayoutResultCallback,
        extras: Bundle?
    ) {
        printed?.close()
        printed = PrintedPdfDocument(context, newAttributes)
        if (cancellationSignal?.isCanceled == true) {
            callback.onLayoutCancelled()
            return
        }
        if (pageCount <= 0) pageCount = countPages()
        if (pageCount <= 0) {
            callback.onLayoutFailed(null)
            return
        }
        val info = PrintDocumentInfo.Builder(jobName)
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(pageCount)
            .build()
        callback.onLayoutFinished(info, true)
    }

    override fun onWrite(
        pages: Array<out PageRange>,
        destination: ParcelFileDescriptor,
        cancellationSignal: CancellationSignal,
        callback: WriteResultCallback
    ) {
        val doc = printed
        if (doc == null) {
            callback.onWriteFailed(null)
            return
        }
        Thread {
            var failure: Throwable? = null
            var fd: ParcelFileDescriptor? = null
            var renderer: PdfRenderer? = null
            try {
                fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                renderer = PdfRenderer(fd)
                var written = 0
                for (i in 0 until renderer.pageCount) {
                    if (cancellationSignal.isCanceled) break
                    if (!isSelected(pages, i)) continue
                    renderInto(doc, renderer, i, written)
                    written++
                }
                if (!cancellationSignal.isCanceled) {
                    // NOT closed here: the stream wraps the print framework's own descriptor, which the framework
                    // closes itself (the Android print docs' sample does the same) - closing it twice is an error
                    doc.writeTo(FileOutputStream(destination.fileDescriptor))
                }
            } catch (e: Throwable) {
                failure = e
            } finally {
                runCatching { renderer?.close() }
                runCatching { fd?.close() }
                runCatching { doc.close() }
                printed = null
            }
            val error = failure
            main.post {
                when {
                    cancellationSignal.isCanceled -> callback.onWriteCancelled()
                    error != null -> callback.onWriteFailed(error.message)
                    else -> callback.onWriteFinished(pages)
                }
            }
        }.start()
    }

    override fun onFinish() {
        runCatching { printed?.close() }
        printed = null
    }

    private fun renderInto(doc: PrintedPdfDocument, renderer: PdfRenderer, sourceIndex: Int, outIndex: Int) {
        val src = renderer.openPage(sourceIndex)
        var bmp: Bitmap? = null
        try {
            val target = doc.startPage(outIndex)
            val content = target.info.contentRect   // printable area, in 1/72 inch like the source page
            val scale = minOf(content.width() / src.width.toFloat(), content.height() / src.height.toFloat())
            val drawW = src.width * scale
            val drawH = src.height * scale
            val pixelScale = PRINT_DPI / 72f
            var bw = (drawW * pixelScale).toInt().coerceAtLeast(1)
            var bh = (drawH * pixelScale).toInt().coerceAtLeast(1)
            val longest = maxOf(bw, bh)
            if (longest > MAX_EDGE_PX) {
                val k = MAX_EDGE_PX.toFloat() / longest
                bw = (bw * k).toInt().coerceAtLeast(1); bh = (bh * k).toInt().coerceAtLeast(1)
            }
            bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            src.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
            val left = content.left + (content.width() - drawW) / 2f
            val top = content.top + (content.height() - drawH) / 2f
            target.canvas.drawBitmap(bmp, null, RectF(left, top, left + drawW, top + drawH), Paint(Paint.FILTER_BITMAP_FLAG))
            doc.finishPage(target)
        } finally {
            src.close()
            bmp?.recycle()
        }
    }

    companion object {
        const val PRINT_DPI = 200

        /** Opens the system print dialog for [file] (used by the export list and by a project's summary screen). */
        fun print(context: Context, file: File) {
            val manager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
            manager.print(file.name, PdfPrintAdapter(context, file, file.name), PrintAttributes.Builder().build())
        }
        const val MAX_EDGE_PX = 3300

        /** Whether 0-based page [index] falls in any of the requested ranges (inclusive, as [PageRange] defines
         *  them; [PageRange.ALL_PAGES] is 0..Int.MAX_VALUE). Pure - mirrored in tools/verify/print_ranges_check.py. */
        fun isSelected(pages: Array<out PageRange>, index: Int): Boolean =
            pages.any { index >= it.start && index <= it.end }
    }
}
