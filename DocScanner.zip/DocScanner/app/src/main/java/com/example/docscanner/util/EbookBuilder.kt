package com.example.docscanner.util

import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Builds ebook files straight from OCR text - no third-party ebook/EPUB library. EPUB is just a
 * ZIP file with a well-defined internal XML structure, so it's written directly with
 * `java.util.zip` (already in the JDK) instead of pulling in a dependency we can't verify without
 * a real build. MOBI/AZW3 are deliberately NOT supported: they are complex proprietary binary
 * formats, Amazon stopped accepting MOBI uploads in March 2025, and Kindle has accepted EPUB
 * directly (via Send to Kindle) since 2022 - so EPUB is both the safer and the more future-proof
 * choice.
 */
object EbookBuilder {

    /** One chapter: a title (goes in the table of contents) and its paragraphs, in order. */
    data class Chapter(val title: String, val paragraphs: List<String>)

    // ---------------------------------------------------------------------------------------
    // EPUB
    // ---------------------------------------------------------------------------------------

    fun buildEpub(outFile: File, bookTitle: String, chapters: List<Chapter>) {
        val uuid = "urn:uuid:${UUID.randomUUID()}"
        ZipOutputStream(FileOutputStream(outFile)).use { zip ->
            // Must be the first entry, and stored (uncompressed) - this is what makes a .zip an .epub.
            writeStoredEntry(zip, "mimetype", "application/epub+zip".toByteArray(Charsets.US_ASCII))

            writeTextEntry(zip, "META-INF/container.xml", containerXml())
            writeTextEntry(zip, "OEBPS/styles.css", stylesCss())

            chapters.forEachIndexed { index, chapter ->
                writeTextEntry(zip, "OEBPS/chapter${index + 1}.xhtml", chapterXhtml(chapter))
            }

            writeTextEntry(zip, "OEBPS/nav.xhtml", navXhtml(chapters))
            writeTextEntry(zip, "OEBPS/toc.ncx", tocNcx(uuid, bookTitle, chapters))
            writeTextEntry(zip, "OEBPS/content.opf", contentOpf(uuid, bookTitle, chapters))
        }
    }

    private fun writeStoredEntry(zip: ZipOutputStream, name: String, data: ByteArray) {
        val entry = ZipEntry(name)
        entry.method = ZipEntry.STORED
        entry.size = data.size.toLong()
        entry.compressedSize = data.size.toLong()
        val crc = CRC32()
        crc.update(data)
        entry.crc = crc.value
        zip.putNextEntry(entry)
        zip.write(data)
        zip.closeEntry()
    }

    private fun writeTextEntry(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun esc(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")

    private fun containerXml(): String = """<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>"""

    private fun stylesCss(): String = """body { font-family: serif; line-height: 1.5; margin: 1em; }
h1 { text-align: center; font-size: 1.4em; }
p { text-indent: 1.5em; margin: 0 0 0.6em 0; }"""

    private fun chapterXhtml(chapter: Chapter): String {
        val body = if (chapter.paragraphs.isEmpty()) {
            "    <p><em>(không có văn bản)</em></p>"
        } else {
            chapter.paragraphs.joinToString("\n") { "    <p>${esc(it)}</p>" }
        }
        return """<?xml version="1.0" encoding="UTF-8"?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>${esc(chapter.title)}</title>
  <link rel="stylesheet" type="text/css" href="styles.css"/>
</head>
<body>
  <h1>${esc(chapter.title)}</h1>
$body
</body>
</html>"""
    }

    private fun navXhtml(chapters: List<Chapter>): String {
        val items = chapters.mapIndexed { i, c ->
            "      <li><a href=\"chapter${i + 1}.xhtml\">${esc(c.title)}</a></li>"
        }.joinToString("\n")
        return """<?xml version="1.0" encoding="UTF-8"?>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<head><title>Mục lục</title></head>
<body>
  <nav epub:type="toc" id="toc">
    <h1>Mục lục</h1>
    <ol>
$items
    </ol>
  </nav>
</body>
</html>"""
    }

    private fun tocNcx(uuid: String, bookTitle: String, chapters: List<Chapter>): String {
        val points = chapters.mapIndexed { i, c ->
            """    <navPoint id="navPoint-${i + 1}" playOrder="${i + 1}">
      <navLabel><text>${esc(c.title)}</text></navLabel>
      <content src="chapter${i + 1}.xhtml"/>
    </navPoint>"""
        }.joinToString("\n")
        return """<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
  <head>
    <meta name="dtb:uid" content="$uuid"/>
    <meta name="dtb:depth" content="1"/>
    <meta name="dtb:totalPageCount" content="0"/>
    <meta name="dtb:maxPageNumber" content="0"/>
  </head>
  <docTitle><text>${esc(bookTitle)}</text></docTitle>
  <navMap>
$points
  </navMap>
</ncx>"""
    }

    private fun contentOpf(uuid: String, bookTitle: String, chapters: List<Chapter>): String {
        val manifestItems = chapters.mapIndexed { i, _ ->
            "    <item id=\"chapter${i + 1}\" href=\"chapter${i + 1}.xhtml\" media-type=\"application/xhtml+xml\"/>"
        }.joinToString("\n")
        val spineItems = chapters.mapIndexed { i, _ ->
            "    <itemref idref=\"chapter${i + 1}\"/>"
        }.joinToString("\n")
        val modified = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
            .format(java.util.Date())
        return """<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="BookId">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <dc:identifier id="BookId">$uuid</dc:identifier>
    <dc:title>${esc(bookTitle)}</dc:title>
    <dc:language>vi</dc:language>
    <meta property="dcterms:modified">$modified</meta>
  </metadata>
  <manifest>
    <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
    <item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
    <item id="css" href="styles.css" media-type="text/css"/>
$manifestItems
  </manifest>
  <spine toc="ncx">
$spineItems
  </spine>
</package>"""
    }

    // ---------------------------------------------------------------------------------------
    // Plain text
    // ---------------------------------------------------------------------------------------

    fun buildTxt(outFile: File, bookTitle: String, chapters: List<Chapter>) {
        outFile.bufferedWriter(Charsets.UTF_8).use { w ->
            w.write(bookTitle)
            w.write("\n")
            w.write("=".repeat(bookTitle.length.coerceAtLeast(10)))
            w.write("\n\n")
            chapters.forEach { chapter ->
                w.write(chapter.title)
                w.write("\n")
                w.write("-".repeat(chapter.title.length.coerceAtLeast(6)))
                w.write("\n\n")
                if (chapter.paragraphs.isEmpty()) {
                    w.write("(không có văn bản)\n\n")
                } else {
                    chapter.paragraphs.forEach { p ->
                        w.write(p)
                        w.write("\n\n")
                    }
                }
            }
        }
    }
}
