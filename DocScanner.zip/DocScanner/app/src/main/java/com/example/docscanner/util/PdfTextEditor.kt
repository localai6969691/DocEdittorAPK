package com.example.docscanner.util

import com.itextpdf.kernel.font.PdfFont
import com.itextpdf.kernel.pdf.PdfArray
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfLiteral
import com.itextpdf.kernel.pdf.PdfNumber
import com.itextpdf.kernel.pdf.PdfObject
import com.itextpdf.kernel.pdf.PdfStream
import com.itextpdf.kernel.pdf.PdfString
import com.itextpdf.kernel.pdf.canvas.PdfCanvas
import com.itextpdf.kernel.pdf.canvas.parser.PdfCanvasProcessor

/**
 * "Sửa chữ PDF" - find-and-replace a SHORT run of already-existing real text in an external PDF,
 * in place, without rasterizing the page. Deliberately the narrowest possible scope for this,
 * chosen and confirmed with the person before writing any of this (see TECHNICAL_DOCS.md, phiên
 * thứ 8) - NOT real re-flow, NOT "edit like Word".
 *
 * Both reading (see [walkTextOperators]) and writing (see [applyEdit]) walk a page's content
 * stream through the SAME [PdfCanvasEditor] mechanism - one text-showing operator (`Tj`/`'`/`"`/
 * `TJ`) is one [TextChunk], numbered by [TextChunk.index] in strict document order. Unifying read
 * and write onto one traversal (rather than reading via iText's separate `TextRenderInfo` event
 * mechanism and writing via [PdfCanvasEditor] independently, as an earlier version of this file
 * did) means there is exactly one place that decides "what counts as an operator, and in what
 * order" - see TECHNICAL_DOCS.md (phiên thứ 9 rồi phiên thứ 10) for the real bug this fixed
 * (silently divergent counters between two separate traversals whenever a page had a Form XObject
 * with text in it) and why this redesign closes off that whole class of problem rather than
 * patching around one instance of it.
 *
 * A `TJ` operator's array can hold several string fragments interspersed with kerning-adjustment
 * numbers (e.g. `[(Hel) -20 (lo)] TJ` shows "Hello" as two kerned pieces) - [decodeOperatorText]
 * concatenates every string fragment in one array into a SINGLE [TextChunk], since which fragments
 * belong to one array is a plain structural fact read directly off the PDF (there is nothing to
 * guess: they are literally elements of the same array, in the same instruction) - unlike merging
 * fragments across two DIFFERENT operators, which would need guessing whether they're really
 * continuous text or just visually adjacent, this app does not attempt that (see below).
 *
 * ## What this refuses rather than guesses at, and why
 * - **A character [findMissingGlyphs] flags**: the chunk's font has no glyph for it. Most
 *   real-world embedded fonts are SUBSET to only the characters the original document actually
 *   used - there is no reliable way to add a brand new glyph to an already-embedded font from
 *   inside this app, and guessing (e.g. silently falling back to some other font) would produce
 *   text that doesn't match the surrounding document at all. Refusing and telling the person
 *   exactly which characters aren't available is the honest alternative.
 * - **A scale outside 40%-250%** ([EditResult.ScaleOutOfRange]): this tool does not re-flow text -
 *   a same-width replacement is achieved by horizontally scaling (`Tz`) the new text to fill the
 *   original run's measured width (see [applyEdit]'s own doc comment for the exact mechanism and
 *   why it also keeps whatever comes after this run on the same line correctly positioned). Past
 *   a certain point that scaling would look absurd (squeezed or stretched far past readable) rather
 *   than like a normal edit, so this is refused instead of silently producing something illegible.
 * - **Text split across TWO DIFFERENT operators** (as opposed to within one `TJ` array, which IS
 *   handled - see above): e.g. one `Tj` shows "Hel" and a later, separate `Tj` shows "lo", possibly
 *   with a `Td` repositioning in between. Whether two separate operators represent one continuous
 *   run of text or just two coincidentally-adjacent pieces isn't a structural fact the way a
 *   shared array is - it would need a position/font-proximity HEURISTIC, which could itself guess
 *   wrong (merge unrelated text, or mis-measure the combined width) - out of keeping with this
 *   whole tool's refuse-rather-than-guess design. A search match must fall entirely within ONE
 *   operator's combined text.
 * - **Form XObjects, patterns, annotations**: [PdfCanvasEditor] explicitly does not descend into
 *   these (matches the real reference implementation's own documented scope) - since both read and
 *   write now go through that same class, this applies identically to both, automatically (no
 *   separate consistency mechanism needed - see the class doc comment above) - text living inside
 *   one of these (common for some page templates/backgrounds) is neither found nor editable here.
 *
 * None of the above are treated as bugs to eventually fix by trying harder - they are the
 * boundary of what this app can respond for once it has committed to writing SOMETHING into a
 * real PDF's real text objects, in an environment with no way to visually verify the result on a
 * real device before it ships. Refuse cleanly outside that boundary, do the edit precisely and
 * narrowly inside it.
 */
object PdfTextEditor {

    private val TEXT_SHOWING_OPERATORS = setOf("Tj", "'", "\"", "TJ")
    private const val MIN_SCALE_PERCENT = 40f
    private const val MAX_SCALE_PERCENT = 250f

    data class TextChunk(val index: Int, val text: String, val fontSize: Float, val widthPt: Float)

    sealed class EditResult {
        object Success : EditResult()
        data class MissingGlyphs(val chars: String) : EditResult()
        data class ScaleOutOfRange(val percent: Float) : EditResult()
        object ChunkNotFound : EditResult()
    }

    /** Decodes the full text shown by ONE text-showing operator - for `Tj`/`'`/`"` just that
     *  operator's single string; for `TJ`, every [PdfString] element in its array, concatenated in
     *  order ([PdfNumber] kerning-adjustment elements skipped - they're spacing, not text). See the
     *  class doc comment for why grouping this way is reading a structural fact, not guessing. */
    private fun decodeOperatorText(font: PdfFont, operands: List<PdfObject>, isArray: Boolean): String {
        if (isArray) {
            val array = operands.getOrNull(0) as? PdfArray ?: return ""
            val sb = StringBuilder()
            for (i in 0 until array.size()) {
                val el = array.get(i)
                if (el is PdfString) sb.append(runCatching { font.decode(el) }.getOrDefault(""))
            }
            return sb.toString()
        }
        val s = operands.getOrNull(operands.size - 2) as? PdfString ?: return ""
        return runCatching { font.decode(s) }.getOrDefault("")
    }

    /** Read-only walk of page [pageNumber]'s content stream - calls [onEach] once per
     *  text-showing operator, in document order, with its ordinal index, active font/size, and
     *  decoded combined text (blank for an operator with no actual string content, e.g. an empty
     *  `TJ` array of only kerning numbers - [onEach] gets called anyway, to keep numbering
     *  identical between this and [applyEdit]'s own walk). Never modifies [pdfDocument] - uses
     *  [PdfCanvasEditor.editContent] directly (not [PdfCanvasEditor.editPage], which would
     *  reassign the page's `/Contents` even when every operator is re-emitted unchanged) with a
     *  throwaway [PdfCanvas] as the write target, since this call only cares about [onEach]'s side
     *  effects, never about the bytes the editor itself produces. */
    private fun walkTextOperators(
        pdfDocument: PdfDocument,
        pageNumber: Int,
        onEach: (index: Int, font: PdfFont, fontSize: Float, text: String) -> Unit
    ) {
        var counter = 0
        val editor = object : PdfCanvasEditor() {
            override fun write(processor: PdfCanvasProcessor, operator: PdfLiteral, operands: List<PdfObject>) {
                val opString = operator.toString()
                if (opString in TEXT_SHOWING_OPERATORS) {
                    val font = graphicsState.font
                    val size = graphicsState.fontSize
                    val text = decodeOperatorText(font, operands, opString == "TJ")
                    onEach(counter, font, size, text)
                    counter++
                }
                super.write(processor, operator, operands)
            }
        }
        val page = pdfDocument.getPage(pageNumber)
        val resources = page.resources
        val throwawayCanvas = PdfCanvas(PdfStream(), resources, pdfDocument)
        editor.editContent(page.contentBytes, resources, throwawayCanvas)
    }

    /** Lists every non-blank text-showing operator on page [pageNumber] (1-based) of
     *  [pdfDocument], in document order. [TextChunk.index] is that operator's ordinal position
     *  among ALL text-showing operators on the page (blank ones included in the count, just not
     *  returned in the list) - [applyEdit] relies on this exact numbering scheme to find the same
     *  operator again on a second pass, so callers must pass back the [TextChunk] exactly as
     *  returned here, not a reconstructed one. */
    fun extractChunks(pdfDocument: PdfDocument, pageNumber: Int): List<TextChunk> {
        val chunks = mutableListOf<TextChunk>()
        walkTextOperators(pdfDocument, pageNumber) { index, font, size, text ->
            if (text.isNotBlank()) {
                val width = runCatching { font.getWidth(text, size) }.getOrDefault(0f)
                chunks.add(TextChunk(index, text, size, width))
            }
        }
        return chunks
    }

    /** Every Unicode character in [newText] that [chunk]'s own font cannot render, as a single
     *  string (for showing the person exactly what's missing) - empty if every character is
     *  supported. A cheap, callable-anytime check meant for live feedback as the person types;
     *  [applyEdit] always re-checks this itself too before writing anything, so skipping this call
     *  never risks a silently-broken edit - this is purely for UI responsiveness. */
    fun findMissingGlyphs(pdfDocument: PdfDocument, pageNumber: Int, chunk: TextChunk, newText: String): String {
        val font = findChunkFont(pdfDocument, pageNumber, chunk.index) ?: return newText
        val missing = StringBuilder()
        newText.codePoints().forEach { cp ->
            val ch = String(Character.toChars(cp))
            if (!font.containsGlyph(cp) && !missing.contains(ch)) missing.append(ch)
        }
        return missing.toString()
    }

    private fun findChunkFont(pdfDocument: PdfDocument, pageNumber: Int, chunkIndex: Int): PdfFont? {
        var found: PdfFont? = null
        walkTextOperators(pdfDocument, pageNumber) { index, font, _, _ ->
            if (index == chunkIndex) found = font
        }
        return found
    }

    /**
     * Replaces [chunk]'s text on page [pageNumber] with [newText], wrapped in its own `q ... Tz
     * ... Q` block scaled so the new text's rendered width matches [chunk]'s ORIGINAL measured
     * width ([TextChunk.widthPt], captured by [extractChunks] - never re-measured mid-edit, so an
     * already-active scaling factor at the original spot can't throw the ratio off) as closely as
     * mechanically possible. Wrapping in `q`/`Q` (rather than tracking and restoring whatever
     * horizontal-scaling value was active before) means nothing before or after this one run is
     * ever affected, regardless of what was active there originally - per the PDF spec, `q`/`Q`
     * save and restore the full text state including `Tz`. Because the replacement is scaled to
     * the SAME rendered width as the original, the text matrix position after this run advances by
     * (very close to) the same amount the original would have - which is what keeps any further
     * text later on the SAME line, shown via a later Tj/TJ with no repositioning in between,
     * lined up correctly. [pdfDocument] must be open in stamping mode.
     *
     * If [chunk] came from a `TJ` operator with several kerned string fragments, the WHOLE array
     * is collapsed to a single new string (no kerning-adjustment numbers) - the original per-
     * fragment kerning was calibrated for the OLD text's specific characters and has no meaningful
     * carry-over to different replacement text; `[(newtext)] TJ` (a one-element array) is exactly
     * as valid PDF as `(newtext) Tj` would be.
     *
     * [pdfDocument] and [pageNumber] must be the SAME document/page [chunk] came from, unmodified
     * since - a re-parse here (needed to locate the exact operator to rewrite) must see the exact
     * same content [extractChunks] saw for [TextChunk.index] to mean the same thing. Editing 2
     * chunks on the same page means calling this twice, in EITHER order, each a full fresh
     * edit - never batch multiple substitutions into one pass.
     */
    fun applyEdit(pdfDocument: PdfDocument, pageNumber: Int, chunk: TextChunk, newText: String): EditResult {
        val missing = findMissingGlyphs(pdfDocument, pageNumber, chunk, newText)
        if (missing.isNotEmpty()) return EditResult.MissingGlyphs(missing)

        var result: EditResult = EditResult.ChunkNotFound
        val editor = object : PdfCanvasEditor() {
            var counter = 0

            override fun write(processor: PdfCanvasProcessor, operator: PdfLiteral, operands: List<PdfObject>) {
                val opString = operator.toString()
                if (opString !in TEXT_SHOWING_OPERATORS || counter != chunk.index) {
                    super.write(processor, operator, operands)
                    if (opString in TEXT_SHOWING_OPERATORS) counter++
                    return
                }
                counter++ // this IS the target - consume its slot now, every path below writes exactly once

                val font = graphicsState.font
                val size = graphicsState.fontSize
                val newWidth = font.getWidth(newText, size)
                val scalePercent = if (newWidth > 0f) chunk.widthPt / newWidth * 100f else 100f
                if (scalePercent < MIN_SCALE_PERCENT || scalePercent > MAX_SCALE_PERCENT) {
                    super.write(processor, operator, operands)
                    result = EditResult.ScaleOutOfRange(scalePercent)
                    return
                }

                val newBytes = font.convertToBytes(newText)
                val newOperands: List<PdfObject> = if (opString == "TJ") {
                    val newArray = PdfArray()
                    newArray.add(PdfString(newBytes))
                    listOf(newArray, operator)
                } else {
                    val stringIdx = operands.size - 2
                    if (stringIdx < 0 || operands.getOrNull(stringIdx) !is PdfString) {
                        super.write(processor, operator, operands)
                        result = EditResult.ChunkNotFound
                        return
                    }
                    operands.toMutableList().also { it[stringIdx] = PdfString(newBytes) }
                }
                writeScaled(processor, operator, newOperands, scalePercent)
                result = EditResult.Success
            }

            /** Writes [operands] (already substituted by the caller) wrapped in `q [scale] Tz ...
             *  Q` - see this file's [applyEdit] doc comment for why a self-contained q/Q block
             *  rather than tracking/restoring whatever Tz was active before. */
            private fun writeScaled(processor: PdfCanvasProcessor, operator: PdfLiteral, operands: List<PdfObject>, scalePercent: Float) {
                val out = canvas!!.contentStream.outputStream
                out.write(PdfLiteral("q"))
                out.writeNewLine()
                out.write(PdfNumber(scalePercent.toDouble()))
                out.writeSpace()
                out.write(PdfLiteral("Tz"))
                out.writeNewLine()
                super.write(processor, operator, operands)
                out.write(PdfLiteral("Q"))
                out.writeNewLine()
            }
        }
        editor.editPage(pdfDocument, pageNumber)
        return result
    }
}
