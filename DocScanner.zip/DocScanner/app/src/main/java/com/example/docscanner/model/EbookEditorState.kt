package com.example.docscanner.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Persists the in-progress state of [com.example.docscanner.EbookExportActivity] - which source
 * pages are loaded, the book title, which output formats are checked, and (the part that's
 * actually expensive to redo) each page's chapter marks the user has set by hand.
 *
 * Deliberately does NOT persist the OCR'd paragraph text itself: re-running OCR on restore is
 * cheap (a few pages, all local/offline - see the class doc comment on EbookExportActivity), so
 * there is no reason to duplicate potentially large recognized text into this JSON file. On
 * restore, OCR is re-run against the same source pages and the saved chapter marks are re-applied
 * on top by matching page path.
 *
 * Only meaningful when the source pages live somewhere durable: see
 * [com.example.docscanner.util.FileUtils.ebookImportDir] for pages imported directly via file
 * picker; pages coming from [ScanSessionManager] are already durable on their own.
 *
 * Same lazy/explicit [init] pattern as [PdfEditorState] and [ScanSessionManager].
 */
object EbookEditorState {

    data class SavedPage(val path: String, val isChapterStart: Boolean, val chapterTitle: String)
    data class SavedState(
        val bookTitle: String,
        val wantEpub: Boolean,
        val wantTxt: Boolean,
        val pages: List<SavedPage>
    )

    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    private fun stateFile(): File? = appContext?.let { File(it.filesDir, "ebook_editor_state.json") }

    fun persist(state: SavedState) {
        val file = stateFile() ?: return
        try {
            val pagesArr = JSONArray()
            state.pages.forEach { p ->
                pagesArr.put(
                    JSONObject()
                        .put("path", p.path)
                        .put("chapterStart", p.isChapterStart)
                        .put("chapterTitle", p.chapterTitle)
                )
            }
            val root = JSONObject()
                .put("bookTitle", state.bookTitle)
                .put("wantEpub", state.wantEpub)
                .put("wantTxt", state.wantTxt)
                .put("pages", pagesArr)
            file.writeText(root.toString())
        } catch (e: Exception) {
            // Best-effort only - a failed save just means nothing to restore later, never crash over it.
        }
    }

    fun savedPageCount(): Int {
        val file = stateFile() ?: return 0
        if (!file.exists()) return 0
        return try {
            JSONObject(file.readText()).optJSONArray("pages")?.length() ?: 0
        } catch (e: Exception) {
            0
        }
    }

    fun hasSaved(): Boolean = savedPageCount() > 0

    /** Loads the saved state, dropping any page whose source file no longer exists on disk.
     *  Returns null if nothing usable is left (e.g. every source page vanished). */
    fun restore(): SavedState? {
        val file = stateFile() ?: return null
        return try {
            val root = JSONObject(file.readText())
            val pagesArr = root.optJSONArray("pages") ?: return null
            val pages = (0 until pagesArr.length()).mapNotNull { i ->
                val obj = pagesArr.getJSONObject(i)
                val path = obj.optString("path")
                if (path.isNotBlank() && File(path).exists()) {
                    SavedPage(
                        path,
                        obj.optBoolean("chapterStart", false),
                        obj.optString("chapterTitle", "")
                    )
                } else null
            }
            if (pages.isEmpty()) return null
            SavedState(
                bookTitle = root.optString("bookTitle"),
                wantEpub = root.optBoolean("wantEpub", true),
                wantTxt = root.optBoolean("wantTxt", true),
                pages = pages
            )
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Discards the saved state on disk. Only deletes the source page *files* it referenced when
     * they live under [com.example.docscanner.util.FileUtils.ebookImportDir] - i.e. only when
     * this flow owns them. Pages sourced from [ScanSessionManager] must NOT be deleted here:
     * that manager owns their lifecycle (its own `clear()`/export flow), and deleting them out
     * from under it would corrupt an unrelated, possibly still-active scan session. [context] is
     * optional only so callers that just want to drop the JSON record (no context handy) still
     * compile - pass it whenever available so owned page files actually get cleaned up too.
     */
    fun clear(context: Context? = null) {
        val file = stateFile()
        if (context != null && file != null && file.exists()) {
            try {
                val root = JSONObject(file.readText())
                val pagesArr = root.optJSONArray("pages")
                val ownedDirPath = com.example.docscanner.util.FileUtils.ebookImportDir(context).absolutePath
                if (pagesArr != null) {
                    for (i in 0 until pagesArr.length()) {
                        val path = pagesArr.getJSONObject(i).optString("path")
                        if (path.isNotBlank()) {
                            val f = File(path)
                            if (f.parentFile?.absolutePath == ownedDirPath) runCatching { f.delete() }
                        }
                    }
                }
            } catch (e: Exception) {
                // ignore - best effort cleanup
            }
        }
        runCatching { file?.delete() }
    }
}
