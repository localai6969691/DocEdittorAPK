package com.example.docscanner.util

import android.content.Context
import android.os.SystemClock
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * App lock: ask for the user's fingerprint / face / screen-lock PIN, pattern or password before showing the app
 * again. Scanned documents are often IDs, contracts and bills, so this is the "hidden folder" protection people
 * expect from a scanner app - done for the WHOLE app at once instead of one folder, which also covers the export
 * list, the share sheet entry points and every editor.
 *
 * How it hangs together (see DocScannerApp's AppLockCallbacks and LockActivity):
 *  - the lock engages on a cold start, and when the app comes back after being out of sight for more than
 *    [GRACE_MS] (so switching to the file picker or the camera app for a moment does not ask again);
 *  - while a lock is enabled every window is created with FLAG_SECURE: the content is hidden in the recent-apps
 *    list and cannot be screenshotted (said so in the switch's description);
 *  - authentication uses `BIOMETRIC_WEAK | DEVICE_CREDENTIAL`: any enrolled biometric OR the device PIN/pattern.
 *    `BIOMETRIC_STRONG | DEVICE_CREDENTIAL` is NOT used because androidx.biometric does not support that
 *    combination on Android 9-10 (API 28-29); with DEVICE_CREDENTIAL allowed there is no negative button.
 *
 * Fail-open case, on purpose: if the lock is enabled but the device has no screen lock / biometric any more
 * (the user removed it in Settings), nothing can answer the prompt and the user would be locked out of their own
 * documents for good - and a phone with no screen lock is open to anyone anyway. The lock then switches itself off.
 * Transient errors (sensor busy, security update pending) keep the lock on.
 *
 * The decision itself ([shouldLock]) is a pure function, mirrored with the surrounding event sequence in
 * tools/verify/app_lock_check.py.
 */
object AppLock {

    /** How long the app may be out of sight before it asks again. */
    const val GRACE_MS = 60_000L

    private const val PREFS = "app_lock"
    private const val KEY_ENABLED = "enabled"
    private const val AUTHENTICATORS =
        BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL

    @Volatile
    var unlocked: Boolean = false
        private set

    /** [SystemClock.elapsedRealtime] when the last activity went out of sight; 0 while the app is in front. */
    @Volatile
    private var backgroundedAt: Long = 0L

    fun isEnabled(context: Context): Boolean =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, value: Boolean) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, value).apply()
    }

    /** [BiometricManager.BIOMETRIC_SUCCESS] when a biometric or a screen lock can answer the prompt. */
    fun status(context: Context): Int = BiometricManager.from(context).canAuthenticate(AUTHENTICATORS)

    fun isSupported(context: Context): Boolean = status(context) == BiometricManager.BIOMETRIC_SUCCESS

    /** Pure: should the lock screen be shown now? */
    fun shouldLock(enabled: Boolean, unlocked: Boolean, backgroundedAt: Long, now: Long, graceMs: Long): Boolean {
        if (!enabled) return false
        if (!unlocked) return true
        return backgroundedAt > 0L && now - backgroundedAt > graceMs
    }

    /** The last visible activity went away. */
    fun onAppBackgrounded() {
        backgroundedAt = SystemClock.elapsedRealtime()
    }

    /** An activity (other than the lock screen) became visible. @return true if the lock screen must be shown. */
    fun onActivityVisible(context: Context): Boolean {
        val enabled = isEnabled(context)
        if (enabled) {
            val s = status(context)
            if (s == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED || s == BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE) {
                setEnabled(context, false)   // nothing can unlock it: do not trap the user (see class doc)
                return false
            }
        }
        val lock = shouldLock(enabled, unlocked, backgroundedAt, SystemClock.elapsedRealtime(), GRACE_MS)
        if (lock) unlocked = false else backgroundedAt = 0L
        return lock
    }

    /** Call after a successful authentication (the lock screen, or just after the user turned the lock on). */
    fun markUnlocked() {
        unlocked = true
        backgroundedAt = 0L
    }

    /** Shows the system prompt. [onResult] gets true on success, false on any error or cancel. */
    fun authenticate(activity: FragmentActivity, title: String, onResult: (Boolean) -> Unit) {
        val prompt = BiometricPrompt(
            activity,
            ContextCompat.getMainExecutor(activity),
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onResult(true)
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onResult(false)
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setAllowedAuthenticators(AUTHENTICATORS)
            .build()
        prompt.authenticate(info)
    }
}
