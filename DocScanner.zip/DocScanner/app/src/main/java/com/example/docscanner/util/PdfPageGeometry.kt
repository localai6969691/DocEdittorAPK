package com.example.docscanner.util

import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.util.Matrix

/**
 * Where a point of the page AS THE USER SEES IT lives in the page's own PDF coordinate space.
 *
 * A PDF page has a CropBox (the visible area, not necessarily starting at 0,0) and a `/Rotate` (0/90/180/270,
 * clockwise) applied when the page is displayed. Page numbers, signatures and stamps are all specified as "this
 * far from the left / top / bottom of the page I am looking at", so every one of them needs the same two things:
 *
 *  - [displayMatrix]: a `cm` matrix after which content can be drawn in an upright, bottom-left-origin frame of
 *    size [displayWidth] x [displayHeight] (the displayed page), whatever the rotation - used for text and images;
 *  - [toUser]: a point picked on a preview image (x from the left, y from the TOP, in points) as user-space
 *    coordinates - used when something must be placed without a matrix.
 *
 * The formulas were checked against poppler on 12 combinations (rotation 0/90/180/270 x no CropBox / offset
 * CropBox / negative-origin MediaBox) by `tools/verify/page_geometry_check.py`, which holds a Python copy of this
 * class: change one, change the other. Use [PDPage.getCropBox] (already clipped to the MediaBox) - that is the
 * box poppler's `-cropbox` and Android's PdfRenderer show.
 */
class PdfPageGeometry(
    private val llx: Float,
    private val lly: Float,
    private val cropWidth: Float,
    private val cropHeight: Float,
    rotationDegrees: Int
) {
    /** 0, 90, 180 or 270 - a damaged `/Rotate` (e.g. 45, -90, 450) is snapped to the nearest quarter turn. */
    val rotation: Int = (((Math.round(rotationDegrees / 90f) * 90) % 360) + 360) % 360

    private val swap = rotation == 90 || rotation == 270
    val displayWidth: Float = if (swap) cropHeight else cropWidth
    val displayHeight: Float = if (swap) cropWidth else cropHeight

    /** The six numbers `[a b c d e f]` of a PDF `cm` operator: after it, (0,0) is the displayed page's
     *  bottom-left corner, x runs right and y runs up as the user sees the page. */
    fun displayMatrixValues(): FloatArray = when (rotation) {
        90 -> floatArrayOf(0f, 1f, -1f, 0f, llx + cropWidth, lly)
        180 -> floatArrayOf(-1f, 0f, 0f, -1f, llx + cropWidth, lly + cropHeight)
        270 -> floatArrayOf(0f, -1f, 1f, 0f, llx, lly + cropHeight)
        else -> floatArrayOf(1f, 0f, 0f, 1f, llx, lly)
    }

    fun displayMatrix(): Matrix {
        val m = displayMatrixValues()
        return Matrix(m[0], m[1], m[2], m[3], m[4], m[5])
    }

    /** [xFromLeft] / [yFromTop] on the displayed page (points) -> user-space (x, y). */
    fun toUser(xFromLeft: Float, yFromTop: Float): Pair<Float, Float> {
        val m = displayMatrixValues()
        val xb = xFromLeft
        val yb = displayHeight - yFromTop
        return Pair(m[0] * xb + m[2] * yb + m[4], m[1] * xb + m[3] * yb + m[5])
    }

    companion object {
        fun of(page: PDPage): PdfPageGeometry {
            val box = page.cropBox
            return PdfPageGeometry(box.lowerLeftX, box.lowerLeftY, box.width, box.height, page.rotation)
        }
    }
}
