package com.example.docscanner.adapter

import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.R
import com.example.docscanner.databinding.ItemEbookPageBinding
import com.example.docscanner.util.FileUtils

/** UI state for one page inside the ebook chapter/TOC editor. */
data class EbookPageData(
    val path: String,
    var paragraphs: List<String> = emptyList(),
    var isChapterStart: Boolean = false,
    var chapterTitle: String = ""
)

class EbookPageAdapter(
    private val onChanged: () -> Unit
) : RecyclerView.Adapter<EbookPageAdapter.ViewHolder>() {

    private val items = mutableListOf<EbookPageData>()

    fun submitList(pages: List<EbookPageData>) {
        items.clear()
        items.addAll(pages)
        notifyDataSetChanged()
    }

    fun currentList(): List<EbookPageData> = items

    inner class ViewHolder(val binding: ItemEbookPageBinding) : RecyclerView.ViewHolder(binding.root) {
        var textWatcher: TextWatcher? = null
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemEbookPageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        val context = holder.binding.root.context

        holder.binding.tvPageNumber.text = "Trang ${position + 1}"

        val preview = item.paragraphs.joinToString(" ")
        holder.binding.tvTextPreview.text = preview.ifBlank { context.getString(R.string.ebook_page_no_text) }

        // Detach previous listeners before rebinding - RecyclerView reuses views, and a stale
        // listener would otherwise write into whichever item happens to scroll into this slot.
        holder.binding.switchChapterStart.setOnCheckedChangeListener(null)
        holder.textWatcher?.let { holder.binding.etChapterTitle.removeTextChangedListener(it) }

        holder.binding.switchChapterStart.isChecked = item.isChapterStart
        holder.binding.switchChapterStart.isEnabled = position != 0 // page 1 is always a chapter start
        holder.binding.etChapterTitle.setText(item.chapterTitle)
        holder.binding.etChapterTitle.visibility = if (item.isChapterStart) View.VISIBLE else View.GONE

        holder.binding.switchChapterStart.setOnCheckedChangeListener { _, checked ->
            val pos = holder.bindingAdapterPosition
            if (pos == RecyclerView.NO_POSITION) return@setOnCheckedChangeListener
            items[pos].isChapterStart = checked
            holder.binding.etChapterTitle.visibility = if (checked) View.VISIBLE else View.GONE
            onChanged()
        }

        val watcher = object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val pos = holder.bindingAdapterPosition
                if (pos == RecyclerView.NO_POSITION) return
                items[pos].chapterTitle = s?.toString().orEmpty()
                onChanged()
            }
        }
        holder.textWatcher = watcher
        holder.binding.etChapterTitle.addTextChangedListener(watcher)

        holder.binding.ivThumb.setImageBitmap(FileUtils.decodeSampledBitmap(item.path, 200, 260))
    }

    override fun getItemCount(): Int = items.size
}
