package com.example.docscanner

import android.content.Context
import android.content.Intent
import com.example.docscanner.model.Project
import com.example.docscanner.model.ProjectStage

/**
 * Maps a [Project]'s current [ProjectStage] to the Activity that handles it, and starts it. Used
 * both to launch the very next stage as soon as one finishes, and to resume a project from
 * [ProjectHubActivity] at exactly the stage it was left at - the two cases are the same call,
 * which is what makes "exit anytime, resume exactly where you left off" work for free instead of
 * needing separate resume logic.
 */
object ProjectFlow {

    const val EXTRA_PROJECT_ID = "extra_project_id"

    fun open(context: Context, project: Project) {
        val cls = when (project.stage) {
            ProjectStage.PICK_IMAGES -> ProjectPickImagesActivity::class.java
            ProjectStage.EDIT_IMAGES -> ProjectEditActivity::class.java
            ProjectStage.SCAN -> ProjectScanActivity::class.java
            ProjectStage.EXPORT_PDF -> ProjectExportPdfActivity::class.java
            ProjectStage.COMPRESS -> ProjectCompressActivity::class.java
            ProjectStage.OCR -> ProjectOcrActivity::class.java
            ProjectStage.EBOOK -> ProjectEbookActivity::class.java
            ProjectStage.DONE -> ProjectSummaryActivity::class.java
        }
        context.startActivity(Intent(context, cls).putExtra(EXTRA_PROJECT_ID, project.id))
    }
}
