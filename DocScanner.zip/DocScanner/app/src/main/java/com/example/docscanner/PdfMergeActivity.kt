package com.example.docscanner

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.adapter.PdfFileAdapter
import com.example.docscanner.databinding.ActivityPdfMergeBinding
import com.example.docscanner.model.PdfMergeState
import com.example.docscanner.util.PdfExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class PdfMergeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPdfMergeBinding
    private lateinit var adapter: PdfFileAdapter
    private lateinit var touchHelper: ItemTouchHelper
    private val pickedUris = mutableListOf<Uri>()

    private val addPdfLauncher =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) {
                uris.forEach { uri ->
                    runCatching {
                        contentResolver.takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    }
                }
                pickedUris.addAll(uris)
                refreshList()
                persistState()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfMergeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        adapter = PdfFileAdapter(
            context = this,
            onRemove = { position ->
                pickedUris.removeAt(position)
                refreshList()
                persistState()
            },
            onDragHandleTouch = { holder -> touchHelper.startDrag(holder) }
        )
        binding.rvMergeFiles.layoutManager = LinearLayoutManager(this)
        binding.rvMergeFiles.adapter = adapter

        touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = viewHolder.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
                val item = pickedUris.removeAt(from)
                pickedUris.add(to, item)
                adapter.moveItem(from, to)
                persistState()
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}
        })
        touchHelper.attachToRecyclerView(binding.rvMergeFiles)

        binding.btnAddPdf.setOnClickListener { addPdfLauncher.launch(arrayOf("application/pdf")) }
        binding.btnMerge.setOnClickListener { doMerge() }

        if (savedInstanceState == null && PdfMergeState.hasSaved()) {
            offerRestore()
        } else {
            refreshList()
        }
    }

    /** If a previous process left a picked-but-not-yet-merged file list on disk (killed by the
     *  OS, crashed, phone restarted...) ask whether to pick it back up - same idea as
     *  MainActivity's scan-session restore prompt. Lower stakes than that one (re-picking a few
     *  files back is cheap), but still a couple of taps saved. */
    private fun offerRestore() {
        val count = PdfMergeState.savedCount()
        AlertDialog.Builder(this)
            .setTitle(R.string.restore_merge_title)
            .setMessage(getString(R.string.restore_merge_message, count))
            .setCancelable(false)
            .setPositiveButton(R.string.restore_merge_continue) { _, _ ->
                pickedUris.addAll(PdfMergeState.restore(this))
                refreshList()
            }
            .setNegativeButton(R.string.restore_merge_new) { _, _ ->
                PdfMergeState.clear()
                refreshList()
            }
            .show()
    }

    private fun persistState() {
        PdfMergeState.persist(pickedUris)
    }

    private fun refreshList() {
        adapter.submitList(pickedUris)
        binding.tvEmptyMerge.visibility = if (pickedUris.isEmpty()) View.VISIBLE else View.GONE
        binding.btnMerge.isEnabled = pickedUris.size >= 2
    }

    private fun doMerge() {
        if (pickedUris.size < 2) return
        setBusy(true)
        val urisSnapshot = pickedUris.toList()
        lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.Default) {
                    PdfExporter.mergePdfs(
                        context = this@PdfMergeActivity,
                        uris = urisSnapshot,
                        onFileProgress = { done, total ->
                            runOnUiThread {
                                binding.tvProgress.text = getString(R.string.merge_progress, done, total)
                            }
                        }
                    )
                }
                setBusy(false)
                Toast.makeText(
                    this@PdfMergeActivity,
                    getString(R.string.export_success, result.name),
                    Toast.LENGTH_LONG
                ).show()
                PdfMergeState.clear()
                finish()
            } catch (e: Exception) {
                setBusy(false)
                Toast.makeText(
                    this@PdfMergeActivity,
                    getString(R.string.export_failed, e.message ?: ""),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun setBusy(busy: Boolean) {
        binding.progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        binding.tvProgress.visibility = if (busy) View.VISIBLE else View.GONE
        binding.btnMerge.isEnabled = !busy && pickedUris.size >= 2
        binding.btnAddPdf.isEnabled = !busy
    }
}
