package com.example.docscanner

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityProjectCompressBinding
import com.example.docscanner.model.Project
import com.example.docscanner.model.ProjectManager
import com.example.docscanner.model.ProjectStage
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfCompressor
import com.example.docscanner.util.PdfExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

/**
 * Project stage 6: mandatory PDF compression. Unlike the standalone "Nén PDF" tool (which has to
 * re-render an arbitrary source PDF to images first, since it doesn't have the originals), a
 * project already has its own working page images on disk - [PdfCompressor.compress] is called
 * directly on those, and if the previous stage added a table of contents, the same entries are
 * passed through again here so the fresh PDF this produces keeps its bookmarks too (compressing
 * builds a brand new file from scratch, it doesn't patch the uncompressed one).
 */
class ProjectCompressActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProjectCompressBinding
    private lateinit var project: Project

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProjectCompressBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val projectId = intent.getStringExtra(ProjectFlow.EXTRA_PROJECT_ID)
        val loaded = projectId?.let { ProjectManager.load(this, it) }
        if (loaded == null || loaded.pdfPath == null) {
            finish()
            return
        }
        project = loaded
        title = project.name
        binding.tvStageIndicator.text = getString(R.string.project_stage_indicator_5)

        binding.btnContinue.setOnClickListener { doCompress() }
    }

    private fun doCompress() {
        val pdfPath = project.pdfPath ?: return
        val method = if (binding.rbCompressG4.isChecked) {
            PdfCompressor.TextCompressionMethod.CCITT_G4
        } else {
            PdfCompressor.TextCompressionMethod.SAFE_DEFLATE
        }
        val methodLabel = if (binding.rbCompressG4.isChecked) {
            getString(R.string.compress_method_g4)
        } else {
            getString(R.string.compress_method_safe)
        }
        binding.progressBar.visibility = View.VISIBLE
        binding.tvProgress.visibility = View.VISIBLE
        binding.btnContinue.isEnabled = false
        lifecycleScope.launch {
            val originalSize = File(pdfPath).length()
            val outFile = File(PdfExporter.exportDir(this@ProjectCompressActivity), "${FileUtils.defaultCompressedName()}.pdf")
            val result = withContext(Dispatchers.Default) {
                PdfCompressor.compress(
                    pageImagePaths = project.pages.map { it.path },
                    outFile = outFile,
                    originalSize = originalSize,
                    textMethod = method,
                    chapterTitles = project.tocEntries.map { it.title },
                    chapterStartPageIndex = project.tocEntries.map { it.pageIndex }
                ) { done, total ->
                    runOnUiThread {
                        binding.tvProgress.text = getString(R.string.compress_progress, done, total)
                    }
                }
            }
            project.compressedPdfPath = outFile.absolutePath
            project.compressMethodLabel = methodLabel
            project.stage = ProjectStage.OCR
            ProjectManager.save(this@ProjectCompressActivity, project)

            val ratioStr = String.format(Locale.getDefault(), "%.1f", result.ratio)
            val resultMsg = getString(
                R.string.compress_success,
                FileUtils.humanFileSize(result.originalSize),
                FileUtils.humanFileSize(result.compressedSize),
                ratioStr
            )
            binding.progressBar.visibility = View.GONE
            binding.tvProgress.visibility = View.GONE
            binding.tvCompressResult.visibility = View.VISIBLE
            binding.tvCompressResult.text = resultMsg
            Toast.makeText(this@ProjectCompressActivity, resultMsg, Toast.LENGTH_LONG).show()
            ProjectFlow.open(this@ProjectCompressActivity, project)
            finish()
        }
    }
}
