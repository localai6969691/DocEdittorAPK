package com.example.docscanner.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.font.PDType1Font
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import java.io.File

/**
 * Page numbers, headers/footers and Bates numbering written onto the pages of an EXISTING PDF - the "stamp"
 * module paid PDF SDKs sell, done with PdfBox-Android alone and WITHOUT rasterizing: the original text, fonts
 * and images stay exactly as they are, the labels are appended to each page's content.
 *
 * A label is a position plus a template. Tokens in a template:
 *  - `{n}`  the page number, counting from [Options.startNumber] (so a Bates run can continue from the last
 *           document: start at 101 and the first page says 101);
 *  - `{N}`  the number of pages of this document;
 *  - `{b}`  the Bates number: [Options.batesPrefix] + the page number padded with zeros to [Options.batesDigits]
 *           (prefix "ABC-", 4 digits, page 7 -> `ABC-0007`).
 *
 * Text that is plain printable ASCII is written with the built-in Helvetica font (no font to embed, the file stays
 * small). Anything else - Vietnamese, CJK, a "№" - is drawn into a bitmap with Android's own text engine and added
 * as an image, the same trick [PdfSecurityTools.watermark] uses, because the 14 standard PDF fonts cannot show it.
 * Such a bitmap is made once per distinct text and reused on every page.
 *
 * Position on a page that is shown rotated, or has a CropBox that does not start at 0,0, is handled by
 * [PdfPageGeometry] (checked with poppler on 12 cases by tools/verify/page_geometry_check.py): "bottom centre"
 * is the bottom centre of the page AS SEEN, and the text reads upright.
 * Writes a NEW file; the input is only read.
 */
object PdfDecorator {

    enum class Place { TOP_LEFT, TOP_CENTER, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_CENTER, BOTTOM_RIGHT }

    data class Label(val place: Place, val template: String)

    data class Options(
        val labels: List<Label>,
        val startNumber: Int = 1,
        val batesPrefix: String = "",
        val batesDigits: Int = 6,
        val fontSize: Float = 10f,
        /** Distance from the page edge, in points. */
        val margin: Float = 28f,
        /** Number the cover differently: skip the first [skipFirstPages] pages (they get no label and do not
         *  count - the page after them is numbered [startNumber]). */
        val skipFirstPages: Int = 0
    )

    /** Template with every token replaced. Pure function - also mirrored in tools/verify/decorate_check.py. */
    fun expand(template: String, pageNumber: Int, totalPages: Int, opt: Options): String {
        val digits = opt.batesDigits.coerceIn(1, 12)
        val bates = opt.batesPrefix + pageNumber.toString().padStart(digits, '0')
        return template
            .replace("{n}", pageNumber.toString())
            .replace("{N}", totalPages.toString())
            .replace("{b}", bates)
    }

    fun isPlainAscii(s: String): Boolean = s.all { it.code in 0x20..0x7E }

    /** Left edge of a label of [textWidth] points on a page [pageWidth] wide. Never negative: a label wider than
     *  the page starts at the margin and runs off the right side rather than off the left. */
    fun labelX(place: Place, textWidth: Float, pageWidth: Float, margin: Float): Float {
        val x = when (place) {
            Place.TOP_LEFT, Place.BOTTOM_LEFT -> margin
            Place.TOP_CENTER, Place.BOTTOM_CENTER -> (pageWidth - textWidth) / 2f
            Place.TOP_RIGHT, Place.BOTTOM_RIGHT -> pageWidth - margin - textWidth
        }
        return if (x < margin) margin.coerceAtMost(pageWidth / 4f) else x
    }

    /** Baseline y (from the BOTTOM of the displayed page) for a label of [textHeight] points. */
    fun labelBaselineY(place: Place, textHeight: Float, pageHeight: Float, margin: Float): Float = when (place) {
        Place.TOP_LEFT, Place.TOP_CENTER, Place.TOP_RIGHT -> pageHeight - margin - textHeight
        else -> margin
    }

    /** @return number of pages that got at least one label. */
    fun decorate(src: File, out: File, opt: Options): Int {
        require(opt.labels.any { it.template.isNotBlank() }) { "no label" }
        val doc = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
        try {
            if (doc.isEncrypted) throw IllegalStateException("encrypted")
            val pages = doc.numberOfPages
            val skip = opt.skipFirstPages.coerceIn(0, pages)
            val font = PDType1Font.HELVETICA
            val imageCache = HashMap<String, Pair<PDImageXObject, Float>>() // text -> image, width in points
            var labelled = 0
            for (i in skip until pages) {
                val page = doc.getPage(i)
                val geo = PdfPageGeometry.of(page)
                val number = opt.startNumber + (i - skip)
                val drawable = opt.labels.filter { it.template.isNotBlank() }
                    .map { it to expand(it.template, number, pages - skip, opt) }
                if (drawable.isEmpty()) continue
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    cs.saveGraphicsState()
                    cs.transform(geo.displayMatrix())
                    for ((label, text) in drawable) {
                        if (isPlainAscii(text)) {
                            val width = font.getStringWidth(text) / 1000f * opt.fontSize
                            val x = labelX(label.place, width, geo.displayWidth, opt.margin)
                            val y = labelBaselineY(label.place, opt.fontSize, geo.displayHeight, opt.margin)
                            cs.beginText()
                            cs.setFont(font, opt.fontSize)
                            cs.setNonStrokingColor(0.1f, 0.1f, 0.1f)
                            cs.newLineAtOffset(x, y)
                            cs.showText(text)
                            cs.endText()
                        } else {
                            val (image, widthPt) = imageCache.getOrPut(text) { renderText(doc, text, opt.fontSize) }
                            val heightPt = widthPt * image.height / image.width
                            val x = labelX(label.place, widthPt, geo.displayWidth, opt.margin)
                            val y = labelBaselineY(label.place, heightPt, geo.displayHeight, opt.margin)
                            cs.drawImage(image, x, y, widthPt, heightPt)
                        }
                    }
                    cs.restoreGraphicsState()
                }
                labelled++
            }
            PdfStructureOptimizer.save(doc, out)
            if (!PdfVerify.opensAsPdf(out, pages)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
            return labelled
        } finally {
            runCatching { doc.close() }
        }
    }

    /** [text] drawn black on transparent at 4x scale; returns the image and its width in PDF points at [fontSize]. */
    private fun renderText(doc: PDDocument, text: String, fontSize: Float): Pair<PDImageXObject, Float> {
        val scale = 4f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(255, 26, 26, 26)
            textSize = fontSize * scale
        }
        val fm = paint.fontMetrics
        val w = (paint.measureText(text) + 2f * scale).toInt().coerceIn(8, 6000)
        val h = (fm.descent - fm.ascent + 2f * scale).toInt().coerceAtLeast(8)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(bmp).drawText(text, scale, scale - fm.ascent, paint)
        val image = LosslessFactory.createFromImage(doc, bmp)
        bmp.recycle()
        return Pair(image, w / scale)
    }
}
