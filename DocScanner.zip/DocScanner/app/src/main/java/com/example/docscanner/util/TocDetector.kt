package com.example.docscanner.util

import android.graphics.BitmapFactory
import com.example.docscanner.model.ProjectTocEntry

/**
 * Best-effort auto-detection of a book's own table-of-contents page, for the Project flow's
 * "Xuất PDF" stage (see `ProjectExportPdfActivity` and TECHNICAL_DOCS.md). Pure OCR-text pattern
 * matching - no ML model, no external service.
 */
object TocDetector {

    // A line that looks like a table-of-contents entry: title text, then a run of dots and/or
    // spaces (a "leader"), then a page number at the very end of the line.
    private val TOC_LINE = Regex("""^(.{2,80}?)[\s.]{2,}(\d{1,4})\s*$""")

    private val TOC_KEYWORDS = listOf(
        "MỤC LỤC", "MUC LUC", "TABLE OF CONTENTS", "CONTENTS", "INDEX"
    )

    private const val FRONT_MATTER_SEARCH_LIMIT = 20

    /**
     * Scans the first [FRONT_MATTER_SEARCH_LIMIT] pages (a real table of contents is almost
     * always near the front of a book) looking for one that reads like a table of contents, then
     * parses its "title .... N" lines into entries. Returns an empty list if nothing convincing
     * is found.
     *
     * Callers MUST treat the result as a mere starting point for the user to review and correct
     * (see `ProjectExportPdfActivity`'s TOC review screen), never as a final answer: the page
     * number in each entry is the book's own PRINTED page number, which almost never lines up
     * 1:1 with the scan's page index - a cover, title page, copyright page, dedication, etc. all
     * shift the offset by an amount this function has no reliable way to know. Rather than guess
     * that mapping and risk a confidently-wrong bookmark, entries are handed back with their
     * scan-page guess simply spread evenly across the book - the part actually worth automating
     * is recovering the chapter TITLES (tedious to type by hand), not the page mapping (a few
     * taps to fix per entry in the review screen).
     */
    suspend fun detect(pages: List<String>): List<ProjectTocEntry> {
        val searchCount = minOf(FRONT_MATTER_SEARCH_LIMIT, pages.size)
        var bestMatches: List<Pair<String, Int>> = emptyList()

        for (i in 0 until searchCount) {
            val bitmap = BitmapFactory.decodeFile(pages[i]) ?: continue
            val text = OcrHelper.recognize(bitmap)
            bitmap.recycle()

            val hasKeyword = TOC_KEYWORDS.any { text.uppercase().contains(it) }
            val matches = text.lines().mapNotNull { line ->
                TOC_LINE.matchEntire(line.trim())?.let { m ->
                    val title = m.groupValues[1].trim(' ', '.', '-')
                    val pageNum = m.groupValues[2].toIntOrNull()
                    if (title.isNotBlank() && pageNum != null) title to pageNum else null
                }
            }
            // A stray "something ... 12" line on its own is too weak a signal - require either an
            // explicit "Mục lục"/"Contents" heading nearby, or several matching lines together.
            val looksLikeToc = (hasKeyword && matches.size >= 2) || matches.size >= 3
            if (looksLikeToc && matches.size > bestMatches.size) {
                bestMatches = matches
            }
        }

        if (bestMatches.isEmpty()) return emptyList()

        val pageCount = pages.size
        val n = bestMatches.size
        return bestMatches.mapIndexed { index, (title, _) ->
            val guessIndex = if (n <= 1) 0 else index * (pageCount - 1) / (n - 1)
            ProjectTocEntry(title, guessIndex.coerceIn(0, pageCount - 1))
        }
    }
}
