package com.example.docscanner

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.docscanner.adapter.ProjectAdapter
import com.example.docscanner.databinding.ActivityProjectHubBinding
import com.example.docscanner.model.Project
import com.example.docscanner.model.ProjectManager

/**
 * Entry point for the "Dự án" (Project) workflow: create a new project, or resume one that's
 * still in progress. Resuming and continuing use the exact same call
 * ([ProjectFlow.open]) - a project's [Project.stage] is the single source of truth for where it
 * left off, so there is no separate "resume" logic to keep in sync with the "advance" logic every
 * stage Activity already has.
 */
class ProjectHubActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProjectHubBinding
    private lateinit var adapter: ProjectAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProjectHubBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.project_hub_title)

        adapter = ProjectAdapter(
            onClick = { project -> ProjectFlow.open(this, project) },
            onDelete = { project -> confirmDelete(project) }
        )
        binding.rvProjects.layoutManager = LinearLayoutManager(this)
        binding.rvProjects.adapter = adapter

        binding.btnNewProject.setOnClickListener {
            val project = ProjectManager.createProject(this)
            ProjectFlow.open(this, project)
        }

        refreshList()
    }

    override fun onResume() {
        super.onResume()
        refreshList()
    }

    private fun refreshList() {
        val projects = ProjectManager.listProjects(this)
        adapter.submitList(projects)
        binding.tvEmptyProjects.visibility = if (projects.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun confirmDelete(project: Project) {
        AlertDialog.Builder(this)
            .setMessage(getString(R.string.project_confirm_delete, project.name))
            .setPositiveButton(R.string.dialog_yes) { _, _ ->
                ProjectManager.delete(this, project.id)
                refreshList()
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }
}
