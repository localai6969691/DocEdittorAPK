package com.example.docscanner.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Backup and restore of the user's work as ONE ZIP file they choose where to keep (Drive, a USB stick, another
 * phone): the exported documents (PDF / EPUB / TXT in the export folder) and every project (its `project.json` plus
 * the raw and page images). The app has `allowBackup=false` on purpose, so without this a phone change or a
 * reinstall would lose everything.
 *
 * Deliberately NOT in the ZIP: saved signatures ([SignatureStore]) and the app-lock setting. A ZIP is the kind of
 * file people upload to the cloud or send around; a signature image that anyone could lift from it is exactly what
 * the private storage was protecting.
 *
 * Restoring is careful in three ways:
 *  - NEVER overwrites: a file that already exists is skipped (and counted), so restoring on top of today's work
 *    cannot destroy it;
 *  - NEVER trusts entry names ([parseEntry]): "..", absolute paths, backslashes, NUL bytes and anything outside the
 *    two known folders are rejected, and the resolved file must still sit inside its folder ([isInside], which also
 *    catches symlinks) - the classic "zip slip" attack and a hand-edited ZIP both end up as "rejected", not as a
 *    file written somewhere else;
 *  - REBASES paths ([rebasePath]): `project.json` stores absolute paths, which differ between devices/users, so
 *    each path is re-pointed at this device's folders (a no-op when restoring on the same device).
 * Each file is written to a `.restore.part` name and renamed, so a kill mid-restore leaves no half-written file
 * that a later restore would then skip as "already there".
 * [parseEntry] and [rebasePath] are pure and mirrored in tools/verify/backup_check.py.
 */
object BackupManager {

    enum class Area(val prefix: String) { EXPORTS("exports/"), PROJECTS("projects/") }

    data class RestoreResult(val written: Int, val skipped: Int, val rejected: Int)

    /** Stop a ZIP that claims to unpack to more than this many bytes (a "zip bomb"): 6 GB is far beyond real use. */
    const val MAX_RESTORE_BYTES = 6L * 1024 * 1024 * 1024

    private const val PART_SUFFIX = ".restore.part"

    private fun baseDir(context: Context, area: Area): File = when (area) {
        Area.EXPORTS -> PdfExporter.exportDir(context)
        Area.PROJECTS -> FileUtils.projectsRootDir(context)
    }

    /** ZIP entry name -> (area, path relative to the area's folder), or null if it must not be extracted. Pure. */
    fun parseEntry(name: String): Pair<Area, String>? {
        if (name.indexOf('\u0000') >= 0) return null
        val n = name.replace('\\', '/')
        if (n.startsWith("/")) return null
        val area = Area.values().firstOrNull { n.startsWith(it.prefix) } ?: return null
        val rel = n.substring(area.prefix.length)
        if (rel.isEmpty() || rel.endsWith("/")) return null       // a directory entry carries no file
        if (rel.split('/').any { it.isEmpty() || it == "." || it == ".." }) return null
        return Pair(area, rel)
    }

    /** True if [target] resolves (symlinks included) to a place inside [base]. */
    fun isInside(base: File, target: File): Boolean {
        val b = base.canonicalPath
        val t = target.canonicalPath
        return t.startsWith(b + File.separator)
    }

    /** Re-point an absolute path stored by another install at this device's folders. Pure.
     *  `.../projects/<id>/...` -> [projectsRoot]/<id>/...;  `.../Documents/<file>` -> [exportsRoot]/<file>;
     *  anything else is returned unchanged. */
    fun rebasePath(path: String, projectsRoot: String, exportsRoot: String): String {
        val p = path.lastIndexOf("/projects/")
        if (p >= 0) return projectsRoot.trimEnd('/') + path.substring(p + "/projects".length)
        val d = path.lastIndexOf("/Documents/")
        if (d >= 0) return exportsRoot.trimEnd('/') + path.substring(d + "/Documents".length)
        return path
    }

    /** project.json text with every stored path rebased; returns the original text if it does not parse. */
    fun rebaseProjectJson(text: String, projectsRoot: String, exportsRoot: String): String {
        return try {
            val obj = JSONObject(text)
            fun fix(s: String) = rebasePath(s, projectsRoot, exportsRoot)
            fun fixArray(key: String) {
                val arr = obj.optJSONArray(key) ?: return
                val out = JSONArray()
                for (i in 0 until arr.length()) out.put(fix(arr.getString(i)))
                obj.put(key, out)
            }
            fixArray("pendingRawPaths")
            fixArray("ebookPaths")
            obj.optJSONArray("pages")?.let { arr ->
                for (i in 0 until arr.length()) {
                    val page = arr.getJSONObject(i)
                    if (page.has("path") && !page.isNull("path")) page.put("path", fix(page.getString("path")))
                }
            }
            for (key in arrayOf("pdfPath", "compressedPdfPath", "ocrTextPath")) {
                if (obj.has(key) && !obj.isNull(key)) obj.put(key, fix(obj.getString(key)))
            }
            obj.toString()
        } catch (e: Exception) {
            text
        }
    }

    /** Writes every file of both areas into [out] as a ZIP. @return number of files stored. */
    fun backup(context: Context, out: OutputStream): Int {
        var count = 0
        ZipOutputStream(BufferedOutputStream(out)).use { zip ->
            zip.setLevel(Deflater.BEST_SPEED)    // PDFs and JPEGs are already compressed: speed over a few percent
            for (area in Area.values()) {
                val base = baseDir(context, area)
                base.walkTopDown()
                    .filter { it.isFile && !it.name.endsWith(PART_SUFFIX) }
                    .forEach { f ->
                        val rel = f.relativeTo(base).invariantSeparatorsPath
                        zip.putNextEntry(ZipEntry(area.prefix + rel).apply { time = f.lastModified() })
                        f.inputStream().use { it.copyTo(zip) }
                        zip.closeEntry()
                        count++
                    }
            }
        }
        return count
    }

    /** Unpacks a backup ZIP made by [backup]. Throws if it holds nothing this app recognises. */
    fun restore(context: Context, input: InputStream): RestoreResult {
        var written = 0
        var skipped = 0
        var rejected = 0
        var recognised = 0
        var total = 0L
        val projectsRoot = FileUtils.projectsRootDir(context).absolutePath
        val exportsRoot = PdfExporter.exportDir(context).absolutePath
        ZipInputStream(BufferedInputStream(input)).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    val parsed = parseEntry(entry.name)
                    if (parsed == null) {
                        rejected++
                    } else {
                        recognised++
                        val (area, rel) = parsed
                        val base = baseDir(context, area)
                        val target = File(base, rel)
                        if (!isInside(base, target)) {
                            rejected++
                        } else if (target.exists()) {
                            skipped++
                        } else {
                            target.parentFile?.mkdirs()
                            val part = File(target.parentFile, target.name + PART_SUFFIX)
                            try {
                                part.outputStream().use { o ->
                                    val buf = ByteArray(64 * 1024)
                                    while (true) {
                                        val n = zip.read(buf)
                                        if (n < 0) break
                                        total += n
                                        if (total > MAX_RESTORE_BYTES) throw IllegalStateException("backup too large")
                                        o.write(buf, 0, n)
                                    }
                                }
                                if (area == Area.PROJECTS && target.name == "project.json") {
                                    val fixed = rebaseProjectJson(part.readText(Charsets.UTF_8), projectsRoot, exportsRoot)
                                    part.writeText(fixed, Charsets.UTF_8)
                                }
                                if (!part.renameTo(target)) throw IllegalStateException("rename failed")
                                written++
                            } catch (e: Exception) {
                                runCatching { part.delete() }
                                throw e
                            }
                        }
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        if (recognised == 0) throw IllegalArgumentException("not a backup of this app")
        return RestoreResult(written, skipped, rejected)
    }
}
