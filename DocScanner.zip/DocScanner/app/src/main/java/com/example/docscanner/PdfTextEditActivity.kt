package com.example.docscanner

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.docscanner.adapter.TextChunkAdapter
import com.example.docscanner.databinding.ActivityPdfTextEditBinding
import com.example.docscanner.model.PdfTextEditState
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfTextEditor
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfReader
import com.itextpdf.kernel.pdf.PdfWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * "Sửa chữ PDF" - find-and-replace short runs of already-existing real text in an external PDF.
 * See [PdfTextEditor]'s own doc comment for the full technical picture and exactly what this
 * refuses rather than guesses at - this Activity is UI only, every actual PDF read/write decision
 * lives there.
 *
 * Keeps ONE `PdfDocument` open (stamping mode) for the whole session - every edit the person makes,
 * across however many pages/chunks, is applied to it immediately (see [PdfTextEditor.applyEdit]);
 * Save just closes it (finalizing the PDF's own serialization), no separate re-open/re-apply step.
 * Matches how `PdfObjectRecompressor` already keeps one `PdfDocument` open across every image
 * before a single close.
 *
 * **Backup/restore** ([PdfTextEditState]) - unlike this Activity's first version, a kill mid-session
 * IS now recoverable: [srcFile] lives in durable storage
 * ([com.example.docscanner.util.FileUtils.textEditSourceDir]), and every successful edit is
 * recorded (page, chunk index, new text) alongside it. [onCreate] checks for saved state BEFORE
 * launching the picker - if found, it reopens THAT source fresh and silently replays every
 * recorded edit in order (see [restoreFromSavedState]) rather than trying to resume the half-built
 * output file directly, which [PdfTextEditState]'s own doc comment explains isn't possible with
 * how iText's stamping mode serializes a document. [explicitlyDiscarding] distinguishes a person
 * choosing to discard (clears the saved state, see [onDestroy]) from any other exit (process
 * death, plain backgrounding) - which must NOT clear it, or there would be nothing left to restore.
 */
class PdfTextEditActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPdfTextEditBinding
    private lateinit var adapter: TextChunkAdapter

    private var pdfDocument: PdfDocument? = null
    private var srcFile: File? = null
    private var outFile: File? = null
    private var currentPage = 1
    private var totalPages = 0
    private var hasAppliedEdits = false
    private var explicitlyDiscarding = false
    private val appliedEdits = mutableListOf<PdfTextEditState.AppliedEdit>()

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openNewPdf(uri) else finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfTextEditBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.tool_text_edit_title)

        adapter = TextChunkAdapter(onTap = { chunk -> showEditDialog(chunk) })
        binding.rvChunks.layoutManager = LinearLayoutManager(this)
        binding.rvChunks.adapter = adapter

        binding.btnPrevPage.setOnClickListener { showPage(currentPage - 1) }
        binding.btnNextPage.setOnClickListener { showPage(currentPage + 1) }
        binding.btnSaveTextEdit.setOnClickListener { saveAndExit() }

        val saved = PdfTextEditState.restore(this)
        if (saved != null) {
            restoreFromSavedState(saved)
        } else {
            pdfPicker.launch(arrayOf("application/pdf"))
        }
    }

    private fun openNewPdf(uri: Uri) {
        setBusy(true, getString(R.string.text_edit_loading))
        lifecycleScope.launch {
            val opened = withContext(Dispatchers.IO) {
                runCatching {
                    val src = copyUriToDurableSourceFile(uri) ?: return@runCatching null
                    val out = File(PdfExporter.exportDir(this@PdfTextEditActivity), "${FileUtils.defaultCompressedName()}.pdf")
                    val doc = PdfDocument(PdfReader(src.absolutePath), PdfWriter(out.absolutePath))
                    Triple(src, out, doc)
                }.getOrNull()
            }
            setBusy(false, null)
            if (opened == null || opened.third.numberOfPages == 0) {
                Toast.makeText(this@PdfTextEditActivity, getString(R.string.annotate_load_failed), Toast.LENGTH_LONG).show()
                finish()
                return@launch
            }
            srcFile = opened.first
            outFile = opened.second
            pdfDocument = opened.third
            totalPages = opened.third.numberOfPages
            // Baseline save right away (empty edit list) - same defensive reasoning as other
            // editors' early persist: a kill before the first edit still leaves the durable source
            // copy findable next time, instead of only starting to track state after edit #1.
            PdfTextEditState.persist(this@PdfTextEditActivity, opened.first.absolutePath, emptyList())
            showPage(1)
        }
    }

    private fun restoreFromSavedState(saved: PdfTextEditState.SavedState) {
        setBusy(true, getString(R.string.text_edit_loading))
        lifecycleScope.launch {
            val opened = withContext(Dispatchers.IO) {
                runCatching {
                    val out = File(PdfExporter.exportDir(this@PdfTextEditActivity), "${FileUtils.defaultCompressedName()}.pdf")
                    val doc = PdfDocument(PdfReader(saved.sourcePath), PdfWriter(out.absolutePath))
                    saved.edits.forEach { edit ->
                        val chunk = PdfTextEditor.extractChunks(doc, edit.pageNumber).find { it.index == edit.chunkIndex }
                        if (chunk != null) runCatching { PdfTextEditor.applyEdit(doc, edit.pageNumber, chunk, edit.newText) }
                    }
                    Pair(out, doc)
                }.getOrNull()
            }
            setBusy(false, null)
            if (opened == null || opened.second.numberOfPages == 0) {
                // Source copy or replay failed outright - nothing safe to continue with. Clear the
                // stale state so the person isn't stuck unable to start a fresh session, and fall
                // back to the normal picker.
                PdfTextEditState.clear(this@PdfTextEditActivity)
                Toast.makeText(this@PdfTextEditActivity, getString(R.string.annotate_load_failed), Toast.LENGTH_LONG).show()
                pdfPicker.launch(arrayOf("application/pdf"))
                return@launch
            }
            srcFile = File(saved.sourcePath)
            outFile = opened.first
            pdfDocument = opened.second
            totalPages = opened.second.numberOfPages
            appliedEdits.addAll(saved.edits)
            hasAppliedEdits = saved.edits.isNotEmpty()
            showPage(1)
        }
    }

    private fun showPage(page: Int) {
        val doc = pdfDocument ?: return
        if (page !in 1..totalPages) return
        currentPage = page
        binding.tvPageIndicator.text = getString(R.string.annotate_page_indicator, page, totalPages)
        binding.btnPrevPage.isEnabled = page > 1
        binding.btnNextPage.isEnabled = page < totalPages
        val chunks = runCatching { PdfTextEditor.extractChunks(doc, page) }.getOrDefault(emptyList())
        adapter.submitList(chunks)
        binding.tvEmptyChunks.visibility = if (chunks.isEmpty()) View.VISIBLE else View.GONE
        binding.rvChunks.visibility = if (chunks.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun showEditDialog(chunk: PdfTextEditor.TextChunk) {
        val editText = EditText(this).apply {
            setText(chunk.text)
            setSelection(text.length)
        }
        val container = FrameLayout(this).apply {
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, 0)
            addView(editText)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.text_edit_dialog_title)
            .setView(container)
            .setPositiveButton(R.string.dialog_ok) { _, _ ->
                val newText = editText.text?.toString().orEmpty()
                if (newText.isNotBlank() && newText != chunk.text) applyEdit(chunk, newText)
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun applyEdit(chunk: PdfTextEditor.TextChunk, newText: String) {
        val doc = pdfDocument ?: return
        setBusy(true, null)
        lifecycleScope.launch {
            val result = withContext(Dispatchers.Default) {
                runCatching { PdfTextEditor.applyEdit(doc, currentPage, chunk, newText) }
                    .getOrElse { PdfTextEditor.EditResult.ChunkNotFound }
            }
            setBusy(false, null)
            when (result) {
                is PdfTextEditor.EditResult.Success -> {
                    hasAppliedEdits = true
                    appliedEdits.add(PdfTextEditState.AppliedEdit(currentPage, chunk.index, newText))
                    srcFile?.let { PdfTextEditState.persist(this@PdfTextEditActivity, it.absolutePath, appliedEdits) }
                    Toast.makeText(this@PdfTextEditActivity, R.string.text_edit_applied, Toast.LENGTH_SHORT).show()
                    showPage(currentPage) // re-extract - positions/indices after this point may have shifted meaning
                }
                is PdfTextEditor.EditResult.MissingGlyphs -> Toast.makeText(
                    this@PdfTextEditActivity,
                    getString(R.string.text_edit_missing_glyphs, result.chars),
                    Toast.LENGTH_LONG
                ).show()
                is PdfTextEditor.EditResult.ScaleOutOfRange -> Toast.makeText(
                    this@PdfTextEditActivity, R.string.text_edit_scale_out_of_range, Toast.LENGTH_LONG
                ).show()
                is PdfTextEditor.EditResult.ChunkNotFound -> Toast.makeText(
                    this@PdfTextEditActivity, R.string.text_edit_chunk_not_found, Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun saveAndExit() {
        val doc = pdfDocument ?: return
        setBusy(true, getString(R.string.text_edit_saving))
        lifecycleScope.launch {
            val closed = withContext(Dispatchers.Default) { runCatching { doc.close() } }
            pdfDocument = null
            setBusy(false, null)
            val out = outFile
            if (closed.isSuccess && out != null && out.exists()) {
                PdfTextEditState.clear(this@PdfTextEditActivity)
                Toast.makeText(this@PdfTextEditActivity, getString(R.string.export_success, out.name), Toast.LENGTH_LONG).show()
            } else {
                runCatching { out?.delete() }
                Toast.makeText(this@PdfTextEditActivity, getString(R.string.export_failed, ""), Toast.LENGTH_LONG).show()
            }
            finish()
        }
    }

    private fun onBackPressedOrUp(): Boolean {
        if (!hasAppliedEdits) {
            explicitlyDiscarding = true
            finish()
            return true
        }
        AlertDialog.Builder(this)
            .setMessage(R.string.text_edit_discard_confirm)
            .setPositiveButton(R.string.annotate_discard_yes) { _, _ ->
                explicitlyDiscarding = true
                finish()
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
        return true
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (!onBackPressedOrUp()) super.onBackPressed()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Close the PdfDocument if Save was never reached, so its file handles don't leak, and
        // discard the half-finished OUTPUT file - neither is ever recoverable regardless (see
        // PdfTextEditState's own doc comment for why resuming a half-written stamping-mode output
        // isn't possible). The saved STATE (durable source copy + edit list) is a different
        // matter: only [explicitlyDiscarding] clears it - any other exit (process death, plain
        // backgrounding) leaves it in place so [onCreate] can restore it next time.
        if (pdfDocument != null) {
            runCatching { pdfDocument?.close() }
            runCatching { outFile?.delete() }
        }
        if (explicitlyDiscarding) {
            PdfTextEditState.clear(this)
        }
    }

    private fun setBusy(busy: Boolean, message: String?) {
        binding.progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        binding.tvProgress.visibility = if (busy && message != null) View.VISIBLE else View.GONE
        binding.tvProgress.text = message
        binding.btnSaveTextEdit.isEnabled = !busy
        binding.rvChunks.isEnabled = !busy
    }

    /** Copies the picked Uri into durable storage (iText's `PdfReader` needs a real file path, not
     *  a content:// stream - same need `MainActivity.copyUriToTempPdfFile` has, duplicated here
     *  rather than extracted into `FileUtils` since it's a few lines) - into
     *  [FileUtils.textEditSourceDir] specifically, NOT cache, because [PdfTextEditState] needs this
     *  exact copy to still exist for a restore to work (see that class's own doc comment). */
    private fun copyUriToDurableSourceFile(uri: Uri): File? {
        return try {
            val file = File(FileUtils.textEditSourceDir(this), "TEXTEDIT_SRC_${System.currentTimeMillis()}.pdf")
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            } ?: return null
            file
        } catch (e: Exception) {
            null
        }
    }
}
