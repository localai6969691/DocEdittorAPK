package com.example.docscanner

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.docscanner.adapter.TextChunkAdapter
import com.example.docscanner.databinding.ActivityPdfTextEditBinding
import com.example.docscanner.model.PdfTextEditState
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfVerify
import com.example.docscanner.util.PdfTextEditor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.File
import java.io.FileOutputStream

/**
 * "Sửa chữ PDF" - find-and-replace short runs of already-existing real text in an external PDF.
 * See [PdfTextEditor]'s own doc comment for the full technical picture and exactly what this
 * refuses rather than guesses at - this Activity is UI only, every actual PDF read/write decision
 * lives there.
 *
 * Keeps ONE PdfBox `PDDocument` open (in memory) for the whole session - every edit the person makes,
 * across however many pages/chunks, is applied to it immediately (see [PdfTextEditor.applyEdit]);
 * Save writes it out with `PDDocument.save(File)` and closes it - nothing touches the disk before
 * that, so there is no half-written output file to worry about.
 *
 * **Backup/restore** ([PdfTextEditState]) - unlike this Activity's first version, a kill mid-session
 * IS now recoverable: [srcFile] lives in durable storage
 * ([com.example.docscanner.util.FileUtils.textEditSourceDir]), and every successful edit is
 * recorded (page, chunk index, new text) alongside it. [onCreate] checks for saved state BEFORE
 * launching the picker - if found, it reopens THAT source fresh and silently replays every
 * recorded edit in order (see [restoreFromSavedState]) rather than trying to resume the half-built
 * output file directly, which [PdfTextEditState]'s own doc comment explains isn't possible with
 * how a PDDocument is only serialized on save(). [explicitlyDiscarding] distinguishes a person
 * choosing to discard (clears the saved state, see [onDestroy]) from any other exit (process
 * death, plain backgrounding) - which must NOT clear it, or there would be nothing left to restore.
 */
class PdfTextEditActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPdfTextEditBinding
    private lateinit var adapter: TextChunkAdapter

    private var pdfDocument: PDDocument? = null
    private var srcFile: File? = null
    private var outFile: File? = null
    private var currentPage = 1
    private var totalPages = 0
    private var hasAppliedEdits = false
    private var explicitlyDiscarding = false
    private val appliedEdits = mutableListOf<PdfTextEditState.AppliedEdit>()

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) openNewPdf(uri) else finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfTextEditBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.tool_text_edit_title)

        adapter = TextChunkAdapter(onTap = { chunk -> showEditDialog(chunk) })
        binding.rvChunks.layoutManager = LinearLayoutManager(this)
        binding.rvChunks.adapter = adapter

        binding.btnPrevPage.setOnClickListener { showPage(currentPage - 1) }
        binding.btnNextPage.setOnClickListener { showPage(currentPage + 1) }
        binding.btnSaveTextEdit.setOnClickListener { saveAndExit() }

        // targetSdk 36: Activity.onBackPressed() is no longer called (predictive back) - use the
        // dispatcher instead.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                onBackPressedOrUp()
            }
        })

        val saved = PdfTextEditState.restore(this)
        if (saved != null) {
            restoreFromSavedState(saved)
        } else {
            pdfPicker.launch(arrayOf("application/pdf"))
        }
    }

    private fun openNewPdf(uri: Uri) {
        setBusy(true, getString(R.string.text_edit_loading))
        lifecycleScope.launch {
            val opened = withContext(Dispatchers.IO) {
                runCatching {
                    val src = copyUriToDurableSourceFile(uri) ?: return@runCatching null
                    val out = File(PdfExporter.exportDir(this@PdfTextEditActivity), "${FileUtils.defaultCompressedName()}.pdf")
                    val doc = openEditableDocument(src) ?: return@runCatching null
                    Triple(src, out, doc)
                }.getOrNull()
            }
            setBusy(false, null)
            if (opened == null || opened.third.numberOfPages == 0) {
                Toast.makeText(this@PdfTextEditActivity, getString(R.string.annotate_load_failed), Toast.LENGTH_LONG).show()
                finish()
                return@launch
            }
            srcFile = opened.first
            outFile = opened.second
            pdfDocument = opened.third
            totalPages = opened.third.numberOfPages
            // Baseline save right away (empty edit list) - same defensive reasoning as other
            // editors' early persist: a kill before the first edit still leaves the durable source
            // copy findable next time, instead of only starting to track state after edit #1.
            PdfTextEditState.persist(this@PdfTextEditActivity, opened.first.absolutePath, emptyList())
            showPage(1)
        }
    }

    private fun restoreFromSavedState(saved: PdfTextEditState.SavedState) {
        setBusy(true, getString(R.string.text_edit_loading))
        lifecycleScope.launch {
            val opened = withContext(Dispatchers.IO) {
                runCatching {
                    val out = File(PdfExporter.exportDir(this@PdfTextEditActivity), "${FileUtils.defaultCompressedName()}.pdf")
                    val doc = openEditableDocument(File(saved.sourcePath)) ?: return@runCatching null
                    saved.edits.forEach { edit ->
                        val chunk = PdfTextEditor.extractChunks(doc, edit.pageNumber).find { it.index == edit.chunkIndex }
                        if (chunk != null) runCatching { PdfTextEditor.applyEdit(doc, edit.pageNumber, chunk, edit.newText) }
                    }
                    Pair(out, doc)
                }.getOrNull()
            }
            setBusy(false, null)
            if (opened == null || opened.second.numberOfPages == 0) {
                // Source copy or replay failed outright - nothing safe to continue with. Clear the
                // stale state so the person isn't stuck unable to start a fresh session, and fall
                // back to the normal picker.
                PdfTextEditState.clear(this@PdfTextEditActivity)
                Toast.makeText(this@PdfTextEditActivity, getString(R.string.annotate_load_failed), Toast.LENGTH_LONG).show()
                pdfPicker.launch(arrayOf("application/pdf"))
                return@launch
            }
            srcFile = File(saved.sourcePath)
            outFile = opened.first
            pdfDocument = opened.second
            totalPages = opened.second.numberOfPages
            appliedEdits.addAll(saved.edits)
            hasAppliedEdits = saved.edits.isNotEmpty()
            showPage(1)
        }
    }

    private fun showPage(page: Int) {
        val doc = pdfDocument ?: return
        if (page !in 1..totalPages) return
        currentPage = page
        binding.tvPageIndicator.text = getString(R.string.annotate_page_indicator, page, totalPages)
        binding.btnPrevPage.isEnabled = page > 1
        binding.btnNextPage.isEnabled = page < totalPages
        val chunks = runCatching { PdfTextEditor.extractChunks(doc, page) }.getOrDefault(emptyList())
        adapter.submitList(chunks)
        binding.tvEmptyChunks.visibility = if (chunks.isEmpty()) View.VISIBLE else View.GONE
        binding.rvChunks.visibility = if (chunks.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun showEditDialog(chunk: PdfTextEditor.TextChunk) {
        val editText = EditText(this).apply {
            setText(chunk.text)
            setSelection(text.length)
        }
        val container = FrameLayout(this).apply {
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, 0)
            addView(editText)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.text_edit_dialog_title)
            .setView(container)
            .setPositiveButton(R.string.dialog_ok) { _, _ ->
                val newText = editText.text?.toString().orEmpty()
                if (newText.isNotBlank() && newText != chunk.text) applyEdit(chunk, newText)
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun applyEdit(chunk: PdfTextEditor.TextChunk, newText: String) {
        val doc = pdfDocument ?: return
        setBusy(true, null)
        lifecycleScope.launch {
            val result = withContext(Dispatchers.Default) {
                runCatching { PdfTextEditor.applyEdit(doc, currentPage, chunk, newText) }
                    .getOrElse { PdfTextEditor.EditResult.ChunkNotFound }
            }
            setBusy(false, null)
            when (result) {
                is PdfTextEditor.EditResult.Success -> {
                    hasAppliedEdits = true
                    appliedEdits.add(PdfTextEditState.AppliedEdit(currentPage, chunk.index, newText))
                    srcFile?.let { PdfTextEditState.persist(this@PdfTextEditActivity, it.absolutePath, appliedEdits) }
                    Toast.makeText(this@PdfTextEditActivity, R.string.text_edit_applied, Toast.LENGTH_SHORT).show()
                    showPage(currentPage) // re-extract - positions/indices after this point may have shifted meaning
                }
                is PdfTextEditor.EditResult.MissingGlyphs -> Toast.makeText(
                    this@PdfTextEditActivity,
                    // A space is invisible in a message - spell it out so the person can see what's missing.
                    getString(R.string.text_edit_missing_glyphs, result.chars.replace(" ", "␣ (dấu cách)")),
                    Toast.LENGTH_LONG
                ).show()
                is PdfTextEditor.EditResult.ScaleOutOfRange -> Toast.makeText(
                    this@PdfTextEditActivity, R.string.text_edit_scale_out_of_range, Toast.LENGTH_LONG
                ).show()
                is PdfTextEditor.EditResult.UnsupportedFont -> Toast.makeText(
                    this@PdfTextEditActivity, R.string.text_edit_unsupported_font, Toast.LENGTH_LONG
                ).show()
                is PdfTextEditor.EditResult.ChunkNotFound -> Toast.makeText(
                    this@PdfTextEditActivity, R.string.text_edit_chunk_not_found, Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun saveAndExit() {
        val doc = pdfDocument ?: return
        setBusy(true, getString(R.string.text_edit_saving))
        lifecycleScope.launch {
            val out = outFile
            val pageCount = totalPages
            val closed = withContext(Dispatchers.Default) {
                runCatching {
                    if (out == null) error("no output file")
                    doc.save(out)
                    doc.close()
                    // Never hand over a file that a second, independent reader (Android's PdfRenderer)
                    // cannot open - editing real text objects is the riskiest thing this app does.
                    check(PdfVerify.opensAsPdf(out, pageCount)) { "output failed verification" }
                }
            }
            pdfDocument = null
            setBusy(false, null)
            if (closed.isSuccess && out != null && out.exists()) {
                PdfTextEditState.clear(this@PdfTextEditActivity)
                Toast.makeText(this@PdfTextEditActivity, getString(R.string.export_success, out.name), Toast.LENGTH_LONG).show()
            } else {
                runCatching { out?.delete() }
                Toast.makeText(this@PdfTextEditActivity, getString(R.string.export_failed, ""), Toast.LENGTH_LONG).show()
            }
            finish()
        }
    }

    private fun onBackPressedOrUp(): Boolean {
        if (!hasAppliedEdits) {
            explicitlyDiscarding = true
            finish()
            return true
        }
        AlertDialog.Builder(this)
            .setMessage(R.string.text_edit_discard_confirm)
            .setPositiveButton(R.string.annotate_discard_yes) { _, _ ->
                explicitlyDiscarding = true
                finish()
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
        return true
    }

    override fun onDestroy() {
        super.onDestroy()
        // Close the PDDocument if Save was never reached, so its file handles/scratch memory
        // don't leak, and discard any output file - nothing here is ever resumable directly (see
        // PdfTextEditState's own doc comment: recovery replays the recorded edits on the source). The saved STATE (durable source copy + edit list) is a different
        // matter: only [explicitlyDiscarding] clears it - any other exit (process death, plain
        // backgrounding) leaves it in place so [onCreate] can restore it next time.
        if (pdfDocument != null) {
            runCatching { pdfDocument?.close() }
            runCatching { outFile?.delete() }
        }
        if (explicitlyDiscarding) {
            PdfTextEditState.clear(this)
        }
    }

    private fun setBusy(busy: Boolean, message: String?) {
        binding.progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        binding.tvProgress.visibility = if (busy && message != null) View.VISIBLE else View.GONE
        binding.tvProgress.text = message
        binding.btnSaveTextEdit.isEnabled = !busy
        binding.rvChunks.isEnabled = !busy
    }

    /** Opens [file] with PdfBox and refuses (returns null) a document that is encrypted WITHOUT
     *  granting modify permission - editing text in a file its owner locked is not something this
     *  tool should do silently. Runs on a background thread (called from `Dispatchers.IO`). */
    private fun openEditableDocument(file: File): PDDocument? {
        // Mixed memory mode: big scans spill to a scratch file in the app's cache instead of the heap.
        val memory = MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(file.parentFile)
        val doc = PDDocument.load(file, memory)
        if (doc.isEncrypted && !doc.currentAccessPermission.canModify()) {
            runCatching { doc.close() }
            return null
        }
        return doc
    }

    /** Copies the picked Uri into durable storage (PdfBox's `PDDocument.load(File)` needs a real file path, not
     *  a content:// stream - same need `MainActivity.copyUriToTempPdfFile` has, duplicated here
     *  rather than extracted into `FileUtils` since it's a few lines) - into
     *  [FileUtils.textEditSourceDir] specifically, NOT cache, because [PdfTextEditState] needs this
     *  exact copy to still exist for a restore to work (see that class's own doc comment). */
    private fun copyUriToDurableSourceFile(uri: Uri): File? {
        return try {
            val file = File(FileUtils.textEditSourceDir(this), "TEXTEDIT_SRC_${System.currentTimeMillis()}.pdf")
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            } ?: return null
            file
        } catch (e: Exception) {
            null
        }
    }
}
