package com.example.docscanner.util

import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max

/**
 * "Tự động chụp" decision logic - deliberately free of any Android / CameraX type so it can be checked
 * on its own (tools/verify/stability_check.py is the line-by-line Python twin that was run against ten
 * scripted situations). Paid scanner SDKs (Scanbot, Dynamsoft...) call this feature "auto snapping".
 *
 * Fed once per analysed camera frame (about 5 per second) with the four detected corners, a focus
 * measure and the clock, it answers whether to release the shutter NOW. A shot fires only when
 *  - a document-shaped quadrilateral (convex, 20%-97% of the frame) has been seen, and
 *  - none of its corners moved more than 1.8% of the frame's long side between two frames for 1.2 s in
 *    a row (short detector drop-outs under 0.5 s do not reset that timer), and
 *  - the frame is as sharp as the sharpest one of the last 2 s (within 60%): the lens is not still
 *    hunting for focus. This is RELATIVE on purpose - an absolute sharpness limit would have to be
 *    calibrated per phone and per lighting, which cannot be done here, and
 *  - it is armed: after a shot the tracker stays quiet until the page has left the view for 0.7 s or
 *    moved by more than 10% (turning the page), so holding one page still never produces a burst;
 *    and at least 3 s passed since the previous shot.
 * The thresholds are starting values chosen on simulated sequences, not on real handheld video.
 */
class CaptureStability {

    enum class State { SEARCHING, MOVING, HOLDING, TRIGGER }

    private var prev: DoubleArray? = null
    private var stableSince: Long = -1
    private var lastSeen: Long = -1
    private var lastTrigger: Long = -1
    private var armed = true
    private var lostSince: Long = -1
    private val sharp = ArrayDeque<Pair<Long, Double>>()

    fun reset() {
        prev = null; stableSince = -1; lastSeen = -1; lastTrigger = -1; armed = true; lostSince = -1; sharp.clear()
    }

    /**
     * @param quad 8 numbers x0,y0..x3,y3 (top-left, top-right, bottom-right, bottom-left) normalised to
     *   0..1 by the frame's width (x) and height (y), or null when nothing was detected
     * @param aspect frame width / frame height
     */
    fun update(quad: DoubleArray?, sharpness: Double, nowMs: Long, aspect: Double): State {
        while (sharp.isNotEmpty() && nowMs - sharp.first().first > SHARP_WINDOW_MS) sharp.removeFirst()
        if (quad != null) sharp.addLast(nowMs to sharpness)

        val docLike = quad != null && area(quad) in MIN_AREA..MAX_AREA && isConvex(quad)
        if (!docLike) {
            if (lastSeen < 0 || nowMs - lastSeen > LOST_GRACE_MS) { prev = null; stableSince = -1 }
            if (lostSince < 0) lostSince = nowMs
            if (nowMs - lostSince >= REARM_LOST_MS) armed = true
            return State.SEARCHING
        }
        quad!!
        lostSince = -1
        lastSeen = nowMs

        var moved = 0.0
        val p = prev
        if (p != null) {
            for (i in 0 until 4) {
                val dx = (quad[2 * i] - p[2 * i]) * aspect
                val dy = quad[2 * i + 1] - p[2 * i + 1]
                moved = max(moved, hypot(dx, dy))
            }
            moved /= max(aspect, 1.0) // portrait and landscape frames behave alike (units of the long side)
        }
        prev = quad
        if (moved > REARM_MOVE) armed = true
        if (stableSince < 0 || moved > MOVE_TOL) {
            stableSince = nowMs
            return State.MOVING
        }
        val best = sharp.maxOf { it.second }
        if (sharpness < SHARP_FLOOR || sharpness < SHARP_KEEP * best) return State.HOLDING
        if (nowMs - stableSince < HOLD_MS) return State.HOLDING
        if (!armed) return State.HOLDING
        if (lastTrigger >= 0 && nowMs - lastTrigger < COOLDOWN_MS) return State.HOLDING
        lastTrigger = nowMs
        armed = false
        return State.TRIGGER
    }

    /** Fraction (0..1) of the "hold still" time already served - for a progress hint on screen. */
    fun holdProgress(nowMs: Long): Double =
        if (stableSince < 0) 0.0 else ((nowMs - stableSince).toDouble() / HOLD_MS).coerceIn(0.0, 1.0)

    companion object {
        const val MIN_AREA = 0.20
        const val MAX_AREA = 0.97
        const val MOVE_TOL = 0.018
        const val REARM_MOVE = 0.10
        const val HOLD_MS = 1200L
        const val COOLDOWN_MS = 3000L
        const val LOST_GRACE_MS = 500L
        const val REARM_LOST_MS = 700L
        const val SHARP_KEEP = 0.6
        const val SHARP_WINDOW_MS = 2000L
        const val SHARP_FLOOR = 5.0

        /** Shoelace area of the quad in normalised (fraction-of-frame) units. */
        fun area(q: DoubleArray): Double {
            var a = 0.0
            for (i in 0 until 4) {
                val j = (i + 1) % 4
                a += q[2 * i] * q[2 * j + 1] - q[2 * j] * q[2 * i + 1]
            }
            return abs(a) / 2
        }

        /** True for a convex quad; a bow-tie (self-intersecting) polygon gives false. */
        fun isConvex(q: DoubleArray): Boolean {
            var sum = 0
            for (i in 0 until 4) {
                val b = (i + 1) % 4
                val c = (i + 2) % 4
                val cross = (q[2 * b] - q[2 * i]) * (q[2 * c + 1] - q[2 * b + 1]) -
                    (q[2 * b + 1] - q[2 * i + 1]) * (q[2 * c] - q[2 * b])
                if (cross != 0.0) sum += if (cross > 0) 1 else -1
            }
            return abs(sum) == 4
        }
    }
}
