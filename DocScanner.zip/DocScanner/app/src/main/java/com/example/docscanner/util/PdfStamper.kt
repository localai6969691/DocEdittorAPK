package com.example.docscanner.util

import android.graphics.Bitmap
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import java.io.File

/**
 * Lays one picture - a handwritten signature or a stamp, both transparent PNG-style bitmaps - onto chosen pages
 * of an existing PDF, WITHOUT rasterizing it: text, fonts and images of the page stay as they were, the picture
 * is appended to the page content (so it sits on top, and a viewer that selects text still finds the original).
 *
 * The position is given the way a person points at a page: where the picture's CENTRE is, as a fraction of the
 * page AS DISPLAYED (0..1 from the left, 0..1 from the top), and how wide it is as a fraction of the page width.
 * [PdfPageGeometry] turns that into the page's real coordinates, so the same placement lands on the same spot of a
 * page shown rotated or with an offset CropBox (checked with poppler by tools/verify/stamp_check.py).
 *
 * This is a VISUAL signature (an image on the page). It is not a cryptographic signature: a viewer will not show
 * "signed by ..." and the file is not tamper-evident. Say so in the UI wherever it is offered.
 * Writes a NEW file; the input is only read.
 */
object PdfStamper {

    data class Placement(
        /** Centre of the picture, 0..1 from the left of the displayed page. */
        val centerX: Float,
        /** Centre of the picture, 0..1 from the TOP of the displayed page. */
        val centerY: Float,
        /** Width of the picture as a fraction of the displayed page width. */
        val widthFraction: Float
    )

    /** x, y (bottom-left of the picture, in displayed-page points measured from the bottom-left corner) and the
     *  picture's width/height in points. The picture is moved inward if it would hang over an edge, and is never
     *  wider than the page nor taller than the page. Pure function - mirrored in tools/verify/stamp_check.py. */
    fun rectFor(p: Placement, aspect: Float, displayWidth: Float, displayHeight: Float): FloatArray {
        val safeAspect = if (aspect > 0.01f) aspect else 1f
        var w = (p.widthFraction.coerceIn(MIN_WIDTH_FRACTION, MAX_WIDTH_FRACTION)) * displayWidth
        var h = w / safeAspect
        if (h > displayHeight) { h = displayHeight; w = h * safeAspect }
        val cx = p.centerX.coerceIn(0f, 1f) * displayWidth
        val cyTop = p.centerY.coerceIn(0f, 1f) * displayHeight
        val x = (cx - w / 2f).coerceIn(0f, displayWidth - w)
        val yTop = (cyTop - h / 2f).coerceIn(0f, displayHeight - h)
        val y = displayHeight - yTop - h
        return floatArrayOf(x, y, w, h)
    }

    /** @param pageIndexes 0-based pages to stamp; indexes outside the document are ignored.
     *  @return number of pages stamped. */
    fun stamp(src: File, out: File, image: Bitmap, placement: Placement, pageIndexes: Set<Int>): Int {
        require(image.width > 0 && image.height > 0) { "empty picture" }
        val doc = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
        try {
            if (doc.isEncrypted) throw IllegalStateException("encrypted")
            val pages = doc.numberOfPages
            val targets = pageIndexes.filter { it in 0 until pages }.sorted()
            if (targets.isEmpty()) throw IllegalArgumentException("no page selected")
            val pdImage = LosslessFactory.createFromImage(doc, image)
            val aspect = image.width.toFloat() / image.height
            for (i in targets) {
                val page = doc.getPage(i)
                val geo = PdfPageGeometry.of(page)
                val r = rectFor(placement, aspect, geo.displayWidth, geo.displayHeight)
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    cs.saveGraphicsState()
                    cs.transform(geo.displayMatrix())
                    cs.drawImage(pdImage, r[0], r[1], r[2], r[3])
                    cs.restoreGraphicsState()
                }
            }
            PdfStructureOptimizer.save(doc, out)
            if (!PdfVerify.opensAsPdf(out, pages)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
            return targets.size
        } finally {
            runCatching { doc.close() }
        }
    }

    const val MIN_WIDTH_FRACTION = 0.04f
    const val MAX_WIDTH_FRACTION = 0.95f
}
