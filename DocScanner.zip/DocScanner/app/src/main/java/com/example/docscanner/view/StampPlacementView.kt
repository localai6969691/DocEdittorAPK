package com.example.docscanner.view

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import com.example.docscanner.util.PdfStamper

/**
 * Shows one rendered PDF page (fitted and centred in the view) with a movable, resizable picture on top: drag with
 * one finger to move it, pinch to resize. The result is read back as [placement] - the picture's centre and width as
 * FRACTIONS of the page - which is exactly what [PdfStamper.Placement] takes, so it is independent of the size the
 * preview happens to be drawn at (and of the page's rotation, which the preview already shows as the user sees it).
 *
 * The same placement is applied to every page the user chooses, so the preview only needs to be right for the page
 * being shown.
 */
class StampPlacementView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var page: Bitmap? = null
    private var stamp: Bitmap? = null

    private var centerX = 0.5f
    private var centerY = 0.8f
    private var widthFraction = 0.3f

    private val pageRect = RectF()
    private val stampRect = RectF()
    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(200, 25, 118, 210)
        style = Paint.Style.STROKE
        strokeWidth = 2f * resources.displayMetrics.density
        pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }
    private val shadowPaint = Paint().apply { color = Color.argb(40, 0, 0, 0) }

    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false
    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            widthFraction = (widthFraction * detector.scaleFactor)
                .coerceIn(PdfStamper.MIN_WIDTH_FRACTION, PdfStamper.MAX_WIDTH_FRACTION)
            invalidate()
            return true
        }
    })

    fun setPage(bitmap: Bitmap?) {
        page = bitmap
        requestLayout()
        invalidate()
    }

    fun setStamp(bitmap: Bitmap?) {
        stamp = bitmap
        invalidate()
    }

    fun hasStamp(): Boolean = stamp != null

    fun placement(): PdfStamper.Placement = PdfStamper.Placement(centerX, centerY, widthFraction)

    private fun layoutPageRect() {
        val p = page
        if (p == null || width == 0 || height == 0) { pageRect.setEmpty(); return }
        val scale = minOf(width.toFloat() / p.width, height.toFloat() / p.height)
        val w = p.width * scale
        val h = p.height * scale
        pageRect.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
    }

    private fun layoutStampRect() {
        val s = stamp
        if (s == null || pageRect.isEmpty) { stampRect.setEmpty(); return }
        // same clamping as the real stamping so what the user sees is where the picture will land
        val r = PdfStamper.rectFor(placement(), s.width.toFloat() / s.height, pageRect.width(), pageRect.height())
        val left = pageRect.left + r[0]
        val top = pageRect.top + (pageRect.height() - r[1] - r[3])
        stampRect.set(left, top, left + r[2], top + r[3])
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val p = page ?: return
        layoutPageRect()
        if (pageRect.isEmpty) return
        canvas.drawRect(pageRect.left + 4, pageRect.top + 4, pageRect.right + 4, pageRect.bottom + 4, shadowPaint)
        canvas.drawBitmap(p, null, pageRect, bitmapPaint)
        val s = stamp ?: return
        layoutStampRect()
        canvas.drawBitmap(s, null, stampRect, bitmapPaint)
        canvas.drawRect(stampRect, borderPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (stamp == null || pageRect.isEmpty) return super.onTouchEvent(event)
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastX = event.x; lastY = event.y
                // grab only when the finger starts on (or near) the picture, so a stray touch cannot throw it away
                val slop = 24f * resources.displayMetrics.density
                dragging = RectF(stampRect).apply { inset(-slop, -slop) }.contains(event.x, event.y)
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging && !scaleDetector.isInProgress && event.pointerCount == 1) {
                    centerX = (centerX + (event.x - lastX) / pageRect.width()).coerceIn(0f, 1f)
                    centerY = (centerY + (event.y - lastY) / pageRect.height()).coerceIn(0f, 1f)
                    invalidate()
                }
                lastX = event.x; lastY = event.y
            }
            MotionEvent.ACTION_POINTER_UP -> {
                // after a pinch, continue the drag from the finger that is left instead of jumping
                val idx = if (event.actionIndex == 0) 1 else 0
                lastX = event.getX(idx); lastY = event.getY(idx)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }
}
