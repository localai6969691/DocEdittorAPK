package com.example.docscanner.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.R
import com.example.docscanner.databinding.ItemHistoryBinding
import com.example.docscanner.util.FileUtils
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryAdapter(
    private val onClick: (File) -> Unit,
    private val onShare: (File) -> Unit,
    private val onDelete: (File) -> Unit
) : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

    private val items = mutableListOf<File>()

    fun submitList(files: List<File>) {
        items.clear()
        items.addAll(files)
        notifyDataSetChanged()
    }

    inner class ViewHolder(val binding: ItemHistoryBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val file = items[position]
        holder.binding.tvFileName.text = file.name
        val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(file.lastModified()))
        holder.binding.tvFileMeta.text = "$dateStr  •  ${FileUtils.humanFileSize(file.length())}"
        holder.binding.ivFileIcon.setImageResource(
            if (file.extension.equals("pdf", ignoreCase = true)) R.drawable.ic_pdf else R.drawable.ic_book
        )
        holder.binding.root.setOnClickListener { onClick(file) }
        holder.binding.btnShare.setOnClickListener { onShare(file) }
        holder.binding.btnDelete.setOnClickListener { onDelete(file) }
    }

    override fun getItemCount(): Int = items.size
}
