package com.example.docscanner.util

import android.graphics.Bitmap
import android.graphics.Color

/**
 * Decodes this app's own [Ccitt4Encoder] output - used purely as an on-device self-check (see
 * [PdfCompressor]): encode a page, decode it right back, compare pixel-for-pixel against the
 * source bitmap, and only keep the CCITT-encoded bytes if they match exactly. If anything about
 * the encoder or this decoder has a bug that survived the Python/libtiff verification described
 * in [Ccitt4Encoder]'s doc comment, this check catches it at encode time on the very page that
 * triggered it, rather than producing a silently-corrupt PDF - [PdfCompressor] falls back to the
 * lossless 1-bit+Deflate path for that page instead.
 */
internal object Ccitt4Decoder {


    private val WHITE_TERM = arrayOf(
        8 to 0b00110101, 6 to 0b000111, 4 to 0b0111, 4 to 0b1000,
        4 to 0b1011, 4 to 0b1100, 4 to 0b1110, 4 to 0b1111,
        5 to 0b10011, 5 to 0b10100, 5 to 0b00111, 5 to 0b01000,
        6 to 0b001000, 6 to 0b000011, 6 to 0b110100, 6 to 0b110101,
        6 to 0b101010, 6 to 0b101011, 7 to 0b0100111, 7 to 0b0001100,
        7 to 0b0001000, 7 to 0b0010111, 7 to 0b0000011, 7 to 0b0000100,
        7 to 0b0101000, 7 to 0b0101011, 7 to 0b0010011, 7 to 0b0100100,
        7 to 0b0011000, 8 to 0b00000010, 8 to 0b00000011, 8 to 0b00011010,
        8 to 0b00011011, 8 to 0b00010010, 8 to 0b00010011, 8 to 0b00010100,
        8 to 0b00010101, 8 to 0b00010110, 8 to 0b00010111, 8 to 0b00101000,
        8 to 0b00101001, 8 to 0b00101010, 8 to 0b00101011, 8 to 0b00101100,
        8 to 0b00101101, 8 to 0b00000100, 8 to 0b00000101, 8 to 0b00001010,
        8 to 0b00001011, 8 to 0b01010010, 8 to 0b01010011, 8 to 0b01010100,
        8 to 0b01010101, 8 to 0b00100100, 8 to 0b00100101, 8 to 0b01011000,
        8 to 0b01011001, 8 to 0b01011010, 8 to 0b01011011, 8 to 0b01001010,
        8 to 0b01001011, 8 to 0b01001100, 8 to 0b01001101, 8 to 0b00110010,
    )

    private val BLACK_TERM = arrayOf(
        10 to 0b0000110111, 3 to 0b010, 2 to 0b11, 2 to 0b10,
        3 to 0b011, 4 to 0b0011, 4 to 0b0010, 5 to 0b00011,
        6 to 0b000101, 6 to 0b000100, 7 to 0b0000100, 7 to 0b0000101,
        7 to 0b0000111, 8 to 0b00000100, 8 to 0b00000111, 9 to 0b000011000,
        10 to 0b0000010111, 10 to 0b0000011000, 10 to 0b0000001000, 11 to 0b00001100111,
        11 to 0b00001101000, 11 to 0b00001101100, 11 to 0b00000110111, 11 to 0b00000101000,
        11 to 0b00000010111, 11 to 0b00000011000, 12 to 0b000011001010, 12 to 0b000011001011,
        12 to 0b000011001100, 12 to 0b000011001101, 12 to 0b000001101000, 12 to 0b000001101001,
        12 to 0b000001101010, 12 to 0b000001101011, 12 to 0b000011010010, 12 to 0b000011010011,
        12 to 0b000011010100, 12 to 0b000011010101, 12 to 0b000011010110, 12 to 0b000011010111,
        12 to 0b000001101100, 12 to 0b000001101101, 12 to 0b000011011010, 12 to 0b000011011011,
        12 to 0b000001010100, 12 to 0b000001010101, 12 to 0b000001010110, 12 to 0b000001010111,
        12 to 0b000001100100, 12 to 0b000001100101, 12 to 0b000001010010, 12 to 0b000001010011,
        12 to 0b000000100100, 12 to 0b000000110111, 12 to 0b000000111000, 12 to 0b000000100111,
        12 to 0b000000101000, 13 to 0b0000001011000, 13 to 0b0000001011001, 13 to 0b0000000101011,
        13 to 0b0000000101100, 13 to 0b0000001011010, 13 to 0b0000001100110, 13 to 0b0000001100111,
    )

    private val WHITE_MAKEUP = mapOf(
        64 to (5 to 0b11011), 128 to (5 to 0b10010), 192 to (6 to 0b010111),
        256 to (7 to 0b0110111), 320 to (8 to 0b00110110), 384 to (8 to 0b00110111),
        448 to (8 to 0b01100100), 512 to (8 to 0b01100101), 576 to (8 to 0b01101000),
        640 to (8 to 0b01100111), 704 to (9 to 0b011001100), 768 to (9 to 0b011001101),
        832 to (9 to 0b011010010), 896 to (9 to 0b011010011), 960 to (9 to 0b011010100),
        1024 to (9 to 0b011010101), 1088 to (9 to 0b011010110), 1152 to (9 to 0b011010111),
        1216 to (9 to 0b011011000), 1280 to (9 to 0b011011001), 1344 to (9 to 0b011011010),
        1408 to (9 to 0b011011011), 1472 to (9 to 0b010011000), 1536 to (9 to 0b010011001),
        1600 to (9 to 0b010011010), 1664 to (6 to 0b011000), 1728 to (9 to 0b010011011),
    )

    private val BLACK_MAKEUP = mapOf(
        64 to (10 to 0b0000001111), 128 to (12 to 0b000011001000), 192 to (12 to 0b000011001001),
        256 to (12 to 0b000001011011), 320 to (12 to 0b000000110011), 384 to (12 to 0b000000110100),
        448 to (12 to 0b000000110101), 512 to (13 to 0b0000001101100), 576 to (13 to 0b0000001101101),
        640 to (13 to 0b0000001001010), 704 to (13 to 0b0000001001011), 768 to (13 to 0b0000001001100),
        832 to (13 to 0b0000001001101), 896 to (13 to 0b0000001110010), 960 to (13 to 0b0000001110011),
        1024 to (13 to 0b0000001110100), 1088 to (13 to 0b0000001110101), 1152 to (13 to 0b0000001110110),
        1216 to (13 to 0b0000001110111), 1280 to (13 to 0b0000001010010), 1344 to (13 to 0b0000001010011),
        1408 to (13 to 0b0000001010100), 1472 to (13 to 0b0000001010101), 1536 to (13 to 0b0000001011010),
        1600 to (13 to 0b0000001011011), 1664 to (13 to 0b0000001100100), 1728 to (13 to 0b0000001100101),
    )

    private val EXT_MAKEUP = mapOf(
        1792 to (11 to 0b00000001000), 1856 to (11 to 0b00000001100), 1920 to (11 to 0b00000001101),
        1984 to (12 to 0b000000010010), 2048 to (12 to 0b000000010011), 2112 to (12 to 0b000000010100),
        2176 to (12 to 0b000000010101), 2240 to (12 to 0b000000010110), 2304 to (12 to 0b000000010111),
        2368 to (12 to 0b000000011100), 2432 to (12 to 0b000000011101), 2496 to (12 to 0b000000011110),
        2560 to (12 to 0b000000011111),
    )


    private class BitReader(private val data: ByteArray) {
        var pos = 0
            private set

        fun readBit(): Int {
            val byteIndex = pos / 8
            val bitIndex = 7 - (pos % 8)
            if (byteIndex >= data.size) throw IndexOutOfBoundsException("out of bits")
            val bit = (data[byteIndex].toInt() shr bitIndex) and 1
            pos++
            return bit
        }
    }

    // Mode constants
    private const val MODE_PASS = 0
    private const val MODE_HORIZONTAL = 1
    private const val MODE_V0 = 2
    private const val MODE_VR1 = 3
    private const val MODE_VL1 = 4
    private const val MODE_VR2 = 5
    private const val MODE_VL2 = 6
    private const val MODE_VR3 = 7
    private const val MODE_VL3 = 8

    private val MODE_TABLE: Map<Int, Map<Int, Int>> = mapOf(
        1 to mapOf(0b1 to MODE_V0),
        3 to mapOf(0b011 to MODE_VR1, 0b010 to MODE_VL1, 0b001 to MODE_HORIZONTAL),
        4 to mapOf(0b0001 to MODE_PASS),
        6 to mapOf(0b000011 to MODE_VR2, 0b000010 to MODE_VL2),
        7 to mapOf(0b0000011 to MODE_VR3, 0b0000010 to MODE_VL3),
    )

    private fun readMode(reader: BitReader): Int {
        var code = 0
        for (len in 1..7) {
            code = (code shl 1) or reader.readBit()
            val mode = MODE_TABLE[len]?.get(code)
            if (mode != null) return mode
        }
        error("no matching mode code found")
    }

    private fun buildRunTable(term: Array<Pair<Int, Int>>, makeup: Map<Int, Pair<Int, Int>>): Map<Int, Map<Int, Int>> {
        val byLength = HashMap<Int, MutableMap<Int, Int>>()
        term.forEachIndexed { run, pair ->
            val (length, value) = pair
            byLength.getOrPut(length) { HashMap() }[value] = run
        }
        makeup.forEach { (run, pair) ->
            val (length, value) = pair
            byLength.getOrPut(length) { HashMap() }[value] = run
        }
        return byLength
    }

    private fun buildExtTable(ext: Map<Int, Pair<Int, Int>>): Map<Int, Map<Int, Int>> {
        val byLength = HashMap<Int, MutableMap<Int, Int>>()
        ext.forEach { (run, pair) ->
            val (length, value) = pair
            byLength.getOrPut(length) { HashMap() }[value] = run
        }
        return byLength
    }

    private val WHITE_RUN_TABLE = buildRunTable(WHITE_TERM, WHITE_MAKEUP)
    private val BLACK_RUN_TABLE = buildRunTable(BLACK_TERM, BLACK_MAKEUP)
    private val EXT_RUN_TABLE = buildExtTable(EXT_MAKEUP)

    private fun decodeRunLength(reader: BitReader, table: Map<Int, Map<Int, Int>>): Int {
        var total = 0
        while (true) {
            var code = 0
            var matchedRun: Int? = null
            for (len in 1..14) {
                code = (code shl 1) or reader.readBit()
                val fromTable = table[len]?.get(code)
                if (fromTable != null) {
                    matchedRun = fromTable
                    break
                }
                val fromExt = EXT_RUN_TABLE[len]?.get(code)
                if (fromExt != null) {
                    matchedRun = fromExt
                    break
                }
            }
            val run = matchedRun ?: error("no matching MH code found")
            total += run
            if (run < 64) return total // terminating code - makeup codes are always >= 64
        }
    }

    private fun findB1B2(refChanges: IntArray, a0: Int, wantWhiteColor: Boolean, width: Int): IntArray {
        val n = refChanges.size
        var i = 0
        while (i < n && refChanges[i] <= a0) i++
        if (i < n) {
            val idxIsEven = (i % 2 == 0)
            if (idxIsEven != wantWhiteColor) i++
        }
        val b1 = if (i < n) refChanges[i] else width
        val b2 = if (i + 1 < n) refChanges[i + 1] else width
        return intArrayOf(b1, b2)
    }

    private fun verticalOffset(mode: Int): Int = when (mode) {
        MODE_V0 -> 0
        MODE_VR1 -> 1
        MODE_VR2 -> 2
        MODE_VR3 -> 3
        MODE_VL1 -> -1
        MODE_VL2 -> -2
        MODE_VL3 -> -3
        else -> error("not a vertical mode: $mode")
    }

    /**
     * Decodes [data] (a width x height Group 4 bitstream) and checks every pixel matches
     * [original] exactly. Returns false (never throws) on any mismatch, decode error, or
     * malformed input, so callers can treat it as a simple pass/fail safety gate.
     */
    fun verify(data: ByteArray, original: Bitmap): Boolean {
        val width = original.width
        val height = original.height
        return try {
            val reader = BitReader(data)
            var refChanges = IntArray(0)
            val origRow = IntArray(width)

            for (y in 0 until height) {
                val codingChanges = ArrayList<Int>()
                var a0 = -1
                var colorWhite = true
                while (a0 < width) {
                    val b = findB1B2(refChanges, a0, colorWhite, width)
                    val b1 = b[0]
                    val b2 = b[1]
                    when (val mode = readMode(reader)) {
                        MODE_PASS -> {
                            a0 = b2
                        }
                        MODE_HORIZONTAL -> {
                            val run1 = decodeRunLength(reader, if (colorWhite) WHITE_RUN_TABLE else BLACK_RUN_TABLE)
                            val start = if (a0 >= 0) a0 else 0
                            val a1 = start + run1
                            val run2 = decodeRunLength(reader, if (colorWhite) BLACK_RUN_TABLE else WHITE_RUN_TABLE)
                            val a2 = a1 + run2
                            codingChanges.add(a1)
                            codingChanges.add(a2)
                            a0 = a2
                        }
                        else -> {
                            val a1 = b1 + verticalOffset(mode)
                            codingChanges.add(a1)
                            a0 = a1
                            colorWhite = !colorWhite
                        }
                    }
                }
                refChanges = codingChanges.toIntArray()

                // Compare this decoded row directly against the source bitmap's row.
                original.getPixels(origRow, 0, width, 0, y, width, 1)
                var color = 0
                var prev = 0
                for (c in refChanges) {
                    val cClamped = if (c > width) width else c
                    for (x in prev until cClamped) {
                        val p = origRow[x]
                        val gray = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3
                        val isWhite = gray >= 128
                        val decodedWhite = (color == 0)
                        if (isWhite != decodedWhite) return false
                    }
                    prev = cClamped
                    color = 1 - color
                }
                // any pixels after the last processed run take whatever colour that run implies
                // (in practice this range is always empty - the loop above always reaches `width` -
                // but using the tracked colour instead of assuming white costs nothing and removes
                // any doubt about it).
                for (x in prev until width) {
                    val p = origRow[x]
                    val gray = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3
                    val isWhite = gray >= 128
                    val decodedWhite = (color == 0)
                    if (isWhite != decodedWhite) return false
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }
}
