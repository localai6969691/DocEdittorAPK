package com.example.docscanner.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.io.FileOutputStream

/**
 * Saved signatures: transparent PNGs in the app's private storage, newest first, at most [MAX_SAVED] kept (the
 * oldest is dropped to make room). Private storage on purpose - a signature is something nobody else's app
 * should be able to read - and `allowBackup=false` keeps it out of cloud device backups too.
 */
object SignatureStore {

    const val MAX_SAVED = 8

    private fun dir(context: Context): File =
        File(context.filesDir, "signatures").apply { if (!exists()) mkdirs() }

    fun list(context: Context): List<File> =
        dir(context).listFiles { f -> f.isFile && f.extension == "png" }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()

    /** Writes [bitmap] to a temp name first and renames, so a kill mid-write never leaves a half PNG in the list. */
    fun save(context: Context, bitmap: Bitmap): File? {
        return try {
            val d = dir(context)
            val tmp = File(d, "sig_tmp_${System.nanoTime()}.part")
            FileOutputStream(tmp).use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val target = File(d, "sig_${System.currentTimeMillis()}.png")
            if (!tmp.renameTo(target)) { tmp.delete(); return null }
            list(context).drop(MAX_SAVED).forEach { runCatching { it.delete() } }
            target
        } catch (e: Exception) {
            null
        }
    }

    fun delete(file: File) { runCatching { file.delete() } }

    fun load(file: File): Bitmap? = runCatching { BitmapFactory.decodeFile(file.absolutePath) }.getOrNull()
}
