package com.example.docscanner.util

import java.io.ByteArrayOutputStream
import java.util.Locale

/**
 * Minimal, hand-written PDF object/xref writer. Only supports what [PdfCompressor] needs: a
 * sequence of pages, each with exactly one full-page image XObject. Object numbers are assigned
 * by the caller in strict ascending order starting at 1 with no gaps, which keeps offset tracking
 * simple and unambiguous.
 */
internal class PdfByteWriter {

    private val buffer = ByteArrayOutputStream()
    private val offsets = mutableListOf<Int>() // offsets[i] = byte offset of object (i + 1)

    init {
        // The high-byte comment line is a long-standing convention that tells naive tools
        // "this file contains binary data" - harmless, and some older tools expect it.
        writeAscii("%PDF-1.4\n%\u00E2\u00E3\u00CF\u00D3\n")
    }

    private fun writeAscii(s: String) {
        buffer.write(s.toByteArray(Charsets.ISO_8859_1))
    }

    private fun writeBytes(b: ByteArray) {
        buffer.write(b)
    }

    private fun recordOffset(num: Int) {
        check(num == offsets.size + 1) { "Objects must be written in order starting at 1 (got $num, expected ${offsets.size + 1})" }
        offsets.add(buffer.size())
    }

    /** Writes a simple (non-stream) object, e.g. `<< /Type /Catalog ... >>`. */
    fun writeObject(num: Int, dict: String) {
        recordOffset(num)
        writeAscii("$num 0 obj\n$dict\nendobj\n")
    }

    /** Writes an object whose dictionary is followed by a raw binary stream (image or content stream). */
    fun writeStreamObject(num: Int, dict: String, data: ByteArray) {
        recordOffset(num)
        writeAscii("$num 0 obj\n$dict\nstream\n")
        writeBytes(data)
        writeAscii("\nendstream\nendobj\n")
    }

    /** Writes the xref table + trailer and returns the finished file bytes. Call last. */
    fun finish(catalogObjNum: Int): ByteArray {
        val xrefOffset = buffer.size()
        val count = offsets.size + 1 // +1 for the mandatory free object 0
        writeAscii("xref\n0 $count\n")
        writeAscii("0000000000 65535 f\r\n")
        for (off in offsets) {
            writeAscii(String.format(Locale.US, "%010d 00000 n\r\n", off))
        }
        writeAscii("trailer\n<< /Size $count /Root $catalogObjNum 0 R >>\nstartxref\n$xrefOffset\n%%EOF")
        return buffer.toByteArray()
    }
}
