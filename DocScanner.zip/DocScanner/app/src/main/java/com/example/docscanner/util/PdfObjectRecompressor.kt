package com.example.docscanner.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.itextpdf.io.image.ImageDataFactory
import com.itextpdf.kernel.pdf.CompressionConstants
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfName
import com.itextpdf.kernel.pdf.PdfReader
import com.itextpdf.kernel.pdf.PdfStream
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.kernel.pdf.WriterProperties
import com.itextpdf.kernel.pdf.xobject.PdfImageXObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.CRC32
import java.util.zip.Inflater

/**
 * Third compression option for the STANDALONE "Nén PDF" tool ONLY (`MainActivity`) - an
 * ADDITIONAL choice alongside the 2 existing methods in `PdfCompressor`, never a replacement.
 * The Project/Scanner flow's compress stage (`ProjectCompressActivity`) is untouched and keeps
 * using `PdfCompressor` exclusively - its source is always this app's own freshly-scanned images,
 * where this class's whole reason to exist (preserving a source PDF's own real text/vector
 * content) does not apply.
 *
 * Unlike `PdfCompressor` (which rasterizes every page to a bitmap and rebuilds the PDF from
 * scratch - see that class's own doc comment for why, and TECHNICAL_DOCS.md for the full
 * discussion), this edits the EXISTING PDF's embedded image objects directly, via iText
 * (`com.itextpdf.android:kernel-android`, AGPL - see TECHNICAL_DOCS.md for the license tradeoff
 * this accepts) - real vector text, fonts, links and bookmarks in the source PDF are left
 * completely untouched, since nothing about them is ever read or rewritten.
 *
 * ## Deliberately narrow scope - read before extending
 * Handles 2 cases, chosen because both can be decoded WITHOUT AWT and without iText's more
 * general (and, per real-world bug reports, occasionally fragile) image-decode path:
 *  1. `/DCTDecode` (plain embedded JPEG, single filter, not chained) - decoded straight via
 *     Android's `BitmapFactory` inline in [recompress]'s loop, no separate helper needed.
 *  2. `/FlateDecode` (single filter) raw raster image, 8 bits/component, `/DeviceGray` or
 *     `/DeviceRGB` - see [decodeFlateRaster]. Handles BOTH no predictor (`/DecodeParms
 *     /Predictor` absent or `1`) AND PNG-style predictor (`/Predictor` 10-15 - see
 *     [wrapAsMinimalPng] for why that whole range decodes identically, and why it's handled by
 *     reusing Android's own PNG decoder rather than a hand-written un-filter implementation).
 *     This scope (8bpc, Gray/RGB, Flate+DCT only, TIFF-style `/Predictor 2`/Indexed/CMYK still
 *     excluded) deliberately matches what other independent PDF-editing tools settle on for the
 *     same "recompress an image XObject without a full PDF-image-codec stack" problem - not an
 *     arbitrary corner cut.
 * Every other case - `/CCITTFaxDecode`, `/JBIG2Decode`, `/JPXDecode`, `/Indexed` or other
 * non-Gray/RGB color spaces, `BitsPerComponent` other than 8, `/DecodeParms /Predictor 2`
 * (TIFF-style horizontal differencing - a real, separate, unrelated algorithm this does not
 * implement), filter arrays/chains, non-`/Image` XObjects (e.g. Form XObjects) - is left
 * completely untouched. Concrete reasons, not guesses:
 *  1. iText's own recommended way to get pixels out of an image XObject,
 *     [PdfImageXObject.getBufferedImage], is implemented as `ImageIO.read(getImageBytes())` -
 *     `javax.imageio`/`java.awt.image.BufferedImage` DO NOT EXIST on Android at all (confirmed:
 *     these are desktop-JVM-only APIs; third-party Android AWT-shim libraries exist specifically
 *     because of this gap, and are explicitly disclaimed by their own authors as experimental/
 *     not-for-production). That method is NEVER called here.
 *  2. For `/DCTDecode`, [PdfImageXObject.getImageBytes] explicitly documents that filter as left
 *     as raw native bytes (never further "decoded" at the PDF level) - exactly what lets those
 *     bytes go straight into Android's own `BitmapFactory` (already used everywhere else in this
 *     app) with zero AWT involvement. For any OTHER filter, that same general decode path is a
 *     real, demonstrated source of bugs (a real bug report shows a wrong-by-1-byte size
 *     miscalculation on a FlateDecode image producing a visibly distorted, duplicated result) -
 *     not a path worth trusting blind. [decodeFlateRaster] instead does its own minimal,
 *     narrowly-scoped inflate (`java.util.zip.Inflater`, standard Java, not iText) and requires
 *     the inflated byte count to match width*height*components EXACTLY before trusting it -
 *     anything else aborts rather than risk exactly that kind of silent corruption.
 *
 * A page whose only images fall outside this scope (or that has no images at all - a text-only
 * PDF) will come back with those pages completely unchanged; only genuinely-recompressed pages
 * shrink. [recompress] reports how many images it actually touched vs skipped so the caller can
 * be honest with the user about partial coverage rather than implying the whole file was
 * optimized.
 *
 * NONE of this has run on a real device or a real build yet - see TECHNICAL_DOCS.md for the full
 * risk accounting (this is the single highest-risk piece of code in the project: an external,
 * 3-year-unreleased-but-still-real dependency, AGPL-licensed, combined with API usage grounded in
 * official docs/examples but never compiled or executed anywhere in this environment).
 */
object PdfObjectRecompressor {

    // Same quality/size bar the existing PdfCompressor already uses for color pages, so a
    // recompressed JPEG here looks like it came from the same app, not a different tool with a
    // different opinion on acceptable quality (see PdfCompressor.COLOR_PAGE_JPEG_QUALITY / _MAX_EDGE_PX).
    private const val JPEG_QUALITY = 55
    private const val MAX_EDGE_PX = 1600

    data class Result(val imagesRecompressed: Int, val imagesSkipped: Int, val pageCount: Int)

    /**
     * Opens [srcFile] for editing in place (iText "stamping" mode - the standard, well-documented
     * way to modify an existing PDF while leaving everything not explicitly touched exactly as it
     * was) and writes the result to [outFile]. Never throws for a single bad/unusual image - that
     * image is just counted as skipped and left as it was; only a fundamentally unreadable PDF
     * (can't even be opened) propagates an exception to the caller.
     */
    fun recompress(
        srcFile: File,
        outFile: File,
        onProgress: (Int, Int) -> Unit = { _, _ -> }
    ): Result {
        var recompressedCount = 0
        var skippedCount = 0
        // Full compression mode (object streams + xref streams, PDF 1.5+) and smart mode
        // (dedupe identical resource objects - e.g. the same font referenced by several pages)
        // compress the PDF's own STRUCTURE, not any one image - this is what actually answers
        // "what about the text/fonts/vector content, does that get compressed too": nothing about
        // their content is rewritten (see the class doc comment), but how the file stores them at
        // the byte level does shrink. Real iText kernel API (WriterProperties/CompressionConstants,
        // confirmed via official docs across iText 7.0-9.1, unchanged in that span) - no new
        // dependency, this is already part of `kernel-android` which the image recompression above
        // already depends on. TECHNICAL_DOCS.md has the fuller comparison against true font
        // SUBSETTING (removing already-embedded-but-unused glyphs), which is NOT available here -
        // that specific capability is gated behind iText's paid pdfOptimizer add-on, confirmed by
        // its own official feature page, not something this free dependency can do.
        val writerProps = WriterProperties()
            .setFullCompressionMode(true)
            .setCompressionLevel(CompressionConstants.BEST_COMPRESSION)
            .useSmartMode()
        val pdfDoc = PdfDocument(PdfReader(srcFile.absolutePath), PdfWriter(outFile.absolutePath, writerProps))
        try {
            val pageCount = pdfDoc.numberOfPages
            for (i in 1..pageCount) {
                onProgress(i, pageCount)
                val page = pdfDoc.getPage(i)
                val resources = page.getPdfObject().getAsDictionary(PdfName.Resources) ?: continue
                val xObjects = resources.getAsDictionary(PdfName.XObject) ?: continue
                for (key in xObjects.keySet().toList()) {
                    val stream = xObjects.getAsStream(key)
                    if (stream == null || stream.getAsName(PdfName.Subtype) != PdfName.Image) {
                        skippedCount++
                        continue
                    }
                    val filter = stream.get(PdfName.Filter)
                    val bitmap = when (filter) {
                        PdfName.DCTDecode -> runCatching {
                            val jpegBytes = PdfImageXObject(stream).getImageBytes()
                            BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size)
                        }.getOrNull()
                        PdfName.FlateDecode -> decodeFlateRaster(stream)
                        else -> null
                    }
                    if (bitmap == null) {
                        skippedCount++
                        continue
                    }
                    val recompressedBytes = runCatching {
                        val downscaled = ImageProcessor.downscaleTo(bitmap, MAX_EDGE_PX)
                        val out = ByteArrayOutputStream()
                        downscaled.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
                        if (downscaled !== bitmap) downscaled.recycle()
                        bitmap.recycle()
                        out.toByteArray()
                    }.getOrNull()

                    if (recompressedBytes == null) {
                        // Either the decode/re-encode failed, or something else went wrong - leave
                        // this one exactly as it was rather than risk a bad replacement. Whether
                        // the recompressed FILE as a whole actually ends up smaller than the
                        // original is checked once, at the whole-file level, by the caller (see
                        // MainActivity) - same rule the other 2 compression methods already
                        // follow, applied consistently here too.
                        skippedCount++
                        continue
                    }
                    val newImage = PdfImageXObject(ImageDataFactory.create(recompressedBytes))
                    xObjects.put(key, newImage.getPdfObject())
                    recompressedCount++
                }
            }
            return Result(recompressedCount, skippedCount, pageCount)
        } finally {
            pdfDoc.close()
        }
    }

    /**
     * Decodes a `/FlateDecode`, 8-bits-per-component, `/DeviceGray` or `/DeviceRGB` raw raster
     * image XObject - see the class doc comment for exactly why this narrow slice and nothing
     * more. Handles 2 sub-cases:
     *  - No predictor (`/DecodeParms /Predictor` absent or `1`): does its own inflate
     *    (`java.util.zip.Inflater`, not iText) precisely so it never touches iText's general
     *    image-decode path for this filter - see the class doc comment for the real
     *    distorted-image bug report that motivated that choice.
     *  - PNG-style predictor (`/Predictor` 10-15 - see [wrapAsMinimalPng]'s doc comment for why
     *    10-15 all decode identically): wraps the raw zlib bytes in a minimal PNG container and
     *    decodes via Android's own `BitmapFactory`, instead of hand-writing the PNG
     *    Sub/Up/Average/Paeth un-filtering algorithm with no way to test it in this environment.
     * TIFF-style predictor (`/Predictor 2`) is NOT handled - a different, unrelated algorithm
     * (horizontal differencing, not per-row-tagged like PNG's) that neither sub-case above covers.
     * Returns null (never throws) for anything outside this exact shape, including a byte-count
     * mismatch after inflating in the no-predictor case - that specific check exists because the
     * real bug report found was precisely a silent size miscalculation, not a hypothetical concern.
     */
    private fun decodeFlateRaster(stream: PdfStream): Bitmap? {
        return runCatching {
            val width = stream.getAsNumber(PdfName.Width)?.intValue() ?: return null
            val height = stream.getAsNumber(PdfName.Height)?.intValue() ?: return null
            if (width <= 0 || height <= 0) return null
            val bpc = stream.getAsNumber(PdfName.BitsPerComponent)?.intValue() ?: return null
            if (bpc != 8) return null

            val colorSpace = stream.getAsName(PdfName.ColorSpace) ?: return null
            val pngColorType = when (colorSpace) {
                PdfName.DeviceGray -> 0
                PdfName.DeviceRGB -> 2
                else -> return null
            }
            val components = if (pngColorType == 0) 1 else 3

            val decodeParms = stream.getAsDictionary(PdfName.DecodeParms)
            val predictor = decodeParms?.getAsNumber(PdfName.Predictor)?.intValue() ?: 1
            val rawDeflated = stream.getBytes(false) ?: return null

            if (predictor >= 10) {
                // Predictor's own /Columns should match the image's /Width for a well-formed
                // file (they describe the SAME row) - if a producer set it differently, don't
                // guess which one is right, just skip this image like any other unrecognized shape.
                val pngColumns = decodeParms?.getAsNumber(PdfName.Columns)?.intValue() ?: width
                if (pngColumns != width) return null
                val png = wrapAsMinimalPng(rawDeflated, width, height, pngColorType)
                BitmapFactory.decodeByteArray(png, 0, png.size)
            } else {
                if (predictor > 1) return null // TIFF-style (2) - not understood, skip rather than guess

                val expectedSize = width * height * components
                val inflated = inflate(rawDeflated, expectedSize) ?: return null
                if (inflated.size != expectedSize) return null

                val pixels = IntArray(width * height)
                if (components == 1) {
                    for (i in pixels.indices) {
                        val g = inflated[i].toInt() and 0xFF
                        pixels[i] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
                    }
                } else {
                    for (i in pixels.indices) {
                        val idx = i * 3
                        val r = inflated[idx].toInt() and 0xFF
                        val g = inflated[idx + 1].toInt() and 0xFF
                        val b = inflated[idx + 2].toInt() and 0xFF
                        pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                }
                Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
            }
        }.getOrNull()
    }

    /**
     * Wraps [zlibData] - an already-zlib-compressed byte string taken AS-IS from a PDF's
     * `/FlateDecode` stream (`/Predictor` 10-15) - as the entire IDAT payload of a minimal,
     * otherwise-empty PNG file, and returns the resulting bytes.
     *
     * Why this works and isn't a coincidence: ISO 32000 (the PDF spec) defines `/Predictor` 10-15
     * ("PNG prediction") by explicit reference to the PNG spec's own per-row adaptive filtering -
     * a 1-byte filter-type tag (None/Sub/Up/Average/Paeth) prefixing each row, the whole thing
     * zlib-compressed (RFC 1950). A PNG file's IDAT chunk contains EXACTLY this same byte layout,
     * zlib-compressed the same way. So a PDF FlateDecode+Predictor stream's raw bytes ARE already
     * valid PNG IDAT content, byte for byte, with no conversion needed - only a PNG container
     * (signature + IHDR + this IDAT + IEND) needs to be built around them. The `/Predictor` value
     * itself (10-15) only documents which per-row heuristic the ENCODER claims to have used to
     * pick each row's filter type - irrelevant to decoding, since the decoder always just reads
     * whatever filter-type byte each row actually starts with and un-filters accordingly,
     * regardless of what the encoder's chosen strategy was. This is why 10-15 all decode
     * identically here (single code path, no `when` on the exact value).
     *
     * Handing this to Android's own `BitmapFactory` means the actual Sub/Up/Average/Paeth
     * un-filtering math - real, fiddly, per-pixel-neighbor logic - runs inside Android's own
     * already-shipped, already-battle-tested PNG decoder, not a hand-written reimplementation that
     * this environment has no way to test (no Android device, no way to render and visually check
     * a single pixel). Building the ~40-byte chunk wrapper around already-correct, unmodified
     * image bytes is a much smaller, more mechanical, more independently-checkable piece of code
     * than reimplementing PNG's own un-filtering algorithm would be.
     */
    private fun wrapAsMinimalPng(zlibData: ByteArray, width: Int, height: Int, colorType: Int): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)) // PNG signature
        fun be32(v: Int) = byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte())
        fun writeChunk(type: String, payload: ByteArray) {
            out.write(be32(payload.size))
            val typeBytes = type.toByteArray(Charsets.US_ASCII)
            out.write(typeBytes)
            out.write(payload)
            val crc = CRC32()
            crc.update(typeBytes)
            crc.update(payload)
            out.write(be32(crc.value.toInt()))
        }
        val ihdr = ByteArrayOutputStream().apply {
            write(be32(width))
            write(be32(height))
            write(8) // bit depth - matches this class's existing 8-bits-per-component-only scope
            write(colorType) // 0 = grayscale, 2 = truecolor(RGB) - the only 2 values this class ever passes in
            write(0) // compression method - always 0 per PNG spec
            write(0) // filter method - always 0 (per-row adaptive filtering, as tagged in the data itself)
            write(0) // interlace method - none (PDF predictor data is never interlaced)
        }.toByteArray()
        writeChunk("IHDR", ihdr)
        writeChunk("IDAT", zlibData)
        writeChunk("IEND", ByteArray(0))
        return out.toByteArray()
    }

    /** Plain zlib inflate via the standard Java API (available on Android, no new dependency) -
     *  [expectedSize] is just a sane upper bound for the output buffer, not trusted for anything
     *  beyond that; the caller independently re-checks the actual inflated size matches exactly. */
    private fun inflate(deflated: ByteArray, expectedSize: Int): ByteArray? {
        return runCatching {
            val inflater = Inflater()
            inflater.setInput(deflated)
            val out = ByteArrayOutputStream(expectedSize.coerceAtLeast(64))
            val buf = ByteArray(8192)
            while (!inflater.finished()) {
                val n = inflater.inflate(buf)
                if (n == 0) {
                    if (inflater.needsInput() || inflater.needsDictionary()) break
                }
                out.write(buf, 0, n)
            }
            inflater.end()
            out.toByteArray()
        }.getOrNull()
    }
}
