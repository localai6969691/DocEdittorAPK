package com.example.docscanner.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.tom_roush.pdfbox.cos.COSBase
import com.tom_roush.pdfbox.cos.COSDictionary
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSNumber
import com.tom_roush.pdfbox.cos.COSStream
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Collections
import java.util.IdentityHashMap
import java.util.zip.CRC32
import java.util.zip.Inflater

/**
 * Third compression option for the STANDALONE "Nén PDF" tool ONLY (`MainActivity`) - an ADDITIONAL
 * choice alongside the 2 methods in `PdfCompressor`, never a replacement. The Project/Scanner
 * flow's compress stage keeps using `PdfCompressor` exclusively.
 *
 * Unlike `PdfCompressor` (which rasterizes every page and rebuilds the PDF), this edits the EXISTING
 * PDF's embedded image objects in place - real vector text, fonts, links and bookmarks are never
 * read or rewritten.
 *
 * ## Engine: PdfBox-Android (Apache 2.0), NOT iText (phiên 11)
 * iText 7 is AGPL / paid-commercial and cannot ship in a paid Play app without a yearly licence, so
 * it was replaced by PdfBox-Android (free for commercial use). Behavioural differences vs the iText
 * version, all deliberate:
 *  - Images are rewritten IN PLACE at the COS level (`COSStream` raw bytes + dictionary keys) - the
 *    old code built a fresh image XObject, which silently dropped `/SMask`, `/Mask`, `/Decode`.
 *    Now images carrying `/ImageMask`, `/Mask` or `/Decode` are SKIPPED (their meaning depends on
 *    the original pixel data) and `/SMask` is left untouched (soft masks may differ in size).
 *  - An image shared by several pages is recompressed ONCE (identity set) - re-encoding the same
 *    JPEG once per page would stack generation loss.
 *  - Structure compression (iText's "full compression mode" + "smart mode") is re-created by
 *    [PdfStructureOptimizer]: object streams + xref stream + Flate for unfiltered streams +
 *    merging of byte-identical streams, written from the PDF spec and only kept if
 *    [PdfVerify.sameAsDocument] passes. NOT possible without a paid product: true font SUBSETTING of
 *    fonts already embedded in the source PDF (iText's pdfOptimizer add-on) - not attempted.
 *
 * ## Deliberately narrow scope (unchanged)
 *  1. `/DCTDecode` (single filter): raw JPEG bytes -> Android `BitmapFactory`.
 *  2. `/FlateDecode` (single filter), 8 bits/component, `/DeviceGray` or `/DeviceRGB`: see
 *     [decodeFlateRaster] - no predictor via `java.util.zip.Inflater` with an EXACT byte-count
 *     check, PNG predictor (10-15) by wrapping the bytes in a minimal PNG for Android's own decoder
 *     ([wrapAsMinimalPng]). TIFF predictor 2, Indexed/CMYK, other bit depths, CCITT/JBIG2/JPX,
 *     filter chains and Form XObjects are left untouched.
 * The result reports how many images were touched vs skipped so the caller can be honest about
 * partial coverage.
 *
 * NOT run on a real device yet - see TECHNICAL_DOCS.md, "Bảng mức tin cậy API PdfBox".
 */
object PdfObjectRecompressor {

    // Same quality/size bar the existing PdfCompressor uses for color pages.
    private const val JPEG_QUALITY = 55
    private const val MAX_EDGE_PX = 1600

    data class Result(
        val imagesRecompressed: Int,
        val imagesSkipped: Int,
        val pageCount: Int,
        /** true when the extra structure pass (object streams, de-duplication) was verified and used */
        val structureOptimized: Boolean = false
    )

    private val DCT = COSName.getPDFName("DCTDecode")
    private val FLATE = COSName.getPDFName("FlateDecode")
    private val N_XOBJECT = COSName.getPDFName("XObject")
    private val N_SUBTYPE = COSName.getPDFName("Subtype")
    private val N_IMAGE = COSName.getPDFName("Image")
    private val N_FILTER = COSName.getPDFName("Filter")
    private val N_WIDTH = COSName.getPDFName("Width")
    private val N_HEIGHT = COSName.getPDFName("Height")
    private val N_BPC = COSName.getPDFName("BitsPerComponent")
    private val N_COLORSPACE = COSName.getPDFName("ColorSpace")
    private val N_DECODE_PARMS = COSName.getPDFName("DecodeParms")
    private val N_DECODE = COSName.getPDFName("Decode")
    private val N_MASK = COSName.getPDFName("Mask")
    private val N_IMAGE_MASK = COSName.getPDFName("ImageMask")
    private val N_PREDICTOR = COSName.getPDFName("Predictor")
    private val N_COLUMNS = COSName.getPDFName("Columns")
    private val N_DEVICE_GRAY = COSName.getPDFName("DeviceGray")
    private val N_DEVICE_RGB = COSName.getPDFName("DeviceRGB")

    /**
     * Opens [srcFile], recompresses the supported embedded images in place and saves to [outFile].
     * Never throws for one bad/unusual image (counted as skipped); only a fundamentally unreadable
     * PDF propagates an exception. Encrypted PDFs that don't grant modify permission are refused.
     */
    fun recompress(
        srcFile: File,
        outFile: File,
        onProgress: (Int, Int) -> Unit = { _, _ -> }
    ): Result {
        var recompressedCount = 0
        var skippedCount = 0
        // PdfBox keeps a whole document in the Java heap by default (iText streamed lazily). Mixed mode
        // keeps up to 24 MB of stream data in RAM and spills the rest to a scratch file next to the
        // source (the app's own cache dir) - the main protection against OutOfMemoryError on big scans.
        val memory = MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(srcFile.parentFile)
        val doc = PDDocument.load(srcFile, memory)
        try {
            if (doc.isEncrypted && !doc.currentAccessPermission.canModify()) {
                throw SecurityException("PDF does not permit modification")
            }
            val pageCount = doc.numberOfPages
            val handled: MutableSet<COSBase> = Collections.newSetFromMap(IdentityHashMap<COSBase, Boolean>())
            for (i in 1..pageCount) {
                onProgress(i, pageCount)
                val resources = doc.getPage(i - 1).resources ?: continue
                val xObjects = resources.cosObject.getDictionaryObject(N_XOBJECT) as? COSDictionary ?: continue
                for (key in xObjects.keySet().toList()) {
                    val obj = xObjects.getDictionaryObject(key)
                    if (obj !is COSStream || obj.getCOSName(N_SUBTYPE) != N_IMAGE) {
                        skippedCount++ // Form XObjects etc.
                        continue
                    }
                    if (!handled.add(obj)) continue // already processed via another page
                    if (recompressImage(obj)) recompressedCount++ else skippedCount++
                }
            }
            // Plain PdfBox save first, then the verified structure pass (PdfStructureOptimizer) which
            // only replaces it if the result opens in an independent reader and is really smaller.
            val outcome = PdfStructureOptimizer.save(doc, outFile)
            return Result(recompressedCount, skippedCount, pageCount, outcome.optimizedUsed)
        } finally {
            runCatching { doc.close() }
        }
    }

    /** Recompresses one image stream in place. Returns false (image left EXACTLY as it was) for
     *  anything outside the supported scope or on any error. */
    private fun recompressImage(stream: COSStream): Boolean {
        return try {
            if (stream.getBoolean(N_IMAGE_MASK, false)) return false
            if (stream.containsKey(N_MASK) || stream.containsKey(N_DECODE)) return false

            val originalSize = stream.createRawInputStream().use { input ->
                var total = 0L
                val chunk = ByteArray(8192)
                while (true) {
                    val n = input.read(chunk)
                    if (n < 0) break
                    total += n
                }
                total
            }
            val filter = stream.getDictionaryObject(N_FILTER)
            val bitmap: Bitmap = when (filter) {
                DCT -> {
                    val jpeg = stream.createRawInputStream().use { it.readBytes() }
                    BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size)
                }
                FLATE -> decodeFlateRaster(stream)
                else -> null
            } ?: return false

            val downscaled = ImageProcessor.downscaleTo(bitmap, MAX_EDGE_PX)
            val out = ByteArrayOutputStream()
            downscaled.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)
            val newW = downscaled.width
            val newH = downscaled.height
            if (downscaled !== bitmap) downscaled.recycle()
            bitmap.recycle()
            val jpegBytes = out.toByteArray()
            // A lossy re-encode that is not even smaller would only add generation loss - keep the original.
            if (jpegBytes.isEmpty() || jpegBytes.size >= originalSize) return false

            // Write the new payload first; only then change the dictionary, so a failure while
            // writing cannot leave a half-converted image behind.
            stream.createRawOutputStream().use { it.write(jpegBytes) }
            stream.setItem(N_FILTER, DCT)
            stream.removeItem(N_DECODE_PARMS)
            stream.setInt(N_WIDTH, newW)
            stream.setInt(N_HEIGHT, newH)
            stream.setInt(N_BPC, 8)
            // Android's JPEG encoder always writes 3-component YCbCr, even from a gray bitmap.
            stream.setItem(N_COLORSPACE, N_DEVICE_RGB)
            true
        } catch (e: Throwable) {
            false
        }
    }

    /**
     * Decodes a `/FlateDecode`, 8-bits-per-component, `/DeviceGray` or `/DeviceRGB` raw raster image
     * (no predictor via [Inflater] + exact-size check; PNG predictor 10-15 via [wrapAsMinimalPng]).
     * Returns null (never throws) for anything outside that exact shape.
     */
    private fun decodeFlateRaster(stream: COSStream): Bitmap? {
        return runCatching {
            val width = (stream.getDictionaryObject(N_WIDTH) as? COSNumber)?.intValue() ?: return null
            val height = (stream.getDictionaryObject(N_HEIGHT) as? COSNumber)?.intValue() ?: return null
            if (width <= 0 || height <= 0) return null
            val bpc = (stream.getDictionaryObject(N_BPC) as? COSNumber)?.intValue() ?: return null
            if (bpc != 8) return null

            val pngColorType = when (stream.getDictionaryObject(N_COLORSPACE)) {
                N_DEVICE_GRAY -> 0
                N_DEVICE_RGB -> 2
                else -> return null
            }
            val components = if (pngColorType == 0) 1 else 3

            val decodeParms = stream.getDictionaryObject(N_DECODE_PARMS) as? COSDictionary
            val predictor = (decodeParms?.getDictionaryObject(N_PREDICTOR) as? COSNumber)?.intValue() ?: 1
            val rawDeflated = stream.createRawInputStream().use { it.readBytes() }

            if (predictor >= 10) {
                // Predictor /Columns must equal the image /Width (same row) - otherwise don't guess.
                val pngColumns = (decodeParms?.getDictionaryObject(N_COLUMNS) as? COSNumber)?.intValue() ?: width
                if (pngColumns != width) return null
                val png = wrapAsMinimalPng(rawDeflated, width, height, pngColorType)
                BitmapFactory.decodeByteArray(png, 0, png.size)
            } else {
                if (predictor > 1) return null // TIFF-style (2) - not understood, skip rather than guess

                val expectedSize = width * height * components
                val inflated = inflate(rawDeflated, expectedSize) ?: return null
                if (inflated.size != expectedSize) return null

                val pixels = IntArray(width * height)
                if (components == 1) {
                    for (i in pixels.indices) {
                        val g = inflated[i].toInt() and 0xFF
                        pixels[i] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
                    }
                } else {
                    for (i in pixels.indices) {
                        val idx = i * 3
                        val r = inflated[idx].toInt() and 0xFF
                        val g = inflated[idx + 1].toInt() and 0xFF
                        val b = inflated[idx + 2].toInt() and 0xFF
                        pixels[i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                }
                Bitmap.createBitmap(pixels, width, height, Bitmap.Config.ARGB_8888)
            }
        }.getOrNull()
    }

    /**
     * Wraps [zlibData] - the zlib bytes of a PDF `/FlateDecode` stream with `/Predictor` 10-15 - as the
     * IDAT payload of a minimal PNG. ISO 32000 defines predictors 10-15 by reference to PNG's own
     * per-row filtering (1 tag byte per row, whole thing zlib-compressed), so those bytes ARE already
     * valid IDAT content; only the PNG container (signature + IHDR + IDAT + IEND) is built around
     * them, and Android's own PNG decoder does the Sub/Up/Average/Paeth un-filtering. The exact
     * predictor value (10-15) only hints at the ENCODER's row-filter strategy and does not change
     * decoding, so one code path covers all of them.
     */
    private fun wrapAsMinimalPng(zlibData: ByteArray, width: Int, height: Int, colorType: Int): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)) // PNG signature
        fun be32(v: Int) = byteArrayOf((v ushr 24).toByte(), (v ushr 16).toByte(), (v ushr 8).toByte(), v.toByte())
        fun writeChunk(type: String, payload: ByteArray) {
            out.write(be32(payload.size))
            val typeBytes = type.toByteArray(Charsets.US_ASCII)
            out.write(typeBytes)
            out.write(payload)
            val crc = CRC32()
            crc.update(typeBytes)
            crc.update(payload)
            out.write(be32(crc.value.toInt()))
        }
        val ihdr = ByteArrayOutputStream().apply {
            write(be32(width))
            write(be32(height))
            write(8) // bit depth
            write(colorType) // 0 = grayscale, 2 = truecolor(RGB)
            write(0) // compression method
            write(0) // filter method (per-row adaptive, tagged in the data itself)
            write(0) // interlace: none
        }.toByteArray()
        writeChunk("IHDR", ihdr)
        writeChunk("IDAT", zlibData)
        writeChunk("IEND", ByteArray(0))
        return out.toByteArray()
    }

    /** Plain zlib inflate via the standard Java API. [expectedSize] is only a buffer hint; the
     *  caller re-checks the real inflated size. */
    private fun inflate(deflated: ByteArray, expectedSize: Int): ByteArray? {
        return runCatching {
            val inflater = Inflater()
            inflater.setInput(deflated)
            val out = ByteArrayOutputStream(expectedSize.coerceAtLeast(64))
            val buf = ByteArray(8192)
            while (!inflater.finished()) {
                val n = inflater.inflate(buf)
                if (n == 0) {
                    if (inflater.needsInput() || inflater.needsDictionary()) break
                }
                out.write(buf, 0, n)
            }
            inflater.end()
            out.toByteArray()
        }.getOrNull()
    }
}
