package com.example.docscanner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.example.docscanner.databinding.ActivityCaptureBinding
import com.example.docscanner.model.ProjectManager
import com.example.docscanner.model.ScanSessionManager
import com.example.docscanner.util.FileUtils

/**
 * Camera screen: lets the user shoot as many pages as they want, one at a time.
 *
 * Runs in one of two modes, chosen by whether [ProjectFlow.EXTRA_PROJECT_ID] is present in the
 * launch intent:
 *  - Normal mode (no project id): the original standalone "Quét" flow - every shot goes straight
 *    into [CropActivity] (single-shot mode) for corner adjustment + filter, then control returns
 *    here so the loop can continue until the user taps "Xong, xem lại".
 *  - Project mode (project id present, see `ProjectPickImagesActivity`): shots are only ever
 *    *picked* here, matching that stage's job - crop/split happens later, together, in
 *    `ProjectEditActivity`. Each shot is appended straight to the project's
 *    `Project.pendingRawPaths` and persisted immediately, no per-shot detour.
 */
class CaptureActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCaptureBinding
    private var imageCapture: ImageCapture? = null
    private var flashOn = false
    private var projectId: String? = null

    private val cropLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            updatePageCount()
        }

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else finish()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCaptureBinding.inflate(layoutInflater)
        setContentView(binding.root)

        projectId = intent.getStringExtra(ProjectFlow.EXTRA_PROJECT_ID)

        binding.btnClose.setOnClickListener { finish() }
        binding.btnFlash.setOnClickListener { toggleFlash() }
        binding.btnShutter.setOnClickListener { takePhoto() }
        binding.btnDoneCapturing.setOnClickListener { finishCapturing() }

        updatePageCount()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }
            val capture = ImageCapture.Builder()
                .setFlashMode(if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF)
                .build()
            imageCapture = capture
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, capture)
            } catch (e: Exception) {
                Log.e(TAG, "Camera bind failed", e)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun toggleFlash() {
        flashOn = !flashOn
        imageCapture?.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
    }

    private fun takePhoto() {
        val capture = imageCapture ?: return
        val pid = projectId
        val file = if (pid != null) {
            val project = ProjectManager.load(this, pid) ?: return
            FileUtils.newProjectRawFile(this, pid, project.pendingRawPaths.size)
        } else {
            FileUtils.newCaptureFile(this)
        }
        val outputOptions = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    if (pid != null) {
                        val project = ProjectManager.load(this@CaptureActivity, pid) ?: return
                        project.pendingRawPaths.add(file.absolutePath)
                        ProjectManager.save(this@CaptureActivity, project)
                        updatePageCount()
                    } else {
                        val intent = Intent(this@CaptureActivity, CropActivity::class.java).apply {
                            putExtra(CropActivity.EXTRA_IMAGE_PATH, file.absolutePath)
                            putExtra(CropActivity.EXTRA_QUEUE_MODE, false)
                        }
                        cropLauncher.launch(intent)
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    Log.e(TAG, "Capture failed", exception)
                }
            }
        )
    }

    private fun updatePageCount() {
        val pid = projectId
        val count = if (pid != null) {
            ProjectManager.load(this, pid)?.pendingRawPaths?.size ?: 0
        } else {
            ScanSessionManager.pages.size
        }
        binding.tvPageCount.text = getString(R.string.pages_captured_count, count)
        binding.btnDoneCapturing.visibility = if (count > 0) View.VISIBLE else View.GONE
    }

    private fun finishCapturing() {
        val pid = projectId
        if (pid != null) {
            // Nothing more to do here - ProjectPickImagesActivity (still on the back stack)
            // reloads the project and refreshes its own count/button in onResume.
            finish()
        } else {
            startActivity(Intent(this, PageListActivity::class.java))
            finish()
        }
    }

    companion object {
        private const val TAG = "CaptureActivity"
    }
}
