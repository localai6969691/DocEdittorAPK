package com.example.docscanner

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.docscanner.adapter.TocEntryAdapter
import com.example.docscanner.databinding.ActivityProjectExportPdfBinding
import com.example.docscanner.model.Project
import com.example.docscanner.model.ProjectManager
import com.example.docscanner.model.ProjectStage
import com.example.docscanner.model.ProjectTocEntry
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.TocDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Project stage 5: export the working pages to a PDF. Table of contents is an OPTIONAL choice
 * within this mandatory stage (per the described workflow: "có lựa chọn tạo mục lục") - if the
 * user opts in, [TocDetector] proposes entries from the book's own contents page, shown here for
 * review/edit ([TocEntryAdapter]) before anything is written; the reviewed entries become real
 * PDF bookmarks via [PdfExporter]'s [com.example.docscanner.util.PdfBookmarkInjector] pass.
 */
class ProjectExportPdfActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProjectExportPdfBinding
    private lateinit var project: Project
    private lateinit var tocAdapter: TocEntryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProjectExportPdfBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val projectId = intent.getStringExtra(ProjectFlow.EXTRA_PROJECT_ID)
        val loaded = projectId?.let { ProjectManager.load(this, it) }
        if (loaded == null) {
            finish()
            return
        }
        project = loaded
        title = project.name
        binding.tvStageIndicator.text = getString(R.string.project_stage_indicator_4)

        tocAdapter = TocEntryAdapter(
            pageCount = project.pages.size,
            onChanged = { persistToc() },
            onDelete = { updateEmptyTocVisibility() }
        )
        binding.rvTocEntries.layoutManager = LinearLayoutManager(this)
        binding.rvTocEntries.adapter = tocAdapter
        tocAdapter.submitList(project.tocEntries)

        binding.switchWantToc.isChecked = project.wantToc
        applyTocVisibility(project.wantToc)
        if (project.wantToc && project.tocEntries.isEmpty()) {
            runAutoDetect()
        } else {
            updateEmptyTocVisibility()
        }

        binding.switchWantToc.setOnCheckedChangeListener { _, checked ->
            project.wantToc = checked
            applyTocVisibility(checked)
            if (checked && tocAdapter.currentList().isEmpty()) {
                runAutoDetect() // ends with persistToc() itself
            } else {
                updateEmptyTocVisibility()
                persistToc() // make sure the on/off choice itself is saved even with no entries to touch
            }
        }
        binding.btnAddTocEntry.setOnClickListener {
            val list = tocAdapter.currentList().toMutableList()
            list.add(ProjectTocEntry(title = "", pageIndex = 0))
            tocAdapter.submitList(list)
            updateEmptyTocVisibility()
            persistToc()
        }
        binding.btnExportPdf.setOnClickListener { exportPdf() }
    }

    private fun applyTocVisibility(wantToc: Boolean) {
        binding.tvTocHint.visibility = if (wantToc) View.VISIBLE else View.GONE
        binding.rvTocEntries.visibility = if (wantToc) View.VISIBLE else View.GONE
        binding.btnAddTocEntry.visibility = if (wantToc) View.VISIBLE else View.GONE
        if (!wantToc) binding.tvEmptyToc.visibility = View.GONE
    }

    private fun updateEmptyTocVisibility() {
        if (!project.wantToc) return
        binding.tvEmptyToc.visibility = if (tocAdapter.currentList().isEmpty()) View.VISIBLE else View.GONE
    }

    private fun persistToc() {
        project.tocEntries = tocAdapter.currentList().toMutableList()
        ProjectManager.save(this, project)
    }

    private fun runAutoDetect() {
        binding.progressBar.visibility = View.VISIBLE
        binding.tvProgress.visibility = View.VISIBLE
        binding.tvProgress.text = getString(R.string.project_toc_detecting)
        lifecycleScope.launch {
            val detected = withContext(Dispatchers.Default) {
                TocDetector.detect(project.pages.map { it.path })
            }
            binding.progressBar.visibility = View.GONE
            binding.tvProgress.visibility = View.GONE
            tocAdapter.submitList(detected)
            updateEmptyTocVisibility()
            persistToc()
        }
    }

    private fun exportPdf() {
        val pages = project.pages
        if (pages.isEmpty()) return
        val entries = if (project.wantToc) {
            tocAdapter.currentList().filter { it.title.isNotBlank() }
        } else {
            emptyList()
        }
        binding.progressBar.visibility = View.VISIBLE
        binding.tvProgress.visibility = View.VISIBLE
        binding.tvProgress.text = getString(R.string.project_exporting_pdf)
        binding.btnExportPdf.isEnabled = false
        lifecycleScope.launch {
            val pdfFile = withContext(Dispatchers.Default) {
                PdfExporter.exportImagePaths(
                    context = this@ProjectExportPdfActivity,
                    imagePaths = pages.map { it.path },
                    rotations = pages.map { it.rotationDeg },
                    baseName = FileUtils.defaultDocName(),
                    chapterTitles = entries.map { it.title },
                    chapterStartPageIndex = entries.map { it.pageIndex }
                )
            }
            project.pdfPath = pdfFile.absolutePath
            project.tocEntries = entries.toMutableList()
            project.stage = ProjectStage.COMPRESS
            ProjectManager.save(this@ProjectExportPdfActivity, project)
            Toast.makeText(
                this@ProjectExportPdfActivity,
                getString(R.string.export_success, pdfFile.name),
                Toast.LENGTH_SHORT
            ).show()
            ProjectFlow.open(this@ProjectExportPdfActivity, project)
            finish()
        }
    }
}
