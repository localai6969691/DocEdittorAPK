package com.example.docscanner.model

import android.content.Context
import com.example.docscanner.util.FileUtils
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Persists the in-progress state of [com.example.docscanner.PdfTextEditActivity] - the durable
 * copy of the source PDF being edited, plus every edit successfully applied so far (page number,
 * chunk index, replacement text) - so a session killed mid-work can be resumed.
 *
 * **Why replay-from-source, not resume-from-output** (different from every other `model.*State`
 * in this app, which just reopens a saved working file directly): a PdfBox
 * `PDDocument` holds the entire edited document in memory and only serializes it to disk at
 * `save()` - a process killed mid-session leaves NO output at all, not a valid partial PDF that
 * could simply be reopened and continued. Re-deriving from the source
 * plus a recorded edit list sidesteps that: [com.example.docscanner.util.PdfTextEditor.applyEdit]
 * is deterministic given the same source bytes and the same chunk index, so replaying the exact
 * same edits in the exact same order against a freshly-opened copy of the source reproduces
 * exactly what the person had built up before the process died - see
 * [com.example.docscanner.PdfTextEditActivity]'s own doc comment for how this gets wired in.
 *
 * The source copy lives in [com.example.docscanner.util.FileUtils.textEditSourceDir] - *files*
 * storage, not cache, same reasoning as [PdfEditorState] - and [clear] deletes it too, since
 * nothing else references that copy once the session is done (saved) or abandoned (discarded).
 */
object PdfTextEditState {

    data class AppliedEdit(val pageNumber: Int, val chunkIndex: Int, val newText: String)
    data class SavedState(val sourcePath: String, val edits: List<AppliedEdit>)

    private fun stateFile(context: Context): File = File(FileUtils.textEditSourceDir(context), "text_edit_state.json")

    fun persist(context: Context, sourcePath: String, edits: List<AppliedEdit>) {
        val file = stateFile(context)
        try {
            val arr = JSONArray()
            edits.forEach { e ->
                arr.put(
                    JSONObject()
                        .put("page", e.pageNumber)
                        .put("chunk", e.chunkIndex)
                        .put("text", e.newText)
                )
            }
            val root = JSONObject().put("source", sourcePath).put("edits", arr)
            file.writeText(root.toString())
        } catch (e: Exception) {
            // Best-effort only - a failed save just means nothing to restore later, never crash over it.
        }
    }

    /** Loads the saved state, or null if there is nothing usable to restore (never saved, or the
     *  source copy it points at no longer exists on disk). */
    fun restore(context: Context): SavedState? {
        val file = stateFile(context)
        if (!file.exists()) return null
        return try {
            val root = JSONObject(file.readText())
            val sourcePath = root.optString("source")
            if (sourcePath.isBlank() || !File(sourcePath).exists()) return null
            val arr = root.optJSONArray("edits") ?: JSONArray()
            val edits = (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                AppliedEdit(obj.optInt("page", 1), obj.optInt("chunk", 0), obj.optString("text"))
            }
            SavedState(sourcePath, edits)
        } catch (e: Exception) {
            null
        }
    }

    /** Discards the saved state on disk AND the durable source copy it points at - safe to call
     *  even if nothing was ever saved for this tool. */
    fun clear(context: Context) {
        val file = stateFile(context)
        runCatching {
            if (file.exists()) {
                val sourcePath = JSONObject(file.readText()).optString("source")
                if (sourcePath.isNotBlank()) File(sourcePath).delete()
            }
        }
        runCatching { file.delete() }
    }
}
