package com.example.docscanner.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Persists the in-progress state of [com.example.docscanner.PdfPageEditorActivity] - which
 * pages are loaded, their current order, rotation and selection - so a rotate/delete/reorder
 * session survives the process being killed while the user is mid-edit. Same reasoning and same
 * disk-backed-JSON pattern as [ScanSessionManager]'s backup/restore; see TECHNICAL_DOCS.md.
 *
 * Only meaningful together with [com.example.docscanner.util.FileUtils.pdfEditorPagesDir] -
 * the rendered page files themselves must live there (internal *files* storage, not cache) for
 * a restore to actually find them again; a path into the OS-clearable cache dir would make this
 * silently fail.
 *
 * [init] must be called once (from [com.example.docscanner.DocScannerApp.onCreate]) before
 * persistence works, same as [ScanSessionManager.init].
 */
object PdfEditorState {

    data class SavedPage(val path: String, val rotationDeg: Int, val selected: Boolean)

    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    private fun stateFile(): File? = appContext?.let { File(it.filesDir, "pdf_editor_state.json") }

    fun persist(pages: List<SavedPage>) {
        val file = stateFile() ?: return
        try {
            val arr = JSONArray()
            pages.forEach { p ->
                arr.put(
                    JSONObject()
                        .put("path", p.path)
                        .put("rotation", p.rotationDeg)
                        .put("selected", p.selected)
                )
            }
            file.writeText(arr.toString())
        } catch (e: Exception) {
            // Best-effort only - a failed save just means nothing to restore later, never crash over it.
        }
    }

    fun savedPageCount(): Int {
        val file = stateFile() ?: return 0
        if (!file.exists()) return 0
        return try {
            JSONArray(file.readText()).length()
        } catch (e: Exception) {
            0
        }
    }

    fun hasSaved(): Boolean = savedPageCount() > 0

    /** Loads the saved state, dropping any page whose file no longer exists on disk (should be
     *  rare given [com.example.docscanner.util.FileUtils.pdfEditorPagesDir] is durable, but
     *  never trust a path from disk without checking). */
    fun restore(): List<SavedPage> {
        val file = stateFile() ?: return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).mapNotNull { i ->
                val obj = arr.getJSONObject(i)
                val path = obj.optString("path")
                if (path.isNotBlank() && File(path).exists()) {
                    SavedPage(path, obj.optInt("rotation", 0), obj.optBoolean("selected", false))
                } else null
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    /** Discards the saved state on disk, deleting the page files it referenced too - they live
     *  in a dedicated durable dir just for this editor session, nothing else points at them. */
    fun clear() {
        val file = stateFile() ?: return
        try {
            val arr = JSONArray(file.readText())
            for (i in 0 until arr.length()) {
                val path = arr.getJSONObject(i).optString("path")
                if (path.isNotBlank()) runCatching { File(path).delete() }
            }
        } catch (e: Exception) {
            // ignore - best effort cleanup
        }
        runCatching { file.delete() }
    }
}
