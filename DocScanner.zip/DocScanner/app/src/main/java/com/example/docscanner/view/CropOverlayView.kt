package com.example.docscanner.view

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat
import com.example.docscanner.R
import com.example.docscanner.util.ImageProcessor
import kotlin.math.hypot
import org.opencv.core.Point as CvPoint

/**
 * Shows [bitmap] scaled to fit the view, with a draggable quadrilateral overlaid on top so the
 * user can correct the auto-detected document corners before the perspective warp is applied.
 * All corner storage/math happens in BITMAP pixel space; screen <-> bitmap conversion is done
 * through [bitmapToView] / [viewToBitmap] so touch handling stays correct at any view size.
 */
class CropOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var bitmap: Bitmap? = null

    // Corners in bitmap pixel space, order: TL, TR, BR, BL
    private val corners = arrayOf(PointF(), PointF(), PointF(), PointF())

    private val bitmapToView = Matrix()
    private val viewToBitmap = Matrix()
    private var activeCorner = -1

    private val touchSlopPx = resources.displayMetrics.density * 28f
    private val handleRadiusPx = resources.displayMetrics.density * 9f

    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.overlay_line)
        style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density * 2.5f
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.overlay_fill)
        style = Paint.Style.FILL
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.overlay_handle)
        style = Paint.Style.FILL
    }
    private val handleStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = ContextCompat.getColor(context, R.color.overlay_line)
        style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density * 2f
    }

    fun setImage(bmp: Bitmap, quad: ImageProcessor.Quad) {
        bitmap = bmp
        corners[0].set(quad.tl.x.toFloat(), quad.tl.y.toFloat())
        corners[1].set(quad.tr.x.toFloat(), quad.tr.y.toFloat())
        corners[2].set(quad.br.x.toFloat(), quad.br.y.toFloat())
        corners[3].set(quad.bl.x.toFloat(), quad.bl.y.toFloat())
        recomputeMatrix()
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        recomputeMatrix()
    }

    private fun recomputeMatrix() {
        val bmp = bitmap ?: return
        if (width == 0 || height == 0) return
        val scale = minOf(width.toFloat() / bmp.width, height.toFloat() / bmp.height)
        val dx = (width - bmp.width * scale) / 2f
        val dy = (height - bmp.height * scale) / 2f
        bitmapToView.reset()
        bitmapToView.postScale(scale, scale)
        bitmapToView.postTranslate(dx, dy)
        bitmapToView.invert(viewToBitmap)
    }

    private fun mapPoint(matrix: Matrix, p: PointF): PointF {
        val arr = floatArrayOf(p.x, p.y)
        matrix.mapPoints(arr)
        return PointF(arr[0], arr[1])
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val bmp = bitmap ?: return
        canvas.drawBitmap(bmp, bitmapToView, bitmapPaint)

        val viewPts = corners.map { mapPoint(bitmapToView, it) }

        val path = Path()
        path.moveTo(viewPts[0].x, viewPts[0].y)
        for (i in 1..3) path.lineTo(viewPts[i].x, viewPts[i].y)
        path.close()
        canvas.drawPath(path, fillPaint)
        canvas.drawPath(path, linePaint)

        for (p in viewPts) {
            canvas.drawCircle(p.x, p.y, handleRadiusPx, handlePaint)
            canvas.drawCircle(p.x, p.y, handleRadiusPx, handleStrokePaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val bmp = bitmap ?: return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val viewPts = corners.map { mapPoint(bitmapToView, it) }
                var closestIndex = -1
                var closestDist = Float.MAX_VALUE
                viewPts.forEachIndexed { i, p ->
                    val d = hypot((p.x - event.x).toDouble(), (p.y - event.y).toDouble()).toFloat()
                    if (d < closestDist) {
                        closestDist = d
                        closestIndex = i
                    }
                }
                activeCorner = if (closestDist <= touchSlopPx) closestIndex else -1
                parent?.requestDisallowInterceptTouchEvent(activeCorner != -1)
                return activeCorner != -1
            }
            MotionEvent.ACTION_MOVE -> {
                if (activeCorner == -1) return false
                val pt = mapPoint(viewToBitmap, PointF(event.x, event.y))
                val clampedX = pt.x.coerceIn(0f, bmp.width.toFloat())
                val clampedY = pt.y.coerceIn(0f, bmp.height.toFloat())
                corners[activeCorner].set(clampedX, clampedY)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                activeCorner = -1
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    fun getResultQuad(): ImageProcessor.Quad = ImageProcessor.Quad(
        CvPoint(corners[0].x.toDouble(), corners[0].y.toDouble()),
        CvPoint(corners[1].x.toDouble(), corners[1].y.toDouble()),
        CvPoint(corners[2].x.toDouble(), corners[2].y.toDouble()),
        CvPoint(corners[3].x.toDouble(), corners[3].y.toDouble())
    )
}
