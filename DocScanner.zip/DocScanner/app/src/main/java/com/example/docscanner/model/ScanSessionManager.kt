package com.example.docscanner.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Holds the list of pages for the document currently being built, shared across
 * CaptureActivity / CropActivity / PageListActivity.
 *
 * The in-memory list (`pages`) is what every screen actually reads/writes while the app is
 * running - that part is unchanged from the original MVP design. On top of that, every change is
 * also mirrored to a small JSON file on disk (`session_state.json` in internal storage, NOT the
 * cache dir - cache can be cleared by the OS at any time, which would defeat the point), so a
 * session survives the app process being killed (backgrounded and reclaimed by Android, a crash,
 * a phone restart) instead of silently losing everything the user had already scanned. See
 * TECHNICAL_DOCS.md for why this was added and what it does/doesn't cover.
 *
 * [init] must be called once (from [com.example.docscanner.DocScannerApp.onCreate]) before
 * persistence works; without it, the class still works as a plain in-memory session, it just
 * can't save/restore across process death.
 */
object ScanSessionManager {

    private val _pages = mutableListOf<ScanPage>()
    val pages: List<ScanPage> get() = _pages
    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun addPage(page: ScanPage) {
        _pages.add(page)
        persist()
    }

    fun removeAt(index: Int) {
        if (index !in _pages.indices) return
        val page = _pages.removeAt(index)
        runCatching { File(page.filePath).delete() }
        persist()
    }

    fun move(from: Int, to: Int) {
        if (from !in _pages.indices || to !in _pages.indices) return
        val item = _pages.removeAt(from)
        _pages.add(to, item)
        persist()
    }

    fun replaceFile(index: Int, newPath: String) {
        if (index !in _pages.indices) return
        _pages[index].filePath = newPath
        persist()
    }

    fun clear() {
        _pages.forEach { runCatching { File(it.filePath).delete() } }
        _pages.clear()
        persist()
    }

    fun newPageId(): String = UUID.randomUUID().toString()

    // --- Backup/restore across process death ---------------------------------------------

    private fun stateFile(): File? = appContext?.let { File(it.filesDir, "session_state.json") }

    private fun persist() {
        val file = stateFile() ?: return
        try {
            val arr = JSONArray()
            _pages.forEach { page ->
                val obj = JSONObject().put("id", page.id).put("path", page.filePath)
                if (page.sourceDpi != null) obj.put("sourceDpi", page.sourceDpi)
                arr.put(obj)
            }
            file.writeText(arr.toString())
        } catch (e: Exception) {
            // Best-effort only - a failed save just means nothing to restore later, never crash over it.
        }
    }

    /** True if there's a saved session on disk with at least 1 page. Callers should also check
     *  that [pages] is currently empty - a non-empty in-memory list means this process is
     *  already actively using a session, so there's nothing to "restore" on top of it. */
    fun hasSavedSession(): Boolean = savedSessionPageCount() > 0

    fun savedSessionPageCount(): Int {
        val file = stateFile() ?: return 0
        if (!file.exists()) return 0
        return try {
            JSONArray(file.readText()).length()
        } catch (e: Exception) {
            0
        }
    }

    /** Loads the saved session from disk into memory (e.g. after the user picks "Continue"). */
    fun restoreSavedSession() {
        val file = stateFile() ?: return
        _pages.clear()
        try {
            val arr = JSONArray(file.readText())
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val path = obj.optString("path")
                val id = obj.optString("id")
                val sourceDpi = if (obj.has("sourceDpi")) obj.optDouble("sourceDpi").toFloat() else null
                if (path.isNotBlank() && id.isNotBlank() && File(path).exists()) {
                    _pages.add(ScanPage(id, path, sourceDpi))
                }
            }
        } catch (e: Exception) {
            _pages.clear()
        }
    }

    /** Discards the saved session on disk (and the page files it referenced) without loading it. */
    fun discardSavedSession() {
        val file = stateFile() ?: return
        try {
            val arr = JSONArray(file.readText())
            for (i in 0 until arr.length()) {
                val path = arr.getJSONObject(i).optString("path")
                if (path.isNotBlank()) runCatching { File(path).delete() }
            }
        } catch (e: Exception) {
            // ignore - best effort cleanup
        }
        runCatching { file.delete() }
    }
}
