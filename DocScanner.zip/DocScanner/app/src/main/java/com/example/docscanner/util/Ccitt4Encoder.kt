package com.example.docscanner.util

import android.graphics.Bitmap
import android.graphics.Color

/**
 * CCITT Group 4 (T.6 / MMR) encoder for pure black-and-white images - the same compression real
 * scanner hardware/software uses for bitonal (text) pages, compressing further than the 1-bit +
 * Deflate path in [PdfCompressor]. Fully lossless: it stores exact run lengths of black/white
 * pixels, so it can never introduce the "ringing" artifacts a DCT codec like JPEG would around
 * sharp text edges.
 *
 * This is a genuinely intricate binary format to hand-write, so instead of trusting memory alone,
 * the encoder logic and every entry in the Modified Huffman run-length tables below were developed
 * and verified in a Python sandbox against libtiff (the reference implementation almost every real
 * TIFF/fax/PDF tool is built on) - encoding 11 varied test images (including a 400x300 synthetic
 * page) and diffing the result byte-for-byte against libtiff's own Group 4 output. All 11 matched
 * exactly. The tables here are a direct, mechanical transcription of that verified data (see
 * TECHNICAL_DOCS.md for the verification method), generated straight from the same Python data
 * structures rather than retyped by hand a second time, to avoid reintroducing a transcription
 * error after the fact.
 *
 * Still: this has never run through this exact Kotlin code path on a real device or against a real
 * PDF reader. [PdfCompressor] self-checks every page by decoding its own output back and comparing
 * pixels before committing to use it, falling back to the safe 1-bit+Deflate path if anything looks
 * wrong - see [Ccitt4Decoder] and TECHNICAL_DOCS.md.
 */
internal object Ccitt4Encoder {


    private val WHITE_TERM = arrayOf(
        8 to 0b00110101, 6 to 0b000111, 4 to 0b0111, 4 to 0b1000,
        4 to 0b1011, 4 to 0b1100, 4 to 0b1110, 4 to 0b1111,
        5 to 0b10011, 5 to 0b10100, 5 to 0b00111, 5 to 0b01000,
        6 to 0b001000, 6 to 0b000011, 6 to 0b110100, 6 to 0b110101,
        6 to 0b101010, 6 to 0b101011, 7 to 0b0100111, 7 to 0b0001100,
        7 to 0b0001000, 7 to 0b0010111, 7 to 0b0000011, 7 to 0b0000100,
        7 to 0b0101000, 7 to 0b0101011, 7 to 0b0010011, 7 to 0b0100100,
        7 to 0b0011000, 8 to 0b00000010, 8 to 0b00000011, 8 to 0b00011010,
        8 to 0b00011011, 8 to 0b00010010, 8 to 0b00010011, 8 to 0b00010100,
        8 to 0b00010101, 8 to 0b00010110, 8 to 0b00010111, 8 to 0b00101000,
        8 to 0b00101001, 8 to 0b00101010, 8 to 0b00101011, 8 to 0b00101100,
        8 to 0b00101101, 8 to 0b00000100, 8 to 0b00000101, 8 to 0b00001010,
        8 to 0b00001011, 8 to 0b01010010, 8 to 0b01010011, 8 to 0b01010100,
        8 to 0b01010101, 8 to 0b00100100, 8 to 0b00100101, 8 to 0b01011000,
        8 to 0b01011001, 8 to 0b01011010, 8 to 0b01011011, 8 to 0b01001010,
        8 to 0b01001011, 8 to 0b01001100, 8 to 0b01001101, 8 to 0b00110010,
    )

    private val BLACK_TERM = arrayOf(
        10 to 0b0000110111, 3 to 0b010, 2 to 0b11, 2 to 0b10,
        3 to 0b011, 4 to 0b0011, 4 to 0b0010, 5 to 0b00011,
        6 to 0b000101, 6 to 0b000100, 7 to 0b0000100, 7 to 0b0000101,
        7 to 0b0000111, 8 to 0b00000100, 8 to 0b00000111, 9 to 0b000011000,
        10 to 0b0000010111, 10 to 0b0000011000, 10 to 0b0000001000, 11 to 0b00001100111,
        11 to 0b00001101000, 11 to 0b00001101100, 11 to 0b00000110111, 11 to 0b00000101000,
        11 to 0b00000010111, 11 to 0b00000011000, 12 to 0b000011001010, 12 to 0b000011001011,
        12 to 0b000011001100, 12 to 0b000011001101, 12 to 0b000001101000, 12 to 0b000001101001,
        12 to 0b000001101010, 12 to 0b000001101011, 12 to 0b000011010010, 12 to 0b000011010011,
        12 to 0b000011010100, 12 to 0b000011010101, 12 to 0b000011010110, 12 to 0b000011010111,
        12 to 0b000001101100, 12 to 0b000001101101, 12 to 0b000011011010, 12 to 0b000011011011,
        12 to 0b000001010100, 12 to 0b000001010101, 12 to 0b000001010110, 12 to 0b000001010111,
        12 to 0b000001100100, 12 to 0b000001100101, 12 to 0b000001010010, 12 to 0b000001010011,
        12 to 0b000000100100, 12 to 0b000000110111, 12 to 0b000000111000, 12 to 0b000000100111,
        12 to 0b000000101000, 13 to 0b0000001011000, 13 to 0b0000001011001, 13 to 0b0000000101011,
        13 to 0b0000000101100, 13 to 0b0000001011010, 13 to 0b0000001100110, 13 to 0b0000001100111,
    )

    private val WHITE_MAKEUP = mapOf(
        64 to (5 to 0b11011), 128 to (5 to 0b10010), 192 to (6 to 0b010111),
        256 to (7 to 0b0110111), 320 to (8 to 0b00110110), 384 to (8 to 0b00110111),
        448 to (8 to 0b01100100), 512 to (8 to 0b01100101), 576 to (8 to 0b01101000),
        640 to (8 to 0b01100111), 704 to (9 to 0b011001100), 768 to (9 to 0b011001101),
        832 to (9 to 0b011010010), 896 to (9 to 0b011010011), 960 to (9 to 0b011010100),
        1024 to (9 to 0b011010101), 1088 to (9 to 0b011010110), 1152 to (9 to 0b011010111),
        1216 to (9 to 0b011011000), 1280 to (9 to 0b011011001), 1344 to (9 to 0b011011010),
        1408 to (9 to 0b011011011), 1472 to (9 to 0b010011000), 1536 to (9 to 0b010011001),
        1600 to (9 to 0b010011010), 1664 to (6 to 0b011000), 1728 to (9 to 0b010011011),
    )

    private val BLACK_MAKEUP = mapOf(
        64 to (10 to 0b0000001111), 128 to (12 to 0b000011001000), 192 to (12 to 0b000011001001),
        256 to (12 to 0b000001011011), 320 to (12 to 0b000000110011), 384 to (12 to 0b000000110100),
        448 to (12 to 0b000000110101), 512 to (13 to 0b0000001101100), 576 to (13 to 0b0000001101101),
        640 to (13 to 0b0000001001010), 704 to (13 to 0b0000001001011), 768 to (13 to 0b0000001001100),
        832 to (13 to 0b0000001001101), 896 to (13 to 0b0000001110010), 960 to (13 to 0b0000001110011),
        1024 to (13 to 0b0000001110100), 1088 to (13 to 0b0000001110101), 1152 to (13 to 0b0000001110110),
        1216 to (13 to 0b0000001110111), 1280 to (13 to 0b0000001010010), 1344 to (13 to 0b0000001010011),
        1408 to (13 to 0b0000001010100), 1472 to (13 to 0b0000001010101), 1536 to (13 to 0b0000001011010),
        1600 to (13 to 0b0000001011011), 1664 to (13 to 0b0000001100100), 1728 to (13 to 0b0000001100101),
    )

    private val EXT_MAKEUP = mapOf(
        1792 to (11 to 0b00000001000), 1856 to (11 to 0b00000001100), 1920 to (11 to 0b00000001101),
        1984 to (12 to 0b000000010010), 2048 to (12 to 0b000000010011), 2112 to (12 to 0b000000010100),
        2176 to (12 to 0b000000010101), 2240 to (12 to 0b000000010110), 2304 to (12 to 0b000000010111),
        2368 to (12 to 0b000000011100), 2432 to (12 to 0b000000011101), 2496 to (12 to 0b000000011110),
        2560 to (12 to 0b000000011111),
    )


    private class BitWriter {
        private val bits = ArrayList<Int>(1024)

        fun write(length: Int, value: Int) {
            for (i in length - 1 downTo 0) {
                bits.add((value shr i) and 1)
            }
        }

        fun toByteArray(): ByteArray {
            val padded = bits.size + ((8 - bits.size % 8) % 8)
            val out = ByteArray(padded / 8)
            for (i in 0 until padded) {
                val bit = if (i < bits.size) bits[i] else 0
                if (bit == 1) {
                    out[i / 8] = (out[i / 8].toInt() or (1 shl (7 - (i % 8)))).toByte()
                }
            }
            return out
        }
    }

    private fun encodeRun(writer: BitWriter, runIn: Int, isWhite: Boolean) {
        var run = runIn
        val term = if (isWhite) WHITE_TERM else BLACK_TERM
        val makeup = if (isWhite) WHITE_MAKEUP else BLACK_MAKEUP
        while (run >= 64) {
            val m = when {
                run >= 2560 -> 2560
                run >= 1792 -> 1792 + ((run - 1792) / 64) * 64
                else -> (run / 64) * 64
            }
            val (length, value) = if (m >= 1792) EXT_MAKEUP.getValue(m) else makeup.getValue(m)
            writer.write(length, value)
            run -= m
        }
        val (length, value) = term[run]
        writer.write(length, value)
    }

    private fun writeVerticalMode(writer: BitWriter, offset: Int) {
        when (offset) {
            0 -> writer.write(1, 0b1)
            1 -> writer.write(3, 0b011)
            -1 -> writer.write(3, 0b010)
            2 -> writer.write(6, 0b000011)
            -2 -> writer.write(6, 0b000010)
            3 -> writer.write(7, 0b0000011)
            -3 -> writer.write(7, 0b0000010)
            else -> error("invalid vertical offset $offset")
        }
    }

    /** Changing-element positions for one row: x-coordinates where the pixel colour differs from
     *  the pixel to its left (an imaginary white pixel is assumed to sit before position 0), so
     *  the first entry (if any) is always a transition into black, matching T.6's convention. */
    private fun rowToChanges(rowPixels: IntArray, width: Int): IntArray {
        val changes = ArrayList<Int>()
        var prevWhite = true
        for (x in 0 until width) {
            val p = rowPixels[x]
            val gray = (Color.red(p) + Color.green(p) + Color.blue(p)) / 3
            val isWhite = gray >= 128
            if (isWhite != prevWhite) {
                changes.add(x)
                prevWhite = isWhite
            }
        }
        return changes.toIntArray()
    }

    private fun findChange(changes: IntArray, a0: Int, wantWhiteColor: Boolean, width: Int): IntArray {
        val n = changes.size
        var i = 0
        while (i < n && changes[i] <= a0) i++
        if (i < n) {
            val idxIsEven = (i % 2 == 0)
            if (idxIsEven != wantWhiteColor) i++
        }
        val first = if (i < n) changes[i] else width
        val second = if (i + 1 < n) changes[i + 1] else width
        return intArrayOf(first, second)
    }

    /**
     * Encodes [bitmap] (any bitmap - pixels are thresholded at the midpoint, so pass an
     * already-binarized black/white bitmap for a predictable result) as a raw Group 4 bitstream,
     * including the trailing EOFB marker.
     */
    fun encode(bitmap: Bitmap): ByteArray {
        val width = bitmap.width
        val height = bitmap.height
        val writer = BitWriter()
        var refChanges = IntArray(0)
        val rowPixels = IntArray(width)

        for (y in 0 until height) {
            bitmap.getPixels(rowPixels, 0, width, 0, y, width, 1)
            val codingChanges = rowToChanges(rowPixels, width)

            var a0 = -1
            var colorWhite = true
            while (a0 < width) {
                val ref = findChange(refChanges, a0, colorWhite, width)
                val b1 = ref[0]
                val b2 = ref[1]
                val coding = findChange(codingChanges, a0, colorWhite, width)
                val a1 = coding[0]
                val a2 = coding[1]

                when {
                    b2 < a1 -> {
                        writer.write(4, 0b0001) // Pass mode
                        a0 = b2
                    }
                    Math.abs(a1 - b1) <= 3 -> {
                        writeVerticalMode(writer, a1 - b1)
                        a0 = a1
                        colorWhite = !colorWhite
                    }
                    else -> {
                        writer.write(3, 0b001) // Horizontal mode
                        val start = if (a0 >= 0) a0 else 0
                        encodeRun(writer, a1 - start, colorWhite)
                        encodeRun(writer, a2 - a1, !colorWhite)
                        a0 = a2
                    }
                }
            }
            refChanges = codingChanges
        }

        // EOFB (End Of Facsimile Block) = two consecutive EOL codes. Not strictly required when the
        // PDF's CCITTFaxDecode /Rows parameter is set (which PdfCompressor always sets) and
        // /EndOfBlock is false, but included anyway since it costs only 3 bytes and matches what
        // real encoders (including libtiff) produce, maximising compatibility with any reader.
        writer.write(12, 0b000000000001)
        writer.write(12, 0b000000000001)
        return writer.toByteArray()
    }
}
