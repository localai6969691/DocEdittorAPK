package com.example.docscanner

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.docscanner.adapter.EbookPageAdapter
import com.example.docscanner.adapter.EbookPageData
import com.example.docscanner.databinding.ActivityEbookEditorBinding
import com.example.docscanner.model.Project
import com.example.docscanner.model.ProjectEbookEditorState
import com.example.docscanner.model.ProjectManager
import com.example.docscanner.model.ProjectStage
import com.example.docscanner.util.EbookBuilder
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.OcrHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Project stage 8 (final): build the ebook. Reuses `activity_ebook_editor.xml` /
 * [ActivityEbookEditorBinding] and [EbookPageAdapter] directly - same screen shape as the
 * standalone `EbookExportActivity`, just with a project as the source of pages instead of
 * `ScanSessionManager`/a picked PDF, and with chapter marks pre-populated from the table of
 * contents already reviewed back in the Export-PDF stage ([Project.tocEntries]) instead of
 * starting blank - the user already did this work once; no reason to ask again from scratch, just
 * let them touch up.
 *
 * Runs its own fresh OCR pass (block/paragraph form, via [OcrHelper.recognizeBlocks]) rather than
 * reusing [Project.ocrTextPath] from the previous stage - that file has flat text in a different
 * shape (for the plain .txt deliverable) and OCR is cheap to redo (same reasoning as the
 * standalone tool - see [EbookBuilder] callers elsewhere).
 *
 * Backs up manual chapter-mark/title touch-ups made here via [ProjectEbookEditorState], the same
 * way [EbookExportActivity] backs up its own via [com.example.docscanner.model.EbookEditorState] -
 * this closes the one remaining gap noted in TECHNICAL_DOCS.md section 4.15/6: previously, a
 * process death while reviewing chapter marks on this screen (after OCR finished) silently lost
 * whatever the user had just touched up, even though the source pages and the original TOC were
 * always safe as part of [Project] itself. No "restore or start over" prompt is shown here, unlike
 * the standalone tool - a Project's source pages are fixed ([Project.pages]), so restoring is
 * always the right call when a saved state matches them, with no ambiguity to ask the user about.
 */
class ProjectEbookActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEbookEditorBinding
    private lateinit var project: Project
    private lateinit var adapter: EbookPageAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEbookEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val projectId = intent.getStringExtra(ProjectFlow.EXTRA_PROJECT_ID)
        val loaded = projectId?.let { ProjectManager.load(this, it) }
        if (loaded == null) {
            finish()
            return
        }
        project = loaded
        title = getString(R.string.project_stage_indicator_7)

        adapter = EbookPageAdapter(onChanged = { persistEditorState() })
        binding.rvEbookPages.layoutManager = LinearLayoutManager(this)
        binding.rvEbookPages.adapter = adapter

        binding.etBookTitle.setText(project.name)
        binding.btnExportEbook.setOnClickListener { exportEbook() }

        // Book title / format checkboxes live outside the per-page adapter, so they need their
        // own hooks into the same persistence call the adapter's onChanged uses for chapter marks
        // - same wiring as EbookExportActivity.
        binding.etBookTitle.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = persistEditorState()
        })
        binding.cbFormatEpub.setOnCheckedChangeListener { _, _ -> persistEditorState() }
        binding.cbFormatTxt.setOnCheckedChangeListener { _, _ -> persistEditorState() }

        runOcrAndShowEditor()
    }

    private fun runOcrAndShowEditor() {
        val paths = project.pages.map { it.path }
        if (paths.isEmpty()) {
            binding.tvEmptyPages.visibility = View.VISIBLE
            return
        }
        // TOC-derived default mark for each page, computed up front (doesn't need OCR to know).
        fun defaultMark(index: Int) = project.tocEntries.firstOrNull { it.pageIndex == index }
        // Save a baseline restore point (TOC-derived marks) right away, before the OCR loop below
        // even starts - same defensive reasoning as EbookExportActivity.runOcrAndShowEditor(): OCR
        // across many pages can take a while, and without this a process death mid-loop would leave
        // nothing on disk to restore despite the source pages/TOC themselves already being safe as
        // part of Project. Cheap to overwrite once real (possibly hand-touched-up) marks exist - see
        // persistEditorState(), called again once OCR finishes.
        ProjectEbookEditorState.persist(
            this, project.id,
            ProjectEbookEditorState.SavedState(
                bookTitle = binding.etBookTitle.text?.toString().orEmpty(),
                wantEpub = binding.cbFormatEpub.isChecked,
                wantTxt = binding.cbFormatTxt.isChecked,
                pages = paths.mapIndexed { i, p ->
                    val tocMatch = defaultMark(i)
                    ProjectEbookEditorState.SavedPage(p, tocMatch != null || i == 0, tocMatch?.title.orEmpty())
                }
            )
        )
        setBusy(true, getString(R.string.ebook_ocr_progress, 0, paths.size))
        lifecycleScope.launch {
            val pages = mutableListOf<EbookPageData>()
            paths.forEachIndexed { index, path ->
                binding.tvProgress.text = getString(R.string.ebook_ocr_progress, index + 1, paths.size)
                val paragraphs = withContext(Dispatchers.Default) {
                    val bitmap = android.graphics.BitmapFactory.decodeFile(path)
                    val result = if (bitmap != null) OcrHelper.recognizeBlocks(bitmap) else emptyList()
                    bitmap?.recycle()
                    result
                }
                val tocMatch = defaultMark(index)
                pages.add(
                    EbookPageData(
                        path = path,
                        paragraphs = paragraphs,
                        isChapterStart = tocMatch != null || index == 0,
                        chapterTitle = tocMatch?.title.orEmpty()
                    )
                )
            }
            applySavedMarksIfMatching(pages)
            adapter.submitList(pages)
            setBusy(false, null)
            persistEditorState()
        }
    }

    /** Re-applies chapter marks + book title/format checkboxes from a saved
     *  [ProjectEbookEditorState] onto a freshly-OCR'd page list, when the saved state's page paths
     *  line up exactly with what's showing now (same source pages -> the user's earlier manual
     *  touch-ups - or, on a first-ever run, the TOC-derived baseline just written above - are still
     *  meaningful). If they don't line up (shouldn't normally happen for a Project, whose page list
     *  is fixed, but could if pages were somehow re-scanned), the saved state is simply left
     *  untouched on disk - it'll be overwritten by this session's own first edit via
     *  [persistEditorState] regardless. */
    private fun applySavedMarksIfMatching(pages: MutableList<EbookPageData>) {
        val saved = ProjectEbookEditorState.restore(this, project.id) ?: return
        if (saved.pages.map { it.path } != pages.map { it.path }) return
        saved.pages.forEachIndexed { index, sp ->
            pages[index].isChapterStart = sp.isChapterStart
            pages[index].chapterTitle = sp.chapterTitle
        }
        binding.etBookTitle.setText(saved.bookTitle)
        binding.cbFormatEpub.isChecked = saved.wantEpub
        binding.cbFormatTxt.isChecked = saved.wantTxt
    }

    private fun persistEditorState() {
        val pages = adapter.currentList()
        if (pages.isEmpty()) return
        ProjectEbookEditorState.persist(
            this, project.id,
            ProjectEbookEditorState.SavedState(
                bookTitle = binding.etBookTitle.text?.toString().orEmpty(),
                wantEpub = binding.cbFormatEpub.isChecked,
                wantTxt = binding.cbFormatTxt.isChecked,
                pages = pages.map { ProjectEbookEditorState.SavedPage(it.path, it.isChapterStart, it.chapterTitle) }
            )
        )
    }

    private fun buildChapters(): List<EbookBuilder.Chapter> {
        val pages = adapter.currentList()
        val chapters = mutableListOf<EbookBuilder.Chapter>()
        var currentTitle = ""
        var currentParagraphs = mutableListOf<String>()
        var started = false

        pages.forEachIndexed { index, page ->
            if (page.isChapterStart || !started) {
                if (started) chapters.add(EbookBuilder.Chapter(currentTitle, currentParagraphs))
                currentTitle = page.chapterTitle.ifBlank { "Chương ${chapters.size + 1}" }
                currentParagraphs = mutableListOf()
                started = true
            }
            currentParagraphs.addAll(page.paragraphs)
        }
        if (started) chapters.add(EbookBuilder.Chapter(currentTitle, currentParagraphs))
        return chapters
    }

    private fun exportEbook() {
        val chapters = buildChapters()
        if (chapters.isEmpty()) return
        val wantEpub = binding.cbFormatEpub.isChecked
        val wantTxt = binding.cbFormatTxt.isChecked
        if (!wantEpub && !wantTxt) return

        val bookTitle = binding.etBookTitle.text?.toString()?.ifBlank { null } ?: project.name
        val baseName = FileUtils.defaultEbookName()
        val outDir = com.example.docscanner.util.PdfExporter.exportDir(this)

        setBusy(true, null)
        lifecycleScope.launch {
            val outputs = withContext(Dispatchers.Default) {
                val created = mutableListOf<File>()
                if (wantEpub) {
                    val f = File(outDir, "$baseName.epub")
                    EbookBuilder.buildEpub(f, bookTitle, chapters)
                    created.add(f)
                }
                if (wantTxt) {
                    val f = File(outDir, "$baseName.txt")
                    EbookBuilder.buildTxt(f, bookTitle, chapters)
                    created.add(f)
                }
                created
            }
            setBusy(false, null)
            project.ebookPaths = outputs.map { it.absolutePath }.toMutableList()
            project.stage = ProjectStage.DONE
            ProjectManager.save(this@ProjectEbookActivity, project)
            ProjectEbookEditorState.clear(this@ProjectEbookActivity, project.id)
            Toast.makeText(
                this@ProjectEbookActivity,
                getString(R.string.ebook_export_success, outputs.joinToString(", ") { it.name }),
                Toast.LENGTH_LONG
            ).show()
            ProjectFlow.open(this@ProjectEbookActivity, project)
            finish()
        }
    }

    private fun setBusy(busy: Boolean, message: String?) {
        binding.progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        binding.tvProgress.visibility = if (busy && message != null) View.VISIBLE else View.GONE
        if (message != null) binding.tvProgress.text = message
        binding.btnExportEbook.isEnabled = !busy
    }
}
