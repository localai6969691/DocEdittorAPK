package com.example.docscanner

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityCropBinding
import com.example.docscanner.model.PendingCropQueue
import com.example.docscanner.model.ScanPage
import com.example.docscanner.model.ScanSessionManager
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.ImageProcessor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileOutputStream

/**
 * Three-stage screen: (0, optional) split a 2-page spread photo into 2 single pages, (1) drag the
 * 4 corners to match the document, (2) pick a filter and save.
 *
 * Runs in one of two navigation modes:
 *  - Single mode (queueMode = false): launched by CaptureActivity for one just-taken photo.
 *    Saving/retaking finishes this activity with a result and CaptureActivity resumes.
 *  - Queue mode (queueMode = true): launched directly for a batch of images (gallery picks or
 *    pages rendered from an imported PDF, see [PendingCropQueue]). After each save/skip it loads
 *    the next queued image itself, and moves on to [PageListActivity] once the queue is empty.
 *
 * A split (stage 0) always switches this instance to queue mode from that point on, even if it
 * started in single mode: splitting produces 2 pages instead of 1, so there's more than one image
 * left to get through, and the simplest, safest thing is to always finish into [PageListActivity]
 * once every resulting page has been saved (see TECHNICAL_DOCS.md for the reasoning).
 */
class CropActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCropBinding
    private var sourceBitmap: Bitmap? = null
    private var warpedBitmap: Bitmap? = null
    private var queueMode = false
    private var selectedFilter = ImageProcessor.ScanFilter.ORIGINAL

    /** Known render DPI for every page in this batch (queue mode only - `null` for a camera
     *  single-mode capture, which has no "true" DPI). Read once from the launching Intent and
     *  reused for every page saved out of this activity instance, split-page halves included,
     *  since one CropActivity instance only ever processes pages from a single source/batch -
     *  see [PendingCropQueue]'s doc comment and TECHNICAL_DOCS.md section 6/7 ("ASSUMED_DPI"). */
    private var sourceDpi: Float? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCropBinding.inflate(layoutInflater)
        setContentView(binding.root)

        queueMode = intent.getBooleanExtra(EXTRA_QUEUE_MODE, false)
        sourceDpi = if (intent.hasExtra(EXTRA_SOURCE_DPI)) intent.getFloatExtra(EXTRA_SOURCE_DPI, 0f) else null
        val path = intent.getStringExtra(EXTRA_IMAGE_PATH)
        if (path == null) {
            finish()
            return
        }
        loadImage(path)

        binding.btnRetake.setOnClickListener { handleSkip() }
        binding.btnConfirmCrop.setOnClickListener { confirmCrop() }
        binding.btnBackToCrop.setOnClickListener { showCropStage() }
        binding.btnSavePage.setOnClickListener { savePage() }
        binding.btnSplitPages.setOnClickListener { showSplitStage() }
        binding.btnCancelSplit.setOnClickListener { showCropStage() }
        binding.btnConfirmSplit.setOnClickListener { confirmSplit() }

        binding.chipGroup.setOnCheckedChangeListener { _, checkedId ->
            selectedFilter = when (checkedId) {
                binding.chipEnhance.id -> ImageProcessor.ScanFilter.ENHANCE
                binding.chipGray.id -> ImageProcessor.ScanFilter.GRAY
                binding.chipBw.id -> ImageProcessor.ScanFilter.BW
                else -> ImageProcessor.ScanFilter.ORIGINAL
            }
            updateFilterPreview()
        }
    }

    private fun loadImage(path: String) {
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.Default) { FileUtils.decodeBitmapWithExifOrientation(path) }
            if (bmp == null) {
                binding.progressBar.visibility = View.GONE
                handleSkip()
                return@launch
            }
            proceedWithBitmap(bmp)
        }
    }

    /** Shared by the initial file load and by the split flow (which hands over the left-half
     *  bitmap directly, with no file to decode). Detects corners and shows stage 1. */
    private suspend fun proceedWithBitmap(bmp: Bitmap) {
        sourceBitmap = bmp
        val detected = withContext(Dispatchers.Default) {
            ImageProcessor.detectDocumentCorners(bmp)
        } ?: ImageProcessor.defaultCorners(bmp.width, bmp.height)
        binding.cropOverlayView.setImage(bmp, detected)
        binding.progressBar.visibility = View.GONE
        showCropStage()
    }

    /** Used both when the user explicitly retakes/cancels and as a fallback if a file fails to load. */
    private fun handleSkip() {
        if (queueMode) {
            val next = PendingCropQueue.pollNext()
            if (next != null) loadImage(next) else goToPageListAndFinish()
        } else {
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    private fun showSplitStage() {
        val bmp = sourceBitmap ?: return
        binding.cropOverlayView.visibility = View.GONE
        binding.bottomBar1.visibility = View.GONE
        binding.btnSplitPages.visibility = View.GONE
        binding.splitLineOverlayView.visibility = View.VISIBLE
        binding.bottomBarSplit.visibility = View.VISIBLE
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val gutterX = withContext(Dispatchers.Default) { ImageProcessor.detectGutterX(bmp) }
            binding.splitLineOverlayView.setImage(bmp, gutterX)
            binding.progressBar.visibility = View.GONE
        }
    }

    private fun confirmSplit() {
        val source = sourceBitmap ?: return
        val splitX = binding.splitLineOverlayView.getSplitX().toInt().coerceIn(1, source.width - 1)
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val leftBitmap = withContext(Dispatchers.Default) {
                val left = Bitmap.createBitmap(source, 0, 0, splitX, source.height)
                val right = Bitmap.createBitmap(source, splitX, 0, source.width - splitX, source.height)
                val rightFile = FileUtils.newSplitPageFile(this@CropActivity)
                FileOutputStream(rightFile).use { out -> right.compress(Bitmap.CompressFormat.JPEG, 95, out) }
                right.recycle()
                PendingCropQueue.pushFront(rightFile.absolutePath)
                left
            }
            queueMode = true // splitting means there's now more than 1 page left - always finish to the page list
            proceedWithBitmap(leftBitmap)
        }
    }

    private fun confirmCrop() {
        val bmp = sourceBitmap ?: return
        val quad = binding.cropOverlayView.getResultQuad()
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val warped = withContext(Dispatchers.Default) { ImageProcessor.warpDocument(bmp, quad) }
            warpedBitmap = warped
            val suggestColor = withContext(Dispatchers.Default) { ImageProcessor.isColorPage(warped) }
            binding.progressBar.visibility = View.GONE
            showFilterStage(suggestColor)
        }
    }

    private fun showCropStage() {
        binding.cropOverlayView.visibility = View.VISIBLE
        binding.bottomBar1.visibility = View.VISIBLE
        binding.btnSplitPages.visibility = View.VISIBLE
        binding.splitLineOverlayView.visibility = View.GONE
        binding.bottomBarSplit.visibility = View.GONE
        binding.ivResult.visibility = View.GONE
        binding.filterScroll.visibility = View.GONE
        binding.bottomBar2.visibility = View.GONE
    }

    private fun showFilterStage(suggestColor: Boolean = false) {
        binding.cropOverlayView.visibility = View.GONE
        binding.bottomBar1.visibility = View.GONE
        binding.btnSplitPages.visibility = View.GONE
        binding.splitLineOverlayView.visibility = View.GONE
        binding.bottomBarSplit.visibility = View.GONE
        binding.ivResult.visibility = View.VISIBLE
        binding.filterScroll.visibility = View.VISIBLE
        binding.bottomBar2.visibility = View.VISIBLE
        if (suggestColor) {
            binding.chipEnhance.isChecked = true
            selectedFilter = ImageProcessor.ScanFilter.ENHANCE
        } else {
            binding.chipBw.isChecked = true
            selectedFilter = ImageProcessor.ScanFilter.BW
        }
        updateFilterPreview()
    }

    private fun updateFilterPreview() {
        val warped = warpedBitmap ?: return
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val filtered = withContext(Dispatchers.Default) {
                ImageProcessor.applyFilter(warped, selectedFilter)
            }
            binding.ivResult.setImageBitmap(filtered)
            binding.progressBar.visibility = View.GONE
        }
    }

    private fun savePage() {
        val warped = warpedBitmap ?: return
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val outFile = withContext(Dispatchers.Default) {
                val finalBitmap = ImageProcessor.applyFilter(warped, selectedFilter)
                val file = FileUtils.newSessionPageFile(this@CropActivity)
                FileOutputStream(file).use { out ->
                    finalBitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
                }
                file
            }
            ScanSessionManager.addPage(ScanPage(ScanSessionManager.newPageId(), outFile.absolutePath, sourceDpi = sourceDpi))
            binding.progressBar.visibility = View.GONE

            if (queueMode) {
                val next = PendingCropQueue.pollNext()
                if (next != null) loadImage(next) else goToPageListAndFinish()
            } else {
                setResult(RESULT_OK)
                finish()
            }
        }
    }

    private fun goToPageListAndFinish() {
        startActivity(Intent(this, PageListActivity::class.java))
        finish()
    }

    companion object {
        const val EXTRA_IMAGE_PATH = "extra_image_path"
        const val EXTRA_QUEUE_MODE = "extra_queue_mode"
        /** Optional Float extra - only set by [MainActivity.startCropQueue] when the batch has a
         *  known real DPI (currently: PDF-import-for-scanning, 220). Absent entirely for gallery
         *  imports and camera captures, which fall back to `null` (the camera-capture convention -
         *  see [sourceDpi]'s doc comment). */
        const val EXTRA_SOURCE_DPI = "extra_source_dpi"
    }
}
