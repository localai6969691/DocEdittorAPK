package com.example.docscanner

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import com.example.docscanner.adapter.SimpleThumbnailAdapter
import com.example.docscanner.databinding.ActivityProjectScanBinding
import com.example.docscanner.model.Project
import com.example.docscanner.model.ProjectManager
import com.example.docscanner.model.ProjectStage
import com.example.docscanner.util.ScanPresetApplier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

/**
 * Project stage 4: mandatory scan preset. Reuses [ScanPresetApplier] (the same 7 presets, e-ink
 * and general-purpose, that `PageListActivity`'s standalone "Lọc hàng loạt" tool already offers -
 * see TECHNICAL_DOCS.md) so a project applies identical processing rather than a second copy. The
 * *stage* is mandatory - Continue stays disabled until a preset has actually been chosen and
 * applied - but *which* preset is entirely the user's choice, same as the standalone tool.
 */
class ProjectScanActivity : AppCompatActivity() {

    private lateinit var binding: ActivityProjectScanBinding
    private lateinit var project: Project
    private lateinit var thumbAdapter: SimpleThumbnailAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProjectScanBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val projectId = intent.getStringExtra(ProjectFlow.EXTRA_PROJECT_ID)
        val loaded = projectId?.let { ProjectManager.load(this, it) }
        if (loaded == null) {
            finish()
            return
        }
        project = loaded
        title = project.name
        binding.tvStageIndicator.text = getString(R.string.project_stage_indicator_3)

        thumbAdapter = SimpleThumbnailAdapter()
        binding.rvScanPages.layoutManager = GridLayoutManager(this, 3)
        binding.rvScanPages.adapter = thumbAdapter
        thumbAdapter.submitList(project.pages.map { it.path })

        updatePresetLabel()
        binding.btnContinue.isEnabled = project.scanPresetLabel != null

        binding.btnChoosePreset.setOnClickListener { showPresetDialog() }
        binding.btnContinue.setOnClickListener { advance() }
    }

    private fun updatePresetLabel() {
        val label = project.scanPresetLabel
        binding.tvSelectedPreset.text = if (label != null) {
            getString(R.string.project_scan_current_preset, label)
        } else {
            getString(R.string.project_scan_no_preset_yet)
        }
    }

    private fun showPresetDialog() {
        val labels = arrayOf(
            getString(R.string.preset_original),
            getString(R.string.preset_enhance),
            getString(R.string.preset_gray),
            getString(R.string.preset_bw),
            getString(R.string.preset_eink),
            getString(R.string.preset_eink_color),
            getString(R.string.preset_auto)
        )
        val presets = ScanPresetApplier.Preset.values()
        var selected = 6 // default to Auto, same default as the standalone bulk-filter tool
        AlertDialog.Builder(this)
            .setTitle(R.string.bulk_filter_title)
            .setSingleChoiceItems(labels, selected) { _, which -> selected = which }
            .setPositiveButton(R.string.dialog_yes) { dialog, _ ->
                applyPreset(presets[selected], labels[selected])
                dialog.dismiss()
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun applyPreset(preset: ScanPresetApplier.Preset, label: String) {
        val pages = project.pages.toList()
        if (pages.isEmpty()) return
        binding.progressBar.visibility = View.VISIBLE
        binding.tvProgress.visibility = View.VISIBLE
        val autoStats = ScanPresetApplier.AutoStats()
        lifecycleScope.launch {
            pages.forEachIndexed { index, page ->
                binding.tvProgress.text = getString(R.string.bulk_filter_progress, index + 1, pages.size)
                withContext(Dispatchers.Default) {
                    val bitmap = BitmapFactory.decodeFile(page.path) ?: return@withContext
                    val out = ScanPresetApplier.apply(bitmap, preset, autoStats)
                    FileOutputStream(File(page.path)).use { fos ->
                        out.compress(Bitmap.CompressFormat.JPEG, 92, fos)
                    }
                    if (out !== bitmap) out.recycle()
                    bitmap.recycle()
                }
            }
            project.scanPresetLabel = label
            ProjectManager.save(this@ProjectScanActivity, project)
            binding.progressBar.visibility = View.GONE
            binding.tvProgress.visibility = View.GONE
            updatePresetLabel()
            thumbAdapter.refreshThumbnails()
            binding.btnContinue.isEnabled = true
        }
    }

    private fun advance() {
        project.stage = ProjectStage.EXPORT_PDF
        ProjectManager.save(this, project)
        ProjectFlow.open(this, project)
        finish()
    }
}
