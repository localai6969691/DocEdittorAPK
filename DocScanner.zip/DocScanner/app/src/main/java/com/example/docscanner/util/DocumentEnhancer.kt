package com.example.docscanner.util

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Point
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.geometry.Geometry
import org.opencv.imgproc.Imgproc
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Image-enhancement features that commercial document-scanner SDKs (Scanbot, Dynamsoft, ABBYY...)
 * sell and that neither plain OpenCV nor ML Kit gives out of the box. Each one is written from the
 * published paper named next to it, not from anybody's source code (TECHNICAL_DOCS.md, phiên 12).
 *
 *  - [sauvolaBinarize]      - "Trắng đen nâng cao": local-contrast binarization.
 *      J. Sauvola, M. Pietikäinen, "Adaptive document image binarization", Pattern Recognition 33(2),
 *      2000, pp. 225-236: `T = m * (1 + k * (s / R - 1))`, m/s = local mean/standard deviation, R = 128,
 *      k in [0.2, 0.5]. Local mean and variance come from box filters (constant time per pixel),
 *      the same idea as the integral-image implementation of F. Shafait, D. Keysers, T. Breuel,
 *      "Efficient implementation of local adaptive thresholding techniques using integral images",
 *      SPIE Document Recognition and Retrieval XV, 2008. Compared with the plain Gaussian
 *      `adaptiveThreshold` the app used until now, flat paper areas stay clean white (no salt-and-pepper
 *      speckle: with s ~ 0 the threshold drops to m*(1-k), far below the paper level).
 *  - [normalizeBackground]  - "Xóa bóng": shadow / uneven-light removal that keeps colour.
 *      Idea from S. Bako, S. Darabi, E. Shechtman, J. Wang, K. Sunkavalli, P. Sen, "Removing shadows
 *      from images of documents", ACCV 2016: a document has a constant-coloured background, so estimate
 *      the LOCAL background colour, compare it with the global reference (white) and correct by the
 *      ratio. This is a deliberately simple classical version: a small grey-scale dilation (5x5) removes
 *      the ink, a 3x3 median drops single-pixel noise, and the result - at 1000 px long edge - is the
 *      local background (a wide blur would smear the edge of a hard shadow; measured in
 *      tools/verify/shadow_edge_check.py). The topographic "water-filling" method of S. Jung, M. Hasan,
 *      C. Kim (ACCV 2018) is stronger on hard shadow edges but its author asks for permission before any
 *      commercial use (patent issue, GitHub README), so it is deliberately NOT implemented.
 *      Weak spot: big uniform FILLED areas (shaded table headers) count as background and are lightened.
 *  - [estimateSkewDegrees]/[straighten] - auto-straighten ("Tự thẳng chữ").
 *      Projection-profile skew detection: W. Postl, ICPR 1986; D. Bloomberg, G. Kopec, L. Dasari,
 *      "Measuring document image skew and orientation", SPIE 2422, 1995: rotate (here: really rotate a
 *      down-scaled ink mask), and keep the angle that maximises the sum of squared differences of
 *      adjacent row sums - text lines make that profile spiky only when they are horizontal. Coarse sweep
 *      then two refinements, as in Bloomberg et al. The related Xerox patent (US 5,355,420) is listed as
 *      expired by Google Patents; that is not legal advice.
 *
 * Every function returns a NEW bitmap and never modifies its input; on any OpenCV failure the input
 * bitmap is returned unchanged, so a bug here can only cost the enhancement, never the page.
 */
object DocumentEnhancer {

    // ---------------------------------------------------------------------------------------
    // Sauvola binarization
    // ---------------------------------------------------------------------------------------

    /** Chosen by a sweep on synthetic pages (noise, faint text, stains, shadows; TECHNICAL_DOCS.md phiên 12):
     *  0.25 had the best mean overlap with the true ink. 0.34 (a common default) lost much faint text,
     *  0.5 (the paper's own suggestion) lost almost all of it. Re-tune with real photos. */
    private const val SAUVOLA_K = 0.25
    private const val SAUVOLA_R = 128.0
    /** The local mean/std ("threshold surface") is computed on a copy with at most this long edge and
     *  stretched back: it varies smoothly, so nothing is lost (measured: equal or slightly better ink
     *  overlap than full resolution on a 300 dpi page, and faster), the page keeps its exact pixel size
     *  (the exporters derive the PDF page size from it) and the float buffers stay small on 12 MP photos. */
    private const val SAUVOLA_WORK_EDGE = 2000.0

    /** Odd window ~ 1/40 of the short side, clamped: ~1.5-2 text-line heights at scan resolution. */
    private fun sauvolaWindow(shortSide: Int): Int {
        val w = (shortSide / 40).coerceIn(21, 75)
        return if (w % 2 == 0) w + 1 else w
    }

    fun sauvolaBinarize(bitmap: Bitmap, k: Double = SAUVOLA_K, r: Double = SAUVOLA_R): Bitmap {
        val mats = ArrayList<Mat>()
        fun track(m: Mat): Mat { mats.add(m); return m }
        return try {
            val rgba = track(Mat())
            Utils.bitmapToMat(bitmap, rgba)
            val gray = track(Mat())
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)

            val scale = min(1.0, SAUVOLA_WORK_EDGE / max(gray.cols(), gray.rows()).toDouble())
            val small = if (scale < 1.0) {
                val m = track(Mat())
                Imgproc.resize(gray, m, Size(), scale, scale, Imgproc.INTER_AREA)
                m
            } else gray
            val g32 = track(Mat())
            small.convertTo(g32, CvType.CV_32F)

            val w = sauvolaWindow(min(small.rows(), small.cols()))
            val ksize = Size(w.toDouble(), w.toDouble())
            val anchor = Point(-1.0, -1.0)

            val mean = track(Mat())
            Imgproc.boxFilter(g32, mean, CvType.CV_32F, ksize, anchor, true, Core.BORDER_REPLICATE)
            val sq = track(Mat())
            Core.multiply(g32, g32, sq)
            val meanSq = track(Mat())
            Imgproc.boxFilter(sq, meanSq, CvType.CV_32F, ksize, anchor, true, Core.BORDER_REPLICATE)
            sq.release()

            val meanPow2 = track(Mat())
            Core.multiply(mean, mean, meanPow2)
            val variance = track(Mat())
            Core.subtract(meanSq, meanPow2, variance)
            meanSq.release(); meanPow2.release()
            Core.max(variance, Scalar(0.0), variance)
            val std = track(Mat())
            Core.sqrt(variance, std)
            variance.release()

            // T = m * (1 - k) + m * s * (k / R)   (algebraically identical to m * (1 + k * (s/R - 1)))
            val base = track(Mat())
            Core.multiply(mean, Scalar(1.0 - k), base)
            val spread = track(Mat())
            Core.multiply(mean, std, spread)
            Core.multiply(spread, Scalar(k / r), spread)
            val threshold = track(Mat())
            Core.add(base, spread, threshold)

            // 8-bit threshold surface, stretched back to the page size; the final comparison is 8-bit too.
            val threshold8 = track(Mat())
            threshold.convertTo(threshold8, CvType.CV_8U) // rounds and clamps to 0..255
            val thresholdFull = if (scale < 1.0) {
                val m = track(Mat())
                Imgproc.resize(threshold8, m, Size(gray.cols().toDouble(), gray.rows().toDouble()), 0.0, 0.0, Imgproc.INTER_LINEAR)
                m
            } else threshold8

            val binary = track(Mat())
            Core.compare(gray, thresholdFull, binary, Core.CMP_GT) // 255 = paper, 0 = ink
            Imgproc.cvtColor(binary, rgba, Imgproc.COLOR_GRAY2RGBA)
            toBitmap(rgba)
        } catch (t: Throwable) {
            bitmap
        } finally {
            mats.forEach { runCatching { it.release() } }
        }
    }

    // ---------------------------------------------------------------------------------------
    // Background / shadow normalization
    // ---------------------------------------------------------------------------------------

    /** Measured on a synthetic page with a hard-edged cast shadow (TECHNICAL_DOCS.md phiên 13): a small
     *  dilation at high resolution cuts the bright/dark halo along the shadow edge (spread of the paper
     *  next to the edge 45.7 -> 20.5, versus the earlier 480 px / 9x9 / median 15 / Gauss 21). The price:
     *  uniform FILLED areas (shaded table headers, photos) count as "background" too and get lightened,
     *  so this filter is meant for text pages - use "Trắng đen+" or "Gốc" for pages with big filled regions. */
    private const val BG_WORK_EDGE = 1000.0
    /** Background darker than this is treated as "content", not "shadow": caps the brightening gain at
     *  255/96 ~ 2.7x so photos and dark filled regions are not washed out to white. */
    private const val BG_FLOOR = 96.0

    fun normalizeBackground(bitmap: Bitmap): Bitmap {
        val mats = ArrayList<Mat>()
        fun track(m: Mat): Mat { mats.add(m); return m }
        return try {
            val rgba = track(Mat())
            Utils.bitmapToMat(bitmap, rgba)
            val rgb = track(Mat())
            Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)

            val scale = min(1.0, BG_WORK_EDGE / max(rgb.cols(), rgb.rows()).toDouble())
            val small = track(Mat())
            Imgproc.resize(rgb, small, Size(), scale, scale, Imgproc.INTER_AREA)

            // Grey-scale dilation = local maximum: thin dark ink disappears, paper colour stays.
            val kernel = track(Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(5.0, 5.0)))
            val dilated = track(Mat())
            Imgproc.dilate(small, dilated, kernel)
            val smooth = track(Mat())
            // just enough to drop single-pixel noise; a wide blur would smear a hard shadow edge
            Imgproc.medianBlur(dilated, smooth, 3)

            val background = track(Mat())
            Imgproc.resize(smooth, background, Size(rgb.cols().toDouble(), rgb.rows().toDouble()), 0.0, 0.0, Imgproc.INTER_LINEAR)
            Core.max(background, Scalar(BG_FLOOR, BG_FLOOR, BG_FLOOR), background)

            val corrected = track(Mat())
            Core.divide(rgb, background, corrected, 255.0) // pixel * 255 / local background
            Imgproc.cvtColor(corrected, rgba, Imgproc.COLOR_RGB2RGBA)
            toBitmap(rgba)
        } catch (t: Throwable) {
            bitmap
        } finally {
            mats.forEach { runCatching { it.release() } }
        }
    }

    // ---------------------------------------------------------------------------------------
    // Skew detection + straightening
    // ---------------------------------------------------------------------------------------

    private const val SKEW_WORK_EDGE = 900.0
    private const val SKEW_MAX_DEGREES = 8.0
    /** Below this the correction is invisible and only costs a resample. */
    private const val SKEW_MIN_DEGREES = 0.2
    /** Best score must beat the average over all tried angles by this factor, or the page is
     *  treated as "no clear text lines" (photo, blank page, table-only page) and left alone. */
    private const val SKEW_MIN_PROMINENCE = 1.25
    private const val SKEW_MIN_INK_FRACTION = 0.004

    /** Result of one skew analysis: [degrees] to rotate by (0.0 when unsure), the projection-profile
     *  [score] of the best angle (comparable between an image and the same image turned 90 degrees) and
     *  the best score divided by the average over all tried angles ([prominence], >= 1.25 = real text lines). */
    class SkewResult(val degrees: Double, val score: Double, val prominence: Double)

    private val NO_SKEW = SkewResult(0.0, 0.0, 0.0)

    /** Angle in degrees (OpenCV convention: positive = counter-clockwise) by which [bitmap] must be
     *  rotated to make its text lines horizontal, or 0.0 when there is no trustworthy answer. */
    fun estimateSkewDegrees(bitmap: Bitmap): Double {
        val rgba = Mat()
        val gray = Mat()
        return try {
            Utils.bitmapToMat(bitmap, rgba)
            Imgproc.cvtColor(rgba, gray, Imgproc.COLOR_RGBA2GRAY)
            analyzeSkew(gray).degrees
        } catch (t: Throwable) {
            0.0
        } finally {
            rgba.release(); gray.release()
        }
    }

    /** Skew analysis of an 8-bit grey image [gray] (any size; downscaled internally). Never throws. */
    internal fun analyzeSkew(gray: Mat): SkewResult {
        val mats = ArrayList<Mat>()
        fun track(m: Mat): Mat { mats.add(m); return m }
        return try {
            val scale = min(1.0, SKEW_WORK_EDGE / max(gray.cols(), gray.rows()).toDouble())
            val small = track(Mat())
            Imgproc.resize(gray, small, Size(), scale, scale, Imgproc.INTER_AREA)

            // Ink mask: local threshold so shadows do not turn into "ink"; horizontal dilation joins
            // the letters of a word/line so the row profile is not dominated by single strokes.
            val ink = track(Mat())
            Imgproc.adaptiveThreshold(small, ink, 255.0, Imgproc.ADAPTIVE_THRESH_MEAN_C, Imgproc.THRESH_BINARY_INV, 31, 12.0)
            val joiner = track(Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(9.0, 1.0)))
            Imgproc.dilate(ink, ink, joiner)

            val inkFraction = Core.countNonZero(ink).toDouble() / (ink.rows().toDouble() * ink.cols())
            if (inkFraction < SKEW_MIN_INK_FRACTION || inkFraction > 0.5) return NO_SKEW

            val center = Point(ink.cols() / 2.0, ink.rows() / 2.0)
            val rotated = track(Mat())
            val profile = track(Mat())
            val rows = FloatArray(ink.rows())
            val scores = HashMap<Double, Double>()

            fun score(angle: Double): Double {
                scores[angle]?.let { return it }
                val m = Geometry.getRotationMatrix2D(center, angle, 1.0)
                Imgproc.warpAffine(ink, rotated, m, ink.size(), Imgproc.INTER_NEAREST)
                m.release()
                Core.reduce(rotated, profile, 1, Core.REDUCE_SUM, CvType.CV_32F)
                profile.get(0, 0, rows)
                var s = 0.0
                for (i in 1 until rows.size) {
                    val d = (rows[i] - rows[i - 1]).toDouble()
                    s += d * d
                }
                scores[angle] = s
                return s
            }

            var best = 0.0
            var bestScore = score(0.0)
            fun sweep(from: Double, to: Double, step: Double) {
                var a = from
                while (a <= to + 1e-9) {
                    val s = score(round2(a))
                    if (s > bestScore) { bestScore = s; best = round2(a) }
                    a += step
                }
            }
            sweep(-SKEW_MAX_DEGREES, SKEW_MAX_DEGREES, 1.0)
            sweep(best - 1.0, best + 1.0, 0.25)
            sweep(best - 0.25, best + 0.25, 0.05)

            val average = scores.values.average()
            if (average <= 0.0) return NO_SKEW
            val prominence = bestScore / average
            val degrees = if (prominence < SKEW_MIN_PROMINENCE || abs(best) < SKEW_MIN_DEGREES) 0.0 else best
            SkewResult(degrees, bestScore, prominence)
        } catch (t: Throwable) {
            NO_SKEW
        } finally {
            mats.forEach { runCatching { it.release() } }
        }
    }

    private fun round2(v: Double): Double = Math.round(v * 100.0) / 100.0

    /** Rotates [bitmap] by [degrees] (OpenCV convention) about its centre, keeping its size and
     *  filling the exposed corners with white. */
    fun straighten(bitmap: Bitmap, degrees: Double): Bitmap {
        if (abs(degrees) < 1e-3) return bitmap
        val mats = ArrayList<Mat>()
        fun track(m: Mat): Mat { mats.add(m); return m }
        return try {
            val src = track(Mat())
            Utils.bitmapToMat(bitmap, src)
            val m = track(Geometry.getRotationMatrix2D(Point(src.cols() / 2.0, src.rows() / 2.0), degrees, 1.0))
            val dst = track(Mat())
            Imgproc.warpAffine(
                src, dst, m, src.size(), Imgproc.INTER_LINEAR, Core.BORDER_CONSTANT, Scalar(255.0, 255.0, 255.0, 255.0)
            )
            toBitmap(dst)
        } catch (t: Throwable) {
            bitmap
        } finally {
            mats.forEach { runCatching { it.release() } }
        }
    }

    private fun toBitmap(rgba: Mat): Bitmap {
        val result = Bitmap.createBitmap(rgba.cols(), rgba.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(rgba, result)
        return result
    }
}
