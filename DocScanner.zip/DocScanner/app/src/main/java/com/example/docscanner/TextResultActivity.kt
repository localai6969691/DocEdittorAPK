package com.example.docscanner

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.docscanner.databinding.ActivityTextResultBinding
import java.io.File

class TextResultActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTextResultBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTextResultBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val path = intent.getStringExtra(EXTRA_TEXT_FILE_PATH)
        val text = path?.let { runCatching { File(it).readText() }.getOrNull() }
        binding.tvRecognizedText.text = text?.takeIf { it.isNotBlank() } ?: getString(R.string.no_text_found)

        binding.btnCopyText.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("scanned_text", binding.tvRecognizedText.text))
            Toast.makeText(this, R.string.text_copied, Toast.LENGTH_SHORT).show()
        }
    }

    companion object {
        const val EXTRA_TEXT_FILE_PATH = "extra_text_file_path"
    }
}
