package com.example.docscanner

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.docscanner.databinding.ActivityLicensesBinding

/**
 * Shows `assets/THIRD_PARTY_NOTICES.txt`. Apache License 2.0 (PdfBox-Android, OpenCV, AndroidX...)
 * requires passing on a copy of the licence and the NOTICE text with the app; an in-app screen is
 * the usual way to do that for an Android app. Linked from the bottom of the main screen.
 */
class LicensesActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityLicensesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.licenses_title)
        binding.tvLicenses.text = runCatching {
            assets.open("THIRD_PARTY_NOTICES.txt").bufferedReader(Charsets.UTF_8).use { it.readText() }
        }.getOrElse { getString(R.string.licenses_load_failed) }
    }
}
