package com.example.docscanner.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.encryption.AccessPermission
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.pdmodel.encryption.StandardProtectionPolicy
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.util.Matrix
import java.io.File
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Password protection and text watermark for PDFs - two features paid PDF SDKs (Apryse, PSPDFKit, Foxit)
 * sell as "security" and "stamp" modules, done here with PdfBox-Android alone (Apache 2.0).
 *
 *  - [protect]: standard security handler with AES-256 (PDF 2.0 style, `setEncryptionKeyLength(256)`,
 *    the documented PdfBox 2.0 cookbook recipe). The password opens the file; printing and copying stay
 *    allowed. The result is only kept after it was re-opened WITH the password (same page count) and
 *    shown to REFUSE opening without one - a "protected" file that opens freely would be worse than none.
 *  - [unprotect]: opens with the given password and writes a copy without any encryption.
 *  - [watermark]: the text is drawn into a transparent bitmap with Android's own text engine (so
 *    Vietnamese and every other script the phone can draw work, and no PDF font has to be embedded),
 *    added as an image with an alpha mask, and laid diagonally over the centre of every page. The angle
 *    accounts for `/Rotate` so it reads at 45 degrees on the displayed page (checked with poppler on
 *    /Rotate 0/90/180/270 and a CropBox in tools/verify/watermark_check.py).
 * All three write a NEW file; the input is only read.
 */
object PdfSecurityTools {

    class WrongPassword : Exception()

    private fun memory(src: File) = MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile)

    fun protect(src: File, out: File, password: String): Int {
        require(password.isNotEmpty()) { "empty password" }
        val doc = PDDocument.load(src, memory(src))
        try {
            if (doc.isEncrypted) throw IllegalStateException("already encrypted")
            val pages = doc.numberOfPages
            val policy = StandardProtectionPolicy(password, password, AccessPermission())
            policy.encryptionKeyLength = 256
            doc.protect(policy)
            doc.save(out)
            doc.close()

            // (1) it must open WITH the password and have the same pages ...
            val withPassword = try {
                PDDocument.load(out, password).use { it.numberOfPages }
            } catch (e: Exception) { -1 }
            // (2) ... and must refuse to open WITHOUT one
            val opensFree = try { PDDocument.load(out).use { true } } catch (e: InvalidPasswordException) { false } catch (e: Exception) { false }
            if (withPassword != pages || opensFree) {
                runCatching { out.delete() }
                throw IllegalStateException("protection check failed")
            }
            return pages
        } finally {
            runCatching { doc.close() }
        }
    }

    fun unprotect(src: File, out: File, password: String): Int {
        val doc = try {
            PDDocument.load(src, password, memory(src))
        } catch (e: InvalidPasswordException) {
            throw WrongPassword()
        }
        try {
            val pages = doc.numberOfPages
            doc.isAllSecurityToBeRemoved = true
            doc.save(out)
            doc.close()
            if (!PdfVerify.opensAsPdf(out, pages)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
            return pages
        } finally {
            runCatching { doc.close() }
        }
    }

    fun watermark(src: File, out: File, text: String): Int {
        require(text.isNotBlank()) { "empty text" }
        val memory = memory(src)
        val doc = PDDocument.load(src, memory)
        try {
            if (doc.isEncrypted) throw IllegalStateException("encrypted")
            val pages = doc.numberOfPages
            val bmp = renderWatermark(text.trim())
            val image = LosslessFactory.createFromImage(doc, bmp)
            for (i in 0 until pages) {
                val page = doc.getPage(i)
                val crop = page.cropBox
                val cw = crop.width
                val ch = crop.height
                val cx = crop.lowerLeftX + cw / 2
                val cy = crop.lowerLeftY + ch / 2
                val widthPt = min(cw, ch) * 0.9f
                val heightPt = widthPt * bmp.height / bmp.width
                // 45 degrees on the DISPLAYED page: a page shown rotated by r needs 45 + r in user space
                val theta = Math.toRadians(45.0 + page.rotation)
                PDPageContentStream(doc, page, PDPageContentStream.AppendMode.APPEND, true, true).use { cs ->
                    cs.saveGraphicsState()
                    cs.transform(Matrix(cos(theta).toFloat(), sin(theta).toFloat(), -sin(theta).toFloat(), cos(theta).toFloat(), cx, cy))
                    cs.drawImage(image, -widthPt / 2, -heightPt / 2, widthPt, heightPt)
                    cs.restoreGraphicsState()
                }
            }
            bmp.recycle()
            PdfStructureOptimizer.save(doc, out)
            if (!PdfVerify.opensAsPdf(out, pages)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
            return pages
        } finally {
            runCatching { doc.close() }
        }
    }

    /** Grey, semi-transparent, bold text on a transparent bitmap just big enough for it. */
    private fun renderWatermark(text: String): Bitmap {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(90, 128, 128, 128)
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textSize = 160f
        }
        val width = (paint.measureText(text) + 40f).toInt().coerceIn(200, 4000)
        val fm = paint.fontMetrics
        val height = (fm.descent - fm.ascent + 40f).toInt().coerceAtLeast(120)
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        Canvas(bmp).drawText(text, 20f, 20f - fm.ascent, paint)
        return bmp
    }
}
