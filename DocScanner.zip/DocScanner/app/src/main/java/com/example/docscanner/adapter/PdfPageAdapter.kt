package com.example.docscanner.adapter

import android.graphics.Bitmap
import android.graphics.Matrix
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.databinding.ItemPdfPageBinding
import com.example.docscanner.util.FileUtils

/** UI state for one page inside the PDF page-manager tool. */
data class PdfPageItem(
    val path: String,
    var rotationDeg: Int = 0,
    var selected: Boolean = false
)

class PdfPageAdapter(
    private val onDelete: (Int) -> Unit,
    private val onRotate: (Int) -> Unit,
    private val onToggleSelect: (Int) -> Unit
) : RecyclerView.Adapter<PdfPageAdapter.ViewHolder>() {

    private val items = mutableListOf<PdfPageItem>()

    fun submitList(pages: List<PdfPageItem>) {
        items.clear()
        items.addAll(pages)
        notifyDataSetChanged()
    }

    fun moveItem(from: Int, to: Int) {
        if (from < 0 || to < 0 || from >= items.size || to >= items.size) return
        val item = items.removeAt(from)
        items.add(to, item)
        notifyItemMoved(from, to)
    }

    inner class ViewHolder(val binding: ItemPdfPageBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemPdfPageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.binding.tvPageNumber.text = (position + 1).toString()

        val thumb = FileUtils.decodeSampledBitmap(item.path, 400, 600)
        if (thumb != null && item.rotationDeg != 0) {
            val matrix = Matrix().apply { postRotate(item.rotationDeg.toFloat()) }
            val rotated = Bitmap.createBitmap(thumb, 0, 0, thumb.width, thumb.height, matrix, true)
            holder.binding.ivPageThumb.setImageBitmap(rotated)
        } else {
            holder.binding.ivPageThumb.setImageBitmap(thumb)
        }

        holder.binding.selectedOverlay.visibility = if (item.selected) View.VISIBLE else View.INVISIBLE
        holder.binding.ivSelectedCheck.visibility = if (item.selected) View.VISIBLE else View.INVISIBLE

        holder.binding.ivPageThumb.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onToggleSelect(pos)
        }
        holder.binding.btnRotatePage.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onRotate(pos)
        }
        holder.binding.btnDeletePage.setOnClickListener {
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) onDelete(pos)
        }
    }

    override fun getItemCount(): Int = items.size
}
