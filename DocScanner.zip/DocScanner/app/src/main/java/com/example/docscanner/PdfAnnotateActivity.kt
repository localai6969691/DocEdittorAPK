package com.example.docscanner

import android.graphics.Color
import android.graphics.PointF
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityPdfAnnotateBinding
import com.example.docscanner.model.ScanSessionManager
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfImportHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileOutputStream

/**
 * "Chú thích PDF" - draw/write/whiteout on top of page images, then flatten the result into a new
 * PDF (or, for a single scanned page, back into the current scan session). See
 * [com.example.docscanner.view.AnnotationCanvasView]'s own doc comment for what "flatten" means
 * here and why this is a rasterizing, not a real-PDF-annotation-object, tool - consistent with
 * every other PDF-writing tool in this app.
 *
 * Two independent entry points/modes, chosen by which Intent extra is present:
 *  - No image-path extra present: launches the file picker itself in [onCreate] - an arbitrary
 *    external PDF. Every page is rendered once via [PdfImportHelper], annotated one at a time, and
 *    the final Save writes a brand new PDF (via [PdfExporter.exportImagePaths], already used
 *    elsewhere for exactly this "list of page images -> one PDF" job).
 *  - [EXTRA_IMAGE_PATH] + [EXTRA_SESSION_PAGE_INDEX]: ONE page of the current scan session
 *    (`PageListActivity`'s per-page "Chú thích" action). Save flattens that one page and calls
 *    [ScanSessionManager.replaceFile] - the app's normal way for a page-level editor to hand a
 *    changed file back to the session (`CropActivity` does the same for its own re-crop/re-filter
 *    saves).
 *
 * A page's annotations are baked into its own bitmap/file as soon as the user navigates away from
 * it (previous/next page, or Save) - there is no per-page undo history kept once you've left a
 * page, only for the page currently showing. This keeps all annotation STATE inside
 * [com.example.docscanner.view.AnnotationCanvasView] itself (reset on every
 * [com.example.docscanner.view.AnnotationCanvasView.loadPage] call) rather than this Activity
 * needing to track a separate elements-list per page.
 *
 * **Giới hạn đã biết, nói thẳng không né** (see TECHNICAL_DOCS.md for the fuller picture): unlike
 * `PdfPageEditorActivity`/`EbookExportActivity`, this tool has NO backup/restore across process
 * death yet - a kill mid-session (external-PDF mode especially, which can span many pages) loses
 * whatever wasn't already flattened+saved. Mitigated only with a plain "discard unsaved changes?"
 * confirmation on exit (see [onBackPressedOrUp]) - not full JSON state persistence like the other
 * multi-step editors. Accepted for a first version rather than left silent; a real fix would
 * follow the exact same `model.*State` pattern already used elsewhere (see
 * `model.PdfEditorState`/`model.EbookEditorState`) if this turns out to need it.
 */
class PdfAnnotateActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPdfAnnotateBinding

    /** Single-page mode only - the session index to write back to on save. */
    private var sessionPageIndex: Int = -1
    private var singlePageMode = false

    /** Current working copy of every page's file, in order - for single-page mode this always
     *  has exactly 1 entry. Each entry is overwritten in place (flattened bitmap re-written to the
     *  SAME path) whenever the user navigates away from that page - see the class doc comment. */
    private val workingPaths = mutableListOf<String>()
    private var currentIndex = 0
    private var pendingTextPoint: PointF? = null

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            loadPdfPages(uri)
        } else {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // targetSdk 36: Activity.onBackPressed() is no longer called (predictive back) - use the
        // dispatcher instead.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                onBackPressedOrUp()
            }
        })
        binding = ActivityPdfAnnotateBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.tool_annotate_title)

        val imagePath = intent.getStringExtra(EXTRA_IMAGE_PATH)
        sessionPageIndex = intent.getIntExtra(EXTRA_SESSION_PAGE_INDEX, -1)
        if (imagePath != null && sessionPageIndex >= 0) {
            singlePageMode = true
            workingPaths.add(imagePath)
            showPage(0)
        } else {
            pdfPicker.launch(arrayOf("application/pdf"))
        }

        setupToolbarControls()

        binding.btnPrevPage.setOnClickListener { navigateTo(currentIndex - 1) }
        binding.btnNextPage.setOnClickListener { navigateTo(currentIndex + 1) }
        binding.btnSaveAnnotated.setOnClickListener { saveAndExit() }

        binding.annotationCanvas.onTextTap = { point ->
            pendingTextPoint = point
            showTextInputDialog()
        }
    }

    private fun setupToolbarControls() {
        binding.btnToolPen.setOnClickListener { binding.annotationCanvas.mode = com.example.docscanner.view.AnnotationCanvasView.Mode.PEN }
        binding.btnToolText.setOnClickListener { binding.annotationCanvas.mode = com.example.docscanner.view.AnnotationCanvasView.Mode.TEXT }
        binding.btnToolRedact.setOnClickListener { binding.annotationCanvas.mode = com.example.docscanner.view.AnnotationCanvasView.Mode.REDACT }
        binding.btnUndo.setOnClickListener {
            if (binding.annotationCanvas.canUndo()) binding.annotationCanvas.undo()
        }

        val colors = listOf(
            binding.colorSwatch1 to Color.BLACK,
            binding.colorSwatch2 to Color.RED,
            binding.colorSwatch3 to Color.BLUE,
            binding.colorSwatch4 to Color.parseColor("#FFEB3B") // highlighter yellow
        )
        colors.forEach { (view, color) ->
            view.setBackgroundColor(color)
            view.setOnClickListener { binding.annotationCanvas.currentColor = color }
        }
        binding.annotationCanvas.currentColor = Color.RED

        binding.btnSizeSmall.setOnClickListener { binding.annotationCanvas.setSizePreset(small = true) }
        binding.btnSizeMedium.setOnClickListener { binding.annotationCanvas.setSizePreset(medium = true) }
        binding.btnSizeLarge.setOnClickListener { binding.annotationCanvas.setSizePreset(large = true) }
    }

    private fun showTextInputDialog() {
        val editText = layoutInflater.inflate(R.layout.dialog_annotate_text, null) as EditText
        AlertDialog.Builder(this)
            .setTitle(R.string.annotate_tool_text)
            .setView(editText)
            .setPositiveButton(R.string.dialog_ok) { _, _ ->
                val text = editText.text?.toString().orEmpty()
                val point = pendingTextPoint
                if (text.isNotBlank() && point != null) {
                    binding.annotationCanvas.addText(text, point)
                }
                pendingTextPoint = null
            }
            .setNegativeButton(R.string.dialog_cancel) { _, _ -> pendingTextPoint = null }
            .setOnCancelListener { pendingTextPoint = null }
            .show()
    }

    private fun loadPdfPages(uri: Uri) {
        setBusy(true, getString(R.string.annotate_loading))
        lifecycleScope.launch {
            val paths = withContext(Dispatchers.IO) {
                PdfImportHelper.renderAllPagesToFiles(
                    this@PdfAnnotateActivity, uri, dpi = 200,
                    fileFactory = { i -> FileUtils.newAnnotatePageFile(this@PdfAnnotateActivity, i) }
                )
            }
            setBusy(false, null)
            if (paths.isEmpty()) {
                Toast.makeText(this@PdfAnnotateActivity, getString(R.string.annotate_load_failed), Toast.LENGTH_LONG).show()
                finish()
                return@launch
            }
            workingPaths.clear()
            workingPaths.addAll(paths)
            showPage(0)
        }
    }

    private fun showPage(index: Int) {
        currentIndex = index
        val bitmap = android.graphics.BitmapFactory.decodeFile(workingPaths[index])
        if (bitmap != null) binding.annotationCanvas.loadPage(bitmap)
        binding.pageNavRow.visibility = if (workingPaths.size > 1) View.VISIBLE else View.GONE
        binding.tvPageIndicator.text = getString(R.string.annotate_page_indicator, index + 1, workingPaths.size)
        binding.btnPrevPage.isEnabled = index > 0
        binding.btnNextPage.isEnabled = index < workingPaths.size - 1
    }

    /** Bakes the current page's annotations into its file (see the class doc comment for why this
     *  happens on every navigation, not just on final Save), overwriting the SAME path so
     *  [workingPaths] never needs to change - only the bytes at that path do. No-op if nothing was
     *  drawn on this page, so re-visiting an already-annotated page without changing it doesn't
     *  re-compress the JPEG for no reason. */
    private fun flattenCurrentPageToDisk() {
        if (!binding.annotationCanvas.hasUnsavedEdits()) return
        val flattened = binding.annotationCanvas.flatten() ?: return
        val path = workingPaths[currentIndex]
        FileOutputStream(path).use { out -> flattened.compress(android.graphics.Bitmap.CompressFormat.JPEG, 92, out) }
        flattened.recycle()
    }

    private fun navigateTo(index: Int) {
        if (index !in workingPaths.indices) return
        flattenCurrentPageToDisk()
        showPage(index)
    }

    private fun saveAndExit() {
        flattenCurrentPageToDisk()
        if (singlePageMode) {
            ScanSessionManager.replaceFile(sessionPageIndex, workingPaths[0])
            Toast.makeText(this, R.string.annotate_saved, Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        setBusy(true, getString(R.string.annotate_exporting))
        lifecycleScope.launch {
            val outFile = withContext(Dispatchers.Default) {
                PdfExporter.exportImagePaths(
                    context = this@PdfAnnotateActivity,
                    imagePaths = workingPaths,
                    rotations = List(workingPaths.size) { 0 },
                    baseName = "annotated_${FileUtils.defaultDocName()}",
                    sourceDpi = 200f
                )
            }
            setBusy(false, null)
            Toast.makeText(
                this@PdfAnnotateActivity,
                getString(R.string.export_success, outFile.name),
                Toast.LENGTH_LONG
            ).show()
            cleanupWorkingFiles()
            finish()
        }
    }

    /** Clears every leftover per-page working file this tool ever wrote for THIS mode
     *  (external-PDF mode only - [FileUtils.annotatePagesDir] is exclusively this tool's own
     *  scratch space, single-page mode never writes into it, so this is always safe to empty
     *  outright). Called once the working files are no longer needed - either exported into a
     *  final PDF, or the user explicitly chose to discard them (see [onBackPressedOrUp]) - so a
     *  session that never finishes this tool's flow doesn't leave orphaned JPEGs behind forever. */
    private fun cleanupWorkingFiles() {
        if (singlePageMode) return
        FileUtils.annotatePagesDir(this).listFiles()?.forEach { runCatching { it.delete() } }
    }

    private fun setBusy(busy: Boolean, message: String?) {
        binding.progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        binding.tvProgress.visibility = if (busy && message != null) View.VISIBLE else View.GONE
        binding.tvProgress.text = message
        binding.btnSaveAnnotated.isEnabled = !busy
    }

    /** Only a plain confirmation, not real backup/restore - see the class doc comment's "Giới hạn
     *  đã biết". Only asks when there is something to lose: either the current page has
     *  un-flattened edits, or (external-PDF mode) an earlier page in this session was already
     *  flattened to its working file and would be discarded along with it - a single-page mode
     *  visit with nothing drawn just exits immediately like any other cancel. */
    private fun onBackPressedOrUp(): Boolean {
        val hasAnythingToLose = binding.annotationCanvas.hasUnsavedEdits() ||
            (!singlePageMode && workingPaths.size > 1 && currentIndex > 0)
        if (!hasAnythingToLose) {
            finish()
            return true
        }
        AlertDialog.Builder(this)
            .setMessage(R.string.annotate_discard_confirm)
            .setPositiveButton(R.string.annotate_discard_yes) { _, _ ->
                cleanupWorkingFiles()
                finish()
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
        return true
    }

    companion object {
        const val EXTRA_IMAGE_PATH = "extra_image_path"
        const val EXTRA_SESSION_PAGE_INDEX = "extra_session_page_index"
    }
}
