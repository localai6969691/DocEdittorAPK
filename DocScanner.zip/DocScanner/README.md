# Quét & Chỉnh Sửa PDF (DocScanner)

Ứng dụng Android (Kotlin) kiểu CamScanner: chụp ảnh / nhập ảnh từ thư viện / nhập từ PDF khác
→ tự động phát hiện & chỉnh biên tài liệu → lọc màu/xám/trắng đen → ghép thành PDF, kèm các công
cụ chỉnh sửa PDF khác (ghép nhiều file, quản lý trang, tối ưu cho máy đọc sách e-ink), và OCR
nhận diện văn bản.

## Tính năng

- **Quét tài liệu**: chụp bằng camera (CameraX), chọn nhiều ảnh từ thư viện, hoặc nhập từ 1 file
  PDF khác — tất cả đều đi qua cùng bước tự động phát hiện 4 góc tài liệu (OpenCV) + cho chỉnh tay,
  rồi làm phẳng phối cảnh (perspective warp).
- **Tách ảnh chụp 2 trang sách**: nếu 1 ảnh chụp được cả 2 trang sách mở phẳng, có nút "Tách 2
  trang" (trước khi crop) để tách thành 2 ảnh trang đơn đúng thứ tự đọc, kéo tay chỉnh đúng gáy
  sách (có gợi ý tự động vị trí ban đầu).
- **Bộ lọc mỗi trang**: Màu gốc / Tăng sáng / Xám / Trắng đen (ngưỡng thích ứng) — có gợi ý tự động
  chọn sẵn Trắng đen hay Tăng sáng tuỳ trang đó có màu thật hay không.
- **Bộ lọc hàng loạt** (trong màn hình danh sách trang): áp 1 trong 6 chế độ cho toàn bộ tài liệu,
  gồm cả chế độ **Tự động** (mỗi trang tự nhận diện đen trắng/màu và xử lý phù hợp) và 2 preset tối
  ưu riêng cho máy đọc sách e-ink.
- **OCR**: nhận diện văn bản (ML Kit, chạy offline, không cần mạng), lưu kèm file `.txt`.
- **Tạo Ebook**: sau khi OCR, xuất EPUB và/hoặc TXT, có thể tự chọn mục lục (đánh dấu trang nào bắt
  đầu chương mới + đặt tên chương).
- **Ghép nhiều PDF** thành 1 file.
- **Quản lý trang PDF**: xoay, xoá, sắp xếp lại, chọn trang để tách riêng — từ 1 file PDF có sẵn.
- **Xuất PDF thành ảnh** (JPG từng trang).
- **Nén PDF đã quét**: giảm dung lượng nhiều lần mà chữ không vỡ ảnh — nhị phân hoá đen trắng rồi
  nén không mất dữ liệu, 2 cách chọn được: "An toàn" (1-bit + Deflate) hoặc "CCITT Group 4" (đúng
  công nghệ máy scan thật dùng, nén sâu hơn, tự kiểm tra lại kết quả trước khi dùng — xem giới hạn
  bên dưới). Trang có ảnh màu/ảnh chụp được nén JPEG riêng, không áp cho trang chữ.
- **Chuyển đổi định dạng**: PDF ↔ EPUB ↔ TXT ↔ Ảnh — 1 công cụ chung, chọn nguồn rồi chọn đích.
  Khi đọc EPUB, tên chương được lấy từ đúng mục lục gốc của file (không chỉ đoán qua nội dung).
  PDF xuất từ EPUB/TXT có thử thêm bookmark điều hướng thật (best-effort — không có cũng không sao,
  file vẫn dùng bình thường, xem giới hạn bên dưới).
- **Tự lưu phiên quét**: nếu app bị hệ thống tắt/crash/máy khởi động lại giữa chừng lúc đang quét,
  mở lại app sẽ hỏi khôi phục đúng những trang đã chụp trước đó thay vì mất hết.

## Vì sao chọn Trắng đen / Giữ màu cho e-ink

Xem giải thích chi tiết trong lịch sử trò chuyện đã tạo ra dự án này — tóm tắt: hầu hết máy đọc
sách màu hiện nay (Kaleido 3: Kobo Libra/Clara Colour, Kindle Colorsoft, PocketBook Era Color...)
hiển thị đen trắng ở 300ppi nhưng chỉ 150ppi khi hiển thị màu, vì lớp lọc màu phủ trên nền đen
trắng. Nên trang chữ thuần luôn nên để trắng đen (kể cả trên máy màu), chỉ trang có màu thật sự
quan trọng mới nên giữ màu.

## Giới hạn cần biết

- Các công cụ Ghép PDF / Quản lý trang PDF hoạt động bằng cách **render từng trang PDF gốc thành
  ảnh rồi dựng lại thành PDF mới** (dùng `PdfRenderer` + `PdfDocument` có sẵn trong Android, không
  dùng thư viện PDF ngoài để tránh rủi ro build lỗi). Hệ quả: nếu PDF gốc có chữ thật (chọn/copy
  được), sau khi qua các công cụ này chữ sẽ thành ảnh, không copy được nữa — trừ khi bật OCR để lấy
  lại văn bản dưới dạng file `.txt` riêng.
- OCR chỉ tạo file `.txt` đi kèm, **không** nhúng lớp văn bản có thể tìm kiếm vào trong PDF.
- **Ebook chỉ xuất EPUB và TXT**, không hỗ trợ MOBI/AZW3 (Amazon đã ngừng nhận MOBI từ 3/2025, và
  Kindle nhận EPUB trực tiếp qua Send-to-Kindle từ 2022, nên không cần MOBI nữa). File EPUB được tự
  viết bằng `java.util.zip` theo đúng chuẩn EPUB3, **nhưng chưa được mở thử bằng app đọc sách thật
  nào** — nếu gặp lỗi khi mở, báo lại để chỉnh.
- **Nén PDF, chế độ "CCITT G4" là thử nghiệm**: thuật toán đã được kiểm chứng rất kỹ bằng cách viết
  và đối chiếu byte-for-byte với thư viện chuẩn công nghiệp (libtiff) trước khi chuyển sang Kotlin,
  và app tự giải mã lại để so khớp với ảnh gốc trước khi dùng kết quả — nếu có lỗi sẽ tự rơi về chế
  độ "An toàn" cho đúng trang đó, không thể ra file hỏng. Nhưng bản Kotlin thật sự thì **chưa từng
  chạy trên thiết bị Android** — nếu chế độ này báo lỗi hoặc luôn rơi về "An toàn", báo lại.
- **Bookmark trong PDF xuất từ EPUB/TXT là best-effort**: vì Android không cho cách chính thức nào
  để thêm bookmark vào PDF, app tự vá thêm vào sau — dựa vào cấu trúc file không có tài liệu chính
  thức, không cách nào kiểm chứng trước khi có máy thật. Có bookmark hay không tuỳ máy, nhưng file
  luôn hợp lệ và dùng bình thường dù có hay không.
- Dự án dùng OpenCV bản chính thức trên Maven Central (`org.opencv:opencv:5.0.0.1`) và ML Kit Text
  Recognition bản đóng gói sẵn (`com.google.mlkit:text-recognition`) — cả hai đều chạy hoàn toàn
  offline trên máy, không cần API key.
- **Code này chưa được build-test thật** (môi trường tạo ra nó không có Android SDK/mạng để chạy
  Gradle). Nếu GitHub Actions báo lỗi build, gửi lại log lỗi để sửa tiếp.

## Cách build ra file APK bằng GitHub Actions (không cần máy tính cài Android Studio)

1. Tạo một repository mới trên GitHub (public hoặc private đều được).
2. Giải nén file zip này, upload **toàn bộ nội dung thư mục** (không phải bản thân thư mục
   `DocScanner`) lên repo đó — có thể dùng giao diện web "Add file → Upload files" của GitHub, kéo
   thả cả cây thư mục vào.
3. Vào tab **Actions** của repo → sẽ thấy workflow "Build APK" tự chạy sau khi upload xong (nhánh
   `main`). Nếu chưa chạy, bấm **Run workflow** thủ công.
4. Đợi build xong (vài phút), bấm vào lần chạy đó → phần **Artifacts** ở cuối trang → tải file
   `docscanner-debug-apk.zip` → giải nén ra sẽ có file `.apk`.
5. Chuyển file `.apk` vào điện thoại Android (qua Google Drive, Zalo, cáp USB...) → mở file đó để
   cài (cần cho phép "Cài ứng dụng không rõ nguồn gốc" cho ứng dụng dùng để mở file lần đầu).

Đây là bản build **debug** (chưa ký release) — cài trực tiếp lên máy để dùng thử là dùng được bình
thường, chỉ không đăng lên Play Store được (Play Store cần bản ký release).

## Cấu trúc dự án

```
app/src/main/java/com/example/docscanner/
├── MainActivity.kt          # màn hình chính - 5 công cụ + lịch sử
├── CaptureActivity.kt       # camera (CameraX)
├── CropActivity.kt          # tách 2 trang (tuỳ chọn) + chỉnh 4 góc + chọn bộ lọc
├── PageListActivity.kt      # danh sách trang của phiên quét hiện tại + xuất PDF/Ebook
├── PdfMergeActivity.kt      # ghép nhiều PDF
├── PdfPageEditorActivity.kt # xoay/xoá/sắp xếp/tách trang PDF
├── EbookExportActivity.kt   # chạy OCR, soạn mục lục, xuất EPUB/TXT
├── TextResultActivity.kt    # xem văn bản OCR
├── model/                   # ScanPage, ScanSessionManager, PendingCropQueue
├── util/                    # ImageProcessor (OpenCV), PdfExporter, PdfImportHelper, OcrHelper,
│                             # EbookBuilder, PdfCompressor, Ccitt4Encoder/Decoder
├── view/                    # CropOverlayView, SplitLineOverlayView (kéo-thả)
└── adapter/                 # các RecyclerView adapter
```
