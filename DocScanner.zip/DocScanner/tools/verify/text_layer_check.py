# Python mirror of SearchablePdfBuilder (font + content generation), tested with independent readers.
import pikepdf, sys, subprocess, re, zlib
from _common import OUT
from pikepdf import Name, Dictionary, Array, Stream

GLYPH_W, SPACE_W, CODES_PER_FONT = 500, 200, 250

def utf16hex(cp): return chr(cp).encode('utf-16-be').hex().upper()

def tounicode(cps):
    s = "/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n"
    s += "/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n"
    s += "/CMapName /Adobe-Identity-UCS def\n/CMapType 2 def\n1 begincodespacerange\n<01> <FF>\nendcodespacerange\n"
    for i in range(0, len(cps), 100):
        chunk = cps[i:i+100]
        s += f"{len(chunk)} beginbfchar\n"
        for j, cp in enumerate(chunk): s += "<%02X> <%s>\n" % (i+j+1, utf16hex(cp))
        s += "endbfchar\n"
    s += "endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend\n"
    return s.encode()

def build_font(pdf, cps):
    glyph = pdf.make_stream(f"{GLYPH_W} 0 d0\n".encode())
    charprocs = Dictionary(); diffs = Array([1]); widths = Array()
    for i, cp in enumerate(cps):
        n = f"g{i+1}"; charprocs[Name("/"+n)] = glyph; diffs.append(Name("/"+n))
        widths.append(SPACE_W if cp == 0x20 else GLYPH_W)
    return pdf.make_indirect(Dictionary(
        Type=Name.Font, Subtype=Name.Type3, FontBBox=Array([0,-200,GLYPH_W,800]),
        FontMatrix=Array([0.001,0,0,0.001,0,0]), CharProcs=charprocs,
        Encoding=Dictionary(Type=Name.Encoding, Differences=diffs),
        FirstChar=1, LastChar=len(cps), Widths=widths,
        ToUnicode=pdf.make_stream(tounicode(cps))))

class Geo:
    def __init__(s, w, h, rot):
        s.cw, s.ch, s.rot = w, h, rot % 360
        s.vw, s.vh = (h, w) if s.rot in (90, 270) else (w, h)
        s.a = {90:0,180:-1,270:0}.get(s.rot,1); s.b = {90:1,180:0,270:-1}.get(s.rot,0)
        s.c, s.d = -s.b, s.a
    def to_user(s, u, v):
        r = s.rot
        if r == 90: return v, u
        if r == 180: return s.cw-u, v
        if r == 270: return s.cw-v, s.ch-u
        return u, s.ch-v

def content(geo, bw, bh, lines, index_of):
    sx, sy = geo.vw/bw, geo.vh/bh
    out = ["q\nBT\n3 Tr\n"]
    for line in lines:
        for wi, (text, (l, t, r, b)) in enumerate(line):
            left, right, top, bottom = l*sx, r*sx, t*sy, b*sy
            h, w = bottom-top, right-left
            if h < 1 or w < 1: continue
            cps = [c for c in map(ord, text) if c in index_of]
            if not cps: continue
            fs = h; tz = max(1, min(5000, 100*w/(len(cps)*0.5*fs)))
            x0, y0 = geo.to_user(left, bottom-0.2*h)
            if wi < len(line)-1: cps.append(0x20)
            adv = 0; i = 0
            while i < len(cps):
                fi = index_of[cps[i]] // CODES_PER_FONT; hx = ""; run = 0
                while i < len(cps) and index_of[cps[i]] // CODES_PER_FONT == fi:
                    hx += "%02X" % (index_of[cps[i]] % CODES_PER_FONT + 1)
                    run += SPACE_W if cps[i] == 0x20 else GLYPH_W; i += 1
                ap = adv/1000*fs*tz/100
                ox, oy = x0 + geo.a*ap, y0 + geo.b*ap
                out.append(f"/OcrF{fi+1} {fs:.3f} Tf {tz:.3f} Tz {geo.a} {geo.b} {geo.c} {geo.d} {ox:.3f} {oy:.3f} Tm <{hx}> Tj\n")
                adv += run
    out.append("ET\nQ\n")
    return "".join(out).encode()

def make(path, rot):
    pdf = pikepdf.new()
    page = pdf.add_blank_page(page_size=(595, 842))
    page.Rotate = rot
    # visible content so the page is not empty: a rectangle
    page.Contents = pdf.make_stream(b"0.8 g 50 700 200 40 re f\n")
    BW, BH = 1653, 2339          # ~200 dpi bitmap of the *displayed* page (A4 portrait)
    if rot in (90, 270): BW, BH = BH, BW
    lines = [
        [("Cộng", (200, 300, 420, 360)), ("hòa", (450, 300, 600, 360)), ("xã", (630, 300, 720, 360)), ("hội", (750, 300, 880, 360))],
        [("Việt", (200, 420, 380, 480)), ("Nam", (410, 420, 600, 480)), ("Độc", (630, 420, 800, 480)), ("lập", (830, 420, 960, 480))],
        [("Hello,", (200, 540, 400, 600)), ("World!", (430, 540, 660, 600)), ("Ǆ", (700, 540, 760, 600))],
    ]
    allc = sorted({ord(ch) for ln in lines for w, _ in ln for ch in w} | {0x20})
    index_of = {cp: i for i, cp in enumerate(allc)}
    fonts = [build_font(pdf, allc[i:i+CODES_PER_FONT]) for i in range(0, len(allc), CODES_PER_FONT)]
    geo = Geo(595, 842, rot)
    page.Resources = Dictionary(Font=Dictionary({f"/OcrF{i+1}": f for i, f in enumerate(fonts)}))
    cs = content(geo, BW, BH, lines, index_of)
    page.Contents = Array([page.Contents, pdf.make_stream(cs)])
    pdf.save(path)
    return lines

if __name__ == "__main__":
    for rot in (0, 90, 180, 270):
        p = f"{OUT}/t3_{rot}.pdf"; make(p, rot)
        chk = subprocess.run(["qpdf", "--check", p], capture_output=True, text=True)
        print(f"--- rot {rot}: qpdf rc={chk.returncode}", (chk.stdout+chk.stderr).strip().splitlines()[-1])
        txt = subprocess.run(["pdftotext", "-enc", "UTF-8", p, "-"], capture_output=True, text=True)
        print(repr(txt.stdout.strip()[:200]), txt.stderr.strip()[:200])
