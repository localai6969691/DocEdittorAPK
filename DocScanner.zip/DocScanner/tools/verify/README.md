# Kiểm chứng bằng công cụ độc lập (không nằm trong app)

Các script Python này là bản song song (cùng thuật toán, cùng hằng số) của phần Kotlin ở phiên 11-15, dùng để thử ý tưởng bằng trình đọc
độc lập TRƯỚC khi có máy Android, và để tái hiện MỌI con số ghi trong `TECHNICAL_DOCS.md` mục 4.18-4.22. Không phải mã của ứng dụng,
không được đóng vào APK/AAB. Chạy từ thư mục này: `python3 <script>`; file tạm ghi vào `$VERIFY_OUT` (mặc định: thư mục tạm của hệ thống).

Cần: `pip install pikepdf pypdf pdfminer.six pdfplumber reportlab pillow opencv-python scikit-image numpy` và các lệnh `qpdf`, `pdftotext`/`pdftoppm` (poppler).

| Script | Kiểm gì | Mục tài liệu |
|---|---|---|
| `doc_sync_check.py` (chạy từ gốc dự án) | tài liệu khớp mã: file/layout/activity, bảng phiên bản, bảng hằng số, danh sách script này, các câu khẳng định đã cũ | 0, 3, 4.21 |
| `text_layer_check.py` | lớp chữ vô hình bằng font Type3 + ToUnicode + Tr 3, 4 hướng xoay trang; đọc lại bằng qpdf/poppler | 4.19 |
| `rotated_words_check.py` | đặt từ OCR nghiêng (cornerPoints) → ma trận chữ, 4 hướng xoay; đo góc đường cơ sở từ vị trí từng chữ | 4.20 |
| `highlight_height_check.py` | FontDescriptor/FontBBox có đổi chiều cao vùng bôi chọn không (poppler vs pdfplumber) | 4.20 |
| `structure_optimizer_check.py [vào.pdf ra.pdf]` | ghi object stream + xref stream + gộp stream trùng; qpdf/poppler/pypdf phải đọc giống bản gốc, poppler render đúng từng điểm ảnh (sinh PDF thử bằng `make_test_pdfs.py`) | 4.19 |
| `image_algorithms_check.py` | Sauvola (so với scikit-image, bảng IoU, quét k), tự thẳng chữ (dấu + độ chính xác), xóa bóng, đo mờ | 4.19 |
| `orientation_check.py` | nhận hướng 0/90/180/270: 480 trang Anh/Việt (xoay, nghiêng, nhiễu); trang số/chữ hoa/trắng/nhiễu phải bị từ chối | 4.20 |
| `dewarp_check.py` | duỗi dòng cong (phần DỌC): bowl/wave/half, và trang phẳng/2 cột/ảnh/bảng số/thưa phải giữ nguyên | 4.20 |
| `dewarp_horizontal_check.py` (+ `book_render.py`, `dewarp_model.py`) | trang sách cong mô phỏng vật lý có đáp án chuẩn (lưới chấm): sai số sửa dọc vs dọc + ngang, 27 tổ hợp | 4.21 |
| `tounicode_check.py` | bộ đảo ngược bảng `/ToUnicode` (bfchar + bfrange 2 dạng) cho font CID | 4.18 |
| `stability_check.py` | logic tự động chụp trên 10 tình huống mô phỏng | 4.20 |
| `shadow_edge_check.py` | xóa bóng viền gắt: so các cấu hình lọc, đánh đổi với ô xám | 4.20 |
| `watermark_check.py` | watermark chéo 45° đúng tâm trên trang xoay và có CropBox | 4.20 |
| `page_geometry_check.py` | ma trận đặt nội dung theo trang ĐANG HIỂN THỊ: xoay 0/90/180/270 × không/có CropBox lệch × MediaBox gốc âm (12 tổ hợp) với poppler `-cropbox` | 4.22 |
| `decorate_check.py` | số trang / đầu-chân trang / Bates: token, vị trí nhãn (hàm thuần) + 8 tổ hợp xoay × CropBox, đọc lại bằng `pdftotext -cropbox -bbox` (đúng chỗ, nằm ngang) | 4.22 |
| `stamp_check.py` | đặt ảnh trong suốt (chữ ký/tem) theo tỉ lệ trang: `rectFor` + 24 tổ hợp xoay × CropBox × 3 vị trí, poppler đo màu từng nửa ảnh và vùng trong suốt | 4.22 |
| `print_ranges_check.py` | phạm vi trang `PageRange` của hệ thống in (chỉ hàm thuần; in thật phải thử trên máy) | 4.22 |
| `app_lock_check.py` | logic khoá ứng dụng qua chuỗi sự kiện: khởi động nguội, đi lại trong app, ra ngoài 30/61 s, Home ở màn khoá, xoay màn hình, gỡ khoá màn hình, lỗi tạm thời | 4.22 |
| `backup_check.py` | `parseEntry`/`rebasePath`/khôi phục THẬT trên đĩa: zip-slip, symlink, không ghi đè, rebase `project.json`, ZIP lạ | 4.22 |
| `metadata_check.py` | sửa/xoá thông tin PDF phải bỏ cả XMP, nếu không tiêu đề cũ vẫn hiện (pikepdf + poppler; KHÔNG chạy PdfBox) | 4.22 |
| `static_refs_check.py` (chạy từ gốc dự án) | rà tĩnh thay compiler: `R.*`/`@…` tồn tại, trùng tên, `binding.x` có `android:id`, ngoặc cân bằng, Activity ↔ manifest | 4.22 |

Lưu ý: dữ liệu ảnh là TỔNG HỢP; kết quả trên ảnh chụp thật có thể khác. Các bản Python phải được giữ khớp với Kotlin: nếu đổi hằng số/thuật toán
trong Kotlin (ví dụ `TextLineDewarp.F_REL`, `DocumentEnhancer.SAUVOLA_K`) thì đổi cả bản Python tương ứng và bảng hằng số ở TECHNICAL_DOCS.md mục 4.21
(`doc_sync_check.py` bắt lệch ở bảng hằng số, KHÔNG bắt lệch giữa Kotlin và Python — việc đó phải làm tay).
