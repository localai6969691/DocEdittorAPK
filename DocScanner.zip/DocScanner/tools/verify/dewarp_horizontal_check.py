# Physically simulated curled book page (cylinder curl + pinhole camera) with exact ground truth:
# measures how well vertical-only and vertical+horizontal dewarping flatten a printed dot grid.
# Run from tools/verify:  python3 dewarp_horizontal_check.py
import sys, itertools, numpy as np
sys.path.insert(0, ".")
import book_render as B, orientation_check as O
import dewarp_model as M

tex = B.text_texture(O.EN * 2); dots, pts = B.dot_texture()
res, resV, base = [], [], []; refused = 0
for phi0, L, Hr in itertools.product((30, 45, 55), (0.15, 0.25, 0.4), (0.7, 1.0, 1.6)):
    img, _ = B.render(tex, phi0_deg=phi0, L_frac=L, H_over_Wp=Hr); dimg, _ = B.render(dots, phi0_deg=phi0, L_frac=L, H_over_Wp=Hr)
    fitted = M.fit_models(img); base.append(B.grid_residual(dimg, pts)[0])
    m, _ = M.dewarp_maps3(img, fitted=fitted); mv, _ = M.dewarp_maps3(img, fitted=fitted, horizontal=False)
    refused += m is None
    res.append(base[-1] if m is None else B.grid_residual(M.apply_maps(dimg, m), pts)[0])
    resV.append(base[-1] if mv is None else B.grid_residual(M.apply_maps(dimg, mv), pts)[0])
for name, arr in (("raw photo", base), ("vertical only", resV), ("vertical + horizontal", res)):
    a = np.array(arr); print(f"{name:24s} mean {a.mean():.2f}  median {np.median(a):.2f}  worst {a.max():.2f}   (% of page width)")
print(f"cases refused by the safety gates (page left untouched): {refused} of {len(base)}")
