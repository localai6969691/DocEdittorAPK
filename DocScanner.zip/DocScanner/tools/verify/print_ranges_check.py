"""Kiểm chứng PdfPrintAdapter.isSelected (phiên 15): trang 0-based có nằm trong các PageRange (đóng hai đầu) mà hệ thống in yêu cầu.

PageRange.ALL_PAGES = (0, Int.MAX_VALUE). Bản Python song song của hàm thuần trong PdfPrintAdapter.kt.
Phần còn lại của luồng in (PrintedPdfDocument, máy in/spooler) không chạy được trên máy tính -> kiểm trên thiết bị.
Chạy: python3 print_ranges_check.py
"""
import sys

INT_MAX = 2**31 - 1


def is_selected(ranges, index):
    return any(lo <= index <= hi for lo, hi in ranges)


def selected_pages(ranges, total):
    return [i for i in range(total) if is_selected(ranges, i)]


def main():
    cases = [
        ([(0, INT_MAX)], 5, [0, 1, 2, 3, 4], "tất cả"),
        ([(0, 0)], 5, [0], "một trang"),
        ([(1, 2), (4, 4)], 6, [1, 2, 4], "hai khoảng rời nhau"),
        ([(3, INT_MAX)], 5, [3, 4], "từ trang 4 đến hết"),
        ([(7, 9)], 5, [], "ngoài tài liệu -> không trang nào"),
        ([], 4, [], "không yêu cầu gì"),
        ([(2, 3), (3, 4)], 6, [2, 3, 4], "hai khoảng chạm nhau không in trùng"),
    ]
    bad = 0
    for ranges, total, want, what in cases:
        got = selected_pages(ranges, total)
        ok = got == want
        bad += 0 if ok else 1
        print("ok " if ok else "LOI", what, got, "" if ok else f"(mong đợi {want})")
    print("TAT CA DAT" if bad == 0 else f"{bad} TRUONG HOP LOI")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
