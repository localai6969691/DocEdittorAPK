# Physically-based synthetic "photo of a curled book page": flat page texture -> cylinder-like curl about the vertical spine
# -> pinhole camera looking straight down. Gives exact ground truth (flat coordinates) for evaluating dewarping.
import numpy as np, cv2
from _common import OUT
from PIL import Image, ImageDraw, ImageFont
import orientation_check as O

def curve(Wp, phi0_deg, L_frac, n=4000):
    """page points at distance d from the spine (d in 0..Wp). returns d, X (image-plane world x, spine at X=Wp), z (height toward camera)"""
    d = np.linspace(0, Wp, n); L = L_frac * Wp
    phi = np.radians(phi0_deg) * np.exp(-d / L)
    dd = d[1] - d[0]
    xs = np.cumsum(np.cos(phi)) * dd                     # horizontal distance covered from the spine
    zs = np.cumsum((np.sin(phi))[::-1])[::-1] * dd       # height above the table (0 at the far edge)
    zs = zs - zs[-1]
    return d, Wp - xs + xs[-1] * 0 , zs

def render(tex, phi0_deg=45, L_frac=0.25, f_over_H=1.0, H_over_Wp=1.0, out_size=None, spine="right", border=245):
    Hp, Wp = tex.shape
    d, X, z = curve(Wp, phi0_deg, L_frac)
    # page coordinate a (texture column) -> d = Wp - a for spine on the right
    H = H_over_Wp * Wp; f = f_over_H * H
    Xc = (X.min() + X.max()) / 2                            # camera above the middle of the flattened footprint
    depth = H - z
    xi = f * (X - Xc) / depth                               # image x (relative to centre) of the page point at distance d
    # monotonic in d? guard
    order = np.argsort(xi); xi_s = xi[order]; d_s = d[order]
    x_min, x_max = xi_s.min(), xi_s.max()
    pad = 40
    W_out = int(x_max - x_min) + 2 * pad
    H_out = int(Hp * f / (H - z.min()) * 1.02) + 2 * pad
    if out_size: W_out, H_out = out_size
    cx = -x_min + pad; cy = H_out / 2
    cols = np.arange(W_out) - cx
    d_of_col = np.interp(cols, xi_s, d_s, left=np.nan, right=np.nan)
    valid = ~np.isnan(d_of_col)
    z_of_col = np.interp(d_of_col, d, z)
    depth_col = H - z_of_col
    mapx = np.zeros((H_out, W_out), np.float32); mapy = np.zeros((H_out, W_out), np.float32)
    rows = (np.arange(H_out) - cy)[:, None]
    b = rows * depth_col[None, :] / f                       # flat vertical coordinate (relative to page centre)
    a = (Wp - d_of_col)[None, :].repeat(H_out, 0)
    mapx[:] = a; mapy[:] = b + Hp / 2
    img = cv2.remap(tex, mapx, mapy, cv2.INTER_LINEAR, borderValue=border)
    inval = (~valid)[None, :] | (mapy < 0) | (mapy > Hp - 1)
    img[inval] = border
    return img, (mapx, mapy, inval)

def text_texture(lines, font="DejaVuSans", size=26, w=1240, h=1754):
    return O.page(lines, O.FONTS[font], size, w=w, h=h)

def dot_texture(w=1240, h=1754, step=110, r=5):
    t = np.full((h, w), 245, np.uint8); pts = []
    for by, y in enumerate(range(130, h - 100, step)):
        for ax, x in enumerate(range(130, w - 100, step)):
            cv2.circle(t, (x, y), r, 30, -1, cv2.LINE_AA); pts.append((ax, by, x, y))
    return t, pts

def find_dots(img):
    """centroids of dark blobs, matched to the (ax, by) grid by rank order"""
    _, bw = cv2.threshold(img, 128, 255, cv2.THRESH_BINARY_INV)
    n, lab, st, cen = cv2.connectedComponentsWithStats(bw, connectivity=8)
    return [(cen[i][0], cen[i][1]) for i in range(1, n) if 6 <= st[i, cv2.CC_STAT_AREA] <= 400]

def grid_residual(img, pts, verbose=False):
    """RMS deviation (as % of page width) of the dot centroids from the best-fit affine image of the flat grid. returns (rms%, n_found, n_expected)"""
    found = find_dots(img)
    if len(found) < 0.6 * len(pts): return float("nan"), len(found), len(pts)
    # match: for each expected flat grid point, pick nearest found after a first affine guess using extremes
    F = np.array(found); G = np.array([(p[2], p[3]) for p in pts], float)
    # robust 1st guess: map bounding boxes
    g0, g1 = G.min(0), G.max(0); f0, f1 = F.min(0), F.max(0)
    guess = (G - g0) / (g1 - g0) * (f1 - f0) + f0
    matched = []
    for gi, pg in enumerate(guess):
        dist = np.hypot(*(F - pg).T); j = int(np.argmin(dist))
        if dist[j] < 0.6 * 110 * (f1[0] - f0[0]) / (g1[0] - g0[0]): matched.append((gi, j))
    if len(matched) < 0.6 * len(pts): return float("nan"), len(found), len(pts)
    Gm = np.array([G[i] for i, _ in matched]); Fm = np.array([F[j] for _, j in matched])
    A = np.hstack([Gm, np.ones((len(Gm), 1))]); coef, *_ = np.linalg.lstsq(A, Fm, rcond=None)
    res = Fm - A @ coef; rms = float(np.sqrt((res**2).sum(1).mean()))
    width = f1[0] - f0[0]
    return 100 * rms / width, len(matched), len(pts)

if __name__ == "__main__":
    tex = text_texture(O.EN * 2); dots, pts = dot_texture()
    for phi0 in (0, 30, 45, 55):
        img, _ = render(tex, phi0_deg=phi0); d_img, _ = render(dots, phi0_deg=phi0)
        r = grid_residual(d_img, pts)
        print(f"curl phi0={phi0:2d} deg: image {img.shape[::-1]}  dot-grid residual {r[0]:.2f}% of page width ({r[1]}/{r[2]} dots)")
        cv2.imwrite(f"{OUT}/book_{phi0}.png", img)
