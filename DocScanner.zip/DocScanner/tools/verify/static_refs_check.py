#!/usr/bin/env python3
"""Rà tĩnh các tham chiếu tài nguyên và cú pháp thô của Kotlin (phiên 15) - thay cho trình biên dịch khi không có Android SDK.

Không thay được `gradle assembleDebug`, nhưng bắt được lớp lỗi hay gặp khi viết code nhiều file không có compiler:
  1. mọi `R.string/array/drawable/layout/color.X` trong Kotlin (không tính `android.R.*` của hệ điều hành) và mọi `@string/@drawable/@color/@array/@style/@layout/@id` trong XML đều tồn tại;
  2. không có tên string trùng trong strings.xml, không có android:id trùng trong cùng một layout;
  3. mọi `binding.<tên>` của một Activity/Adapter ViewBinding đều là android:id có thật trong layout tương ứng
     (ActivityFooBarBinding -> activity_foo_bar.xml, ItemHistoryBinding -> item_history.xml);
  4. dấu ngoặc {} () [] cân bằng trong từng file Kotlin (đã bỏ qua chuỗi, ký tự, chú thích);
  5. mọi Activity trong manifest có file Kotlin tương ứng và ngược lại (trừ lớp không phải Activity);
  6. mọi tên lớp CamelCase được dùng trong Kotlin đều có nguồn: import, khai báo trong dự án, hoặc mặc định của Kotlin/Java
     (bắt lỗi "Unresolved reference" do thiếu import - lỗi biên dịch phổ biến nhất khi viết không có compiler).
Chạy từ thư mục gốc dự án: python3 tools/verify/static_refs_check.py   (thoát mã 1 nếu có lỗi)
"""
import pathlib, re, sys

ROOT = pathlib.Path(__file__).resolve().parents[2]
RES = ROOT / "app/src/main/res"
JAVA = ROOT / "app/src/main/java/com/example/docscanner"
problems = []


def bad(msg):
    problems.append(msg)
    print("MISMATCH:", msg)


def read(p):
    return p.read_text(encoding="utf-8")


# ---- tài nguyên đã khai báo ----
declared = {k: set() for k in ("string", "array", "drawable", "layout", "color", "style", "id", "mipmap", "xml", "dimen", "plurals", "anim", "menu")}
for f in RES.glob("values*/*.xml"):
    text = read(f)
    names = re.findall(r'<string\s+name="([^"]+)"', text)
    if f.name == "strings.xml":
        seen = set()
        for n in names:
            if n in seen:
                bad(f"strings.xml: tên trùng '{n}'")
            seen.add(n)
    declared["string"].update(names)
    declared["array"].update(re.findall(r'<(?:string|integer)-array\s+name="([^"]+)"', text))
    declared["color"].update(re.findall(r'<color\s+name="([^"]+)"', text))
    declared["style"].update(n.replace(".", "_") for n in re.findall(r'<style\s+name="([^"]+)"', text))
    declared["dimen"].update(re.findall(r'<dimen\s+name="([^"]+)"', text))
    declared["id"].update(re.findall(r'<item\s+name="([^"]+)"\s+type="id"', text))
for folder, kind in (("drawable*", "drawable"), ("layout*", "layout"), ("mipmap*", "mipmap"), ("xml", "xml"), ("anim", "anim"), ("menu", "menu")):
    for d in RES.glob(folder):
        for f in d.iterdir():
            declared[kind].add(f.stem)
            if kind == "drawable":
                declared["mipmap"].discard(f.stem)
for f in RES.rglob("*.xml"):
    declared["id"].update(re.findall(r'android:id="@\+id/([^"]+)"', read(f)))
layout_ids = {}
for f in (RES / "layout").glob("*.xml"):
    ids = re.findall(r'android:id="@\+id/([^"]+)"', read(f))
    seen = set()
    for i in ids:
        if i in seen:
            bad(f"{f.name}: android:id trùng '{i}'")
        seen.add(i)
    layout_ids[f.stem] = set(ids)
    declared["id"].update(ids)

# ---- 1. tham chiếu trong XML ----
for f in list(RES.rglob("*.xml")) + [ROOT / "app/src/main/AndroidManifest.xml"]:
    text = read(f)
    for kind, name in re.findall(r'@(string|array|drawable|layout|color|style|mipmap|xml|dimen|anim|menu)/([A-Za-z0-9_.]+)', text):
        if name.replace(".", "_") not in {n.replace(".", "_") for n in declared[kind]} and not (kind in ("color", "drawable") and name in declared["color"] | declared["drawable"]):
            if kind == "style" and name.startswith(("Theme.", "Widget.", "TextAppearance.", "ThemeOverlay.", "Base.", "Platform.")) and name.replace(".", "_") not in declared["style"]:
                continue   # theme/widget do thư viện Material/AppCompat
            bad(f"{f.relative_to(ROOT)}: @{kind}/{name} không tồn tại")
    for ref in re.findall(r'@id/([A-Za-z0-9_]+)', text):
        if ref not in declared["id"] and ref not in ("content",):
            bad(f"{f.relative_to(ROOT)}: @id/{ref} không có android:id nào khai báo")

# ---- 1b. tham chiếu R.* trong Kotlin ----
kt_files = sorted(JAVA.rglob("*.kt"))
for f in kt_files:
    text = read(f)
    for kind, name in re.findall(r'(?<![.\w])R\.(string|array|drawable|layout|color|style|mipmap|xml|dimen|anim|menu)\.([A-Za-z0-9_]+)', text):
        pool = {n.replace(".", "_") for n in declared[kind]}
        if name not in pool:
            bad(f"{f.name}: R.{kind}.{name} không tồn tại")
    for name in re.findall(r'(?<![.\w])R\.id\.([A-Za-z0-9_]+)', text):
        if name not in declared["id"]:
            bad(f"{f.name}: R.id.{name} không tồn tại")

# ---- 3. ViewBinding ----
def snake(name):
    return re.sub(r'(?<!^)(?=[A-Z])', '_', name).lower()

for f in kt_files:
    text = read(f)
    for bcls in set(re.findall(r'\b([A-Z][A-Za-z0-9]*)Binding\b', text)):
        layout = snake(bcls)
        if layout not in layout_ids:
            continue   # Binding không phải của layout (vd. lớp khác)
        ids = layout_ids[layout]
        camel = {re.sub(r'_([a-z])', lambda m: m.group(1).upper(), i) for i in ids}
        # chỉ xét các tệp dùng đúng biến `binding` của lớp này (mỗi Activity/Adapter ở đây dùng một binding chính)
        bindings_in_file = set(re.findall(r'\b([A-Z][A-Za-z0-9]*)Binding\b', text)) & {c for c in set(re.findall(r'\b([A-Z][A-Za-z0-9]*)Binding\b', text)) if snake(c) in layout_ids}
        if len(bindings_in_file) != 1:
            continue
        for name in set(re.findall(r'\bbinding\.([a-z][A-Za-z0-9]*)', text)):
            if name in ("root",):
                continue
            if name not in camel:
                bad(f"{f.name}: binding.{name} không có android:id tương ứng trong {layout}.xml")

# ---- 4. ngoặc cân bằng ----
def strip_kotlin(src):
    out, i, n = [], 0, len(src)
    while i < n:
        c = src[i]
        if src.startswith("//", i):
            j = src.find("\n", i); i = n if j < 0 else j
        elif src.startswith("/*", i):
            j = src.find("*/", i + 2); i = n if j < 0 else j + 2
        elif src.startswith('"""', i):
            j = src.find('"""', i + 3); i = n if j < 0 else j + 3
        elif c == '"':
            i += 1
            while i < n and src[i] != '"':
                i += 2 if src[i] == "\\" else 1
            i += 1
        elif c == "'":
            i += 1
            while i < n and src[i] != "'":
                i += 2 if src[i] == "\\" else 1
            i += 1
        else:
            out.append(c); i += 1
    return "".join(out)

pairs = {")": "(", "]": "[", "}": "{"}
for f in kt_files:
    stack, line = [], 1
    code = strip_kotlin(read(f))
    ok = True
    for ch in code:
        if ch == "\n":
            line += 1
        if ch in "([{":
            stack.append((ch, line))
        elif ch in ")]}":
            if not stack or stack[-1][0] != pairs[ch]:
                bad(f"{f.name}: '{ch}' thừa hoặc sai cặp ở dòng {line}"); ok = False; break
            stack.pop()
    if ok and stack:
        bad(f"{f.name}: '{stack[-1][0]}' mở ở dòng {stack[-1][1]} chưa đóng")

# ---- 5. manifest <-> Activity ----
manifest = read(ROOT / "app/src/main/AndroidManifest.xml")
declared_acts = set(re.findall(r'<activity[^>]*android:name="\.(\w+)"', manifest))
for a in sorted(declared_acts):
    if not any(k.stem == a for k in kt_files):
        bad(f"manifest khai báo {a} nhưng không có {a}.kt")
for f in kt_files:
    if re.search(r'\bclass\s+' + f.stem + r'\s*(?:\([^)]*\))?\s*:\s*(?:AppCompatActivity|androidx\.appcompat\.app\.AppCompatActivity)', read(f)):
        if f.stem not in declared_acts:
            bad(f"{f.stem} là Activity nhưng thiếu trong AndroidManifest.xml")

# ---- 6. import: mọi tên lớp viết hoa được dùng đều phải có nguồn gốc ----
# Lỗi "Unresolved reference" vì thiếu import là lỗi biên dịch Kotlin hay gặp nhất khi viết code không có compiler.
# Một tên lớp (CamelCase, không đứng sau dấu '.') hợp lệ nếu: được import; hoặc khai báo trong chính file/dự án (cùng package, lớp lồng nhau);
# hoặc thuộc mặc định của Kotlin/Java (bảng dưới); hoặc là hằng ALL_CAPS / tham số kiểu một chữ cái. Chuỗi và chú thích đã được bỏ qua.
KOTLIN_DEFAULT = set("""
String Int Long Float Double Boolean Char Byte Short Array List Map Set MutableList MutableMap MutableSet HashMap HashSet ArrayList
LinkedHashMap LinkedHashSet Pair Triple Throwable Exception Error RuntimeException IllegalStateException IllegalArgumentException
UnsupportedOperationException NumberFormatException NullPointerException SecurityException IndexOutOfBoundsException ClassCastException
OutOfMemoryError Math Unit Any Nothing Number Comparable CharSequence Regex Result Sequence Collection Iterable Iterator MutableIterator
StringBuilder Thread Runnable Suppress Deprecated JvmStatic JvmOverloads JvmField Volatile Synchronized Throws ByteArray FloatArray IntArray
BooleanArray CharArray LongArray DoubleArray ShortArray Enum Lazy Function0 Function1 Function2 Companion R BuildConfig Override
Char Comparator Cloneable AutoCloseable Closeable System StackTraceElement Class Void Object Appendable Readable CharRange IntRange
LongRange Annotation Strictfp Transient Process Runtime Charsets ArrayDeque RegexOption Character
LayoutResultCallback WriteResultCallback
""".split())
# Ghi chú: kotlin.text.* / kotlin.collections.* / java.lang.* được import ngầm (Charsets, RegexOption, ArrayDeque, Character).
# LayoutResultCallback / WriteResultCallback là lớp lồng của PrintDocumentAdapter: trong lớp con của nó dùng được tên ngắn không cần import
# (mẫu trong tài liệu Android cũng viết vậy).
KOTLIN_DEFAULT -= {"Closeable", "TimeUnit"}   # java.io / java.util.concurrent cần import
project_types = set(k.stem for k in kt_files)
for f in kt_files:
    for m in re.finditer(r'\b(?:class|object|interface|enum\s+class|typealias)\s+([A-Z]\w*)', strip_kotlin(read(f))):
        project_types.add(m.group(1))
for f in kt_files:
    raw = read(f)
    code = strip_kotlin(raw)
    imported = set()
    star = []
    for m in re.finditer(r'^import\s+([\w.]+?)(?:\s+as\s+(\w+))?\s*$', raw, re.M):
        imported.add(m.group(2) or m.group(1).split(".")[-1])
    for m in re.finditer(r'^import\s+([\w.]+)\.\*\s*$', raw, re.M):
        star.append(m.group(1))
    if star:
        continue   # import dùng dấu * thì không kiểm được tên nào đến từ đâu
    generics = set(re.findall(r'<\s*(?:out\s+|in\s+)?([A-Z])\b', code)) | set(re.findall(r'\b([A-Z])\s*:', code))
    seen = set()
    for m in re.finditer(r'(?<![\w.@])([A-Z][A-Za-z0-9]*)\b', code):
        name = m.group(1)
        if name in seen:
            continue
        seen.add(name)
        if name.isupper() or len(name) == 1 or name in generics:
            continue                       # hằng ALL_CAPS, tham số kiểu
        if name in imported or name in KOTLIN_DEFAULT or name in project_types:
            continue
        # tên là thuộc tính/tham số viết hoa lạ, hoặc enum entry kiểu CamelCase: bỏ qua nếu được khai báo như giá trị
        if re.search(r'\b(?:val|var)\s+' + name + r'\b', code):
            continue
        bad(f"{f.name}: dùng `{name}` nhưng không import, không khai báo trong dự án và không phải tên mặc định của Kotlin")

print("TAT CA DAT" if not problems else f"{len(problems)} VAN DE")
sys.exit(1 if problems else 0)
