#!/usr/bin/env python3
"""Rà tĩnh các tham chiếu tài nguyên và cú pháp thô của Kotlin (phiên 15) - thay cho trình biên dịch khi không có Android SDK.

Không thay được `gradle assembleDebug`, nhưng bắt được lớp lỗi hay gặp khi viết code nhiều file không có compiler:
  1. mọi `R.string/array/drawable/layout/color.X` trong Kotlin (không tính `android.R.*` của hệ điều hành) và mọi `@string/@drawable/@color/@array/@style/@layout/@id` trong XML đều tồn tại;
  2. không có tên string trùng trong strings.xml, không có android:id trùng trong cùng một layout;
  3. mọi `binding.<tên>` của một Activity/Adapter ViewBinding đều là android:id có thật trong layout tương ứng
     (ActivityFooBarBinding -> activity_foo_bar.xml, ItemHistoryBinding -> item_history.xml);
  4. dấu ngoặc {} () [] cân bằng trong từng file Kotlin (đã bỏ qua chuỗi, ký tự, chú thích);
  5. mọi Activity trong manifest có file Kotlin tương ứng và ngược lại (trừ lớp không phải Activity);
  7. `Object.thanhvien` với object nội bộ (FileUtils, PdfExporter, AppLock...) thì thành viên đó phải được khai báo trong object (bắt gọi nhầm tên hàm);
  8. lời gọi hàm tạo của lớp trong dự án, khi dùng toàn tên tham số, không được thiếu tham số bắt buộc hay có tên lạ
     (bắt "No value passed for parameter" khi thêm tham số mà quên một nơi gọi);
  6. mọi tên lớp CamelCase được dùng trong Kotlin đều có nguồn: import, khai báo trong dự án, hoặc mặc định của Kotlin/Java
     (bắt lỗi "Unresolved reference" do thiếu import - lỗi biên dịch phổ biến nhất khi viết không có compiler).
Chạy từ thư mục gốc dự án: python3 tools/verify/static_refs_check.py   (thoát mã 1 nếu có lỗi)
"""
import pathlib, re, sys

ROOT = pathlib.Path(__file__).resolve().parents[2]
RES = ROOT / "app/src/main/res"
JAVA = ROOT / "app/src/main/java/com/example/docscanner"
problems = []


def bad(msg):
    problems.append(msg)
    print("MISMATCH:", msg)


def read(p):
    return p.read_text(encoding="utf-8")


# ---- tài nguyên đã khai báo ----
declared = {k: set() for k in ("string", "array", "drawable", "layout", "color", "style", "id", "mipmap", "xml", "dimen", "plurals", "anim", "menu")}
for f in RES.glob("values*/*.xml"):
    text = read(f)
    names = re.findall(r'<string\s+name="([^"]+)"', text)
    if f.name == "strings.xml":
        seen = set()
        for n in names:
            if n in seen:
                bad(f"strings.xml: tên trùng '{n}'")
            seen.add(n)
    declared["string"].update(names)
    declared["array"].update(re.findall(r'<(?:string|integer)-array\s+name="([^"]+)"', text))
    declared["color"].update(re.findall(r'<color\s+name="([^"]+)"', text))
    declared["style"].update(n.replace(".", "_") for n in re.findall(r'<style\s+name="([^"]+)"', text))
    declared["dimen"].update(re.findall(r'<dimen\s+name="([^"]+)"', text))
    declared["id"].update(re.findall(r'<item\s+name="([^"]+)"\s+type="id"', text))
for folder, kind in (("drawable*", "drawable"), ("layout*", "layout"), ("mipmap*", "mipmap"), ("xml", "xml"), ("anim", "anim"), ("menu", "menu")):
    for d in RES.glob(folder):
        for f in d.iterdir():
            declared[kind].add(f.stem)
            if kind == "drawable":
                declared["mipmap"].discard(f.stem)
for f in RES.rglob("*.xml"):
    declared["id"].update(re.findall(r'android:id="@\+id/([^"]+)"', read(f)))
layout_ids = {}
for f in (RES / "layout").glob("*.xml"):
    ids = re.findall(r'android:id="@\+id/([^"]+)"', read(f))
    seen = set()
    for i in ids:
        if i in seen:
            bad(f"{f.name}: android:id trùng '{i}'")
        seen.add(i)
    layout_ids[f.stem] = set(ids)
    declared["id"].update(ids)

# ---- 1. tham chiếu trong XML ----
for f in list(RES.rglob("*.xml")) + [ROOT / "app/src/main/AndroidManifest.xml"]:
    text = read(f)
    for kind, name in re.findall(r'@(string|array|drawable|layout|color|style|mipmap|xml|dimen|anim|menu)/([A-Za-z0-9_.]+)', text):
        if name.replace(".", "_") not in {n.replace(".", "_") for n in declared[kind]} and not (kind in ("color", "drawable") and name in declared["color"] | declared["drawable"]):
            if kind == "style" and name.startswith(("Theme.", "Widget.", "TextAppearance.", "ThemeOverlay.", "Base.", "Platform.")) and name.replace(".", "_") not in declared["style"]:
                continue   # theme/widget do thư viện Material/AppCompat
            bad(f"{f.relative_to(ROOT)}: @{kind}/{name} không tồn tại")
    for ref in re.findall(r'@id/([A-Za-z0-9_]+)', text):
        if ref not in declared["id"] and ref not in ("content",):
            bad(f"{f.relative_to(ROOT)}: @id/{ref} không có android:id nào khai báo")

# ---- 1b. tham chiếu R.* trong Kotlin ----
kt_files = sorted(JAVA.rglob("*.kt"))
for f in kt_files:
    text = read(f)
    for kind, name in re.findall(r'(?<![.\w])R\.(string|array|drawable|layout|color|style|mipmap|xml|dimen|anim|menu)\.([A-Za-z0-9_]+)', text):
        pool = {n.replace(".", "_") for n in declared[kind]}
        if name not in pool:
            bad(f"{f.name}: R.{kind}.{name} không tồn tại")
    for name in re.findall(r'(?<![.\w])R\.id\.([A-Za-z0-9_]+)', text):
        if name not in declared["id"]:
            bad(f"{f.name}: R.id.{name} không tồn tại")

# ---- 3. ViewBinding ----
def snake(name):
    return re.sub(r'(?<!^)(?=[A-Z])', '_', name).lower()

for f in kt_files:
    text = read(f)
    for bcls in set(re.findall(r'\b([A-Z][A-Za-z0-9]*)Binding\b', text)):
        layout = snake(bcls)
        if layout not in layout_ids:
            continue   # Binding không phải của layout (vd. lớp khác)
        ids = layout_ids[layout]
        camel = {re.sub(r'_([a-z])', lambda m: m.group(1).upper(), i) for i in ids}
        # chỉ xét các tệp dùng đúng biến `binding` của lớp này (mỗi Activity/Adapter ở đây dùng một binding chính)
        bindings_in_file = set(re.findall(r'\b([A-Z][A-Za-z0-9]*)Binding\b', text)) & {c for c in set(re.findall(r'\b([A-Z][A-Za-z0-9]*)Binding\b', text)) if snake(c) in layout_ids}
        if len(bindings_in_file) != 1:
            continue
        for name in set(re.findall(r'\bbinding\.([a-z][A-Za-z0-9]*)', text)):
            if name in ("root",):
                continue
            if name not in camel:
                bad(f"{f.name}: binding.{name} không có android:id tương ứng trong {layout}.xml")

# ---- 4. ngoặc cân bằng ----
def strip_kotlin(src):
    """Bỏ chú thích và NỘI DUNG chuỗi/ký tự, nhưng GIỮ lại mã trong mẫu chuỗi `${...}` (vd "${FileUtils.name()}.pdf"):
    lời gọi hàm nằm trong mẫu chuỗi vẫn là mã thật và phải được kiểm."""
    n = len(src)

    def string_end(k):          # k ngay sau dấu " mở; trả về vị trí sau dấu " đóng
        while k < n:
            c = src[k]
            if c == "\\":
                k += 2
            elif c == '"':
                return k + 1
            elif src.startswith("${", k):
                k = template_end(k + 2)
            else:
                k += 1
        return k

    def template_end(k):        # k ngay sau "${"; trả về vị trí sau dấu } khớp
        depth = 1
        while k < n and depth > 0:
            c = src[k]
            if c == '"':
                k = string_end(k + 1); continue
            if c == "'":
                k += 3 if src[k + 1:k + 2] != "\\" else 4; continue
            if c == "{":
                depth += 1
            elif c == "}":
                depth -= 1
            k += 1
        return k

    out, i = [], 0
    while i < n:
        c = src[i]
        if src.startswith("//", i):
            j = src.find("\n", i); i = n if j < 0 else j
        elif src.startswith("/*", i):
            j = src.find("*/", i + 2); i = n if j < 0 else j + 2
        elif src.startswith('"""', i):
            k = i + 3
            while k < n and not src.startswith('"""', k):
                if src.startswith("${", k):
                    e = template_end(k + 2)
                    out.append(" " + strip_kotlin(src[k + 2:e - 1]) + " "); k = e
                else:
                    k += 1
            i = k + 3
        elif c == '"':
            k = i + 1
            while k < n and src[k] != '"':
                if src[k] == "\\":
                    k += 2
                elif src.startswith("${", k):
                    e = template_end(k + 2)
                    out.append(" " + strip_kotlin(src[k + 2:e - 1]) + " "); k = e
                else:
                    k += 1
            i = k + 1
        elif c == "'":
            i += 1
            while i < n and src[i] != "'":
                i += 2 if src[i] == "\\" else 1
            i += 1
        else:
            out.append(c); i += 1
    return "".join(out)

pairs = {")": "(", "]": "[", "}": "{"}
for f in kt_files:
    stack, line = [], 1
    code = strip_kotlin(read(f))
    ok = True
    for ch in code:
        if ch == "\n":
            line += 1
        if ch in "([{":
            stack.append((ch, line))
        elif ch in ")]}":
            if not stack or stack[-1][0] != pairs[ch]:
                bad(f"{f.name}: '{ch}' thừa hoặc sai cặp ở dòng {line}"); ok = False; break
            stack.pop()
    if ok and stack:
        bad(f"{f.name}: '{stack[-1][0]}' mở ở dòng {stack[-1][1]} chưa đóng")

# ---- 5. manifest <-> Activity ----
manifest = read(ROOT / "app/src/main/AndroidManifest.xml")
declared_acts = set(re.findall(r'<activity[^>]*android:name="\.(\w+)"', manifest))
for a in sorted(declared_acts):
    if not any(k.stem == a for k in kt_files):
        bad(f"manifest khai báo {a} nhưng không có {a}.kt")
for f in kt_files:
    if re.search(r'\bclass\s+' + f.stem + r'\s*(?:\([^)]*\))?\s*:\s*(?:AppCompatActivity|androidx\.appcompat\.app\.AppCompatActivity)', read(f)):
        if f.stem not in declared_acts:
            bad(f"{f.stem} là Activity nhưng thiếu trong AndroidManifest.xml")

# ---- 6. import: mọi tên lớp viết hoa được dùng đều phải có nguồn gốc ----
# Lỗi "Unresolved reference" vì thiếu import là lỗi biên dịch Kotlin hay gặp nhất khi viết code không có compiler.
# Một tên lớp (CamelCase, không đứng sau dấu '.') hợp lệ nếu: được import; hoặc khai báo trong chính file/dự án (cùng package, lớp lồng nhau);
# hoặc thuộc mặc định của Kotlin/Java (bảng dưới); hoặc là hằng ALL_CAPS / tham số kiểu một chữ cái. Chuỗi và chú thích đã được bỏ qua.
KOTLIN_DEFAULT = set("""
String Int Long Float Double Boolean Char Byte Short Array List Map Set MutableList MutableMap MutableSet HashMap HashSet ArrayList
LinkedHashMap LinkedHashSet Pair Triple Throwable Exception Error RuntimeException IllegalStateException IllegalArgumentException
UnsupportedOperationException NumberFormatException NullPointerException SecurityException IndexOutOfBoundsException ClassCastException
OutOfMemoryError Math Unit Any Nothing Number Comparable CharSequence Regex Result Sequence Collection Iterable Iterator MutableIterator
StringBuilder Thread Runnable Suppress Deprecated JvmStatic JvmOverloads JvmField Volatile Synchronized Throws ByteArray FloatArray IntArray
BooleanArray CharArray LongArray DoubleArray ShortArray Enum Lazy Function0 Function1 Function2 Companion R BuildConfig Override
Char Comparator Cloneable AutoCloseable Closeable System StackTraceElement Class Void Object Appendable Readable CharRange IntRange
LongRange Annotation Strictfp Transient Process Runtime Charsets ArrayDeque RegexOption Character
LayoutResultCallback WriteResultCallback
""".split())
# Ghi chú: kotlin.text.* / kotlin.collections.* / java.lang.* được import ngầm (Charsets, RegexOption, ArrayDeque, Character).
# LayoutResultCallback / WriteResultCallback là lớp lồng của PrintDocumentAdapter: trong lớp con của nó dùng được tên ngắn không cần import
# (mẫu trong tài liệu Android cũng viết vậy).
KOTLIN_DEFAULT -= {"Closeable", "TimeUnit"}   # java.io / java.util.concurrent cần import
project_types = set(k.stem for k in kt_files)
for f in kt_files:
    for m in re.finditer(r'\b(?:class|object|interface|enum\s+class|typealias)\s+([A-Z]\w*)', strip_kotlin(read(f))):
        project_types.add(m.group(1))
for f in kt_files:
    raw = read(f)
    code = strip_kotlin(raw)
    imported = set()
    star = []
    for m in re.finditer(r'^import\s+([\w.]+?)(?:\s+as\s+(\w+))?\s*$', raw, re.M):
        imported.add(m.group(2) or m.group(1).split(".")[-1])
    for m in re.finditer(r'^import\s+([\w.]+)\.\*\s*$', raw, re.M):
        star.append(m.group(1))
    if star:
        continue   # import dùng dấu * thì không kiểm được tên nào đến từ đâu
    generics = set(re.findall(r'<\s*(?:out\s+|in\s+)?([A-Z])\b', code)) | set(re.findall(r'\b([A-Z])\s*:', code))
    seen = set()
    for m in re.finditer(r'(?<![\w.@])([A-Z][A-Za-z0-9]*)\b', code):
        name = m.group(1)
        if name in seen:
            continue
        seen.add(name)
        if name.isupper() or len(name) == 1 or name in generics:
            continue                       # hằng ALL_CAPS, tham số kiểu
        if name in imported or name in KOTLIN_DEFAULT or name in project_types:
            continue
        # tên là thuộc tính/tham số viết hoa lạ, hoặc enum entry kiểu CamelCase: bỏ qua nếu được khai báo như giá trị
        if re.search(r'\b(?:val|var)\s+' + name + r'\b', code):
            continue
        bad(f"{f.name}: dùng `{name}` nhưng không import, không khai báo trong dự án và không phải tên mặc định của Kotlin")

# ---- 7. thành viên của object trong dự án: `FileUtils.foo(...)` thì `foo` phải được khai báo trong `object FileUtils` ----
# Bắt lỗi "Unresolved reference: foo" khi gọi nhầm tên hàm/hằng của một object nội bộ (không bắt được sai kiểu/số tham số).
objects = {}
for f in kt_files:
    code7 = strip_kotlin(read(f))
    for m in re.finditer(r'\bobject\s+([A-Z]\w*)\s*(?::[^{]*)?\{', code7):
        name = m.group(1)
        # thân object: từ dấu { đến dấu } khớp
        depth, i = 0, m.end() - 1
        j = i
        while j < len(code7):
            if code7[j] == "{": depth += 1
            elif code7[j] == "}":
                depth -= 1
                if depth == 0: break
            j += 1
        body = code7[i:j]
        members = set(re.findall(r'\b(?:fun|val|var|class|object|interface|typealias)\s+(?:<[^>]*>\s*)?(?:[A-Za-z_][\w<>?., ]*\.)?([A-Za-z_]\w*)', body))
        members |= set(re.findall(r'\bconst\s+val\s+(\w+)', body))
        for em in re.finditer(r'\benum\s+class\s+\w+[^{]*\{([^}]*)\}', body):
            members |= set(re.findall(r'\b([A-Z][A-Za-z0-9_]*)\b', em.group(1).split(";")[0]))
        # tham số của hàm tạo/ data class không cần cho object; thêm tên chung của mọi object Kotlin
        members |= {"hashCode", "toString", "equals", "javaClass", "let", "also", "apply", "run", "with", "takeIf", "takeUnless"}
        objects[name] = (f.name, members)
for f in kt_files:
    code7 = strip_kotlin(read(f))
    for m in re.finditer(r'(?<![\w.])([A-Z]\w*)\.([A-Za-z_]\w*)', code7):
        owner, member = m.group(1), m.group(2)
        if owner in objects and member not in objects[owner][1]:
            bad(f"{f.name}: `{owner}.{member}` - object {owner} ({objects[owner][0]}) không khai báo `{member}`")

# ---- 8. lời gọi hàm tạo của lớp trong dự án: thiếu tham số bắt buộc / tên tham số lạ (chỉ xét lời gọi dùng TOÀN tên tham số) ----
# Bắt đúng lỗi "No value passed for parameter 'x'" khi thêm tham số vào hàm tạo mà quên một nơi gọi (run #15: HistoryAdapter.onPrint).
def balanced(code, open_idx):
    """Chỉ số dấu ) khớp với dấu ( tại open_idx, hoặc -1."""
    depth = 0
    for k in range(open_idx, len(code)):
        if code[k] == "(": depth += 1
        elif code[k] == ")":
            depth -= 1
            if depth == 0: return k
    return -1

def split_top(text):
    """Tách theo dấu phẩy ở mức ngoài cùng. Dấu < > chỉ tính là ngoặc kiểu tổng quát (List<String>) khi dính liền tên kiểu;
    `a < b` / `a > b` (so sánh, có dấu cách) thì không - nếu không dấu phẩy phía sau bị nuốt (lỗi báo nhầm ở ScanQuality.Report)."""
    parts, depth, angle, cur = [], 0, 0, []
    text = text.replace("->", "  ")          # mũi tên lambda không phải dấu <> của kiểu tổng quát
    for k, c in enumerate(text):
        prev = text[k - 1] if k else " "
        nxt = text[k + 1] if k + 1 < len(text) else " "
        if c in "([{":
            depth += 1
        elif c in ")]}":
            depth -= 1
        elif c == "<" and (prev.isalnum() or prev == "_") and nxt not in " =":
            angle += 1
        elif c == ">" and angle > 0 and prev not in " =":
            angle -= 1
        if c == "," and depth == 0 and angle == 0:
            parts.append("".join(cur)); cur = []
        else:
            cur.append(c)
    if "".join(cur).strip(): parts.append("".join(cur))
    return [p.strip() for p in parts if p.strip()]

classes = {}
for f in kt_files:
    code8 = strip_kotlin(read(f))
    for m in re.finditer(r'\bclass\s+([A-Z]\w*)\s*(?:<[^>(]*>)?\s*(?:(?:private|internal|protected)\s+)?(?:constructor\s*)?\(', code8):
        o = m.end() - 1
        c = balanced(code8, o)
        if c < 0: continue
        params = {}
        for part in split_top(code8[o + 1:c]):
            head = part.split("=", 1)[0] if "=" in part and not part.lstrip().startswith("=") else part
            pm = re.search(r'(?:\b(?:private|public|internal|protected|override|val|var|vararg|noinline|crossinline)\s+)*(\w+)\s*:', head)
            if pm:
                params[pm.group(1)] = ("=" in part, "vararg" in head)
        classes.setdefault(m.group(1), params)
for f in kt_files:
    code8 = strip_kotlin(read(f))
    for name, params in classes.items():
        for m in re.finditer(r'(?<![\w.])' + name + r'\s*\(', code8):
            before = code8[max(0, m.start() - 12):m.start()]
            if re.search(r'\b(?:class|fun|object|interface)\s*$', before):
                continue
            o = m.end() - 1
            c = balanced(code8, o)
            if c < 0: continue
            args = split_top(code8[o + 1:c])
            if not args: 
                if any(not d and not v for d, v in params.values()) and params and False:
                    pass
                continue
            if not all(re.match(r'^\w+\s*=(?!=)', a) for a in args):
                continue                      # có đối số vị trí: không xét
            given = {re.match(r'^(\w+)', a).group(1) for a in args}
            for g in sorted(given - set(params)):
                bad(f"{f.name}: `{name}(...)` truyền tham số tên lạ `{g}` (hàm tạo có: {', '.join(params) or 'không'})")
            for req in sorted(k for k, (d, v) in params.items() if not d and not v and k not in given):
                bad(f"{f.name}: `{name}(...)` thiếu tham số bắt buộc `{req}`")

print("TAT CA DAT" if not problems else f"{len(problems)} VAN DE")
sys.exit(1 if problems else 0)
