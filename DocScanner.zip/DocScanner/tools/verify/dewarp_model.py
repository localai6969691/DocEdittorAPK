# Reference model of TextLineDewarp (vertical straightening + horizontal cylinder correction + gates).
# Dewarp with vertical straightening (as before) PLUS horizontal correction from the line-spacing cue.
import numpy as np, cv2
from dewarp_check import ink_mask, find_lines, robust_polyfit

def fit_models(gray, work=1000):
    small, ink, sc = ink_mask(gray, work)
    lines, h = find_lines(ink)
    models = []
    for xs, cs in lines:
        m = robust_polyfit(xs, cs)
        if m is not None: models.append((xs.min(), xs.max(), m))
    return small, sc, models

def spacing_profile(models, Wd, smooth_frac=0.04):
    """s(x): local line spacing (median of adjacent-line gaps at column x), gaps filled and smoothed; None if unreliable"""
    X = np.arange(Wd, dtype=np.float64); raw = np.full(Wd, np.nan)
    ys = np.full((len(models), Wd), np.nan)
    for k, (x0, x1, (coef, xm)) in enumerate(models):
        inside = (X >= x0) & (X <= x1); ys[k, inside] = np.polyval(coef, X[inside] - xm)
    # typical spacing at the median column to reject paragraph gaps / merged lines
    allgaps = []
    for x in range(0, Wd, 8):
        col = np.sort(ys[~np.isnan(ys[:, x]), x]); 
        if len(col) >= 3: allgaps.extend(np.diff(col))
    if len(allgaps) < 20: return None
    med = np.median(allgaps)
    for x in range(Wd):
        col = np.sort(ys[~np.isnan(ys[:, x]), x])
        if len(col) < 2: continue
        g = np.diff(col); g = g[(g > 0.5 * med) & (g < 1.8 * med)]
        if len(g) >= 2: raw[x] = np.median(g)
    valid = ~np.isnan(raw)
    if valid.mean() < 0.6: return None
    idx = np.arange(Wd); filled = np.interp(idx, idx[valid], raw[valid])          # constant extension at both ends
    sig = max(2.0, smooth_frac * Wd)
    k = np.arange(-int(3*sig), int(3*sig)+1); w = np.exp(-0.5*(k/sig)**2); w /= w.sum()
    pad = np.pad(filled, (len(k)//2, len(k)//2), mode="edge"); sm = np.convolve(pad, w, mode="valid")
    return sm / np.median(sm)

def horizontal_map(s, mode, f_px, cx):
    """returns u(x): flattened coordinate of every work column, normalised to span the same width"""
    Wd = len(s); x = np.arange(Wd, dtype=np.float64)
    if mode == "v1":
        step = 1.0 / s
    elif mode == "v2":
        Z = 1.0 / s; X = (x - cx) * Z / f_px
        dX = np.gradient(X); dZ = np.gradient(Z)
        step = np.sqrt(dX**2 + dZ**2) * f_px            # arc length, back in "reference pixels" (Z0 = 1)
    else:
        return x
    u = np.cumsum(step); u = u - u[0]
    return u / u[-1] * (Wd - 1)

def dewarp_maps(gray, mode="v2", f_rel=1.0, cx_rel=0.5, strength=1.0, work=1000, fitted=None, max_disp=0.12):
    small, sc, models = fitted if fitted is not None else fit_models(gray, work)
    Hd, Wd = small.shape
    if len(models) < 4: return None, "too-few-lines"
    X = np.arange(Wd, dtype=np.float64)
    ycen = np.full((len(models), Wd), np.nan); disp = np.full_like(ycen, np.nan)
    for k, (x0, x1, (coef, xm)) in enumerate(models):
        inside = (X >= x0) & (X <= x1); f = np.polyval(coef, X[inside] - xm)
        ycen[k, inside] = f; disp[k, inside] = (f.mean() - f) * strength
    if np.nanmax(np.abs(disp)) > max_disp * Hd: return None, "disp-too-large"
    Dfield = np.zeros((Hd, Wd), np.float32); Yg = np.arange(Hd, dtype=np.float64)
    for x in range(Wd):
        m = ~np.isnan(ycen[:, x])
        if m.sum() < 2: continue
        yc, dd = ycen[m, x], disp[m, x]; o = np.argsort(yc); Dfield[:, x] = np.interp(Yg, yc[o], dd[o])
    s = spacing_profile(models, Wd) if mode != "v0" else None
    if mode != "v0" and s is None: mode = "v0"
    u = horizontal_map(s, mode, f_rel * Wd, cx_rel * Wd) if mode != "v0" else X
    # backward column map g(x') : source column for every OUTPUT column (u is monotone increasing source->output)
    g = np.interp(X, u, X)
    # backward vertical map with D sampled at the (fractional) source column
    src_cols = g
    Dg = np.empty_like(Dfield)
    c0 = np.clip(np.floor(src_cols).astype(int), 0, Wd - 1); c1 = np.clip(c0 + 1, 0, Wd - 1); t = (src_cols - c0)[None, :]
    Dg = Dfield[:, c0] * (1 - t) + Dfield[:, c1] * t
    ys_out = np.repeat(Yg[:, None], Wd, axis=1).astype(np.float32); src = ys_out.copy(); cols = np.arange(Wd)[None, :].repeat(Hd, 0).astype(np.float32)
    for _ in range(3): src = ys_out - cv2.remap(Dg.astype(np.float32), cols, src, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    return (g, src, sc, Hd, Wd), mode

def apply_maps(img, maps):
    g, src, sc, Hd, Wd = maps; H, W = img.shape[:2]
    mapy = cv2.resize(src, (W, H), interpolation=cv2.INTER_LINEAR) / sc
    gx = np.interp(np.arange(W) * sc, np.arange(Wd), g) / sc                      # full-res output col -> full-res source col
    mapx = np.tile(gx.astype(np.float32)[None, :], (H, 1))
    return cv2.remap(img, mapx, mapy.astype(np.float32), cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)


# Reference implementation of the final TextLineDewarp (vertical straightening + horizontal cylinder correction + all gates).

F_REL = 0.7            # assumed focal length, as a fraction of the page-image width (sweep: 0.6-0.9 all within 5% of best)
ACT_LO, ACT_HI = 0.05, 0.09     # spacing-range activation ramp of the horizontal part (flat pages measure <= 0.053, curled >= 0.07)
MAX_DISP = 0.12
MIN_DISP_PX = 2.0
MIN_GAIN = 0.85
MAX_SHIFT = 0.12

def dewarp_maps3(gray, work=1000, fitted=None, horizontal=True, f_rel=F_REL):
    small, sc, models = fitted if fitted is not None else fit_models(gray, work)
    Hd, Wd = small.shape
    if len(models) < 4: return None, "too-few-lines"
    X = np.arange(Wd, dtype=np.float64)
    ycen = np.full((len(models), Wd), np.nan); disp = np.full_like(ycen, np.nan)
    before, after = [], []
    for k, (x0, x1, (coef, xm)) in enumerate(models):
        inside = (X >= x0) & (X <= x1); xs_ = X[inside]
        if len(xs_) < 8: continue
        f = np.polyval(coef, xs_ - xm); ycen[k, inside] = f; disp[k, inside] = f.mean() - f
        c1 = np.polyfit(xs_, f, 1); before.append(np.sqrt(np.mean((f - np.polyval(c1, xs_))**2)))
        g = f + disp[k, inside]; c2 = np.polyfit(xs_, g, 1); after.append(np.sqrt(np.mean((g - np.polyval(c2, xs_))**2)))
    mx = np.nanmax(np.abs(disp))
    if mx > MAX_DISP * Hd: return None, "disp-too-large"
    if mx < MIN_DISP_PX: return None, "already-straight"
    if np.sum(after) > MIN_GAIN * np.sum(before): return None, "not-better"
    Dfield = np.zeros((Hd, Wd), np.float32); Yg = np.arange(Hd, dtype=np.float64)
    for x in range(Wd):
        m = ~np.isnan(ycen[:, x])
        if m.sum() < 2: continue
        yc, dd = ycen[m, x], disp[m, x]; o = np.argsort(yc); Dfield[:, x] = np.interp(Yg, yc[o], dd[o])
    g = X.copy(); info = f"vertical max {mx:.1f}px"
    if horizontal:
        s = spacing_profile(models, Wd)
        if s is not None:
            rng = float(s.max() - s.min()); w = float(np.clip((rng - ACT_LO) / (ACT_HI - ACT_LO), 0, 1))
            if w > 0:
                s_eff = 1.0 + w * (s - 1.0)
                u = horizontal_map(s_eff, "v2", f_rel * Wd, 0.5 * Wd)
                cand = np.interp(X, u, X)
                shift = float(np.abs(cand - X).max())
                if shift <= MAX_SHIFT * Wd: g = cand; info += f", horizontal activation {w:.2f} shift {shift:.1f}px"
                else: info += ", horizontal refused (shift too large)"
    c0 = np.clip(np.floor(g).astype(int), 0, Wd - 1); c1 = np.clip(c0 + 1, 0, Wd - 1); t = (g - c0)[None, :]
    Dg = Dfield[:, c0] * (1 - t) + Dfield[:, c1] * t
    ys_out = np.repeat(Yg[:, None], Wd, axis=1).astype(np.float32); src = ys_out.copy(); cols = np.arange(Wd)[None, :].repeat(Hd, 0).astype(np.float32)
    for _ in range(3): src = ys_out - cv2.remap(Dg.astype(np.float32), cols, src, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    return (g, src, sc, Hd, Wd), info
