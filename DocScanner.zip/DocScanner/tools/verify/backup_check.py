"""Kiểm chứng BackupManager (phiên 15): parseEntry, isInside, rebasePath, rebaseProjectJson và luồng khôi phục an toàn.

Bản Python song song của BackupManager.kt. Có 3 phần:
  1. parse_entry: tên entry hợp lệ giữ nguyên; ".." / đường dẫn tuyệt đối / backslash trá hình / NUL / ngoài 2 thư mục -> bị từ chối.
  2. rebase_path: đường dẫn tuyệt đối của máy khác -> thư mục của máy này (projects/..., Documents/...); không khớp thì giữ nguyên.
  3. Khôi phục THẬT trên đĩa (Python): một ZIP có entry hợp lệ + entry "zip slip" + file đã tồn tại -> kiểm: không file nào rơi ra ngoài
     thư mục, file có sẵn KHÔNG bị ghi đè, project.json được rebase, không để lại file .restore.part, ZIP lạ -> báo lỗi.
Chạy: python3 backup_check.py
"""
import json, os, shutil, sys, tempfile, zipfile

AREAS = ("exports/", "projects/")
PART = ".restore.part"


def parse_entry(name):
    if "\x00" in name:
        return None
    n = name.replace("\\", "/")
    if n.startswith("/"):
        return None
    area = next((a for a in AREAS if n.startswith(a)), None)
    if area is None:
        return None
    rel = n[len(area):]
    if rel == "" or rel.endswith("/"):
        return None
    if any(p in ("", ".", "..") for p in rel.split("/")):
        return None
    return area, rel


def rebase_path(path, projects_root, exports_root):
    p = path.rfind("/projects/")
    if p >= 0:
        return projects_root.rstrip("/") + path[p + len("/projects"):]
    d = path.rfind("/Documents/")
    if d >= 0:
        return exports_root.rstrip("/") + path[d + len("/Documents"):]
    return path


def rebase_project_json(text, projects_root, exports_root):
    try:
        obj = json.loads(text)
    except Exception:
        return text
    fix = lambda s: rebase_path(s, projects_root, exports_root)
    for key in ("pendingRawPaths", "ebookPaths"):
        if isinstance(obj.get(key), list):
            obj[key] = [fix(s) for s in obj[key]]
    for page in obj.get("pages", []) or []:
        if page.get("path"):
            page["path"] = fix(page["path"])
    for key in ("pdfPath", "compressedPdfPath", "ocrTextPath"):
        if obj.get(key):
            obj[key] = fix(obj[key])
    return json.dumps(obj)


def is_inside(base, target):
    b = os.path.realpath(base)
    t = os.path.realpath(target)
    return t.startswith(b + os.sep)


def restore(zip_path, roots):
    written = skipped = rejected = recognised = 0
    with zipfile.ZipFile(zip_path) as z:
        for info in z.infolist():
            if info.is_dir():
                continue
            parsed = parse_entry(info.filename)
            if parsed is None:
                rejected += 1
                continue
            recognised += 1
            area, rel = parsed
            base = roots[area]
            target = os.path.join(base, *rel.split("/"))
            if not is_inside(base, target):
                rejected += 1
            elif os.path.exists(target):
                skipped += 1
            else:
                os.makedirs(os.path.dirname(target), exist_ok=True)
                part = target + PART
                with z.open(info) as src, open(part, "wb") as out:
                    shutil.copyfileobj(src, out)
                if area == "projects/" and os.path.basename(target) == "project.json":
                    with open(part, encoding="utf-8") as f:
                        fixed = rebase_project_json(f.read(), roots["projects/"], roots["exports/"])
                    with open(part, "w", encoding="utf-8") as f:
                        f.write(fixed)
                os.rename(part, target)
                written += 1
    if recognised == 0:
        raise ValueError("not a backup of this app")
    return written, skipped, rejected


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    return cond


def main():
    good = True
    # 1. parse_entry
    good &= check(parse_entry("exports/a.pdf") == ("exports/", "a.pdf"), "entry hợp lệ exports")
    good &= check(parse_entry("projects/123/pages/p1.jpg") == ("projects/", "123/pages/p1.jpg"), "entry hợp lệ projects lồng nhau")
    for bad in ("../x.pdf", "exports/../../x", "exports/a/../../b", "/etc/passwd", "exports\\..\\x", "projects/..\\..\\x",
                "exports/a\x00.pdf", "signatures/sig_1.png", "exports/", "exports", "exports//x", "exports/./x", "other/a.pdf", ""):
        good &= check(parse_entry(bad) is None, f"từ chối {bad!r}")
    # 2. rebase_path
    pr, ex = "/data/user/0/app/files/projects", "/sdcard/Android/data/app/files/Documents"
    good &= check(rebase_path("/data/user/10/app/files/projects/ab/pages/1.jpg", pr, ex) == pr + "/ab/pages/1.jpg", "rebase projects khác người dùng")
    good &= check(rebase_path("/old/Documents/scan_1.pdf", pr, ex) == ex + "/scan_1.pdf", "rebase Documents")
    good &= check(rebase_path("/somewhere/else.pdf", pr, ex) == "/somewhere/else.pdf", "không khớp -> giữ nguyên")
    good &= check(rebase_path(pr + "/ab/x.jpg", pr, ex) == pr + "/ab/x.jpg", "cùng máy -> không đổi")
    # 3. khôi phục thật
    tmp = tempfile.mkdtemp()
    try:
        roots = {"exports/": os.path.join(tmp, "Documents"), "projects/": os.path.join(tmp, "files", "projects")}
        for r in roots.values():
            os.makedirs(r)
        with open(os.path.join(roots["exports/"], "existing.pdf"), "wb") as f:
            f.write(b"HIEN-TAI")
        pj = json.dumps({"id": "ab", "pendingRawPaths": ["/old/files/projects/ab/raw/r.jpg"],
                         "pages": [{"path": "/old/files/projects/ab/pages/1.jpg", "rotation": 0}],
                         "pdfPath": "/old/Documents/out.pdf", "compressedPdfPath": None, "ebookPaths": ["/old/Documents/b.epub"]})
        zp = os.path.join(tmp, "b.zip")
        with zipfile.ZipFile(zp, "w") as z:
            z.writestr("exports/new.pdf", b"MOI")
            z.writestr("exports/existing.pdf", b"TRONG-ZIP")
            z.writestr("projects/ab/project.json", pj)
            z.writestr("projects/ab/pages/1.jpg", b"jpg")
            z.writestr("../escape.txt", b"x")
            z.writestr("exports/../../escape2.txt", b"x")
            z.writestr("/abs/escape3.txt", b"x")
            z.writestr("signatures/sig.png", b"x")
        w, s, r = restore(zp, roots)
        # ghi 3 (new.pdf, project.json, 1.jpg); bỏ qua 1 (existing.pdf đã có); từ chối 4 (hai "..", đường dẫn tuyệt đối, signatures/)
        good &= check((w, s, r) == (3, 1, 4), f"đếm kết quả (ghi 3, bỏ qua 1, từ chối 4) -> {(w, s, r)}")
        good &= check(open(os.path.join(roots["exports/"], "existing.pdf"), "rb").read() == b"HIEN-TAI", "file có sẵn không bị ghi đè")
        good &= check(open(os.path.join(roots["exports/"], "new.pdf"), "rb").read() == b"MOI", "file mới được ghi")
        escaped = [os.path.join(tmp, n) for n in ("escape.txt", "escape2.txt")] + [os.path.join(tmp, "files", "escape.txt"), "/abs/escape3.txt"]
        good &= check(not any(os.path.exists(p) for p in escaped), "không file nào rơi ra ngoài thư mục")
        left = [n for dp, _, fs in os.walk(tmp) for n in fs if n.endswith(PART)]
        good &= check(left == [], "không để lại .restore.part")
        pj2 = json.load(open(os.path.join(roots["projects/"], "ab", "project.json"), encoding="utf-8"))
        good &= check(pj2["pages"][0]["path"] == roots["projects/"] + "/ab/pages/1.jpg", "project.json: trang được rebase")
        good &= check(pj2["pendingRawPaths"][0] == roots["projects/"] + "/ab/raw/r.jpg", "project.json: ảnh thô được rebase")
        good &= check(pj2["pdfPath"] == roots["exports/"] + "/out.pdf" and pj2["ebookPaths"][0] == roots["exports/"] + "/b.epub", "project.json: pdf/ebook được rebase về Documents")
        good &= check(pj2["compressedPdfPath"] is None, "project.json: giá trị null giữ nguyên")
        # symlink thoát ra ngoài
        outside = os.path.join(tmp, "outside"); os.makedirs(outside)
        os.symlink(outside, os.path.join(roots["exports/"], "link"))
        zp2 = os.path.join(tmp, "c.zip")
        with zipfile.ZipFile(zp2, "w") as z:
            z.writestr("exports/link/pwn.txt", b"x"); z.writestr("exports/fine.pdf", b"ok")
        w2, s2, r2 = restore(zp2, roots)
        good &= check(not os.path.exists(os.path.join(outside, "pwn.txt")) and r2 == 1 and w2 == 1, f"symlink thoát thư mục bị chặn -> {(w2, s2, r2)}")
        # ZIP lạ
        zp3 = os.path.join(tmp, "d.zip")
        with zipfile.ZipFile(zp3, "w") as z:
            z.writestr("holiday/photo.jpg", b"x")
        try:
            restore(zp3, roots); good &= check(False, "ZIP lạ phải báo lỗi")
        except ValueError:
            good &= check(True, "ZIP không phải bản sao lưu của app -> báo lỗi")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("TAT CA DAT" if good else "CO LOI")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
