# Python mirror of OrientationDetector (Bloomberg/Dasari-style ascender vs descender statistics, written from the
# 1995 paper / expired Xerox patent US 5,276,742 description, using per-line profiles instead of hit-miss SELs).
import cv2, numpy as np, math
from PIL import Image, ImageDraw, ImageFont

def ink_mask(gray, work=1100):
    sc = min(1.0, work/max(gray.shape)); small = cv2.resize(gray, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
    ink = cv2.adaptiveThreshold(small, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 31, 12)
    return ink

def hv_scores(ink):
    d = cv2.dilate(ink, cv2.getStructuringElement(cv2.MORPH_RECT, (9, 1)))
    rows = d.sum(axis=1, dtype=np.float64); cols = cv2.dilate(ink, cv2.getStructuringElement(cv2.MORPH_RECT, (1, 9))).sum(axis=0, dtype=np.float64)
    return float(np.sum(np.diff(rows)**2)), float(np.sum(np.diff(cols)**2))

def line_bands(ink):
    """text-line bands from the smoothed row profile of the horizontally smeared mask"""
    d = cv2.dilate(ink, cv2.getStructuringElement(cv2.MORPH_RECT, (25, 1)))
    prof = d.sum(axis=1, dtype=np.float64)
    if prof.max() <= 0: return []
    sm = np.convolve(prof, np.ones(3)/3, mode="same")
    thr = 0.12 * sm.max()
    bands, inb, start = [], False, 0
    for y, v in enumerate(sm):
        if v > thr and not inb: inb, start = True, y
        elif v <= thr and inb:
            inb = False
            if y - start >= 6: bands.append((start, y))
    if inb and len(sm) - start >= 6: bands.append((start, len(sm)))
    return bands

def _components(mask, min_area, min_height=0):
    if mask.size == 0: return 0
    n, _, stats, _ = cv2.connectedComponentsWithStats(mask, connectivity=8)
    return int(sum(1 for i in range(1, n) if stats[i, cv2.CC_STAT_AREA] >= min_area and stats[i, cv2.CC_STAT_HEIGHT] >= min_height))

def up_down(ink):
    """(Na, Nd, Nx, lines): number of separate strokes rising above / dropping below the x-height band, and
    number of glyph bodies inside it, summed over all text lines (counts, as in the paper; not ink mass)"""
    bands = line_bands(ink); na = nd = nx = used = 0
    for (a, b) in bands:
        p = ink[a:b].sum(axis=1, dtype=np.float64)
        if p.max() <= 0: continue
        dense = np.where(p >= 0.5 * p.max())[0]
        xt, base = int(dense.min()), int(dense.max())
        xh = base - xt + 1
        if xh < 4 or (b - a) > 6 * xh: continue                   # not a text line (image / table / very tall blob)
        lo = max(a, a + xt - int(0.9 * xh)); hi_ = a + xt                # zone above x-height: up to ~0.9 x-height high
        up = ink[lo:hi_]; body = ink[a + xt:a + base + 1]; dn = ink[a + base + 1: min(b, a + base + 1 + int(0.9 * xh))]
        # a stroke must be at least ~0.15 x-height wide-ish: filter specks
        min_area = max(2, int(0.12 * xh * xh / 4))
        mh = max(2, int(0.35 * xh))                                     # commas / periods / specks are shorter than a real stroke
        na += _components(up, min_area, mh); nd += _components(dn, min_area, mh)
        nx += _components(cv2.morphologyEx(body, cv2.MORPH_OPEN, np.ones((max(2, xh // 3), 1), np.uint8)), min_area * 2)
        used += 1
    return na, nd, nx, used

MIN_COUNT, MIN_FRACTION, MIN_CONF = 40, 0.12, 0.2

def decide_up_down(na, nd, nx):
    """Significance test of Bloomberg/Dasari: |Na-Nd| must exceed 3 * (sqrt(Na)+sqrt(Nd)) / sqrt(2) (three
    standard deviations of random data). Plus two guards for text that has no ascender/descender contrast
    (digits, ALL CAPS): enough strokes overall, and enough of them relative to the glyph bodies."""
    tot = na + nd
    if tot < MIN_COUNT or nx <= 0 or tot < MIN_FRACTION * nx: return 0, 0.0
    if abs(na - nd) <= 3 * (math.sqrt(na) + math.sqrt(nd)) / math.sqrt(2): return 0, 0.0
    conf = (na - nd) / tot
    if abs(conf) < MIN_CONF: return 0, conf
    return (1 if conf > 0 else -1), conf

from image_algorithms_check import estimate_skew

def _axis_score(gray):
    """(best projection-profile score over +-8 deg, angle) when the text lines are assumed HORIZONTAL"""
    ang, prom = estimate_skew(gray)
    return estimate_skew.last_best_score, (ang or 0.0), prom

def _upright_vote(gray, ang):
    if ang:
        M = cv2.getRotationMatrix2D((gray.shape[1]/2, gray.shape[0]/2), ang, 1.0)
        gray = cv2.warpAffine(gray, M, (gray.shape[1], gray.shape[0]), borderValue=255)
    ink = ink_mask(gray)
    na, nd, nx, used = up_down(ink)
    s, c = decide_up_down(na, nd, nx)
    return s, c, used

def detect(gray):
    """degrees the page must be rotated COUNTER-clockwise to be upright (0/90/180/270), or None if unsure.
    1) which axis do the text lines follow (best deskew profile score, horizontal vs the page turned 90 deg),
    2) deskew, 3) ascender/descender vote (up or upside down)."""
    ink = ink_mask(gray)
    frac = cv2.countNonZero(ink)/ink.size
    if frac < 0.004 or frac > 0.5: return None, "no-text"
    rot90 = cv2.rotate(gray, cv2.ROTATE_90_COUNTERCLOCKWISE)
    sh, ah, ph = _axis_score(gray); sv, av, pv = _axis_score(rot90)
    if max(sh, sv) <= 0 or max(ph or 0, pv or 0) < 1.25: return None, "no-text-lines"
    if sv > 1.5 * sh:                                  # text lines run vertically -> 90 or 270
        s, c, used = _upright_vote(rot90, av)
        if used < 3 or s == 0: return None, "vertical-unknown"
        return (90 if s > 0 else 270), f"vertical conf {c:+.2f}"
    if sh > 1.5 * sv or True:
        s, c, used = _upright_vote(gray, ah)
        if used < 3 or s == 0: return None, f"unknown conf {c:+.2f} lines {used}"
        return (0 if s > 0 else 180), f"conf {c:+.2f} lines {used}"

def page(text_lines, font_path, size=26, w=1240, h=1754, fill=30):
    img = Image.new("L", (w, h), 245); d = ImageDraw.Draw(img); f = ImageFont.truetype(font_path, size); y = 130
    i = 0
    while y < h - 130:
        d.text((110, y), text_lines[i % len(text_lines)], fill=fill, font=f); y += int(size * 1.7); i += 1
    return np.array(img)

EN = ["The quick brown fox jumps over the lazy dog while the lighthouse keeper looks at the sea.",
      "Programming languages, hyperbolic geometry, and the philosophy of mathematics belong together.",
      "A journey of a thousand miles begins with a single step; practice makes perfect, they say."]
VI = ["Cộng hòa xã hội chủ nghĩa Việt Nam, độc lập tự do hạnh phúc, mọi người đều bình đẳng.",
      "Trường đại học công nghệ thông tin tổ chức hội nghị khoa học quốc tế về trí tuệ nhân tạo.",
      "Thủ đô Hà Nội có nhiều di tích lịch sử, văn hóa và những con phố cổ kính nổi tiếng."]
DIGITS = ["0123456789 2026-09-30 12,345,678.90 $ 1,250.00 ID 445566778899 0011223344"]
CAPS = ["THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG NEAR THE RIVER BANK TODAY", "ALL CAPITAL LETTERS TEXT HAS VERY FEW DESCENDERS AT ALL IN IT"]
FONTS = {"DejaVuSans": "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "DejaVuSerif": "/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf"}
import glob
for extra in glob.glob("/usr/share/fonts/truetype/*/*.ttf"):
    n = extra.split("/")[-1]
    if n.startswith(("LiberationSans-Regular", "LiberationSerif-Regular", "NotoSans-Regular", "Ubuntu-R")): FONTS[n] = extra

if __name__ == "__main__":
    rng = np.random.default_rng(5)
    codes = {0: None, 90: cv2.ROTATE_90_CLOCKWISE, 180: cv2.ROTATE_180, 270: cv2.ROTATE_90_COUNTERCLOCKWISE}
    def skew(deg):
        def f(a):
            M = cv2.getRotationMatrix2D((a.shape[1]/2, a.shape[0]/2), deg, 1.0)
            return cv2.warpAffine(a, M, (a.shape[1], a.shape[0]), borderValue=245)
        return f
    def noise(s): return lambda a: np.clip(a.astype(np.float32) + rng.normal(0, s, a.shape), 0, 255).astype(np.uint8)
    totals = dict(tot=0, ok=0, unk=0, wrong=0)
    def run(label, make, sizes=(22, 28, 34)):
        tot = ok = unk = wrong = 0
        for ln, lines in (("EN", EN), ("VI", VI)):
            for fn in ("DejaVuSans", "DejaVuSerif", "LiberationSerif-Regular.ttf", "LiberationSans-Regular.ttf"):
                for size in sizes:
                    base = make(page(lines, FONTS[fn], size))
                    for rot, code in codes.items():
                        img = base if code is None else cv2.rotate(base, code)
                        ans, info = detect(img); tot += 1
                        if ans is None: unk += 1
                        elif ans == rot: ok += 1
                        else: wrong += 1; print(f"    WRONG [{label}] {ln} {fn[:10]} {size}px rot {rot}: {ans} {info}")
        print(f"{label:24s} correct {ok:3d}/{tot}  declined {unk:3d}  WRONG {wrong}")
        for k, v in (("tot", tot), ("ok", ok), ("unk", unk), ("wrong", wrong)): totals[k] += v
    print("English + Vietnamese pages, 4 fonts x 3 sizes x 4 rotations = 96 pages per scenario:")
    run("clean", lambda a: a); run("skew +3", skew(3.0)); run("skew -4", skew(-4.0)); run("skew +6", skew(6.0))
    run("skew -5 + noise 12", lambda a: noise(12)(skew(-5.0)(a)))
    print(f"TOTAL {totals['tot']} pages: correct {totals['ok']}, declined {totals['unk']}, WRONG {totals['wrong']}")
    print("--- pages that must be DECLINED (never turned): all-caps, digits only, blank, noise ---")
    for name, img in (("caps", page(CAPS, FONTS['DejaVuSans'], 28)), ("digits", page(DIGITS, FONTS['DejaVuSans'], 28)),
                      ("blank", np.full((1754, 1240), 245, np.uint8)), ("noise", (np.random.default_rng(0).random((1754, 1240))*255).astype(np.uint8))):
        print(f"  {name:7s} upright: {detect(img)}   upside-down: {detect(cv2.rotate(img, cv2.ROTATE_180))}")
