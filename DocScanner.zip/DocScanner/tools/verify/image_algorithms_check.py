# Python/OpenCV mirrors of DocumentEnhancer + ScanQuality (same steps/constants as the Kotlin), run on synthetic pages.
import cv2, numpy as np, math
from PIL import Image, ImageDraw, ImageFont
from skimage.filters import threshold_sauvola

def make_page(w=1240, h=1754, skew=0.0, shadow=False, blur=0.0, seed=0):
    img = Image.new("L", (w, h), 245)
    d = ImageDraw.Draw(img)
    f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 26)
    y = 140
    txt = "The quick brown fox jumps over the lazy dog. Cộng hòa xã hội chủ nghĩa Việt Nam 0123456789"
    while y < h - 140:
        d.text((110, y), txt, fill=30, font=f); y += 46
    a = np.array(img)
    if skew:
        M = cv2.getRotationMatrix2D((w/2, h/2), skew, 1.0)   # +skew = content rotated CCW
        a = cv2.warpAffine(a, M, (w, h), borderValue=245)
    if shadow:
        xx = np.linspace(0, 1, w)[None, :]; yy = np.linspace(0, 1, h)[:, None]
        g = 1.0 - 0.55 * np.clip(xx * 1.2 + yy * 0.5 - 0.4, 0, 1)      # smooth gradient shadow
        a = (a * g).astype(np.uint8)
    if blur: a = cv2.GaussianBlur(a, (0, 0), blur)
    return a

# ---------------- Sauvola (mirror) ----------------
def sauvola_mirror(gray, k=0.25, R=128.0, work=2000.0, exact=False):
    """Mirror of DocumentEnhancer.sauvolaBinarize: the threshold surface is computed on a copy with long edge <= `work`,
    rounded to 8 bit and stretched back; `exact=True` skips the reduction and the rounding (used to compare with skimage)."""
    sc = 1.0 if exact else min(1.0, work / max(gray.shape))
    small = gray if sc >= 1.0 else cv2.resize(gray, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
    w = int(np.clip(min(small.shape)//40, 21, 75)); w += (w % 2 == 0)
    g = small.astype(np.float32)
    mean = cv2.boxFilter(g, cv2.CV_32F, (w, w), normalize=True, borderType=cv2.BORDER_REPLICATE)
    meansq = cv2.boxFilter(g*g, cv2.CV_32F, (w, w), normalize=True, borderType=cv2.BORDER_REPLICATE)
    std = np.sqrt(np.maximum(meansq - mean*mean, 0))
    T = mean*(1-k) + mean*std*(k/R)
    if exact: return np.where(gray.astype(np.float32) > T, 255, 0).astype(np.uint8)
    T8 = np.clip(np.rint(T), 0, 255).astype(np.uint8)
    if sc < 1.0: T8 = cv2.resize(T8, (gray.shape[1], gray.shape[0]), interpolation=cv2.INTER_LINEAR)
    return np.where(gray > T8, 255, 0).astype(np.uint8)

# ---------------- skew (mirror) ----------------
def estimate_skew(gray):
    sc = min(1.0, 900/max(gray.shape)); small = cv2.resize(gray, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
    ink = cv2.adaptiveThreshold(small, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 31, 12)
    ink = cv2.dilate(ink, cv2.getStructuringElement(cv2.MORPH_RECT, (9, 1)))
    frac = cv2.countNonZero(ink)/ink.size
    estimate_skew.last_best_score = 0.0
    if frac < 0.004 or frac > 0.5: return 0.0, None
    c = (ink.shape[1]/2, ink.shape[0]/2); scores = {}
    def score(a):
        if a in scores: return scores[a]
        M = cv2.getRotationMatrix2D(c, a, 1.0); r = cv2.warpAffine(ink, M, (ink.shape[1], ink.shape[0]), flags=cv2.INTER_NEAREST)
        rows = r.sum(axis=1, dtype=np.float32) ; s = float(np.sum(np.diff(rows)**2)); scores[a] = s; return s
    best, bs = 0.0, score(0.0)
    def sweep(lo, hi, st):
        nonlocal best, bs
        a = lo
        while a <= hi + 1e-9:
            s = score(round(a, 2))
            if s > bs: bs, best = s, round(a, 2)
            a += st
    sweep(-8, 8, 1.0); sweep(best-1, best+1, 0.25); sweep(best-0.25, best+0.25, 0.05)
    prom = bs/np.mean(list(scores.values()))
    estimate_skew.last_best_score = bs
    if prom < 1.25: return 0.0, prom
    return (0.0 if abs(best) < 0.2 else best), prom

# ---------------- background normalisation (mirror) ----------------
def normalize_bg(rgb):
    """Mirror of DocumentEnhancer.normalizeBackground (phiên 13 configuration)."""
    sc = min(1.0, 1000/max(rgb.shape[:2])); small = cv2.resize(rgb, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
    d = cv2.dilate(small, cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5)))
    d = cv2.medianBlur(d, 3)
    bg = cv2.resize(d, (rgb.shape[1], rgb.shape[0]), interpolation=cv2.INTER_LINEAR)
    bg = np.maximum(bg, 96)
    return np.clip(rgb.astype(np.float32) * 255.0 / bg, 0, 255).astype(np.uint8)

# ---------------- quality (mirror) ----------------
def quality(gray):
    sc = min(1.0, 1200/max(gray.shape)); small = cv2.resize(gray, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
    p5, p95 = np.percentile(small, 5), np.percentile(small, 95); rng = p95 - p5
    lap = cv2.Laplacian(small, cv2.CV_64F); G = 8; th, tw = small.shape[0]//G, small.shape[1]//G
    v = sorted([lap[gy*th:(gy+1)*th, gx*tw:(gx+1)*tw].var() for gy in range(G) for gx in range(G)], reverse=True)
    sharp = float(np.mean(v[:max(1, len(v)//4)]))
    return sharp, float(small.mean()), rng

def degrade(clean, noise=0, stain=False, low_contrast=0.0, shadow=False, rng=None):
    rng = rng or np.random.default_rng(1)
    a = clean.astype(np.float32); h, w = a.shape
    if low_contrast: a = 245 - (245 - a) * (1 - low_contrast)
    if stain:
        yy, xx = np.mgrid[0:h, 0:w]
        a = a * (1 - 0.45 * np.exp(-(((xx - w*0.65)/(w*0.18))**2 + ((yy - h*0.45)/(h*0.12))**2)))
    if shadow:
        xx = np.linspace(0, 1, w)[None, :]; yy = np.linspace(0, 1, h)[:, None]
        a = a * (1.0 - 0.6 * np.clip(xx*1.2 + yy*0.5 - 0.4, 0, 1))
    if noise: a = a + rng.normal(0, noise, a.shape)
    return np.clip(a, 0, 255).astype(np.uint8)

SCENARIOS = [("clean", {}), ("noise sigma=12", dict(noise=12)), ("noise sigma=25", dict(noise=25)),
             ("faint text (60% contrast loss)", dict(low_contrast=0.6, noise=8)), ("stain + noise", dict(stain=True, noise=10)),
             ("strong shadow + noise", dict(shadow=True, noise=10)), ("shadow + stain + faint + noise", dict(shadow=True, stain=True, low_contrast=0.4, noise=12))]

if __name__ == "__main__":
    print("== deskew: page rotated by a known angle; the estimate must be the NEGATIVE of it (the correction) ==")
    for true in (0.0, 1.5, -2.7, 4.2, -6.0):
        a = make_page(skew=true); est, prom = estimate_skew(a)
        print(f"  content skew {true:+.1f} deg -> correction {est:+.2f} deg  (want {-true:+.1f}, prominence {prom if prom is None else round(prom, 2)})")
    print("== deskew on pages with no text lines (must return 0) ==")
    blank = np.full((1754, 1240), 245, np.uint8)
    print("  blank:", estimate_skew(blank)[0], "| noise:", estimate_skew((np.random.default_rng(0).random((1754, 1240))*255).astype(np.uint8))[0])
    print("== Sauvola vs skimage.threshold_sauvola (same window/k/R) on a shadowed page ==")
    sh = make_page(shadow=True); mine = sauvola_mirror(sh, k=0.34, exact=True)
    w = int(np.clip(min(sh.shape)//40, 21, 75)); w += (w % 2 == 0)
    ref = (sh > threshold_sauvola(sh, window_size=w, k=0.34, r=128.0)).astype(np.uint8) * 255
    print("  window", w, "| pixels differing from skimage: %.4f%%" % (100*np.mean(mine != ref)))
    print("== ink overlap (IoU) with the true ink, Sauvola k=0.25 (shipped) vs the old Gaussian adaptiveThreshold vs Otsu ==")
    clean = make_page(); gt = clean < 128
    iou = lambda m: np.logical_and(m, gt).sum() / np.logical_or(m, gt).sum()
    print(f"  {'scenario':34s} {'Sauvola':>8s} {'old adapt':>10s} {'Otsu':>7s}   speckle in blank strip (Sauvola/old)")
    for label, kw in SCENARIOS:
        img = degrade(clean, **kw)
        s = sauvola_mirror(img, k=0.25) == 0
        o = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 25, 15) == 0
        ot = cv2.threshold(img, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1] == 0
        print(f"  {label:34s} {iou(s):8.3f} {iou(o):10.3f} {iou(ot):7.3f}   {int(s[20:100].sum()):6d} / {int(o[20:100].sum()):6d}")
    print("== k sweep (mean IoU over 6 degraded scenarios) -> why the shipped k is 0.25 ==")
    six = [(n, degrade(clean, **kw)) for n, kw in SCENARIOS[1:]]
    for k in (0.10, 0.15, 0.20, 0.25, 0.34, 0.50):
        vals = [iou(sauvola_mirror(im, k=k) == 0) for _, im in six]
        print(f"  k={k:4.2f}  mean {np.mean(vals):.3f}   per scenario " + " ".join(f"{v:.3f}" for v in vals))
    print("== background normalisation (shipped: 1000 px, dilate 5x5, median 3) on a smooth-gradient shadow ==")
    rgb = cv2.cvtColor(sh, cv2.COLOR_GRAY2RGB); out = normalize_bg(rgb)[:, :, 0]
    print("  top strip mean/std before: %.0f/%.1f  after: %.0f/%.1f" % (sh[20:100].mean(), sh[20:100].std(), out[20:100].mean(), out[20:100].std()))
    print("  bottom-right corner mean before: %.0f after: %.0f (paper is white -> want ~ the top value)" % (sh[-120:-40, -200:].mean(), out[-120:-40, -200:].mean()))
    print("== quality measure: sharpness / mean / range ==")
    for label, img in (("sharp", make_page()), ("blur sigma=1.5", make_page(blur=1.5)), ("blur sigma=3", make_page(blur=3.0)), ("blur sigma=6", make_page(blur=6.0)),
                       ("dark (x0.25)", (make_page()*0.25).astype(np.uint8)), ("blank", blank)):
        s_, m_, r_ = quality(img); print(f"  {label:15s} sharpness {s_:9.1f} mean {m_:5.1f} range {r_:5.1f}")
