"""Kiểm chứng PdfDecorator (phiên 15): số trang / đầu-chân trang / Bates.

Bản Python song song của app/.../util/PdfDecorator.kt (expand, isPlainAscii, labelX, labelBaselineY) + PdfPageGeometry.
Phần 1: hàm thuần (token, Bates, vị trí) - kiểm bằng ví dụ có đáp án tay.
Phần 2: đặt nhãn lên trang xoay 0/90/180/270 x (không CropBox | CropBox lệch gốc), cho poppler đọc lại bằng
`pdftotext -bbox` (toạ độ TRANG ĐANG HIỂN THỊ, gốc trên-trái): nhãn phải nằm đúng góc/giữa cạnh, đọc đúng chữ, và nằm
NGANG (rộng > cao => không bị xoay nghiêng theo /Rotate). Chạy: python3 decorate_check.py
"""
import os, re, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import pikepdf
from pikepdf import Name, Dictionary
from reportlab.pdfbase.pdfmetrics import stringWidth
from page_geometry_check import Geometry

BATES_DEFAULT_DIGITS = 6


def expand(template, n, total, prefix="", digits=BATES_DEFAULT_DIGITS):
    digits = max(1, min(12, digits))
    bates = prefix + str(n).rjust(digits, "0")
    return template.replace("{n}", str(n)).replace("{N}", str(total)).replace("{b}", bates)


def is_plain_ascii(s):
    return all(0x20 <= ord(c) <= 0x7E for c in s)


def label_x(place, tw, pw, margin):
    if place in ("TOP_LEFT", "BOTTOM_LEFT"):
        x = margin
    elif place in ("TOP_CENTER", "BOTTOM_CENTER"):
        x = (pw - tw) / 2.0
    else:
        x = pw - margin - tw
    return min(margin, pw / 4.0) if x < margin else x


def label_baseline_y(place, th, ph, margin):
    return ph - margin - th if place.startswith("TOP") else margin


def pure_tests():
    ok = True
    def eq(a, b, what):
        nonlocal ok
        if a != b:
            ok = False
            print("LOI", what, repr(a), "!=", repr(b))
    eq(expand("Trang {n}/{N}", 3, 10), "Trang 3/10", "n/N")
    eq(expand("{b}", 7, 10, "ABC-", 4), "ABC-0007", "bates 4")
    eq(expand("{b}", 12345, 10, "X", 3), "X12345", "bates tràn số chữ số vẫn giữ đủ")
    eq(expand("{b}", 5, 10, "", 99), "000000000005", "digits bị kẹp 12")
    eq(expand("không token", 1, 1), "không token", "không token")
    eq(is_plain_ascii("Page 1/2 ABC-0001"), True, "ascii")
    eq(is_plain_ascii("Trang 1 – Hợp đồng"), False, "không phải ascii")
    eq(label_x("BOTTOM_LEFT", 50, 400, 28), 28, "trái")
    eq(label_x("BOTTOM_CENTER", 50, 400, 28), 175, "giữa")
    eq(label_x("BOTTOM_RIGHT", 50, 400, 28), 322, "phải")
    eq(label_x("BOTTOM_RIGHT", 500, 400, 28), 28, "nhãn rộng hơn trang không chạy ra bên trái")
    eq(label_baseline_y("TOP_LEFT", 10, 600, 28), 562, "trên")
    eq(label_baseline_y("BOTTOM_LEFT", 10, 600, 28), 28, "dưới")
    print("ok  phan thuan" if ok else "LOI phan thuan")
    return ok


def build_page(path, mediabox, cropbox, rotate, ops):
    pdf = pikepdf.new()
    pg = pdf.add_blank_page(page_size=(mediabox[2] - mediabox[0], mediabox[3] - mediabox[1]))
    pg.MediaBox = pikepdf.Array(mediabox)
    if cropbox:
        pg.CropBox = pikepdf.Array(cropbox)
    pg.Rotate = rotate
    pg.Resources = Dictionary(Font=Dictionary(F1=Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Helvetica)))
    pg.Contents = pdf.make_stream(ops.encode())
    pdf.save(path)


def words(path):
    out = subprocess.run(["pdftotext", "-cropbox", "-bbox", path, "-"], capture_output=True, text=True, check=True).stdout
    res = []
    for m in re.finditer(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">([^<]*)</word>', out):
        x0, y0, x1, y1 = (float(m.group(i)) for i in range(1, 5))
        res.append((x0, y0, x1, y1, m.group(5)))
    return res


def geometry_tests():
    fails = 0
    size = 10.0
    margin = 28.0
    labels = [("TOP_LEFT", "Header {n}-{N}"), ("BOTTOM_CENTER", "Trang {n}"), ("BOTTOM_RIGHT", "{b}")]
    for rot in (0, 90, 180, 270):
        for mb, cb in (((0, 0, 400, 600), None), ((-50, -40, 350, 560), (-30, -10, 330, 540))):
            box = cb or mb
            g = Geometry(box[0], box[1], box[2] - box[0], box[3] - box[1], rot)
            a, b, c, d, e, f = g.matrix()
            ops = f"q {a} {b} {c} {d} {e} {f} cm\n"
            expected = {}
            for place, tpl in labels:
                text = expand(tpl, 5, 9, "ABC-", 4)
                tw = stringWidth(text, "Helvetica", size)
                x = label_x(place, tw, g.dw, margin)
                y = label_baseline_y(place, size, g.dh, margin)
                ops += f"BT /F1 {size} Tf 0.1 0.1 0.1 rg {x} {y} Td ({text}) Tj ET\n"
                expected[text] = (place, x, y, tw)
            ops += "Q\n"
            p = os.path.join(OUT, f"dec_{rot}_{'c' if cb else 'm'}.pdf")
            build_page(p, mb, cb, rot, ops)
            ws = words(p)
            ok = True
            detail = []
            # poppler -bbox lists words of the DISPLAYED page; gộp lại thành dòng theo chuỗi mong đợi
            joined = " ".join(w[4] for w in ws)
            for text, (place, x, y, tw) in expected.items():
                parts = text.split(" ")
                found = [w for w in ws if w[4] in parts]
                if len(found) < len(parts):
                    ok = False
                    detail.append(f"thieu '{text}'")
                    continue
                x0 = min(w[0] for w in found); x1 = max(w[2] for w in found)
                y0 = min(w[1] for w in found); y1 = max(w[3] for w in found)
                # y mong đợi (từ trên xuống): đáy chữ = dh - y  => yMax ~ dh - y + descent(~2.1)
                exp_bottom = g.dh - y
                horizontal = (x1 - x0) > (y1 - y0)
                near_x = abs(x0 - x) < 3.0
                near_y = abs(y1 - exp_bottom) < 4.0
                if not (horizontal and near_x and near_y):
                    ok = False
                    detail.append(f"'{text}' x0={x0:.1f}/{x:.1f} yMax={y1:.1f}/{exp_bottom:.1f} ngang={horizontal}")
            if not ok:
                fails += 1
            print(("ok  " if ok else "LOI"), f"rot={rot:3d} crop={'co' if cb else 'khong'}", "; ".join(detail), "|", joined[:60])
    return fails == 0


if __name__ == "__main__":
    good = pure_tests()
    good = geometry_tests() and good
    print("TAT CA DAT" if good else "CO LOI")
    sys.exit(0 if good else 1)
