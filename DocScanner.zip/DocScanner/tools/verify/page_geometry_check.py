"""Kiểm chứng PdfPageGeometry (phiên 15): đặt nội dung theo toạ độ TRANG ĐANG HIỂN THỊ (gốc trên-trái, y xuống dưới)
lên trang có /Rotate 0/90/180/270 và CropBox lệch gốc, rồi cho poppler (pdftoppm) vẽ lại và đo điểm ảnh.

Bản Python song song của app/src/main/java/com/example/docscanner/util/PdfPageGeometry.kt: cùng công thức ma trận
(a b c d e f) và cùng hàm toUser(). Nếu đổi công thức trong Kotlin thì đổi ở đây (và ngược lại).

Hai phép thử cho MỖI tổ hợp (xoay x CropBox):
  1. displayMatrix: nội dung vẽ trong "khung hiển thị" (gốc dưới-trái, thẳng đứng) phải hiện đúng chỗ VÀ đúng chiều:
     ô đỏ ở góc dưới-trái, ô xanh ở góc trên-trái, ô xanh lá ở góc trên-phải (3 góc khác nhau => lật/xoay sai sẽ lộ ngay).
  2. toUser: điểm chọn trên ảnh xem trước (x từ trái, y từ trên) đổi sang toạ độ PDF phải rơi đúng pixel đó khi vẽ không qua ma trận.
Chạy: python3 page_geometry_check.py  (cần pikepdf, numpy, pillow, pdftoppm)
"""
import subprocess, sys, os
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import numpy as np
from PIL import Image
import pikepdf
from pikepdf import Name


class Geometry:
    def __init__(self, llx, lly, cw, ch, rotation):
        self.llx, self.lly, self.cw, self.ch = llx, lly, cw, ch
        r = int(round(rotation / 90.0)) * 90
        self.rotation = ((r % 360) + 360) % 360
        swap = self.rotation in (90, 270)
        self.dw = ch if swap else cw
        self.dh = cw if swap else ch

    def matrix(self):
        llx, lly, cw, ch = self.llx, self.lly, self.cw, self.ch
        return {
            0: (1, 0, 0, 1, llx, lly),
            90: (0, 1, -1, 0, llx + cw, lly),
            180: (-1, 0, 0, -1, llx + cw, lly + ch),
            270: (0, -1, 1, 0, llx, lly + ch),
        }[self.rotation]

    def to_user(self, x_left, y_top):
        a, b, c, d, e, f = self.matrix()
        xb, yb = x_left, self.dh - y_top
        return a * xb + c * yb + e, b * xb + d * yb + f


def build(path, mediabox, cropbox, rotate, ops):
    pdf = pikepdf.new()
    pg = pdf.add_blank_page(page_size=(mediabox[2] - mediabox[0], mediabox[3] - mediabox[1]))
    pg.MediaBox = pikepdf.Array(mediabox)
    if cropbox:
        pg.CropBox = pikepdf.Array(cropbox)
    pg.Rotate = rotate
    pg.Contents = pdf.make_stream(ops.encode())
    pdf.save(path)


def render(path):
    base = path[:-4]
    subprocess.run(["pdftoppm", "-r", "72", "-cropbox", "-png", "-singlefile", path, base], check=True)
    return np.array(Image.open(base + ".png").convert("RGB"))


def color_at(img, x, y):
    return tuple(int(v) for v in img[int(y), int(x)])


def near(c, target, tol=40):
    return all(abs(c[i] - target[i]) <= tol for i in range(3))


def main():
    fails = 0
    cases = []
    for rot in (0, 90, 180, 270):
        cases.append(((0, 0, 400, 600), None, rot))
        cases.append(((0, 0, 400, 600), (20, 30, 380, 570), rot))          # CropBox lệch gốc
        cases.append(((-50, -40, 350, 560), (-30, -10, 330, 540), rot))    # MediaBox gốc âm
    for mb, cb, rot in cases:
        box = cb or mb
        g = Geometry(box[0], box[1], box[2] - box[0], box[3] - box[1], rot)
        a, b, c, d, e, f = g.matrix()
        # 1) displayMatrix: 3 ô màu ở 3 góc của khung hiển thị
        ops = (f"q {a} {b} {c} {d} {e} {f} cm "
               f"1 0 0 rg 10 10 40 20 re f "                                   # đỏ: dưới-trái
               f"0 0 1 rg 10 {g.dh - 30} 40 20 re f "                         # xanh dương: trên-trái
               f"0 1 0 rg {g.dw - 50} {g.dh - 30} 40 20 re f Q\n")             # xanh lá: trên-phải
        p = os.path.join(OUT, f"geo_{rot}_{'c' if cb else 'm'}_{mb[0]}.pdf")
        build(p, mb, cb, rot, ops)
        img = render(p)
        h, w = img.shape[:2]
        ok_size = (w, h) == (int(round(g.dw)), int(round(g.dh)))
        red = color_at(img, 30, h - 20)
        blue = color_at(img, 30, 20)
        green = color_at(img, w - 30, 20)
        ok1 = ok_size and near(red, (255, 0, 0)) and near(blue, (0, 0, 255)) and near(green, (0, 255, 0))
        # 2) toUser: vẽ ô nhỏ (không qua ma trận) ở điểm user-space tính từ (x_left, y_top) = (120, 90)
        ux, uy = g.to_user(120, 90)
        ops2 = f"1 0 1 rg {ux - 3} {uy - 3} 6 6 re f\n"
        p2 = p[:-4] + "_pt.pdf"
        build(p2, mb, cb, rot, ops2)
        img2 = render(p2)
        mag = color_at(img2, 120, 90)
        ok2 = near(mag, (255, 0, 255))
        status = "ok " if (ok1 and ok2) else "LOI"
        if not (ok1 and ok2):
            fails += 1
        print(f"{status} rot={rot:3d} media={mb} crop={cb} anh={w}x{h} dich-ma-tran={ok1} (do={red} xd={blue} xl={green}) to_user={ok2} ({mag})")
    print("TAT CA DAT" if fails == 0 else f"{fails} TRUONG HOP LOI")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
