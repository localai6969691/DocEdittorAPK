import numpy as np, cv2, sys
sys.path.insert(0, ".")
import orientation_check as O
from PIL import Image, ImageDraw, ImageFont

def make_doc():
    img = Image.new("L", (1240, 1754), 245); d = ImageDraw.Draw(img)
    big = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 110)
    small = ImageFont.truetype(O.FONTS["DejaVuSans"], 26)
    d.text((110, 100), "TIÊU ĐỀ", fill=30, font=big); d.text((110, 260), "Chapter One", fill=30, font=big)
    y = 480
    while y < 1600:
        d.text((110, y), O.EN[(y//44) % 3], fill=30, font=small); y += 44
    return np.array(img)

def normalize_v2(rgb, work=1200, fine=5, coarse=(480, 9, 15, 21)):
    h, w = rgb.shape[:2]
    def bg_est(work_, dil, med, gauss):
        sc = min(1.0, work_/max(h, w)); small = cv2.resize(rgb, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
        d = cv2.dilate(small, cv2.getStructuringElement(cv2.MORPH_RECT, (dil, dil)))
        if med: d = cv2.medianBlur(d, med)
        if gauss: d = cv2.GaussianBlur(d, (gauss, gauss), 0)
        return cv2.resize(d, (w, h), interpolation=cv2.INTER_LINEAR)
    bg_fine = bg_est(work, fine, 3, 0)
    bg_coarse = bg_est(*coarse)
    # thick ink (headings, bold, filled shapes) survives a small dilation and would be mistaken for background:
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    sc = min(1.0, 800/max(h, w)); g = cv2.resize(gray, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
    ink = cv2.adaptiveThreshold(g, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 51, 14)
    k = max(5, int(0.012 * max(g.shape)))                               # ~ strokes thicker than 1.2% of the page
    thick = cv2.morphologyEx(ink, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    thick = cv2.dilate(thick, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    m = cv2.resize(thick, (w, h), interpolation=cv2.INTER_LINEAR).astype(np.float32)[:, :, None] / 255.0
    bg = bg_fine.astype(np.float32) * (1 - m) + bg_coarse.astype(np.float32) * m
    bg = np.maximum(bg, 96)
    return np.clip(rgb.astype(np.float32) * 255 / bg, 0, 255).astype(np.uint8)

if __name__ == "__main__":
    from image_algorithms_check import normalize_bg      # = the SHIPPED configuration (1000 px, dilate 5x5, median 3)
    clean = make_doc(); H, W = clean.shape
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    edge = (xx*0.9 + yy*0.35 - 0.62*W); alpha = 1/(1+np.exp(np.clip(edge/3.0, -50, 50)))
    img = (clean.astype(np.float32) * (1 - 0.55*alpha)).astype(np.uint8)           # hard-edged cast shadow (penumbra ~3 px)
    rgb = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
    paper = clean > 200; ink = clean < 100; head_ = np.zeros_like(ink); head_[80:400] = True; head_ &= ink; body = ink & ~head_
    band = paper & (np.abs(edge) < 14); inside = paper & (alpha > 0.9)
    box = clean.copy(); box[1650:1730, 100:600] = 128                               # a mid-grey filled box (shaded table header)
    rgb_box = cv2.cvtColor(box, cv2.COLOR_GRAY2RGB)
    def fine(r, work, dil, med, gauss=0):
        sc = min(1.0, work/max(r.shape[:2])); small = cv2.resize(r, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
        d = cv2.dilate(small, np.ones((dil, dil), np.uint8))
        if med: d = cv2.medianBlur(d, med)
        if gauss: d = cv2.GaussianBlur(d, (gauss, gauss), 0)
        bg = np.maximum(cv2.resize(d, (r.shape[1], r.shape[0])), 96)
        return np.clip(r.astype(np.float32)*255/bg, 0, 255).astype(np.uint8)
    configs = (("earlier: 480/9x9/med15/gauss21", lambda r: fine(r, 480, 9, 15, 21)), ("1000/9x9/med5", lambda r: fine(r, 1000, 9, 5)),
               ("1000/7x7/med5", lambda r: fine(r, 1000, 7, 5)), ("SHIPPED 1000/5x5/med3", lambda r: normalize_bg(r)))
    print("hard-edged shadow; clean ink = 30, grey box = 128, paper = 245")
    print(f"{'setting':32s} shadow-paper  edge-band mean/std | heading-ink | body-ink | grey box 128 ->")
    for name, fn in configs:
        o = fn(rgb)[:, :, 0]; ob = fn(rgb_box)[:, :, 0]
        print(f"{name:32s} {o[inside].mean():9.1f}   {o[band].mean():7.1f} / {o[band].std():5.1f} | {o[head_].mean():11.1f} | {o[body].mean():8.1f} | {ob[1650:1730, 100:600].mean():6.1f}")
    print(f"{'(no correction)':32s} {img[inside].mean():9.1f}   {img[band].mean():7.1f} / {img[band].std():5.1f}")
