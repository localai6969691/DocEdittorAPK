"""Kiểm chứng PdfStamper (phiên 15): đặt ảnh trong suốt (chữ ký / tem) lên trang theo TỈ LỆ trên trang đang hiển thị.

Bản Python song song của PdfStamper.rect_for + PdfPageGeometry. Với mỗi tổ hợp (xoay 0/90/180/270 x không/có CropBox lệch gốc
x 3 vị trí: giữa / sát góc trên-trái (phải bị kéo vào trong) / sát góc dưới-phải):
  - ảnh = hình chữ nhật tím có 2 nửa đỏ/xanh dương để lộ lật hoặc xoay sai; góc ảnh trong suốt (SMask) để thấy nền xanh lá của trang;
  - poppler (pdftoppm -cropbox) vẽ lại; đo: tâm ảnh đúng chỗ, nửa đỏ ở TRÁI-DƯỚI hay TRÊN-TRÁI đúng như ảnh gốc, vùng trong suốt hở nền.
Phần thuần: rect_for không bao giờ cho ảnh tràn mép, không rộng hơn trang, giữ tỉ lệ.
Chạy: python3 stamp_check.py   (cần pikepdf, numpy, pillow, pdftoppm)
"""
import os, subprocess, sys, zlib
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import numpy as np
from PIL import Image
import pikepdf
from pikepdf import Name, Dictionary
from page_geometry_check import Geometry, render, color_at, near

MIN_W, MAX_W = 0.04, 0.95


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def rect_for(cx_f, cy_f, w_f, aspect, dw, dh):
    aspect = aspect if aspect > 0.01 else 1.0
    w = clamp(w_f, MIN_W, MAX_W) * dw
    h = w / aspect
    if h > dh:
        h = dh; w = h * aspect
    cx = clamp(cx_f, 0, 1) * dw
    cy_top = clamp(cy_f, 0, 1) * dh
    x = clamp(cx - w / 2, 0, dw - w)
    y_top = clamp(cy_top - h / 2, 0, dh - h)
    return x, dh - y_top - h, w, h


def pure_tests():
    ok = True
    for (cx, cy, wf, asp, dw, dh) in [(.5, .5, .3, 3, 400, 600), (0, 0, .5, 2, 400, 600), (1, 1, .5, 2, 400, 600),
                                      (.5, .5, 2.0, 1, 400, 600), (.5, .5, .5, .01, 400, 600), (-3, 9, .2, 4, 300, 300),
                                      (.5, .5, .9, .2, 400, 300)]:
        x, y, w, h = rect_for(cx, cy, wf, asp, dw, dh)
        inside = x >= -1e-6 and y >= -1e-6 and x + w <= dw + 1e-6 and y + h <= dh + 1e-6
        ratio_ok = abs(w / h - (asp if asp > 0.01 else 1.0)) < 1e-6
        if not (inside and ratio_ok):
            ok = False; print("LOI rect_for", (cx, cy, wf, asp, dw, dh), "->", (x, y, w, h))
    x, y, w, h = rect_for(.5, .5, .3, 3, 400, 600)
    if abs(x - 140) > 1e-6 or abs(w - 120) > 1e-6 or abs(h - 40) > 1e-6 or abs(y - 280) > 1e-6:
        ok = False; print("LOI vi du tay", (x, y, w, h))
    print("ok  phan thuan" if ok else "LOI phan thuan")
    return ok


def make_image(pdf, w=60, h=20):
    """RGB: nửa trái đỏ, nửa phải xanh dương; SMask: 5x5 góc trên-trái trong suốt."""
    rgb = np.zeros((h, w, 3), np.uint8); rgb[:, : w // 2] = (255, 0, 0); rgb[:, w // 2:] = (0, 0, 255)
    alpha = np.full((h, w), 255, np.uint8); alpha[:6, :6] = 0
    sm = pdf.make_stream(zlib.compress(alpha.tobytes()))
    sm.Type = Name.XObject; sm.Subtype = Name.Image; sm.Width = w; sm.Height = h
    sm.ColorSpace = Name.DeviceGray; sm.BitsPerComponent = 8; sm.Filter = Name.FlateDecode
    im = pdf.make_stream(zlib.compress(rgb.tobytes()))
    im.Type = Name.XObject; im.Subtype = Name.Image; im.Width = w; im.Height = h
    im.ColorSpace = Name.DeviceRGB; im.BitsPerComponent = 8; im.Filter = Name.FlateDecode; im.SMask = sm
    return im, w / h


def build(path, mb, cb, rot, place):
    box = cb or mb
    g = Geometry(box[0], box[1], box[2] - box[0], box[3] - box[1], rot)
    pdf = pikepdf.new()
    pg = pdf.add_blank_page(page_size=(mb[2] - mb[0], mb[3] - mb[1]))
    pg.MediaBox = pikepdf.Array(mb)
    if cb: pg.CropBox = pikepdf.Array(cb)
    pg.Rotate = rot
    im, asp = make_image(pdf)
    a, b, c, d, e, f = g.matrix()
    x, y, w, h = rect_for(*place, asp, g.dw, g.dh)
    ops = (f"q {a} {b} {c} {d} {e} {f} cm 0 1 0 rg 0 0 {g.dw} {g.dh} re f Q\n"      # nền xanh lá, phủ trang
           f"q {a} {b} {c} {d} {e} {f} cm {w} 0 0 {h} {x} {y} cm /Im0 Do Q\n")
    pg.Resources = Dictionary(XObject=Dictionary(Im0=im))
    pg.Contents = pdf.make_stream(ops.encode())
    pdf.save(path)
    return g, (x, y, w, h)


def geometry_tests():
    fails = 0
    places = {"giua": (.5, .5, .4), "tren-trai": (0.0, 0.0, .5), "duoi-phai": (1.0, 1.0, .3)}
    for rot in (0, 90, 180, 270):
        for mb, cb in (((0, 0, 400, 600), None), ((-50, -40, 350, 560), (-30, -10, 330, 540))):
            for name, pl in places.items():
                p = os.path.join(OUT, f"stamp_{rot}_{'c' if cb else 'm'}_{name}.pdf")
                g, (x, y, w, h) = build(p, mb, cb, rot, pl)
                img = render(p)
                # 1px = 1pt. Hình ở khung hiển thị: góc trên-trái ảnh = (x, dh - y - h) tính từ trên-trái trang
                left, top = x, g.dh - y - h
                c_left = color_at(img, left + w * 0.25, top + h * 0.7)    # nửa trái: đỏ
                c_right = color_at(img, left + w * 0.75, top + h * 0.7)   # nửa phải: xanh dương
                c_hole = color_at(img, left + 2, top + 2)                 # góc trong suốt: thấy nền xanh lá
                ok = near(c_left, (255, 0, 0)) and near(c_right, (0, 0, 255)) and near(c_hole, (0, 255, 0), 60)
                inside = left >= -0.01 and top >= -0.01 and left + w <= g.dw + 0.01 and top + h <= g.dh + 0.01
                if not (ok and inside):
                    fails += 1
                print(("ok  " if ok and inside else "LOI"), f"rot={rot:3d} crop={'co' if cb else 'khong'} {name:9s} trai={c_left} phai={c_right} ho={c_hole}")
    return fails == 0


if __name__ == "__main__":
    good = pure_tests()
    good = geometry_tests() and good
    print("TAT CA DAT" if good else "CO LOI")
    sys.exit(0 if good else 1)
