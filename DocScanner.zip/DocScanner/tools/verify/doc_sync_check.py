#!/usr/bin/env python3
"""Checks that TECHNICAL_DOCS.md / README.md / tools/verify/README.md still match the code. Exit code 1 on any mismatch.
Run from the project root:  python3 tools/verify/doc_sync_check.py      (also runs in CI, see .github/workflows/android-build.yml)

What it checks (each one is a kind of drift that really happened - phiên 14 audit):
  1. every Kotlin file, layout and manifest activity is mentioned in the docs; every Kotlin file named in the file map (section 3) exists;
  2. the "Bảng phiên bản hiện hành" block in the docs equals build.gradle / settings / the CI workflow;
  3. the "Hằng số quan trọng" block in the docs equals the constants in the Kotlin sources;
  4. every tools/verify/*_check.py script is listed in tools/verify/README.md and vice versa;
  5. forbidden claims that were once true and are now false (e.g. "không dùng PDFBox") do not reappear in the docs;
  7. NARRATIVE axis: every bug ID in the change log (section 12) is defined in the bug register (section 7) and vice versa; every session
     number the docs mention has a change-log row; every feature row (section 11) names only classes/scripts that exist;
  6. the constants of the Python mirrors in tools/verify equal the Kotlin constants they imitate (the mirrors are what the
     measured numbers in the docs come from, so a silent difference would make those numbers describe a different algorithm).
"""
import ast, pathlib, re, sys

ROOT = pathlib.Path(__file__).resolve().parents[2]
DOCS = (ROOT / "TECHNICAL_DOCS.md").read_text(encoding="utf-8")
README = (ROOT / "README.md").read_text(encoding="utf-8")
JAVA = ROOT / "app/src/main/java/com/example/docscanner"
problems = []
def bad(msg): problems.append(msg); print("MISMATCH:", msg)

# ---- 1. files ----
kt = sorted(JAVA.rglob("*.kt"))
lines = DOCS.splitlines()
s3 = next(i for i, l in enumerate(lines) if l.startswith("## 3.")); s4 = next(i for i, l in enumerate(lines) if l.startswith("## 4."))
sec3 = "\n".join(lines[s3:s4])
mapped = set(re.findall(r"[├└]──\s+([A-Za-z0-9_]+\.kt)", sec3))
actual = {f.name for f in kt}
for n in sorted(actual - mapped): bad(f"{n} exists but is missing from the section-3 file map")
for n in sorted(mapped - actual): bad(f"{n} is in the section-3 file map but the file does not exist")
for f in kt:
    if f.stem not in DOCS + README: bad(f"{f.name} is not mentioned anywhere in the docs")
layouts = {f.stem for f in (ROOT / "app/src/main/res/layout").glob("*.xml")}
for n in sorted(l for l in layouts if l not in DOCS): bad(f"layout {n}.xml is not mentioned in TECHNICAL_DOCS.md")
manifest = (ROOT / "app/src/main/AndroidManifest.xml").read_text(encoding="utf-8")
for a in re.findall(r'android:name="\.(\w+)"', manifest):
    if a not in DOCS: bad(f"manifest activity {a} is not mentioned in TECHNICAL_DOCS.md")
HISTORICAL = {"PdfCanvasEditor"}      # deleted in phiên 11, still named in the history
for n in sorted(set(re.findall(r"\b([A-Z][A-Za-z0-9]+)\.kt\b", DOCS)) - {f.stem for f in kt} - HISTORICAL):
    bad(f"the docs name {n}.kt but no such file exists")

# ---- 2. versions ----
g = (ROOT / "app/build.gradle").read_text(encoding="utf-8"); root = (ROOT / "build.gradle").read_text(encoding="utf-8")
wf = (ROOT / ".github/workflows/android-build.yml").read_text(encoding="utf-8")
code = {
    "AGP": re.search(r"com\.android\.application' version '([\d.]+)'", root).group(1),
    "Kotlin": re.search(r"kotlin\.android' version '([\d.]+)'", root).group(1),
    "Gradle(CI)": re.search(r"gradle-version:\s*([\d.]+)", wf).group(1),
    "compileSdk": re.search(r"compileSdk (\d+)", g).group(1), "targetSdk": re.search(r"targetSdk (\d+)", g).group(1), "minSdk": re.search(r"minSdk (\d+)", g).group(1),
    "OpenCV": re.search(r"org\.opencv:opencv:([\d.]+)", g).group(1), "MLKit": re.search(r"mlkit:text-recognition:([\d.]+)", g).group(1),
    "PdfBox-Android": re.search(r"pdfbox-android:([\d.]+)", g).group(1), "CameraX": re.search(r'camerax_version = "([\d.]+)"', g).group(1),
}
for k, v in code.items():
    m = re.search(rf"^\s*{re.escape(k)}=([\d.]+)\s*$", DOCS, re.M)
    if not m: bad(f"version block in the docs has no line '{k}=...' (code has {v})")
    elif m.group(1) != v: bad(f"{k}: docs say {m.group(1)}, code says {v}")
for lib in ("chinese", "japanese", "korean", "devanagari"):
    m = re.search(rf"text-recognition-{lib}:([\d.]+)", g)
    if not m or m.group(1) != code["MLKit"]: bad(f"text-recognition-{lib} version is not the same as text-recognition ({code['MLKit']})")

# ---- 3. constants ----
def kotlin_const(cls, name):
    f = next((x for x in kt if x.stem == cls), None)
    if f is None: return None
    m = re.search(rf"\bconst val {re.escape(name)}(?::\s*\w+)?\s*=\s*([\d.]+)L?\b", f.read_text(encoding="utf-8"))
    return float(m.group(1)) if m else None
block = re.search(r"Hằng số quan trọng.*?```\n(.*?)```", DOCS, re.S)
if not block: bad("docs have no 'Hằng số quan trọng' block")
else:
    for ln in block.group(1).splitlines():
        if "=" not in ln: continue
        key, val = ln.strip().split("=", 1); cls, name = key.split(".")
        got = kotlin_const(cls, name)
        if got is None: bad(f"constant {key} not found in the Kotlin source")
        elif abs(got - float(val)) > 1e-9: bad(f"constant {key}: docs say {val}, code says {got}")

# ---- 4. tools/verify ----
tv = ROOT / "tools/verify"; tvr = (tv / "README.md").read_text(encoding="utf-8")
scripts = {f.name for f in tv.glob("*_check.py")}
for n in sorted(scripts):
    if n not in tvr: bad(f"tools/verify/{n} is not listed in tools/verify/README.md")
for n in sorted(set(re.findall(r"`([a-z_]+_check\.py)`", tvr)) - scripts): bad(f"tools/verify/README.md lists {n} but the file does not exist")

# ---- 5. claims that are no longer true ----
for pat, why in ((r"Không dùng thư viện PDF ngoài\*\* \(không iText/PDFBox\)", "the app DOES use PdfBox-Android since phiên 11"),
                 (r"OCR chỉ tạo file `\.txt` đi kèm, \*\*không\*\* nhúng", "a searchable-PDF tool exists since phiên 12"),
                 (r"Chỉ có build type `debug` \(workflow CI chỉ chạy `assembleDebug`\)", "release/AAB signing exists since phiên 11")):
    if re.search(pat, DOCS + README):
        bad(f"stale claim present: {why}")

# ---- 6. Python mirrors vs Kotlin constants ----
def python_values(path, scope=None):
    """name -> number for simple constant assignments (also tuple unpacking) at module level or inside class `scope`,
    plus default values of function parameters (as 'func.param')."""
    tree = ast.parse((tv / path).read_text(encoding="utf-8")); out = {}
    def num(node):
        try: v = ast.literal_eval(node); return float(v) if isinstance(v, (int, float)) else None
        except Exception: return None
    def collect(body, prefix=""):
        for node in body:
            if isinstance(node, ast.Assign):
                for tgt in node.targets:
                    if isinstance(tgt, ast.Name):
                        v = num(node.value)
                        if v is not None: out[prefix + tgt.id] = v
                    elif isinstance(tgt, ast.Tuple) and isinstance(node.value, ast.Tuple):
                        for n, vnode in zip(tgt.elts, node.value.elts):
                            v = num(vnode)
                            if isinstance(n, ast.Name) and v is not None: out[prefix + n.id] = v
            elif isinstance(node, ast.FunctionDef):
                args = node.args.args; defs = node.args.defaults
                for a_, d_ in zip(args[len(args) - len(defs):], defs):
                    v = num(d_)
                    if v is not None: out[f"{node.name}.{a_.arg}"] = v
            elif isinstance(node, ast.ClassDef) and scope == node.name:
                collect(node.body, prefix)
    collect(tree.body)
    return out

MIRRORS = [  # (Kotlin class, Kotlin const, python file, python scope class or None, python name)
    *[("CaptureStability", c, "stability_check.py", "CaptureStability", c) for c in
      ("MIN_AREA", "MAX_AREA", "MOVE_TOL", "REARM_MOVE", "HOLD_MS", "COOLDOWN_MS", "LOST_GRACE_MS", "REARM_LOST_MS", "SHARP_KEEP", "SHARP_WINDOW_MS", "SHARP_FLOOR")],
    ("PageOrientation", "MIN_COUNT", "orientation_check.py", None, "MIN_COUNT"),
    ("PageOrientation", "MIN_FRACTION", "orientation_check.py", None, "MIN_FRACTION"),
    ("PageOrientation", "MIN_CONF", "orientation_check.py", None, "MIN_CONF"),
    ("TextLineDewarp", "F_REL", "dewarp_model.py", None, "F_REL"),
    ("TextLineDewarp", "ACT_LO", "dewarp_model.py", None, "ACT_LO"),
    ("TextLineDewarp", "ACT_HI", "dewarp_model.py", None, "ACT_HI"),
    ("TextLineDewarp", "MAX_DISP_FRACTION", "dewarp_model.py", None, "MAX_DISP"),
    ("TextLineDewarp", "MIN_DISP_PX", "dewarp_model.py", None, "MIN_DISP_PX"),
    ("TextLineDewarp", "MIN_GAIN", "dewarp_model.py", None, "MIN_GAIN"),
    ("TextLineDewarp", "MAX_SHIFT_FRACTION", "dewarp_model.py", None, "MAX_SHIFT"),
    ("TextLineDewarp", "POLY_DEGREE", "dewarp_check.py", None, "POLY_DEG"),
    ("DocumentEnhancer", "SAUVOLA_K", "image_algorithms_check.py", None, "sauvola_mirror.k"),
    ("DocumentEnhancer", "SAUVOLA_R", "image_algorithms_check.py", None, "sauvola_mirror.R"),
    ("DocumentEnhancer", "SAUVOLA_WORK_EDGE", "image_algorithms_check.py", None, "sauvola_mirror.work"),
]
cache = {}
for kcls, kname, pfile, pscope, pname in MIRRORS:
    kv = kotlin_const(kcls, kname)
    key = (pfile, pscope)
    if key not in cache: cache[key] = python_values(pfile, pscope)
    pv = cache[key].get(pname)
    if kv is None: bad(f"Kotlin constant {kcls}.{kname} not found")
    elif pv is None: bad(f"Python mirror {pfile}: no constant '{pname}' (Kotlin {kcls}.{kname} = {kv})")
    elif abs(kv - pv) > 1e-9: bad(f"{kcls}.{kname} = {kv} in Kotlin but {pname} = {pv} in {pfile}")

# ---- 7. narrative axis: change log <-> bug register <-> feature inventory ----
def section(prefix):
    i = next((k for k, l in enumerate(lines) if l.startswith(prefix)), None)
    if i is None: return ""
    j = next((k for k in range(i + 1, len(lines)) if lines[k].startswith("## ")), len(lines))
    return "\n".join(lines[i:j])
sec7 = section("## 7."); sec11 = section("## 11."); sec12 = section("## 12.")
if not sec11: bad("docs have no section 11 (feature inventory)")
if not sec12: bad("docs have no section 12 (change log)")
def expand(text):
    ids = set(re.findall(r"\bB\d\d-\d\d\b", text))
    for a_, b_ in re.findall(r"\b(B\d\d-\d\d)…(B\d\d-\d\d)\b", text):
        pre, lo = a_.split("-"); _, hi = b_.split("-")
        ids |= {f"{pre}-{n:02d}" for n in range(int(lo), int(hi) + 1)}
    return ids
defined = set(re.findall(r"^\|\s*(B\d\d-\d\d)\s*\|", sec7, re.M))
logged = expand(sec12)
for i in sorted(logged - defined): bad(f"change log (section 12) cites {i} but section 7 does not define it")
for i in sorted(defined - logged): bad(f"section 7 defines {i} but the change log (section 12) never mentions it")
mentioned_sessions = {int(n) for n in re.findall(r"phiên(?: làm việc)?(?: thứ)? (\d+)", DOCS)}
rows = {int(n) for n in re.findall(r"^\|\s*(\d+)(?: \(suy ra\))?\s*\|", sec12, re.M)}
for n in sorted(x for x in mentioned_sessions if 1 <= x <= max(rows or {0}) and x not in rows): bad(f"session {n} is mentioned in the docs but has no row in the change log")
latest = max(mentioned_sessions) if mentioned_sessions else 0
if latest not in rows: bad(f"the newest session mentioned ({latest}) has no row in the change log")
classes = {f.stem for f in kt} | {"ImageProcessor", "ScanSessionManager"}
for cls in sorted(set(re.findall(r"`([A-Z][A-Za-z0-9]+)(?:\.\w+)?`", sec11))):
    if cls not in classes and cls not in {"Project", "ProjectManager", "AndroidManifest"}:
        bad(f"section 11 names `{cls}` which is not a Kotlin class/file of the app")
for script in sorted(set(re.findall(r"`([a-z_]+_check\.py)`", sec11 + sec12 + DOCS))):
    if not (tv / script).exists(): bad(f"the docs cite tools/verify/{script} which does not exist")

print()
print("DOC SYNC OK" if not problems else f"{len(problems)} MISMATCH(ES) - fix the docs (or the code)")
sys.exit(1 if problems else 0)
