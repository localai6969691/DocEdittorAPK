# Mirror of ToUnicodeReverse (PdfTextEditor.kt): parse a /ToUnicode CMap (bfchar + bfrange in both forms) and invert it.
import re

BF_CHAR = re.compile(r"beginbfchar(.*?)endbfchar", re.S)
BF_RANGE = re.compile(r"beginbfrange(.*?)endbfrange", re.S)
CHAR_PAIR = re.compile(r"<([0-9A-Fa-f\s]+)>\s*<([0-9A-Fa-f\s]+)>")
RANGE_ITEM = re.compile(r"<([0-9A-Fa-f\s]+)>\s*<([0-9A-Fa-f\s]+)>\s*(?:<([0-9A-Fa-f\s]+)>|\[(.*?)])", re.S)
HEX = re.compile(r"<([0-9A-Fa-f\s]+)>")
hexof = lambda t: "".join(t.split())

def single_cp(h):
    h = hexof(h)
    if not h or (len(h) % 4 != 0 and len(h) != 2): return None
    if len(h) == 2: h = "00" + h
    s = bytes.fromhex(h).decode("utf-16-be", errors="replace")
    return ord(s) if len(s) == 1 else None

def parse(cmap):
    res = {}
    def add(cp, code, nbytes):
        if cp and cp > 0 and 1 <= nbytes <= 4: res.setdefault(cp, (code, nbytes))
    for sec in BF_CHAR.finditer(cmap):
        for m in CHAR_PAIR.finditer(sec.group(1)):
            src = hexof(m.group(1))
            if src and len(src) % 2 == 0 and len(src) <= 8: add(single_cp(m.group(2)), int(src, 16), len(src) // 2)
    for sec in BF_RANGE.finditer(cmap):
        for m in RANGE_ITEM.finditer(sec.group(1)):
            lo, hi = hexof(m.group(1)), hexof(m.group(2))
            if not lo or len(lo) != len(hi) or len(lo) % 2 or len(lo) > 8: continue
            a, b = int(lo, 16), int(hi, 16)
            if b < a or b - a > 0xFFFF: continue
            if m.group(3):
                base = single_cp(m.group(3))
                if base is None: continue
                for i in range(b - a + 1): add(base + i, a + i, len(lo) // 2)
            else:
                for i, t in enumerate(HEX.finditer(m.group(4))):
                    if a + i > b: break
                    add(single_cp(t.group(1)), a + i, len(lo) // 2)
    return res

if __name__ == "__main__":
    cmap = """/CIDInit /ProcSet findresource begin 12 dict begin begincmap
/CMapName /Adobe-Identity-UCS def /CMapType 2 def
1 begincodespacerange <0000> <FFFF> endcodespacerange
2 beginbfchar
<0003> <0020>
<0024> <0041>
endbfchar
2 beginbfrange
<0025> <0027> <0042>
<0030> <0032> [<0061> <0062> <00E1>]
endbfrange
endcmap"""
    got = {chr(cp): code for cp, (code, n) in parse(cmap).items()}
    want = {" ": 0x03, "A": 0x24, "B": 0x25, "C": 0x26, "D": 0x27, "a": 0x30, "b": 0x31, "\u00e1": 0x32}
    print("parsed:", {k: hex(v) for k, v in got.items()})
    ok = got == want
    print("ToUnicodeReverse mirror OK" if ok else f"MISMATCH, wanted {want}")
    raise SystemExit(0 if ok else 1)
