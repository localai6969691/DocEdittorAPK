# Generates the PDFs used by structure_optimizer_check.py: a 12-page text+image document (rl.pdf) and a 2-page document
# whose pages embed the SAME JPEG as two separate objects, like a merged PDF (dup.pdf).
import io, random, sys
sys.path.insert(0, ".")
from _common import OUT
from reportlab.pdfgen import canvas
from reportlab.lib.utils import ImageReader
from PIL import Image
import pikepdf
from pikepdf import Name, Dictionary

def make_rl(path):
    c = canvas.Canvas(path, pagesize=(595, 842), pageCompression=0)
    c.setTitle("Thu nghiem tieng Viet / test #1 (a)"); c.setAuthor("A B")
    def img(seed):
        random.seed(seed); im = Image.new("RGB", (200, 120)); im.putdata([(random.randint(0, 255), 30, 60) for _ in range(200*120)])
        b = io.BytesIO(); im.save(b, "PNG"); b.seek(0); return b
    for p in range(12):
        c.setFont("Helvetica", 14); c.drawString(72, 780, f"Page {p+1} of test document ({p}) [x] /name %percent")
        c.setFont("Times-Roman", 11)
        for i in range(40): c.drawString(72, 740 - i*12, f"Line {i}: the quick brown fox jumps over the lazy dog {p*i}")
        c.drawImage(ImageReader(img(7)), 72, 100, 200, 120); c.drawImage(ImageReader(img(8 if p % 2 else 9)), 300, 100, 200, 120)
        c.showPage()
    c.save()

def make_dup(path):
    random.seed(3); im = Image.new("RGB", (120, 80)); im.putdata([(random.randint(0, 255), 50, 90) for _ in range(120*80)])
    buf = io.BytesIO(); im.save(buf, "JPEG", quality=80); jpg = buf.getvalue()
    pdf = pikepdf.new()
    for i in range(2):
        xo = pdf.make_stream(jpg); xo.Type = Name.XObject; xo.Subtype = Name.Image; xo.Width = 120; xo.Height = 80
        xo.ColorSpace = Name.DeviceRGB; xo.BitsPerComponent = 8; xo.Filter = Name.DCTDecode
        pg = pdf.add_blank_page(page_size=(300, 200)); pg.Resources = Dictionary(XObject=Dictionary(Im0=xo))
        pg.Contents = pdf.make_stream(b"q 240 0 0 160 30 20 cm /Im0 Do Q\n")
    pdf.save(path)

if __name__ == "__main__":
    make_rl(f"{OUT}/rl.pdf"); make_dup(f"{OUT}/dup.pdf"); print("written to", OUT)
