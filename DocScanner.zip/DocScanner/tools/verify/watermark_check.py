# Watermark placement maths (mirror of PdfWatermark): a diagonal image centred on the crop box, correct on rotated pages.
import math, subprocess, io, numpy as np, pikepdf
from _common import OUT
from pikepdf import Name, Dictionary, Array
from PIL import Image, ImageDraw, ImageFont

def make_wm_png(w=900, h=220):
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    f = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 150)
    d.text((20, 15), "BẢO MẬT", fill=(128, 128, 128, 90), font=f); return im

def build(path, rot, cropbox=None):
    pdf = pikepdf.new(); page = pdf.add_blank_page(page_size=(595, 842)); page.Rotate = rot
    if cropbox: page.CropBox = Array(cropbox)
    page.Contents = pdf.make_stream(b"1 g 0 0 595 842 re f\n")          # white page
    im = make_wm_png(); rgb = im.convert("RGB"); alpha = im.split()[3]
    xo = pdf.make_stream(rgb.tobytes()); xo.Type = Name.XObject; xo.Subtype = Name.Image; xo.Width = im.width; xo.Height = im.height
    xo.ColorSpace = Name.DeviceRGB; xo.BitsPerComponent = 8
    sm = pdf.make_stream(alpha.tobytes()); sm.Type = Name.XObject; sm.Subtype = Name.Image; sm.Width = im.width; sm.Height = im.height
    sm.ColorSpace = Name.DeviceGray; sm.BitsPerComponent = 8; xo.SMask = sm
    page.Resources = Dictionary(XObject=Dictionary(Wm=xo))
    cb = cropbox or [0, 0, 595, 842]
    cw, ch = cb[2]-cb[0], cb[3]-cb[1]
    cx, cy = cb[0] + cw/2, cb[1] + ch/2
    w_pt = min(cw, ch) * 0.9; h_pt = w_pt * im.height / im.width
    theta = math.radians(45 + rot)                               # appears at 45 deg on screen for a page with /Rotate = rot
    c, s = math.cos(theta), math.sin(theta)
    # q  [c s -s c cx cy] cm  [w 0 0 h -w/2 -h/2] cm  /Wm Do  Q
    cs = f"q\n{c:.6f} {s:.6f} {-s:.6f} {c:.6f} {cx:.3f} {cy:.3f} cm\n{w_pt:.3f} 0 0 {h_pt:.3f} {-w_pt/2:.3f} {-h_pt/2:.3f} cm\n/Wm Do\nQ\n".encode()
    page.Contents = Array([page.Contents, pdf.make_stream(cs)]); pdf.save(path)

def analyse(path):
    subprocess.run(["pdftoppm", "-r", "50", "-png", "-singlefile", path, path[:-4]], check=True)
    img = np.array(Image.open(path[:-4] + ".png").convert("L")).astype(float)
    mask = img < 245; ys, xs = np.nonzero(mask)
    if len(xs) < 50: return None
    cx, cy = xs.mean()/img.shape[1], ys.mean()/img.shape[0]
    cov = np.cov(np.vstack([xs, ys])); w, v = np.linalg.eigh(cov); major = v[:, 1]
    ang = math.degrees(math.atan2(-major[1], major[0])) % 180                 # screen angle of the long axis, CCW from +x
    return cx, cy, ang, img.shape

for rot, cb in ((0, None), (90, None), (180, None), (270, None), (0, [50, 100, 500, 700])):
    p = f"{OUT}/wm_{rot}_{'cb' if cb else 'nocb'}.pdf"; build(p, rot, cb); r = analyse(p)
    print(f"/Rotate {rot:3d} {'CropBox' if cb else '       '}: centroid ({r[0]:.3f}, {r[1]:.3f}) of the displayed page, long axis at {r[2]:5.1f} deg  (want ~0.500,0.500 and 45 deg) page px {r[3]}")
