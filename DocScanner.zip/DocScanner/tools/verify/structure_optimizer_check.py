# Python mirror of PdfStructureOptimizer.writeOptimized (layout arithmetic, names, numbers, strings),
# checked against qpdf / poppler / pypdf / pikepdf. Same algorithm, same constants as the Kotlin.
import pikepdf, zlib, hashlib, struct, io, decimal
from pikepdf import Name, Stream, Dictionary, Array, String, Object, ObjectType

OBJSTM_N = 100

def deflate(b): return zlib.compress(b, 9)

def esc_name(n):
    assert n.startswith('/')
    out = '/'
    for ch in n[1:]:
        c = ord(ch)
        if c < 0x21 or c > 0x7E: raise ValueError("non-ascii name")
        out += '#%02X' % c if ch in '()<>[]{}/%#' else ch
    return out

class Ctx:
    def __init__(s): s.num = {}          # id(obj) key -> new number
    
def key(o): return o.objgen        # (num, gen) for indirect objects

def ser(o, refs, top=False):
    t = o._type_code if hasattr(o, "_type_code") else None
    ty = o.__class__.__name__
    if isinstance(o, (bool,)): return b"true" if o else b"false"
    if isinstance(o, int): return str(o).encode()
    if isinstance(o, decimal.Decimal): return format(o, 'f').encode()
    if isinstance(o, float): return repr(o).encode()
    if o is None: return b"null"
    if isinstance(o, pikepdf.Object):
        if o.is_indirect and refs is not None and not top:
            n = refs(o)
            return b"null" if n is None else f"{n} 0 R".encode()
        tc = o._type_code
        if tc == ObjectType.name_: return esc_name(str(o)).encode()
        if tc == ObjectType.string: return b"<" + bytes(o).hex().encode() + b">"
        if tc == ObjectType.array: return b"[" + b" ".join(ser(x, refs) for x in o) + b"]"
        if tc == ObjectType.dictionary: return serdict(o, refs, set(), [])
        if tc == ObjectType.boolean: return b"true" if bool(o) else b"false"
        if tc == ObjectType.null: return b"null"
        if tc == ObjectType.integer: return str(int(o)).encode()
        if tc == ObjectType.real: return format(decimal.Decimal(str(o)), 'f').encode()
        raise ValueError("unsupported " + str(tc))
    if isinstance(o, str): return esc_name(o).encode()
    raise ValueError("unsupported python type " + ty)

def serdict(d, refs, skip, extra):
    out = b"<<"
    for k in d.keys():
        if k in skip: continue
        out += esc_name(k).encode() + b" " + ser(d[k], refs) + b"\n"
    for k, v in extra: out += esc_name(k).encode() + b" " + v + b"\n"
    return out + b">>"

def optimize(src, dst):
    pdf = pikepdf.open(src)
    trailer = pdf.trailer
    # discover (BFS from Root, Info)
    order, seen, queue = [], set(), [trailer.Root] + ([trailer.Info] if "/Info" in trailer else [])
    qi = 0
    while qi < len(queue):
        b = queue[qi]; qi += 1
        if not isinstance(b, pikepdf.Object): continue
        if b.is_indirect:
            k = key(b)
            if k in seen: continue
            seen.add(k); order.append(b)
        tc = b._type_code
        if tc in (ObjectType.dictionary, ObjectType.stream):
            for kk in b.keys():
                if tc == ObjectType.stream and kk == "/Length": continue
                queue.append(b[kk])
        elif tc == ObjectType.array:
            queue.extend(list(b))
    # classify + prepare + number
    numof, streams, plain, canon = {}, [], [], {}
    nxt = 1
    for o in order:
        if o._type_code == ObjectType.null: continue
        if o._type_code == ObjectType.stream:
            raw = o.read_raw_bytes()
            f = o.get("/Filter")
            add_flate = False
            if f is None:
                typ = o.get("/Type")
                if not (typ is not None and str(typ) == "/Metadata") and "/DecodeParms" not in o and len(raw) >= 64:
                    d = deflate(raw)
                    if len(d) < len(raw): raw, add_flate = d, True
            elif str(f) == "/FlateDecode" or (f._type_code == ObjectType.array and len(f) == 1 and str(f[0]) == "/FlateDecode"):
                try:
                    inf = zlib.decompress(raw)
                    d = deflate(inf)
                    if len(d) < len(raw): raw = d
                except Exception: pass
            # dedupe signature
            try:
                sd = serdict(o, lambda x: (_ for _ in ()).throw(ValueError("ref")), {"/Length"}, [("/Length", str(len(raw)).encode())] + ([("/Filter", b"/FlateDecode")] if add_flate else []))
                sig = hashlib.sha256(sd + b"\0" + raw).hexdigest()
            except ValueError:
                sig = None
            if sig is not None and sig in canon:
                numof[key(o)] = canon[sig]
            else:
                n = nxt; nxt += 1; numof[key(o)] = n
                streams.append((n, o, raw, add_flate))
                if sig is not None: canon[sig] = n
        else:
            n = nxt; nxt += 1; numof[key(o)] = n; plain.append((n, o))
    refs = lambda o: numof.get(key(o))
    out = io.BytesIO(); pos = lambda: out.tell()
    ver = max(float(pdf.pdf_version), 1.5)
    out.write(f"%PDF-{ver:.1f}\n".encode()); out.write(b"%\xE2\xE3\xCF\xD3\n")
    offsets, inobj = {}, {}
    for n, o, raw, add_flate in streams:
        offsets[n] = pos()
        extra = ([("/Filter", b"/FlateDecode")] if add_flate else []) + [("/Length", str(len(raw)).encode())]
        out.write(f"{n} 0 obj\n".encode() + serdict(o, refs, {"/Length"}, extra) + b"\nstream\n" + raw + b"\nendstream\nendobj\n")
    nextnum = nxt
    for i in range(0, len(plain), OBJSTM_N):
        chunk = plain[i:i+OBJSTM_N]; body = io.BytesIO(); header = ""
        for idx, (n, o) in enumerate(chunk):
            header += f"{n} {body.tell()} "
            body.write(ser(o, refs, top=True)); body.write(b"\n")
            inobj[n] = (nextnum, idx)
        hb = (header.rstrip() + "\n").encode()
        packed = deflate(hb + body.getvalue())
        stm = nextnum; nextnum += 1; offsets[stm] = pos()
        out.write(f"{stm} 0 obj\n<< /Type /ObjStm /N {len(chunk)} /First {len(hb)} /Filter /FlateDecode /Length {len(packed)} >>\nstream\n".encode() + packed + b"\nendstream\nendobj\n")
    xnum = nextnum; nextnum += 1; xoff = pos(); offsets[xnum] = xoff; size = xnum + 1
    rows = io.BytesIO()
    def row(t, f2, f3): rows.write(bytes([t]) + struct.pack(">I", f2) + struct.pack(">H", f3))
    row(0, 0, 0xFFFF)
    for n in range(1, size):
        if n in offsets: row(1, offsets[n], 0)
        elif n in inobj: row(2, inobj[n][0], inobj[n][1])
        else: row(0, 0, 0)
    xd = deflate(rows.getvalue())
    tt = f"<< /Type /XRef /Size {size} /W [1 4 2] /Root {numof[key(trailer.Root)]} 0 R ".encode()
    if "/Info" in trailer and key(trailer.Info) in numof: tt += f"/Info {numof[key(trailer.Info)]} 0 R ".encode()
    if "/ID" in trailer: tt += b"/ID " + ser(trailer.ID, refs) + b" "
    tt += f"/Filter /FlateDecode /Length {len(xd)} >>".encode()
    out.write(f"{xnum} 0 obj\n".encode() + tt + b"\nstream\n" + xd + b"\nendstream\nendobj\n")
    out.write(f"startxref\n{xoff}\n%%EOF\n".encode())
    open(dst, "wb").write(out.getvalue())
    return len(streams), len(plain)

if __name__ == "__main__":
    import sys, subprocess, os, glob
    sys.path.insert(0, ".")
    from _common import OUT
    import make_test_pdfs as M
    import pypdf
    if len(sys.argv) == 3: jobs = [(sys.argv[1], sys.argv[2])]
    else:
        M.make_rl(f"{OUT}/rl.pdf"); M.make_dup(f"{OUT}/dup.pdf")
        import text_layer_check as T
        T.make(f"{OUT}/t3_0.pdf", 0); T.make(f"{OUT}/t3_90.pdf", 90)
        jobs = [(f"{OUT}/{n}.pdf", f"{OUT}/opt_{n}.pdf") for n in ("rl", "dup", "t3_0", "t3_90")]
    for src, dst in jobs:
        ns, npl = optimize(src, dst)
        print(f"{os.path.basename(src)}: {os.path.getsize(src)} -> {os.path.getsize(dst)} bytes ({100*(os.path.getsize(dst)/os.path.getsize(src)-1):+.0f}%); streams={ns} plain={npl}")
        chk = subprocess.run(["qpdf", "--check", dst], capture_output=True, text=True)
        print("  qpdf:", chk.returncode, (chk.stdout + chk.stderr).strip().splitlines()[-1])
        a = subprocess.run(["pdftotext", "-enc", "UTF-8", src, "-"], capture_output=True, text=True).stdout
        b = subprocess.run(["pdftotext", "-enc", "UTF-8", dst, "-"], capture_output=True, text=True)
        print("  poppler text identical:", a == b.stdout, "| stderr:", b.stderr.strip()[:100] or "-")
        r1, r2 = pypdf.PdfReader(src), pypdf.PdfReader(dst)
        same = len(r1.pages) == len(r2.pages) and all(r1.pages[i].get_contents().get_data() == r2.pages[i].get_contents().get_data() for i in range(len(r1.pages)))
        print("  pypdf pages/content identical:", same, len(r2.pages))
        stem = os.path.join(OUT, "px_" + os.path.basename(src)[:-4])
        subprocess.run(["pdftoppm", "-r", "40", "-png", src, stem + "_a"], capture_output=True); subprocess.run(["pdftoppm", "-r", "40", "-png", dst, stem + "_b"], capture_output=True)
        A = sorted(glob.glob(stem + "_a-*.png")); B = sorted(glob.glob(stem + "_b-*.png"))
        print("  poppler renders identical pixels on", len(A), "pages:", len(A) == len(B) and all(open(x, "rb").read() == open(y, "rb").read() for x, y in zip(A, B)))
        if os.path.basename(src) == "dup.pdf":
            b2 = pikepdf.open(dst); print("  distinct image objects across the 2 pages:", len({p.Resources.XObject.Im0.objgen for p in b2.pages}))
