# Math check for rotated OCR words (ML Kit cornerPoints: TL, TR, BR, BL of the word in bitmap pixels) -> text matrix.
import math, subprocess, re, pikepdf
from _common import OUT
from pikepdf import Name, Dictionary, Array
import text_layer_check as t3

def word_matrix(geo, corners_px, sx, sy, text_len, fs_ratio=1.0):
    TL, TR, BR, BL = [(x*sx, y*sy) for x, y in corners_px]                  # visible points, v downward
    w = math.dist(TL, TR); h = math.dist(TL, BL)
    dirv = ((TR[0]-TL[0])/w, (TR[1]-TL[1])/w); upv = ((TL[0]-BL[0])/h, (TL[1]-BL[1])/h)
    org = (BL[0] + 0.2*h*upv[0], BL[1] + 0.2*h*upv[1])                       # baseline 0.2 em above the bottom-left corner
    o = geo.to_user(*org); d1 = geo.to_user(org[0]+dirv[0], org[1]+dirv[1]); u1 = geo.to_user(org[0]+upv[0], org[1]+upv[1])
    a, b = d1[0]-o[0], d1[1]-o[1]; c, d = u1[0]-o[0], u1[1]-o[1]
    tz = max(1, min(5000, 100*w/(text_len*0.5*h)))
    return h, tz, (a, b, c, d, o[0], o[1]), (w, h)

def make(path, rot, phi_deg):
    pdf = pikepdf.new(); page = pdf.add_blank_page(page_size=(595, 842)); page.Rotate = rot
    page.Contents = pdf.make_stream(b"0.9 g 10 10 20 20 re f\n")
    BW, BH = (1653, 2339) if rot in (0, 180) else (2339, 1653)
    sx, sy = (595 if rot in (0, 180) else 842)/BW, (842 if rot in (0, 180) else 595)/BH
    text = "Hello"; cps = [ord(c) for c in text]; allc = sorted(set(cps) | {32}); idx = {c: i for i, c in enumerate(allc)}
    font = t3.build_font(pdf, allc)
    page.Resources = Dictionary(Font=Dictionary({"/OcrF1": font}))
    geo = t3.Geo(595, 842, rot)
    # a word 400x60 px whose baseline is tilted by phi degrees clockwise on screen, top-left at (500, 700)
    phi = math.radians(phi_deg); w_px, h_px = 400.0, 60.0
    TL = (500.0, 700.0)
    TR = (TL[0] + w_px*math.cos(phi), TL[1] + w_px*math.sin(phi))
    BL = (TL[0] - h_px*math.sin(phi), TL[1] + h_px*math.cos(phi))
    BR = (TR[0] - h_px*math.sin(phi), TR[1] + h_px*math.cos(phi))
    fs, tz, (a, b, c, d, x, y), (w_pt, h_pt) = word_matrix(geo, [TL, TR, BR, BL], sx, sy, len(cps))
    hexs = "".join("%02X" % (idx[c]+1) for c in cps)
    cs = f"q\nBT\n3 Tr\n/OcrF1 {fs:.3f} Tf {tz:.3f} Tz {a:.5f} {b:.5f} {c:.5f} {d:.5f} {x:.3f} {y:.3f} Tm <{hexs}> Tj\nET\nQ\n".encode()
    page.Contents = Array([page.Contents, pdf.make_stream(cs)]); pdf.save(path)
    # expected axis-aligned bbox (visible top-left origin, points) of the rotated rectangle
    pts = [(p[0]*sx, p[1]*sy) for p in (TL, TR, BR, BL)]
    return (min(p[0] for p in pts), min(p[1] for p in pts), max(p[0] for p in pts), max(p[1] for p in pts))

for rot in (0, 90, 180, 270):
    for phi in (0, 15, -25):
        p = f"{OUT}/rw_{rot}_{phi}.pdf"; exp = make(p, rot, phi)
        out = subprocess.run(["pdftotext", "-bbox", "-enc", "UTF-8", p, "-"], capture_output=True, text=True).stdout
        m = re.search(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(\w+)</word>', out)
        if not m: print(rot, phi, "NO WORD FOUND:", out[-200:]); continue
        got = tuple(map(float, m.groups()[:4])); word = m.group(5)
        # poppler reports the word box in the ROTATED (displayed) page frame for /Rotate pages
        print(f"rot {rot:3d} phi {phi:4d}: word {word!r} poppler x {got[0]:6.1f}-{got[2]:6.1f} y {got[1]:6.1f}-{got[3]:6.1f}   expected x {exp[0]:6.1f}-{exp[2]:6.1f} y {exp[1]:6.1f}-{exp[3]:6.1f}")

print()
print("Baseline angle measured from the letter positions (pdfplumber), displayed page; must equal the angle the word was given:")
import pdfplumber
worst = 0.0
for rot in (0, 90, 180, 270):
    for phi in (0, 15, -25):
        with pdfplumber.open(f"{OUT}/rw_{rot}_{phi}.pdf") as pdf:
            ch = [c for c in pdf.pages[0].chars if c["text"].strip()]
        pts = [((c["x0"]+c["x1"])/2, (c["top"]+c["bottom"])/2) for c in ch]
        xs = [q[0] for q in pts]; ys = [q[1] for q in pts]; n = len(pts); mx, my = sum(xs)/n, sum(ys)/n
        ang = math.degrees(math.atan2(sum((x-mx)*(y-my) for x, y in zip(xs, ys)), sum((x-mx)**2 for x in xs)))
        worst = max(worst, abs(ang - phi))
        print(f"  /Rotate {rot:3d}  given {phi:4d} deg  measured {ang:7.2f} deg  letters {''.join(c['text'] for c in ch)}")
print(f"worst error {worst:.2f} deg")
