# Python mirror of TextLineDewarp: straighten curled text lines (vertical displacement model).
# Idea: A. Ulges, C. Lampert, T. Breuel, "Document image dewarping using robust estimation of curled text lines",
# ICDAR 2005 (text lines of a flat page are straight; estimate each curled line robustly, map it back to a straight line).
import cv2, numpy as np

POLY_DEG = 3

def ink_mask(gray, work):
    sc = min(1.0, work/max(gray.shape)); small = cv2.resize(gray, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
    ink = cv2.adaptiveThreshold(small, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY_INV, 31, 12)
    return small, ink, sc

def robust_polyfit(xs, ys, deg=POLY_DEG, iters=3):
    xs = np.asarray(xs, np.float64); ys = np.asarray(ys, np.float64)
    keep = np.ones(len(xs), bool); coef = None
    for _ in range(iters):
        if keep.sum() < deg + 2: return None
        x0 = xs[keep].mean(); coef = np.polyfit(xs[keep] - x0, ys[keep], deg); coef = (coef, x0)
        res = ys - np.polyval(coef[0], xs - x0); s = np.median(np.abs(res)) * 1.4826 + 1e-6
        keep = np.abs(res) < max(2.5 * s, 1.5)
    return coef

def find_lines(ink):
    """text-line blobs: letters merged horizontally; returns list of (xs, ys) centre samples per blob"""
    n, lab, st, _ = cv2.connectedComponentsWithStats(ink, connectivity=8)
    hs = np.array([st[i, cv2.CC_STAT_HEIGHT] for i in range(1, n) if 3 <= st[i, cv2.CC_STAT_HEIGHT] <= ink.shape[0]//8 and st[i, cv2.CC_STAT_AREA] >= 6])
    if len(hs) < 30: return [], 0
    h = float(np.median(hs))                                   # typical glyph height
    txt = np.zeros_like(ink)
    for i in range(1, n):
        H, W, A = st[i, cv2.CC_STAT_HEIGHT], st[i, cv2.CC_STAT_WIDTH], st[i, cv2.CC_STAT_AREA]
        if 2 <= H <= 4.5 * h and W <= 12 * h and A >= 4: txt[lab == i] = 255       # drop pictures / rules / huge blobs
    kx = max(9, int(2.2 * h)); ky = max(1, int(0.25 * h))
    merged = cv2.dilate(txt, cv2.getStructuringElement(cv2.MORPH_RECT, (kx, ky)))
    n2, lab2, st2, _ = cv2.connectedComponentsWithStats(merged, connectivity=8)
    lines = []
    for i in range(1, n2):
        x, y, w, hh, a = st2[i]
        if w < 0.22 * ink.shape[1] or hh > 3.2 * h + 0.10 * ink.shape[0]: continue      # too short / clearly several lines merged
        mask = (lab2[y:y+hh, x:x+w] == i) & (txt[y:y+hh, x:x+w] > 0)
        xs, cs, ext = [], [], []
        step = max(1, int(h // 2))
        for cx in range(0, w, step):
            col = np.where(mask[:, cx:cx+step].any(axis=1))[0]
            if len(col) < 2: continue
            xs.append(x + cx + step/2); cs.append(y + 0.5*(col.min() + col.max())); ext.append(col.max() - col.min())
        if len(xs) >= 8 and np.median(ext) <= 2.4 * h: lines.append((np.array(xs), np.array(cs)))   # one line = thin at every column
    return lines, h

def dewarp(gray, work=1000, strength=1.0):
    """returns (dewarped gray, info). The map is estimated on a downscaled copy and applied at full size."""
    small, ink, sc = ink_mask(gray, work)
    lines, h = find_lines(ink)
    if len(lines) < 4: return gray, "too-few-lines"
    models = []
    for xs, cs in lines:
        m = robust_polyfit(xs, cs)
        if m is not None: models.append((xs.min(), xs.max(), m))
    if len(models) < 4: return gray, "fit-failed"
    Wd, Hd = small.shape[1], small.shape[0]
    X = np.arange(Wd, dtype=np.float64)
    ycen = np.full((len(models), Wd), np.nan); disp = np.full((len(models), Wd), np.nan)
    maxdisp = 0.0
    for k, (x0, x1, (coef, xm)) in enumerate(models):
        inside = (X >= x0) & (X <= x1)
        f = np.polyval(coef, X[inside] - xm)
        target = f.mean()                                          # keep the line where it is on average, make it straight
        ycen[k, inside] = f; disp[k, inside] = (target - f) * strength
    # too wild a correction means the fit is not a text line (pictures, tables): give up rather than tear the page
    if np.nanmax(np.abs(disp)) > 0.08 * Hd: return gray, "displacement-too-large"
    if np.nanmax(np.abs(disp)) < 2.0: return gray, "already-straight"                 # not worth a resample
    # the correction must really straighten the lines it was estimated from
    before, after = [], []
    for (xs, cs) in lines:
        p1 = np.polyfit(xs, cs, 1); before.append(np.sqrt(np.mean((cs - np.polyval(p1, xs))**2)))
        d_at = np.array([np.nanmean(disp[k, int(min(max(x, 0), Wd-1))] for k in range(0)) if False else 0.0 for x in xs])
    for k, (x0, x1, (coef, xm)) in enumerate(models):
        inside = (X >= x0) & (X <= x1); xs_ = X[inside]; f = np.polyval(coef, xs_ - xm)
        c1 = np.polyfit(xs_, f, 1); before.append(np.sqrt(np.mean((f - np.polyval(c1, xs_))**2)))
        g = f + disp[k, inside]; c2 = np.polyfit(xs_, g, 1); after.append(np.sqrt(np.mean((g - np.polyval(c2, xs_))**2)))
    b_m, a_m = float(np.mean(before[len(lines):])), float(np.mean(after))
    if a_m > 0.85 * b_m: return gray, f"not-better ({b_m:.2f}->{a_m:.2f})"
    D = np.zeros((Hd, Wd), np.float32)
    Yg = np.arange(Hd, dtype=np.float64)
    for x in range(Wd):
        m = ~np.isnan(ycen[:, x])
        if m.sum() < 2: continue
        yc, dd = ycen[m, x], disp[m, x]; o = np.argsort(yc)
        D[:, x] = np.interp(Yg, yc[o], dd[o])                     # linear between line centres, constant outside
    # backward map: output row y_out samples source row y_src with y_src + D(x, y_src) = y_out  (2 fixed-point steps)
    ys_out = np.repeat(Yg[:, None], Wd, axis=1).astype(np.float32)
    src = ys_out.copy()
    cols = np.arange(Wd)[None, :].repeat(Hd, axis=0)
    for _ in range(3):
        src = ys_out - cv2.remap(D, cols.astype(np.float32), src, cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    # upscale the map to full size and apply
    full_h, full_w = gray.shape
    mapy = cv2.resize(src, (full_w, full_h), interpolation=cv2.INTER_LINEAR) / sc
    mapx = np.tile(np.arange(full_w, dtype=np.float32)[None, :], (full_h, 1))
    out = cv2.remap(gray, mapx, mapy.astype(np.float32), cv2.INTER_LINEAR, borderMode=cv2.BORDER_REPLICATE)
    return out, f"lines {len(models)}, max displacement {np.nanmax(np.abs(disp))/sc:.1f}px"

def straightness(gray, work=1000):
    """RMS residual (px at working scale) of every text line from its own least-squares straight line"""
    small, ink, sc = ink_mask(gray, work); lines, h = find_lines(ink); res = []
    for xs, cs in lines:
        p = np.polyfit(xs, cs, 1); res.append(np.sqrt(np.mean((cs - np.polyval(p, xs))**2)))
    return (float(np.mean(res)) if res else float("nan")), len(res)

if __name__ == "__main__":
    import orientation_check as O
    def warp(a, amp, kind):
        H, W = a.shape; yy, xx = np.mgrid[0:H, 0:W].astype(np.float32); u = (xx/W - 0.5)*2
        if kind == "bowl":   dy = amp * u**2 * (0.4 + 0.6*yy/H)
        elif kind == "wave": dy = amp * np.sin(2*np.pi*xx/W*1.2) * (0.5 + 0.5*yy/H)
        else:                dy = amp * np.maximum(u, 0)**2
        return cv2.remap(a, xx, (yy - dy).astype(np.float32), cv2.INTER_LINEAR, borderValue=245)
    def two_col(a):
        h, w = a.shape; b = np.full_like(a, 245); b[:, :w//2 - 30] = a[:, 100:100 + w//2 - 30]; b[:, w//2 + 30:] = a[:, 100:100 + w//2 - 30]; return b
    def picture(a):
        b = a.copy(); rr = np.random.default_rng(3).random((500, 900)); b[600:1100, 180:1080] = (rr*255).astype(np.uint8); return b
    en = O.page(O.EN * 2, O.FONTS["DejaVuSans"], 26); vi = O.page(O.VI * 2, O.FONTS["DejaVuSerif"], 28)
    digits = O.page(O.DIGITS * 3, O.FONTS["DejaVuSans"], 26)
    sparse = np.full((1754, 1240), 245, np.uint8); sparse[300:330, 200:900] = 30; sparse[600:630, 200:800] = 30
    print("VERTICAL part only (this file = the phiên-12/13 algorithm). straightness = RMS px of text lines from their own straight fit, 1000 px wide")
    print(f"  {'flat English (control)':28s} {straightness(en)[0]:5.2f}")
    for nm, base in (("English", en), ("Vietnamese serif", vi), ("two-column", two_col(en)), ("with photo block", picture(en))):
        for kind, amp in (("bowl", 30), ("half", 40)):
            w = warp(base, amp, kind); b = straightness(w)[0]; out, info = dewarp(w); a = straightness(out)[0] if out is not w else float("nan")
            print(f"  {nm:18s} {kind} {amp:2d}: {b:5.2f} -> {a:5.2f}   {info}")
    print("  English, stronger curl (bowl/wave/half amp 15..50):")
    for kind in ("bowl", "wave", "half"):
        for amp in (15, 30, 50):
            w = warp(en, amp, kind); b = straightness(w)[0]; out, info = dewarp(w); a = straightness(out)[0] if out is not w else float("nan")
            print(f"    {kind:5s} {amp:2d}: {b:6.2f} -> {a:6.2f}   {info}")
    print("FLAT / non-text pages must stay UNTOUCHED (mean pixel change 0):")
    for nm, img in (("flat English", en), ("flat two-column", two_col(en)), ("flat + photo block", picture(en)), ("digits table", digits), ("nearly blank", sparse)):
        out, info = dewarp(img)
        print(f"  {nm:20s} mean pixel change {float(np.abs(out.astype(int) - img.astype(int)).mean()):.3f}   {info}")
