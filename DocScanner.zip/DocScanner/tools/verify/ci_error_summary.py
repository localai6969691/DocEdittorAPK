#!/usr/bin/env python3
"""Gom lỗi biên dịch từ log Gradle thành chú thích (annotation) của GitHub Actions (phiên 15, sau run #15).

Vấn đề: khi `gradle assembleDebug` thất bại, log đầy dấu vết ngăn xếp dài; dòng quan trọng (`e: file:///...Foo.kt:12:34 ...`) nằm
ở trên cùng, và log chỉ xem được khi đăng nhập GitHub. Chú thích thì hiện công khai ở trang chạy (Annotations), nên script này:
  - tìm lỗi Kotlin (`e: file:///path/F.kt:L:C msg` và dạng cũ `e: /path/F.kt: (L, C): msg`), javac (`F.java:L: error: msg`),
    aapt2 (`ERROR: .../x.xml:L: AAPT: error: msg`), và khối "What went wrong" của Gradle;
  - phát tối đa 10 chú thích có file/dòng/cột (hiện ngay trên mã) + MỘT chú thích tổng hợp liệt kê tới 40 lỗi;
  - ghi toàn bộ vào $GITHUB_STEP_SUMMARY nếu có;
  - đường dẫn được đổi thành tương đối so với $GITHUB_WORKSPACE.
Dùng:  python3 tools/verify/ci_error_summary.py build.log [build2.log ...]      (luôn thoát mã 0: chỉ để báo cáo)
Tự kiểm:  python3 tools/verify/ci_error_summary.py --selftest
"""
import os, re, sys

MAX_FILE_ANNOTATIONS = 10
MAX_IN_SUMMARY_ANNOTATION = 40
WORKSPACE = os.environ.get("GITHUB_WORKSPACE", "")

KOTLIN_NEW = re.compile(r"^e:\s+file://(?P<path>.+?):(?P<line>\d+):(?P<col>\d+)\s+(?P<msg>.*)$")
KOTLIN_OLD = re.compile(r"^e:\s+(?P<path>/.+?\.kt):\s*\((?P<line>\d+),\s*(?P<col>\d+)\):\s*(?P<msg>.*)$")
JAVAC = re.compile(r"^(?P<path>/.+?\.java):(?P<line>\d+):\s+error:\s+(?P<msg>.*)$")
AAPT = re.compile(r"^(?:ERROR:\s*)?(?P<path>/.+?\.xml):(?P<line>\d+):\s*(?:AAPT:\s*)?error:\s*(?P<msg>.*)$")


def rel(path):
    path = path.replace("\\", "/")
    if WORKSPACE and path.startswith(WORKSPACE.rstrip("/") + "/"):
        return path[len(WORKSPACE.rstrip("/")) + 1:]
    k = path.find("/app/src/")
    return path[k + 1:] if k >= 0 else path


def esc_data(s):
    return s.replace("%", "%25").replace("\r", "%0D").replace("\n", "%0A")


def esc_prop(s):
    return esc_data(s).replace(":", "%3A").replace(",", "%2C")


def parse(lines):
    """-> (danh sách lỗi [(path, line, col, msg, kind)], khối 'What went wrong' [str])"""
    errors, seen, went_wrong = [], set(), []
    i = 0
    while i < len(lines):
        raw = lines[i].rstrip("\n").rstrip("\r")
        line = raw.strip()
        hit = None
        for kind, rx in (("Kotlin", KOTLIN_NEW), ("Kotlin", KOTLIN_OLD), ("Java", JAVAC), ("Resource", AAPT)):
            m = rx.match(line)
            if m:
                d = m.groupdict()
                hit = (rel(d["path"]), int(d["line"]), int(d.get("col") or 0), d["msg"].strip(), kind)
                break
        if hit and hit not in seen:
            seen.add(hit)
            errors.append(hit)
        if line.startswith("* What went wrong:"):
            block = []
            j = i + 1
            while j < len(lines) and lines[j].strip() != "" and not lines[j].startswith("* Try:") and len(block) < 6:
                block.append(lines[j].strip())
                j += 1
            went_wrong = block
        i += 1
    return errors, went_wrong


def render(errors, went_wrong):
    out = []
    for path, line, col, msg, kind in errors[:MAX_FILE_ANNOTATIONS]:
        loc = f"file={esc_prop(path)},line={line}" + (f",col={col}" if col else "")
        out.append(f"::error {loc},title={esc_prop(kind + ' error')}::{esc_data(msg)}")
    if errors:
        rows = [f"{p}:{l}:{c} {m}" if c else f"{p}:{l} {m}" for p, l, c, m, _ in errors[:MAX_IN_SUMMARY_ANNOTATION]]
        more = len(errors) - len(rows)
        if more > 0:
            rows.append(f"... và {more} lỗi nữa (xem Job summary)")
        out.append(f"::error title={esc_prop('Compile errors (%d)' % len(errors))}::{esc_data(chr(10).join(rows))}")
    elif went_wrong:
        out.append(f"::error title={esc_prop('Gradle failure')}::{esc_data(chr(10).join(went_wrong))}")
    return out


def summary_markdown(errors, went_wrong):
    md = ["## Lỗi build", ""]
    if errors:
        md.append(f"Tìm thấy **{len(errors)}** lỗi biên dịch:\n")
        md.append("| File | Dòng:Cột | Lỗi |")
        md.append("|---|---|---|")
        for p, l, c, m, k in errors:
            md.append(f"| `{p}` | {l}:{c} | {m.replace('|', '\\|')} |")
    if went_wrong:
        md += ["", "Gradle báo:", "```", *went_wrong, "```"]
    if not errors and not went_wrong:
        md.append("Không nhận ra dòng lỗi nào trong log (xem artifact build-log).")
    return "\n".join(md) + "\n"


SAMPLE = """\
> Task :app:compileDebugKotlin FAILED
e: file:///home/runner/work/R/R/app/src/main/java/com/example/docscanner/PdfSignActivity.kt:123:45 Unresolved reference 'foo'.
e: file:///home/runner/work/R/R/app/src/main/java/com/example/docscanner/PdfSignActivity.kt:123:45 Unresolved reference 'foo'.
e: file:///home/runner/work/R/R/app/src/main/java/com/example/docscanner/util/A,B.kt:7:1 Type mismatch: inferred type is 100% Int but String was expected
e: /home/runner/work/R/R/app/src/main/java/com/example/docscanner/Old.kt: (5, 9): Old style message
/home/runner/work/R/R/app/src/main/java/com/example/docscanner/J.java:12: error: cannot find symbol
ERROR: /home/runner/work/R/R/app/src/main/res/layout/x.xml:3: AAPT: error: attribute foo not found.

FAILURE: Build failed with an exception.

* What went wrong:
Execution failed for task ':app:compileDebugKotlin'.
> A failure occurred while executing org.jetbrains.kotlin.compilerRunner.GradleCompilerRunnerWithWorkers$GradleKotlinCompilerWorkAction
   > Compilation error. See log for more details

* Try:
> Run with --stacktrace option to get the stack trace.
"""


def selftest():
    global WORKSPACE
    WORKSPACE = "/home/runner/work/R/R"
    errors, ww = parse(SAMPLE.splitlines(True))
    ok = True

    def check(cond, what):
        nonlocal ok
        print(("ok  " if cond else "LOI"), what)
        ok &= bool(cond)
    check(len(errors) == 5, f"5 lỗi duy nhất (trùng bị loại): {len(errors)}")
    check(errors[0][:4] == ("app/src/main/java/com/example/docscanner/PdfSignActivity.kt", 123, 45, "Unresolved reference 'foo'."), "đường dẫn tương đối + dòng/cột đúng")
    check(any(e[4] == "Java" and e[1] == 12 for e in errors) and any(e[4] == "Resource" for e in errors), "nhận cả javac và aapt")
    check(any("Old style" in e[3] and e[1] == 5 and e[2] == 9 for e in errors), "nhận dạng Kotlin cũ (L, C)")
    check(ww and ww[0].startswith("Execution failed") and len(ww) <= 6, f"khối What went wrong: {ww[:1]}")
    lines = render(errors, ww)
    check(len(lines) == 6 and lines[-1].startswith("::error title=Compile errors (5)::"), "5 chú thích theo file + 1 chú thích tổng hợp")
    comma_line = [l for l in lines if "A%2CB.kt" in l]
    check(comma_line and "line=7,col=1" in comma_line[0], "dấu phẩy trong tên file được mã hoá %2C")
    check("100%25 Int" in "".join(lines), "ký tự % trong thông báo được mã hoá %25")
    check("%0A" in lines[-1] and "\n" not in lines[-1], "chú thích tổng hợp xuống dòng bằng %0A, không có xuống dòng thật")
    many = [("f.kt", i, 1, "m", "Kotlin") for i in range(1, 80)]
    r = render(many, [])
    check(len(r) == MAX_FILE_ANNOTATIONS + 1 and "và 39 lỗi nữa" in r[-1], "quá nhiều lỗi: 10 chú thích + tổng hợp cắt ở 40")
    check(render([], ww)[0].startswith("::error title=Gradle failure::"), "không có lỗi dòng nào: dùng khối What went wrong")
    check("Không nhận ra" in summary_markdown([], []), "log không có gì: nói rõ")
    print("TAT CA DAT" if ok else "CO LOI")
    return 0 if ok else 1


def main(argv):
    if argv and argv[0] == "--selftest":
        return selftest()
    lines = []
    for p in argv:
        try:
            with open(p, encoding="utf-8", errors="replace") as f:
                lines += f.readlines()
        except OSError as e:
            print(f"(không đọc được {p}: {e})")
    errors, went_wrong = parse(lines)
    print(f"Tìm thấy {len(errors)} lỗi biên dịch.")
    for p, l, c, m, k in errors[:MAX_IN_SUMMARY_ANNOTATION]:
        print(f"  [{k}] {p}:{l}:{c} {m}")
    for a in render(errors, went_wrong):
        print(a)
    summary = os.environ.get("GITHUB_STEP_SUMMARY")
    if summary:
        with open(summary, "a", encoding="utf-8") as f:
            f.write(summary_markdown(errors, went_wrong))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
