# Python mirror of CaptureStability (pure logic; the Kotlin class has no Android dependency).
import math, random

class CaptureStability:
    MIN_AREA, MAX_AREA = 0.20, 0.97
    MOVE_TOL = 0.018          # max corner movement between two analysed frames, in fractions of the frame's long side
    REARM_MOVE = 0.10
    HOLD_MS = 1200
    COOLDOWN_MS = 3000
    LOST_GRACE_MS = 500
    REARM_LOST_MS = 700
    SHARP_KEEP = 0.6          # current sharpness must be >= 60% of the best seen in the last 2 s (focus not hunting)
    SHARP_WINDOW_MS = 2000
    SHARP_FLOOR = 5.0

    def __init__(self):
        self.prev = None; self.stable_since = None; self.last_seen = None; self.last_trigger = None
        self.armed = True; self.lost_since = None; self.sharp = []   # (t, value)

    @staticmethod
    def area(q):
        # shoelace on 4 points normalised by frame area; q = [(x,y)*4] in 0..1 of each axis
        a = 0.0
        for i in range(4):
            x1, y1 = q[i]; x2, y2 = q[(i+1) % 4]; a += x1*y2 - x2*y1
        return abs(a) / 2

    @staticmethod
    def convex(q):
        s = 0
        for i in range(4):
            ax, ay = q[i]; bx, by = q[(i+1) % 4]; cx, cy = q[(i+2) % 4]
            cross = (bx-ax)*(cy-by) - (by-ay)*(cx-bx)
            if cross != 0: s = s + (1 if cross > 0 else -1)
        return abs(s) == 4

    def update(self, quad, sharpness, now, aspect):
        """quad: 4 (x,y) points normalised to the frame (x by width, y by height) or None. aspect = width/height of the frame.
        returns one of 'searching', 'moving', 'holding', 'trigger'"""
        self.sharp = [(t, v) for (t, v) in self.sharp if now - t <= self.SHARP_WINDOW_MS]
        if quad is not None: self.sharp.append((now, sharpness))
        ok_doc = quad is not None and self.MIN_AREA <= self.area(quad) <= self.MAX_AREA and self.convex(quad)
        if not ok_doc:
            if self.last_seen is None or now - self.last_seen > self.LOST_GRACE_MS:
                self.prev = None; self.stable_since = None
            if self.lost_since is None: self.lost_since = now
            if now - self.lost_since >= self.REARM_LOST_MS: self.armed = True
            return "searching"
        self.lost_since = None; self.last_seen = now
        moved = 0.0
        if self.prev is not None:
            # movement in units of the frame's long side, so a portrait and a landscape frame behave alike
            moved = max(math.hypot((a[0]-b[0]) * aspect, (a[1]-b[1])) for a, b in zip(quad, self.prev)) / max(aspect, 1.0)
        self.prev = quad
        if moved > self.REARM_MOVE: self.armed = True
        if self.stable_since is None or moved > self.MOVE_TOL:
            self.stable_since = now
            return "moving"
        best = max(v for _, v in self.sharp)
        if sharpness < self.SHARP_FLOOR or sharpness < self.SHARP_KEEP * best: return "holding"     # camera still refocusing
        if now - self.stable_since < self.HOLD_MS: return "holding"
        if not self.armed: return "holding"
        if self.last_trigger is not None and now - self.last_trigger < self.COOLDOWN_MS: return "holding"
        self.last_trigger = now; self.armed = False
        return "trigger"

def rect(cx, cy, w, h, jitter=0.0, rng=random):
    pts = [(cx-w/2, cy-h/2), (cx+w/2, cy-h/2), (cx+w/2, cy+h/2), (cx-w/2, cy+h/2)]
    return [(x + rng.uniform(-jitter, jitter), y + rng.uniform(-jitter, jitter)) for x, y in pts]

def run(events, label):
    st = CaptureStability(); trig = []; log = []
    for t, quad, sharp in events:
        r = st.update(quad, sharp, t, 0.75)
        if r == "trigger": trig.append(t)
    print(f"{label:52s} triggers at (ms): {trig}")
    return trig

if __name__ == "__main__":
    rng = random.Random(1); dt = 200
    # 1) steady document, tiny detector jitter, sharp
    ev = [(t, rect(.5, .5, .7, .8, .004, rng), 100.0) for t in range(0, 4000, dt)]
    t1 = run(ev, "steady doc, jitter 0.4%")
    # 2) hand-held drift: 2.5% per frame
    ev = [(t, rect(.5 + 0.025*((t//dt) % 40), .5, .7, .8), 100.0) for t in range(0, 6000, dt)]
    t2 = run(ev, "moving 2.5%/frame (should never fire)")
    # 3) steady but lens hunting: sharpness dips at the start then recovers
    ev = [(t, rect(.5, .5, .7, .8, .003, rng), 20.0 if t < 1800 else 100.0) for t in range(0, 5000, dt)]
    ev = [(t, q, (100.0 if t < 400 else 30.0 if t < 2000 else 100.0)) for t, q, _ in ev]
    t3 = run(ev, "steady, focus hunting 0.4-2.0 s")
    # 4) after a trigger the same page stays in view for 10 s: must NOT shoot again
    ev = [(t, rect(.5, .5, .7, .8, .003, rng), 100.0) for t in range(0, 10000, dt)]
    t4 = run(ev, "same page held 10 s (fires once)")
    # 5) page turned: doc lost 1.0 s, new page appears and holds -> second trigger
    ev = [(t, rect(.5, .5, .7, .8, .003, rng), 100.0) for t in range(0, 3000, dt)] + \
         [(t, None, 0.0) for t in range(3000, 4000, dt)] + \
         [(t, rect(.5, .5, .7, .8, .003, rng), 100.0) for t in range(4000, 8000, dt)]
    t5 = run(ev, "page turned (lost 1 s) -> fires again")
    # 6) single-frame detector drop-outs (every 5th frame) must not reset the timer
    ev = [(t, (None if (t//dt) % 5 == 4 else rect(.5, .5, .7, .8, .003, rng)), 100.0) for t in range(0, 4000, dt)]
    t6 = run(ev, "flicker: one missing frame in 5")
    # 7) tiny document (area 10% of frame) and a frame-filling false detection
    ev = [(t, rect(.5, .5, .3, .3), 100.0) for t in range(0, 4000, dt)]; t7 = run(ev, "document too small (9%)")
    ev = [(t, rect(.5, .5, .999, .999), 100.0) for t in range(0, 4000, dt)]; t8 = run(ev, "quad = whole frame (>97%)")
    # 8) self-intersecting (bow-tie) quad
    bow = [(.2, .2), (.8, .8), (.8, .2), (.2, .8)]
    ev = [(t, bow, 100.0) for t in range(0, 4000, dt)]; t9 = run(ev, "bow-tie quad (not convex)")
    # 9) slow drift below tolerance (1% per frame) should still count as stable? (tolerance 1.8%)
    ev = [(t, rect(.4 + 0.01*(t//dt)*0.5, .5, .7, .8), 100.0) for t in range(0, 4000, dt)]; t10 = run(ev, "slow drift 0.5%/frame")
    ok = (len(t1) == 1 and 1200 <= t1[0] <= 1800) and not t2 and (len(t3) == 1 and t3[0] >= 2000) and len(t4) == 1 and len(t5) == 2 and len(t6) == 1 and not t7 and not t8 and not t9 and len(t10) == 1
    print("ALL EXPECTATIONS MET" if ok else "SOME EXPECTATION FAILED")
