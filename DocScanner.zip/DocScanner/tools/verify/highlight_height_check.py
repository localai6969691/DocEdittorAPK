# Does a FontDescriptor / bigger FontBBox change how tall the selection box of the invisible text layer is?
# (phiên 13 finding: poppler picks its own ascent/descent for Type3 fonts; pdfminer/pdfplumber measure the box exactly.)
import re, subprocess, sys
sys.path.insert(0, ".")
import pikepdf, pdfplumber
from pikepdf import Name, Dictionary, Array
import text_layer_check as t3
from _common import OUT

def build(variant):
    orig = t3.build_font
    def bf(pdf, cps):
        f = orig(pdf, cps)
        if variant == "descriptor":
            f.FontDescriptor = pdf.make_indirect(Dictionary(Type=Name.FontDescriptor, FontName=Name("/OcrGlyphless"), Flags=32,
                FontBBox=Array([0, -200, 500, 800]), ItalicAngle=0, Ascent=800, Descent=-200, CapHeight=700, StemV=80))
        elif variant == "bbox1000":
            f.FontBBox = Array([0, -300, 500, 1000])
        return f
    t3.build_font = bf
    path = f"{OUT}/hl_{variant}.pdf"
    t3.make(path, 0)
    t3.build_font = orig
    return path

print("the word box in the test page is 108.0-129.6 = 21.6 pt tall")
for v in ("plain", "descriptor", "bbox1000"):
    path = build(v)
    out = subprocess.run(["pdftotext", "-bbox-layout", "-enc", "UTF-8", path, "-"], capture_output=True, text=True).stdout
    m = re.search(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">C', out)
    y0, y1 = float(m.group(2)), float(m.group(4))
    with pdfplumber.open(path) as pdf:
        w = [w for w in pdf.pages[0].extract_words() if w["text"].startswith("C")][0]
    print(f"  {v:11s} poppler height {y1 - y0:5.2f} pt | pdfplumber height {w['bottom'] - w['top']:5.2f} pt")
