"""Shared helpers for the verification scripts (not part of the Android app)."""
import os, tempfile
OUT = os.environ.get("VERIFY_OUT") or os.path.join(tempfile.gettempdir(), "docscanner_verify")
os.makedirs(OUT, exist_ok=True)
