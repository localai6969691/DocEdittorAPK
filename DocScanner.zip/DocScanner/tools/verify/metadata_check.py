"""Kiểm chứng ý tưởng của PdfMetadataTools (phiên 15): sửa/xoá thông tin PDF phải bỏ cả XMP, nếu không tiêu đề cũ vẫn hiện.

Không chạy được PdfBox trên máy tính, nên script kiểm CÁI THIẾT KẾ bằng pikepdf + poppler: tạo PDF có Info.Title="Cu" VÀ XMP dc:title="CuXMP":
  A. chỉ sửa Info (giữ XMP)  -> `pdfinfo -meta` vẫn còn XMP cũ (chứng minh vì sao phải bỏ XMP);
  B. sửa Info + bỏ /Metadata -> pdfinfo hiện tiêu đề mới, không còn XMP;
  C. strip (Info rỗng + bỏ /Metadata) -> pdfinfo không còn Title/Author/Creator/Producer, không còn XMP;
  D. trường để trống thì bị xoá chứ không lưu chuỗi rỗng.
Chạy: python3 metadata_check.py   (cần pikepdf, pdfinfo)
"""
import os, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import pikepdf
from pikepdf import Name

XMP = b"""<?xpacket begin='' id='W5M0MpCehiHzreSzNTczkc9d'?><x:xmpmeta xmlns:x='adobe:ns:meta/'><rdf:RDF xmlns:rdf='http://www.w3.org/1999/02/22-rdf-syntax-ns#'><rdf:Description rdf:about='' xmlns:dc='http://purl.org/dc/elements/1.1/'><dc:title><rdf:Alt><rdf:li xml:lang='x-default'>CuXMP</rdf:li></rdf:Alt></dc:title></rdf:Description></rdf:RDF></x:xmpmeta><?xpacket end='w'?>"""


def make(path):
    pdf = pikepdf.new()
    pdf.add_blank_page(page_size=(200, 200))
    pdf.docinfo["/Title"] = "Cu"
    pdf.docinfo["/Author"] = "Tac gia cu"
    pdf.docinfo["/Creator"] = "PhanMemCu"
    pdf.docinfo["/Producer"] = "NhaSanXuatCu"
    md = pdf.make_stream(XMP)
    md.Type = Name.Metadata; md.Subtype = Name.XML
    pdf.Root.Metadata = md
    pdf.save(path)


def info(path):
    """Các trường của pdfinfo thành từ điển {khoá: giá trị} (pdfinfo canh lề bằng số dấu cách thay đổi, nên không so chuỗi cứng)."""
    out = subprocess.run(["pdfinfo", path], capture_output=True, text=True).stdout
    fields = {}
    for line in out.splitlines():
        if ":" in line:
            k, v = line.split(":", 1)
            fields[k.strip()] = v.strip()
    return fields


def xmp(path):
    return subprocess.run(["pdfinfo", "-meta", path], capture_output=True, text=True).stdout


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    return cond


def main():
    good = True
    src = os.path.join(OUT, "meta_src.pdf"); make(src)
    good &= check(info(src).get("Title") == "Cu" and "CuXMP" in xmp(src), "PDF gốc có Info và XMP")

    a = os.path.join(OUT, "meta_a.pdf")
    with pikepdf.open(src) as p:
        p.docinfo["/Title"] = "Moi"; p.save(a)
    good &= check("CuXMP" in xmp(a), "A: chỉ sửa Info -> XMP cũ vẫn còn (viewer ưu tiên XMP sẽ hiện tiêu đề cũ)")

    b = os.path.join(OUT, "meta_b.pdf")
    with pikepdf.open(src) as p:
        p.docinfo["/Title"] = "Moi"; p.docinfo["/Author"] = "Tac gia moi"
        del p.Root["/Metadata"]; p.save(b)
    good &= check(info(b).get("Title") == "Moi" and info(b).get("Author") == "Tac gia moi", "B: tiêu đề/tác giả mới hiện ra")
    good &= check("CuXMP" not in xmp(b) and info(b).get("Creator") == "PhanMemCu", "B: không còn XMP cũ; mục Info khác (Creator) được giữ")

    c = os.path.join(OUT, "meta_c.pdf")
    with pikepdf.open(src) as p:
        for k in list(p.docinfo.keys()):
            del p.docinfo[k]
        del p.Root["/Metadata"]; p.save(c)
    t = info(c)
    good &= check(all(k not in t for k in ("Title", "Author", "Creator", "Producer")) and "CuXMP" not in xmp(c), "C: strip xoá Title/Author/Creator/Producer và XMP")

    d = os.path.join(OUT, "meta_d.pdf")
    with pikepdf.open(src) as p:
        del p.docinfo["/Author"]; del p.Root["/Metadata"]; p.save(d)
    good &= check("Author" not in info(d) and info(d).get("Title") == "Cu", "D: trường trống bị xoá, không lưu chuỗi rỗng (Title khác giữ nguyên)")
    print("TAT CA DAT" if good else "CO LOI")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
