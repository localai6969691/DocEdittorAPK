# TECHNICAL_DOCS.md — Quét & Chỉnh Sửa PDF (DocScanner)

> Tài liệu này ghi lại toàn bộ quyết định kỹ thuật, tiến độ, việc đã làm/chưa làm, và các cạm bẫy
> đã gặp của dự án. Mục đích: mở lại dự án sau này (kể cả người/AI khác) chỉ cần đọc file này,
> KHÔNG cần đọc lại lịch sử chat. Mỗi khi tiếp tục dự án, hãy đọc file này trước, code sau. Sau khi
> làm thêm việc gì, cập nhật lại file này (thêm mục vào đúng section, không xoá lịch sử cũ).

## 0. Trạng thái tóm tắt (đọc trước tiên)

**Phiên 23 (mới nhất):** chủ dự án yêu cầu lần nữa "đọc kỹ tài liệu kỹ thuật, hoàn thành việc dang dở, làm nốt kỹ thuật trong PDF chưa áp dụng". Đọc mục 0, 6, 10, 4.49 và các mục C5-C7, F4, I2, I6, M8, M9 của PDF; đối chiếu với mã. Đã xong: **trình đọc EPUB trong app + tô sáng + dấu trang + nhớ vị trí đọc + nhảy tới kết quả tìm** (C5, C6, C7 nối vào; mục 4.50) và **PAdES-LT** (lưu OCSP / CRL vào /DSS của PDF đã ký, hộp kiểm trong hộp ký số; mục 4.51: `Revocation` kiểm bằng `openssl ocsp` thật khớp từng byte, cấu trúc /DSS kiểm bằng `pdfsig` + `qpdf`; phần PdfBox ghi /DSS CHƯA chạy). Phần logic thuần (`EpubNotes`) có bản Java + mô hình đối chứng độc lập (`epub_notes_check`: 9 103 trạng thái tô sáng, 900 tệp bị phá, 5 đột biến đều bị bắt); phần giao diện (`EpubReaderActivity`, `EpubRowAdapter`) chỉ rà tĩnh. Sửa thêm `large_screen_check.py` (từ phiên 22 mọi Activity kế thừa `BaseActivity`, bộ kiểm vẫn tìm `: AppCompatActivity` nên báo đỏ). **Mã Kotlin phiên 16 -> 23 vẫn CHƯA biên dịch** (môi trường không có Kotlin / Gradle). Mục còn lại và lý do: mục 6 "Còn lại sau phiên 23".
**Phiên 22:** chủ dự án yêu cầu lần nữa "đọc kỹ tài liệu kỹ thuật, hoàn thành việc dang dở và làm nốt kỹ thuật trong PDF chưa áp dụng". Đọc mục 0, 6, các trang 40-59 của PDF (danh mục A1-N9), rồi `grep` MÃ THẬT từng mã mục: danh sách mục chưa có trong mã nằm ở đầu mục 4.49. Làm theo thứ tự và xuất zip ngay sau mỗi mục; mỗi mục có bản Java / Python song song + công cụ độc lập. Đã xong: (1) nén tài liệu đã chọn thành ZIP, có mật khẩu AES-256 (4.49.1; bộ đọc độc lập giải mã khớp từng byte, 2 thử âm tính); (2) xuất JSON / XML / Base64 (4.49.2; `json.loads`, `lxml`, `xmllint`, `base64 -d`); (3) khoá app chọn được thời gian hỏi lại (4.49.3; mô phỏng sự kiện cho 5 mức); (4) nhập từ liên kết https và clipboard (4.49.4; máy chủ thử cục bộ, 21 tình huống mạng, bắt được 2 lỗi thật); (5) tìm trong EPUB không phân biệt dấu (4.49.5; đối chứng độc lập trên 397 truy vấn); (6) widget màn hình chính "Quét nhanh" (4.49.6; chỉ rà tĩnh); (7) chụp liên tiếp theo chu kỳ (4.49.7; 600 phiên mô phỏng); (8) ký số bằng chứng thư `.p12` có chuỗi + ECDSA (4.49.8; `openssl cms -verify -CAfile gốc` không `-untrusted`; kho tin cậy NSS; bộ đọc dự phòng cho `.p12` của OpenSSL 3; BouncyCastle cho mật khẩu có dấu); (9) rà Kotlin mức từ vựng thay cho trình biên dịch + bước CI mới (4.49.9; 188 tệp, 0 phát hiện); (10) dấu hiển thị cho chữ ký số, đúng cả trang xoay (4.49.10; render poppler 20 ca); (11) thư mục phân cấp ảo từ thẻ (4.49.11; đối chứng vét cạn); (12) webhook khi có tài liệu mới + cách dùng Tasker (4.49.12; máy chủ cục bộ); (13) cỡ chữ trong app + chữ tương phản AAA (4.49.13); (14) chế độ ảnh HDR / ban đêm (4.49.14; chưa chạy); (15) dịch một bức ảnh (4.49.15; chưa chạy). **Mã Kotlin của phiên 16 → 22 CHƯA biên dịch** (môi trường không có Kotlin / Gradle / mạng): chạy Actions trước. Mục đang làm tiếp xem các mục 4.49.x và mục 6 "Còn lại sau phiên 22".

**Phiên 20:** chủ dự án bảo "làm tiếp theo thứ tự" các mục còn lại của 6 "Còn lại sau phiên 19". Đã đối chiếu MÃ THẬT trước (grep): mã QR đã có từ 4.47.5; tám mục kia chưa có dòng nào. Đã xong, mỗi mục có bản Java / Python song song, đối chiếu với công cụ độc lập, thử âm tính, và xuất zip ngay sau mục:
(1) cảnh báo trước khi sửa PDF đã ký (4.48.1; PDF ký thật so với `pdfsig`); (2) nhập ODT / PPTX / XLSX / RTF (4.48.2; 58 kiểm tra trên tệp LibreOffice / pandoc / python-pptx / openpyxl, 8 bản hỏng bị bắt; trong lúc kiểm bắt được một lỗi thật của bộ đọc ODT);
(3) tóm tắt + phân loại + thẻ gợi ý (4.48.3; TF-IDF khớp scikit-learn, PageRank khớp networkx); (4) eSCL hai mặt (4.48.4; tên phần tử đã tra bằng hai nguồn thật, máy giả trả 409 như Epson); (5) sao lưu theo lịch (4.48.5; phần thuần kiểm kỹ, phần JobScheduler / SAF chưa chạy); (6) chữ ký có dấu thời gian RFC 3161 (4.48.6; `openssl ts` làm TSA cục bộ, `openssl ts -verify` xác nhận token phủ đúng chữ ký, PDF vẫn "Signature is Valid"; bài kiểm bắt được một lỗi thật: token cắt cụt); (7) tô sáng bằng lớp chữ thật (4.48.7; hằng số hộp chỉnh trên 1.879 từ thật rồi kiểm trên mẫu khác: phủ 100 % mực).
**CHƯA làm trong phiên 20:** thêm ngôn ngữ (cần ~1 000 chuỗi mỗi ngôn ngữ và người bản ngữ rà) — xem 6 "Còn lại sau phiên 20". **Mã Kotlin của phiên 20 CHƯA biên dịch** (môi trường không có Kotlin / Gradle); `static_refs_check`, `i18n_check`, `doc_sync_check` đạt. Đã thêm 7 + 1 + 21 + 2 + 18 + 5 chuỗi mới (tô sáng chữ-lớp không cần chuỗi) (Anh / Việt / Nhật).

**Phiên 19:** chủ dự án yêu cầu lần nữa "đọc kỹ tài liệu kỹ thuật, hoàn thành việc dang dở và làm nốt kỹ thuật trong PDF 'Thiếu gì để bán app' chưa áp dụng". Cách làm giống phiên 18: đọc mục 0, 6, 10, 11 + toàn bộ PDF (87 trang), `grep` MÃ THẬT cho từng mục của PDF, rồi làm từng mục và xuất zip ngay sau mỗi mục (xem 4.47). Đã xong: (1) di chuyển / đổi cấp mục lục PDF (4.47.1, mục 6.5 cũ); (2) nhập Markdown / HTML / Word (.docx) → PDF / EPUB / FB2 và CSV / TSV → PDF dạng lưới trong "Chuyển đổi" (4.47.2); (3) áp phích: một trang phóng ra 2-5 tờ A4 (4.47.3); (4) xuất TIFF nhiều trang đen trắng G4 / màu Deflate (4.47.4). Mỗi mục có bản Java / Python song song và đối chiếu với công cụ độc lập (pandoc, lxml, python-docx, csv, html.unescape, poppler, libtiff qua Pillow / OpenCV, ImageMagick). **Mã Kotlin của phiên này CHƯA biên dịch lần nào** (môi trường không có Kotlin / Gradle / mạng tải gói): chạy Actions trước, sửa lỗi biên dịch (nếu có), rồi mới thêm tính năng. Các mục của PDF vẫn chưa làm và hướng đã nghĩ cho từng mục: xem 6 "Còn lại sau phiên 19".

**Phiên 18:** đọc lại toàn bộ TECHNICAL_DOCS.md + PDF "Thiếu gì để bán app", đối chiếu từng mục "chưa làm" với MÃ THẬT (grep), rồi làm theo thứ tự từng mục, xuất ngay sau mỗi mục. Mục 1: bộ công cụ EPUB (4.35). Mục 2: dọn dẹp lưu trữ - dung lượng, tài liệu trùng, xoá hẳn có ghi đè (4.36). Mục 3: nhập từ gói CBZ/ZIP, kiểm dung lượng trống, giữ màn hình sáng (4.37). Mục 4: dịch vụ nền giữ việc dài sống, đã tra cứu tài liệu Android (4.38). Mục 5: tệp đính kèm, lớp OCG, liên kết trong PDF (4.39). Mục 6: sửa PDF hỏng, tự tạo liên kết, PDF Portfolio; tuyến tính hoá đã tra cứu nhưng KHÔNG làm được và nói rõ vì sao (4.40). Mục 7: chế độ riêng tư (4.41). Mục 8: tuyến tính hoá PDF làm thật sau khi đọc mã nguồn trên web (4.42). Mục 9: thư mục theo dõi (4.43). Mục 10: bố cục máy tính bảng hai cột (4.44). Mục 11: đa ngôn ngữ - kiến trúc, bản dịch Anh / Việt / Nhật (4.45) và bộ chọn ngôn ngữ trong app (4.46). Các mục tiếp theo xem 4.47 trở đi (nếu có) và mục 6.

**Phiên 17:** làm các mục "chưa làm sau 4.30": chỉnh tay + khử đốm, chú thích chữ thật (tô sáng/gạch chân/gạch ngang), thùng rác + chọn nhiều + đổi tên hàng loạt, quét QR/mã vạch, camera (lưới, thước thăng bằng, phím âm lượng), bố cục màn rộng, chuyển PDF/A-2b, két an toàn (xem 4.31). Mỗi mục có bản Java/Python song song và kiểm chứng bằng công cụ độc lập (thư mục thật, poppler, lcms, `cryptography`, qpdf); **mã Kotlin của phiên 16 và 17 vẫn CHƯA biên dịch** (môi trường làm việc không có Kotlin/Gradle) và veraPDF chưa từng chạy. Quét Wi-Fi qua eSCL (4.31 I) cũng đã làm nhưng đòi quyền INTERNET - xem quyết định ở đó. Còn lại (tiếng Anh, công cụ cấu trúc PDF, thử eSCL trên máy thật...) nằm ở mục 6 "Còn lại sau phiên 17" kèm hướng đã tra cứu.


- **Cách đọc tài liệu này (phiên 14):** muốn biết app CÓ GÌ → mục 11 (danh mục tính năng + mức kiểm chứng từng cái). Muốn biết ĐÃ ĐỔI GÌ theo thời gian → mục 12 (nhật ký theo phiên).
  Muốn biết LỖI/CHẨN ĐOÁN/CÁCH SỬA → mục 7 (sổ bug có ID, 7.1 phiên 2–10, 7.2 phiên 11–14) và mục 9 (bảng triệu chứng → nghi ngờ đầu tiên → cách kiểm).
  Muốn biết HƯỚNG ĐÃ THỬ VÀ BỎ → mục 8. Các khối "Cập nhật phiên N" ngay bên dưới là tường thuật gốc; mục 11–12 là bản tổng hợp có cấu trúc.
- **Trạng thái build hiện hành (NGUỒN DUY NHẤT — các câu "chưa build" trong các khối cũ bên dưới và ở mục 4.x là LỊCH SỬ tại thời điểm viết, đừng đọc như hiện trạng):**
  (a) CI run #18 (commit #17, 3/10) **xanh**, debug APK 111 MB ⇒ mã tới phiên 15 (tới bản vá `Geometry`: gồm `PdfDecorator`, `PdfStamper`, `PdfMetadataTools`, `PdfPrintAdapter`, `AppLock`, `BackupManager`) **đã biên dịch được**;
  (b) mã từ 4.23 (lịch sử/thẻ, `PdfImposer`), 4.24 (ký số), 4.25 (biểu mẫu, ghép thẻ, so sánh, đổi tên, hàng loạt), 4.26 (đọc to, dịch, Word, che vĩnh viễn) và 4.27, 4.28–4.30 (phiên 16) **chưa biên dịch lần nào**;
  (b2) mã phiên 17, 18 và 19 (4.31-4.47) cũng **chưa biên dịch lần nào**;
  (c) **chưa tính năng nào được chạy trên thiết bị Android**; app chưa có unit test/instrumented test nào. Khi trạng thái đổi, sửa ĐÚNG khối này.
- **Cập nhật (phiên 16, tiếp 2 — NHÓM XUẤT ĐỊNH DẠNG + TRÍCH TRƯỜNG, đọc mục 4.30)**: người dùng nói "tiếp những cái chưa làm". Đã làm: (1) **xuất HTML / Markdown / Excel (.xlsx) / PowerPoint (.pptx)** từ tài liệu trong lịch sử (Excel dựng bảng từ hộp chữ OCR bằng khe trắng
  giữa các cột; PPTX mỗi trang một ảnh), cả bốn bộ ghi viết tay không thư viện và kiểm bằng `openpyxl`, `python-pptx`, `pandoc`, LibreOffice; (2) **trích trường hoá đơn VN** (ngày, số, ký hiệu, MST, tổng tiền, thuế; xem / sao chép / CSV) và **danh thiếp → liên hệ** (form thêm liên hệ của hệ thống,
  hoặc vCard 3.0 kiểm bằng bộ đọc RFC 2426 độc lập); (3) **sửa 3 lỗi có sẵn** thấy trên đường đi: tệp `.fb2` xuất ra không hiện trong danh sách, `shareFile` gửi mọi tệp lạ (kể cả `.docx`) với kiểu `text/plain`, 7 chuỗi mất dấu ngoặc kép; thêm `strings_check.py`.
  Bài kiểm bắt được 8 lỗi THẬT của chính mã mới trong lúc viết (B16-13…B16-15). **Chưa làm** (xem cuối 4.30): QR/mã vạch, máy ảnh, chỉnh ảnh thủ công, highlight trên chữ, chọn nhiều / thùng rác / đổi tên hàng loạt / thư mục, tablet, tiếng Anh. Mã này CHƯA biên dịch.
- **Cập nhật (phiên 16, tiếp — LÀM CÁC MỤC "CÒN THIẾU THẬT" CỦA PDF, đọc mục 4.29)**: người dùng hỏi "vậy tại sao không làm những việc đó"; đã làm 8 nhóm trong danh sách ở 4.28, mỗi nhóm có kiểm chứng:
  (1) **Mở bằng / Chia sẻ tới DocScanner** (PDF, ảnh) → hỏi dùng công cụ nào; 7 màn PDF dùng thẳng file được gửi thay vì mở bộ chọn; (2) **phím tắt ứng dụng** (động, vì `applicationId` đổi theo biến `APP_ID`);
  (3) **giao diện tối** (`values-night`; trước đó theme DayNight không có màu đêm) + màu chữ phụ ban ngày nâng lên đạt WCAG AA (4,23 → 5,7); (4) **Hướng dẫn & phản hồi**, **nhật ký sự cố cục bộ** và hộp hỏi gửi báo cáo;
  (5) **công cụ trang PDF**: thêm trang từ PDF khác, nhân đôi, trang trắng, cắt lề, đổi khổ giấy, tách theo khoảng / mỗi N trang; (6) **tìm theo nội dung đã OCR** trong "Tài liệu đã xuất"; (7) **che tự động thông tin cá nhân**
  (CCCD/CMND, điện thoại, email, thẻ, MST, STK); (8) **trợ năng**: 30/48 ảnh thiếu mô tả đã sửa + script giữ cho không tái diễn. 6 script mới (`night_theme_check`, `crash_log_check`, `page_ranges_check`, `page_tools_check`, `pii_check`,
  `accessibility_check`) + mở rộng `history_filter_check`; mọi bài kiểm có đột biến/thử âm tính. **Chưa làm** (nêu rõ ở 4.29): xuất PPTX/XLSX/HTML/Markdown, trích trường hoá đơn / vCard / QR, tính năng máy ảnh, chỉnh ảnh thủ công,
  highlight trên chữ, thùng rác / chọn nhiều / thư mục, layout tablet, bản tiếng Anh. **Toàn bộ mã này CHƯA biên dịch.**
- **Cập nhật (phiên 16 — HOÀN THÀNH CÁC MỤC DANG DỞ, đọc mục 4.27)**: người dùng dặn đọc tài liệu rồi hoàn thành mọi thứ còn dở. Đã làm 4 việc, mỗi việc có script kiểm chứng và THỬ ĐỘT BIẾN
  (cố ý làm hỏng bản Java để chắc bài kiểm bắt được lỗi): (1) **2 preset mới** Trắng đen+ (Sauvola) và Xóa bóng trong "Bộ lọc hàng loạt" và bước quét của luồng Dự án — nhãn lấy từ enum
  `ScanPresetApplier.Preset`, hai hộp thoại không thể lệch nhau; (2) **lớp chữ OCR gắn thẳng vào PDF** ở ô OCR của luồng Quét và ở bước OCR (7) của luồng Dự án — MỘT lần OCR cho cả lớp chữ lẫn
  file `.txt`; lỗi thì PDF giữ nguyên và chạy lại đường cũ; mất bookmark thì huỷ; (3) **`TextPdfBuilder` ngắt dòng theo Unicode UAX #14** (`android.icu.text.BreakIterator`) qua `TextWrapper` — hết tràn
  khổ với tiếng Trung/Nhật và URL/số dài (`text_wrap_check.py`: 12 mẫu x 3 khổ + 300 đoạn ngẫu nhiên x 3 khổ; thuật toán CŨ làm tràn đúng các mẫu đó); (4) **xuất FB2** (checkbox ở 2 màn ebook + đích
  chuyển đổi từ EPUB/TXT) và **loại ký tự cấm của XML 1.0** khỏi EPUB/FB2 (`fb2_check.py`: `xmllint` + `lxml` + `pandoc -f fb2`). **Toàn bộ mã phiên 16 CHƯA biên dịch** (môi trường không có Kotlin/Gradle/mạng) —
  việc đầu tiên lần build tới: xem mục 10 (phiên 16).
- **Cập nhật (phiên làm việc thứ 15 — BỔ SUNG TÍNH NĂNG TỪ FILE "Thiếu gì để bán app", đọc mục 4.22)**: người dùng đưa file PDF (đoạn chat DeepSeek liệt kê
  ~100 tính năng còn thiếu để bán app) và dặn đọc tài liệu kỹ thuật trước rồi bổ sung. Đã đối chiếu: nhiều mục trong file ĐÃ có từ phiên 11-14 (PDF tìm kiếm được, mật khẩu,
  watermark, tự chụp, tự xoay, xóa bóng, chú thích). Phiên này thêm 6 nhóm CHƯA có: **số trang / đầu-chân trang / số Bates**, **ký tay + đóng tem (ĐÃ DUYỆT, BẢN SAO, ngày)**
  lên PDF mà KHÔNG rasterize, **in PDF**, **khoá ứng dụng bằng vân tay/PIN + chặn chụp màn hình**, **sao lưu/khôi phục ZIP**, **sửa/xoá thông tin tài liệu PDF**.
  Tra cứu giải quyết một "chưa làm" cũ: `pdfbox-android:2.0.27.0` kéo sẵn `bcprov/bcpkix/bcutil-jdk15to18:1.72` ⇒ chữ ký SỐ thật khả thi không thêm thư viện (mục 4.22, 10).
  **Khắc phục 3 "hạn chế đã biết" của 4.25 sau khi người dùng hỏi "sao không tra cứu"**: thẻ ngược đầu (tự nhận chiều + nút 180°; đo 192 ảnh thẻ giả, 0 sai), so sánh PDF (ghép trang chèn/xoá + căn chỉnh theo ô + dung sai; bản Java chạy trên JVM = numpy), điền biểu mẫu vào PDF đã ký (cập nhật tăng dần; pdfsig xác nhận chữ ký còn nguyên). Nguyên tắc ghi ở mục 10 (0e00).
  **Kiểm, khắc phục và làm hết** (4.26): căn chỉnh affine kim tự tháp cho so sánh PDF (xoay ≤ 3°, co ≤ 3% → 0% hộp; bản Java chạy trên JVM = numpy), sửa `PdfFormFiller` theo javadoc `saveIncremental` (đánh dấu cả đường từ catalog), nén hàng loạt, thẻ trong lịch sử, đọc to (TTS), dịch (ML Kit), PDF→Word (.docx kiểm bằng python-docx + LibreOffice), che vĩnh viễn (so với "che giả" bằng poppler). 4 script mới: `text_chunker_check.py`, `docx_check.py`, `redact_check.py`, `compare_java_check.py` mở rộng; trạng thái build thật: run #18 xanh với mã tới bản vá `Geometry`.
  **Làm hết các mục còn lại** (4.25): đổi tên/gợi ý tên từ nội dung, xử lý hàng loạt, ghép thẻ CCCD/hộ chiếu lên A4 đúng kích thước thật, so sánh hai PDF, điền biểu mẫu AcroForm (+ "Ký & đóng dấu" nay thêm được nhiều lần, có chữ không khung để điền bản quét). 4 script mới: `smart_namer_check.py`, `idcard_check.py`, `compare_check.py`, `form_check.py`.
  **Chữ ký SỐ thật** (4.24): chứng thư tự ký trong Android Keystore + CMS tự dựng bằng DER (không BouncyCastle), kiểm bằng `pdfsig` và `openssl` qua bản Java song song (`digital_signature_check.py`, `CmsCheck.java`).
  **Build ĐÃ THÀNH CÔNG** (người dùng báo sau khi sửa 11 lỗi của B15-03). Làm tiếp ngay trong phiên 15: lịch sử tìm kiếm/sắp xếp/yêu thích và gộp trang/in sổ gấp (mục 4.23; hai script mới `history_filter_check.py`, `imposition_check.py`).
  CI run #15: qua mọi bước hạ tầng, ĐỎ ở biên dịch Kotlin với 11 lỗi (B15-03) — đã chẩn đoán từ ảnh log và SỬA (OpenCV 5 chuyển 5 hàm sang `org.opencv.geometry.Geometry`; quên `onPrint` ở `ProjectSummaryActivity`; `writeOcrTextFile` thiếu `suspend`). CHƯA biên dịch lại. VIỆC ĐẦU TIÊN CỦA PHIÊN SAU: xem kết quả run kế tiếp (annotation "Compile errors (N)" / Job summary / artifact `build-log`), sửa lỗi còn lại.
  CI: run #7 và #11 lộ 2 lỗi hạ tầng (repo chỉ chứa zip; gói SDK `tools` không còn) — đã sửa trong workflow (B15-01, B15-02, mục 7.2); CI đã qua được 3 bước đầu (kể cả docs sync).
  Kotlin vẫn CHƯA build; 8 script mới trong `tools/verify/` đã chạy (hình học trang, nhãn, tem, phạm vi in, logic khoá, sao lưu, ý tưởng bỏ XMP, rà tĩnh tham chiếu).
- **Cập nhật (phiên làm việc thứ 14 — KIỂM TOÁN ĐỒNG BỘ TÀI LIỆU ↔ MÃ)**: người dùng hỏi tài liệu có đồng bộ với mã không; câu trả lời đo được là
  KHÔNG hoàn toàn. Đã tìm và sửa: (1) các mục hiện trạng §2/§3/§4.1/§4.2/§4.5/§5/§6/§8/§10 và README còn viết như thể iText/targetSdk 34/AGP 8.5.2/Kotlin 2.0.20 còn hiệu lực,
  hoặc thiếu hẳn các class/layout/công cụ phiên 11-14; (2) phần chú thích Kotlin của `DocumentEnhancer` còn mô tả cấu hình xóa bóng cũ; (3) các script `tools/verify` bị
  chép ở những thời điểm khác nhau nên import chéo hỏng, bản Python của Sauvola/xóa bóng khác Kotlin, và nhiều con số trong tài liệu (480 trang nhận hướng, bảng IoU, quét k,
  số liệu dewarp) chỉ có từ lần chạy thủ công không tái hiện được — nay mọi con số đó do script tái hiện; vài số đã được sửa cho đúng số thật. Để lệch không quay lại:
  `tools/verify/doc_sync_check.py` (chạy trong CI) tự kiểm 6 loại lệch — danh sách file/layout/activity, bảng phiên bản (mục 2), bảng hằng số (mục 4.21),
  danh sách script, các câu khẳng định đã cũ, và hằng số của bản Python so với Kotlin. Nó KHÔNG kiểm được nội dung văn xuôi và KHÔNG chứng minh Kotlin đúng.
- **Cập nhật (phiên làm việc thứ 14 — SỬA CO NGANG GẦN GÁY SÁCH, đọc mục 4.21)**: giới hạn "dewarp chưa sửa được độ co ngang"
  của phiên 13 đã được tra cứu và sửa trong `TextLineDewarp` (mô hình trụ + camera lỗ kim, độ dài cung). Đo trên trang sách cong mô phỏng
  vật lý có đáp án chuẩn (27 tổ hợp): sai số lưới chấm 2,36% → 1,21% (bản cũ, chỉ dọc) → **0,62%** (trung vị 0,69 → 0,28).
  Kotlin vẫn CHƯA build; chưa thử ảnh sách thật.
- **Cập nhật (phiên làm việc thứ 13 — TRA CỨU ĐỂ GIẢI QUYẾT CÁC "GIỚI HẠN" VÀ "CHƯA LÀM", đọc mục 4.20)**: người dùng
  chỉ ra rằng một giới hạn không tra cứu tìm cách giải quyết thì sẽ mãi là giới hạn. Đã tra cứu từng mục của phiên 12 và: thêm
  **tự xoay đúng chiều 0/90/180/270**, **duỗi thẳng dòng chữ cong (trang sách)**, **tự động chụp khi giữ yên máy**, **OCR 5 hệ chữ**
  (Latin/Hán/Nhật/Hàn/Devanagari), **đặt từ OCR nghiêng theo cornerPoints**, **mật khẩu AES-256 + watermark** PDF, sửa **xóa bóng cho
  viền bóng gắt**, sửa rò bộ nhớ native trong `detectDocumentCorners`. **Water-filling (Jung 2018) KHÔNG được cài vì tác giả nêu
  vấn đề bằng sáng chế với mục đích thương mại.** PDF/A và chữ ký số: đã tra cứu, chưa làm (lý do cụ thể ở 4.20). Kotlin vẫn CHƯA build.
- **Cập nhật (phiên làm việc thứ 12 — BỔ SUNG CHỨC NĂNG CÁC SDK TRẢ PHÍ CÓ, đọc mục 4.19)**: theo dặn của người
  dùng ("tính năng bản trả phí có mà bản miễn phí không có thì tham khảo paper rồi tự code"), đã thêm:
  **PDF tìm kiếm được (lớp chữ OCR vô hình)**, **2 bộ lọc mới** ("Trắng đen+" = Sauvola, "Xóa bóng"), **tự thẳng
  chữ**, **gợi ý chất lượng ảnh** (mờ/tối/thiếu tương phản); `PdfStructureOptimizer` giờ xử lý cả stream tạo trong bộ
  nhớ. Khác các phiên trước: phần THUẬT TOÁN đã được thử thật bằng công cụ độc lập (qpdf, poppler, pypdf, pdfminer,
  OpenCV Python, scikit-image) trên bản Python song song; phần KOTLIN/Android vẫn CHƯA build/chạy lần nào.
- **Cập nhật (phiên làm việc thứ 11 — ĐỔI KIẾN TRÚC ĐỂ BÁN TRẢ PHÍ TRÊN GOOGLE PLAY, đọc mục 4.18)**:
  người dùng muốn bán app có tính phí trên Google Play mà không phải trả tiền giấy phép bản quyền
  hàng năm, và dặn thêm: *nếu thư viện mã nguồn mở miễn phí kém hơn bản cần giấy phép thì tham khảo
  bản có giấy phép để tự viết code vá lại*. Đã làm: **gỡ hoàn toàn iText 7** (AGPL / giấy phép thương
  mại thu phí hằng năm) khỏi dự án, thay bằng **PdfBox-Android (Apache 2.0)**; viết lại
  `PdfObjectRecompressor`, `PdfTextEditor`, `PdfTextEditActivity`; **xoá** `PdfCanvasEditor.kt`;
  thêm `PdfStructureOptimizer` + `PdfVerify` + `LicensesActivity` để vá những gì bản miễn phí thiếu;
  chỉnh dự án đạt yêu cầu đăng Play (targetSdk 36, AAB ký release, edge-to-edge, back dự đoán, CI có
  "licence guard"). **Mọi mô tả iText ở các mục 4.11 ("Sửa trực tiếp") và 4.17 và phần "Cập nhật phiên
  8/9/10" bên dưới giờ là LỊCH SỬ — code thật đã khác, xem 4.18.** Vẫn chưa build-test lần nào.
- **Chưa build-test thật lần nào.** Toàn bộ project được viết trong môi trường không có Android
  SDK, không có mạng để chạy Gradle → mọi thứ được kiểm tra tĩnh (xem mục 9), chưa có bằng chứng
  thực tế là `./gradlew assembleDebug` / GitHub Actions chạy qua. **Việc ưu tiên số 1 khi tiếp tục:
  push code lên GitHub, chạy Actions, xem log lỗi đầu tiên (gần như chắc chắn sẽ có ít nhất 1 lỗi
  ở lần build đầu) rồi sửa tiếp.**
- Ngôn ngữ: Kotlin. Người dùng yêu cầu "so sánh cả 2 (Kotlin/Java)" ở bước đầu — **đã trả lời**, xem
  file riêng `KOTLIN_VS_JAVA.md` (tách riêng khỏi file này để không phình to với nội dung không phải
  nhật ký tiến độ). Kết luận: giữ Kotlin.
- Toàn bộ tính năng chính đã có code (xem mục 4), nhưng OCR mới chỉ đi kèm hoặc chưa được test.
- **Cập nhật (phiên làm việc tiếp theo, vẫn trong môi trường không có Android SDK/mạng — chưa
  build-test được lần nào, y hệt hạn chế đã nêu ở trên)**: đã mở rộng tự lưu/khôi phục (mục 4.13)
  sang 3 luồng còn lại — ghép PDF, quản lý trang PDF, soạn mục lục ebook (mục 4.14) — sửa cảnh báo
  xoá cặp EPUB+TXT (mục 6), thêm dọn cache định kỳ (mục 4.14), và **tìm + sửa 1 lỗi build thật** ở
  `PdfPageEditorActivity.kt` nhờ viết thêm 1 script rà soát tĩnh mới (đối chiếu số tham số gọi hàm
  với khai báo — mục 9) — đúng loại lỗi mục này đã dự đoán trước, chỉ khác là tìm được bằng rà soát
  tĩnh thay vì log CI thật.
- **Cập nhật (phiên làm việc thứ 3 — LỚN NHẤT từ trước đến giờ, đọc kỹ mục 4.15)**: người dùng mô
  tả 1 quy trình "Dự án" tuyến tính bắt buộc đi qua 8 bước (tạo dự án → chọn ảnh → chỉnh sửa ảnh →
  chọn kiểu quét → xuất PDF kèm mục lục → nén PDF → OCR → tạo ebook), yêu cầu xây đúng quy trình đó,
  **không xoá bỏ các công cụ độc lập đã có** (chúng trở thành lựa chọn/công cụ phụ, vẫn giữ nguyên
  100%), nhưng **các bước trong quy trình dự án thì bắt buộc phải đi qua, không được bỏ qua bước
  nào**. Đã xây xong toàn bộ: 1 model `Project`/`ProjectManager` mới, 9 màn hình mới (mục 4.15), có
  tính năng hoàn toàn mới chưa từng có trước đó — **tự động dò mục lục từ trang "Mục lục" của sách
  qua OCR** (`TocDetector`, mục 4.15) — và tái cấu trúc nhẹ 1 vài chỗ code cũ để dùng chung logic
  (không đổi hành vi của các công cụ cũ, xem mục 4.15 + mục 5 quyết định 21-25). Đây là khối lượng
  code MỚI lớn nhất trong 1 phiên làm việc, **chưa được build-test dù chỉ 1 dòng nào** (vẫn cùng hạn
  chế môi trường), rủi ro có lỗi build cao hơn hẳn các phiên trước — xem mục 9 "Rủi ro riêng của
  luồng Dự án".
- **Việc ưu tiên số 1 vẫn không đổi và vẫn KHÔNG làm được ở đây**: push code lên GitHub, chạy
  Actions, xem log lỗi đầu tiên — môi trường này cũng không có Android SDK/mạng để tự làm việc đó.
- **Cập nhật (phiên làm việc thứ 4, được yêu cầu "đọc kỹ tài liệu rồi hoàn thành việc dang dở" —
  vẫn cùng hạn chế môi trường như mọi phiên trước, không có SDK/mạng)**: đọc lại toàn bộ tài liệu
  này, rà lại đúng những gì mục 6/7/9/10 liệt kê là còn tồn đọng, rồi:
  - **Sửa nốt đường CUỐI CÙNG còn lại của lỗi `ASSUMED_DPI`** (mục 6/7 đã nêu rõ, cố ý để lại lần
    trước) — `MainActivity.importPdfForScanning()` → hàng đợi `PendingCropQueue` → `CropActivity`
    (chế độ queue) → `ScanSessionManager.addPage()`. Cách sửa đúng như mục 6 đã dự đoán: thêm
    `sourceDpi` (dùng chung cho cả lô) vào `PendingCropQueue`, truyền qua Intent extra
    `CropActivity.EXTRA_SOURCE_DPI` cho ảnh đầu tiên, `CropActivity` giữ lại trong 1 field suốt
    vòng đời Activity đó và gán vào MỌI `ScanPage` nó lưu ra (kể cả 2 nửa sau khi tách trang, vì
    cùng 1 Activity xử lý hết cả lô). Không đổi hành vi đường ảnh chụp/thư viện (vẫn `null` như cũ).
    Xem mục 7 để biết chi tiết đầy đủ, mục 6 mục này giờ đã gạch.
  - **Thêm backup/restore cho `ProjectEbookActivity`** (mục 6 đã nêu là còn thiếu) — file mới
    `ProjectEbookEditorState.kt`, đúng khuôn mẫu `EbookEditorState` (không lưu ảnh gốc/văn bản OCR,
    chỉ lưu tên sách + 2 checkbox định dạng + đánh dấu chương/tên chương từng trang), nhưng lưu
    THEO TỪNG DỰ ÁN (trong thư mục riêng của dự án đó, qua `FileUtils.projectDir`) thay vì 1 slot
    chung duy nhất, vì nhiều dự án có thể đang dang dở bước này ở nhiều thời điểm khác nhau. Không
    hiện hộp thoại "khôi phục hay làm lại" như công cụ độc lập — vì trang nguồn của 1 Dự án luôn cố
    định (`Project.pages`), nên hễ có trạng thái đã lưu khớp đúng danh sách trang là áp dụng luôn,
    không có gì mơ hồ cần hỏi lại người dùng. Xem mục 4.15/6.
  - **Chạy lại đủ cả 6 cách rà soát tĩnh ở mục 9 trên TOÀN BỘ code hiện tại** (kể cả code luồng Dự
    án ở mục 4.15 và `PdfObjectRecompressor.kt` — mục này trước đây có vẻ chưa được rà kỹ, xem ngay
    dưới đây) để tìm lỗi build tiềm ẩn trước khi có CI thật. Không phát hiện lỗi thật mới nào; cách
    rà số tham số hàm báo 41 chỗ nhưng kiểm tra tay xác nhận cả 41 đều là 1 loại báo động giả DUY
    NHẤT (gọi `Activity.finish()` — hàm kế thừa từ Android, 0 tham số — bị đối chiếu nhầm với hàm
    riêng không liên quan `PdfByteWriter.finish(catalogObjNum)` cùng tên nhưng khác hẳn ý nghĩa,
    vì cách rà này không biết hàm nào thuộc class nào). Xem mục 9 để biết chi tiết + cách nhận ra
    loại báo động giả này ở các lần rà sau.
  - **Sửa 2 chỗ chính tài liệu này bị thiếu/lỗi thời** (không phải lỗi code, chỉ là tài liệu): bản
    đồ file (mục 3) thiếu hẳn `PdfObjectRecompressor.kt` dù file này đã có code thật và đã được mô
    tả kỹ ở mục 4.11 — có thể do phiên viết file đó quên cập nhật mục 3; và mô tả `ScanPage.kt`/
    `PendingCropQueue.kt` ở mục 3 bị lỗi thời (chưa nhắc trường `sourceDpi` dù trường này đã có từ
    lâu, theo mục 7). Đã sửa cả 3.
  - Vẫn **chưa build-test được lần nào** — không có gì đổi ở điểm này, việc ưu tiên số 1 vẫn y
    nguyên như mọi phiên trước.
- **Cập nhật (phiên làm việc thứ 5)**: người dùng hỏi sâu thêm về `PdfObjectRecompressor` (mục
  4.11) — vì sao chỉ nén ảnh mà bỏ qua chữ/font/vector, và yêu cầu tra cứu xem có cách nào (kết hợp
  công nghệ có sẵn) giải quyết CCITT/JBIG2/JPX cũng như nén luôn phần chữ/font/vector không. Đã
  `web_search` thật (không đoán) rồi làm 2 việc có bằng chứng rõ ràng, rủi ro thấp:
  - **Bật nén cấu trúc PDF** (`WriterProperties.setFullCompressionMode` + `BEST_COMPRESSION` +
    `useSmartMode`, xác nhận là API có sẵn trong đúng `kernel-android` đang dùng, không cần thêm
    phụ thuộc) — nén object/xref stream + gộp resource trùng lặp, áp dụng cho TOÀN BỘ object trong
    file kể cả font/text/vector, không riêng ảnh. Đây là câu trả lời thật cho câu hỏi "font/text/
    vector có nén không" — nhưng nói rõ: đây là nén CẤU TRÚC LƯU TRỮ, không phải font subsetting
    thật (xoá glyph thừa) — cái đó chỉ có ở gói trả phí `pdfOptimizer` của iText, đã tra cứu xác
    nhận, không có sẵn trong thư viện miễn phí đang dùng.
  - **Thêm hỗ trợ Predictor kiểu PNG (10-15)** cho `PdfObjectRecompressor.decodeFlateRaster()` —
    phát hiện qua tra cứu: định dạng byte bên trong 1 stream FlateDecode+Predictor của PDF CHÍNH LÀ
    đúng nội dung 1 chunk IDAT của PNG (PDF spec dẫn chiếu thẳng cơ chế PNG). Nên thay vì tự viết
    thuật toán un-filter Sub/Up/Average/Paeth (rủi ro cao, không test được), bọc nguyên bytes vào 1
    file PNG tối giản tự dựng rồi đưa cho `BitmapFactory` — để bộ giải mã PNG có sẵn, đã kiểm chứng
    thật của Android tự làm phần khó. Xem mục 4.11 để biết đầy đủ.
  - **Tra cứu JBIG2/JPX, kết luận cuối là KHÔNG tích hợp (đảo ngược đánh giá lạc quan ban đầu trong
    cùng phiên này, sau khi đào sâu thêm)**: đợt tra đầu tìm được 1 thư viện JBIG2 mã nguồn mở thuần
    Java (`github.com/Borisvl/JBIG2-Image-Decoder`, nhánh mở của JPedal) có phần LÕI giải mã KHÔNG
    đụng AWT — tưởng khả thi hơn hẳn đánh giá cũ. Nhưng đào thêm 1 lớp thì phát hiện: (1) chính
    thư viện này có lịch sử lỗi thật đã ghi nhận độc lập (mô tả thẳng là "buggy", có 1 bản port
    khác ghi rõ "sửa lại" phần MMR decode vì bản gốc sai), và (2) thư viện thay thế đáng tin hơn
    (`levigo/jbig2-imageio`, do cộng đồng Apache PDFBox duy trì) lại gắn chặt AWT ở MỌI tầng API
    (`Raster`/`Rectangle`/`Dimension`), không tách được như thư viện đầu, VÀ cũng có báo lỗi thật.
    Do JBIG2 là chuẩn nhiều chế độ phức tạp và môi trường này không có cách nào đối chiếu kết quả
    decode với bất kỳ thứ gì đáng tin (khác hẳn CCITT G4 vốn có Python+libtiff để so trước khi tin)
    — rủi ro ra ảnh sai mà không biết là sai, không có lưới an toàn nào bắt được. Kết luận: KHÔNG
    tích hợp. Xem mục 6 để biết đầy đủ cả quá trình lật lại đánh giá này.
  - **JPEG2000 (JPX)**: xác nhận KHÔNG có lựa chọn thuần Java tốt nào (mọi lựa chọn thật đều bọc
    OpenJPEG qua JNI/WASM, khác hẳn kiểu phụ thuộc thuần Kotlin đã dùng xuyên suốt) — giữ nguyên
    quyết định không làm, giờ có bằng chứng tra cứu thay vì chỉ giả định. Xem mục 4.11/6.
  - Đã chạy lại đủ 6 cách rà soát tĩnh sau khi sửa — không phát hiện lỗi thật mới (chỉ thêm 7 báo
    động giả cùng loại đã biết, xem mục 9).
  - Vẫn **chưa build-test được lần nào** — không đổi.
- **Cập nhật (phiên làm việc thứ 6)**: người dùng yêu cầu thêm hộp thoại chọn cách nén CÓ ghi chú
  ưu/nhược điểm (không chỉ tên ngắn gọn như trước) ở CẢ 2 nơi — công cụ "Nén PDF" độc lập VÀ ngay
  trong luồng Quét khi xuất PDF (luồng Quét trước đây KHÔNG hề có lựa chọn nén nào, luôn xuất qua
  `PdfExporter`/`PdfDocument` của Android, không kiểm soát được cách nén). Đã làm:
  - **`CompressOptionsDialog`** (file mới, `util/`) — hộp thoại dùng chung cho cả 2 nơi, mỗi dòng
    có tiêu đề + tóm tắt + Ưu điểm + Nhược điểm thật (không phải placeholder), thay cho
    `AlertDialog.setItems()` cũ chỉ có tên. Dựng bằng `LinearLayout` điền động lúc chạy, không
    dùng RecyclerView vì danh sách luôn cố định 3-4 mục, không cần thêm phức tạp.
  - **Luồng Quét giờ CÓ lựa chọn nén khi xuất** (`PageListActivity`) — 3 lựa chọn: "Giữ nguyên chất
    lượng" (đúng hành vi cũ, không đổi gì), "An toàn (1-bit + Deflate)", "Nén sâu hơn (CCITT G4)" —
    2 cách sau đi qua ĐÚNG `PdfCompressor` mà công cụ "Nén PDF" độc lập đã dùng (không viết logic
    nén mới), chỉ khác là dựng PDF MỚI từ ảnh của phiên quét thay vì render lại 1 PDF có sẵn. Không
    có lựa chọn "Sửa trực tiếp" ở đây vì luồng Quét chưa có PDF nào tồn tại để sửa — không có ý
    nghĩa ở bước này.
  - **Mở rộng `PdfCompressor.compress()`** thêm tham số `pageDpis: List<Float?>?` (tuỳ chọn, mặc
    định `null` — không đổi hành vi 2 nơi gọi cũ) để nén PDF từ phiên quét vẫn giữ đúng DPI RIÊNG
    của từng trang — quan trọng vì 1 phiên quét có thể trộn trang chụp camera (không DPI thật) và
    trang import từ PDF (DPI thật, ví dụ 220) trong CÙNG 1 phiên (đúng con đường vừa sửa lỗi
    `ASSUMED_DPI` ở phiên thứ 4) — nếu không thêm tham số này, nén qua `PdfCompressor` sẽ ĐỘNG LẠI
    ĐÚNG lỗi khai sai kích thước trang đã dày công sửa trước đó.
  - **Tách hàm OCR ra khỏi `PdfExporter.exportSession()`** thành `PdfExporter.writeOcrTextFile()`
    dùng chung — để luồng nén mới (qua `PdfCompressor`, không tự làm OCR) vẫn giữ được checkbox
    "Nhận diện văn bản" y hệt trước. Đã cẩn thận giữ đúng tính chất "bộ nhớ giới hạn" (decode - OCR
    - giải phóng từng ảnh một, không giữ tất cả bitmap trong RAM cùng lúc) của hàm gốc khi tách ra —
    bản nháp đầu bị lỗi giữ hết bitmap trong RAM, đã tự phát hiện và sửa lại trước khi chạy check.
  - Toàn bộ nội dung Ưu/Nhược điểm viết dựa trên đúng hành vi thật đã xác nhận qua code + tra cứu ở
    các phiên trước (an toàn/G4/sửa trực tiếp — xem mục 4.11), không suy đoán.
  - Đã chạy lại đủ 6 cách rà soát tĩnh — không phát hiện lỗi thật mới (48 báo động, đúng bằng số cũ,
    toàn bộ đã xác nhận là 2 loại báo động giả đã biết — xem mục 9).
  - Vẫn **chưa build-test được lần nào** — không đổi.
- **Cập nhật (phiên làm việc thứ 7)**: người dùng yêu cầu thêm tính năng "chỉnh sửa trực tiếp nội
  dung PDF". Đã hỏi rõ trước khi làm (2 hướng rất khác độ khó/rủi ro: đánh dấu/chú thích lên trang,
  hay sửa lại đúng câu chữ gốc như Word) — người dùng chọn "cả 2, nhưng làm phần đánh dấu/chú thích
  trước". Đã làm xong phần đánh dấu/chú thích, PHẦN SỬA CHỮ GỐC CHƯA LÀM (việc lớn, rủi ro cao hơn
  nhiều — xem mục 6 để biết vì sao chưa làm và cần bàn gì trước khi làm).
  - **Tính năng mới: "Chú thích PDF"** — vẽ tay (bút), chèn chữ tự do, che/xoá 1 vùng (dán trắng)
    lên trang, rồi "làm phẳng" (flatten) kết quả vào ảnh trang — KHÔNG phải object chú thích PDF
    thật (`/Annots`) mà một trình đọc PDF có thể ẩn/hiện lại được, khớp đúng kiến trúc "mọi PDF đều
    là ảnh" của cả app từ trước tới giờ. 2 điểm vào:
    - Công cụ độc lập mới trên màn hình chính ("Chú thích PDF") — mở bất kỳ PDF nào, render từng
      trang, chú thích, xuất PDF mới.
    - Nút mới trên từng trang trong màn hình danh sách trang (`PageListActivity`) — chú thích 1
      trang đang quét dở, lưu lại vào đúng phiên quét đó (qua `ScanSessionManager.replaceFile`,
      giống hệt cách `CropActivity` trả trang đã cắt/lọc lại cho phiên).
  - File mới: `view/AnnotationCanvasView.kt` (View tự vẽ, có bút/chữ/che + hoàn tác, tự quy đổi toạ
    độ màn hình ↔ toạ độ ảnh gốc để nét vẽ không bị vỡ nét khi "làm phẳng" ở độ phân giải đầy đủ),
    `PdfAnnotateActivity.kt` (màn hình dùng chung cho cả 2 điểm vào ở trên).
  - **Tự rà lại bằng tay (không máy nào bắt được) và tìm ra 2 vấn đề thật trước khi coi là xong**:
    1. `AnnotationCanvasView.loadPage()` không giải phóng (`recycle()`) bitmap trang CŨ trước khi
       nhận bitmap MỚI — rò bộ nhớ tích luỹ dần mỗi lần chuyển trang trong 1 phiên chú thích dài
       (PDF nhiều trang). Đã sửa: giải phóng bitmap cũ trước khi gán bitmap mới (trừ khi cùng 1
       object).
    2. Chế độ PDF ngoài dùng riêng 1 thư mục làm việc (`FileUtils.annotatePagesDir`) cho các trang
       đã render — nhưng khi người dùng huỷ (thoát không lưu) hoặc xuất xong, các file trang trung
       gian đó KHÔNG được dọn, tích luỹ dần qua nhiều lần dùng tool. Đã sửa: dọn sạch thư mục này
       sau khi xuất thành công VÀ khi người dùng xác nhận huỷ.
  - **Cố tình KHÔNG làm ở phiên này** (đã ghi thẳng vào mục 6, không giấu): chưa có backup/restore
    qua chết tiến trình cho tool này (không theo khuôn mẫu `model.*State` như các tool nhiều bước
    khác) — chỉ có hộp thoại xác nhận "bỏ chú thích chưa lưu?" khi thoát, không phải lưu JSON đầy
    đủ. Chấp nhận cho bản đầu tiên, ghi rõ cách làm đúng nếu cần sau.
  - Đã chạy lại đủ 6 cách rà soát tĩnh — không phát hiện lỗi thật mới ngoài 2 lỗi tự tìm bằng tay ở
    trên (54 báo động giả, tăng đúng +6 so với trước vì file mới cũng gọi `finish()` — cùng loại đã
    biết, xem mục 9).
  - Vẫn **chưa build-test được lần nào** — không đổi. Tool có custom View (vẽ tay, toạ độ, Matrix)
    nên rủi ro "trông đúng trên giấy nhưng lệch/vỡ nét khi chạy thật" cao hơn các tool thuần logic
    khác — cần test tay kỹ trên máy thật trước khi tin, xem mục 6/10.
- **Cập nhật (phiên làm việc thứ 8) — TÍNH NĂNG RỦI RO CAO NHẤT TỪ TRƯỚC ĐẾN GIỜ, đọc kỹ mục này
  trước khi đụng vào `PdfTextEditor`/`PdfCanvasEditor`**: làm phần "sửa lại đúng câu chữ gốc trong
  PDF" mà phiên thứ 7 đã cố tình để lại (mục 6). Đã hỏi rõ phạm vi TRƯỚC khi viết dòng code nào —
  người dùng chọn "thử làm đúng nghĩa" (đọc/ghi object chữ thật) thay vì hướng an toàn hơn (dùng lại
  Che+Chèn chữ đã có ở `PdfAnnotateActivity`).
  - **Tra cứu kỹ trước khi viết** (không đoán): tìm và ĐỌC TOÀN BỘ 2 file mã nguồn thật từ
    `github.com/mkl-public/testarea-itext7` (tác giả là người trả lời câu hỏi iText content-stream
    nhiều nhất trên Stack Overflow) — `EditPageContent.java` (các ví dụ đã dùng kỹ thuật này: xoá
    chữ theo tên font, đổi màu chữ, xoá dòng theo vị trí) và `PdfCanvasEditor.java` (khung sửa
    content stream mà các ví dụ trên dùng chung) — KHÔNG suy luận từ đoạn trích, đã fetch trọn vẹn
    cả 2 file trước khi viết bất kỳ dòng Kotlin nào.
  - **`util/PdfCanvasEditor.kt`** (file mới) — port sang Kotlin gần như nguyên văn từ
    `PdfCanvasEditor.java` thật ở trên, không tự sáng tác thêm cơ chế nào. Ý tưởng cốt lõi: bọc MỌI
    operator PDF (không riêng chữ) qua `registerContentOperator`, mặc định ghi lại y nguyên qua
    chính bộ serialize object của iText (`PdfOutputStream.write(PdfObject)`) — nghĩa là 99% nội
    dung file (đường vẽ, màu, ảnh, đổi trạng thái...) KHÔNG BAO GIỜ bị app này diễn giải lại, chỉ có
    đúng phần bị override (`write()`) mới đổi. Đây là lý do chọn cách này thay vì tự viết 1 trình
    tokenize/serialize content stream từ đầu — rủi ro thấp hơn hẳn vì phần khó (hiểu đúng MỌI loại
    operator PDF) vẫn do iText lo, code app chỉ quyết định "operator NÀY có muốn đổi không".
  - **`util/PdfTextEditor.kt`** (file mới) — logic tìm (đọc) + sửa (ghi):
    - Đọc: dùng `PdfCanvasProcessor` + `TextRenderInfo` thật của iText (đúng cơ chế bất kỳ tính năng
      tìm-kiếm-chữ/copy-paste nào cũng dùng) — lấy đúng CHỮ ĐÃ GIẢI MÃ UNICODE (iText tự lo phần
      `/ToUnicode`/font encoding, app không tự viết) + font + kích thước chữ + ĐỘ RỘNG ĐÃ RENDER
      (`TextRenderInfo.getBaseline().getLength()` — đo tại đúng thời điểm đọc, không tính lại sau).
    - Sửa: dùng `PdfCanvasEditor`, chỉ can thiệp đúng operator hiện chữ (`Tj`/`'`/`"`/`TJ`), đúng
      "đoạn thứ N" đã xác định lúc đọc (đếm thống nhất — mỗi CHUỖI hiện chữ tính 1, kể cả từng phần
      tử chuỗi bên trong 1 mảng `TJ`, khớp đúng cách `TextRenderInfo` cũng bắn sự kiện theo từng
      chuỗi chứ không theo từng operator).
    - **Kiểm tra AN TOÀN TRƯỚC khi ghi, từ chối thay vì đoán** (đây là phần quan trọng nhất, xem
      doc comment đầy đủ trong chính file): (1) MỌI ký tự chữ mới phải có sẵn trong font đó
      (`PdfFont.containsGlyph(Int)` — font nhúng sẵn trong PDF thật hầu hết bị "subset", chỉ có
      đúng ký tự đã dùng, không thể tự thêm glyph mới); (2) độ co giãn ngang cần dùng để chữ mới
      vừa đúng độ rộng chữ cũ phải nằm trong 40%-250%, ngoài khoảng đó thì từ chối (không tự nén/
      giãn chữ tới mức không đọc được); (3) đoạn chữ đang sửa phải nằm TRỌN trong 1 chuỗi (không
      ghép được nếu 1 cụm chữ bị PDF chia làm nhiều mảnh `TJ` liền kề, thường gặp với chữ có canh
      kerning).
    - **Cơ chế co giãn** (`Tz` — horizontal scaling): bọc operator đã sửa trong 1 khối `q ... Tz
      ... Q` RIÊNG — không cần dò/khôi phục lại đúng giá trị `Tz` đang có trước đó (theo đúng chuẩn
      PDF, `q`/`Q` tự lưu/khôi phục toàn bộ text state kể cả `Tz`), nên phần trước/sau đoạn sửa
      không bị ảnh hưởng dù trước đó có `Tz` gì. Vì scale được tính CHÍNH XÁC để độ rộng render ra
      khớp bản gốc, vị trí con trỏ chữ sau khi hiện xong cũng khớp gần đúng bản gốc — chữ tiếp theo
      cùng dòng (nếu có, hiện bằng Tj/TJ tiếp theo không định vị lại) vẫn đúng chỗ.
  - **`PdfTextEditActivity`** (Activity mới) — chọn PDF ngoài, mở qua `PdfDocument(PdfReader,
    PdfWriter)` (stamping, giữ mở SUỐT phiên làm việc — giống hệt cách `PdfObjectRecompressor` giữ
    mở xuyên suốt nhiều ảnh trước khi đóng 1 lần), duyệt từng trang xem danh sách đoạn chữ tìm
    được, chạm 1 đoạn để sửa, Lưu đóng lại `PdfDocument` (tự hoàn thiện PDF). KHÔNG có lựa chọn
    "sửa cả đoạn văn/nhiều dòng" — chỉ sửa từng đoạn ngắn, đúng phạm vi đã thống nhất.
  - **1 lỗi thật tự tìm ra NHỜ ĐÚNG cách rà số tham số ở mục 9** (không phải nhờ đọc tay lần này) —
    hàm `trySubstituteAndWrite` được gọi kèm 1 lambda cuối (`{ ... }`) ở cả 2 chỗ gọi, nhưng khai
    báo hàm lại THIẾU hẳn tham số callback đó — lỗi sẽ khiến code KHÔNG BIÊN DỊCH ĐƯỢC (tham chiếu
    `substitute()` không tồn tại trong thân hàm). Cách rà "đếm lambda cuối +1 tham số" phát hiện
    đúng NGAY (báo lệch 6 tham số truyền vs 5 khai báo), không phải 1 trong 2 loại báo động giả đã
    biết — đã kiểm tra tay xác nhận là lỗi thật rồi sửa (thêm tham số `substitute: () -> Unit`).
  - **Nói thẳng mức độ tin cậy của các API iText đã dùng** (để phiên sau biết cái nào đã xác minh kỹ,
    cái nào chỉ dựa vào hiểu biết chung): ĐÃ XÁC NHẬN QUA TRA CỨU THẬT trong phiên này —
    `PdfFont.containsGlyph(Int)`, `PdfFont.convertToBytes(String)`, `PdfFont.getWidth(String,
    Float)`, `TextRenderInfo.getText()`/`getBaseline()`/`getFontSize()`, và toàn bộ cơ chế
    `PdfCanvasEditor`. CHƯA tra cứu riêng trong phiên này (dựa vào hiểu biết chung về iText, tin
    cậy cao nhưng không phải mức "đã đọc tài liệu thật"): `TextRenderInfo.getFont()`,
    `PdfArray.get/set/size`, `PdfNumber(Double)`. Nếu build lỗi đúng vào 1 trong 3 API này, đây là
    chỗ đầu tiên nên nghi ngờ.
  - **Giới hạn đã biết, nói thẳng không né** (xem thêm doc comment đầy đủ trong `PdfTextEditor.kt`):
    không sửa được chữ nằm trong Form XObject/pattern/annotation (chỉ đọc content stream CHÍNH của
    trang); không hỗ trợ font CID/Type0 phức tạp đã được test riêng; chưa có backup/restore qua
    chết tiến trình (giống `PdfAnnotateActivity`, cùng lý do, cùng mức chấp nhận được); và QUAN
    TRỌNG NHẤT — CHƯA TỪNG mở thử 1 file PDF thật nào qua tool này, vì môi trường này không build
    được (mục 9). Đây là tính năng DUY NHẤT trong toàn dự án trực tiếp ghi đè vào object chữ thật
    của 1 PDF có sẵn — nếu có lỗi, hậu quả là PDF hỏng/chữ sai vị trí, không phải "trông xấu" như
    lỗi UI thông thường. Bắt buộc phải tự test kỹ bằng nhiều PDF thật đa dạng (PDF từ Word, từ
    LaTeX, PDF quét có OCR text layer...) trước khi tin dùng thật.
  - Đã chạy lại đủ 6 cách rà soát tĩnh sau khi sửa lỗi tự tìm ra — 59 báo động, toàn bộ đã xác nhận
    thuộc 2 loại báo động giả đã biết (`finish`/`write`), không còn báo động chưa giải thích được.
  - Vẫn **chưa build-test được lần nào** — không đổi, và như đã nói ở trên, đây là tính năng CẦN
    test tay thật nhất trong toàn bộ dự án tính đến giờ.
- **Cập nhật (phiên làm việc thứ 9)**: người dùng hỏi thẳng vì sao 3 giới hạn của mục 4.17 không
  được tra cứu cách giải quyết (đúng tinh thần đã làm với JBIG2/font ở `PdfObjectRecompressor`).
  Tra cứu lại nghiêm túc cả 3 — kết quả KHÔNG đồng đều, nói rõ từng cái:
  - **Form XObject: hoá ra KHÔNG PHẢI chỉ là "thiếu tính năng" — là 1 LỖI THẬT nghiêm trọng hơn cả
    câu hỏi ban đầu, đã sửa ngay.** Tra ra API thật (`PdfCanvasProcessor.registerXObjectDoHandler`)
    và xác nhận qua đọc mã nguồn thật của chính iText (`FormXObjectDoHandler`) rằng
    `PdfCanvasProcessor` THƯỜNG (mặc định) TỰ ĐỘNG đi sâu vào Form XObject để bắt sự kiện
    `TextRenderInfo` — nghĩa là bước ĐỌC (`PdfTextEditor.extractChunks`, dùng `PdfCanvasProcessor`
    trơn) vẫn đếm cả chữ nằm trong Form XObject, trong khi bước GHI (`PdfCanvasEditor`, cố tình bỏ
    qua hẳn `Do`) thì KHÔNG — nghĩa là với bất kỳ trang nào có Form XObject chứa chữ (rất phổ biến:
    tiêu đề/chân trang lặp lại, logo, khối mẫu), 2 bộ đếm sẽ LỆCH NHAU ngay từ điểm đó trở đi, khiến
    MỌI đoạn chữ sau điểm lệch bị **sửa nhầm sang đúng đoạn khác** mà không có cảnh báo gì — đúng
    kiểu rủi ro "âm thầm sai" mà cả tính năng này được thiết kế để tránh. Đã sửa: `newProcessor()`
    (hàm mới trong `PdfTextEditor.kt`) đăng ký 1 `IXObjectDoHandler` rỗng cho `PdfName.Form`, buộc
    bước ĐỌC khớp đúng hành vi "không đi vào `Do`" của bước GHI — đánh đổi: chữ nằm trong Form
    XObject giờ CHẮC CHẮN không tìm/sửa được (đúng như tài liệu vốn đã nói), nhưng không còn nguy cơ
    lệch bộ đếm âm thầm nữa. Xem mã nguồn thật đã đọc: `PdfCanvasProcessor.registerXObjectDoHandler`
    + `IXObjectDoHandler.handleXObject(processor, Stack<CanvasTag>, PdfStream, PdfName)` (chữ ký 4
    tham số, đúng bản 7.2.5 dự án đang dùng, xác nhận qua tài liệu javadoc chính thức). **[Đã bị thay
    thế ở phiên thứ 10 — `newProcessor()` không còn tồn tại, giữ mục này làm lịch sử; xem phiên thứ 10
    phía dưới để biết cách sửa tận gốc hơn.]**
  - **Ghép match xuyên nhiều mảnh `TJ`: đã cân nhắc, QUYẾT ĐỊNH KHÔNG làm, không phải bỏ qua không
    nghĩ tới. [LẬP LUẬN NÀY SAI MỘT PHẦN — đã bị người dùng chỉ ra và sửa ở phiên thứ 10, xem ngay phía
    dưới; giữ nguyên nguyên văn ở đây làm lịch sử.]** Cách khả thi duy nhất nghĩ ra là DÒ HEURISTIC (gộp các đoạn liền kề nếu vị trí/font
    "có vẻ" liên tục) — nhưng heuristic tự nó có thể đoán sai (gộp nhầm 2 đoạn không liên quan, hoặc
    tính sai độ rộng gốc để ghép). Toàn bộ tính năng này được thiết kế theo triết lý "từ chối thay vì
    đoán" (xem mục 4.17) — thêm 1 heuristic dò-đoán ở chính bước TÌM sẽ đi ngược triết lý đó. Giữ
    nguyên giới hạn: 1 chuỗi tính 1 chunk, không ghép — nói thẳng đây là lựa chọn có cân nhắc, không
    phải thiếu sót chưa nghĩ tới.
  - **Backup/restore: KHÔNG cần tra cứu gì thêm — chỉ là chưa làm, nay đã làm.** Đây khác 2 mục
    trên (không phải câu hỏi "có cách nào không", mà chỉ là việc chưa bắt tay vào). Thêm
    `model/PdfTextEditState.kt` — nhưng KHÔNG theo đúng khuôn mẫu "lưu file đang dở rồi mở lại" như
    `PdfEditorState`/`EbookEditorState`, vì `PdfDocument`/`PdfWriter` ở chế độ stamping của iText
    XÂY DỰNG TOÀN BỘ file trong RAM, chỉ thật sự ghi ra đĩa lúc `close()` — tiến trình bị giết giữa
    chừng để lại file output RỖNG hoặc DỞ DANG, không phải 1 PDF một-phần-hợp-lệ có thể mở lại tiếp
    tục. Cách giải quyết: lưu bản sao NGUỒN GỐC (chưa sửa gì) ở thư mục durable
    (`FileUtils.textEditSourceDir`, MỚI thêm) + danh sách CÁC LẦN SỬA đã áp dụng thành công (trang,
    số thứ tự đoạn chữ, chữ mới) — khi mở lại, mở NGUYÊN bản sao gốc rồi ÁP LẠI LẦN LƯỢT từng lần
    sửa đã ghi (gọi lại đúng `PdfTextEditor.applyEdit()`, xác định lại đúng chunk cần sửa bằng cách
    trích lại chunk MỚI của trang đó mỗi lần — vì trang đã đổi sau mỗi lần sửa trước đó trong chuỗi
    replay) — không phải mở file dở dang, mà LÀM LẠI TỪ ĐẦU trên bản gốc, kết quả giống hệt lúc
    trước khi bị giết vì `applyEdit()` là hàm xác định (deterministic). `PdfTextEditActivity` phân
    biệt rõ "người dùng chủ động Bỏ" (dọn cả state lẫn bản sao gốc) với "thoát kiểu khác" (giữ
    nguyên state để lần sau khôi phục) qua cờ `explicitlyDiscarding` mới thêm.
  - Đã chạy lại đủ 6 cách rà soát tĩnh sau các thay đổi trên — vẫn đúng 59 báo động, cùng 2 loại đã
    biết, không có báo động mới.
  - Vẫn **chưa build-test được lần nào** — không đổi, và vẫn là tính năng cần test tay đầu tiên.
- **Cập nhật (phiên làm việc thứ 10) — người dùng chỉ ra 1 lỗi TRONG LẬP LUẬN của chính tôi, và đúng**:
  ở phiên thứ 9, tôi từ chối làm phần "ghép match xuyên nhiều mảnh `TJ`" với lý do "cần heuristic dò
  đoán, đi ngược triết lý từ chối-thay-vì-đoán". Người dùng hỏi thẳng: "tại sao phải đoán và từ chối,
  khi có thể tra cứu để biết chính xác cần làm gì" — và khi nghĩ lại, lập luận đó SAI: tôi đã NHẦM 2
  việc khác nhau hoàn toàn thành 1:
  - **Nhóm các mảnh chuỗi nằm trong CÙNG 1 mảng `TJ`** (ví dụ `[(Hel) -20 (lo)] TJ`) — đây KHÔNG PHẢI
    đoán, là **sự thật cấu trúc đọc thẳng từ chính PDF**: chúng LÀ phần tử của cùng 1 mảng, trong cùng
    1 lệnh. Không có gì mơ hồ ở đây cả. Đây mới là trường hợp phổ biến nhất của "chữ bị chia mảnh" (chữ
    canh kerning, canh đều 2 bên).
  - **Nhóm chữ giữa 2 operator KHÁC NHAU** (`Tj` cho "Hel", 1 `Tj` khác sau đó cho "lo", có thể có `Td`
    định vị lại ở giữa) — CÁI NÀY mới cần heuristic (xét vị trí/font gần nhau) vì hoàn toàn không phải
    sự thật cấu trúc, mà chỉ là "trông có vẻ liền nhau" — vẫn giữ nguyên quyết định KHÔNG làm cái này.
  Đã sửa đúng phần thứ nhất — **giờ 1 lệnh hiện chữ (kể cả `TJ` nhiều mảnh) là đúng 1 `TextChunk`**, nối
  chữ của mọi mảnh trong cùng mảng lại, không cần đoán gì.
  - **Đây cũng là dịp thiết kế lại đơn giản hơn hẳn, KHÔNG chỉ vá thêm 1 tính năng**: phiên thứ 9 vá
    lỗi lệch bộ đếm Form XObject bằng cách đăng ký `IXObjectDoHandler` rỗng để 2 đường ĐỌC/GHI (vốn
    dùng 2 cơ chế duyệt khác nhau: ĐỌC qua `TextRenderInfo` của iText, GHI qua `PdfCanvasEditor`)
    hành xử "giống nhau". Phiên này bỏ luôn việc có 2 cơ chế duyệt: **CẢ ĐỌC LẪN GHI giờ đều duyệt
    qua CÙNG 1 lớp `PdfCanvasEditor`** — ĐỌC dùng `PdfCanvasEditor.editContent()` (không phải
    `editPage()`, để tránh việc gán lại `/Contents` của trang dù chỉ để đọc) với 1 `PdfCanvas` bỏ
    đi làm đích ghi giả. Nhờ vậy chỉ còn ĐÚNG 1 chỗ quyết định "cái gì tính là 1 operator, theo thứ
    tự nào" — không thể lệch nhau được nữa, không cần cơ chế "ép cho khớp" riêng cho Form XObject
    (`newProcessor()` của phiên thứ 9 đã bị xoá vì không còn cần). Đây là cách sửa TẬN GỐC cả 1 LOẠI
    lỗi (2 đường duyệt lệch nhau), không chỉ 1 trường hợp cụ thể (Form XObject) — đúng hơn cách vá
    của phiên trước.
  - **`applyEdit()` đơn giản đi đáng kể** — bỏ hẳn vòng lặp duyệt từng phần tử trong mảng `TJ` +
    callback `trySubstituteAndWrite` phức tạp của bản cũ (chính chỗ từng có lỗi thiếu tham số ở phiên
    thứ 8). Giờ mọi trường hợp đều là "thay đúng 1 operator": `Tj`/`'`/`"` thay chuỗi operand cuối;
    `TJ` (dù nhiều mảnh) thay CẢ MẢNG bằng 1 mảng mới chỉ có 1 chuỗi (bỏ hết số kerning cũ — chúng
    được canh riêng cho đúng các ký tự của chữ CŨ, không có ý nghĩa gì với chữ mới khác). `[(chữ mới)]
    TJ` (mảng 1 phần tử) hợp lệ y hệt `(chữ mới) Tj`.
  - **1 giả định CHƯA kiểm chứng, nói thẳng**: cách đọc dùng `editContent()` + `PdfCanvas(PdfStream(),
    ...)` bỏ đi — dựa trên hiểu biết chung rằng 1 `PdfStream()` không gắn vào đâu trong cây đối tượng
    của tài liệu thì sẽ KHÔNG bị serialize vào PDF đầu ra (không rò object mồ côi) — chưa test thật.
    Nếu build xong thấy file PDF đầu ra to bất thường hoặc chứa nhiều object thừa sau nhiều lần mở/
    duyệt trang, đây là chỗ đầu tiên nên nghi ngờ.
  - **Bài học đáng ghi lại về chính cách làm việc**: cả 2 lần người dùng hỏi "sao không tra cứu" (phiên
    thứ 9, 10), lần đầu tra cứu ra 1 lỗi thật, lần sau lập luận lại thì ra 1 lỗi trong LẬP LUẬN của tôi
    — đều không phải kết quả của việc "tra cứu nhiều hơn" mà của việc hỏi lại giả định "cần đoán" có
    thật sự đúng không. Trước khi kết luận "không thể tránh khỏi đoán/từ chối", phải tự hỏi trước:
    đây là sự thật cấu trúc đọc được thẳng, hay thật sự chỉ là suy đoán?
  - Đã chạy lại đủ 6 cách rà soát tĩnh — vẫn đúng 59 báo động, cùng 2 loại đã biết, không có báo
    động mới. API công khai của `PdfTextEditor` KHÔNG ĐỔI (cùng tên/tham số/kiểu trả về) nên
    `PdfTextEditActivity` không phải sửa dòng nào.
  - Vẫn **chưa build-test được lần nào** — không đổi.

## 1. Yêu cầu gốc từ người dùng (theo đúng thứ tự đã nêu, để không sót)

1. Xây app Android kiểu CamScanner: chụp ảnh, scan ảnh, tạo PDF từ ảnh chụp.
2. Trả lời khảo sát ban đầu:
   - Ngôn ngữ: **muốn so sánh Kotlin vs Java** (chưa làm — xem mục 0).
   - Mức tính năng: **Đầy đủ** (gồm cả OCR nhận diện văn bản).
   - Môi trường: **không có PC, không có project sẵn**, cần **source code dạng zip để tự upload lên
     GitHub và build APK bằng GitHub Actions** (không dùng máy cá nhân).
3. Mở rộng phạm vi (rất quan trọng — đổi định hướng toàn bộ app):
   - App phải có **các tính năng chỉnh sửa PDF khác, ngang hàng** với tính năng camscanner — không
     phải tính năng phụ đính kèm.
   - Tính năng scan phải nhận ảnh từ **nhiều nguồn**: chụp camera, chọn từ thư viện ảnh máy, và
     **nhập từ 1 file PDF khác để scan lại**.
   - Hỏi: cách xử lý ảnh nào giúp tài liệu **dễ đọc nhất trên máy đọc sách e-ink**.
4. Phản hồi/điều chỉnh: chỉ ra rằng **e-ink màu (Kaleido 3...) đã phổ biến**, không còn chỉ có màn
   trắng đen như giả định ban đầu → cần xử lý cả 2 trường hợp trắng đen và màu cho e-ink.
5. Hỏi có chế độ **tự động nhận diện** trang trắng đen/màu để tự chọn preset e-ink phù hợp không
   (thay vì người dùng phải tự chọn 1 preset chung cho cả tài liệu) → đã làm (mục 4.6).
6. Yêu cầu viết tài liệu kỹ thuật này (file bạn đang đọc).
7. Mở rộng thêm 2 tính năng:
   - **Tạo ebook nhiều định dạng sau khi OCR**, có tuỳ chọn người dùng tự chọn mục lục (đánh dấu
     trang nào bắt đầu chương mới + đặt tên chương) → đã làm (mục 4.10).
   - **Tách ảnh chụp 2 trang sách thành 2 ảnh trang đơn**, thực hiện ở giai đoạn TRƯỚC khi crop ảnh
     → đã làm (mục 4.9).
8. Yêu cầu thêm tính năng **nén PDF đã quét**, mục tiêu "nén 10 lần nhưng chữ không vỡ ảnh" → đã
   làm (mục 4.11), gồm 2 cách chọn được: an toàn (1-bit+Deflate) và CCITT Group 4 (đúng công nghệ
   máy scan thật dùng, theo yêu cầu làm cả 2 cách để người dùng tự chọn).
9. Hỏi app có chuyển đổi được giữa các định dạng ebook không, rồi yêu cầu **"tất cả các loại convert
   document"** → đã làm 1 công cụ "Chuyển đổi định dạng" chung cho PDF/EPUB/TXT/Ảnh (mục 4.12).
10. Hỏi convert xong thì ebook gốc có mục lục có bị mất mục lục không → xác nhận có mất 1 phần, rồi
    yêu cầu sửa → đã sửa 2 điểm: đọc tên chương ưu tiên từ mục lục thật của EPUB nguồn (thay vì chỉ
    đoán qua `<h1>`), và thêm bookmark điều hướng thật vào PDF xuất ra (mục 4.12).
11. Hỏi phần scanner có backup/restore toàn bộ tiến trình không → xác nhận KHÔNG có (phiên quét chỉ
    ở bộ nhớ trong, mất khi app bị hệ thống tắt/crash/khởi động lại máy) → được yêu cầu làm → đã làm
    (mục 4.13): tự lưu phiên quét xuống đĩa sau mỗi thay đổi, hỏi khôi phục khi mở lại app.
12. Hỏi app hiện tại có đi đúng 1 quy trình cụ thể người dùng mô tả hay không (tạo dự án → chọn ảnh
    [cam hoặc thư viện, đa chọn] → chỉnh sửa ảnh [tự crop, tự gợi ý tách trang đôi, có duyệt lại] →
    chọn kiểu quét [preset cho e-ink/nén, có chỉnh tay] → xuất PDF [tự tạo mục lục từ mục lục sách,
    cho kiểm tra & sửa] → nén PDF → OCR → tạo ebook; mỗi bước thoát ra đều lưu trạng thái + có file
    dùng ngay, mở lại đúng chỗ đã dừng) → trả lời chi tiết: KHÔNG khớp — các kỹ thuật xử lý ảnh/PDF
    đã có sẵn nhưng nằm rời rạc ở các công cụ độc lập, không nối thành 1 luồng "dự án", và chưa hề có
    tính năng tự tạo mục lục từ mục lục sách. Được yêu cầu **xây đúng quy trình đó**, với 2 ràng buộc
    rõ: (a) không được xoá công cụ độc lập đã có — chúng trở thành lựa chọn/công cụ phụ, giữ nguyên;
    (b) các bước NẰM TRONG quy trình dự án thì bắt buộc phải đi tuần tự, không được bỏ qua bước nào
    → đã làm (mục 4.15): model `Project` mới + 9 màn hình mới đi đúng 8 bước, tái dùng tối đa logic
    xử lý ảnh/PDF/OCR/ebook đã có, cộng thêm tính năng mới hoàn toàn là tự động dò mục lục qua OCR
    (`TocDetector`).
13. Hỏi kỹ về cách nén PDF (bước nén trong luồng Dự án dùng thuật toán nào, có phải render trang
    thành ảnh không, so với cách các tool nén PDF khác — kiểu Ghostscript/qpdf — sửa thẳng object
    ảnh trong PDF mà không cần "chụp lại" từng trang). Xác nhận: đúng là app phải render vì không có
    thư viện đọc cấu trúc PDF; với PDF app tự quét thì không thiệt gì (mỗi trang vốn đã là ảnh), NHƯNG
    công cụ "Nén PDF" độc lập nhận PDF NGOÀI bất kỳ, kể cả PDF có chữ thật — cách render sẽ phá chữ
    thật và có thể làm file TO HƠN bản gốc, không có ý nghĩa. Yêu cầu: đổi công nghệ nén cho đúng
    trường hợp "PDF ngoài", còn bước nén trong luồng Dự án/Scanner GIỮ NGUYÊN không đổi → đã thêm 2
    lớp bảo vệ vào `MainActivity.compressExistingPdf()` (cảnh báo trước nếu nghi có chữ thật + không
    bao giờ trả về file nén to hơn bản gốc — xem mục 4.11 và mục 8 để biết vì sao KHÔNG đổi hẳn sang
    kiểu sửa-object-PDF-trực-tiếp như Ghostscript).

## 2. Kiến trúc tổng thể

- **Kotlin, Android Gradle Plugin, không dùng Gradle Wrapper** (lý do: xem mục 8.1). CI tự cài đặt
  Gradle qua action, không cần file `gradle-wrapper.jar` trong repo.
- **Hai nhóm tính năng PDF (đã đổi ở phiên 11 — đọc kỹ):**
  (a) xuất PDF từ ảnh, ghép/tách/xoay/xoá trang, nén "Giữ nguyên"/"An toàn"/CCITT, Chú thích PDF: vẫn CHỈ dùng 2 API có sẵn
  trong Android — `android.graphics.pdf.PdfRenderer` (rasterize PDF có sẵn thành bitmap từng trang) và
  `android.graphics.pdf.PdfDocument` (vẽ bitmap thành PDF mới). Đánh đổi: các công cụ ghép/tách/xoay/xoá trang đều là
  **rasterize rồi dựng lại** — chữ thật trong PDF gốc thành ảnh (lấy lại khả năng tìm chữ bằng công cụ "PDF tìm kiếm được"
  ở nhóm b). Đây là đánh đổi **có chủ đích** (mục 5.2, 8.2), không phải thiếu sót vô tình.
  (b) các tính năng phải đụng vào CẤU TRÚC/ĐỐI TƯỢNG của PDF có sẵn — nén "Sửa trực tiếp" (`PdfObjectRecompressor`), "Sửa chữ PDF"
  (`PdfTextEditor`), "PDF tìm kiếm được" (`SearchablePdfBuilder`), mật khẩu/watermark (`PdfSecurityTools`), `PdfStructureOptimizer`,
  `PdfVerify`: dùng **PdfBox-Android 2.0.27.0 (Apache 2.0)** + code tự viết. **iText đã bị gỡ hoàn toàn từ phiên 11** (AGPL /
  giấy phép thương mại: không bán trả phí được); CI chặn build nếu nó hoặc MuPDF quay lại (mục 4.18).
- **OpenCV** (`org.opencv:opencv:5.0.0.1`, xác nhận qua tra cứu là artifact chính thức trên Maven
  Central, không cần build NDK) dùng cho: phát hiện 4 góc tài liệu, làm phẳng phối cảnh (warp), các
  bộ lọc màu/xám/trắng đen, tăng bão hoà màu, và heuristic nhận diện trang màu/trắng đen.
- **Bảng phiên bản hiện hành** (do `tools/verify/doc_sync_check.py` đối chiếu với `build.gradle` + workflow CI; sửa mã thì sửa cả bảng này):
  ```
  AGP=8.13.0
  Kotlin=2.2.10
  Gradle(CI)=8.13
  compileSdk=36
  targetSdk=36
  minSdk=24
  OpenCV=5.0.0.1
  MLKit=16.0.1
  PdfBox-Android=2.0.27.0
  CameraX=1.4.1
  ```
- **ML Kit Text Recognition** (`com.google.mlkit:text-recognition:16.0.1`, bản **bundled** — không
  phải bản phụ thuộc Google Play Services tải model runtime) dùng cho OCR, chạy hoàn toàn offline. Từ phiên 13 có thêm 4 mô hình riêng (`text-recognition-chinese/japanese/korean/devanagari`,
  cùng số phiên bản) cho công cụ "PDF tìm kiếm được" — `OcrHelper.OcrScript` chọn hệ chữ; mọi chỗ gọi cũ vẫn mặc định Latin.
- **CameraX** (`1.4.1`) cho màn hình chụp.
- **Luồng dữ liệu trong phiên quét hiện tại**: `ScanSessionManager` (object singleton, in-memory,
  KHÔNG dùng database) giữ danh sách trang đang xây dựng. Cố ý đơn giản hoá vì 1 phiên quét thường
  ngắn (chụp vài trang rồi xuất luôn).
- **`PendingCropQueue`** (object singleton riêng): hàng đợi ảnh chờ đưa qua màn hình crop, dùng khi
  nhập nhiều ảnh cùng lúc (chọn nhiều ảnh thư viện, hoặc mọi trang render từ 1 PDF nhập vào) — nhờ
  đó **camera / thư viện ảnh / nhập PDF đều dùng chung 1 màn hình `CropActivity`**, không phải viết
  3 màn hình riêng.
- **`CropActivity` có 2 chế độ điều hướng** (Intent extra `EXTRA_QUEUE_MODE`):
  - *Single* (camera): lưu xong → trả `RESULT_OK`/`RESULT_CANCELED` về cho `CaptureActivity` để nó
    tiếp tục vòng lặp xem trước camera.
  - *Queue* (thư viện ảnh / nhập PDF): lưu xong tự lấy ảnh kế tiếp trong hàng đợi; hết hàng đợi mới
    điều hướng sang `PageListActivity`.
- **Phát hiện góc tài liệu trả về `null` khi không tìm được contour 4 điểm đủ tin cậy** (diện tích
  ≥20% khung hình) → nơi gọi tự dùng `defaultCorners()` (toàn khung hình, lề 5%). Đây **không phải
  ca lỗi** mà là hành vi ĐÚNG cho ảnh đã phẳng sẵn (trang render từ PDF nhập vào) — nhờ vậy code
  phát hiện góc dùng chung được cho cả 3 nguồn ảnh mà không cần nhánh riêng.

## 3. Bản đồ file/package

```
app/src/main/java/com/example/docscanner/
├── DocScannerApp.kt           # Application, khởi tạo OpenCV + PDFBoxResourceLoader + các *State manager + dọn cache (mục 4.14);
│                               # + EdgeToEdgeInsetsCallbacks: xử lý tràn viền (Android 15+) tập trung cho mọi Activity (mục 4.18)
├── ScanWidgetProvider.kt      # MỚI (phiên 22): widget màn hình chính "Quét nhanh" (Quét / Ký PDF / PDF tìm kiếm) dùng lại hành động của lối tắt - 4.49.6
├── BaseActivity.kt            # MỚI (phiên 22): lớp cha của MỌI Activity (attachBaseContext -> FontScale.wrap) - 4.49.13
├── HelpActivity.kt            # phiên 16: hướng dẫn trong app + gửi phản hồi / báo cáo sự cố / đánh giá (layout `activity_help.xml`) - 4.29
├── LicensesActivity.kt        # MỚI (phiên 11): màn "Giấy phép mã nguồn mở" đọc assets/THIRD_PARTY_NOTICES.txt (Apache 2.0 bắt buộc kèm)
├── EpubReaderActivity.kt      # MỚI (phiên 23): trình đọc EPUB trong app - mục lục, tìm + nhảy tới kết quả, dấu trang, tô sáng, cỡ chữ, chép ghi chú (C5 / C6 / C7) - 4.50
├── MainActivity.kt            # màn hình chính: thẻ "Dự án" (nổi bật nhất) + các công cụ độc lập + lịch sử
├── CaptureActivity.kt         # camera (CameraX); 2 chế độ - thường (mục 2) và "chế độ dự án" (mục 4.15)
├── CropActivity.kt            # 2 giai đoạn: kéo góc → chọn bộ lọc; single/queue mode (mục 2) - luồng THƯỜNG
├── PageListActivity.kt        # danh sách trang phiên hiện tại, bộ lọc hàng loạt, xuất PDF+OCR -
│                               # xuất giờ có 3 lựa chọn nén qua CompressOptionsDialog (mục 0/4.11,
│                               # phiên thứ 6), mặc định "Giữ nguyên" giữ đúng hành vi cũ; mỗi trang
│                               # có thêm nút "Chú thích" mở PdfAnnotateActivity (mục 0/4.16, phiên 7)
├── PdfAnnotateActivity.kt     # MỚI (phiên 7): vẽ tay/chữ/che lên trang PDF ngoài hoặc 1 trang đang
│                               # quét dở, "làm phẳng" rồi xuất PDF mới hoặc trả lại cho phiên quét -
│                               # xem mục 4.16
├── PdfTextEditActivity.kt     # MỚI (phiên 8): tìm & thay 1 đoạn chữ THẬT ngắn trong PDF ngoài,
│                               # không rasterize - RỦI RO CAO NHẤT dự án, xem mục 0/4.17/6/9 trước
│                               # khi đụng vào
├── PdfMergeActivity.kt        # ghép nhiều PDF (rasterize + rebuild)
├── PdfPageEditorActivity.kt   # xoay/xoá/sắp xếp/chọn-tách trang từ 1 PDF có sẵn
├── EbookExportActivity.kt     # chạy OCR, soạn mục lục (đánh dấu chương), xuất EPUB/TXT - luồng ĐỘC LẬP
├── ConvertDocumentActivity.kt # chuyển đổi định dạng chung: PDF/EPUB/TXT/Ảnh (mục 4.12)
├── TextResultActivity.kt      # xem + copy văn bản OCR (.txt)
├── ProjectFlow.kt             # điều hướng: stage của Project → Activity tương ứng (mục 4.15)
├── ProjectHubActivity.kt      # danh sách dự án, tạo mới/tiếp tục/xoá (mục 4.15, bước "tạo dự án")
├── ProjectPickImagesActivity.kt # Dự án bước 1: chọn ảnh - camera hoặc thư viện (mục 4.15)
├── ProjectEditActivity.kt     # Dự án bước 2: crop + tách trang đôi (mục 4.15)
├── ProjectScanActivity.kt     # Dự án bước 3: chọn preset quét bắt buộc (mục 4.15)
├── ProjectExportPdfActivity.kt # Dự án bước 4: xuất PDF + mục lục tự động/thủ công (mục 4.15)
├── ProjectCompressActivity.kt # Dự án bước 5: nén PDF (mục 4.15)
├── ProjectOcrActivity.kt      # Dự án bước 6: OCR bắt buộc (mục 4.15)
├── ProjectEbookActivity.kt    # Dự án bước 7 (cuối): tạo ebook (mục 4.15)
├── PdfSignActivity.kt         # MỚI (phiên 15): ký tay / đóng tem lên PDF, kéo-chụm để đặt vị trí, KHÔNG rasterize - 4.22
├── PdfDecorateActivity.kt     # MỚI (phiên 15): số trang, đầu/chân trang, số Bates - 4.22
├── PdfFormActivity.kt         # MỚI (phiên 15, tiếp): điền biểu mẫu PDF có ô sẵn (AcroForm): ô văn bản, ô tích, danh sách chọn - 4.25
├── PdfMarkupActivity.kt       # MỚI (phiên 17): tô sáng / gạch chân / gạch ngang chữ bằng chú thích PDF thật; kéo khung hoặc tìm cụm từ - 4.31
├── BarcodeScanActivity.kt     # MỚI (phiên 17): quét QR / mã vạch bằng camera hoặc từ ảnh, hiểu nội dung rồi gợi ý hành động - 4.31
├── VaultActivity.kt           # MỚI (phiên 17): két an toàn - danh sách, thêm, mở, lấy ra, xoá; mở bằng sinh trắc/khoá màn hình, FLAG_SECURE - 4.31
├── WifiScanActivity.kt        # MỚI (phiên 17): quét qua Wi-Fi bằng máy quét eSCL - tìm bằng mDNS hoặc nhập địa chỉ, chọn nguồn/màu/độ phân giải theo năng lực máy - 4.31
├── PdfBookmarkActivity.kt     # MỚI (phiên 17): sửa mục lục PDF - đổi tên, xoá kèm mục con, thêm dấu trang, lưu BẢN SAO - 4.34
├── PdfRedactActivity.kt       # MỚI (phiên 15, tiếp 3): vẽ hộp đen che thông tin, lưu bản mới mà chữ bên dưới biến mất khỏi tệp - 4.26
├── LockActivity.kt            # MỚI (phiên 15): màn khoá ứng dụng (vân tay / PIN màn hình) - 4.22
├── ProjectSummaryActivity.kt  # màn hình "Hoàn thành" - liệt kê mọi file thành phẩm (mục 4.15)
├── model/
│   ├── ScanPage.kt               # data class: id + filePath + sourceDpi (DPI thật nếu trang render
│   │                              # từ PDF, null nếu ảnh chụp - mục 7 "ASSUMED_DPI")
│   ├── ScanSessionManager.kt     # singleton in-memory, danh sách trang phiên hiện tại (luồng Quét độc lập)
│   ├── PendingCropQueue.kt       # singleton in-memory, hàng đợi ảnh chờ crop (có pushFront cho tách
│   │                              # trang) + sourceDpi dùng chung cho cả lô (mục 6/7, sửa ở phiên này)
│   ├── PdfEditorState.kt         # backup/restore cho PdfPageEditorActivity (mục 4.14)
│   ├── EbookEditorState.kt       # backup/restore cho EbookExportActivity, không lưu văn bản OCR (mục 4.14)
│   ├── PdfMergeState.kt          # backup/restore danh sách file chờ ghép cho PdfMergeActivity (mục 4.14)
│   ├── ProjectEbookEditorState.kt # backup/restore cho ProjectEbookActivity, 1 file JSON riêng theo
│   │                              # từng dự án trong thư mục dự án đó - cùng khuôn mẫu EbookEditorState
│   │                              # nhưng nhiều slot (nhiều dự án cùng lúc) thay vì 1 slot chung (mục 6)
│   ├── PdfTextEditState.kt       # MỚI (phiên 9): backup/restore cho PdfTextEditActivity - KHÁC
│   │                              # khuôn mẫu State khác (không lưu file dở dang mà lưu bản GỐC +
│   │                              # danh sách các lần sửa, khôi phục bằng cách áp lại từ đầu - lý do
│   │                              # kỹ thuật riêng (cả PdfDocument của iText cũ lẫn PDDocument của PdfBox hiện tại chỉ
│   │                              # ghi ra file ở lúc save/close), xem mục 0/4.17)
│   ├── Project.kt                # data class Project + ProjectStage + ProjectPage + ProjectTocEntry,
│   │                              # tự serialize/deserialize JSON (mục 4.15)
│   └── ProjectManager.kt         # CRUD Project trên đĩa (tạo/lưu/đọc/liệt kê/xoá) - THUẦN dữ liệu,
│                                  # không biết gì về Activity (mục 4.15, quyết định 22)
├── util/
│   ├── ImageProcessor.kt      # OpenCV: detect góc, warp, 4 filter, boostSaturation, isColorPage,
│   │                          # detectGutterX (gợi ý gáy sách), downscale
│   ├── OcrHelper.kt           # wrapper ML Kit (recognize: text phẳng; recognizeBlocks: theo đoạn)
│   ├── TesseractOcr.kt        # OCR chữ Cyrillic (tiếng Nga...) bằng Tesseract4Android; tải rus.traineddata MỘT lần (mục 4.48.8 (9))
│   ├── HocrParser.kt          # đọc hOCR của Tesseract -> đoạn / dòng / từ + khung (thuần Kotlin, có bản Java kiểm chứng)
│   ├── FileUtils.kt           # đường dẫn file (thường + Project), decode ảnh mẫu, decode có xử lý
│   │                          # EXIF, dọn cache định kỳ, openFile/shareFile dùng chung (mục 4.14, 4.15)
│   ├── PdfImportHelper.kt     # wrapper PdfRenderer: đếm trang, render-tất-cả-ra-file (có fileFactory
│   │                          # tuỳ chọn để đổi nơi lưu - mục 4.14), tên hiển thị
│   ├── PdfExporter.kt         # build PDF (từ session / từ đường dẫn ảnh, có thể kèm mục lục qua
│   │                          # PdfBookmarkInjector - mục 4.15 / merge nhiều PDF), xuất ảnh;
│   │                          # writeOcrTextFile() tách riêng từ exportSession() ở phiên thứ 6 để
│   │                          # dùng chung với luồng nén mới trong PageListActivity (mục 0)
│   ├── EbookBuilder.kt        # dựng EPUB (tự viết bằng java.util.zip, không thư viện ngoài) + TXT
│   ├── CompressOptionsDialog.kt # hộp thoại chọn cách nén dùng chung, mỗi dòng có Ưu/Nhược điểm
│   │                          # thật - dùng bởi cả công cụ "Nén PDF" (MainActivity) lẫn luồng Quét
│   │                          # lúc xuất (PageListActivity) - thêm ở phiên thứ 6, xem mục 0
│   ├── SearchablePdfBuilder.kt # MỚI (phiên 12): OCR từng trang + lớp chữ vô hình (font Type3 không glyph) - 4.19
│   ├── PageOrientation.kt     # MỚI (phiên 13): nhận hướng trang 0/90/180/270 (Bloomberg 1995) - 4.20
│   ├── TextLineDewarp.kt      # MỚI (phiên 13): duỗi thẳng dòng chữ cong (Ulges 2005) - 4.20
│   ├── CaptureStability.kt    # MỚI (phiên 13): logic "tự động chụp" thuần Kotlin (không phụ thuộc Android) - 4.20
│   ├── FrameDocumentAnalyzer.kt # MỚI (phiên 13): CameraX ImageAnalysis.Analyzer: khung hình → tứ giác + độ nét → CaptureStability - 4.20
│   ├── PdfSecurityTools.kt    # MỚI (phiên 13): mật khẩu AES-256, gỡ mật khẩu, watermark chữ - 4.20
│   ├── PdfPageGeometry.kt     # MỚI (phiên 15): trang xoay + CropBox → ma trận để đặt nội dung theo trang ĐANG HIỂN THỊ - 4.22
│   ├── PdfDecorator.kt        # MỚI (phiên 15): số trang / đầu-chân trang / Bates ghi vào PDF có sẵn, không rasterize - 4.22
│   ├── PdfStamper.kt          # MỚI (phiên 15): đặt ảnh trong suốt (chữ ký, tem) lên trang theo tỉ lệ - 4.22
│   ├── PdfMetadataTools.kt    # MỚI (phiên 15): sửa/xoá tiêu đề, tác giả…; bỏ cả XMP - 4.22
│   ├── PdfPrintAdapter.kt     # MỚI (phiên 15): in PDF qua PrintManager (PdfRenderer → PrintedPdfDocument) - 4.22
│   ├── SignatureStore.kt      # MỚI (phiên 15): chữ ký tay đã lưu (PNG trong bộ nhớ riêng, tối đa 8) - 4.22
│   ├── StampRenderer.kt       # MỚI (phiên 15): vẽ tem chữ có khung (ĐÃ DUYỆT, BẢN SAO, ngày) thành bitmap trong suốt - 4.22
│   ├── AppLock.kt             # MỚI (phiên 15): trạng thái khoá ứng dụng + BiometricPrompt (BIOMETRIC_WEAK | DEVICE_CREDENTIAL) - 4.22
│   ├── BackupManager.kt       # MỚI (phiên 15): sao lưu/khôi phục ZIP (tài liệu + dự án), chống zip-slip, không ghi đè - 4.22
│   ├── HistoryFilter.kt       # MỚI (phiên 15, tiếp): tìm kiếm không dấu, sắp xếp, yêu thích lên đầu cho danh sách tài liệu - 4.23
│   ├── FavoriteStore.kt       # MỚI (phiên 15, tiếp): tài liệu đã gắn sao (theo tên tệp, SharedPreferences) - 4.23
│   ├── PdfPoster.kt           # MỚI (phiên 19): một trang phóng to ra nhiều tờ A4 (poster), chồng 10 mm + dấu góc, không rasterize - 4.47.3
│   ├── PdfImposer.kt          # MỚI (phiên 15, tiếp): gộp 2/4 trang lên một tờ và xếp trang in sổ gấp, không rasterize - 4.23
│   ├── DerWriter.kt           # MỚI (phiên 15, tiếp): ASN.1 DER tối thiểu (không thư viện ngoài) cho chữ ký CMS - 4.24
│   ├── SmartNamer.kt          # MỚI (phiên 15, tiếp): gợi ý tên tệp từ văn bản OCR trang đầu, làm sạch tên, tên không trùng, đổi tên kèm tệp .txt - 4.25
│   ├── PdfPageBitmap.kt       # MỚI (phiên 15, tiếp): dựng trang PDF thành ảnh bằng PdfRenderer (một phiên nhiều trang) - 4.25
│   ├── BatchProcessor.kt      # MỚI (phiên 15, tiếp): một thao tác (đánh số, watermark, mật khẩu, xoá thông tin, gộp 2 trang) cho nhiều PDF - 4.25
│   ├── IdCardComposer.kt      # MỚI (phiên 15, tiếp): cắt thẻ từ ảnh và đặt mặt trước/sau lên một trang A4 đúng kích thước thật - 4.25
│   ├── PdfComparer.kt         # MỚI (phiên 15, tiếp): so sánh hai PDF bằng ảnh, khoanh đỏ vùng khác nhau, xuất báo cáo - 4.25
│   ├── PdfFormFiller.kt       # MỚI (phiên 15, tiếp): đọc/điền ô biểu mẫu AcroForm, dự phòng NeedAppearances cho chữ có dấu - 4.25
│   ├── TextChunker.kt         # MỚI (phiên 15, tiếp 3): cắt văn bản ≤ max ký tự cho đọc to và dịch, không mất/đảo chữ - 4.26
│   ├── TagStore.kt            # MỚI (phiên 15, tiếp 3): thẻ gắn cho tài liệu (theo tên tệp, JSON trong SharedPreferences) - 4.26
│   ├── PdfTextExtractor.kt    # MỚI (phiên 15, tiếp 3): chữ của tài liệu theo trang: lớp chữ PDF → .txt OCR kèm theo → OCR ảnh - 4.26
│   ├── SpeechReader.kt        # MỚI (phiên 15, tiếp 3): đọc to bằng TextToSpeech của máy (ưu tiên giọng Việt) - 4.26
│   ├── TextTranslator.kt      # MỚI (phiên 15, tiếp 3): dịch trên máy bằng ML Kit Translation + Language ID - 4.26
│   ├── DocxWriter.kt          # MỚI (phiên 15, tiếp 3): ghi .docx tối thiểu không thư viện, chia đoạn từ văn bản OCR - 4.26
│   ├── TrashStore.kt              # MỚI (phiên 17): thùng rác 30 ngày (tên `<mili giây>__<tên>`, không có tệp chỉ mục), khôi phục, dọn hết hạn - 4.31
│   ├── BulkRename.kt              # MỚI (phiên 17): mẫu tên {n}/{name}/{date} cho đổi tên hàng loạt, không bao giờ đè tệp - 4.31
│   ├── Despeckle.kt               # MỚI (phiên 17): khử đốm an toàn cho dấu tiếng Việt (mảnh nhỏ VÀ cách xa chữ), tự gán nhãn thành phần liên thông - 4.31
│   ├── ManualAdjust.kt            # MỚI (phiên 17): chỉnh tay 5 thanh trượt (sáng, tương phản, đậm màu, nét, khử đốm) sau bộ lọc - 4.31
│   ├── PdfTextMarkup.kt           # MỚI (phiên 17): QuadPoints theo trang hiển thị, luồng hiển thị tự dựng, khớp cụm từ không dấu - 4.31
│   ├── BarcodeContent.kt          # MỚI (phiên 17): hiểu nội dung mã (WIFI, mailto, MATMSG, tel, sms, geo, MECARD, vCard, sự kiện, URL, sản phẩm) - 4.31
│   ├── LargeScreen.kt             # MỚI (phiên 17): cột nội dung tối đa 640 dp trên màn hình rộng, danh sách màn loại trừ - 4.31
│   ├── LevelIndicator.kt          # MỚI (phiên 17): độ nghiêng máy so với mặt bàn từ gia tốc kế, bộ lọc mượt - 4.31
│   ├── PdfAConverter.kt           # MỚI (phiên 17): chuyển PDF sang PDF/A-2b, dò điểm chặn, ghi OutputIntent + XMP + Info nhất quán - 4.31
│   ├── PdfAXmp.kt                 # MỚI (phiên 17): gói XMP PDF/A và chuỗi ngày Info/XMP từ cùng một Calendar - 4.31
│   ├── SrgbIcc.kt                 # MỚI (phiên 17): hồ sơ ICC sRGB v2.1 tự sinh (2 592 byte, tất định) - 4.31
│   ├── VaultCrypto.kt             # MỚI (phiên 17): mã hoá tệp AES-256-GCM kiểu STREAM (khối 64 KiB, cờ khối cuối), thuần javax.crypto - 4.31
│   ├── VaultStore.kt              # MỚI (phiên 17): khoá chủ trong Android Keystore, thêm (kiểm đọc lại rồi mới xoá bản gốc), liệt kê, mở tạm, lấy ra, xoá sạch - 4.31
│   ├── EsclProtocol.kt            # MỚI (phiên 17): giao thức eSCL thuần (ScanSettings, năng lực theo nguồn, Location, nhập địa chỉ, chỉ mạng nội bộ) - 4.31
│   ├── EsclClient.kt              # MỚI (phiên 17): máy khách HttpURLConnection (503 thử lại, 404 là hết, luôn DELETE, từ chối địa chỉ ngoài mạng nội bộ) - 4.31
│   ├── EsclDiscovery.kt           # MỚI (phiên 17): tìm máy quét bằng NsdManager (_uscan._tcp), phân giải lần lượt - 4.31
│   ├── PdfBookmarks.kt            # MỚI (phiên 17): đọc/ghi mục lục PDF, tách theo mục lục, ghép giữ chữ + mục lục (thay cách ghép rasterize) - 4.32
│   ├── TrashMeta.kt               # MỚI (phiên 17): sao + thẻ của tài liệu viết thành .meta đi cùng tệp vào thùng rác, khôi phục lại được - 4.33
│   ├── PdfRedactor.kt         # MỚI (phiên 15, tiếp 3): che vĩnh viễn: trang có hộp dựng thành ảnh đã tô đen - 4.26
│   ├── CmsSigner.kt           # MỚI (phiên 15, tiếp): dựng PKCS#7/CMS SignedData tách rời (SHA-256 + RSA) cho /Contents của chữ ký PDF - 4.24
│   ├── PdfDigitalSigner.kt    # MỚI (phiên 15, tiếp): ký số PDF: khoá trong AndroidKeyStore + chứng thư tự ký, PdfBox saveIncremental - 4.24
│   ├── PdfSignatureProbe.kt   # MỚI (phiên 20): dò chữ ký số trong PDF bằng byte (/ByteRange + cấu trúc <...>), mức DocMDP, `effect()` theo công cụ - 4.48.1
│   ├── SignedPdfGuard.kt      # MỚI (phiên 20): hộp thoại cảnh báo trước khi ghi lại PDF đã ký (đọc tệp, hỏi, trả đúng/sai) - 4.48.1
│   ├── DocumentEnhancer.kt    # MỚI (phiên 12): Sauvola, xóa bóng nền, ước lượng + sửa nghiêng chữ - 4.19
│   ├── ScanQuality.kt         # MỚI (phiên 12): đo độ mờ (phương sai Laplacian) / tối / thiếu tương phản - 4.19
│   ├── PdfStructureOptimizer.kt # MỚI (phiên 11): tự viết theo đặc tả PDF - gói object vào object
│   │                          # stream + xref stream, Flate cho stream chưa nén, gộp stream trùng
│   │                          # byte; thay phần "full compression + smart mode" của iText. Chỉ giữ
│   │                          # kết quả khi PdfVerify qua VÀ nhỏ hơn - xem 4.18
│   ├── PdfVerify.kt           # MỚI (phiên 11): kiểm file bằng trình đọc ĐỘC LẬP (PdfRenderer) +
│   │                          # so hash nội dung từng trang khi nạp lại bằng PdfBox
│   │                          # (PdfCanvasEditor.kt đã XOÁ ở phiên 11 - nó là bản port từ mã mẫu iText)
│   ├── PdfTextEditor.kt       # MỚI (phiên 8; VIẾT LẠI phiên 11 trên PdfBox): tìm/sửa đoạn chữ thật, chứa
│   │                          # thêm ToUnicodeReverse (hỗ trợ font CID); trước đây dùng PdfCanvasEditor - RỦI RO CAO NHẤT dự án, xem mục 0/4.17/6/9;
│   │                          # viết lại ở phiên 10: ĐỌC lẫn GHI đều duyệt qua CÙNG 1 lớp
│   │                          # PdfCanvasEditor (1 operator hiện chữ = 1 chunk, TJ nhiều mảnh gộp
│   │                          # thành 1) - đọc mục 0 (phiên 9, 10) trước khi sửa file này
│   ├── PdfByteWriter.kt       # ghi object/xref PDF ở mức byte thô (dùng cho PdfCompressor)
│   ├── PdfCompressor.kt       # nén PDF đã quét: tự ghi PDF thô (không qua PdfDocument), chọn
│   │                          # 1-bit+Deflate hoặc CCITT G4 cho trang chữ, JPEG cho trang màu; có
│   │                          # thể ghi thẳng mục lục (Outline) cùng lúc - mục 4.15, quyết định 21;
│   │                          # tham số pageDpis (tuỳ chọn) thêm ở phiên thứ 6 để hỗ trợ DPI khác
│   │                          # nhau theo từng trang khi dùng cho luồng Quét (mục 0)
│   ├── PdfObjectRecompressor.kt # sửa thẳng object ảnh trong 1 PDF NGOÀI bất kỳ bằng PdfBox-Android (trước phiên 11: iText) (không
│   │                          # rasterize) - dùng cho trường hợp PDF có chữ thật, khác hẳn
│   │                          # PdfCompressor ở trên (chỉ dùng cho PDF app tự quét) - xem mục 4.11
│   ├── Ccitt4Encoder.kt       # mã hoá CCITT Group 4 (T.6/MMR) tự viết, đã kiểm chứng kỹ (mục 4.11)
│   ├── Ccitt4Decoder.kt       # giải mã lại để tự kiểm tra ngay trên máy trước khi dùng kết quả G4
│   ├── EpubReader.kt          # đọc lại 1 file EPUB có sẵn thành chapters (dùng cho mục 4.12)
│   ├── EpubTools.kt           # phiên 18: sửa thông tin / đổi bìa / ghép / tách EPUB ở mức gói ZIP - 4.35
│   ├── StorageTools.kt        # phiên 18: báo cáo dung lượng, tìm tài liệu trùng, ghi đè trước khi xoá hẳn - 4.36
│   ├── ArchiveImages.kt       # phiên 18: lấy ảnh từ gói CBZ/ZIP (thứ tự tự nhiên, chống zip-slip / zip-bomb) - 4.37
│   ├── KeepAlive.kt           # phiên 18: bộ đếm việc đang chạy + dịch vụ foreground dataSync giữ tiến trình sống - 4.38
│   ├── PdfStructureTools.kt   # phiên 18: tệp đính kèm, lớp hiển thị (OCG), liên kết trong PDF - 4.39
│   ├── PdfRepair.kt           # phiên 18: chẩn đoán cấu trúc PDF theo byte + sửa PDF hỏng (mở khoan dung rồi lưu lại) - 4.40
│   ├── PdfAutoLinks.kt        # phiên 18: biến địa chỉ web / email trong văn bản PDF thành liên kết bấm được - 4.40
│   ├── PrivateMode.kt         # phiên 18: chế độ riêng tư - tài liệu / dự án vào thư mục riêng, không Thùng rác, tắt thì xoá sạch - 4.41
│   ├── WatchFolder.kt         # phiên 18: chọn tệp MỚI trong thư mục theo dõi (logic thuần tuý) - 4.43
│   ├── AppLanguages.kt        # phiên 18: chọn ngôn ngữ giao diện (theo máy / chọn riêng), mục đang chọn - 4.46
│   ├── AppText.kt             # phiên 18: chuỗi theo ngôn ngữ đang chọn cho lớp tiện ích không có Context - 4.46
│   ├── Linearizer.kt          # phiên 18: lõi tuyến tính hoá PDF (ISO 32000-1 Annex F), thuần tuý - 4.42
│   ├── PdfLinearizer.kt       # phiên 18: lớp nối PdfBox cho Linearizer (đồ thị đối tượng, tuần tự hoá) - 4.42
│   ├── DocumentImport.kt      # đọc Markdown / HTML / Word (.docx) / CSV-TSV thành khối (tiêu đề, đoạn, mục danh sách, mã, hàng bảng) + nhận dạng mã hoá văn bản + khối -> chương (phiên 19, 4.47.2)
│   ├── OfficeImport.kt        # MỚI (phiên 20): đọc ODT / PPTX / XLSX thành khối (hoặc trang tính); máy quét XML nhỏ, ZIP có giới hạn - 4.48.2
│   ├── RtfImport.kt           # MỚI (phiên 20): đọc RTF (trang mã theo phông, \uN + \ucN, kiểu tiêu đề, danh sách, bảng) - 4.48.2
│   ├── DocInsight.kt          # MỚI (phiên 20): phân loại loại tài liệu (bảng cụm từ), gợi ý thẻ TF-IDF, tóm tắt TextRank - 4.48.3
│   ├── BackupSchedule.kt      # MỚI (phiên 20): phần THUẦN của sao lưu theo lịch - đặt tên tệp, nhận diện tệp của ta, xoay vòng giữ N bản mới nhất - 4.48.5
│   ├── AutoBackup.kt          # MỚI (phiên 20): phần Android của sao lưu theo lịch (cài đặt, JobScheduler, ghi ZIP vào thư mục SAF) - 4.48.5
│   ├── AutoBackupJobService.kt # MỚI (phiên 20): JobService chạy sao lưu theo lịch trên luồng riêng - 4.48.5
│   ├── TimeStamp.kt           # MỚI (phiên 20): dấu thời gian RFC 3161 - dựng TimeStampReq, đọc TimeStampResp, kiểm token khớp băm + nonce, POST tới TSA - 4.48.6
│   ├── TextLayerWords.kt      # MỚI (phiên 20): hình học thuần của tô sáng bằng lớp chữ thật - hộp của một từ từ các ô ký tự, hằng số ASCENT / DESCENT đã chỉnh trên dữ liệu thật - 4.48.7
│   ├── PdfTextLayer.kt        # MỚI (phiên 20): đọc từ + vị trí từ lớp chữ của PDF bằng PDFTextStripper (PdfBox) -> PdfTextMarkup.WordBox; CHƯA chạy - 4.48.7
│   ├── TablePdfBuilder.kt     # `TableLayout` (chia bề rộng cột, thuần) + `TablePdfBuilder` (CSV/TSV -> PDF dạng lưới, tiêu đề lặp mỗi trang; phiên 19, 4.47.2)
│   ├── TiffWriter.kt          # MỚI (phiên 19): ghi TIFF nhiều trang từng trang một (G4 đen trắng / xám, màu Deflate + predictor) - 4.47.4
│   ├── ZipPack.kt             # MỚI (phiên 22): nén các tài liệu đã chọn thành ZIP, có thể đặt mật khẩu AES-256 (WinZip AE-2) - 4.49.1
│   ├── LinkImport.kt          # MỚI (phiên 22): tải MỘT PDF / ảnh từ liên kết https (chuyển hướng tay, không hạ cấp, nhận dạng bằng chữ ký, giới hạn 100 MB) - 4.49.4
│   ├── EpubSearch.kt          # MỚI (phiên 22): tìm trong một EPUB, không phân biệt hoa / thường và dấu (kể cả dấu tách rời), kèm chương và ngữ cảnh - 4.49.5
│   ├── EpubNotes.kt           # MỚI (phiên 23): tô sáng / dấu trang / vị trí đọc của một EPUB (gộp vùng, dấu vân tay của sách, tệp ghi chú, chép ghi chú) - 4.50
│   ├── Revocation.kt          # MỚI (phiên 23): dữ liệu thu hồi chứng thư cho PAdES-LT - tách URL OCSP / CRL, dựng yêu cầu OCSP, đọc trả lời, chứng thư trong CMS, gom theo chuỗi - 4.51
│   ├── PdfLtv.kt              # MỚI (phiên 23): ghi /DSS (chứng thư + OCSP + CRL) vào PDF đã ký bằng cập nhật tăng dần (PdfBox) - 4.51
│   ├── IntervalShooter.kt     # MỚI (phiên 22): đồng hồ của "chụp liên tiếp" (2 / 3 / 5 giây, không chồng ảnh, không bù, tự dừng ở 300 ảnh) - 4.49.7
│   ├── Pkcs12Import.kt        # MỚI (phiên 22): đọc chứng thư + khoá riêng từ tệp .p12 / .pfx, kiểm hạn dùng / độ mạnh / khoá khớp chứng thư - 4.49.8
│   ├── Pkcs12Modern.kt        # MỚI (phiên 22): bộ đọc .p12 DỰ PHÒNG bằng javax.crypto (PBES2 / AES + MAC SHA-2 của OpenSSL 3, mà nhiều Android báo nhầm "sai mật khẩu") - 4.49.8
│   ├── VisibleSignature.kt    # MỚI (phiên 22): dấu HIỂN THỊ của chữ ký số - vị trí góc dưới phải thấy được (kể cả trang xoay), PDF mẫu viết tay, vẽ dấu bằng Canvas - 4.49.10
│   ├── TagTree.kt             # MỚI (phiên 22): thư mục ẢO phân cấp từ thẻ dạng Công việc/Hoá đơn (đếm tài liệu, lọc cha gồm con) - 4.49.11
│   ├── DocumentWebhook.kt     # MỚI (phiên 22): webhook - gửi tin ngắn (tên, loại, cỡ, giờ; KHÔNG nội dung) tới địa chỉ https khi có tài liệu mới, chữ ký HMAC-SHA256 - 4.49.12
│   ├── FontScale.kt           # MỚI (phiên 22): cỡ chữ TRONG app (Chuẩn / Lớn / Lớn hơn / Lớn nhất = 1,0 / 1,15 / 1,3 / 1,5 lần cỡ hệ thống, trần 2,0), Chuẩn = không đổi gì - 4.49.13
│   ├── QrEncoder.kt           # MỚI (phiên 19): bộ mã hoá QR thuần (phiên bản 1-40, 4 mức, số / chữ-số / byte, chuỗi Wi-Fi) - 4.47.5
│   ├── QrPdfBuilder.kt        # MỚI (phiên 19): vẽ mã QR thành một trang A4 vector kèm chú thích - 4.47.5
│   ├── TextPdfBuilder.kt      # vẽ chapters thành PDF chữ thật (dùng PdfDocument bình thường - văn
│   │                          # bản không phải mối lo nén ảnh như PdfCompressor)
│   ├── AppShortcuts.kt        # phiên 16: phím tắt ĐỘNG khi nhấn giữ biểu tượng (Quét, Dự án, PDF tìm kiếm, Ký) - 4.29
│   ├── ContentIndex.kt        # phiên 16: chỉ mục chữ OCR (`<tên>.txt` cạnh tài liệu) để tìm theo NỘI DUNG - 4.29
│   ├── CrashLog.kt            # phiên 16: nhật ký sự cố cục bộ (không Firebase), ẩn thông báo lỗi có thể chứa đường dẫn - 4.29
│   ├── IncomingFile.kt        # phiên 16: đọc/phân loại file do app khác gửi tới ("Mở bằng", "Chia sẻ") - 4.29
│   ├── PageEditorTools.kt     # phiên 16: nhân đôi / trang trắng / cắt lề / đổi khổ giấy cho Quản lý trang - 4.29
│   ├── PageRanges.kt          # phiên 16: đọc "1-3, 5, 8-" thành nhóm trang (logic thuần, có bản Java) - 4.29
│   ├── PiiDetector.kt         # phiên 16: dò CCCD/CMND, điện thoại, email, thẻ, MST, STK trong chữ (logic thuần, có bản Java) - 4.29
│   ├── ContactCard.kt         # phiên 16: danh thiếp (chữ OCR) -> liên hệ + vCard 3.0 (logic thuần, có bản Java) - 4.30
│   ├── InvoiceFields.kt       # phiên 16: trường hoá đơn VN cạnh nhãn của chúng: ngày, số, ký hiệu, MST, tổng tiền, thuế (logic thuần, có bản Java) - 4.30
│   ├── PptxWriter.kt          # phiên 16: ghi .pptx không thư viện (mỗi trang một ảnh vừa khung) - 4.30
│   ├── TableExtractor.kt      # phiên 16: dựng bảng từ hộp chữ OCR bằng khe trắng dọc giữa các cột (logic thuần, có bản Java) - 4.30
│   ├── TextExporters.kt       # phiên 16: HTML và Markdown từ chữ từng trang - 4.30
│   ├── XlsxWriter.kt          # phiên 16: ghi .xlsx không thư viện (chuỗi nội tuyến, số nguyên thành số) - 4.30
│   ├── PiiScanner.kt          # phiên 16: OCR trang -> hộp che cho PiiDetector - 4.29
│   ├── TextWrapper.kt         # phiên 16: chọn điểm ngắt dòng tham lam từ các điểm UAX #14 (không cần dấu cách;
│   │                          # logic thuần, có bản Java `WrapCheck.java`; mục 4.27)
│   ├── PdfBookmarkInjector.kt # vá bookmark vào PDF do PdfDocument ghi (byte-patching, mục 4.12)
│   ├── ScanPresetApplier.kt   # 9 preset quét (nhãn nằm trên enum), tách ra từ PageListActivity để dùng chung với
│   │                          # ProjectScanActivity (mục 4.15, quyết định 23)
│   └── TocDetector.kt         # MỚI HOÀN TOÀN: dò trang "Mục lục" của sách qua OCR + regex, tự gợi ý
│                              # tên chương (mục 4.15 - đọc kỹ phần giới hạn của heuristic này)
├── view/
│   ├── CropOverlayView.kt        # custom View: 4 góc kéo-thả, tự quy đổi toạ độ bitmap<->view (dùng
│   │                              # chung cho cả CropActivity và ProjectEditActivity)
│   ├── SplitLineOverlayView.kt   # custom View: 1 đường kéo-thả để tách ảnh 2 trang thành 2 (dùng
│   │                              # chung cho cả CropActivity và ProjectEditActivity)
│   ├── AnnotationCanvasView.kt   # MỚI (phiên 7): custom View vẽ tay/chữ/che lên 1 bitmap trang, có
│                                  # hoàn tác, cùng cách quy đổi toạ độ bitmap<->view như 2 View trên
│                                  # + hàm flatten() làm phẳng ra bitmap độ phân giải đầy đủ - dùng
│                                  # ở PdfAnnotateActivity (mục 4.16)
│   ├── SignaturePadView.kt       # MỚI (phiên 15): bảng ký tay, xuất PNG nền trong suốt cắt sát nét - 4.22
│   └── StampPlacementView.kt     # MỚI (phiên 15): trang xem trước + ảnh kéo/chụm được, trả về vị trí theo TỈ LỆ trang - 4.22
│   ├── GridOverlayView.kt         # MỚI (phiên 17): lưới chia ba trên khung camera - 4.31
│   ├── RedactionView.kt          # MỚI (phiên 15, tiếp 3): trang xem trước + vuốt vẽ hộp, trả về hộp theo TỈ LỆ trang - 4.26
└── adapter/
    ├── PageListAdapter.kt    # grid trang phiên quét (xoá + kéo sắp xếp + chú thích - phiên 7)
    ├── HistoryAdapter.kt     # list PDF/EPUB/TXT đã xuất (icon theo loại file, chia sẻ/xoá/xem) -
    │                         # dùng lại nguyên cho ProjectSummaryActivity (mục 4.15)
    ├── PdfFileAdapter.kt     # list file PDF chờ ghép (kéo sắp xếp)
    ├── PdfPageAdapter.kt     # grid trang PDF đang chỉnh (xoay/chọn/xoá/kéo sắp xếp)
    ├── EbookPageAdapter.kt   # list trang cho màn soạn mục lục ebook (bật/tắt "chương mới" + tên
    │                         # chương) - dùng lại nguyên cho ProjectEbookActivity (mục 4.15)
    ├── ProjectAdapter.kt     # list dự án cho ProjectHubActivity - dùng lại layout item_history.xml
    ├── TocEntryAdapter.kt    # list mục lục có thể sửa cho ProjectExportPdfActivity (mục 4.15)
    ├── TextChunkAdapter.kt   # list đoạn chữ tìm thấy trong PDF cho PdfTextEditActivity (mục 4.17)
    ├── EpubRowAdapter.kt     # MỚI (phiên 23): các dòng của trình đọc EPUB (tiêu đề chương + đoạn chữ chọn được, vẽ tô sáng và dấu trang) - 4.50
    └── SimpleThumbnailAdapter.kt  # grid thumbnail chỉ-xem, dùng cho ProjectScanActivity (mục 4.15)
```

Layout XML tương ứng 1-1 theo tên cho các file trên (ví dụ `activity_main.xml`,
`activity_capture.xml`, `activity_crop.xml`, `activity_page_list.xml`, `activity_pdf_merge.xml`,
`activity_pdf_page_editor.xml`, `activity_text_result.xml`, `item_page.xml`, `item_history.xml`,
`item_pdf_file.xml`, `item_pdf_page.xml`, `widget_scan.xml` (widget, phiên 22)), CỘNG THÊM cho luồng Dự án (mục 4.15):
`activity_project_hub.xml`, `activity_project_pick_images.xml`, `activity_project_edit.xml`,
`activity_project_scan.xml`, `activity_project_export_pdf.xml`, `activity_project_compress.xml`,
`activity_project_ocr.xml`, `activity_project_summary.xml`, `item_toc_entry.xml`,
`item_thumbnail.xml`; và cho các công cụ độc lập thêm sau: `activity_convert_document.xml`, `activity_pdf_annotate.xml`,
`activity_pdf_text_edit.xml`, `activity_licenses.xml`, `dialog_annotate_text.xml`, `dialog_compress_options.xml`,
`item_compress_option.xml`, `item_ebook_page.xml`, `item_text_chunk.xml`; phiên 23: `activity_epub_reader.xml`, `item_epub_row.xml`, `menu_epub_reader.xml`; phiên 15: `activity_pdf_sign.xml`, `activity_pdf_decorate.xml`, `activity_lock.xml`, `activity_pdf_form.xml`, `activity_pdf_redact.xml`. `ProjectEbookActivity` KHÔNG có layout riêng - dùng lại nguyên
`activity_ebook_editor.xml`/`ActivityEbookEditorBinding` (xem mục 4.15).

Ngoài cây thư mục trên, còn có `KOTLIN_VS_JAVA.md` ở gốc dự án (câu trả lời cho mục 1, ý 1-đầu), và (phiên 11-14):
`app/src/main/assets/THIRD_PARTY_NOTICES.txt` (giấy phép bên thứ ba, hiện ở màn Giấy phép), `.github/workflows/android-build.yml`
(build APK debug + AAB release, "licence guard", đối chiếu tài liệu) và `create-keystore.yml` (tạo khoá upload 1 lần), và `tools/verify/`
(script Python kiểm chứng thuật toán bằng công cụ độc lập — KHÔNG nằm trong APK; xem `tools/verify/README.md`).

## 4. Đã hoàn thành (chi tiết)

### 4.1 Quét tài liệu (camscanner gốc)
- 3 nguồn ảnh đầu vào từ 1 dialog chọn nguồn trong `MainActivity`: camera / thư viện ảnh (Photo
  Picker, chọn nhiều) / nhập từ file PDF khác (SAF `OpenDocument`, render mọi trang bằng
  `PdfImportHelper`).
- Cả 3 nguồn đều đi qua chung `CropActivity`: tự phát hiện 4 góc (OpenCV), cho kéo tay chỉnh lại
  (`CropOverlayView`), làm phẳng phối cảnh, rồi chọn bộ lọc (xem 4.2) và lưu trang.
- **Tự động chụp (phiên 13, mục 4.20)**: công tắc trên màn camera (mặc định TẮT); khi bật, `FrameDocumentAnalyzer` + `CaptureStability`
  tự bấm chụp khi tứ giác tài liệu đứng yên ~1,2 s và ống kính hết dò nét; chỉ chụp lại sau khi trang rời khỏi khung/lật trang.
- Ảnh camera/thư viện được decode có xử lý **EXIF orientation** trước khi xử lý (xem mục 7 — đây là
  1 lỗi thật đã tìm và sửa, không phải làm ngay từ đầu).

### 4.2 Bộ lọc mỗi trang (lúc quét, trong `CropActivity`)
6 lựa chọn thủ công (chip): Màu gốc / Tăng sáng / Xám / Trắng đen (ngưỡng thích ứng — `adaptiveThreshold`,
không phải ngưỡng cố định, để chịu được ánh sáng không đều) / **Trắng đen+** (Sauvola, phiên 12) / **Xóa bóng** (phiên 12, cấu hình
chỉnh ở phiên 13) — xem 4.19/4.20. Hai chip mới này CÓ trong "Bộ lọc hàng loạt" và bước quét của luồng Dự án từ phiên 16 (4.27; trước đó chỉ có 7 preset). Dưới hàng chip có 2 ô tích:
**"Tự xoay đúng chiều và thẳng chữ"** (`PageOrientation` + `DocumentEnhancer`, 4.20) và **"Duỗi thẳng dòng chữ cong (trang sách)"**
(`TextLineDewarp`, 4.21), cả hai mặc định TẮT, chạy nền, mỗi bước tự từ chối khi không chắc; và sau khi warp xong có toast gợi ý chất
lượng (mờ/tối/thiếu tương phản, `ScanQuality`) — chỉ là gợi ý, không chặn lưu. **Tự động gợi ý sẵn** 1 trong 2 lựa
chọn (Trắng đen nếu heuristic thấy trang không màu, Tăng sáng nếu thấy có màu) ngay sau khi warp
xong — người dùng vẫn bấm đổi được bằng tay.

### 4.3 Bộ lọc hàng loạt (trong `PageListActivity`, menu "Bộ lọc hàng loạt")
7 lựa chọn, mặc định chọn sẵn **Tự động**:
- Giữ màu gốc / Tăng sáng / Xám / Trắng đen (áp cho toàn bộ, không phân biệt từng trang)
- **E-ink – Văn bản**: trắng đen thích ứng + giảm còn ~2500px cạnh dài (≈300dpi cho khổ trang
  thường)
- **E-ink – Giữ màu**: tăng sáng/tương phản + tăng bão hoà màu (×1.35 trên kênh S của HSV) + giảm
  còn ~1300px cạnh dài (≈150dpi)
- **Tự động**: chạy `ImageProcessor.isColorPage()` cho TỪNG trang, trang nào bị coi là màu thì áp
  pipeline E-ink màu, còn lại áp E-ink văn bản; kết thúc hiện toast tổng kết
  ("Đã xử lý N trang: X trắng đen, Y giữ màu").

**Cơ sở số liệu cho 300dpi/150dpi**: tra cứu xác nhận công nghệ e-ink màu phổ biến nhất hiện nay
(Kaleido 3 — Kobo Libra/Clara Colour, Kindle Colorsoft, PocketBook Era Color...) hiển thị đen trắng
ở 300ppi nhưng giảm còn 150ppi khi hiển thị màu (do lớp lọc màu phủ trên nền panel đen trắng), và
màu thường bị nhạt/tối hơn thực tế trên loại màn này — đó là lý do preset màu có thêm bước tăng bão
hoà. Máy đọc sách trắng đen thuần (Kindle Paperwhite, Kobo Clara BW...) vẫn đang bán song song,
không phải toàn bộ thị trường đã chuyển sang màu.

### 4.4 Heuristic nhận diện trang màu/trắng đen — `ImageProcessor.isColorPage()`
Chuyển ảnh sang HSV, lấy kênh Saturation, tính tỉ lệ điểm ảnh có saturation > 40 (thang 0-255); nếu
tỉ lệ đó > 2% tổng số điểm ảnh → coi là trang có màu. Ảnh được resize nhỏ (cạnh dài ~300px) trước
khi tính để nhanh. Ngưỡng 40/2% là **suy đoán hợp lý, CHƯA từng test với ảnh thật** — xem mục 6 khi
cần tinh chỉnh.

### 4.5 OCR
`OcrHelper` bọc ML Kit Text Recognition (model bundled sẵn trong app, không cần tải thêm, chạy
offline). Khi bật checkbox "Nhận diện văn bản (OCR)" lúc xuất PDF, mỗi trang được nhận diện, kết quả
lưu thành file `.txt` cùng tên với PDF (luồng xuất này KHÔNG nhúng chữ vào PDF).
**Từ phiên 12-13:** có thêm công cụ riêng "PDF tìm kiếm được (OCR)" (thẻ ở màn hình chính, `SearchablePdfBuilder`) nhận PDF bất kỳ,
OCR từng trang chưa có chữ thật và gắn lớp chữ vô hình (mục 4.19/4.20); `OcrHelper` giờ có `recognizeLines()` (dòng→từ + khung + 4 góc) và
chọn được hệ chữ (`OcrScript`: Latin mặc định, Hán, Nhật, Hàn, Devanagari — mô hình riêng của ML Kit).

### 4.6 Ghép nhiều PDF — `PdfMergeActivity`
Chọn nhiều file PDF (SAF, có thể bấm "+ Thêm file" nhiều lần để gộp thêm), kéo sắp xếp thứ tự, ghép
bằng cách render từng trang mọi file (200dpi) rồi vẽ tuần tự vào 1 `PdfDocument` mới.

### 4.7 Quản lý trang PDF — `PdfPageEditorActivity`
Mở sẵn dialog chọn file PDF ngay khi vào màn hình. Sau khi tải (render 200dpi mọi trang), hiển thị
lưới trang cho: xoay từng trang (90°/lần), xoá trang, kéo sắp xếp lại (long-press, không có tay cầm
kéo riêng ở màn này), chạm vào ảnh để **chọn** trang (dùng cho tách/trích riêng — nếu không chọn gì,
xuất sẽ lấy TẤT CẢ trang theo thứ tự/góc xoay hiện tại). 2 nút xuất: "Xuất PDF" và "Xuất thành ảnh"
(JPG từng trang).

### 4.8 Lịch sử & chia sẻ (`MainActivity`)
Liệt kê mọi `*.pdf`/`*.epub`/`*.txt` (chỉ `.txt` ĐỘC LẬP, không phải file `.txt` đi kèm 1 `.pdf`
cùng tên) trong `Documents/` của app (external-files-dir riêng, không cần quyền storage). Icon khác
nhau theo loại file (PDF: icon tài liệu; EPUB/TXT: icon quyển sách). Mỗi dòng: chia sẻ (FileProvider
+ `ACTION_SEND`, mime type theo đúng đuôi file), xoá (kèm xoá `.txt` đi kèm cùng tên nếu có — xem
lưu ý ở mục 6 về trường hợp EPUB+TXT xuất cùng lúc dùng chung tên), chạm vào dòng: PDF → mở file
`.txt` OCR đi kèm nếu có; TXT độc lập (ebook) → mở luôn để xem/copy; EPUB → không xem trước được
trong app, chạm vào sẽ mở hộp thoại chia sẻ.

### 4.8a Công cụ "Tối ưu cho máy đọc sách" (E-ink) — `MainActivity.importPdfForEink()`
(Mô tả bổ sung ở phiên 14: trước đây công cụ này chỉ được nhắc rải rác ở 4.3 và 4.10, không có mục riêng.)
Chọn 1 PDF → render TOÀN BỘ trang ở **250 dpi** (`PdfImportHelper.renderAllPagesToFiles`) → xoá phiên quét hiện tại (`ScanSessionManager.clear()`) rồi nạp từng trang
vào phiên mới với `sourceDpi = 250` (để trang xuất ra khai đúng kích thước vật lý, xem mục 7 lỗi `ASSUMED_DPI`) → mở thẳng `PageListActivity`. Từ đó người dùng dùng
"Bộ lọc hàng loạt" (4.3, chế độ trắng đen thích ứng cho e-ink) rồi xuất PDF như luồng Quét. Lưu ý: phiên quét cũ BỊ XOÁ khi vào công cụ này (không hỏi lại);
chữ thật của PDF gốc thành ảnh (đánh đổi chung của nhóm (a), mục 2) — dùng "PDF tìm kiếm được" để lấy lại.

### 4.8b Màn xem văn bản OCR — `TextResultActivity`
Hiện nội dung file `.txt` OCR đi kèm 1 PDF (mở từ dòng PDF trong lịch sử, mục 4.8) hoặc 1 `.txt` ebook độc lập, trong 1 `TextView`; nút "Copy" đặt toàn bộ văn bản vào clipboard
(nhãn `scanned_text`). Không sửa được văn bản ở màn này. Nếu file rỗng/không đọc được: hiện chuỗi `no_text_found`.

### 4.9 Tách ảnh chụp 2 trang sách (trước khi crop)
Trong `CropActivity`, giai đoạn 1 (chỉnh góc) có thêm nút **"Tách 2 trang"** (góc trên bên phải).
Bấm vào sẽ chuyển sang 1 giai đoạn phụ hiển thị đúng ảnh gốc (CHƯA crop/warp) kèm **1 đường thẳng
đứng kéo-thả được** (`SplitLineOverlayView`, cùng cách quy đổi toạ độ bitmap↔view như
`CropOverlayView`). Vị trí khởi tạo của đường thẳng được gợi ý tự động bằng
`ImageProcessor.detectGutterX()` — tìm dải cột dọc tối nhất (bóng gáy sách) trong khoảng giữa 30%-70%
chiều rộng ảnh (dùng `Core.reduce` lấy trung bình độ sáng từng cột). Đây chỉ là **gợi ý điểm bắt
đầu**, người dùng luôn kéo chỉnh lại được — không có cơ chế nào bắt buộc theo gợi ý tự động.

Bấm "Tách trang" sẽ: cắt ảnh gốc thành 2 bitmap (trái/phải) tại đúng vị trí đường thẳng, lưu nửa
**phải** ra file tạm rồi đẩy vào **đầu** hàng đợi `PendingCropQueue` (`pushFront`, xử lý ngay sau nửa
trái, trước mọi ảnh khác đang chờ), còn nửa **trái** được đưa thẳng vào lại quy trình bình thường
(phát hiện góc → chỉnh tay → chọn lọc → lưu) như thể vừa nạp ảnh mới. Từ thời điểm tách xảy ra,
`CropActivity` **luôn chuyển sang queueMode = true** dù ban đầu vào từ camera (single mode) hay
không — lý do: xem mục 5 (quyết định 11) và mục 8.

Áp dụng đồng nhất cho **cả 3 nguồn ảnh** (camera/thư viện/PDF nhập vào) vì nút này nằm ngay trong
giai đoạn crop dùng chung, không cần code riêng cho từng nguồn.

### 4.10 Tạo Ebook (EPUB/TXT có mục lục) — `EbookExportActivity`

Vào từ 2 chỗ: (a) thẻ công cụ "Tạo Ebook" ở màn hình chính (luôn xoá phiên hiện tại trước, bắt buộc
chọn 1 file PDF để nhập vào — giống công cụ E-ink), hoặc (b) menu "Xuất Ebook" trong `PageListActivity`
(dùng ngay danh sách trang của phiên quét đang có, không xoá, không cần nhập PDF).

Luồng xử lý:
1. Nếu chưa có ảnh (trường hợp (a)), mở SAF chọn file PDF, render toàn bộ trang (200dpi) bằng
   `PdfImportHelper` như các công cụ khác.
2. Chạy OCR cho **từng trang** bằng `OcrHelper.recognizeBlocks()` (khác với `recognize()` dùng cho
   PDF — hàm này trả về danh sách theo **block** ML Kit tự nhóm dòng gần nhau, cho ranh giới đoạn
   văn tốt hơn nhiều so với việc tự tách theo dấu xuống dòng thô của `recognize()`).
3. Hiện danh sách trang (`EbookPageAdapter`): mỗi trang có ảnh thu nhỏ, đoạn xem trước văn bản OCR,
   1 công tắc **"Bắt đầu chương mới tại đây"** (trang 1 luôn bật, không tắt được — luôn có ít nhất 1
   chương), và khi bật thì hiện thêm ô nhập **tên chương** (để trống sẽ tự đặt "Chương N"). Đây
   chính là cách "người dùng chọn mục lục" mà yêu cầu đã nêu.
4. Người dùng đặt tên sách, chọn định dạng muốn xuất (checkbox EPUB / TXT, mặc định cả 2 đều bật —
   đúng nghĩa "nhiều định dạng khác nhau" trong yêu cầu).
5. Bấm Xuất: gộp trang thành danh sách `Chapter(title, paragraphs)` theo đúng các mốc "chương mới"
   đã đánh dấu, rồi gọi `EbookBuilder.buildEpub()`/`buildTxt()` tương ứng, lưu vào `Documents/`
   cùng thư mục với PDF, tên file `ebook_<timestamp>.epub`/`.txt` (khác tiền tố `scan_` của PDF để
   không đụng tên).

**`EbookBuilder.buildEpub()`** tự dựng cấu trúc EPUB bằng `java.util.zip` (KHÔNG dùng thư viện EPUB
ngoài): `mimetype` (bắt buộc là entry ZIP đầu tiên, STORED không nén) + `META-INF/container.xml` +
`OEBPS/content.opf` (metadata + manifest + spine) + `OEBPS/nav.xhtml` (mục lục EPUB3) +
`OEBPS/toc.ncx` (mục lục EPUB2, thêm vào để tương thích ngược với app đọc sách cũ) +
1 file `.xhtml` riêng cho mỗi chương + `styles.css` cơ bản. Toàn bộ text được escape XML
(`&`, `<`, `>`, `"`, `'`) trước khi chèn vào — quan trọng vì văn bản OCR có thể chứa ký tự đặc biệt.

**Quyết định không làm MOBI/AZW3**: đã tra cứu xác nhận Amazon **ngừng nhận file MOBI hoàn toàn từ
18/3/2025**, và Kindle đã nhận EPUB trực tiếp qua Send-to-Kindle từ 2022 — nên EPUB vừa an toàn hơn
(tự viết bằng ZIP có sẵn, không cần đoán định dạng nhị phân độc quyền của Amazon mà không cách nào
kiểm chứng được) vừa là lựa chọn "tương lai" hơn MOBI. FB2 (định dạng ebook Nga phổ biến) cũng được
cân nhắc (dễ làm vì cũng chỉ là XML, tái dùng được cấu trúc `Chapter` có sẵn) nhưng **chưa làm**, để
dành nếu người dùng cần thêm.

### 4.11 Nén PDF đã quét — `PdfCompressor` (+ `Ccitt4Encoder`/`Ccitt4Decoder`)

Công cụ "Nén PDF" ở màn hình chính: chọn 1 file PDF có sẵn (bất kỳ, không riêng file app này tạo
ra), chọn cách nén cho trang chữ (dialog hỏi ngay trước khi chọn file), render lại toàn bộ trang ở
250dpi rồi ghi ra 1 PDF hoàn toàn mới **tự viết ở mức byte thô** (`PdfByteWriter`) — KHÔNG dùng
`android.graphics.pdf.PdfDocument` cho tính năng này, vì lý do quan trọng: đã tra cứu xác nhận (mã
nguồn/mailing list Skia — engine PDF Android dùng bên dưới) rằng `PdfDocument` lưu bitmap đưa vào
gần như nguyên trạng (không tự nén ảnh) trừ khi cắm thêm JPEG encoder qua API Skia cấp thấp mà
`PdfDocument` công khai của Android không hề lộ ra — nghĩa là KHÔNG có cách nào khiến `PdfDocument`
thật sự nén ảnh, nên nó vô dụng cho 1 tính năng mà mục đích chính là giảm dung lượng theo tỉ lệ cụ
thể. `PdfExporter` (các tính năng khác) vẫn tiếp tục dùng `PdfDocument` bình thường vì những tính
năng đó không cam kết tỉ lệ nén cụ thể nào.

Mỗi trang được tự động phân loại (dùng lại `ImageProcessor.isColorPage()`):
- **Trang màu/ảnh chụp**: giảm cạnh dài còn ≤1600px + nén JPEG chất lượng 55, nhúng thẳng bytes
  JPEG vào PDF qua `/Filter /DCTDecode` (có mất chi tiết, nhưng chỉ áp cho ảnh, không áp cho chữ).
- **Trang chữ** (đa số): nhị phân hoá đen trắng thật (trắng đen thích ứng, dùng lại bộ lọc "Trắng
  đen" đã có), sau đó nén bằng 1 trong 2 cách **hoàn toàn không mất dữ liệu** — người dùng tự chọn
  qua dialog trước khi bắt đầu:
  1. **An toàn (1-bit + Deflate)**: đóng gói 1-bit/điểm ảnh (giảm 8 lần ngay lập tức so với 8-bit
     xám) rồi nén thêm bằng Deflate (`java.util.zip`, có sẵn trong JDK, cùng công cụ dùng để viết
     EPUB). Nhúng qua `/Filter /FlateDecode`.
  2. **CCITT Group 4 (thử nghiệm)**: đúng công nghệ nén mà máy scan/phần mềm scan thật dùng cho
     trang chữ đen trắng, nén sâu hơn cách 1 nữa. Nhúng qua `/Filter /CCITTFaxDecode` với
     `/DecodeParms << /K -1 /Columns W /Rows H /BlackIs1 false /EndOfBlock false >>`.

**Vì sao có 2 lựa chọn**: người dùng hỏi trực tiếp "có làm CCITT G4 như máy scan thật không", được
báo trước rủi ro (codec nhị phân phức tạp, tự viết mà không có máy Android thật để build/test),
người dùng yêu cầu **làm cả 2 cách để tự chọn** — không chọn 1 trong 2 thay người dùng.

#### Cách đã kiểm chứng CCITT Group 4 (quan trọng — đọc trước khi sửa `Ccitt4Encoder`/`Ccitt4Decoder`)

Đây là phần rủi ro kỹ thuật cao nhất trong toàn bộ dự án (codec nhị phân thật, sai 1 bit trong bảng
mã Huffman là hỏng thầm lặng, không cách nào phát hiện bằng mắt). Vì môi trường viết code không có
Android thật để test, đã dùng cách khác: **dựng và kiểm chứng thuật toán trong Python trước, có đối
chiếu với 1 bộ giải/mã hoá CCITT G4 đáng tin cậy đã có sẵn (libtiff, qua thư viện Pillow của
Python)**, rồi mới chuyển (port) sang Kotlin:

1. Viết bảng mã Modified Huffman (run-length trắng/đen, terminating + makeup + extended makeup) và
   thuật toán 2D (Pass/Horizontal/Vertical mode, logic tìm b1/b2 theo chuẩn T.6) bằng Python, dựa
   trên hiểu biết có sẵn về chuẩn ITU-T T.4/T.6.
2. Viết bộ **giải mã** trước, test đối chiếu: mã hoá ảnh bằng `Pillow` (`Image.save(...,
   compression='group4')`, dùng libtiff bên dưới) → dùng bộ giải mã Python tự viết để giải mã lại →
   so khớp từng điểm ảnh với ảnh gốc. Test trên 11 mẫu ảnh khác nhau (hình chữ nhật, các dòng giống
   chữ, dòng giống nhau liên tiếp, checkerboard, nhiễu ngẫu nhiên, toàn trắng, toàn đen, cả 1 trang
   giả lập 400×300 điểm ảnh) — khớp 100%.
3. Viết bộ **mã hoá** bằng chính logic/bảng đã kiểm chứng ở bước 2, test đối chiếu ngược lại: mã
   hoá cùng 11 ảnh đó bằng code Python tự viết, so **khớp từng byte** với kết quả mã hoá của
   libtiff. Sau khi phát hiện thiếu 3 byte "EOFB" (2 mã EOL liên tiếp ở cuối luồng — nhiều bộ mã
   hoá thêm vào dù không bắt buộc với PDF) và thêm vào, cả 11/11 mẫu khớp **chính xác từng byte**
   với libtiff — mức xác nhận cao nhất có thể đạt được khi không có máy Android thật.
4. Bảng mã trong file Kotlin **không gõ tay lại lần 2** — dùng script Python xuất thẳng ra cú pháp
   Kotlin (`arrayOf(...)`, `mapOf(...)`) từ đúng dữ liệu Python đã kiểm chứng, để không có cơ hội
   gõ sai khi chuyển ngôn ngữ. Riêng phần logic thuật toán (vòng lặp mã hoá/giải mã, BitWriter/
   BitReader) được chuyển tay sang Kotlin (Python không tự sinh code Kotlin phức tạp được), có rà
   soát so sánh từng dòng với bản Python đã kiểm chứng.
5. **Lưới an toàn cuối cùng nằm ngay trong app**: `PdfCompressor` gọi `Ccitt4Encoder.encode()` rồi
   NGAY LẬP TỨC gọi `Ccitt4Decoder.verify()` giải mã lại và so khớp với ảnh gốc, TRƯỚC KHI quyết
   định dùng kết quả đó. Nếu không khớp (dù rất khó xảy ra sau bước kiểm chứng trên, nhưng đây là
   lưới an toàn cho đúng trang bị lỗi đó, không phải cho cả file) → tự động dùng lại cách an toàn
   (1-bit+Deflate) CHO ĐÚNG TRANG ĐÓ, các trang khác không ảnh hưởng. Nghĩa là: cho dù bảng mã hay
   thuật toán còn sót lỗi ở 1 tình huống nào đó chưa test tới, kết quả tệ nhất là trang đó nén kém
   hơn một chút — KHÔNG BAO GIỜ ra file PDF hỏng/không đọc được.

**Điều CHƯA thể xác nhận** (vì không có máy Android thật): code Kotlin (khác hoàn toàn code Python
đã test) có compile đúng và chạy đúng như bản Python hay không — bước rà soát tay từng dòng đã làm
kỹ, nhưng đây là lần đầu code này chạy trên Android thật. Do có lưới an toàn tự giải mã lại (bước
5), rủi ro cao nhất nếu có lỗi port là "nén CCITT G4 kém hơn dự kiến / tự rơi về cách an toàn nhiều
hơn dự kiến", KHÔNG phải "ra file hỏng".

#### Giới hạn thật khi nén 1 PDF NGOÀI (không phải PDF do chính app quét ra) — và lưới an toàn đã thêm

Người dùng hỏi thẳng: nhiều tool nén PDF ngoài kia (Ghostscript, qpdf...) sửa THẲNG vào cấu trúc PDF
— tìm đúng object ảnh đã nhúng sẵn, nén lại đúng object đó, không đụng gì khác — vậy sao app này lại
"chụp lại" (render) từng trang thành ảnh rồi dựng PDF mới từ đầu?

**Trả lời thẳng: vì app không có khả năng đọc/sửa cấu trúc PDF ở mức object** (không có thư viện
kiểu PDFBox, xem mục 6) — cách DUY NHẤT lấy được pixel ra từ 1 PDF bất kỳ là dùng `PdfRenderer` của
Android để "chụp" từng trang. Với PDF do CHÍNH app quét ra (mỗi trang vốn dĩ đã là 1 ảnh chụp), cách
này không thiệt gì — nhưng công cụ "Nén PDF" độc lập ở `MainActivity` cho phép chọn BẤT KỲ file PDF
nào trên máy, kể cả file có chữ thật/hình vector (PDF xuất từ Word chẳng hạn). Với loại file đó,
"chụp lại thành ảnh" là lựa chọn TỆ: vừa mất khả năng chọn/tìm chữ, vừa thường ra file TO HƠN bản
gốc (chữ vector vốn rất nhẹ, "chụp" thành ảnh rồi nén lại vẫn nặng hơn).

Việc chuyển hẳn sang cách sửa-object-PDF-trực-tiếp như Ghostscript đòi hỏi thêm 1 thư viện đọc/ghi
PDF thật vào dự án — rủi ro cao hơn hẳn mọi thứ đã làm từ trước tới giờ (kể cả CCITT G4 ở trên,
vốn còn kiểm chứng được qua Python/libtiff trước khi port; 1 thư viện ngoài thì KHÔNG có cách nào
kiểm chứng được gì trong môi trường này — không mạng, không SDK, không build thật). Vì rủi ro đó
quá lớn so với việc chỉ đang sửa 1 công cụ có sẵn, đã KHÔNG làm theo hướng đó. Thay vào đó, đã thêm
2 lớp bảo vệ vào đúng `MainActivity.compressExistingPdf()` (**chỉ cho công cụ "Nén PDF" độc lập —
bước Nén trong luồng Dự án ở `ProjectCompressActivity` GIỮ NGUYÊN không đổi gì**, vì nguồn vào của
nó luôn là ảnh app tự quét, không có rủi ro này):

1. **Cảnh báo trước khi nén** (`fileLikelyHasRealText()`) — quét thẳng byte thô của file PDF tìm
   chuỗi `/Font` (khoá xuất hiện trong mọi PDF có nhúng font chữ thật). Tìm thấy → hỏi lại người
   dùng có chắc muốn tiếp tục không, nói rõ lý do. Đây KHÔNG phải đọc PDF thật (không parse object,
   không giải nén stream) — chỉ là tìm chuỗi thô trong file, nên **có thể bỏ sót** (PDF hiện đại
   thường nén cả object vào "object stream", lúc đó chuỗi `/Font` nằm trong dữ liệu đã nén, tìm
   thô sẽ không thấy) — chấp nhận được vì hướng bỏ sót là hướng AN TOÀN hơn (không làm phiền người
   dùng đang nén 1 file scan thật với cảnh báo sai), không phải hướng nguy hiểm.
2. **Không bao giờ trả về file "nén" ra mà lại to hơn hoặc bằng bản gốc** — sau khi nén xong, so
   `compressedSize` với `originalSize`; nếu không nhỏ hơn, XOÁ file vừa nén, báo rõ cho người dùng
   là không nén được (không đổi gì cả), thay vì âm thầm đưa ra 1 kết quả tệ hơn lúc đầu. Đây là
   đảm bảo CHẮC CHẮN, không phụ thuộc heuristic nào — khác với mục (1) ở trên.

#### "Sửa trực tiếp" — `PdfObjectRecompressor` (phụ thuộc ngoài ĐẦU TIÊN của cả dự án; **từ phiên 11 dùng PdfBox-Android thay cho iText — nội dung bên dưới là lịch sử, xem 4.18**)

Sau khi 2 lớp bảo vệ ở trên vẫn không giải quyết đúng gốc vấn đề, người dùng yêu cầu thẳng: xây
1 cách nén THẬT KHÁC — sửa object ảnh trong PDF trực tiếp, không render cả trang ra ảnh. Đã làm,
là **lựa chọn thứ 3** trong công cụ "Nén PDF" độc lập (không thay thế 2 cách cũ; luồng Dự án/
Scanner không đổi gì, tiếp tục dùng `PdfCompressor` như cũ, đúng yêu cầu người dùng).

**Thư viện dùng**: `com.itextpdf.android:kernel-android:7.2.5` (Maven repo riêng của iText:
`https://repo.itextsupport.com/android`, xác nhận qua trang cài đặt chính thức kb.itextpdf.com khi
làm việc này). Đây là **phụ thuộc ngoài đầu tiên của toàn bộ dự án** — mọi thứ khác từ trước tới
giờ đều tự viết (CCITT G4, ghi PDF thô, EPUB...) hoặc dùng thư viện có sẵn trong Android SDK.

**Vì sao chọn iText, không phải lựa chọn khác** (đã tra thật bằng web_search, không đoán):
- `TomRoush/PdfBox-Android`: Apache 2.0 (không ràng buộc), nhưng bản cuối cùng là 1/2023, hơn 3 năm
  không có bản mới, có bug report vẫn mở (8/2025), dependency (Bouncy Castle) có CVE chưa vá. Mọi
  fork khác của nó (rzimmer, tripplemac, needlessly, VivyTeam) đều cũ hơn hoặc chỉ là bản sao —
  không có lựa chọn nào trong dòng PdfBox-Android tốt hơn bản chính.
- `DroidPDF`: Kotlin-native, mới hơn, nhưng danh sách tính năng công khai (PDF Generation, Page
  Operations theo TRANG, Annotations, Forms, Encryption, Text Extraction) KHÔNG nhắc gì tới việc
  lấy ảnh đã nhúng ra rồi nén lại — đúng việc cần làm. Rủi ro "làm xong mới phát hiện thư viện
  không hỗ trợ" cao hơn hẳn rủi ro kỹ thuật thông thường.
- `iText 7/8`: được bảo trì thật, có Android build chính thức, và "lấy ảnh XObject ra, nén lại,
  nhét lại vào đúng chỗ" là chức năng "cơm bữa" của nó — có cả trang hướng dẫn chính thức
  ("Replacing images") kèm ví dụ mã nguồn thật trên GitHub (`itext/i7js-examples`). Đổi lại: AGPL
  hoặc phải mua giấy phép thương mại. **Người dùng đã chọn chấp nhận AGPL** (chỉ dùng cá nhân,
  không phát hành app dưới dạng đóng mã nguồn — nếu sau này đổi ý muốn phát hành, cần xem lại giấy
  phép này, không phải chuyện tự động ổn).

**Phát hiện quan trọng lúc viết code (tự tìm, không phải đoán) — ví dụ mẫu chính thức của iText
KHÔNG dùng được trên Android**: hàm mẫu chính thức để lấy pixel ảnh ra
(`PdfImageXObject.getBufferedImage()`) lấy được đúng SOURCE CODE của nó, bên trong gọi thẳng
`javax.imageio.ImageIO.read(...)` — API này **không tồn tại trên Android** (Android không có
`java.awt`/`javax.imageio`; có thư viện shim của bên thứ 3 chuyên vá lỗ hổng này, nhưng chính tác
giả thư viện đó ghi rõ "hackish, đừng dùng cho production"). **Đã né hoàn toàn** — dùng
`getImageBytes()` (không đụng AWT) thay vì `getBufferedImage()`, decode bằng `BitmapFactory` của
Android (đã dùng khắp app này rồi, không thêm rủi ro mới).

**Vì sao phạm vi lúc đầu chỉ có JPEG, sau đó mở rộng thêm đúng 1 trường hợp nữa (`FlateDecode` ảnh
thô)** — người dùng phản đối đúng: "chỉ JPEG" ban đầu là dừng lại quá sớm, chưa tra kỹ xem còn gì
làm được nữa không. Tra lại thì thấy: `getImageBytes()` ghi rõ 3 loại filter
(`DCTDecode`/`JBIG2Decode`/`JPXDecode`) được trả về NGUYÊN BYTE GỐC (không decode thêm ở tầng PDF)
— đúng thứ `BitmapFactory` của Android đọc được thẳng. Mọi filter KHÁC phải đi qua đường decode
tổng quát hơn của iText — tìm được 1 báo lỗi thật (StackOverflow, dùng iTextSharp — bản .NET cùng
kiến trúc xử lý ảnh với bản Java) là chính người viết code đó, có debug trực tiếp nhìn thấy ảnh,
vẫn tính SAI kích thước buffer (lệch đúng 1 byte) khiến ảnh ra bị méo/nhân đôi — phải thử lại nhiều
lần mới đúng. Đây là bằng chứng cụ thể, không phải phỏng đoán, cho thấy đường decode tổng quát dễ
sai ngay cả khi có thể NHÌN THẤY kết quả để sửa — ở đây thì không có cách nào nhìn thấy gì cả.

Thay vì né toàn bộ "không phải JPEG", đã tách riêng: **`FlateDecode` (không có predictor, 8-bit/
kênh màu, `DeviceGray` hoặc `DeviceRGB`) — TỰ giải nén bằng `java.util.zip.Inflater` (thư viện Java
chuẩn, không qua đường decode tổng quát của iText chút nào)**, rồi tự dựng lại từng pixel bằng tay,
với 1 điều kiện bắt buộc: số byte sau khi giải nén phải khớp CHÍNH XÁC `width*height*số_kênh_màu`
— không khớp thì bỏ qua ảnh đó luôn, không đoán. Đây chính là loại lỗi trong báo lỗi thật ở trên
(lệch 1 byte) nên kiểm tra này không phải phòng xa suông. Tìm thêm được 1 dự án mã nguồn mở độc lập
khác (`open-redact-pdf-redact`, Rust) làm đúng cùng bài toán "sửa ảnh trong PDF không cần cả bộ
codec" và TỰ CHỌN đúng phạm vi tương tự (8-bit/kênh, Gray/RGB, Flate+DCT, bỏ qua Indexed/JBIG2/
JPX/CCITT) — củng cố đây không phải cắt góc tuỳ tiện mà là ranh giới hợp lý nhiều dự án độc lập
khác cũng chọn.

**KHÔNG mở rộng thêm** (nói rõ lý do từng cái, không phải "khó quá bỏ qua"):
- ~~**`/DecodeParms /Predictor` >= 2**...~~ — **đã làm ở phiên thứ 5** cho đúng phần Predictor kiểu
  PNG (10-15), xem cập nhật "Predictor kiểu PNG" ngay dưới. Predictor kiểu TIFF (giá trị `2` — khác
  thuật toán hoàn toàn, không có tag lọc theo từng dòng như PNG) thì VẪN chưa làm, vẫn đúng lý do
  gốc (thuật toán khác, việc riêng).
- **`/CCITTFaxDecode`** (PDF scan đã dùng sẵn CCITT): app này đã có sẵn `Ccitt4Decoder` được kiểm
  chứng kỹ — về mặt kỹ thuật CÓ THỂ decode được — nhưng nén LẠI 1 ảnh đã ở dạng CCITT G4 (vốn đã gần
  tối ưu cho ảnh đen trắng) khó có khả năng nhỏ đi thêm được bao nhiêu, trong khi vẫn tốn công decode
  + risk. Không phải "không làm được", mà là "làm được nhưng lợi ích không rõ ràng đủ để đánh đổi
  rủi ro" — khác hẳn lý do bỏ qua Predictor/JBIG2/JPX. **Đã cân nhắc lại kỹ ở phiên thứ 5** (người
  dùng hỏi thẳng vì sao không làm) — kết luận vẫn giữ nguyên, xem mục 6 "Tra cứu JBIG2/JPX... phiên
  thứ 5" để biết đầy đủ lý do (không phải bỏ qua vì lười, mà vì tính lại thấy lợi ích thật sự rất
  nhỏ so với rủi ro tự giải mã sai `/BlackIs1`/`/K` của 1 PDF NGOÀI không do app tự tạo).
- **`/JBIG2Decode`** (JBIG2): **tra cứu lại kỹ ở phiên thứ 5, sau đó đào sâu thêm ở chính phiên này khi
  người dùng bảo "tiếp" — kết luận bị ĐẢO NGƯỢC so với đánh giá lạc quan lúc đầu, nói rõ ở đây để
  không ai (kể cả phiên sau) hiểu lầm là đã "gần xong"**. Đợt tra đầu chỉ xác nhận 1 thư viện thuần
  Java (nhánh mở của JPedal, `github.com/Borisvl/JBIG2-Image-Decoder`) có phần LÕI giải mã không
  đụng AWT — nghe có vẻ khả thi. Nhưng tra thêm 1 lớp nữa ra 2 việc quan trọng đổi hẳn kết luận:
  1. Thư viện NÀY (nhánh JPedal/Borisvl) có lịch sử lỗi thật, không phải suy đoán — 1 bài thảo luận
     độc lập trên nhóm Google (2012) mô tả thẳng đây là "buggy, open-source version of JPedal
     decoder", và có 1 bản port sang .NET khác ghi rõ trong chính tên repo là "with correct MMR
     decoding" — ý nói bản gốc decode SAI ở chế độ MMR (1 trong các kiểu mã hoá JBIG2 dùng cho
     generic region). Có hẳn 1 issue thật kèm file PDF thật tái hiện lỗi ("Quality of JBIG2 image
     in PDF file", trang 2 của 1 PDF từ archive.org bị lỗi chất lượng).
  2. Thư viện THỨ 2 (`levigo/jbig2-imageio`, tách biệt hoàn toàn với JPedal, giờ do cộng đồng Apache
     PDFBox duy trì, tự mô tả "Production quality, robust and well-tested" — người ta còn thấy 1
     thảo luận thật của người dùng đang MUỐN CHUYỂN từ JPedal-decoder buggy SANG đúng thư viện này)
     — tưởng sẽ đáng tin hơn, nhưng tra sâu vào API thật thì thấy hàm đọc dữ liệu thô của nó
     (`JBIG2ImageReader.readRaster()`) trả về thẳng `java.awt.image.Raster`, và constructor
     `JBIG2ReadParam` nhận tham số kiểu `java.awt.Rectangle`/`java.awt.Dimension` — nghĩa là API
     NÀY gắn chặt với AWT ở MỌI tầng, không tách được như JPedal (chỉ 1 lớp vỏ ngoài cùng đụng AWT,
     lõi thì sạch) — muốn dùng trên Android sẽ phải phẫu thuật sâu hơn hẳn dự tính ban đầu. VÀ thư
     viện này CŨNG có báo lỗi thật (`ArrayIndexOutOfBoundsException` trong `Bitmap.blitWithShift`/
     `TextRegion.insertIntoRegionBitmap`, gặp khi decode file JBIG2 thật).
  **Kết luận cuối cùng của phiên này**: CẢ 2 lựa chọn thực tế đều có lịch sử lỗi thật đã ghi nhận
  (không phải giả định) — khác hẳn CCITT G4 ở mục 4.11 phía trên, nơi có Python+libtiff để đối
  chiếu độc lập TRƯỚC khi tin. Ở đây, JBIG2 là chuẩn phức tạp nhiều chế độ (arithmetic coding, MMR,
  symbol dictionary + text region cho chế độ "văn bản" — đúng chế độ hay dùng nhất cho PDF quét chữ,
  vì đó là lý do JBIG2 nén tốt hơn CCITT cho trang chữ), và môi trường này **không có cách nào đối
  chiếu kết quả decode với bất kỳ thứ gì đáng tin** (không mạng trong container để cài thử 1 thư
  viện Python tham chiếu, không máy Android thật để tự mắt xem ảnh ra đúng hay sai). Tự porting 1
  trong 2 thư viện đã biết có lỗi thật, rồi không kiểm chứng được gì, rủi ro ra ảnh SAI (méo, thiếu
  vùng, lẫn lộn) mà KHÔNG BIẾT là sai — đây là loại rủi ro nghiêm trọng hơn hẳn "chỉ là chưa test
  trên máy thật" (như phần lớn dự án này), vì không có lưới an toàn nào bắt được lỗi loại này trước
  khi người dùng thật sự mở file ra xem. Vì vậy: **quyết định KHÔNG tích hợp JBIG2 trong phiên này**
  — đánh giá "khả thi hơn đã nghĩ" ở đầu mục này bị chính phiên sau (vẫn phiên thứ 5, cùng 1 lượt
  hỏi "tiếp") tự sửa lại sau khi đào sâu thêm, không phải phiên khác đảo ngược. Nếu người dùng vẫn
  muốn làm, cách hợp lý nhất là làm như 1 tính năng THỬ NGHIỆM rõ ràng (cảnh báo riêng, không bật
  mặc định) và bắt buộc tự test bằng nhiều file JBIG2 thật trên máy thật trước khi tin bất kỳ kết
  quả nào, không thể tin theo kiểu "có lưới an toàn" như những phần khác của dự án.
- **`/JPXDecode`** (JPEG2000): **tra cứu ở phiên thứ 5** — kết luận KHÔNG có lựa chọn thuần Java/
  Kotlin nào tốt. Mọi lựa chọn thật sự dùng được trên Android đều bọc thư viện gốc OpenJPEG qua JNI/
  WASM (`ThalesGroup/JP2ForAndroid`, `jpx-OpenJpegAndroid`, `keiji/jp2k-decoder-android`) — khác hẳn
  kiểu phụ thuộc thuần Kotlin/Java đã dùng xuyên suốt dự án, không cách nào kiểm chứng việc build/
  liên kết native trong môi trường này; lựa chọn thuần Java duy nhất tìm được (`JDeli`) là thư viện
  THƯƠNG MẠI, không phù hợp. Giữ nguyên quyết định KHÔNG làm, giờ có dữ liệu tra cứu thật để chứng
  minh thay vì chỉ giả định.
- **CMYK, Indexed/palette color space**: thêm 1 lớp chuyển đổi màu nữa (không đơn giản là đọc byte),
  và không có cách nào kiểm tra kết quả màu ra có đúng không ở đây.

**Predictor kiểu PNG (10-15) — đã thêm ở phiên thứ 5, KHÔNG tự viết thuật toán Sub/Up/Average/Paeth**:
người dùng hỏi thẳng "kết hợp công nghệ có sẵn để giải quyết được không" — tra cứu thì phát hiện 1
điều thú vị: định dạng `/Predictor` 10-15 của PDF ĐƯỢC CHUẨN PDF (ISO 32000) ĐỊNH NGHĨA THẲNG bằng
cách dẫn chiếu đúng cơ chế lọc thích ứng theo từng dòng của PNG (tag 1 byte đầu mỗi dòng + toàn bộ
nén zlib) — nghĩa là byte thô bên trong 1 stream `/FlateDecode` có `/Predictor` của PDF, xét ở mức
bit, CHÍNH LÀ đúng nội dung 1 chunk `IDAT` của file PNG, không cần chuyển đổi gì. Vậy thay vì tự viết
thuật toán un-filter (rủi ro cao, không cách nào test ở môi trường này), `PdfObjectRecompressor` bọc
nguyên bytes đó vào 1 file PNG tối giản (signature + IHDR + IDAT + IEND, tự viết ~40 dòng, cơ học,
dễ kiểm tra) rồi đưa thẳng cho `BitmapFactory` — để chính bộ giải mã PNG có sẵn, đã qua kiểm chứng
thật của Android tự làm phần thuật toán khó. Giá trị Predictor 10-15 chỉ là gợi ý phía ENCODER đã
dùng chiến lược nào để CHỌN filter mỗi dòng — không ảnh hưởng cách DECODE (luôn đọc đúng tag byte đã
ghi trong dữ liệu), nên cả 10-15 xử lý y hệt nhau bằng 1 đường code. Predictor `2` (kiểu TIFF, khác
thuật toán, không có tag theo dòng) vẫn KHÔNG được hỗ trợ. Vẫn giữ đúng phạm vi màu/bit-depth cũ
(Gray/RGB, 8-bit/kênh).

**Nén cấu trúc PDF (object stream + xref stream + smart mode) — đã thêm ở phiên thứ 5, đây là phần
trả lời trực tiếp câu hỏi "font/text/vector có được nén không"**: `PdfWriter` giờ được tạo với
`WriterProperties().setFullCompressionMode(true).setCompressionLevel(CompressionConstants.
BEST_COMPRESSION).useSmartMode()` — cả 3 đều là API CÓ SẴN trong đúng `kernel-android` đã dùng, xác
nhận qua tài liệu chính thức của iText (nhất quán từ bản 7.0 tới 9.1, không đổi qua các bản), không
cần thêm phụ thuộc nào. `setFullCompressionMode` nén CHÍNH CẤU TRÚC LƯU TRỮ của file (object stream +
xref stream, tính năng PDF 1.5+) — áp dụng cho MỌI object trong file, kể cả object chứa lệnh vẽ chữ/
font/vector, không riêng ảnh. `useSmartMode` gộp các resource giống hệt nhau (cùng 1 font/ảnh được
nhiều trang tham chiếu) thành 1 bản duy nhất. **Nói rõ giới hạn thật của hướng này, không phóng đại**:
đây KHÔNG phải font subsetting thật (không xoá glyph thừa chưa dùng khỏi font ĐÃ nhúng sẵn trong PDF
nguồn) — tra cứu xác nhận tính năng đó CHỈ có ở gói trả phí `pdfOptimizer` của iText (add-on riêng,
KHÔNG nằm trong `kernel-android` miễn phí đang dùng), không phải "chỉ cần bật 1 cờ là xong". Cũng
không nén lại vector graphics (đơn giản hoá đường path...) — iText không có tính năng này, và tự
viết sẽ đổi hình ảnh hiển thị nên không phù hợp làm mù trong môi trường không kiểm chứng được. Nghĩa
là: cấu trúc lưu trữ toàn file được nén thêm thật (đo được, không phải giả định), nhưng KHÔNG phải
"nén chữ/font/vector theo nội dung" như nén ảnh — 2 khái niệm khác nhau, đã nói rõ để không hiểu lầm.


**Cách hoạt động** (`PdfObjectRecompressor.recompress()`): mở PDF ở chế độ "stamping" (đúng cách
chuẩn của iText để sửa 1 phần, giữ nguyên phần còn lại — xác nhận qua ví dụ mã nguồn thật), `PdfWriter`
bật sẵn nén cấu trúc (xem "Nén cấu trúc PDF" ở trên), duyệt từng trang → từng object trong
`/Resources/XObject` → object nào là ảnh (`/Subtype /Image`) VÀ filter đúng `/DCTDecode` hoặc
`/FlateDecode` (không phải mảng nhiều filter chồng, có hoặc không Predictor kiểu PNG — xem ở trên)
→ lấy pixel ra theo đúng 1 trong các đường ở trên → nén lại ở chất lượng/kích thước y hệt trang màu
của `PdfCompressor` (JPEG quality 55, giới hạn cạnh dài 1600px — dùng lại đúng ngưỡng, không tự đặt số
mới) → nhét ngược vào đúng chỗ cũ trong dictionary. Mọi lỗi (ảnh hỏng, decode fail, sai kích
thước...) bị bắt riêng lẻ từng ảnh — bỏ qua đúng 1 ảnh đó, không làm hỏng cả file. Kết quả cuối vẫn
qua đúng lưới an toàn "không bao giờ trả về file to hơn/bằng bản gốc" (kiểm ở `MainActivity.
runDirectEditCompression`, so sánh kích thước FILE cuối cùng, không phải so từng ảnh — đáng tin
hơn vì không phụ thuộc chữ ký hàm chưa xác nhận được của `PdfStream`).

**Giới hạn đã biết, nói thẳng không né**:
- Chỉ nén được ảnh JPEG hoặc ảnh thô FlateDecode (8-bit, Gray/RGB, có hoặc không Predictor kiểu
  PNG — xem cập nhật phiên thứ 5 ở trên) — PDF scan dùng CCITT có sẵn, JBIG2, JPX, Predictor kiểu
  TIFF, hoặc PDF chỉ toàn chữ thật không có ảnh nào, sẽ báo "0 ảnh được nén" (không phải lỗi — đúng
  bản chất, không có gì làm được ở đó với phạm vi hiện tại). Cấu trúc file (object/xref stream,
  smart mode) vẫn được nén thêm dù báo "0 ảnh" — 2 việc độc lập nhau.
- Cả thư viện (chưa release 3 năm) lẫn code gọi nó (viết dựa trên tài liệu/ví dụ chính thức, KHÔNG
  compile/chạy được ở đây) đều CHƯA được kiểm chứng bằng máy/build thật — xem mục 9 phần rủi ro
  riêng của tính năng này, đây là rủi ro cao NHẤT trong toàn bộ dự án tính đến giờ.
- **[Lịch sử — repository này đã bị XOÁ khỏi `settings.gradle` ở phiên 11 và CI chặn nếu nó quay lại]** Repository Gradle của iText (`repo.itextsupport.com`) phải khai đúng trong `settings.gradle`
  (không phải `app/build.gradle`) vì dự án dùng `repositoriesMode.set(FAIL_ON_PROJECT_REPOS)` —
  khai sai chỗ sẽ làm build lỗi ngay từ bước resolve dependency, trước khi tới cả bước compile.

### 4.12 Chuyển đổi định dạng — `ConvertDocumentActivity` (+ `EpubReader`, `TextPdfBuilder`)

Công cụ chung ở màn hình chính: chọn định dạng nguồn (PDF/EPUB/TXT/Ảnh) → chọn định dạng đích (tuỳ
theo nguồn) → chuyển đổi. Để tránh viết trùng lặp, các cặp có liên quan tới PDF được **chuyển tiếp
sang đúng màn hình đã có sẵn** thay vì tự làm lại:
- Nguồn PDF, đích Ebook (EPUB/TXT) → mở `EbookExportActivity` (đã có OCR + soạn mục lục).
- Nguồn PDF, đích Ảnh → mở `PdfPageEditorActivity` (đã có nút "Xuất thành ảnh").

Phần thật sự mới (không có sẵn trước đó):
- **EPUB → PDF hoặc TXT**: `EpubReader.read()` tự đọc file EPUB (là 1 file ZIP) — mở
  `META-INF/container.xml` để tìm `content.opf`, đọc `content.opf` để lấy thứ tự spine (thứ tự đọc)
  + manifest (id → tên file chương), rồi đọc từng file `.xhtml` chương theo đúng thứ tự đó. Chỉ
  dùng `java.util.zip` (đọc ZIP) + `javax.xml.parsers.DocumentBuilderFactory` (đọc XML, có sẵn
  trong JDK/Android) + `android.text.Html.fromHtml()` (có sẵn trong Android, dùng để bỏ thẻ HTML
  lấy văn bản thuần) — không thêm thư viện đọc EPUB/HTML nào. Giới hạn: chỉ đọc được văn bản +
  tiêu đề chương, không giữ ảnh/CSS phức tạp/mục lục lồng nhau — đủ dùng để chuyển sang TXT/PDF,
  không phải trình đọc EPUB đầy đủ. Đọc lại đúng file EPUB mà `EbookBuilder` tự tạo ra thì chắc
  chắn đúng (cùng 1 cấu trúc đã biết trước); đọc EPUB từ nguồn khác thì tuỳ độ phức tạp của file đó.
  **Tên chương** được ưu tiên đọc từ mục lục thật của EPUB (`nav.xhtml` chuẩn EPUB3, nếu không có
  thì `toc.ncx` chuẩn EPUB2 — tìm qua `content.opf`: item có `properties="nav"` cho nav.xhtml, item
  có `media-type="application/x-dtbncx+xml"` cho toc.ncx), chỉ khi KHÔNG tìm được mục lục mới rơi về
  tìm `<h1>` trong nội dung chương, và cuối cùng mới là "Chương N". Sửa sau khi người dùng hỏi "EPUB
  gốc có mục lục, convert xong có mất không" — trước đó chỉ tìm `<h1>`, bỏ qua mục lục thật của file.
- **TXT → PDF hoặc EPUB**: đọc thẳng nội dung `.txt`, tách đoạn theo dòng trống, gộp thành 1
  "chương" duy nhất (không có UI đánh dấu chương như bên Ebook từ ảnh quét, vì TXT không có khái
  niệm "trang" để gắn công tắc chương vào) rồi đưa qua `EbookBuilder.buildEpub()`/`buildTxt()` như
  bình thường.
- **Ảnh → PDF**: copy thẳng các ảnh đã chọn (không crop, không OCR, không qua bước chọn bộ lọc —
  đây là đường nhanh cho người chỉ cần gộp ảnh có sẵn thành 1 PDF) rồi gọi thẳng
  `PdfExporter.exportImagePaths()` đã có sẵn.
- **`TextPdfBuilder`**: vẽ chapters thành PDF chữ thật (không phải ảnh) bằng `Canvas.drawText()`,
  tự ngắt dòng theo độ rộng trang (đo bằng `Paint.measureText()`, tách theo khoảng trắng — hoạt
  động tốt với tiếng Việt vì tiếng Việt có khoảng trắng giữa âm tiết, nhưng KHÔNG hoạt động tốt với
  ngôn ngữ không dùng khoảng trắng giữa từ như tiếng Trung/Nhật), tự sang trang mới khi hết chỗ
  (kể cả giữa 1 đoạn văn dài). Khác với `PdfCompressor`, ở đây dùng `PdfDocument` bình thường là
  ĐÚNG lựa chọn — vì đây là chữ thật (glyph/font PDF chuẩn), không phải bitmap cần kiểm soát cách
  nén, nên không gặp vấn đề "PdfDocument không nén" đã nêu ở mục 4.11/5 (quyết định 14).

- **`PdfBookmarkInjector`** (mới, để có mục lục điều hướng thật trong PDF): `PdfDocument` không có
  API công khai nào để thêm bookmark/outline, nên sau khi `PdfDocument` ghi xong file, công cụ này
  **vá thêm** vào bằng kỹ thuật "incremental update" chuẩn của PDF (cách các trình chỉnh sửa PDF
  thật hay dùng để thêm chú thích mà không đụng vào nội dung gốc) — nối thêm các object bookmark
  mới vào CUỐI file, định nghĩa lại đúng 1 object (Catalog) để trỏ tới bookmark mới, thêm 1 đoạn
  xref+trailer mới trỏ `/Prev` về xref gốc. Không đụng vào nội dung trang gốc.
  **Rủi ro thật cần biết**: để làm được việc này, code phải tự đọc lại 1 phần cấu trúc file PDF mà
  `PdfDocument` vừa ghi ra (tìm trailer → Catalog → Pages → Kids) — đây KHÔNG phải API công khai,
  không có gì đảm bảo Android sẽ luôn ghi đúng định dạng giả định (trailer cổ điển, không phải
  cross-reference stream PDF 1.5+). Toàn bộ quá trình bọc trong try/catch, hễ **bất kỳ bước nào**
  không đúng như kỳ vọng (không tìm thấy trailer, số trang đọc được không khớp số trang thực tế đã
  vẽ, v.v.) → trả về `null` → `TextPdfBuilder` tự động dùng file gốc CHƯA có bookmark, không có
  cách nào ra file hỏng. Nghĩa là: có thể có bookmark hoặc không (tuỳ Android có ghi PDF đúng như
  giả định hay không), nhưng không bao giờ làm hỏng file.

### 4.13 Tự lưu & khôi phục phiên quét — `ScanSessionManager` (backup/restore)

Trước bản này, `ScanSessionManager` (danh sách trang của phiên quét hiện tại) chỉ tồn tại **trong
bộ nhớ (RAM)** — mất sạch nếu app bị hệ thống Android tự tắt (rất hay xảy ra khi app chạy nền lâu
trên máy ít RAM), bị crash, hoặc điện thoại khởi động lại, dù đã chụp được bao nhiêu trang cũng
mất hết, chưa kịp xuất PDF/Ebook. Người dùng hỏi thẳng "có backup/restore không" → xác nhận không có
→ được yêu cầu thêm.

Cách làm: **mỗi lần danh sách trang thay đổi** (thêm/xoá/sắp xếp/đổi file trang, kể cả xoá sạch khi
xuất xong) `ScanSessionManager` tự ghi luôn 1 file JSON nhỏ (`session_state.json`, dùng
`org.json.JSONArray`/`JSONObject` có sẵn trong Android, không thêm thư viện) liệt kê id + đường dẫn
từng trang, vào **bộ nhớ trong thật (`context.filesDir`), không phải cache** — quan trọng vì thư mục
cache có thể bị hệ điều hành tự xoá bất cứ lúc nào để giải phóng dung lượng, ghi backup vào đó thì
coi như không backup. Vì lý do này, `FileUtils.sessionPagesDir()` cũng đổi từ `cacheDir` sang
`filesDir` — CHỈ đổi đúng thư mục này (nơi lưu ảnh trang đã xử lý xong của phiên quét); các thư mục
tạm khác (`capturesDir`, `importedDir` — ảnh thô/ảnh nhập chưa qua xử lý) vẫn ở `cacheDir` như cũ vì
đó chỉ là bước trung gian, dùng xong trong cùng 1 lượt thao tác là xoá, không cần bền.

Khi mở `MainActivity` (`onResume`), nếu bộ nhớ hiện tại KHÔNG có phiên nào đang hoạt động (`pages`
rỗng — nghĩa là process này chưa/không tự có sẵn dữ liệu) NHƯNG có phiên đã lưu trên đĩa còn sót lại
→ hiện hộp thoại hỏi "Phát hiện phiên quét dang dở (N trang) — Tiếp tục hay Xoá?". Chọn Tiếp tục sẽ
nạp lại đúng danh sách đó vào bộ nhớ rồi vào thẳng `PageListActivity`; chọn Xoá sẽ xoá cả file JSON
lẫn các ảnh trang nó trỏ tới. Vì mọi nơi bắt đầu phiên MỚI (chụp/nhập ảnh từ "Quét tài liệu",...) đều
gọi `ScanSessionManager.clear()` trước, và `clear()` cũng tự xoá luôn backup trên đĩa, nên không có
tình trạng hộp thoại này hiện ra sai lúc (chỉ hiện đúng khi thật sự có phiên dang dở bị bỏ lại).

**Giới hạn đã biết** (chưa làm, cân nhắc nếu cần):
- Chỉ áp dụng cho phiên quét (`ScanSessionManager`) đúng như câu hỏi — CHƯA áp dụng cho các luồng
  nhiều bước khác cũng có thể bị mất dở dang tương tự: danh sách file đang chờ ghép trong
  `PdfMergeActivity`, trạng thái đang chỉnh (xoay/chọn/sắp xếp) trong `PdfPageEditorActivity`, hay
  mục lục đang soạn trong `EbookExportActivity`. Nếu cần, làm thêm sau theo đúng khuôn mẫu này.
- Nếu app bị tắt đúng lúc đang ở giữa 1 lần crop (đã mở `CropActivity`, đang kéo 4 góc / chưa bấm
  "Xác nhận") thì đúng trang ĐANG crop dở đó vẫn mất — chỉ những trang đã bấm "Lưu trang" xong mới
  được backup. Chấp nhận được vì chỉ mất tối đa 1 trang thay vì mất cả phiên.
- Chưa test trên thiết bị thật kịch bản "hệ thống tự kill app giữa chừng" (khó giả lập chính xác
  khi không có máy) — logic đọc/ghi JSON thì đơn giản, rủi ro thấp hơn nhiều so với mục 4.11/4.12.

### 4.14 Tự lưu & khôi phục cho 3 luồng còn lại — `PdfEditorState` / `EbookEditorState` / `PdfMergeState`

Mở rộng đúng ý còn tồn đọng đã ghi ở mục 6 bản trước: mục 4.13 khi đó chỉ áp dụng cho phiên quét.
Giờ áp dụng thêm cho `PdfPageEditorActivity`, `EbookExportActivity`, `PdfMergeActivity`, theo đúng
khuôn mẫu JSON-trên-`filesDir` của `ScanSessionManager` (persist mỗi lần state đổi, hỏi khôi phục
khi mở lại màn hình nếu phát hiện có phiên dở). Khác biệt so với bản gốc:

- **Không dùng chung 1 manager** — mỗi màn hình có object riêng (`PdfEditorState`,
  `EbookEditorState`, `PdfMergeState`), vì dữ liệu cần lưu khác hẳn nhau (trang+xoay+chọn / trang+
  đánh dấu chương+tên sách+định dạng / danh sách Uri). Hỏi khôi phục được đặt ngay trong `onCreate`
  của từng Activity đó (không dồn cả 3 hộp thoại vào `MainActivity` như bản gốc làm với phiên quét —
  tránh phải xếp thứ tự ưu tiên khi nhiều phiên dở cùng lúc).
- **Trang render từ PDF nhập vào phải đổi từ cache sang `filesDir` mới backup được** — `PdfImportHelper.
  renderAllPagesToFiles()` trước đây luôn ghi vào `FileUtils.importedDir()` (cache, có thể bị hệ
  thống xoá bất cứ lúc nào — xem mục 2), nên dù có lưu state JSON, đường dẫn trỏ tới cũng có thể đã
  mất. Đã thêm tham số `fileFactory: ((Int) -> File)?` (mặc định `null` → giữ nguyên hành vi cũ cho
  mọi nơi gọi khác — `MainActivity` 3 chỗ, `ConvertDocumentActivity`) để 2 nơi cần bền
  (`PdfPageEditorActivity`, `EbookExportActivity`) tự trỏ sang thư mục riêng của mình dưới `filesDir`
  (`FileUtils.pdfEditorPagesDir()` / `ebookImportDir()`).
- **`EbookEditorState` cố tình KHÔNG lưu văn bản OCR** — chỉ lưu đường dẫn trang + đánh dấu chương +
  tên chương + tên sách + 2 checkbox định dạng. Lý do: OCR lại rẻ (vài chục trang, chạy offline —
  đúng như ghi chú gốc trong `EbookExportActivity`), trong khi văn bản OCR có thể khá dài; lưu lại
  vào JSON chỉ tốn dung lượng không cần thiết. Khi khôi phục: chạy lại OCR trên đúng các trang cũ,
  rồi khớp theo đường dẫn để áp lại đánh dấu chương đã lưu (`applySavedMarksIfMatching()`) — nếu
  đường dẫn không khớp (nguồn trang đã đổi), state cũ bị bỏ qua chứ không báo lỗi, và sẽ tự bị ghi
  đè bởi lần persist tiếp theo của phiên mới.
- **Lưu 1 "mốc" ngay khi vừa có `pagePaths`, trước khi vòng lặp OCR chạy** (`EbookExportActivity.
  runOcrAndShowEditor()`) — vì OCR nhiều trang có thể mất một lúc; không có bước này thì app bị tắt
  đúng lúc đang OCR sẽ không có gì để khôi phục dù các trang nguồn đã nằm sẵn trong thư mục bền.
- **`EbookEditorState.clear()` chỉ xoá file nó THỰC SỰ sở hữu** (so khớp thư mục cha với
  `ebookImportDir()`) — không đụng vào trang thuộc `ScanSessionManager` (khi ebook được soạn từ
  phiên quét đang có, không phải từ PDF nhập riêng). Xoá nhầm sẽ làm hỏng phiên quét đang hoạt động
  của 1 manager khác — xem quyết định 20, mục 5.
- **Dọn cache định kỳ** — `FileUtils.cleanOldCacheFiles()`, gọi 1 lần mỗi khi app khởi động (trên
  thread riêng trong `DocScannerApp.onCreate`, không chặn startup), xoá file cũ hơn 24h trong 3 thư
  mục cache tạm (`captures/`, `imported/`, `temp/`) — đúng việc còn tồn đọng đã ghi ở mục 6 bản
  trước ("File tạm trong cache không bao giờ tự dọn"). **Cố tình KHÔNG đụng tới** `session_pages/`,
  `pdf_editor_pages/`, `ebook_import/` (đều nằm dưới `filesDir`, không phải cache) — dọn nhầm các
  thư mục này sẽ phá luôn tính năng backup/restore vừa thêm.
- **Sửa kèm 1 lỗi UX đã ghi ở mục 6 bản trước**: xoá dòng lịch sử EPUB giờ báo rõ nếu có file
  `.txt` cùng tên (cùng 1 cuốn ebook) sẽ bị xoá theo, thay vì xoá âm thầm — chỉ áp dụng cảnh báo cho
  đúng trường hợp này (EPUB có cặp .txt cùng tên), không đổi hành vi khi xoá PDF (file .txt OCR đi
  kèm PDF vẫn bị xoá âm thầm như cũ vì nó không hiện thành dòng riêng trong lịch sử, không có gì
  "biến mất bất ngờ" trước mắt người dùng).

**Giới hạn đã biết (chưa xử lý, mức rủi ro thấp — chấp nhận được)**:
- `PdfPageEditorActivity`: nếu app bị tắt đúng lúc đang render trang từ PDF vừa chọn (trước khi
  `pages.addAll(...)` + lần persist đầu tiên chạy xong), các file đã render dở nằm trong
  `pdf_editor_pages/` sẽ mồ côi (không bị dọn vì không phải cache, nhưng cũng không có state JSON
  nào trỏ tới để khôi phục) — chỉ mất tối đa 1 lượt chọn file, không mất gì đã lưu trước đó.
- `EbookExportActivity`: mốc lưu sớm (nêu trên) thu hẹp rất nhiều nhưng không xoá hết cửa sổ rủi ro
  — nếu app bị tắt đúng giữa lúc ghi xong mốc đó nhưng trước khi ghi xong lần đầu, về lý thuyết vẫn
  có thể lệch; xác suất cực thấp, chưa test thật (cùng nhóm rủi ro "chưa build-test" ở mục 0/9).
- `PdfMergeState`: chỉ lưu Uri, không lưu file cục bộ nào — không có nguy cơ mồ côi file.

### 4.15 Luồng "Dự án" (Project) — quy trình tuyến tính bắt buộc 8 bước

Tính năng LỚN NHẤT trong dự án tính đến giờ (xem mục 0, mục 1 ý 12). Trước đây app chỉ có các
**công cụ độc lập** (Quét, Ghép PDF, Quản lý trang, Nén PDF, Tạo Ebook, Chuyển đổi định dạng) —
không công cụ nào nối với công cụ nào, người dùng tự làm xong 1 việc rồi tự vào công cụ khác chọn
lại file. Mục này thêm một lớp mới bên trên: **"Dự án"** — 1 thực thể duy nhất đi xuyên suốt cả 8
bước, KHÔNG được bỏ bước nào, nhưng KHÔNG xoá bất kỳ công cụ độc lập nào đã có (chúng vẫn nguyên
100%, giờ nằm dưới tiêu đề "Hoặc dùng riêng từng công cụ" trong `MainActivity`).

**Bấm vào đâu**: thẻ "Dự án quét sách" — giờ là thẻ ĐẦU TIÊN, kiểu highlight (nền xanh) mà trước đây
thuộc về thẻ "Quét" (thẻ "Quét" bị hạ xuống thành thẻ thường, xem quyết định 26 ở mục 5).

**8 bước, đúng thứ tự người dùng mô tả, không thể nhảy cóc** (mỗi `Project.stage` chỉ tiến, không
lùi; `ProjectFlow.open()` luôn mở đúng Activity khớp với `stage` hiện tại — dùng chung cho cả "mở
tiếp dự án dở" lẫn "vừa xong 1 bước, sang bước kế"):

1. **Tạo dự án** — không phải 1 màn hình riêng, chỉ là bấm "+ Dự án mới" ở `ProjectHubActivity` →
   `ProjectManager.createProject()` sinh `id` theo timestamp + tên mặc định "Dự án dd/MM HH:mm" →
   lưu JSON rỗng → mở luôn `ProjectPickImagesActivity`.
2. **Chọn ảnh** (`ProjectPickImagesActivity`) — ĐÚNG 2 lựa chọn như mô tả (camera hoặc thư viện,
   không có lựa chọn thứ 3 "nhập từ PDF" như công cụ Quét độc lập, vì 1 dự án được hiểu là bắt đầu
   từ ảnh chụp sách thật). Thư viện dùng `PickMultipleVisualMedia(20)` (đa chọn thật, tối đa
   20 ảnh/lần, giống hệt cơ chế đã có ở `MainActivity`). Camera: xem ý dưới.
3. **Chỉnh sửa ảnh** (`ProjectEditActivity`) — crop (tự phát hiện 4 góc) + tách trang đôi (tự gợi ý
   vị trí gáy sách), dùng LẠI NGUYÊN `CropOverlayView`/`SplitLineOverlayView` và các heuristic
   `detectDocumentCorners`/`detectGutterX` đã có — nhưng KHÔNG có bước chọn bộ lọc như
   `CropActivity` gốc, vì lọc ảnh giờ là 1 bước riêng, bắt buộc, ngay sau đây.
4. **Chọn kiểu quét** (`ProjectScanActivity`) — MỚI, chưa từng có dưới dạng 1 bước độc lập trước
   đây. Dùng lại đúng các preset đã có ở "Lọc hàng loạt" của `PageListActivity` (7 lúc đó, 9 từ phiên 16) (đã tách ra
   `ScanPresetApplier`, quyết định 23), NHƯNG bước này BẮT BUỘC: nút "Tiếp tục" chỉ bật sau khi
   người dùng đã chọn và áp dụng xong 1 preset (mặc định gợi ý "Tự động" giống công cụ gốc).
5. **Xuất PDF, có mục lục** (`ProjectExportPdfActivity`) — MỤC LỤC LÀ TÍNH NĂNG MỚI HOÀN TOÀN, xem
   phần riêng "TocDetector" bên dưới. Việc TẠO mục lục là tuỳ chọn (bật/tắt bằng 1 công tắc, đúng ý
   "có lựa chọn tạo mục lục" trong yêu cầu gốc) nhưng bước XUẤT PDF thì bắt buộc.
6. **Nén PDF** (`ProjectCompressActivity`) — dùng lại `PdfCompressor` đã có, nhưng KHÁC công cụ độc
   lập ở chỗ: công cụ độc lập phải render lại ảnh từ 1 PDF có sẵn (không có ảnh gốc), còn ở đây dự
   án vẫn giữ nguyên ảnh gốc trong `pages` nên nén thẳng từ đó, không phải render lại. Nếu bước 5 có
   mục lục, mục lục đó được GHI LẠI vào bản nén (xem quyết định 21 — nén tạo file hoàn toàn mới nên
   không thể "giữ" mục lục cũ, phải ghi lại).
7. **OCR** (`ProjectOcrActivity`) — bắt buộc, không có gì để người dùng chọn (OCR không có preset),
   tự chạy ngay khi vào màn hình, ra `.txt` đúng định dạng `--- Trang N ---` như công cụ Xuất PDF
   độc lập đã dùng (để nhất quán).
8. **Tạo ebook** (`ProjectEbookActivity`, bước cuối) — dùng lại NGUYÊN layout
   `activity_ebook_editor.xml`/`ActivityEbookEditorBinding` và `EbookPageAdapter` của công cụ độc
   lập `EbookExportActivity` (2 Activity khác nhau, CÙNG 1 file layout — ViewBinding không buộc
   1-layout-1-Activity, xem quyết định 24). Khác biệt duy nhất: đánh dấu chương được ĐIỀN SẴN từ
   mục lục đã duyệt ở bước 5 (khớp theo chỉ số trang), người dùng chỉ cần soát lại thay vì đánh dấu
   từ đầu — tận dụng lại đúng công sức người dùng đã bỏ ra, không bắt làm 2 lần.

Sau bước 8, `stage` chuyển `DONE`, `ProjectFlow` mở `ProjectSummaryActivity` — liệt kê MỌI file
thành phẩm đã ra trong suốt 8 bước (PDF gốc, PDF đã nén, `.txt` OCR, EPUB/TXT ebook), mỗi file có
thể mở/chia sẻ/xoá độc lập — đúng ý "cũng có file thành phẩm ngay chỗ thoát ra nếu người dùng chỉ
muốn dùng file ở bước đó thôi": người dùng có thể dừng lại ở bất kỳ bước nào và vẫn dùng được file
của (các) bước đã xong, không bắt buộc phải đi hết cả 8 bước mới có thứ gì đó dùng được.

**Chế độ "dự án" trong `CaptureActivity`**: thay vì viết 1 màn hình camera mới (trùng lặp toàn bộ
CameraX/preview/flash đã có), `CaptureActivity` được thêm 1 nhánh rẽ theo `ProjectFlow.EXTRA_
PROJECT_ID` có mặt trong Intent hay không — có thì mỗi tấm chụp được lưu thẳng vào
`Project.pendingRawPaths` (không qua `CropActivity`, vì crop là bước 3 riêng), không có thì giữ
NGUYÊN luồng cũ (chụp → `CropActivity` ngay → lặp lại). Hành vi cũ (không có project id) không đổi
1 dòng nào.

**Lưu trạng thái ở mức nào**: mỗi `Project` là 1 file JSON (`filesDir/projects/<id>/project.json`,
`ProjectManager`), lưu lại sau MỌI thay đổi có ý nghĩa (chọn xong ảnh, crop xong 1 trang, áp preset
xong, xuất PDF xong...) — không đợi xong cả bước mới lưu 1 lần, để khớp đúng yêu cầu "thoát bất kỳ
lúc nào cũng lưu, mở lại đúng chỗ": ví dụ đang crop dở trang 5/12, tắt app, mở lại dự án sẽ vào
thẳng `ProjectEditActivity` và tiếp tục đúng trang 5 (12-5=7 trang còn lại vẫn nằm nguyên trong
`pendingRawPaths` vì phần tử đầu chỉ bị `removeAt(0)` NGAY LÚC bắt đầu tải nó, không phải lúc xác
nhận xong — xem comment trong chính `ProjectEditActivity.loadNext()`).

**`TocDetector` — dò mục lục tự động (tính năng hoàn toàn mới, CHƯA từng có ở đâu khác trong app)**:
- Cách làm: OCR (phẳng, `OcrHelper.recognize`) tối đa 20 trang đầu (mục lục sách gần như luôn nằm ở
  đầu sách), tìm trang có nhiều dòng khớp mẫu `"<tên chương> <dấu chấm/khoảng trắng> <số trang>"`
  (regex `^(.{2,80}?)[\s.]{2,}(\d{1,4})\s*$` theo từng dòng) HOẶC có từ khoá "MỤC LỤC"/"CONTENTS",
  lấy trang khớp nhiều dòng nhất.
- **GIỚI HẠN QUAN TRỌNG, đọc kỹ trước khi coi đây là tính năng "chính xác"**: số trang lấy được từ
  mục lục là số trang IN TRÊN SÁCH, hầu như KHÔNG BAO GIỜ trùng với chỉ số trang quét thực tế (sách
  luôn có bìa/trang tên sách/trang bản quyền ở đầu, làm lệch số). `TocDetector` KHÔNG cố đoán độ
  lệch này (không OCR số trang in trên từng ảnh để đối chiếu — cân nhắc rồi bỏ, xem mục 8) — chỉ
  đơn giản CHIA ĐỀU các mục đã dò được ra khắp các trang còn lại làm điểm khởi đầu. Đây là lý do
  `ProjectExportPdfActivity` LUÔN bắt người dùng duyệt/sửa lại (`TocEntryAdapter`, có nút +/- chỉnh
  từng trang) trước khi xuất — phần thật sự đáng tự động hoá là TÊN chương (gõ tay rất mất công),
  không phải vị trí trang (chỉnh vài lần bấm là xong). Không được coi nhẹ bước duyệt này khi test.
- Chỉ hoạt động tốt với mục lục có "leader" (chấm/khoảng trắng) rõ ràng trước số trang — mục lục
  trình bày khác kiểu (ví dụ số trang ở đầu dòng, hoặc dùng bảng thật) nhiều khả năng không khớp
  được regex, khi đó trả về danh sách rỗng và màn hình hiện nút "Thêm mục" để tự thêm tay.

**Đã tái cấu trúc nhẹ 1 vài chỗ code CŨ để dùng chung với luồng Dự án** (không đổi hành vi của công
cụ độc lập tương ứng — xem quyết định 23, 25 ở mục 5 để biết lý do từng chỗ):
- `PageListActivity`: enum `BulkPreset` riêng + 2 hàm `einkTextResult`/`einkColorResult` riêng được
  chuyển thành `ScanPresetApplier` (dùng chung với `ProjectScanActivity`). Hành vi/chuỗi hiển thị
  giữ nguyên 100%.
- `PdfImportHelper.renderAllPagesToFiles()`: thêm tham số `fileFactory` (mục 4.14, dùng lại được
  cho luồng Dự án nếu sau này cần nhập PDF vào 1 dự án — hiện tại Dự án chỉ nhận ảnh, không dùng
  đường này).
- `PdfExporter.exportImagePaths()`: thêm 2 tham số tuỳ chọn `chapterTitles`/`chapterStartPageIndex`
  (mặc định rỗng → hành vi cũ không đổi) để gắn bookmark thật qua `PdfBookmarkInjector`.
- `PdfCompressor.compress()`: thêm 2 tham số tương tự, nhưng KHÔNG dùng `PdfBookmarkInjector` (viết
  thẳng object Outline cùng lúc với các trang, xem quyết định 21).
- `FileUtils`: thêm nhóm hàm thư mục cho Project (`projectsRootDir`/`projectDir`/`projectRawDir`/
  `projectPagesDir`/...), và `openFile`/`shareFile` dùng chung (tách từ logic đã có sẵn trong
  `MainActivity`, KHÔNG sửa `MainActivity.shareFile` gốc — xem quyết định 25).

**Giới hạn đã biết của riêng luồng Dự án (chưa xử lý, mức độ chấp nhận được — không chặn dùng
được, chỉ là chưa hoàn hảo)**:
- [x] ~~`ProjectEbookActivity` (bước 8) KHÔNG có backup/restore ở mức "đang gõ dở" như
  `EbookEditorState` làm cho công cụ độc lập — nếu app bị tắt đúng lúc đang soát lại tên chương ở
  bước này (sau khi OCR xong), mở lại dự án sẽ OCR lại từ đầu VÀ áp lại đúng mục lục gốc từ bước 5
  (không mất mục lục, chỉ mất các chỉnh sửa THỦ CÔNG thêm vào lúc soát ở bước 8 nếu có). Chấp nhận
  được vì đây là bước cuối, thời gian ở lại bước này thường ngắn.~~ — **đã làm ở phiên thứ 4**: file
  mới `model/ProjectEbookEditorState.kt`, đúng khuôn mẫu `EbookEditorState` nhưng lưu riêng theo
  từng dự án (trong `FileUtils.projectDir(id)`, không phải 1 slot chung) vì nhiều dự án có thể đang
  dang dở bước này ở nhiều thời điểm. `runOcrAndShowEditor()` giờ lưu 1 điểm khôi phục CƠ SỞ (marks
  suy từ mục lục bước 5) ngay trước khi vòng lặp OCR bắt đầu — cùng lý do phòng thủ như
  `EbookExportActivity` bản gốc (OCR nhiều trang có thể mất thời gian) — rồi sau khi OCR xong, áp
  lại trạng thái đã lưu (nếu khớp đúng danh sách trang) đè lên marks suy từ mục lục, và lưu lại mỗi
  khi người dùng sửa tay (qua `onChanged` của `EbookPageAdapter`, `TextWatcher` của ô tên sách, và
  2 checkbox định dạng — same wiring như bản gốc). Dọn file trạng thái này sau khi xuất ebook thành
  công (`ProjectEbookEditorState.clear()`), không cần dọn riêng khi xoá cả dự án vì file này nằm
  trong đúng thư mục dự án, `ProjectManager.delete()` đã xoá đệ quy cả thư mục rồi. KHÔNG hiện hộp
  thoại "khôi phục hay làm lại" như công cụ độc lập vì trang nguồn 1 Dự án luôn cố định
  (`Project.pages`) — có trạng thái khớp là áp dụng luôn, không có gì mơ hồ cần hỏi. Xem mục 0/3/6/9.
  Vẫn **chưa test thật** (cùng hạn chế môi trường).
- Toàn bộ 9 màn hình MỚI chưa được xem qua giao diện thật (đang ở môi trường không có Android
  SDK/máy ảo) — rủi ro lệch layout (chồng chéo, tràn chữ, nút bị che) cao hơn các phần cũ đã tồn tại
  lâu, dù đã rà soát tĩnh kỹ (mục 9).
- `TocDetector` chưa test với ảnh mục lục thật nào — hoàn toàn dựa trên suy luận về cấu trúc OCR
  text, có thể cần chỉnh regex sau khi thấy vài ví dụ thật.

### 4.16. "Chú thích PDF" - vẽ tay/chữ/che lên trang (phiên làm việc thứ 7)

Tính năng "chỉnh sửa trực tiếp nội dung PDF" — người dùng được hỏi rõ trước khi làm (xem mục 0) vì
cụm này có thể hiểu theo 2 hướng rất khác nhau: (a) đánh dấu/chú thích lên trang (không đổi nội
dung gốc), hoặc (b) sửa lại đúng câu chữ đã có sẵn trong PDF như Word (đổi thẳng nội dung gốc, khó
và rủi ro hơn nhiều). Người dùng chọn làm CẢ HAI nhưng ưu tiên (a) trước — phiên này chỉ làm (a).
Phần (b) xem mục 6 để biết vì sao chưa làm và cần bàn gì trước khi bắt đầu.

**`AnnotationCanvasView` (custom View, `view/`)** — hiển thị 1 bitmap trang + vẽ đè lên trên 3 loại
"phần tử": nét vẽ tay (`Stroke`), chữ đặt tự do (`TextStamp`), hình chữ nhật che đặc (`Redact`,
mặc định trắng). Điểm quan trọng nhất về mặt kỹ thuật: MỌI phần tử được lưu ở toạ độ KHÔNG GIAN
BITMAP GỐC (không phải toạ độ màn hình) ngay từ lúc chạm tay vào màn hình — quy đổi qua lại bằng 1
cặp `Matrix` (thuận: bitmap→view để hiển thị preview đúng tỉ lệ fit-center; nghịch: view→bitmap để
đổi điểm chạm) — cùng đúng kỹ thuật `CropOverlayView`/`SplitLineOverlayView` đã dùng trước đó cho
việc kéo góc crop/kéo đường tách trang. Nhờ vậy, `onDraw()` (xem trước trên màn hình, độ phân giải
thấp) và `flatten()` (làm phẳng ra file thật, độ phân giải gốc đầy đủ, có thể cao hơn màn hình rất
nhiều lần) dùng chung ĐÚNG 1 đoạn code vẽ phần tử, không có 2 đường tính toán riêng dễ lệch nhau —
những gì thấy trên màn hình chính là những gì ra file, không phải một bản xấp xỉ của nó. Độ dày nét
vẽ/cỡ chữ cũng định nghĩa theo tỉ lệ % chiều rộng bitmap (không phải số px cố định) nên tự động phù
hợp dù trang có độ phân giải bao nhiêu.

**"Làm phẳng" (flatten), không phải object chú thích PDF thật**: kết quả cuối là bitmap trang GỐC +
mọi phần tử được "nướng" (bake) trực tiếp vào từng pixel, ghi đè thành ảnh JPEG mới — KHÔNG phải
tạo ra các object `/Annots` (Text/Ink/Square...) thật sự trong cấu trúc PDF mà 1 trình đọc PDF có
thể ẩn/hiện/xoá lại độc lập với nội dung trang. Đây là lựa chọn CHỦ ĐÍCH, khớp đúng kiến trúc "mọi
PDF trong app này đều là ảnh" đã dùng xuyên suốt từ `PdfExporter`/`PdfCompressor` tới giờ — không
phải giới hạn kỹ thuật tình cờ.

**`PdfAnnotateActivity`** — 1 màn hình, 2 chế độ chọn qua Intent extra, dùng chung toàn bộ UI/logic:
- **Chế độ PDF ngoài** (không có extra nào, hoặc mở từ thẻ công cụ "Chú thích PDF" ở màn hình
  chính): tự bật picker chọn file PDF ngay khi `onCreate`, render mọi trang qua `PdfImportHelper`
  (dùng lại nguyên hàm đã có, không viết lại) ở 200dpi vào thư mục làm việc RIÊNG
  `FileUtils.annotatePagesDir` (mới thêm, tách khỏi `pdfEditorPagesDir` đã có vì là tool khác nhau).
  Lúc Lưu, ghi PDF mới bằng `PdfExporter.exportImagePaths()` — hàm NÀY ĐÃ CÓ SẴN TỪ TRƯỚC (dùng cho
  `PdfPageEditorActivity`), không cần viết thêm gì để xuất PDF từ danh sách ảnh.
- **Chế độ 1 trang trong phiên quét** (mở từ nút mới trên từng trang ở `PageListActivity`, qua
  Intent extra `EXTRA_IMAGE_PATH` + `EXTRA_SESSION_PAGE_INDEX`): chú thích đúng 1 ảnh, Lưu xong gọi
  `ScanSessionManager.replaceFile(index, path)` — CÙNG CÁCH `CropActivity` vẫn dùng để trả trang đã
  cắt/lọc lại cho phiên quét, không phát minh đường mới.
- **"Làm phẳng theo từng trang khi rời trang"**: với PDF nhiều trang, mỗi khi chuyển trang (Trước/
  Sau) hoặc bấm Lưu, trang ĐANG XEM được làm phẳng và ghi đè ngay vào đúng file của nó trên đĩa —
  không giữ toàn bộ lịch sử chỉnh sửa của MỌI trang trong RAM cùng lúc. Đánh đổi: rời khỏi 1 trang
  rồi thì không hoàn tác được nét vẽ đã thêm vào trang đó nữa (chỉ hoàn tác được trang ĐANG xem) —
  chấp nhận được, tránh được việc giữ trạng thái phức tạp nhiều trang cùng lúc.

**2 lỗi tự tìm ra bằng cách đọc lại tay** (không có công cụ nào trong mục 9 bắt được, vì cả 2 đều là
lỗi về hành vi lúc chạy — rò bộ nhớ và rác file — không phải lỗi cú pháp/tham chiếu tĩnh):
1. `AnnotationCanvasView.loadPage()` không giải phóng bitmap trang CŨ trước khi nhận bitmap MỚI —
   với 1 PDF nhiều chục trang, chuyển hết trang này sang trang khác sẽ giữ TẤT CẢ bitmap cũ trong bộ
   nhớ (không ai còn tham chiếu tới nhưng chưa được `recycle()` chủ động, chỉ chờ GC dọn tình cờ) —
   rủi ro hết bộ nhớ thật với phiên chú thích dài. Đã sửa.
2. Thư mục làm việc `annotatePagesDir` (chế độ PDF ngoài) không được dọn khi người dùng huỷ (thoát
   không lưu) hoặc xuất xong — file JPEG trung gian tích luỹ dần qua nhiều lần mở tool, không bao
   giờ tự mất. Đã sửa: dọn sạch thư mục này ở cả 2 thời điểm (xuất xong, xác nhận huỷ).

**Giới hạn đã biết, nói thẳng không né**:
- **Chưa có backup/restore qua chết tiến trình** — khác với `PdfPageEditorActivity`/
  `EbookExportActivity`/`ProjectEbookActivity` (đều theo khuôn mẫu `model.*State`, lưu JSON, tự
  khôi phục khi mở lại), tool này chỉ có 1 hộp thoại xác nhận "Bỏ các chú thích chưa lưu ở trang này
  và thoát?" khi bấm Back mà đang có gì chưa lưu — nếu app bị hệ điều hành giết ngầm (không phải
  người dùng tự thoát) giữa lúc chú thích dở PDF nhiều trang, mất hết các trang CHƯA làm phẳng (các
  trang ĐÃ làm phẳng, tức đã rời qua, vẫn còn nguyên trên đĩa vì được ghi ngay lúc rời trang — chỉ
  mất trang hiện đang xem). Cố tình chấp nhận cho bản đầu tiên (đã ghi thẳng ở đây, không giấu) vì
  đây không phải quy trình nhiều bước phức tạp như soạn ebook — làm lại vài nét vẽ ít tốn công hơn
  nhiều so với làm lại OCR/mục lục. Nếu cần làm đúng chuẩn, theo ĐÚNG khuôn mẫu `PdfEditorState`/
  `EbookEditorState` đã có sẵn, không cần phát minh cách mới.
- **Chưa test trên máy thật lần nào** (như mọi phần khác của dự án — mục 0/9) — nhưng RỦI RO Ở ĐÂY
  CAO HƠN các tool thuần logic khác: đây là tool DUY NHẤT có custom View xử lý cảm ứng + Matrix quy
  đổi toạ độ MỚI viết (không phải chỉnh sửa `CropOverlayView` có sẵn), nên khả năng "đúng trên giấy
  nhưng lệch/vỡ nét khi chạm tay thật" cao hơn hẳn — ưu tiên test tay kỹ tool này trước các phần
  khác nếu build được (mục 10).
- Cỡ nét vẽ/màu chỉ có 3 mức cố định (nhỏ/vừa/lớn) và 4 màu cố định (đen/đỏ/xanh dương/vàng dạ
  quang) — không có bánh xe chọn màu tự do hay điều chỉnh cỡ liên tục. Chấp nhận được cho bản đầu.
- Chữ chèn vào chỉ 1 dòng đơn giản (`Canvas.drawText`, không tự xuống dòng nếu dài) — gõ đoạn dài sẽ
  tràn ra ngoài lề thay vì tự ngắt dòng. Chưa xử lý.
- Không có công cụ tẩy RIÊNG (eraser) — muốn xoá 1 nét vẽ chỉ có cách Hoàn tác (undo) lần lượt từ
  nét mới nhất, không xoá được 1 nét cụ thể ở giữa nếu đã vẽ thêm nét khác sau đó.

### 4.17. "Sửa chữ PDF" - tìm/thay object chữ thật, không rasterize (phiên làm việc thứ 8; **engine đã đổi từ iText sang PdfBox ở phiên 11 — xem 4.18**)

**ĐỌC MỤC NÀY TRƯỚC KHI SỬA `PdfCanvasEditor.kt`/`PdfTextEditor.kt`.** Đây là tính năng khác biệt
nhất và rủi ro cao nhất trong toàn bộ dự án — mọi tool PDF khác (kể cả `PdfObjectRecompressor`) đều
theo kiến trúc raster (trang luôn là ảnh); đây là tool DUY NHẤT ghi trực tiếp vào object CHỮ THẬT
của 1 PDF có sẵn. Xem mục 0 (phiên thứ 8) để biết quá trình quyết định phạm vi trước khi làm — người
dùng đã được hỏi rõ và chọn "thử làm đúng nghĩa" thay vì hướng an toàn hơn.

**Cơ chế đọc — `PdfTextEditor.extractChunks()` (viết lại hoàn toàn ở phiên thứ 10)**: bản đầu dùng
`PdfCanvasProcessor` + lắng nghe sự kiện `TextRenderInfo` của iText (1 sự kiện MỖI CHUỖI — kể cả từng
phần tử chuỗi trong mảng `TJ`); phiên thứ 10 bỏ hẳn cách này. Giờ ĐỌC dùng CHÍNH `PdfCanvasEditor`
(cùng lớp mà bước GHI dùng — xem bên dưới), qua `walkTextOperators()`: 1 hàm duyệt CHỈ ĐỌC (gọi
`editContent()` — không phải `editPage()`, vì `editPage()` gán lại `/Contents` của trang dù mọi
operator được ghi lại y nguyên, không nên xảy ra chỉ để ĐỌC) với 1 `PdfCanvas` bỏ đi làm đích ghi giả.
Mỗi operator hiện chữ (`Tj`/`'`/`"`/`TJ`) là **đúng 1 `TextChunk`** — với `TJ`, nối chữ của MỌI phần
tử chuỗi trong mảng (`decodeOperatorText()`, bỏ qua các số kerning) thành 1 chuỗi duy nhất, dù mảng có
bao nhiêu mảnh. Việc nhóm này **KHÔNG phải heuristic đoán** — các mảnh chuỗi trong cùng 1 mảng `TJ`
là phần tử CỦA CÙNG 1 MẢNG, trong cùng 1 lệnh, đó là sự thật cấu trúc đọc thẳng từ PDF, không có gì mơ
hồ (khác với việc nhóm chữ GIỮA 2 operator khác nhau, cái đó mới cần đoán và vẫn không làm — xem "Giới
hạn đã biết"). Chữ giải mã qua `PdfFont.decode(PdfString)` (đã xác nhận có thật qua tra cứu). Mỗi
operator được đánh số (`TextChunk.index`) theo thứ tự xuất hiện, tính CẢ operator cho ra chữ trắng
(chỉ không đưa vào danh sách hiện cho người dùng) — số này quan trọng vì bước ghi tìm lại ĐÚNG operator
qua số này, không qua nội dung chữ (nội dung có thể trùng nhau ở nhiều chỗ trên trang). Độ rộng gốc
(`TextChunk.widthPt`) tính bằng `PdfFont.getWidth(text, size)` — xấp xỉ, KHÔNG tính chính xác khoảng
kerning giữa các mảnh của `TJ` nhiều mảnh — chấp nhận được vì kerning thường chỉ vài % tổng độ rộng,
và ngưỡng co giãn 40%-250% (bên dưới) đủ rộng để hấp thụ sai lệch nhỏ đó; nếu sai lệch đủ lớn để vượt
ngưỡng thì bị từ chối đúng như thiết kế, không ra kết quả sai âm thầm.

**Cơ chế ghi — `PdfCanvasEditor` + `PdfTextEditor.applyEdit()`**: `PdfCanvasEditor.kt` là bản port
Kotlin gần NGUYÊN VĂN 1 class thật, đã đọc trọn vẹn từ
`github.com/mkl-public/testarea-itext7/.../PdfCanvasEditor.java` (không suy đoán từ đoạn trích) —
tác giả `mkl` là người trả lời câu hỏi StackOverflow về content-stream iText nhiều nhất, dùng đúng
class này cho các ví dụ thật (xoá chữ theo tên font, đổi màu chữ, xoá dòng theo vị trí). Cách hoạt
động: bọc MỌI operator PDF (không riêng operator chữ) qua `registerContentOperator`, mặc định ghi
lại NGUYÊN VẸN qua chính bộ serialize object của iText (`PdfOutputStream.write(PdfObject)`) — nghĩa
là gần như toàn bộ nội dung file (đường vẽ, tô màu, ảnh, đổi trạng thái đồ hoạ...) KHÔNG BAO GIỜ bị
app này diễn giải lại, chỉ đúng phần operator bị `write()` override (chữ) mới có khả năng đổi. Đây
là lý do chọn cách này thay vì tự viết 1 trình tokenize/serialize content stream PDF từ đầu — phần
khó nhất (hiểu đúng MỌI loại operator PDF hợp lệ) vẫn hoàn toàn do iText lo.

`PdfTextEditor.applyEdit()` chỉ can thiệp khi gặp ĐÚNG operator ở ĐÚNG số thứ tự đã xác định lúc đọc.
**Vì ĐỌC và GHI giờ đều duyệt qua CÙNG 1 lớp `PdfCanvasEditor` (phiên thứ 10 — xem mục 0), chỉ còn
ĐÚNG 1 chỗ quyết định "cái gì tính là 1 operator, theo thứ tự nào" — không thể lệch bộ đếm giữa đọc và
ghi được nữa, kể cả với trang có Form XObject chứa chữ (`PdfCanvasEditor` vốn KHÔNG BAO GIỜ gọi thật
operator `Do` cho cả 2 đường, nên chữ trong Form XObject không bao giờ được đếm ở đâu cả). Đây là cách
sửa TẬN GỐC cả 1 loại lỗi (2 đường duyệt lệch nhau), thay cho cách vá riêng cho Form XObject của phiên
thứ 9 (`newProcessor()` + `IXObjectDoHandler` rỗng — ĐÃ BỊ XOÁ, không còn cần). Xem mục 0 (phiên thứ 9
và 10) để biết lịch sử đầy đủ của lỗi này.** Với operator `TJ` nhiều mảnh, **thay CẢ MẢNG bằng 1 mảng
mới chỉ có 1 chuỗi** (bỏ hết số kerning cũ — chúng được canh riêng cho đúng ký tự của chữ CŨ, không có ý
nghĩa gì với chữ mới khác; `[(chữ mới)] TJ` hợp lệ y hệt `(chữ mới) Tj`). Trước khi ghi, LUÔN kiểm tra 2
điều, **từ chối (không đổi gì) thay vì đoán** nếu không đạt:
1. **Mọi ký tự của chữ mới phải có sẵn trong đúng font đó** (`PdfFont.containsGlyph(Int)`) — font
   nhúng sẵn trong 1 PDF thật hầu hết bị "subset" (chỉ chứa đúng ký tự tài liệu gốc đã dùng), không
   có cách nào đáng tin để tự thêm 1 glyph mới vào font đã nhúng từ trong app này.
2. **Độ co giãn ngang cần dùng để chữ mới vừa đúng độ rộng chữ cũ phải nằm trong 40%-250%** — nếu
   ngoài khoảng này, từ chối thay vì tạo ra chữ bị nén/giãn tới mức không đọc được.

Cả 2 điều kiện này BIẾN NHỮNG GÌ KHÔNG KIỂM CHỨNG ĐƯỢC (font có đúng ký tự không, chữ có bị méo
không) thành nhị phân: hoặc chắc chắn an toàn theo đúng phép tính, hoặc từ chối rõ ràng — không có
trạng thái "chắc là ổn" ở giữa.

**Cơ chế co giãn cho vừa khung (`Tz` — horizontal scaling)**: thay vì thử làm reflow (không làm —
xem mục 6 để biết lý do phạm vi bị giới hạn ở đây), operator đã sửa được bọc trong 1 khối `q ... Tz
... Q` RIÊNG, độc lập — không cần dò/nhớ/khôi phục đúng giá trị `Tz` đang có trước đó ở vị trí này
(theo đúng chuẩn PDF ISO 32000, `q`/`Q` tự lưu/khôi phục TOÀN BỘ text state, `Tz` nằm trong đó), nên
phần TRƯỚC và SAU đoạn sửa không bao giờ bị ảnh hưởng, bất kể `Tz` gốc ở đó là gì. Vì tỉ lệ co giãn
được TÍNH CHÍNH XÁC sao cho độ rộng render ra khớp đúng độ rộng gốc (đo lúc đọc, không đo lại lúc
ghi — tránh trường hợp `Tz` gốc đã khác 100% làm sai tỉ lệ nếu đo lại bằng `PdfFont.getWidth()` đơn
thuần, vốn không tính `Tz`/CTM đang áp dụng), vị trí con trỏ chữ NGAY SAU khi hiện xong chữ mới cũng
khớp gần đúng vị trí gốc — đây là lý do chữ tiếp theo cùng dòng (nếu hiện bằng 1 lệnh Tj/TJ khác
không định vị lại) vẫn đứng đúng chỗ dù đoạn ngay trước nó vừa bị thay.

**`PdfTextEditActivity`**: chọn PDF ngoài → mở `PdfDocument(PdfReader, PdfWriter)` (stamping) → GIỮ
MỞ SUỐT CẢ PHIÊN làm việc (đúng cách `PdfObjectRecompressor` giữ mở xuyên suốt nhiều ảnh trước khi
đóng đúng 1 lần) → mỗi trang hiện danh sách đoạn chữ tìm được (RecyclerView, không phải danh sách cố
định vài mục như `CompressOptionsDialog` — 1 trang có thể có rất nhiều đoạn) → chạm 1 đoạn, sửa
trong hộp thoại, áp dụng ngay lên `PdfDocument` đang mở → Lưu đóng lại `PdfDocument` (iText tự hoàn
thiện toàn bộ file). Sau MỖI lần sửa thành công, danh sách đoạn chữ của trang đó được ĐỌC LẠI từ đầu
(không tự cập nhật list cũ) — vì nội dung/vị trí trang vừa đổi, an toàn hơn là tự suy luận list mới.

**1 lỗi thật tự tìm ra — nhờ ĐÚNG cách rà số tham số ở mục 9, không phải đọc tay lần này**: hàm nội
bộ `trySubstituteAndWrite` được gọi kèm 1 lambda cuối (`{ ... }`) ở cả 2 chỗ gọi (Tj và TJ), nhưng
khai báo hàm lại THIẾU hẳn tham số callback đó — lẽ ra sẽ không biên dịch được (`substitute()`
không tồn tại trong thân hàm). Cách rà "đếm số tham số truyền vào kể cả lambda cuối, so với số tham
số khai báo" bắt được NGAY (báo lệch 6 tham số truyền vs 5 khai báo) — không thuộc 2 loại báo động
giả đã biết (`finish`/`write`), nên được kiểm tra tay kỹ, xác nhận đúng là lỗi thật, và sửa (thêm
tham số `substitute: () -> Unit`). Đây là bằng chứng cụ thể cho việc mục 9 khuyên "chạy lại cách rà
này mỗi khi sửa xong 1 đợt code" — không phải hình thức.

**Mức độ tin cậy của các API iText đã dùng, nói thẳng để phiên sau biết chỗ nào chưa xác minh kỹ**:

| API | Đã tra cứu/đọc mã nguồn thật trong phiên này? |
|---|---|
| `PdfFont.containsGlyph(Int)`, `.convertToBytes(String)`, `.getWidth(String, Float)` | Có — tìm thấy trực tiếp qua tra cứu |
| `TextRenderInfo.getText()`, `.getBaseline()`, `.getFontSize()` | Có |
| Toàn bộ cơ chế `PdfCanvasEditor` (`registerContentOperator`, `write()`, `nextOperation()`) | Có — đọc trọn vẹn 2 file nguồn thật |
| `PdfCanvasProcessor.registerXObjectDoHandler`, `IXObjectDoHandler.handleXObject` (4 tham số) | Có — thêm ở phiên thứ 9, đọc cả mã nguồn thật `FormXObjectDoHandler` của chính iText lẫn javadoc bản 7.2.5 |
| `TextRenderInfo.getFont()` | Không — dựa hiểu biết chung, tin cậy cao nhưng chưa tra riêng |
| `PdfArray.get/set/size` | Không — dựa hiểu biết chung (quy ước đặt tên rất chuẩn cho kiểu list-like) |
| `PdfNumber(Double)` | Không — dựa hiểu biết chung |

Nếu build lỗi đúng vào 1 trong 3 dòng cuối, đây là chỗ đầu tiên nên nghi ngờ và tra cứu lại.

**Giới hạn đã biết, nói thẳng không né** (đầy đủ hơn trong chính doc comment của `PdfTextEditor.kt`):
- Không sửa được chữ nằm trong Form XObject/pattern/annotation lồng bên trong trang — **cập nhật phiên
  thứ 9 rồi 10**: từng bị mô tả nhầm là "chỉ thiếu tính năng"; thực ra khi ĐỌC và GHI dùng 2 cơ chế
  duyệt khác nhau (bản cũ), giới hạn này gây ra 1 LỖI THẬT (lệch bộ đếm giữa đọc/ghi khi trang có Form
  XObject chứa chữ — xem mục 0). Đã sửa TẬN GỐC ở phiên thứ 10 bằng cách cho cả ĐỌC lẫn GHI cùng đi
  qua 1 lớp duy nhất (`PdfCanvasEditor`, vốn không bao giờ gọi thật `Do`). Giới hạn "không sửa được
  chữ trong Form XObject" bản thân VẪN ĐÚNG — giờ là hành vi chủ đích, an toàn, nhất quán cho cả 2
  đường, không còn là nguồn lỗi.
- ~~Không hỗ trợ ghép match xuyên qua nhiều mảnh `TJ` liền kề~~ — **CHIA LÀM 2 TRƯỜNG HỢP KHÁC HẲN
  NHAU, cập nhật phiên thứ 10 sau khi người dùng chỉ ra lập luận sai của phiên thứ 9**:
  - **Nhiều mảnh chuỗi trong CÙNG 1 mảng `TJ`** (vd `[(Hel) -20 (lo)] TJ`): **ĐÃ LÀM, không còn là giới
    hạn** — đây là sự thật cấu trúc đọc thẳng từ PDF (các mảnh là phần tử của cùng 1 mảng trong cùng
    1 lệnh), không cần đoán gì cả. Giờ cả mảng là đúng 1 `TextChunk`. Phiên thứ 9 đã nhầm việc này
    với việc dưới đây và từ chối làm với lý do "cần heuristic" — lý do đó SAI cho trường hợp này.
  - **Chữ bị chia giữa 2 operator KHÁC NHAU** (vd 1 `Tj` cho "Hel", 1 `Tj` khác sau đó cho "lo", có thể
    có `Td` định vị lại ở giữa): **VẪN KHÔNG LÀM, lý do này mới ĐÚNG** — đây mới thật sự cần heuristic
    (xét vị trí/font gần nhau) để đoán 2 operator có phải 1 cụm chữ liền không, không phải sự thật
    cấu trúc; heuristic có thể tự đoán sai (gộp nhầm chữ không liên quan, hoặc tính sai độ rộng gộp)
    — đi ngược triết lý "từ chối thay vì đoán" của cả tính năng.
- ~~Chưa có backup/restore qua chết tiến trình~~ — **đã làm ở phiên thứ 9** (`model/PdfTextEditState.kt`
  + `FileUtils.textEditSourceDir`) — KHÁC khuôn mẫu thường dùng (`PdfEditorState`...) vì lý do kỹ
  thuật riêng của iText stamping mode, xem mục 0 (phiên thứ 9) để biết đầy đủ cơ chế "lưu bản gốc +
  danh sách các lần sửa, khôi phục bằng cách áp lại từ đầu" thay vì "mở file dở dang".
- **CHƯA TỪNG mở thử 1 file PDF thật nào qua tool này** — môi trường này không build được (mục 9).
  Đây là tính năng DUY NHẤT ghi trực tiếp vào object chữ của PDF có sẵn — lỗi ở đây nghĩa là PDF
  hỏng/chữ sai vị trí/lệch font, hậu quả nặng hơn hẳn 1 lỗi giao diện thông thường. Bắt buộc tự test
  bằng nhiều PDF thật đa dạng nguồn gốc (Word, LaTeX, PDF quét có lớp OCR...) trước khi tin dùng thật
  — xem mục 10.



### 4.18. Đổi kiến trúc để bán trả phí trên Google Play — gỡ iText, dùng PdfBox-Android (phiên làm việc thứ 11)

**Yêu cầu của người dùng (nguyên văn ý):** app phải bán được có tính phí trên Google Play mà không
tốn tiền giấy phép bản quyền hàng năm; nếu bản mã nguồn mở miễn phí kém hơn bản cần giấy phép thì
tham khảo bản đó để viết code vá lại.

**Vấn đề gốc.** iText 7 phát hành theo AGPL hoặc giấy phép thương mại (thu phí, tính theo năm). Bán 1
app đóng mã nguồn mà nhúng iText thì chỉ có 2 đường: mua giấy phép thương mại, hoặc công bố toàn bộ mã
nguồn theo AGPL. Cả hai đều không phải điều người dùng muốn. iText chỉ được dùng ở 2 tính năng: "Nén
PDF → Sửa trực tiếp" (`PdfObjectRecompressor`) và "Sửa chữ PDF" (`PdfTextEditor` + `PdfCanvasEditor`
+ `PdfTextEditActivity`). Các thành phần còn lại đều dùng được cho app thương mại: CameraX/AndroidX/
Material/OpenCV/Kotlin/coroutines (Apache 2.0), ML Kit (miễn phí theo điều khoản riêng của Google, KHÔNG
phải mã nguồn mở). *Đây là kết luận từ thông tin giấy phép công khai, không phải tư vấn pháp lý.*

**Quy tắc "sạch" khi vá nhược điểm (bắt buộc giữ về sau).**
- ĐƯỢC: học *hành vi* của sản phẩm có giấy phép; đọc đặc tả PDF công khai (ISO 32000); đọc/tham khảo mã
  Apache-2.0 (PDFBox). Mọi code vá trong phiên này viết từ 2 nguồn cuối.
- KHÔNG: chép/port/dịch mã nguồn iText (kể cả bản port của bên thứ ba dựa trên iText) — làm vậy là tác
  phẩm phái sinh và kéo AGPL trở lại. `PdfCanvasEditor.kt` là bản port từ mã mẫu dùng iText nên đã bị
  xoá chứ không giữ lại "cho tiện".
- CI có bước "Licence guard" (`.github/workflows/android-build.yml`) làm build thất bại nếu
  `com.itextpdf`/`com.artifex`/`mupdf` xuất hiện trong mã nguồn hoặc cây dependency.

**Bản đồ thay thế.**

| Việc | Trước (iText) | Sau (miễn phí) |
|---|---|---|
| Đọc/ghi PDF | `PdfDocument`/`PdfReader`/`PdfWriter` | PdfBox-Android `PDDocument` (Apache 2.0), `PDFBoxResourceLoader.init()` trong `DocScannerApp` |
| Nén ảnh trong PDF | dựng XObject mới | sửa TẠI CHỖ `COSStream` (giữ `/SMask`; bỏ qua ảnh có `/Mask`, `/Decode`, `/ImageMask`); ảnh dùng chung nhiều trang chỉ nén 1 lần; chỉ thay khi JPEG mới thực sự nhỏ hơn |
| Nén cấu trúc file | full compression + smart mode có sẵn | `PdfStructureOptimizer` tự viết (bên dưới) |
| Sửa chữ | `PdfCanvasProcessor` + `PdfCanvasEditor` | `PDFStreamParser` + `ContentStreamWriter`; ĐỌC và GHI vẫn dùng chung 1 hàm `scanPage()` |
| Bộ nhớ file lớn | iText đọc lười | `MemoryUsageSetting.setupMixed(24MB)` + thư mục tạm = cache của app |

**Những gì bản miễn phí thiếu và đã vá (viết từ đặc tả, không chép iText).**
1. *Nén cấu trúc* — `PdfStructureOptimizer`: đi từ trailer gom đối tượng còn được tham chiếu (bỏ rác), Flate
   cho stream chưa nén (trừ `/Metadata`), nén lại Flate cấp 9 nếu nhỏ hơn, gộp stream giống hệt byte
   (từ điển không chứa tham chiếu gián tiếp), gói object thường vào object stream, ghi xref stream. Từ chối
   (rơi về file PdfBox thường) nếu: PDF mã hoá, tên `/Name` có ký tự ngoài ASCII, stream lồng trong object
   khác, kiểu COS lạ, file > 40 MB.
2. *Lưới an toàn* — `PdfVerify`: file tối ưu chỉ được dùng nếu (a) mở được bằng `PdfRenderer` của Android
   (PDFium, không liên quan PdfBox) và render thử vài trang mẫu, (b) nạp lại bằng PdfBox có cùng số trang,
   cùng kích thước trang, cùng SHA-256 nội dung từng trang, (c) nhỏ hơn bản PdfBox thường. "Sửa chữ PDF"
   cũng gọi `PdfVerify.opensAsPdf` sau khi lưu (bản iText cũ không có bước kiểm nào).
3. *Font CID (Type0) — phần lớn PDF từ Word/Chrome/LibreOffice* — PdfBox không mã hoá ngược Unicode →
   mã ký tự cho font nhúng đọc từ file. Vá: `ToUnicodeReverse` phân tích bảng `/ToUnicode` (ISO 32000-1
   9.10.3, `bfchar`/`bfrange`) của chính font rồi đảo ngược; ký tự "có trong font con" ⇔ có mã nào trong
   bảng ánh xạ tới nó. Font đơn giản vẫn thử `font.encode()` trước, chỉ rơi về bảng này khi lỗi. Type3, và
   Type0 không có ToUnicode → vẫn từ chối (`UnsupportedFont`).
4. Cải tiến nhỏ so với bản iText: bọc `Tz` không dùng `q…Q` bên trong `BT…ET` (sai chuẩn), tính cả `Tc`/`Tw` và
   `Tz` đang có vào độ co giãn; thông báo thiếu ký tự hiện "␣ (dấu cách)" thay vì ký tự vô hình.

**KHÔNG vá được (cần sản phẩm trả phí, hoặc quá rủi ro):** cắt tỉa (subset) lại font ĐÃ nhúng trong PDF gốc
(add-on pdfOptimizer trả phí của iText); mã hoá/ký số/PDF-A; đưa chữ mới vào font không chứa glyph đó.
Cũng chưa làm: lớp chữ tìm kiếm được (OCR → PDF searchable) — làm được bằng PdfBox nhưng cần nhúng 1 font
Unicode giấy phép OFL/Apache cho tiếng Việt; là hướng phát triển hợp lý tiếp theo cho bản trả phí.

**Bảng mức tin cậy API PdfBox-Android 2.0.27.0 (chưa chạy thật — kiểm khi build lần đầu).**
- Cao (API công khai của PDFBox 2.0.x, dùng đúng mẫu ví dụ chính thức): `PDDocument.load/save/close`,
  `PDFStreamParser(page).parse()/getTokens()`, `ContentStreamWriter.writeTokens`, `PDPage.setContents(PDStream)`,
  `COSStream.createRawInputStream/createRawOutputStream`, `COSName` các hằng số.
- Trung bình (có trong PDFBox, chưa xác nhận trong bản port Android): `PDDocument.load(File, MemoryUsageSetting)`,
  `MemoryUsageSetting.setupMixed(...).setTempDir(...)`, `COSObject.getObjectNumber()` trả `Long`,
  `PDPage.getContents()` (InputStream), `PDFont.getCOSObject()`, `PDFont.readCode/getWidth/toUnicode/encode`.
- Thấp/nhạy: hành vi thực của `font.encode()` với font TrueType con; chất lượng bảng ToUnicode của từng nhà
  sản xuất PDF (bảng sai ⇒ chữ mới có thể hiện sai glyph — không có cách tự kiểm); `PdfStructureOptimizer` trên
  PDF lạ (đã có lưới `PdfVerify`, nhưng lưới chỉ lấy mẫu vài trang khi render).
- Nếu lỗi biên dịch: sửa theo log, đừng đổi ý tưởng. Nếu PdfBox-Android hết được bảo trì hoặc lộ CVE (thư
  viện phụ thuộc BouncyCastle), cân nhắc PDFBox 3.x chính thức khi có bản chạy trên Android.

**Yêu cầu để đăng Google Play (đã chỉnh trong phiên này).**
- `targetSdk 36`/`compileSdk 36`, AGP 8.13.0, Kotlin 2.2.10, Gradle 8.13 (CI). Không phải mọi phiên bản này
  đã được build thử.
- Lưu ý theo Android 15/16: bắt buộc edge-to-edge → `DocScannerApp.EdgeToEdgeInsetsCallbacks` xử lý
  tập trung (đệm theo inset, toolbar kéo dài xuống dưới status bar, tính cả bàn phím); nút Back →
  `OnBackPressedDispatcher` (`onBackPressed()` không còn được gọi); `allowBackup=false`. Khoá hướng dọc
  bị bỏ qua trên màn hình lớn/gập khi targetSdk 36 → cần test `CropActivity` trên máy tính bảng.
- 16 KB page size: `useLegacyPackaging=false` chỉ lo phần đóng gói; các file `.so` của OpenCV/ML Kit có căn lề
  16 KB hay không **chưa xác nhận** — kiểm tra AAB bằng công cụ của Android trước khi tải lên.
- Phát hành: cần AAB ký khoá upload (`create-keystore.yml` tạo 1 lần, lưu vào secret `KEYSTORE_BASE64`,
  `KEYSTORE_PASSWORD`, `KEY_ALIAS`); `versionCode` = số lần chạy CI; **`applicationId` phải đổi khỏi
  `com.example.*` (Play từ chối) bằng biến repo `APP_ID` — không đổi được sau khi phát hành**.
- Apache 2.0 yêu cầu kèm bản giấy phép/NOTICE → màn hình "Giấy phép mã nguồn mở" (`LicensesActivity`, nội dung
  ở `assets/THIRD_PARTY_NOTICES.txt`, link cuối màn hình chính).
- Bán trả phí: đặt giá trong Play Console (không cần code Play Billing). Việc ngoài code người dùng phải
  tự làm: tài khoản nhà phát triển (phí đăng ký 25 USD một lần, không phải hằng năm), hồ sơ thanh toán/
  merchant để nhận tiền, chính sách quyền riêng tư, form Data safety (app xử lý OCR ngay trên máy), và
  các điều kiện thử nghiệm bắt buộc với tài khoản cá nhân mới — kiểm tra quy định hiện hành trên Play Console.

### 4.19. Chức năng bổ sung từ khảo sát SDK trả phí (Scanbot/Dynamsoft/Apryse...) — phiên làm việc thứ 12

**Cách làm.** Đối chiếu danh sách tính năng công khai của SDK quét tài liệu thương mại (tự động chụp, tự cắt + làm
thẳng, bộ lọc nhị phân hóa, Document Quality Analyzer, PDF có lớp chữ OCR, các định dạng xuất...) với bộ ba miễn phí
đang dùng (OpenCV + ML Kit + PdfBox). Chọn những thứ (a) người dùng cuối thấy ngay, (b) làm được thuần bằng OpenCV /
PdfBox / ML Kit không cần mô hình học máy riêng, (c) có bài báo/đặc tả để làm theo. Mọi thứ viết từ bài báo, KHÔNG
chép mã nguồn của ai (quy tắc "sạch" ở 4.18).

| Chức năng | Ở đâu | Nguồn (paper/đặc tả) | Kết quả thử |
|---|---|---|---|
| PDF tìm kiếm được | `SearchablePdfBuilder` + thẻ ở màn hình chính | ISO 32000-1 §9.3.6 (Tr 3), §9.6.5 (Type3), §9.10.3 (ToUnicode); phân tích lỗi font giả của Tesseract (issue #2879, Ghostscript bug 695869) | Xem dưới |
| "Trắng đen+" (Sauvola) | `DocumentEnhancer.sauvolaBinarize`, chip mới ở CropActivity | J. Sauvola & M. Pietikäinen, Pattern Recognition 33(2), 2000; cách cài bằng box filter: Shafait/Keysers/Breuel, SPIE DRR XV, 2008 | Xem dưới |
| "Xóa bóng" | `DocumentEnhancer.normalizeBackground` | Ý tưởng của S. Bako và cs., "Removing shadows from images of documents", ACCV 2016 (ước lượng màu nền cục bộ, chia cho nền); bản classical đơn giản | Xem dưới |
| Tự thẳng chữ | `DocumentEnhancer.estimateSkewDegrees/straighten`, ô tích ở CropActivity | Postl, ICPR 1986; Bloomberg/Kopec/Dasari, SPIE 2422, 1995 (profile chiếu + tổng bình phương hiệu các hàng liền kề; quét thô rồi mịn). Bằng sáng chế Xerox liên quan US 5,355,420 được Google Patents ghi là hết hạn — không phải tư vấn pháp lý | Xem dưới |
| Gợi ý chất lượng ảnh | `ScanQuality`, toast ở CropActivity | Pech-Pacheco và cs., ICPR 2000 (phương sai Laplacian); so sánh toán tử lấy nét: Pertuz/Puig/García, Pattern Recognition 2013 | Xem dưới |

**Lớp chữ OCR — quyết định thiết kế đáng nhớ.** Bảng ToUnicode chỉ tồn tại gắn với một font, nên cần 1 font. Font TrueType
"rỗng" của Tesseract bị chính người phát triển Ghostscript/Tesseract ghi nhận là không hợp lệ (thiếu bảng bắt buộc, checksum
sai, `glyf` rỗng) và PDFium (Chrome, `PdfRenderer` của Android) đọc sai `/W`. Vì vậy dùng **font Type3 mà mọi glyph không vẽ gì**
(`500 0 d0`): font hợp lệ bình thường, không có file font nào nhúng, nghĩa Unicode nằm ở `/ToUnicode`. Mỗi font chứa tối đa
250 ký tự (mã 1 byte); ký tự của cả tài liệu được chia cho đủ số font (thường 1). Mỗi TỪ OCR là 1 lệnh chữ: cỡ chữ = chiều cao
khung, giãn ngang `Tz` cho vừa chiều rộng khung, ma trận chữ xoay theo `/Rotate` của trang, đặt theo `CropBox`. Trang đã có
chữ thật (kể cả lớp OCR làm lần trước) bị BỎ QUA, không nhân đôi. Kết quả phải mở được bằng `PdfRenderer`; sau đó đọc lại 1
trang bằng `PDFTextStripper` của PdfBox và báo % từ khớp (kiểm bằng trình đọc của PdfBox, không phải Chrome/Acrobat).

**Đã thử thật (bản Python song song, cùng thuật toán/hằng số như Kotlin; máy này có qpdf 2.x, poppler, pypdf, pdfminer,
OpenCV, scikit-image; script ở `tools/verify/`, không nằm trong APK; kết quả ghi dưới đây để khỏi làm lại):**
- *Lớp chữ Type3 + ToUnicode + Tr 3*: `qpdf --check` sạch; poppler (`pdftotext`, cả `-layout` và `-bbox-layout`), pdfminer và
  pypdf đều trích đúng tiếng Việt có dấu ("Cộng hòa xã hội Việt Nam Độc lập") trên trang xoay 0/90/180/270. Khung từ theo
  chiều ngang khớp mong đợi trong 0,01 pt; chiều dọc nằm trong khung từ nhưng poppler chỉ dùng ~52% chiều cao (chọn ascent/descent
  của nó) — vùng bôi đen khi chọn chữ có thể thấp hơn chữ in một chút, không ảnh hưởng tìm kiếm/sao chép. CHƯA thử: Chrome, Acrobat,
  Apple Preview, trình đọc trên Android.
- *Object stream + xref stream* (thuật toán của `PdfStructureOptimizer`): file kết quả qua `qpdf --check`; poppler trích cùng
  chữ; pypdf lấy đúng nội dung từng trang; poppler render ĐÚNG TỪNG PIXEL như bản gốc (12 trang + 2 trang có ảnh trùng); tài liệu
  12 trang ≈174 KB → ≈131 KB (−25%; số byte lệch vài chục giữa các lần chạy vì reportlab ghi giờ tạo); 2 ảnh giống hệt ở 2 trang gộp còn 1 đối tượng (11 153 → 5 755 byte, −48%). Phép thử phát hiện
  1 lỗi trong BẢN PYTHON (ghi tham chiếu thay vì nội dung ở đầu object stream) — bản Kotlin lưu đối tượng đã giải tham chiếu nên
  không mắc, nhưng đây là loại lỗi cần để ý khi build lần đầu: mở file kết quả bằng ≥ 2 trình đọc.
- *Sửa nghiêng*: trang có chữ xoay +1,5 / −2,7 / +4,2 / −6,0° → ước lượng đúng −1,5 / +2,7 / −4,2 / +6,0° (dấu đã xác nhận: giá
  trị trả về là góc CẦN XOAY để thẳng); trang trắng và trang nhiễu ngẫu nhiên → 0 (không đoán).
- *Sauvola*: khớp `skimage.filters.threshold_sauvola` (cùng cửa sổ/k/R) đến 0,005% điểm ảnh. So với ngưỡng thích ứng Gauss cũ
  (IoU với mực thật; trang tổng hợp; k=0,25 là giá trị ĐÃ CÀI; `tools/verify/image_algorithms_check.py` tái hiện đúng các số này): sạch 0,869 vs 0,898 (cũ nhỉnh hơn một chút);
  nhiễu σ=12 → 0,864 vs 0,600 (cũ để lại ~9 000 điểm lốm đốm trên nền trắng, mới = 0); σ=25 → 0,770 vs 0,384; chữ nhạt (mất 60% tương phản) 0,861 vs 0,791;
  vết ố + nhiễu 0,866 vs 0,676; bóng + nhiễu 0,871 vs 0,655; bóng + vết ố + nhạt + nhiễu 0,865 vs 0,522. Ngưỡng toàn cục Otsu sập (0,163–0,190) khi có bóng.
  Quét k (trung bình IoU trên 6 kịch bản xấu): 0,10 → 0,678; 0,15 → 0,775; 0,20 → 0,827; **0,25 → 0,849**; 0,34 → 0,843; 0,50 → 0,729. Chênh 0,25 vs 0,34 ở TRUNG BÌNH rất nhỏ,
  nhưng khác nhau ở chỗ: k=0,34 mất chữ nhạt (0,655 vs 0,861) trong khi k=0,25 kém hơn khi nhiễu nặng (0,770 vs 0,857); chọn 0,25 để không mất chữ. k=0,5 (gợi ý gốc của bài báo)
  làm mất gần hết chữ nhạt (0,012). Vì vậy **giữ cả "Trắng đen" cũ lẫn "Trắng đen+"** thay vì thay thế.
- *Xóa bóng* (cấu hình ĐÃ CÀI: 1000 px, dilate 5x5, median 3 — sau phiên 13): bóng chuyển dần làm độ lệch chuẩn của nền giấy 36,9 → 1,0 và góc tối nhất 109 → 252 (giấy về trắng); chữ đen vẫn tối.
  (Bản phiên 12 dùng 480 px/9x9/median 15/Gauss 21 cho 36,9 → 2,0; chuyển cấu hình ở phiên 13 để giảm quầng sáng ở viền bóng gắt — mục 4.20.)
- *Đo mờ*: mờ σ=1,5 → 548; σ=3 → 25; σ=6 → 3,5; trang nét 8 620; ngưỡng đặt 90 ⇒ chỉ báo mờ từ mức σ≳3 (chữ 26 px). Trang tối
  (×0,25) được báo tối + thiếu tương phản; trang trắng không bị báo gì.

**Giới hạn — phải đọc trước khi tin.**
- Các phép thử ở trên dùng trang TỔNG HỢP (chữ DejaVu trên nền phẳng + nhiễu/bóng/vết ố mô phỏng). Ảnh chụp thật có nếp gấp,
  chói, chữ viết tay, bảng, ảnh màu — chưa thử. Nhiễu ảnh thật làm phương sai Laplacian LỚN lên, nên `ScanQuality` dễ báo sót
  ảnh mờ hơn là báo nhầm. Mọi ngưỡng/hằng số cần chỉnh lại bằng ảnh thật; tất cả chỉ là GỢI Ý, không chặn lưu.
- "Tự thẳng chữ" mặc định TẮT. **[Đã đổi: phiên 13 gộp thành ô "Tự xoay đúng chiều và thẳng chữ" + thêm ô "Duỗi thẳng dòng chữ cong" — mục 4.20/4.21; cong gáy sách ĐÃ làm.]**
- **[Đã giải quyết ở phiên 13 — mục 4.20]** ~~Lớp chữ OCR định vị bằng khung ngang-trục~~ (nay dùng 4 góc `cornerPoints`) và ~~ML Kit chỉ có Latin~~ (nay có Hán/Nhật/Hàn/Devanagari;
  tiếng Ả Rập/Thái/... vẫn chưa có mô hình trong dự án).
- Trạng thái Kotlin: mọi file mới chỉ được rà cú pháp bằng máy (cân bằng ngoặc) và đối chiếu logic với bản Python; API PdfBox mới dùng
  (`PDPageContentStream(..., APPEND, true, true)`, `appendRawCommands`, `COSDocument.createCOSStream`, `PDFTextStripper`,
  `PDPage.getCropBox/getRotation`) thuộc nhóm "Trung bình" của bảng mức tin cậy ở 4.18.

**Cân nhắc ở phiên 12 (TRẠNG THÁI MỚI NHẤT của từng mục nằm ở bảng trong 4.20, không còn đúng như cột "Lý do chưa làm" dưới đây):**
| Tính năng SDK trả phí | Lý do chưa làm |
|---|---|
| Tự động chụp khi máy giữ vững (auto-capture) | cần luồng camera thời gian thực + ổn định khung; đáng làm tiếp, kiểm bằng máy thật |
| Dewarp trang sách cong | học thuật nặng (mô hình trụ / lưới dòng chữ / mạng học máy); rủi ro cao khi chưa có máy thử |
| Tự nhận hướng 0/90/180/270 | phân biệt 0° và 180° cần chạy OCR 2 lần hoặc thống kê nét lên/xuống (Bloomberg 1995) |
| Water-filling (Jung 2018) xóa bóng có viền cứng | mạnh hơn bản classical nhưng phức tạp; bản hiện tại yếu ở viền bóng gắt |
| Redaction thật (xóa chữ gốc dưới vùng che) | có thể dựng trên `PdfTextEditor.scanPage`, nhưng là tính năng bảo mật: sai sót thầm lặng là nguy hiểm, cần thử kỹ |
| Mật khẩu PDF (AES-256), watermark, chữ ký hình | PdfBox làm được, ít rủi ro; chưa ưu tiên |
| PDF/A, chữ ký số | cần ICC/XMP/chứng thư; nằm ngoài phạm vi hiện tại |
| Cắt tỉa lại font đã nhúng, nén JBIG2/JPX | cần sản phẩm trả phí hoặc codec có bằng sáng chế |

### 4.20. Phiên 13 — tra cứu để giải quyết từng "giới hạn" / "chưa làm" của phiên 12

**Yêu cầu của người dùng:** giới hạn mà không tra cứu tìm cách giải quyết thì mãi là giới hạn → với MỌI mục còn lại phải tra cứu, rồi
hoặc làm, hoặc nêu lý do có bằng chứng. (Đã lưu thành sở thích làm việc.)

| Mục (phiên 12) | Tra cứu tìm ra | Quyết định | Kiểm chứng (máy này, bản Python song song) |
|---|---|---|---|
| Xóa bóng viền gắt — water-filling (Jung/Hasan/Kim, ACCV 2018) | README của chính tác giả: mã có sẵn nhưng "đừng dùng cho mục đích công nghiệp khi chưa xin phép (vấn đề bằng sáng chế)" | **KHÔNG cài** (app bán trả phí). Cải thiện bằng bộ lọc cổ điển: đa phần halo do làm mờ rộng → nền ước lượng ở 1000 px, dilate 5x5, median 3 (thay 480 px / 9x9 / median 15 / Gauss 21) | độ lệch chuẩn giấy sát viền bóng gắt 45,7 → 20,5; giấy trong vùng bóng 249 → 254. Đánh đổi đo được: ô xám đặc (bảng) 128 bị làm sáng thành 241 (cấu hình cũ: 187) ⇒ bộ lọc dành cho trang CHỮ |
| Tự nhận hướng 0/90/180/270 | Bloomberg/Kopec/Dasari 1995; bằng Xerox US 5,276,742 "Rapid detection of page orientation" (Google Patents: Expired - Lifetime); Leptonica cài cùng ý | Cài `PageOrientation`: trục chữ (điểm profile) → làm thẳng → đếm nét lên/xuống, kiểm 3-sigma của bài báo, TỪ CHỐI khi không chắc | 480 trang (Anh+Việt, 4 font, 3 cỡ, 4 hướng, nghiêng 0/+3/−4/+6°, nhiễu): **0 sai**, 75–90% quyết định, còn lại từ chối. Trang số / CHỮ HOA / trắng / nhiễu: từ chối. LỖI ĐÃ BẮT: bản đầu đếm dấu phẩy là "nét xuống" → trang bảng số bị đảo 180° với độ tin cậy cao; sửa bằng ngưỡng chiều cao nét 0,35 x-height |
| Dewarp trang sách cong | Ulges/Lampert/Breuel ICDAR 2005 (đường chữ cong → thẳng); page_dewarp (MIT, mô hình tấm bậc 3); hướng học máy (DocUNet/DewarpNet/UVDoc) cần file mô hình, không tải được ở đây | Cài `TextLineDewarp` (chỉ sửa cong DỌC, xấp xỉ bậc 3 từng dòng, nội suy giữa dòng); từ chối nếu <4 dòng sạch, dịch chuyển <2 px hoặc >8% chiều cao (phiên 14 nới trần lên 12%, mục 4.21), hoặc không giảm phần dư ≥15% | độ thẳng (RMS px): Anh bowl30 3,12→1,07; half40 3,60→1,08; Việt 3,21→1,38 / 3,62→1,44; 2 cột 1,27→1,06; có khối ảnh 2,99→1,07. Trang phẳng/2 cột/ảnh/bảng số/thưa: 0 điểm ảnh bị đổi. co ngang gần gáy sách: ĐÃ SỬA ở phiên 14 (mục 4.21); sóng mạnh (amp 50: 14,3→5,1) chỉ cải thiện một phần |
| Tự động chụp | CameraX `ImageAnalysis` (KEEP_ONLY_LATEST, plane Y) | Cài `CaptureStability` (giữ yên 1,2 s, góc lệch <1,8%, nét không còn dò, chỉ bắn 1 lần tới khi lật trang) + `FrameDocumentAnalyzer`; công tắc "Tự động chụp" mặc định TẮT | 10 tình huống mô phỏng đều đúng (xem `tools/verify/stability_check.py`): đứng yên bắn lúc 1200 ms; tay di chuyển 2,5%/khung không bao giờ bắn; dò nét chờ tới 2000 ms; giữ trang 10 s chỉ bắn 1 lần; lật trang bắn lần 2; chập chờn 1/5 khung vẫn bắn; khung quá nhỏ / cả khung / tứ giác thắt nơ: không bắn. CHƯA thử: video cầm tay thật |
| ML Kit chỉ có Latin | ML Kit có artifact riêng cho chữ Hán, Nhật, Hàn, Devanagari (miễn phí, ~4 MB/kiến trúc khi đóng gói sẵn) | Thêm 4 phụ thuộc + `OcrHelper.OcrScript`; hộp chọn hệ chữ trước khi chọn PDF; Hán/Nhật không chèn khoảng trắng giữa từ. Gỡ dòng trong `app/build.gradle` nếu muốn app nhẹ hơn | (chưa build; kiểm lại số phiên bản 16.0.1 của 4 artifact khi build) |
| Từ OCR nghiêng bị lệch (khung ngang-trục) | ML Kit `Element.cornerPoints` | `SearchablePdfBuilder` dựng ma trận chữ từ 4 góc (chiều rộng, chiều cao, hướng đường cơ sở, hướng "lên") rồi chuyển qua `/Rotate` | đo góc đường cơ sở từ vị trí từng chữ cái (pdfplumber) trên 4 hướng xoay trang × góc 0/+15/−25°: **đúng tuyệt đối (0,00 / 15,00 / −25,00°)** |
| Vùng bôi chọn trong poppler chỉ cao ~52% | thử 3 biến thể: không FontDescriptor / có FontDescriptor (Ascent 800, Descent −200) / FontBBox lớn hơn | **giữ nguyên.** poppler 11,2 pt / 8,6 pt / 11,2 pt trên khung 21,6 pt (tự chọn ascent/descent cho Type3; biến thể có mô tả còn tệ hơn); pdfminer/pdfplumber đo đúng 21,6 pt ở cả 3 | không sửa được từ phía mình; không ảnh hưởng tìm/sao chép |
| Redaction thật | đọc mã `AnnotationCanvasView.flatten()` + `PdfAnnotateActivity`: ô che và nét vẽ được "nung" vào điểm ảnh rồi dựng lại PDF chỉ gồm ảnh | **đã đúng là redaction thật** cho trang đi qua công cụ Chú thích: chữ gốc dưới ô che không còn trong file (không có /Annots hay text gốc). Sau đó chạy "PDF tìm kiếm được" để lấy lại khả năng tìm chữ | đọc mã; ghi chú: metadata/mục lục PDF gốc cũng không mang sang (PDF dựng mới từ ảnh) |
| Mật khẩu PDF, watermark | PdfBox `StandardProtectionPolicy` + `setEncryptionKeyLength(256)`; ảnh trong suốt qua `LosslessFactory` | Cài `PdfSecurityTools`; đặt mật khẩu chỉ giữ kết quả nếu mở được BẰNG mật khẩu và KHÔNG mở được khi không có; watermark vẽ chữ bằng Canvas của Android (tiếng Việt, không cần nhúng font PDF) | watermark (hình trong suốt + SMask, xoay 45° theo /Rotate + CropBox): poppler đo góc 45,3–45,4° ở /Rotate 0/90/180/270 và CropBox; tâm đúng tâm CropBox, lệch ≤0,05 trang do chữ không lấp đầy ảnh. AES chưa thử (PdfBox-Android thật) |
| PDF/A | PDF/A-2b cần: font nhúng hết, OutputIntent sRGB + ICC, XMP có pdfaid, không mã hóa/JS; công cụ kiểm chuẩn mở là veraPDF (Java). Phiên bản veraPDF ghi nhận miễn trừ CIDToGIDMap cho font chỉ dùng render mode 3 | **chưa làm.** Không có veraPDF ở đây (không mạng) nên không thể xác nhận tuân chuẩn, và không được tuyên bố "PDF/A" khi chưa xác nhận. Đường đi đúng: (1) thêm XMP + OutputIntent bằng PdfBox, (2) chạy veraPDF trên file mẫu ở CI/thiết bị, (3) chỉ khi qua mới bật nút | — |
| Chữ ký số | PDFBox có ví dụ chính thức `CreateSignature/CreateVisibleSignature` (`SignatureInterface` + BouncyCastle + khóa PKCS#12); có ví dụ cộng đồng chạy trên PdfBox-Android + SpongyCastle; gói ký số của PSPDFKit là mô-đun trả phí | **chưa làm.** Khả thi miễn phí, nhưng cần biết chính xác artifact BouncyCastle/bcpkix mà PdfBox-Android kéo theo — `dependencies.txt` của CI sẽ cho biết ở lần build đầu. Quy mô ~150 dòng theo ví dụ của PDFBox + hộp chọn .p12 | — |

**Còn mở (đã tra cứu, nêu thẳng):** (dewarp co ngang đã sửa ở 4.21); tự động chụp/ngưỡng chất lượng/ngưỡng Sauvola chưa thử với ảnh thật; không xác định được tình trạng bằng
sáng chế của các kỹ thuật dewarp/tự chụp/xóa bóng nói chung (nhiều bằng sáng chế tồn tại trong lĩnh vực quét tài liệu) — đây KHÔNG phải kết luận pháp lý, nếu lo ngại cần hỏi luật sư;
Chrome/Acrobat/Preview chưa thử với lớp chữ OCR; chữ viết tay không nằm trong khả năng của ML Kit.

### 4.21. Phiên 14 — sửa độ co ngang gần gáy sách trong `TextLineDewarp`

**Vấn đề.** Phiên 12-13 chỉ sửa độ cong DỌC của dòng chữ. Gần gáy sách chữ còn bị ép hẹp theo chiều ngang.

**Tra cứu → cách làm.** (1) Khoảng cách giữa hai dòng liền kề tại cột x tỉ lệ với độ phóng đại cục bộ = 1/độ sâu của mặt trang (trang phẳng
thì các dòng cách đều) → đo được s(x) ngay từ ảnh, không cần mô hình học máy. (2) Với camera lỗ kim, điểm trên mặt trang có X = (x − cx)·Z/f,
Z = 1/s(x) → đi dọc đường cong đó, độ dài cung u(x) chính là toạ độ trên trang phẳng của cột x (Cao/Ding/Liu, ICDAR 2003, mô hình trụ).
Bước này cũng gỡ phần co do trang NGHIÊNG chứ không chỉ do xa/gần. (3) Tiêu cự f không biết được từ ảnh → giả định 0,7 × bề rộng ảnh trang.
Học máy (DocUNet/DewarpNet/UVDoc) cần file mô hình, không tải được ở môi trường này, nên không dùng.

**Cách đo (có đáp án chuẩn).** `tools/verify/book_render.py` dựng "ảnh chụp trang sách cong" bằng vật lý: trang phẳng → uốn trụ quanh gáy → camera lỗ kim nhìn xuống; render
cùng hình học cho 2 kết cấu: trang chữ (đưa cho thuật toán) và lưới chấm tròn (đáp án: sau khi sửa phải thành lưới đều). Sai số = độ lệch RMS của tâm các chấm so với phép
afin tốt nhất của lưới phẳng, tính bằng % bề rộng trang. Quét 27 tổ hợp: góc cong 30/45/55°, độ rộng vùng cong 0,15/0,25/0,40 bề rộng trang, camera cách 0,7/1,0/1,6 bề rộng trang.

| Phương án | trung bình | trung vị | tệ nhất |
|---|---|---|---|
| ảnh thô | 2,36% | 3,03% | 4,46% |
| chỉ dọc (bản cũ) | 1,21% | 0,69% | 4,41% |
| V1: chỉ chia độ phóng đại (không tính nghiêng) | 0,66% | 0,34% | 3,21% |
| **V2: độ dài cung, f = 0,7 × bề rộng (ĐÃ CÀI)** | **0,62%** | **0,28%** | **2,98%** |
| V2 với f = 0,6 / 0,75 / 0,9 / 1,1 | 0,62 / 0,63 / 0,65 / 0,77% | — | 2,93 / 3,01 / 3,22 / 4,70% |

Độ nhạy: f từ 0,6 đến 0,9 chênh dưới 5% so với tốt nhất, 1,1 trở lên xấu hẳn (nên chọn thấp); lệch tâm ảnh ±10% làm sai số 0,13–0,46% (vẫn tốt hơn V1/V0); nhiễu σ=12 và chữ
tiếng Việt cho kết quả tương tự (0,07–0,38%); gáy bên TRÁI đối xứng với gáy bên phải (0,14–0,30% vs 0,16–0,25%). Camera xa (ít phối cảnh) V1 hơi tốt hơn V2 (0,09 vs 0,28–0,45%) — cả hai
đều cải thiện mạnh so với ảnh thô 1,24%. 4/27 ca còn >1%: tất cả là độ cong phi thực tế (trang nhô lên tới ~nửa khoảng cách camera) và dòng chữ bị nhận sai.

**Cổng an toàn (đã đo).** Kích hoạt mềm theo biên độ biến thiên của s(x): trang phẳng đo được ≤ 0,053 (tiếng Anh, Việt serif, 2 cột, có ảnh, số, nhiễu), trang cong nhẹ nhất ≥ 0,07 → tắt dưới 0,05,
bật hoàn toàn từ 0,09; không dịch cột quá 12% bề rộng. Giữ nguyên các cổng cũ (≥4 dòng sạch; dịch chuyển dọc 2 px … 12% chiều cao — nới từ 8% vì camera gần làm dòng cong tới 8,6%; phải làm
dòng thẳng hơn ≥15%). Cả 7 trang phẳng/không phải chữ thử (Anh, Việt, 2 cột, có ảnh, bảng số, gần trắng, nhiễu σ=15) đều KHÔNG bị thay đổi.

**Hằng số quan trọng** (do `tools/verify/doc_sync_check.py` đối chiếu với mã Kotlin; đổi mã thì đổi cả khối này):
```
DocumentEnhancer.SAUVOLA_K=0.25
DocumentEnhancer.BG_WORK_EDGE=1000.0
TextLineDewarp.F_REL=0.7
TextLineDewarp.MAX_DISP_FRACTION=0.12
TextLineDewarp.ACT_LO=0.05
TextLineDewarp.ACT_HI=0.09
TextLineDewarp.MAX_SHIFT_FRACTION=0.12
CaptureStability.HOLD_MS=1200
CaptureStability.MOVE_TOL=0.018
CaptureStability.SHARP_KEEP=0.6
ScanQuality.BLUR_VARIANCE_THRESHOLD=90.0
PageOrientation.MIN_COUNT=40
PageOrientation.MIN_CONF=0.2
```

**Giới hạn còn lại — nêu thẳng:** (1) giả định gáy chạy dọc (ảnh chụp thẳng đứng) và một chỗ cong trơn; trang cong nhiều chỗ hoặc camera nghiêng mạnh chỉ sửa một phần. (2) f giả định, không đo
được từ ảnh (nếu ảnh có EXIF tiêu cự thì có thể truyền vào — chưa làm). (3) Toàn bộ kiểm chứng là trang SINH RA bằng mô phỏng, chữ DejaVu; chưa thử ảnh sách thật, bóng đổ, chữ nghiêng
lẫn với cong. (4) Bản Kotlin chỉ qua rà cú pháp và đối chiếu logic với bản Python tham chiếu (`tools/verify/dewarp_model.py`), chưa build.

### 4.22. Phiên 15 — số trang/Bates, ký & đóng tem, in, khoá ứng dụng, sao lưu ZIP, thông tin PDF

**Nguồn yêu cầu.** File `Thiếu gì để bán app - DeepSeek.pdf` (87 trang, đoạn chat). Phần có giá trị là danh sách ~100 tính năng và các "giai đoạn" ưu tiên (số trang/đầu-chân trang,
chữ ký, in, app lock, sao lưu ZIP, smart naming, tag/tìm kiếm, batch, N-up/booklet, xuất HTML/MD/CSV...). Phần đầu của file (50 điểm "chưa build-test, chưa có release...")
trùng với mục 6/9/10 sẵn có. Đối chiếu với mục 11: tìm kiếm được, mật khẩu, watermark, tự chụp, tự xoay, xóa bóng, chú thích, tách trang sách ĐÃ có — không làm lại.

**Nền chung — `PdfPageGeometry` (mới).** Mọi thứ ghi lên trang có sẵn đều được người dùng mô tả theo trang ĐANG HIỂN THỊ ("cách mép dưới 28 pt", "giữa trang", "góc dưới-phải"), trong khi
file PDF có `/Rotate` (0/90/180/270) và CropBox có thể không bắt đầu ở (0,0). Lớp này cho (a) ma trận `cm` để vẽ trong khung hiển thị thẳng đứng gốc dưới-trái, (b) hàm đổi điểm (x từ trái,
y từ trên) sang toạ độ trang. Dùng `page.cropBox` (đã cắt theo MediaBox) vì đó là khung mà poppler `-cropbox` và `PdfRenderer` hiển thị. Đã kiểm với poppler trên **12 tổ hợp**
(xoay 0/90/180/270 × không CropBox / CropBox lệch gốc / MediaBox gốc âm): ô đỏ/xanh dương/xanh lá ở 3 góc khác nhau phải hiện đúng chỗ VÀ đúng chiều, điểm chọn phải rơi đúng pixel
(`page_geometry_check.py`). Ghi chú kiểm thử: `pdftoppm`/`pdftotext` phải có `-cropbox`, nếu không poppler vẽ theo MediaBox và phép đo lệch.

**Số trang, đầu/chân trang, Bates — `PdfDecorator` + `PdfDecorateActivity`.** Thêm nhãn vào PDF có sẵn bằng `PDPageContentStream` chế độ APPEND (chữ gốc vẫn là chữ, không rasterize).
Token trong mẫu: `{n}` số trang (đếm từ `startNumber`), `{N}` tổng số trang, `{b}` số Bates = tiền tố + số trang đệm 0 tới `batesDigits` (vd `ABC-` + 4 chữ số + trang 7 → `ABC-0007`).
Chữ ASCII in được → font Helvetica dựng sẵn (file nhỏ); chữ khác (tiếng Việt, CJK) → vẽ bitmap bằng Android rồi chèn như ảnh (cách `PdfSecurityTools.watermark` đã dùng), mỗi chuỗi
khác nhau chỉ tạo bitmap một lần. `skipFirstPages` bỏ trang bìa và không đếm nó. Hai nhãn trùng một vị trí bị từ chối ngay ở màn hình (tránh in chồng). Kết quả qua `PdfStructureOptimizer.save` +
`PdfVerify.opensAsPdf` như mọi công cụ ghi PDF khác. **Đã kiểm:** hàm thuần (token, Bates tràn số chữ số, nhãn rộng hơn trang không chạy ra bên trái) + **8 tổ hợp** xoay × CropBox với poppler
(`pdftotext -cropbox -bbox`: chữ đúng vị trí ±3 pt và NẰM NGANG) — `decorate_check.py`.

**Ký & đóng tem — `PdfStamper`, `SignaturePadView`, `SignatureStore`, `StampRenderer`, `StampPlacementView`, `PdfSignActivity`.** Khác `PdfAnnotateActivity` (nung vào điểm ảnh, rasterize cả trang),
công cụ này THÊM một ảnh trong suốt vào nội dung trang nên chữ gốc vẫn tìm/sao chép được. Vị trí lưu theo TỈ LỆ trang hiển thị (tâm x/y, chiều rộng) nên không phụ thuộc cỡ ảnh xem trước và áp
được cho nhiều trang; `rectFor` kéo ảnh vào trong nếu tràn mép và không cho rộng/cao hơn trang. Luồng: chọn PDF → ký tay (bảng vẽ làm mượt bằng đường cong bậc 2 qua trung điểm, cắt sát nét, nền
trong suốt) / chọn chữ ký đã lưu (tối đa 8, giữ lâu để xoá) / tem (5 mẫu + ngày hôm nay + tự nhập) → kéo, chụm → chọn "trang này / tất cả / trang cuối" → lưu file mới. Chữ ký lưu ở bộ nhớ RIÊNG
của app (`filesDir/signatures`), không vào sao lưu ZIP. **Đây là chữ ký HÌNH ẢNH**: trình đọc không hiện "đã ký bởi…", file không chống sửa; layout nói rõ điều này. **Đã kiểm:** `rectFor` thuần +
**24 tổ hợp** (xoay × CropBox × 3 vị trí: giữa / sát góc trên-trái / sát góc dưới-phải) với poppler: ảnh nửa đỏ-nửa xanh dương có góc trong suốt (SMask) phải hiện đúng chỗ, đúng chiều, hở nền
(`stamp_check.py`). Process death: đường dẫn bản làm việc + trang đang xem được lưu trong instance state.

**In — `PdfPrintAdapter`.** `PrintManager.print` + `PrintDocumentAdapter`: mỗi trang yêu cầu được `PdfRenderer` vẽ ở 200 dpi (trần 3300 px cạnh dài), co vừa vùng in giữ tỉ lệ, đặt giữa, vào
`PrintedPdfDocument`; từng trang một trên luồng riêng, tái chế bitmap trước trang sau. Nút "In" chỉ hiện với file PDF trong danh sách lịch sử và màn tóm tắt dự án (`HistoryAdapter.onPrint`, cả hai gọi `PdfPrintAdapter.print(context, file)`; lần đầu chỉ nối ở `MainActivity` nên `ProjectSummaryActivity` lỗi biên dịch — B15-03). `PdfRenderer` không mở được PDF
có mật khẩu → báo lỗi ở bước layout. **Đã kiểm:** chỉ hàm thuần `isSelected` (phạm vi trang, 7 ca — `print_ranges_check.py`); phần máy in/spooler phải thử trên máy thật. Đã sửa khi rà lại: KHÔNG đóng
`FileOutputStream` bọc descriptor của khung in (khung tự đóng; đóng hai lần là lỗi).

**Khoá ứng dụng — `AppLock`, `LockActivity`, `AppLockCallbacks` (trong `DocScannerApp.kt`), công tắc ở màn chính.** Khoá cả app một lần thay vì từng thư mục: bao phủ lịch sử, mọi trình soạn thảo
và danh sách chia sẻ. Khoá bật khi khởi động nguội và khi app ra khỏi tầm nhìn quá 60 giây (đi lại giữa các màn của app không tính: màn sau `start` TRƯỚC khi màn trước `stop`). Khi khoá bật, mọi cửa sổ
tạo với `FLAG_SECURE` (ẩn ở màn đa nhiệm, chặn chụp màn hình). Xác thực: `BIOMETRIC_WEAK | DEVICE_CREDENTIAL` — **không** dùng `BIOMETRIC_STRONG | DEVICE_CREDENTIAL` vì androidx.biometric không hỗ trợ
tổ hợp đó trên Android 9–10 (đã tra cứu). Quyết định cố ý: nếu khoá đang bật nhưng máy không còn khoá màn hình/sinh trắc (`NONE_ENROLLED`/`NO_HARDWARE`) thì app TỰ TẮT khoá thay vì nhốt người dùng
khỏi tài liệu của mình (điện thoại không khoá màn hình thì ai cũng mở được); lỗi tạm thời (cảm biến bận…) thì giữ khoá. Bật khoá yêu cầu xác thực thành công trước; tắt khoá cũng yêu cầu xác thực.
`LockActivity` chỉ tự hiện prompt MỘT lần mỗi lần ghé (prompt đóng làm activity resume lại — nhắc lại mỗi lần resume sẽ thành vòng lặp không thoát được); Back chuyển app xuống nền chứ không về
màn bên dưới. Thêm phụ thuộc `androidx.biometric:biometric:1.1.0` (Apache 2.0; bản ổn định mới nhất). **Đã kiểm:** `app_lock_check.py` — 10 kịch bản trên bản Python của logic
(khởi động nguội, đi lại trong app rất lâu, ra ngoài 30 s / 61 s, Home ở màn khoá, xoay màn hình, bật giữa phiên, tắt, gỡ khoá màn hình, lỗi tạm thời). KHÔNG kiểm được BiometricPrompt và
vòng đời thật trên Android.

**Sao lưu / khôi phục ZIP — `BackupManager`.** Một tệp ZIP do người dùng chọn nơi lưu (SAF `CreateDocument`/`OpenDocument`): thư mục `exports/` (PDF/EPUB/TXT đã xuất) + `projects/` (mỗi dự án: `project.json`
+ ảnh). `allowBackup=false` nên trước đây đổi máy là mất hết. KHÔNG nằm trong ZIP: chữ ký tay đã lưu và cài đặt khoá (tệp ZIP hay bị tải lên đám mây). Khôi phục: (1) không bao giờ ghi đè — tệp đã có bị
bỏ qua và đếm; (2) không tin tên entry (`parseEntry` từ chối `..`, đường dẫn tuyệt đối, `\`, NUL, thư mục lạ) và còn kiểm đường dẫn chuẩn hoá nằm trong thư mục đích (`isInside`, bắt cả symlink) — chống
zip-slip; (3) `project.json` lưu đường dẫn TUYỆT ĐỐI nên được viết lại theo thư mục của máy này (`rebasePath`); (4) ghi ra `.restore.part` rồi đổi tên; (5) trần 6 GB giải nén (zip bomb). **Đã kiểm trên đĩa**
bằng bản Python (`backup_check.py`): 16 mẫu tên entry, rebase, khôi phục một ZIP có entry hợp lệ + `../` + tuyệt đối + `signatures/` + tệp đã tồn tại (đếm đúng 3 ghi / 1 bỏ qua / 4 từ chối, không tệp nào
rơi ra ngoài, không để lại `.part`), symlink thoát thư mục, ZIP lạ phải báo lỗi.

**Thông tin tài liệu PDF — `PdfMetadataTools`.** Mục "Sửa thông tin tài liệu" và "Xoá thông tin ẩn" trong menu của thẻ Mật khẩu & watermark. PDF có thể giữ tiêu đề HAI nơi: từ điển Info và gói XMP
(`/Metadata` của catalog); nhiều trình đọc ưu tiên XMP nên chỉ sửa Info vẫn hiện tiêu đề CŨ. Cả `write` và `strip` đều bỏ gói XMP cấp tài liệu. `strip` xoá toàn bộ Info (tác giả, phần mềm, ngày) +
XMP; KHÔNG đụng nội dung trang, metadata từng trang, tệp đính kèm — là "gỡ nhãn", không phải làm sạch pháp y. **Đã kiểm ý tưởng** bằng pikepdf + poppler (`metadata_check.py`): chỉ sửa Info → `pdfinfo -meta`
vẫn còn XMP cũ; bỏ `/Metadata` → tiêu đề mới hiện; strip → hết Title/Author/Creator/Producer; trường trống bị xoá. KHÔNG kiểm được code PdfBox thật.

**Mức tin cậy API mới (chưa biên dịch)** — cùng cách bảng ở 4.18:

| API | Tin cậy | Ghi chú |
|---|---|---|
| `PDPageContentStream(doc, page, AppendMode.APPEND, true, true)`, `drawImage`, `LosslessFactory.createFromImage` | Cao | đã dùng ở `PdfSecurityTools.watermark` |
| `PDPageContentStream.transform(Matrix)`, `PDType1Font.HELVETICA`, `beginText/newLineAtOffset/showText` | Cao–Trung bình | API 2.0.x chuẩn; font dựng sẵn cần `PDFBoxResourceLoader.init` (đã có) |
| `documentCatalog.metadata = null`, `PDDocumentInformation.title = null` | Trung bình | theo mã PDFBox 2.0: `setItem/setString` với null thì xoá khoá; chưa thử trên PdfBox-Android |
| `PrintedPdfDocument`, `PrintDocumentAdapter` (`onLayout`/`onWrite`) | Cao | theo tài liệu Android; luồng riêng + `Handler` về main để gọi callback |
| `BiometricManager.canAuthenticate(int)`, `BiometricPrompt(FragmentActivity, Executor, Callback)`, `Authenticators.*` | Cao | androidx.biometric 1.1.0 |
| `ActivityResultContracts.CreateDocument(String)` | Cao | `activity-ktx 1.9.2` (hàm tạo có tham số mime từ 1.7) |
| `DocumentsContract.deleteDocument` để dọn ZIP dở | Trung bình | có thể ném lỗi với một số provider — bọc `runCatching` |

**Rà tĩnh mới — `static_refs_check.py`.** Không có trình biên dịch, nên viết script bắt lớp lỗi hay gặp: mọi `R.*` và `@…/…` tồn tại, không trùng tên string/android:id, mọi `binding.x` ứng với một `android:id`
trong layout của chính Binding đó, ngoặc `{} () []` cân bằng (bỏ qua chuỗi/chú thích), Activity ↔ manifest, và (bổ sung sau run #11 và #15) mọi tên lớp CamelCase được dùng đều có nguồn (import / khai báo trong dự án / mặc định Kotlin-Java) — bắt `Unresolved reference` do thiếu import — cùng tham số hàm tạo (thiếu tham số bắt buộc / tên lạ khi gọi bằng toàn tên tham số — bắt đúng lỗi `onPrint` của run #15) cùng `Object.thanhvien` với object nội bộ (FileUtils, PdfExporter, AppLock…) thì thành viên phải được khai báo — bắt gọi nhầm tên hàm. Bộ tiền xử lý GIỮ mã trong chuỗi mẫu `"${…}"` (lần đầu viết bỏ cả chuỗi mẫu nên một lời gọi sai tên nằm trong `"${FileUtils.x()}.pdf"` lọt qua; phát hiện nhờ thử âm tính, đã sửa). Có thử âm tính: sửa cố ý 3 chỗ (tên string, tên view, thêm `(`) → script báo đủ 3; gỡ 2 import thật + thêm 1 tên lạ → báo đủ 3 → khôi phục → sạch. Chạy trên TOÀN BỘ mã (kể cả phiên 1-14, chưa từng biên dịch) không tìm ra thiếu import hay thành viên object sai tên nào — nhưng run #15 vẫn đỏ ở biên dịch Kotlin, tức lỗi nằm ở lớp mà script này không thấy (kiểu dữ liệu, số/tham số, lời gọi vào PdfBox/AndroidX, override, null-safety): đúng như đã cảnh báo.
Nó KHÔNG phát hiện lỗi kiểu (type), tên hàm, tham số, thiếu `override`, null-safety — những thứ chỉ `gradle assembleDebug` mới bắt; lần build Gradle đầu tiên vẫn có thể lộ lỗi biên dịch.

**Giới hạn đã biết của phiên này (nói thẳng, kèm hướng giải quyết):**
- Chữ ký ở 4.22 chỉ là hình ảnh. Chữ ký SỐ thật đã làm ở 4.24 (chứng thư tự ký, khoá trong Android Keystore; KHÔNG dùng BouncyCastle dù `bcpkix 1.72` có sẵn trong cây phụ thuộc — lý do ở 4.24). Còn lại: chứng thư của tổ chức cấp công cộng, dấu thời gian, LTV, dấu hiển thị.
- Khoá ứng dụng chưa thử trên máy thật; nhớ thử: mở picker/camera rồi quay lại <60 s và >60 s, xoay màn hình, gỡ khoá màn hình trong Cài đặt rồi mở lại app.
- Sao lưu chưa có mã hoá file ZIP và chưa có lịch tự động; ZIP chứa tài liệu ở dạng rõ — người dùng tự bảo quản.
- Chưa làm trong số ưu tiên của file PDF (cập nhật ở 4.23: tìm kiếm/sắp xếp/yêu thích và N-up/booklet đã làm): preset thẻ căn cước/hộ chiếu, tự đặt tên theo nội dung, thẻ/thư mục trong lịch sử, xử lý hàng loạt, điền biểu mẫu, so sánh PDF,
  redaction thật, PDF→Word/Excel, TTS, dịch. Mục 10 xếp thứ tự.

### 4.23. Phiên 15 (tiếp) — lịch sử: tìm kiếm / sắp xếp / yêu thích; gộp trang & in sổ gấp

Làm tiếp danh sách "chưa làm" của 4.22 sau khi người dùng báo build (GitHub Actions) THÀNH CÔNG. Chọn hai mục tái dùng được nền đã kiểm chứng; mục còn lại xem mục 10.

**Lịch sử: tìm kiếm, sắp xếp, yêu thích — `HistoryFilter`, `FavoriteStore`, `HistoryAdapter`, `MainActivity`.** Ô tìm kiếm + nút sắp xếp nằm giữa tiêu đề "Tài liệu đã xuất" và danh sách; chỉ hiện khi có ít nhất một tài liệu.
Tìm KHÔNG phân biệt hoa-thường và DẤU (người dùng điện thoại thường gõ không dấu: "hop dong" phải ra "Hợp đồng thuê nhà.pdf"): `normalize` = hạ chữ → NFD → bỏ dấu kết hợp (`\p{Mn}`) → `đ`→`d` (NFD không tách `đ`).
Nhiều từ trong truy vấn phải ĐỀU xuất hiện (AND, mọi thứ tự); khớp theo chuỗi con (nên "don" cũng khớp "dong" — chủ ý, giống ô tìm kiếm thông thường). Sắp xếp: Mới nhất / Tên A–Z (theo tên đã bỏ dấu) / Lớn nhất; **sao đứng trên cùng**,
trong mỗi nhóm áp dụng kiểu sắp xếp, hai mục bằng nhau giữ nguyên thứ tự (sắp xếp ổn định). Kiểu sắp xếp được nhớ giữa các lần mở (`history_view`). `refreshHistory()` đọc thư mục; `renderHistory()` chỉ lọc/sắp xếp lại (mỗi lần gõ phím không đụng ổ đĩa).
Sao lưu theo TÊN TỆP (`FavoriteStore`); `prune` bỏ tên của tệp không còn (xoá/đổi tên ngoài app) để sao không "sống lại" trên tệp mới trùng tên. `HistoryAdapter` thêm hai tham số CÓ GIÁ TRỊ MẶC ĐỊNH (`onToggleFavorite = null`, `isFavorite = { false }`)
nên `ProjectSummaryActivity` không phải sửa và không hiện nút sao (bài học B15-03: lần trước thêm tham số bắt buộc làm hỏng nơi gọi thứ hai). Khi tìm không ra gì nhưng vẫn có tài liệu, hiện "Không có tài liệu nào khớp" thay vì thông báo "chưa có tài liệu".
**Đã kiểm:** `history_filter_check.py` — 18 ý (chuẩn hoá chữ hoa/`Đ`, NFC ≡ NFD, không dấu ↔ có dấu hai chiều, AND nhiều từ, truy vấn trống, ba kiểu sắp xếp có/không yêu thích, ổn định). Java `Normalizer` và Python `unicodedata` cùng chuẩn Unicode; phần giao diện CHƯA chạy.

**Gộp trang & in sổ gấp — `PdfImposer` (+ `PdfPageGeometry.inverseMatrixValues`), thẻ "Gộp trang & in sổ gấp".** Ba chế độ: 2 trang/tờ (A4 ngang), 4 trang/tờ (A4 dọc, lưới 2×2, kẻ viền xám mảnh quanh từng trang), Sổ gấp (A4 ngang). Mỗi trang nguồn thành một Form XObject (chữ vẫn là chữ, không rasterize)
rồi được vẽ bằng ma trận `[co vừa ô + căn giữa] × [nghịch đảo ma trận hiển thị]`: nghịch đảo đưa toạ độ riêng của trang về trang ĐANG HIỂN THỊ (nên `/Rotate 90`, CropBox lệch vẫn đứng thẳng), `fit` co vừa ô giữ tỉ lệ. `LayerUtility` chỉ dùng để sao chép tài nguyên sang tài liệu mới;
phần xử lý `/Rotate` của chính nó KHÔNG được dựa vào: mã xoá `/Matrix` của form và đặt lại `/BBox` = CropBox, để hình học đúng là hình học đã kiểm. Sổ gấp: đệm trang trống cho đủ bội số của 4; tờ k mang (mặt trước trái/phải) `p-1-2k, 2k` và (mặt sau trái/phải) `2k+1, p-2-2k`;
in hai mặt, lật theo CẠNH NGẮN, gấp đôi chồng giấy (hộp thoại sau khi lưu nhắc điều này). **Đã kiểm:** `imposition_check.py` — lưới ô nằm trong tờ và không chồng nhau, `fit` không tràn và căn giữa; thứ tự sổ gấp cho MỌI số trang 1..60 (mỗi trang đúng một lần,
hai mặt cộng đúng `p-1`, các lá (2j, 2j+1) là hai mặt của cùng một mảnh giấy, lá lồng nhau, trang trống chỉ ở cuối; mẫu 8 trang = 8,1 | 2,7 | 6,3 | 4,5); và **8 tổ hợp** xoay 0/90/180/270 × (không CropBox | CropBox lệch gốc âm) cho cả 2-up và 4-up bằng poppler, đo màu ba góc + tâm của MỖI trang đã đặt
(đúng ô, đúng chiều). Lưu ý khi viết test: poppler làm tròn A4 lên số nguyên điểm ảnh (lệch ≤ 1 px) nên kiểm cỡ ảnh phải có dung sai — lần đầu so bằng đúng làm cả 8 dòng báo lỗi dù từng trang đều đúng.
KHÔNG kiểm được các lời gọi PdfBox thật (`LayerUtility.importPageAsForm`, `PDFormXObject.setBBox`, `PDPageContentStream.drawForm/addRect/stroke`): `LayerUtility`/`drawForm` là API 2.0.x ổn định nhưng chưa chạy trên PdfBox-Android; xem mục 10.

### 4.24. Phiên 15 (tiếp) — chữ ký SỐ thật (chứng thư tự ký, khoá trong Android Keystore)

Khác chữ ký hình ảnh của 4.22 (`PdfStamper`): đây là chữ ký mật mã — trình đọc hiện bảng chữ ký, và sửa MỘT byte của phần đã ký thì báo "tài liệu đã bị thay đổi". Hai tính năng bổ trợ nhau (đóng dấu hình ảnh TRƯỚC, ký số SAU CÙNG).
Người dùng không chọn cụ thể giữa các hướng ở cuối lượt trước mà bảo "làm tiếp"; đã làm theo phương án mình đề xuất: chứng thư TỰ KÝ.

**Quyết định kiến trúc (đổi so với kế hoạch cũ ở 4.22/mục 10): KHÔNG dùng BouncyCastle.** Kế hoạch cũ dựa vào `bcpkix 1.72` có sẵn trong cây phụ thuộc của PdfBox-Android. Bỏ vì: (1) Android có provider "BC" riêng (bản rút gọn, cùng tên) nên phải gỡ/gắn provider cho đúng — cạm bẫy kinh điển;
(2) chưa chắc `bcpkix` nằm trên classpath BIÊN DỊCH (POM có thể khai báo `runtime`); (3) phần cần thiết chỉ ~150 dòng DER. Thay bằng: `DerWriter` (viết DER: TLV, OID, INTEGER, UTCTime, SET OF có sắp xếp) + `CmsSigner` (SignedData tách rời) + `java.security.Signature("SHA256withRSA")` có sẵn của Android.
Chứng thư và khoá: `KeyPairGenerator("RSA", "AndroidKeyStore")` với `KeyGenParameterSpec` (RSA-2048, SHA-256, PKCS#1 v1.5, `setCertificateSubject/SerialNumber/NotBefore/NotAfter`) — Keystore TỰ sinh chứng thư tự ký đi kèm khoá (API 23+, minSdk dự án là 24). Khoá nằm trong kho bảo mật của máy (có phần cứng nếu máy hỗ trợ),
KHÔNG xuất ra được. Hiệu lực chứng thư 25 năm (Adobe kiểm hạn chứng thư theo thời điểm hiện tại nếu không có dấu thời gian).

**Cấu trúc CMS (đã kiểm với hai trình kiểm khác nhau).** `ContentInfo{ signedData, [0]{ SignedData{ version 1, digestAlgorithms{SHA-256}, encapContentInfo{data} (tách rời: không có nội dung), [0] chứng thư, signerInfos{ SignerInfo{ version 1, IssuerAndSerialNumber, SHA-256,
[0] signedAttrs{contentType, signingTime (UTCTime), messageDigest}, sha256WithRSAEncryption, chữ ký } } } } }`. **Cạm bẫy kinh điển:** chữ ký tính trên các thuộc tính ký ĐÓNG GÓI VỚI THẺ SET (0x31) nhưng được LƯU với thẻ ngữ cảnh `[0]` (0xA0) — cùng nội dung, byte đầu khác; mã tạo cả hai từ một nội dung đã sắp xếp.
Thuộc tính trong SET được sắp tăng dần theo mã hoá (X.690 11.6: so như chuỗi byte, ngắn hơn đệm 0 ở cuối). Issuer và serial lấy NGUYÊN BYTE từ TBSCertificate bằng một bộ đọc DER nhỏ (có xử lý chứng thư v1 không có phần `[0]` version) thay vì dựng lại tên từ `X500Principal` — tránh khác biệt chuẩn hoá tên.

**Ghép vào PDF — `PdfDigitalSigner.sign`.** PdfBox: `PDSignature` (Filter `Adobe.PPKLite`, SubFilter `adbe.pkcs7.detached`, tên, lý do, ngày) + `doc.addSignature(signature, SignatureInterface)` + `doc.saveIncremental(out)`: chữ ký là bản CẬP NHẬT TĂNG DẦN nối vào cuối tệp (byte gốc không đổi). `SignatureInterface` nhận luồng "mọi byte trừ khối /Contents" (đúng /ByteRange), băm SHA-256 rồi gọi `CmsSigner`. Chỗ dành sẵn cho chữ ký là mặc định của PdfBox (9472 byte); CMS của ta ~1,2 KB.
Chữ ký không hiển thị (không có khung nhìn) — muốn có dấu thấy được thì đóng dấu hình ảnh trước. **Hệ quả cần nói rõ cho người dùng:** sau khi ký, KHÔNG được chạy tệp qua bất kỳ công cụ nào khác của app (nén, số trang, mật khẩu, gộp trang... đều ghi lại cả tệp và làm mất hiệu lực chữ ký) — hộp thoại xác nhận nhắc điều này. Lối vào: menu của thẻ "Mật khẩu & watermark" → "Ký số". Lần đầu hỏi tên người ký rồi tạo khoá; các lần sau hiện chứng thư (tên, hạn, dấu vân tay SHA-256) kèm nút Xoá chứng thư; sau khi ký có nút "Chia sẻ chứng thư (.cer)" (chỉ chứng thư công khai, không bao giờ là khoá).

**Chứng thư tự ký nghĩa là gì (nói thẳng).** Chữ ký chứng minh "đúng tệp này, nguyên vẹn từ lúc ký, bởi người giữ khoá này"; nhưng không trình đọc nào tin DANH TÍNH người ký cho tới khi người nhận chấp nhận chứng thư — Adobe sẽ báo "chưa được tin cậy". Chứng thư của tổ chức cấp chứng thư công cộng (AATL/EUTL) phải mua từ nơi khác, ứng dụng không tự tạo được.
Chưa có: dấu thời gian (RFC 3161), thông tin thu hồi/LTV, chuỗi chứng thư, dấu hiển thị, ký nhiều người, chứng thư nhập từ tệp .p12.

**Đã kiểm (`digital_signature_check.py` + `CmsCheck.java`).** `CmsCheck.java` là bản Java song song CHẠY ĐƯỢC của `DerWriter.kt` + `CmsSigner.kt` (cùng thuật toán, cùng thứ tự; khác ở chỗ khoá lấy từ tệp). Script Python dựng PDF viết tay một trang, cập nhật tăng dần thêm trường chữ ký (widget + AcroForm) với /ByteRange, đưa phần cần ký cho Java, gắn CMS vào /Contents, rồi:
`pdfsig` (poppler) phải báo "Signature is Valid", nhận `adbe.pkcs7.detached` và SHA-256; `openssl cms -verify` phải "Verification successful". Thử với HAI loại chứng thư tự ký: v3 không extension có tên tiếng Việt (giống chứng thư Keystore) và v1 (không có phần `[0]` version — kiểm đường đi của bộ đọc DER). Thử âm tính: sửa 1 byte vùng đã ký → cả hai báo sai; hỏng 1 byte trong khối chữ ký → pdfsig báo sai.
Cả 15 ý đều đạt (CMS ~1,2 KB, vừa chỗ dành sẵn). **KHÔNG kiểm được:** các lời gọi Keystore (`KeyGenParameterSpec`, `KeyPairGenerator("AndroidKeyStore")`), bản Kotlin của bộ dựng (là bản dịch tay từ Java), `PDSignature`/`addSignature`/`saveIncremental` của PdfBox-Android, và việc `saveIncremental` chạy đúng với tệp dùng xref stream/object stream do `PdfStructureOptimizer` tạo.
**Việc phải thử trên máy:** ký một PDF do chính app xuất → mở bằng Adobe Acrobat Reader và một trình đọc khác; chữ ký phải báo nguyên vẹn (có thể "chưa tin cậy"); sửa tệp bằng một tool khác rồi mở lại: phải báo đã thay đổi. Nếu `saveIncremental` lỗi với tệp xref-stream, phương án dự phòng: đọc tệp nguồn bằng PdfBox rồi lưu lại dạng bảng xref cổ điển trước khi ký.

### 4.25. Phiên 15 (tiếp) — đổi tên/gợi ý tên, xử lý hàng loạt, ghép thẻ lên A4, so sánh PDF, điền biểu mẫu

Người dùng bảo "làm hết" các mục còn lại của file "Thiếu gì để bán app". Làm đủ năm mục; mỗi mục có phần thuần được kiểm bằng script, các lời gọi Android/PdfBox chưa chạy trên máy.

**Đổi tên và gợi ý tên từ nội dung — `SmartNamer`, `PdfPageBitmap`, nhấn giữ một dòng trong lịch sử.** Menu: "Đổi tên" (mọi loại tệp) và "Gợi ý tên từ nội dung (đọc trang 1)" (PDF): dựng trang 1 bằng `PdfRenderer`, OCR (`OcrHelper.recognize`, bảng chữ Latin có tiếng Việt), `SmartNamer.fromText`, rồi mở hộp đổi tên ĐIỀN SẴN gợi ý để người dùng sửa.
Chọn tiêu đề: bỏ các dòng quốc hiệu ("CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", "Độc lập - Tự do - Hạnh phúc"), trong 20 dòng đầu lấy dòng ĐẦU TIÊN bắt đầu bằng từ thường mở tiêu đề (hợp đồng, biên bản, đơn, giấy, hóa đơn, quyết định, thông báo, báo cáo…; so không phân biệt hoa-thường và dấu); không có thì lấy dòng đầu tiên trông như chữ (≥ 4 chữ cái và ≥ một nửa ký tự là chữ — loại ngày, mã vạch, đường kẻ).
Tên được làm sạch ký tự cấm (`\ / : * ? " < > |`), gộp dấu cách, cắt 60 ký tự, và không trùng ("tên (2).pdf"). Đổi tên PDF cũng đổi tệp `.txt` OCR đi kèm và chuyển SAO (`FavoriteStore.rename`). `HistoryAdapter` thêm tham số `onLongClick` MẶC ĐỊNH null (bài học B15-03: không phá nơi gọi khác).
**Đã kiểm:** `smart_namer_check.py` — 25 ý (tiêu đề tiếng Việt sau quốc hiệu, sau tên công ty, dấu đầu dòng, không có từ khoá, tiếng Anh, chỉ xét 20 dòng đầu, tên dài, trùng tên trên đĩa thật, `derivedBase`). OCR trên máy thật CHƯA thử; chữ in nhỏ hoặc ảnh mờ cho kết quả kém, nên luôn có bước người dùng sửa trước khi đổi.

**Xử lý hàng loạt — `BatchProcessor`, thẻ "Xử lý hàng loạt".** Chọn NHIỀU PDF (`OpenMultipleDocuments`), chọn một thao tác dùng chung: đánh số trang ("Trang n / N" giữa đáy), watermark (hỏi chữ), mật khẩu (hỏi mật khẩu), xoá thông tin ẩn, gộp 2 trang/tờ — chỉ chọn thao tác cần nhiều nhất MỘT tham số để một câu trả lời dùng cho mọi tệp. Từng tệp xử lý độc lập ra TỆP MỚI `<tên gốc>_<hậu tố>.pdf` (không trùng tên), tuần tự, hộp thoại tiến độ "i / n"; một tệp lỗi (PDF có mật khẩu, hỏng) được liệt kê và các tệp còn lại vẫn chạy tiếp. Nén được để ngoài vì cần chọn mức nén. **Đã kiểm:** tên đầu ra (`derivedBase`) bằng `smart_namer_check.py`; các thao tác gọi lại những hàm đã có.

**Ghép thẻ lên A4 — `IdCardComposer`, thẻ "Ghép thẻ lên A4".** Hai khổ: ID-1 (CCCD, GPLX, thẻ ngân hàng/BHYT, 85,6 × 53,98 mm) và trang hộ chiếu (125 × 88 mm). Mỗi ảnh: tìm 4 góc thẻ bằng `ImageProcessor.detectDocumentCorners`, nắn phẳng (`warpDocument`), xoay ngang nếu đang dọc, cắt phần thừa theo ĐÚNG tỉ lệ thẻ (`cropToAspect`), co về 300 dpi ở kích thước thật; không tìm thấy khung (thẻ chiếm cả ảnh, nền rối) thì cắt phần giữa ảnh.
Mặt trước đặt trên, mặt sau dưới, cách nhau 28 pt (~10 mm), căn giữa trang cả hai chiều, kẻ viền xám mảnh như bản photo.
**Chiều của thẻ (đã khắc phục sau phản hồi "sao không tra cứu khắc phục hạn chế"):** bản đầu chỉ xoay thẻ dọc thành ngang nên thẻ chụp ngược đầu vẫn ngược. Nay dùng lại `PageOrientation.detectCcwDegrees` (bộ nhận chiều của luồng quét trang, đã kiểm 480 trang văn bản, 0 sai) trên thẻ đã nắn phẳng: số trả về thì xoay đúng số đó.
Thẻ khác trang văn bản (5-8 dòng ngắn, ô ảnh, nhiều dòng IN HOA) nên đã ĐO riêng bằng `card_orientation_check.py`: 192 ảnh thẻ giả (CCCD và GPLX, 4 font, mọi hướng xoay, nghiêng ±2°, nhiễu) → **đúng 126 (66%), từ chối 66 (34%), SAI 0** (từ chối chia đều 4 hướng; 33 ca là "vertical-unknown" = chữ nằm dọc nhưng không phân biệt được 90°/270°, còn lại là không đủ bằng chứng trên chữ IN HOA). Đã thử cứu bằng cách xoay thẻ về ngang rồi nhận 0°/180° bằng chính bộ nhận chiều: chỉ cứu được 1/33 vì ngay ở chiều ngang nó cũng từ chối — không đáng đưa vào. Vì còn 34% từ chối nên thiết kế KHÔNG tự đoán: `prepare` trả `Prepared(bitmap, orientationKnown)`; khi không chắc, sau khi lưu app mở hộp thoại "Kiểm tra chiều của thẻ" với nút "Xoay mặt trước/mặt sau 180°" (chỉ cho thẻ không chắc) và tạo lại
(tệp cũ bị thay); thẻ người dùng đã tự xoay coi là đã xác định. Một thẻ ngang chỉ có thể sai đúng nửa vòng nên nút 180° là đủ. **Đã kiểm:** `idcard_check.py` — kích thước thẻ trên trang A4 dựng bằng poppler ở 300 dpi (đo được 85,6 × 54,0 mm và 125,0 × 88,1 mm), lề, khoảng cách 9,8 mm, `cropToAspect`; `card_orientation_check.py` như trên.
KHÔNG kiểm được việc tìm góc thẻ trên ảnh thật và bộ nhận chiều trên thẻ thật (ML Kit).

**So sánh hai PDF — `PdfComparer`, thẻ "So sánh hai PDF".** So bằng cách NHÌN, hộp đỏ trên BẢN MỚI; báo cáo là một PDF gồm trang đã đổi, trang MỚI THÊM (băng xanh) và trang bị XOÁ (phủ xám, băng xám), viết bằng `android.graphics.pdf.PdfDocument`.
Bản đầu so điểm ảnh thẳng và liệt kê ba "hạn chế": trang lệch/xoay/co nhẹ bị coi là khác khắp nơi; trang chèn/xoá làm mọi trang sau lệch; trang thừa chỉ được đếm. Sau phản hồi của người dùng đã tra cứu kỹ thuật chuẩn (đăng ký ảnh bằng dịch chuyển rồi so có dung sai; ghép trang bằng chuỗi con chung dài nhất) và làm:
(1) **ghép trang** — chữ ký mỗi trang = mật độ mực trên lưới 96×128, làm mờ σ=1,5, TRỪ trang trung bình của cả hai tài liệu (bỏ phần chung: lề, khoảng cách dòng — nếu không mọi trang chữ đều "giống" nhau, đo được cách biệt cùng-trang/khác-trang chỉ 0,05), chuẩn hoá; quy hoạch động tối đa hoá tổng độ tương tự các cặp ≥ 0,5. Đo trên 8 trang chữ: cùng trang bị dịch+xoay ≥ 0,865, hai trang khác nhau ≤ 0,116. Trang không ghép: ở bản mới = THÊM, ở bản gốc = XOÁ;
(2) **căn chỉnh** — dịch chuyển cả trang (SAD trên ĐỘ ĐẬM MỰC ở 1/4 độ phân giải, ±20 px; đo trên độ sáng thường cho kết quả sai vì vùng trắng lấn át), rồi (bản đầu: dịch chuyển riêng từng ô; nay thay bằng căn chỉnh AFFINE kim tự tháp, xem 4.26) tinh chỉnh ±1 px theo ô;
(3) **so có dung sai** — làm mờ σ=1 cả hai ảnh, điểm khác khi nằm NGOÀI khoảng min-max cửa sổ 3×3 của ảnh kia quá 32 mức sáng; khối 16 px đổi khi ≥ 8 điểm khác; gom khối thành vùng liên thông 8 hướng.
**Số đo (`compare_check.py`, trang chữ tổng hợp 800×1131; số cập nhật ở 4.26):** dịch (9,−6), (18,12), (−17,15): 0 hộp (không căn chỉnh: ~66% trang bị phủ); xoay tới 3° và co tới 3%: 0%. ĐỘ NHẠY vẫn giữ: đổi số tiền 1→7 và xoá một cụm chữ đều được khoanh ở CẢ 6 tình huống (không dịch / dịch / xoay 0,3°); hai trang hoàn toàn khác nhau: > 40% diện tích.
Bộ tham số (σ=1,0; ngưỡng 32; tối thiểu 8) chọn bằng quét 36 tổ hợp đánh đổi nhạy-bền: cấu hình bền hơn làm mất ca đổi chữ số.
**Kiểm bằng JVM thật:** `CompareCheck.java` là bản Java chạy được của toàn bộ thuật toán (căn chỉnh, dung sai, gom hộp, chữ ký, ghép trang) và `compare_java_check.py` cho nó và mô hình numpy (`compare_align_model.py`) xử lý CÙNG 10 cặp ảnh + một tình huống chèn/xoá/sửa trang: số hộp, hộp (IoU ≥ 0,9), dịch chuyển ước lượng và danh sách cặp ghép giống hệt. `PdfComparer.kt` là bản dịch từng bước từ Java.
**(Cập nhật ở 4.26: hạn chế xoay ≥ 1° đã được khắc phục bằng căn chỉnh affine kim tự tháp thuần Kotlin — xem 4.26.)** Giới hạn còn lại: xoay > ~3° hoặc co > ~3-5% không hội tụ; hai trang khác tỉ lệ > 2% báo "đổi cỡ" bằng một hộp trùm cả trang (đúng bản chất: bố cục khác); PDF có mật khẩu không dựng được; thời gian trên điện thoại chưa đo.

**Điền biểu mẫu — `PdfFormFiller`, `PdfFormActivity`, thẻ "Điền biểu mẫu PDF".** Với PDF CÓ ô điền sẵn (AcroForm): liệt kê ô văn bản, ô tích, danh sách chọn (bỏ ô chỉ-đọc, nút, ô chữ ký, nhóm radio), mỗi ô một dòng, lưu ra tệp mới. PDF không có ô (bản quét) → hộp thoại hướng dẫn dùng "Ký & đóng dấu PDF" → Tem → "Văn bản không khung".
**Chữ tiếng Việt là chỗ vướng:** ô văn bản vẽ giá trị bằng font trong default appearance (gần như luôn Helvetica) và PdfBox ném lỗi khi font không mã hoá được ký tự ("ạ", "ế"). Mã thử đường chuẩn (`setValue`); nếu ném lỗi thì gán `/V` trực tiếp và bật `/NeedAppearances` để trình đọc tự vẽ. **PDF đã ký số (khắc phục sau phản hồi):** bản đầu lưu cả tệp nên làm mất chữ ký. Tra cứu: PDFBox hỗ trợ cập nhật TĂNG DẦN cho biểu mẫu (PDFBOX-2859): đánh dấu đối tượng đã đổi bằng `setNeedToBeUpdated(true)` rồi `saveIncremental` — byte gốc (phần chữ ký phủ) không đổi, bản sửa nối vào cuối. Nay nếu PDF có chữ ký (`signatureDictionaries` không rỗng): gán `/V` trực tiếp, đánh dấu CẢ ĐƯỜNG từ catalog tới ô (javadoc `PDDocument.saveIncremental`: "there must be a path of objects that have `isNeedToBeUpdated()` set, starting from the document catalog" — tức catalog, AcroForm, mảng `/Fields`, mọi ô cha và mảng `/Kids`, ô, widget; chỉ đánh dấu ô thì thay đổi bị bỏ im lặng), bật NeedAppearances (không dựa vào việc PdfBox cập nhật luồng giao diện cũ, vốn không được ghi nếu không đánh dấu), rồi `saveIncremental`; PDF chưa ký vẫn lưu đầy đủ. Hộp thoại kết quả nói thẳng: chữ ký của bản gốc vẫn nguyên vẹn nhưng trình đọc báo tệp đã thay đổi sau khi ký (trừ khi người ký cho phép điền biểu mẫu).
**Đã kiểm ý tưởng** bằng `form_check.py` (reportlab dựng biểu mẫu thật + pikepdf + poppler): `/V` có chữ Việt mà KHÔNG bật cờ → ô vẫn trống; có cờ → ô có mực; ô tích đặt `/V` + `/AS` hiện dấu tích. Poppler cảnh báo thiếu font cho vài ký tự ("U+1EC5") trong môi trường thử: hiển thị đủ dấu phụ thuộc font của trình đọc. **Đã kiểm thêm bằng `signed_form_check.py` (pdfsig, bộ dựng CMS Java):** PDF có ô văn bản + chữ ký hợp lệ → nối bản cập nhật điền ô (đổi `/V`, bật NeedAppearances) → pdfsig VẪN báo "Signature is Valid", ghi nhận có thay đổi sau chữ ký, byte của tệp đã ký còn NGUYÊN ở đầu tệp mới, poppler vẽ được chữ; đối chứng: ghi lại cả tệp bằng pikepdf → chữ ký KHÔNG còn hợp lệ. KHÔNG kiểm được các lời gọi PdfBox (`PDTerminalField`, `fieldTree`, `widgets`, `check/unCheck`, `setNeedToBeUpdated`, `saveIncremental`, `signatureDictionaries`).

**"Ký & đóng dấu PDF" đổi luồng (để điền bản quét được nhiều ô).** Trước: một lần áp dụng rồi thoát và ghi ngay vào thư mục xuất. Nay: nút "Thêm vào trang" ghi vào BẢN LÀM VIỆC (tệp tạm, mở lại để xem kết quả) và cho thêm tiếp (nhiều chữ ký, nhiều ô chữ); "Lưu & thoát" mới sao chép bản làm việc thành tài liệu mới; thoát khi đã thêm mà chưa lưu thì hỏi xác nhận; số lần thêm được giữ qua việc hệ điều hành giết tiến trình. Thêm kiểu tem "Văn bản không khung" (`StampRenderer.plainText`, mực xanh đậm) — điền chữ lên bản quét. KHÔNG kiểm được giao diện này trên máy.

### 4.26. Phiên 15 (tiếp 3) — kiểm, khắc phục, làm hết ("Kiểm, khắc phục và làm hết")

Người dùng dán đoạn cuối lượt trước ("Chưa kiểm được…", "Còn lại sau khi khắc phục: xoay ≥ 1°…", "Các mục chưa làm cũ") và bảo **kiểm, khắc phục và làm hết**.

**Kiểm.** (1) Trạng thái build thật: trang Actions công khai của repo cho thấy run #18 (commit "Add files via upload" #17, 3/10 18:09) THÀNH CÔNG, debug APK 111 MB — tức mã phiên 15 tới bản vá `Geometry` đã BIÊN DỊCH được (PdfDecorator, PdfStamper, PdfMetadataTools, PdfPrintAdapter, AppLock, BackupManager… — tên API PdfBox của chúng đã được trình biên dịch xác nhận, nhưng CHƯA chạy). Mã sau đó (lịch sử/thẻ, PdfImposer, ký số, biểu mẫu, ghép thẻ, so sánh, đọc to, dịch, Word, che…) CHƯA qua biên dịch lần nào. (2) Tra javadoc PDFBox 2.0.x: `saveIncremental` chỉ ghi các đối tượng nằm trên MỘT ĐƯỜNG đánh dấu `setNeedToBeUpdated(true)` bắt đầu từ catalog — phát hiện `PdfFormFiller` mới đánh dấu thiếu (không có tổ tiên của ô, mảng `/Fields`/`/Kids`) và đã sửa (4.25). (3) Bộ nhận chiều thẻ trên thẻ thật và các hộp thoại: KHÔNG kiểm được trên máy này — đã đo trên ảnh thẻ giả (66% đúng, 0 sai) và thử cứu các ca từ chối (không được, ghi ở 4.25).

**Khắc phục: so sánh PDF xoay ≥ 1° (căn chỉnh affine kim tự tháp, thuần Kotlin).** Kế hoạch cũ là dùng OpenCV (`findTransformECC`); thay bằng cách tự làm vì kiểm được hoàn toàn trên máy này (OpenCV 5 đã đổi chỗ nhiều hàm — bài học `Geometry` — không thể thử ở đây). Chẩn đoán: với xoay 1–2° hoặc co 3%, dịch chuyển tại góc trang lên tới 16–26 px, vượt vùng tìm ±6 px quanh dịch chuyển toàn trang (27–39/54 ô sai > 2 px).
Thử khớp affine rồi tìm lại quanh dự đoán (vòng lặp): chỉ hội tụ khi xoay ≤ 2°, hỏng với co 3% (sai số mô hình tới 30 px). Cách đúng là **kim tự tháp thô → mịn** (mức 1/8, 1/4, 1/2): ở mức thô dịch chuyển nhỏ 8 lần nên vùng tìm ±2 điểm ảnh phủ ±16 px thật; mỗi mức biến đổi `b` theo affine hiện có, tìm dịch chuyển DƯ của từng ô 128 px, khớp lại affine (6 tham số, bình phương tối thiểu, loại ngoại lai với ngưỡng 8/4/2,5 px; bỏ kết quả nếu hệ số tuyến tính > 0,08), rồi biến đổi `b` mịn bằng nội suy song tuyến và tinh chỉnh ±1 px theo ô.
**Số đo (`compare_check.py`, 3 trang chữ, 54 ý):** xoay 0,3° / 1° / 1,5° / 2° / 3°, co 2% / 3%, xoay 1,5°+co 2%, xoay 2°+dịch (12,−9): **0% diện tích hộp ở cả 3 trang** (không căn chỉnh: 55–67%); độ nhạy giữ nguyên — đổi số tiền 1→7 và xoá cụm chữ vẫn được khoanh bằng ĐÚNG một hộp, không hộp thừa, kể cả khi trang xoay 2°, co 3% hoặc xoay 1,5°+co 2%+dịch; hai trang hoàn toàn khác nhau vẫn bị phủ > 60% (căn chỉnh không "làm khớp bừa"). Giới hạn đo được: co 5% không hội tụ ở 2/3 trang.
**Kiểm bằng JVM thật:** `CompareCheck.java` (bản Java song song, có thêm `warpAffine`, `leastSquares`, `estimateAffinePyramid`) cho cùng kết quả với mô hình numpy trên 15 cặp ảnh (kể cả xoay 2°, 3°, co 3%, đổi số + xoay) và ghép trang; `PdfComparer.kt` là bản dịch từng bước.

**Làm hết các mục "chưa làm" — và sửa nhận định sai.** Nhận định cũ "nén hàng loạt cần chọn mức nén" SAI: `PdfObjectRecompressor.recompress` chỉ có một chế độ → thêm thẳng vào xử lý hàng loạt.
- **Nén hàng loạt:** `BatchProcessor.Op.COMPRESS` → `PdfObjectRecompressor.recompress`. Chưa chạy.
- **Thẻ trong lịch sử:** `TagStore` (JSON `{tên tệp: [thẻ]}`), nhấn giữ → "Gắn thẻ…" (chọn nhiều + "Thẻ mới…"), nút "Thẻ" cạnh nút sắp xếp lọc theo một thẻ (đếm số tài liệu), ô tìm kiếm khớp cả chữ trong thẻ; thẻ chỉ khác hoa-thường/dấu là MỘT thẻ (`canonical`); đổi tên tài liệu mang thẻ theo; dọn thẻ của tệp đã mất. Đã kiểm `history_filter_check.py` (thêm 8 ý về thẻ).
- **Đọc to:** `SpeechReader` bọc `TextToSpeech` (ưu tiên `vi-VN`, thiếu giọng thì dùng mặc định và báo), cắt văn bản bằng `TextChunker`; Android 11+ BẮT BUỘC khai báo `<queries><intent><action android:name="android.intent.action.TTS_SERVICE"/></intent></queries>` trong manifest nếu không không tìm thấy engine (đã thêm — chi tiết dễ quên). Nguồn chữ `PdfTextExtractor`: lớp chữ PDF (PDFBox `PDFTextStripper`, từng trang) nếu đủ ≥ 20 ký tự/trang, không thì `.txt` OCR đi kèm, không thì OCR tối đa 10 trang. `TextChunker` kiểm bằng `text_chunker_check.py` (300 văn bản ngẫu nhiên: mọi đoạn ≤ max, không rỗng, đủ chữ đúng thứ tự). Giọng nói/engine CHƯA thử.
- **Dịch:** `TextTranslator` = ML Kit `Language ID` (nhận ngôn ngữ nguồn trên máy) + `Translation` (6 ngôn ngữ đích: Việt, Anh, Trung, Nhật, Hàn, Pháp); phụ thuộc `com.google.mlkit:translate:17.0.3`, `com.google.mlkit:language-id:17.0.6` (phiên bản theo tài liệu ML Kit; điều khoản ML Kit như nhận dạng chữ — đã thêm vào THIRD_PARTY_NOTICES); mô hình ~30 MB/ngôn ngữ tải lần đầu (hộp thoại báo trước và khuyên Wi-Fi), sau đó chạy offline; cặp không có tiếng Anh dịch qua tiếng Anh (chất lượng thấp hơn). Kết quả lưu `<tên>_<mã ngôn ngữ>.txt` (hiện trong danh sách). KHÔNG kiểm được (cần Google Play services/mô hình).
- **PDF → Word:** `DocxWriter` ghi gói .docx tối thiểu (ZIP + 5 phần XML), A4, lề trái 3 cm / 2 cm, Times New Roman 13 pt, `vi-VN`; chia đoạn từ văn bản OCR bằng heuristic (dòng kết thúc câu, dòng ngắn hơn 70% dòng dài nhất, hoặc dòng cuối = ngắt đoạn; còn lại nối dòng lại cho văn bản chảy); trang nối bằng ngắt trang. **Kiểm bằng hai trình độc lập** (`docx_check.py` + `DocxCheck.java`, bản Java song song chạy trên JVM): python-docx đọc lại đúng 8 đoạn, đúng chữ (có & < > ", tiếng Việt đủ dấu), khổ A4, lề; LibreOffice mở và xuất PDF 2 trang (ngắt trang có hiệu lực), chữ khớp. **Lỗi bắt được nhờ kiểm:** dấu ngắt trang đầu tiên là ký tự form feed — `trim()` coi nó là khoảng trắng và xoá mất (PDF ra 1 trang); đổi sang ký tự private-use `\uE000`. Chỉ mang CHỮ (không ảnh, bảng, cột, phông của bản gốc).
- **Che thông tin vĩnh viễn:** `PdfRedactor` + `RedactionView` + `PdfRedactActivity` + thẻ "Che thông tin vĩnh viễn". Vẽ hộp đen bằng cách vuốt; trang có hộp được dựng ở 200 dpi bằng `PdfRenderer`, hộp NUNG vào ảnh, trang thay bằng ảnh; trang không có hộp `importPage` nguyên vẹn; lưu bản mới (không đụng bản gốc; mất lớp chữ của trang đã che, dấu trang, biểu mẫu, metadata). **Vì sao không chỉ phủ đen:** `redact_check.py` chứng minh bằng poppler — hộp đen đè lên chữ thật thì `pdftotext` VẪN trích được chữ bí mật; còn bản che thật thì chữ bí mật không còn trong bất kỳ trang nào của `pdftotext` lẫn trong BẤT KỲ đối tượng/luồng nào của tệp (đã giải nén), các trang khác giữ nguyên lớp chữ và khổ trang, vùng bị che đen kín 100% và `pixelRect` làm tròn RA NGOÀI để không hở mép. Dựa vào PdfBox (`importPage`, `drawImage`) CHƯA chạy.

**Chưa làm / chưa kiểm sau lượt này (nói thẳng):** toàn bộ mã của lượt này và các lượt trước từ lịch sử/thẻ trở đi CHƯA biên dịch — lần build tới có thể lộ lỗi; đọc to (engine/giọng), dịch (mô hình), OCR gợi ý tên, tìm góc thẻ trên ảnh thật, mọi hộp thoại/màn hình Android CHƯA chạy; co > 3–5% và xoay > 3° trong so sánh PDF không hội tụ; chữ ký số chưa thử Adobe.

### 4.27. Phiên 16 — hoàn thành các mục dang dở (người dùng: "đọc kỹ tài liệu kỹ thuật … cái nào dở dang thì hoàn thành cho xong")

Đọc mục 0, 4.25–4.26, 6, 10, 11, 12 rồi chạy cả 35 script `tools/verify` đang có (đều đạt, tài liệu ↔ mã khớp); sau phiên 16 có 37 script, chạy lại toàn bộ: 37/37 đạt. Việc dở dang thật nằm ở mục 6 và dòng "nói thẳng" cuối mục 11; theo nguyên tắc của dự án
(gặp giới hạn / mục "cân nhắc nhưng chưa làm" thì TRA CỨU để giải quyết chứ không chỉ ghi nhận) đã làm các việc sau. `android-build.yml` người dùng tải kèm là bản CŨ hơn bản trong zip (thiếu bước ghi log và
tóm tắt lỗi biên dịch, B15-03) — dùng bản trong zip.

1. **Hai preset còn thiếu** — `ScanPresetApplier.Preset` giờ có 9 giá trị (thêm `BW_SAUVOLA`, `CLEAN` sau `BW`), mỗi giá trị mang `labelRes`; `PageListActivity.showBulkFilterDialog` và
   `ProjectScanActivity.showPresetDialog` dựng danh sách TỪ enum (`values()` + `getString(labelRes)`), mặc định = vị trí của `AUTO` (không còn số cứng `6`). Preset trong luồng Dự án được lưu theo NHÃN chuỗi,
   không theo thứ tự, nên thêm giá trị giữa danh sách không làm hỏng dự án đã lưu. Hai bộ lọc là đúng hai chip của `CropActivity` (`ImageProcessor.ScanFilter.BW_SAUVOLA` / `CLEAN`); khi không chạy được
   chúng trả về chính bitmap đầu vào, đã được `out !== bitmap` ở nơi gọi xử lý. Kiểm: rà tĩnh; thuật toán hai bộ lọc đã kiểm ở 4.19.
2. **Lớp chữ OCR ngay trong bước xuất / bước OCR của Dự án** — `SearchablePdfBuilder.build` có thêm tham số `onPageText` (đặt TRƯỚC `onProgress` để cú pháp lambda cuối của nơi gọi cũ vẫn hợp lệ) trả chữ từng trang
   từ CÙNG lần OCR; `embedInPlace(pdf)` = build ra `<tên>.ocr.tmp`, kiểm (`PdfVerify` trong build, số bookmark cấp cao nhất KHÔNG giảm), rồi đổi tên cũ→`.ocr.bak`, mới→tên gốc (không lúc nào mất cả hai);
   trả `null` và để nguyên PDF nếu bất cứ bước nào thất bại; `CancellationException` được ném lại. `PdfExporter.ocrExportedPdf` (chạy trong `Dispatchers.Default` vì `exportSession` được gọi từ luồng chính)
   dùng nó cho ô OCR của luồng Quét (cả đường `PdfDocument` lẫn đường `PdfCompressor`) và **rơi về `writeOcrTextFile` cũ** nếu không gắn được — ô OCR không bao giờ cho ít hơn trước. `ProjectOcrActivity` gắn
   lớp chữ vào `compressedPdfPath ?: pdfPath` (bản nén là file nhỏ mà dự án giao; nén ở bước 6 dựng lại file từ ảnh trang nên gắn trước sẽ bị mất) — bản PDF còn lại KHÔNG có lớp chữ (OCR hai lần quá tốn), tên file
   được nêu trong thông báo hoàn tất. `.txt` luôn có, theo định dạng `--- Trang N ---` như cũ. Các chuỗi "PDF chỉ chứa hình ảnh" không còn đúng đã sửa (`ocr_text_note`, `checkbox_ocr`).
3. **Ngắt dòng của `TextPdfBuilder`** — lỗi cũ: tách bằng `" "` nên đoạn tiếng Trung/Nhật (không dấu cách) là MỘT từ và chạy ra ngoài lề phải; URL/dãy số dài hơn khổ cũng tràn. Tra cứu: Android có
   `android.icu.text.BreakIterator.getLineInstance()` từ API 24 (đúng minSdk) theo UAX #14 (có quy tắc CJK: không bắt đầu dòng bằng `。、）」`). `TextWrapper.wrap` (Kotlin thuần) chọn, trong các điểm ngắt được cấp,
   điểm CUỐI CÙNG còn vừa; mảnh không có điểm ngắt mà vẫn rộng hơn khổ thì cắt theo code point + dấu kết hợp (không tách chữ khỏi dấu thanh). `text.lines()` tách xuống dòng cứng trước. Khoảng trắng cuối dòng
   không tính vào độ rộng.
4. **FB2** — `EbookBuilder.buildFb2`/`fb2Document`: `description` (title-info: genre, author, book-title, date, lang; document-info: author, program-used, date, id, version) + `body` (tên sách, mỗi chương một
   `<section>` có `<title>`; section rỗng nhận dòng "(không có văn bản)" vì section bắt buộc có `<p>`). Thứ tự phần tử theo lược đồ FictionBook 2.x (tra cứu GitHub gribuser/fb2, MobileRead, ví dụ thật). UI: ô `cbFormatFb2` (mặc định
   TẮT) trong `activity_ebook_editor.xml` dùng chung cho `EbookExportActivity` và `ProjectEbookActivity`; `wantFb2` thêm vào cả hai `SavedState` (đặt CUỐI, mặc định `false`; tệp trạng thái cũ không có khoá → false);
   `ConvertDocumentActivity` thêm đích FB2 cho nguồn EPUB và TXT (`pendingTargetIsPdf: Boolean` → enum `Target`). **Việc sửa kèm theo:** `EbookBuilder.esc` (dùng cho EPUB) trước đây KHÔNG loại ký tự mà XML 1.0 cấm hẳn
   (mã điều khiển U+0000–0008, 000B, 000C, 000E–001F, surrogate lẻ, U+FFFE/FFFF) — văn bản lấy từ OCR hoặc lớp chữ PDF có thể chứa chúng và làm EPUB không mở được; nay `xmlSafe` loại chúng (B16-02). MOBI/AZW3 vẫn KHÔNG làm (quyết định 11).

**Kiểm chứng (mức cao nhất đạt được: chạy trên JVM/Python với công cụ độc lập; Kotlin chưa build):**

| Script | Làm gì | Kết quả / thử âm tính |
|---|---|---|
| `text_wrap_check.py` (+ `WrapCheck.java`) | Java chạy đúng thuật toán `TextWrapper`; độ rộng đo bằng phông THẬT Noto Sans CJK (PIL); 12 đoạn mẫu (Trung, Nhật, Hàn, Việt NFC/NFD, Anh có gạch nối, URL, dãy số, trộn, nhiều dấu cách, 1 ký tự, từ NFD dài) x 3 khổ (515/120/40) + 300 đoạn ngẫu nhiên x 3 khổ: không dòng vượt khổ (đo lại bằng `getlength` cả dòng), không mất/thêm chữ, mỗi chỗ ngắt là điểm ngắt được cấp hoặc cắt cưỡng bức đúng lúc, tham lam (kéo tới điểm kế tiếp thì vượt khổ) | đạt. Thuật toán CŨ làm tràn ZH/JA/URL/DIGITS (mỗi mẫu 1 dòng tràn); **3 đột biến** (không tham lam → 14 lỗi; vượt khổ 20% → 14 lỗi; tách chữ khỏi dấu → 3 lỗi) đều bị bắt |
| `fb2_check.py` (+ `Fb2Check.java`) | 7 ca (thường, ký tự đặc biệt `<&>\"'`, mã điều khiển + surrogate lẻ + U+FFFE, chương rỗng, không chương, tên trống, đoạn 100 000 ký tự): `xmllint`, `lxml` (thứ tự phần tử, mỗi section ≥ 1 `<p>`), `pandoc -f fb2` (tên sách = Header 1, mỗi chương = Header 2, mọi đoạn đúng thứ tự) | đạt. Ký tự `\x0b` đưa thẳng vào XML bị `xmllint` từ chối (làm sạch là cần thiết); **2 đột biến** (bỏ làm sạch; đảo `lang`/`date`) đều bị bắt |

**Hai chỗ bài kiểm của chính tôi sai/hở, đã sửa (ghi để lần sau không lặp):** (a) lần chạy đầu của `text_wrap_check.py` báo 12 "LỖI" nhưng cả 12 là lỗi của BÀI KIỂM: không phân biệt ngắt ở dấu cách với cắt giữa từ (dòng xuất ra đã bỏ khoảng trắng),
đo "dòng đầy" bằng độ rộng có kerning trong khi Java cộng độ rộng từng ký tự, và coi "không dấu đóng ngoặc đầu dòng" là tính chất của thuật toán trong khi nó là tính chất của BỘ TÁCH DÒNG (JDK không áp LB13 như ICU). Sửa
bằng cách cho Java trả cả danh sách điểm ngắt và kiểm tính chất của thuật toán độc lập với nguồn điểm ngắt. (b) Đột biến "tách chữ khỏi dấu" LỌT HAI LẦN: bảng độ rộng gán dấu kết hợp = 0 nên thêm một dấu không bao giờ làm
dòng vượt khổ và đoạn bảo vệ không bao giờ được chạy. Thêm biến thể bộ đo cho dấu rộng 4 → đột biến bị bắt (3 lỗi). Bài học: một bài kiểm chưa từng bị cố ý làm cho đỏ thì chưa chứng minh được gì.

**Chưa làm / chưa kiểm sau phiên 16 (nói thẳng):** mã Kotlin của phiên 16 (và của 4.23–4.26 như đã ghi) CHƯA biên dịch; `android.icu.text.BreakIterator` (ICU của Android, chặt hơn JDK ở LB13) chưa chạy — chỉ kiểm thuật toán với `java.text.BreakIterator`;
phông Android thật đo `Paint.measureText` (có kerning/hinting) khác bảng đo bằng PIL; lớp chữ trong bước xuất/Dự án chưa thử trên thiết bị (thời gian OCR cả tài liệu, PDF CCITT G4 sau khi PdfBox nạp/lưu lại, bookmark còn nguyên
trong trình đọc thật); FB2 chưa mở bằng FBReader/Calibre/PocketBook (chỉ `pandoc` và `lxml`); chưa có kiểm tra theo lược đồ XSD chính thức (không tải được ở đây).

### 4.28. Phiên 16 (tiếp) — kiểm đồng bộ tài liệu ↔ mã, và đối chiếu lại PDF "Thiếu gì để bán app"

**A. Tài liệu có đồng bộ với mã không?** Về cơ học: CÓ — `doc_sync_check.py` đạt và cả 37 script `tools/verify` đạt. Nhưng đọc kỹ còn 6 chỗ lệch mà script không bắt được (B16-06), đã sửa: (1) bảng mục 11 có HAI dòng đánh số 35 (do
phiên 16 thêm dòng mới mà không nhìn cuối bảng; dòng "Che thông tin vĩnh viễn" nay là 38); (2) đầu mục 11 ghi "MỌI tính năng CHƯA được build" trong khi CI run #18 đã biên dịch mã tới phiên 15; (3) đầu sổ bug (mục 7) ghi
"Kotlin chưa build lần nào"; (4) mục 6 ghi "CHƯA build thật lần nào" cho nhánh debug (nhánh `bundleRelease` mới đúng là chưa chạy); (5) mục 9 nói "54 file `.kt` hiện tại" (lúc viết là 54, nay 110); (6) mô tả thẻ "Tạo Ebook" và
"Chuyển đổi định dạng" trong `strings.xml` chưa nhắc FB2. Gốc của (2)–(4): các câu "chưa build" từ thời chưa build được lần nào vẫn nằm ở nhiều chỗ, trong khi trạng thái thật đổi theo thời gian — nay có MỘT khối duy nhất
"Trạng thái build hiện hành" ở đầu mục 0, các câu cũ là lịch sử. `doc_sync_check.py` có thêm kiểm 8: số thứ tự dòng mục 11 không trùng; mọi tên thẻ/menu trích ở cột "Điểm vào" còn tồn tại trong `strings.xml` (đã giải mã `&amp;`);
khối trạng thái build tồn tại; hai câu khẳng định sai cũ không quay lại. **4 đột biến đều bị bắt** (đánh số trùng; đổi tên thẻ; đưa lại câu "MỌI tính năng… CHƯA được build"; xoá khối trạng thái) — lần đầu một đột biến lọt vì tôi
sửa nhầm dòng tường thuật thay vì hàng bảng; nhắm lại đúng hàng thì bị bắt (kiểm tra chưa hở).

**B. PDF "Thiếu gì để bán app - DeepSeek"** (87 trang, xuất 30/9/2026, 4 lượt hỏi: thiếu gì để bán; thiếu tính năng nào; "còn gì nữa ko"; "còn nữa ko"). Đây là CHÍNH file đã đối chiếu ở phiên 15 (mục 4.22). Nó dựa trên bản
`TECHNICAL_DOCS.md` 215,6 KB — cũ hơn nhiều bản hiện tại — nên nhiều nhận xét đã lỗi thời: "chưa build lần nào" (nay mã tới phiên 15 đã biên dịch), "không có searchable PDF / mật khẩu / watermark / tự chụp / tự xoay / xoá bóng" (đều có),
"ML Kit không hỗ trợ viết tay" (không phải lý do để bỏ), "tài khoản cá nhân mới cần 20 người thử 14 ngày" (đã tra cứu: hiện là **12 người, 14 ngày liên tục**, chỉ áp dụng cho tài khoản CÁ NHÂN tạo sau 13/11/2023 — tài khoản tổ chức
được miễn). Đối chiếu từng mục với MÃ THẬT (không dựa ghi chú; nhiều lần regex lỏng báo "có" nhầm nên đã in ngữ cảnh khớp để kiểm: barcode, feedback, chỉ mục toàn văn, nhân đôi trang, outline, lịch sử phiên bản, két — tất cả KHÔNG có):

*Đã có (PDF liệt kê là thiếu):* PDF tìm kiếm được (5 hệ chữ; từ 4.27 còn gắn thẳng ở ô OCR và bước OCR Dự án); chữ ký tay + tem + ngày; ký số thật; điền biểu mẫu; mật khẩu AES-256; watermark; số trang / đầu-chân trang /
Bates; in; gộp 2/4 trang + sổ gấp; đổi tên theo nội dung; thẻ + sao + tìm không dấu + sắp xếp; xử lý hàng loạt (đánh số, watermark, mật khẩu, xoá thông tin ẩn, gộp trang, nén); sao lưu/khôi phục ZIP; khoá ứng dụng (vân tay/PIN,
chặn chụp màn hình); tự chụp khi giữ yên; tự xoay + thẳng chữ + duỗi dòng cong; xoá bóng + trắng đen Sauvola; ghép thẻ CCCD/GPLX/hộ chiếu; so sánh PDF; che thông tin vĩnh viễn; đọc to; dịch 6 ngôn ngữ; PDF→Word; sửa
thông tin PDF; FB2 (4.27); chế độ sách (tách trang đôi, Dự án + mục lục); flash bật/tắt.

*CÒN THIẾU THẬT, làm được trong mã, không cần tài khoản/máy chủ (theo thứ tự đề xuất; mỗi mục kèm cách làm):*
1. **Mở bằng / nhận chia sẻ** — manifest chỉ có `MAIN/LAUNCHER`: thêm `intent-filter` `VIEW` + `SEND`/`SEND_MULTIPLE` cho `application/pdf` và `image/*`, dẫn vào công cụ tương ứng (quản lý trang, quét, OCR). Rẻ, mở lối dùng hằng ngày.
2. **Phím tắt ứng dụng** (nhấn giữ biểu tượng: Quét, Dự án, PDF tìm kiếm được) — `shortcuts.xml` tĩnh; không có widget/shortcut nào hiện nay.
3. **Giao diện tối** (`values-night`), **tablet / màn ngang** (`layout-sw600dp`, `layout-land`; `targetSdk 36` bỏ qua khoá hướng trên màn lớn), **bản tiếng Anh** (`values-en`, 526 chuỗi), **trợ năng** (chỉ 18 `contentDescription`).
4. **Hướng dẫn + trợ giúp + màn trống có lời dẫn; gửi phản hồi; nhật ký sự cố cục bộ có nút "gửi báo cáo"** (`setDefaultUncaughtExceptionHandler` → file → `ACTION_SEND`; KHÔNG cần Firebase). Hiện không có gì.
5. **Công cụ trang PDF còn thiếu** (PdfBox thuần): chèn trang từ PDF khác, nhân đôi trang, thêm trang trắng, cắt lề (`CropBox`), đổi khổ giấy, tách theo KHOẢNG trang (5–12) hoặc theo bookmark, ghép giữ bookmark, sửa bookmark.
   Hiện `Quản lý trang` chỉ xoá/sắp xếp/xoay/tách bằng chọn từng trang trong MỘT PDF; `Ghép PDF` ghép nguyên file.
6. **Quản lý tài liệu**: chọn nhiều → xoá/chia sẻ hàng loạt, thùng rác, đổi tên hàng loạt, **tìm theo NỘI DUNG** (chỉ mục từ file `.txt` OCR và lớp chữ; hiện chỉ tìm theo tên/thẻ), thư mục.
7. **Che tự động thông tin cá nhân** (số CCCD 12 chữ số, SĐT, email, mã số thuế bằng biểu thức chính quy trên lớp chữ/OCR, rồi dùng `PdfRedactor` đã có).
8. **Xuất thêm**: PDF→PPTX (mỗi trang một ảnh), PDF→XLSX/CSV (gom hộp OCR theo cột), HTML/Markdown từ OCR; nhập `.docx`/`.md`/`.csv`→PDF (Word→PDF đúng bố cục cần engine dàn trang — chỉ làm được phần chữ).
9. **Trích trường** hoá đơn VN (MST, ngày, tổng tiền) → CSV; danh thiếp → vCard; QR/mã vạch (ML Kit `barcode-scanning`, thêm một phụ thuộc).
10. **Máy ảnh**: chụp liên tiếp, lưới, thước thăng bằng (cảm biến), phím âm lượng/tai nghe, chạm lấy nét. **Chỉnh ảnh thủ công** (sáng/tương phản/độ nét) và khử đốm. **Chú thích**: highlight/gạch chân/gạch ngang trên CHỮ (từ hộp OCR/lớp chữ), hình, mũi tên — hiện chỉ có bút màu vàng dạ.
11. Poster/tiling in, hồ sơ/preset xuất.

*Làm được nhưng rủi ro/khó kiểm hơn (để sau):* két mã hoá / thư mục ẩn (Keystore AES-GCM theo luồng), PDF/A cho bản quét (OutputIntent + XMP; cần veraPDF để kiểm — chưa tra cứu cách chạy offline), máy quét WiFi eSCL (HTTP + XML; không có máy để thử).

*Không giải bằng mã trong app:* đồng bộ đám mây thật (cần OAuth/máy chủ) — **cách thay thế đã sẵn**: sao lưu dùng Storage Access Framework nên lưu thẳng vào Drive/Dropbox/OneDrive được, và hộp chia sẻ hệ thống đã gửi được tới các app đó; cộng tác thời gian thực, SSO, bảng quản trị, API/webhook, thanh toán, white-label, Wear OS/iOS/Android Auto,
HIPAA/SOC 2/ISO 27001, dấu thời gian RFC 3161 + LTV (cần máy chủ TSA, đã ghi ở 4.24), fax, DICOM, hỏi-đáp/tóm tắt tài liệu bằng AI (cần mô hình/máy chủ).

*Không phải tính năng (từ lượt 1 của PDF), hiện trạng:* build — mã tới phiên 15 đã biên dịch (run #18), mã từ 4.23 chưa; AAB ký + `create-keystore.yml` + `versionCode` = số lần chạy CI đã có, người dùng còn phải đặt biến `APP_ID`,
chạy workflow tạo khoá và thử nhánh `bundleRelease` lần đầu; căn lề 16 KB của `.so` chưa xác nhận; **`minifyEnabled false` cả bản release** (APK debug 111 MB; bật R8 cần quy tắc giữ cho OpenCV/ML Kit/PdfBox — chưa thử);
0 unit test; icon tạm; KHÔNG có chính sách quyền riêng tư / khai báo Data safety / điều khoản trong repo (lưu ý: dịch của ML Kit tải mô hình qua mạng nên khai báo phải nói đúng); điều kiện thử nghiệm Play: 12 người × 14 ngày liên tục (tài khoản cá nhân), xem trên.


### 4.29. Phiên 16 (tiếp) — làm các mục "còn thiếu thật" của PDF (danh sách ở 4.28)

Người dùng hỏi vì sao không làm luôn những việc 4.28 ghi là "làm được trong mã, không cần máy chủ". Lý do đã nói: mã chưa biên dịch đang chồng lên — nhưng đó là quyết định của tôi, không phải giới hạn kỹ thuật; người dùng chọn làm, nên làm,
theo thứ tự rủi ro thấp trước và kiểm chứng từng phần.

**1. Mở bằng / Chia sẻ tới DocScanner.** Manifest: ba `intent-filter` trên `MainActivity` (`VIEW` + `content` + `application/pdf`; `SEND` và `SEND_MULTIPLE` cho `application/pdf`, `image/*`; không dùng `file://`). `IncomingFile.urisOf` gom URI từ
data, `EXTRA_STREAM` và ClipData; `classify` phân loại theo MIME hoặc đuôi `.pdf` (trộn PDF với ảnh → từ chối, không đoán). `MainActivity.handleIncomingIntent`: một PDF → danh sách 12 công cụ; nhiều PDF → menu hàng loạt; ảnh → thẳng vào phiên quét;
sau đó thay intent để xoay màn hình không hỏi lại. 7 màn PDF (quản lý trang, ký, số trang, biểu mẫu, che, chú thích, sửa chữ) đổi `pdfPicker` thành `onPdfChosen` (`ActivityResultCallback`) và gọi `pickPdfOrUseIncoming()`: có `intent.data` thì dùng luôn,
không thì mở bộ chọn như cũ (các nút "chọn PDF khác" giữ nguyên). Quyền đọc truyền sang màn con bằng `FLAG_GRANT_READ_URI_PERMISSION`. Kiểm: rà tĩnh; CHƯA chạy (chưa thử file từ Drive/Zalo/Gmail, chưa thử khi khoá ứng dụng bật).

**2. Phím tắt ứng dụng.** `AppShortcuts.publish` dùng `ShortcutManagerCompat.setDynamicShortcuts` vì phím tắt TĨNH (`shortcuts.xml`) phải ghi cứng tên gói, mà `applicationId` đổi theo biến `APP_ID`. Bốn phím tắt gửi `MainActivity` một `ACTION_*`; `handleShortcutIntent` mở công cụ.
Biểu tượng dùng chung `ic_launcher`.

**3. Giao diện tối.** Theme gốc đã là `Theme.Material3.DayNight` nhưng KHÔNG có màu ban đêm: trên máy bật chế độ tối, widget không đặt màu riêng (EditText, hộp thoại) nhận chữ SÁNG trên nền `@color/background` SÁNG. Thêm `values-night/colors.xml` (đủ mọi tên màu)
và `values-night/themes.xml` (cùng tên `Theme.DocScanner`, lặp lại mọi mục + `colorSurface`, `colorOnSurface`, `android:colorBackground`, `android:textColorPrimary/Secondary`) — chỉ thắng khi máy ở chế độ tối nên giao diện ban ngày KHÔNG đổi, trừ một điểm: `text_secondary`
#757575 trên nền #F5F5F5 chỉ đạt 4,23:1 (< 4,5 của WCAG AA, dùng 63 lần) → #616161 (5,66). `night_theme_check.py`: đủ tên màu, theme đêm đủ mục của theme ngày, 6 tỉ lệ tương phản x 2 bảng màu, mọi `@color/` trong layout có ở cả hai bảng; 4 đột biến bị bắt.
Chưa xem bằng mắt trên máy; các `#hex` cứng trong vài layout (viền thẻ nén `#E0E0E0`) giữ nguyên.

**4. Hướng dẫn & phản hồi + nhật ký sự cố.** `HelpActivity` (7 mục hướng dẫn, nút gửi phản hồi, gửi báo cáo sự cố gần nhất, đánh giá trên Google Play qua `market://` rồi `https://`); link "Hướng dẫn & phản hồi" ở cuối màn hình chính; màn lịch sử trống có lời dẫn.
`CrashLog`: handler lỗi không bắt ghi file văn bản trong `filesDir/crash` (giữ 3 file), chạy handler của hệ thống sau đó; lần mở sau hỏi MỘT lần có gửi không (hộp chia sẻ của hệ thống: người dùng thấy toàn bộ chữ và tự chọn ứng dụng) — KHÔNG Firebase vì
cần tài khoản + `google-services.json` và sẽ tự tải dữ liệu lên. Quyền riêng tư: báo cáo gồm phiên bản, kiểu máy, lớp ngoại lệ, dòng ngăn xếp; thông báo lỗi chứa `/` hoặc `\` bị ẩn (đường dẫn có thể mang tên tài liệu như "Hợp đồng CCCD.pdf");
thông báo không có dấu gạch vẫn giữ nên KHÔNG thể nói "không bao giờ chứa tên file" (đã sửa câu hỏi cho đúng). `crash_log_check.py` (bản Java của `describe`): ngoại lệ thật mang đường dẫn Unix/Windows tiếng Việt → báo cáo không chứa tên đó; chuỗi nguyên nhân ≤ 6 cấp;
≤ 25 dòng ngăn xếp; thử âm tính bản "ngây thơ" làm lộ.

**5. Công cụ trang PDF** (menu ⋮ của "Quản lý trang PDF"). Màn này giữ mỗi trang là ảnh JPEG 200 DPI và dựng lại PDF từ ảnh (quyết định cũ — chữ gốc không còn), nên mỗi thao tác là thao tác ảnh sinh file MỚI (xoay đang chờ được nướng vào, item mới `rotation=0`):
thêm trang từ PDF khác (`renderAllPagesToFiles` với tên file không trùng `FileUtils.newPdfEditorExtraPageFile`; chèn sau trang chọn cuối hoặc cuối cùng), nhân đôi các trang đã chọn, chèn trang trắng (cùng cỡ với trang bên cạnh; A4 nếu không có), cắt lề (% mỗi cạnh, kẹp 0–45),
đổi khổ giấy (A4/A5/A3/Letter/Legal; vừa khổ, căn giữa, giữ tỉ lệ), tách theo khoảng ("1-3, 5, 8-": mỗi phần là một PDF) và tách mỗi N trang (cũng xuất theo thứ tự + xoay HIỆN TẠI, màn vẫn mở). `PageRanges.parse` NGHIÊM NGẶT: "1-99" trong tệp 20 trang là LỖI,
không cắt lặng lẽ. Kiểm: `page_ranges_check.py` (22 ca viết tay + 20 000 chuỗi ngẫu nhiên so với bản tham chiếu Python viết ĐỘC LẬP; 3 đột biến), `page_tools_check.py` (hình học cắt lề / vừa khổ / kích thước giấy; tính chất bất biến trên 6 000 ca; 2 đột biến).
CHƯA làm: tách theo bookmark, sửa bookmark, chèn trang GIỮ vector (cần viết lại màn này trên PdfBox thay vì ảnh).

**6. Tìm theo nội dung.** `ContentIndex` đọc `<tên>.txt` cạnh PDF/EPUB/DOCX (bỏ dòng `--- Trang N ---` và dòng "không nhận diện được" vì tài liệu nào cũng có), chuẩn hoá một lần (không dấu, chữ thường), cắt 60 000 ký tự/tài liệu, ghi nhớ theo `lastModified`+độ dài. `HistoryFilter.arrange` thêm tham số
`content`: mỗi từ truy vấn phải xuất hiện trong tên, thẻ HOẶC nội dung (AND giữa các nguồn). Đọc file chạy ở nền (`warmContentIndex`); lọc theo tên/thẻ hiện ngay, kết quả nội dung hiện khi nạp xong rồi vẽ lại. `history_filter_check.py` mở rộng 9 ca (nội dung, AND giữa thẻ và nội dung, không dấu, lọc thẻ).
Chỉ tài liệu CÓ bản `.txt` tìm được theo nội dung; PDF có lớp chữ nhưng không có `.txt` thì chưa (nạp bằng PdfBox là việc nặng, để sau).

**7. Che tự động thông tin cá nhân.** Nút "Tự động tìm" ở "Che thông tin vĩnh viễn": chọn loại → OCR từng trang (ảnh 2000 px, `OcrHelper`, Latin) → ghép chữ theo dòng → `PiiDetector.find` → `wordsCovering` quy về các từ → hộp có đệm (fractions của trang) thêm vào danh sách hộp, người dùng xem lại từng trang trước khi lưu;
"Bỏ hộp tự động" xoá đúng các hộp tự động (nhận theo identity), giữ hộp vẽ tay. Quy tắc: email; số có NHÃN (CMND/CCCD 9 hoặc 12 số, MST 10/13 số, STK 6–19 số — nhãn nhận cả khi không dấu / viết hoa vì có bước `fold` cùng độ dài); thẻ ngân hàng (nhóm 4 số, 13–19 chữ số, qua Luhn);
CCCD 12 số bắt đầu bằng 0 + mã tỉnh 001–096; điện thoại di động (0/84/+84 + [35789] + 8 số, ngăn cách bằng dấu cách/chấm/gạch) và cố định (02x). Số 9–10 chữ số trơ trọi KHÔNG báo (có thể là số tiền). Ưu tiên khi trùng: email > số có nhãn > thẻ > CCCD trần > điện thoại.
`pii_check.py` (bản Java cùng `java.util.regex`): 23 ca khó + 2 000 văn bản DỰNG từ giá trị đã biết xen "mồi nhử" (số tiền, ngày, 16 số không qua Luhn, 000/097 sai mã tỉnh...) — báo đúng và chỉ đúng chúng; `wordsCovering` so với bản tham chiếu độc lập; 4 đột biến. Giả định có ghi rõ: các chuỗi số cách nhau bằng chữ.
**Bắt được 1 lỗi thật nhờ bài kiểm (B16-07):** số tài khoản có nhãn 13 chữ số tình cờ qua Luhn bị gán nhãn THẺ; sửa ưu tiên. Kết quả OCR chưa chắc đủ: số bị tách cách lạ, hoặc nằm khác dòng với nhãn, sẽ bị bỏ sót — màn hình nói rõ và yêu cầu xem lại.

**8. Trợ năng.** 30/48 `ImageView`/`ImageButton` không có `contentDescription` cũng không đánh dấu trang trí → TalkBack đọc "chưa gắn nhãn" cho từng biểu tượng thẻ ở màn hình chính. Biểu tượng cạnh nhãn chữ → `importantForAccessibility="no"`; ảnh xem trước, tay kéo, dấu chọn trang → mô tả (4 chuỗi `cd_*`).
`accessibility_check.py` giữ cho không tái diễn (cả MaterialButton chỉ-có-biểu-tượng); thử âm tính.

**Hồi quy cuối phiên 16:** toàn bộ 42 script `tools/verify` + `ci_error_summary.py --selftest` = 43/43 đạt (script cũ không bị ảnh hưởng); `static_refs_check.py` và `doc_sync_check.py` đạt. Tất cả đều là kiểm chứng trên JVM/Python — mã Kotlin chưa biên dịch.

**Chưa làm (mỗi mục kèm lý do thật và hướng đi, không phải "không làm được"):** xuất PPTX/XLSX/HTML/Markdown và PDF→Excel (viết OOXML tối thiểu như `DocxWriter`; PDF→Excel cần gom hộp OCR theo cột — lớn, cần bộ ca bảng thật để kiểm); trích trường hoá đơn VN / danh thiếp → vCard (regex như `PiiDetector`, kiểm bằng văn bản dựng sẵn);
QR/mã vạch (thêm `com.google.mlkit:barcode-scanning`, một phụ thuộc mới → phải kiểm thông báo giấy phép `THIRD_PARTY_NOTICES`); máy ảnh (chụp liên tiếp, lưới, thước thăng bằng, phím âm lượng — mã CameraX không kiểm được ngoài thiết bị); chỉnh ảnh thủ công; highlight/gạch chân trên CHỮ (cần hộp từ OCR/lớp chữ);
thùng rác, chọn nhiều → xoá/chia sẻ hàng loạt, đổi tên hàng loạt, thư mục (thay đổi cấu trúc danh sách lịch sử + `FavoriteStore`/`TagStore`); layout tablet/màn ngang; bản tiếng Anh (`values-en`: 679 chuỗi, cần script so khớp `%1$d`/khoá — `strings_check.py` đã kiểm cú pháp chuỗi); két mã hoá; PDF/A; máy quét WiFi eSCL.
Lý do chung: mỗi mục là thay đổi lớn hơn một lượt, và mã phiên 16 đã chưa biên dịch — nên build xanh trước (mục 10, 14).


### 4.30. Phiên 16 (tiếp 2) — xuất định dạng, trích hoá đơn, danh thiếp

Người dùng: "Tiếp những cái chưa làm". Theo thứ tự đã nêu ở cuối 4.29, làm nhóm có thể kiểm chứng bằng công cụ độc lập. Mọi bộ ghi/trích đều là **Kotlin thuần** (không thư viện mới → không đụng `THIRD_PARTY_NOTICES`) kèm bản Java chạy được; đáp án của bài kiểm được DỰNG từ giá trị đã biết
hoặc lấy từ công cụ bên thứ ba, không từ chính mã.

**1. Xuất HTML / Markdown / Excel / PowerPoint** — menu nhấn giữ một tài liệu: "Xuất HTML / Markdown…" (cho PDF có chữ hoặc `.txt`), và với PDF: "Xuất bảng sang Excel (.xlsx)", "Xuất sang PowerPoint (.pptx)".
- `TextExporters.html/markdown`: chữ từng trang dựng lại thành đoạn bằng `DocxWriter.paragraphsFromText` (như Word). Markdown escape các ký tự có nghĩa (`\ ` * _ [ ] < > & |`) và dấu đầu đoạn (`# + - = ~ 1.`); HTML escape `& < >`; cả hai bỏ ký tự XML 1.0 cấm.
- `PptxWriter`: ZIP gồm presentation, một slide master, một layout trống, theme đủ `fmtScheme` (3 fill / line / effect / bgFill — thiếu là PowerPoint từ chối), các slide với ảnh JPEG vừa khung, căn giữa; kích thước trang chiếu theo ảnh đầu (cạnh dài 12 192 000 EMU). Không có chữ sửa được (mô tả thay thế = "Trang N"). Giới hạn 100 trang.
- `XlsxWriter`: ZIP với workbook, styles tối thiểu và mỗi sheet một `sheetN.xml`; chuỗi nội tuyến (`inlineStr`), nên chữ bắt đầu bằng `=` KHÔNG thành công thức. Chỉ số nguyên thường (không số 0 đầu, ≤ 15 chữ số) thành số; mã (0912345678), số CCCD, "1.234" (nghìn kiểu Việt) giữ là chữ. Tên sheet theo luật Excel, không trùng.
- `TableExtractor` (PDF → Excel): OCR từng trang ở 2000 px lấy hộp từng từ → gom hàng (tâm dọc trong 0,6 x chiều cao trung vị) → gom ô (khoảng cách < 0,8 x chiều cao) → khe cột = dải mà ≤ 10% hàng nhiều ô chạm vào và rộng ≥ 0,8 x chiều cao → ranh giới đặt tại **điểm bắt đầu của phần khe không hàng nào chạm** → mỗi ô vào cột chứa cạnh trái của nó. Trang không có cấu trúc bảng ra 1 cột (một dòng chữ một hàng) và thông báo nói rõ. Tối đa 40 trang (mỗi trang ~1 giây OCR).
  **Giới hạn đã biết:** ô xuống dòng thành hàng thứ hai chỉ có một ô; hai cột cách nhau < 0,8 x chiều cao dính nhau; hàng toàn ô trống không để lại gì cho OCR thấy; bảng chỉ có một hàng nhiều ô không nhận ra là bảng; trang nghiêng > ~1 độ làm hàng lẫn nhau (cần "Tự thẳng chữ" trước); chữ không dấu Latin (OCR Latin).
- Sửa kèm: danh sách "Tài liệu đã xuất" lọc thêm `fb2, xlsx, pptx, html, md` (`fb2` bị bỏ sót từ phiên 16 trước: tệp FB2 được ghi nhưng không bao giờ hiện); `shareFile` dùng `FileUtils.mimeTypeFor` (biết cả docx, xlsx, pptx, html, md, fb2, vcf, csv) — trước đó mọi tệp ngoài pdf/epub, kể cả `.docx` đã xuất ở phiên 15, được gửi đi là `text/plain`.

**2. Trích trường hoá đơn** ("Trích thông tin hoá đơn", PDF): đọc chữ ba trang đầu (lớp chữ hoặc OCR). `InvoiceFields` tìm mỗi trường CẠNH NHÃN của nó trên chữ đã bỏ dấu + chữ thường (`PiiDetector.foldLower`, cùng độ dài nên vị trí dùng được trên bản gốc): ngày (hợp lệ ĐẦU TIÊN theo vị trí, ba kiểu viết,
31/02 bị loại), số hoá đơn, ký hiệu (nhận cả "Ký hiệu hóa đơn (Series):"), MST (10 hoặc 13 chữ số, có thể "-001"; mọi MST, theo thứ tự trang), tổng thanh toán (nhãn mạnh trước "Tổng cộng", số CUỐI trên dòng, bỏ số theo sau `%`, rơi sang dòng kế nếu dòng nhãn không có số), thuế suất, tiền thuế.
Số tiền chuẩn hoá `1.234.567,5` / `1,234,567.5` / `1234567.5` → `1234567.5`; một dấu phân cách + đúng 3 chữ số = nghìn ("1.234" = 1234, theo thói quen Việt). Hiển thị với dấu chấm nghìn, nút Sao chép và Lưu CSV (UTF-8 có BOM để Excel đọc đúng dấu). Số 9–10 chữ số trơ trọi KHÔNG bao giờ được coi là MST.

**3. Danh thiếp → liên hệ** ("Danh thiếp → thêm vào danh bạ", PDF): OCR trang đầu → `ContactCard.parse`: email và điện thoại bằng chính `PiiDetector` (số ngay sau chữ "Fax" bị bỏ, kể cả khi chung dòng "Tel: … | Fax: …"), website (giữ NGUYÊN chữ in), công ty (Công ty / TNHH / Cổ phần / JSC / Corp / Ltd / Group…), chức danh (Giám đốc, Trưởng phòng, Manager, Director, Kỹ sư…),
địa chỉ (dòng có từ khoá Đường / Phường / Quận / TP. / Tầng… VÀ có chữ số hoặc dấu phẩy, hoặc bắt đầu bằng "Số 12"), tên (2–5 từ viết hoa, không chữ số — dòng đầu tiên thoả mãn; một khẩu hiệu viết Title Case cũng thoả, nên đặt sau tên thì mới đúng). Hiện kết quả để người dùng xem, rồi MỞ form thêm liên hệ của hệ thống (`ContactsContract.Intents.Insert`; không cần quyền, ứng dụng Danh bạ lưu) hoặc lưu/chia sẻ vCard 3.0.
`toVCard`: `N` (họ = từ đầu, thứ tự Việt), `FN`, `ORG`, `TITLE`, `TEL`, `EMAIL`, `URL`, `ADR`; escape `\ ; ,` và xuống dòng; gấp dòng ở 75 BYTE (không cắt đôi ký tự UTF-8); CRLF.

**Kiểm chứng** (`export_check.py`, `extract_check.py`, `strings_check.py`; mọi mục có đột biến cố ý làm hỏng bản Java):

| Phần | Đáp án lấy từ | Kết quả |
|---|---|---|
| Bảng từ hộp chữ | bảng DỰNG từ lưới đã biết (2–6 cột, 3–14 hàng, căn trái/phải, ô trống, nhiễu ±2 px, tiêu đề dài, nghiêng 0,3°, văn xuôi + bảng) | 400 + 150 + 100 + 100 bảng khớp từng ô; từ lạc xa bên phải không sinh cột thừa; 8 đột biến bắt được |
| XLSX | `openpyxl` (giá trị, kiểu ô, tên sheet, độ rộng cột), LibreOffice (CSV); `get_column_letter` cho tên cột A..XFD | đạt; chữ `=SUM(...)` không thành công thức; mã có số 0 đầu giữ nguyên |
| PPTX | `python-pptx` (kích thước, vị trí/kích thước ảnh, nội dung ảnh, alt text), LibreOffice → PDF (đúng số trang, có ảnh) | đạt |
| HTML | `html.parser` (thẻ, chữ) + `pandoc -f html` (cấu trúc theo trang) | đạt; không thẻ lạ lọt từ văn bản |
| Markdown | `pandoc -f commonmark -t json`: chỉ Header / Para / HorizontalRule, chữ từng trang = chữ vào | 60 trang đầy `* _ # - + > 1. [x] <b> &amp; \| ` ~~~` đạt |
| Số tiền | giá trị sinh trước, in 3 kiểu | 3000 ca đạt |
| Hoá đơn | 1500 hoá đơn dựng từ giá trị đã biết (nhãn hoa/thường/không dấu, 3 kiểu ngày, số trên dòng kế, hàng tổng của bảng thuế, dòng nhiễu) | đạt |
| Danh thiếp | 1200 danh thiếp dựng từ giá trị đã biết (thứ tự dòng xáo trộn, fax mồi nhử, tên có "Quân", "Tú Vân") | đạt |
| vCard | bộ đọc RFC 2426 viết ĐỘC LẬP (gỡ gấp dòng, tách tham số, bỏ escape, tách ADR theo `;` không escape; mọi dòng ≤ 75 byte, CRLF, UTF-8 nghiêm ngặt) | 306 thẻ đạt |
| `strings.xml` | quy tắc aapt2 (nháy đơn/kép phải escape, chỉ số `%1$d`) | 679 chuỗi đạt sau khi sửa 7 chuỗi |

**Lỗi thật của mã MỚI mà bài kiểm bắt được khi viết (không phải lỗi bài kiểm):** (a) `TableExtractor`: khi một cột căn phải có vài ô dài hơn hẳn (tiêu đề "Thành tiền" rộng hơn số liệu) thì khe "dung sai" kéo dài vào đầu cột đó và đường ranh giới ở GIỮA khe xếp ô dài nhất sang cột trái. Đã thử hai hướng sai trước khi tìm ra đúng:
đo lại hai lượt có thêm ô đơn (làm mất cả khe thật khi tiêu đề kết thúc giữa khe), và trả về đoạn trống để phân biệt "tiêu đề" với "ô nhô" (không phân biệt được bằng hình học). Hướng đúng, đơn giản hơn và chỉ một lượt: ranh giới tại ĐIỂM BẮT ĐẦU phần khe không hàng nào chạm — ô nhô vào từ bên phải có cạnh trái sau điểm đó, ô nhô từ bên trái hoặc tiêu đề có cạnh trái trước nó.
(b) `InvoiceFields`: ngày chọn theo KIỂU viết thay vì theo VỊ TRÍ ("Hạn thanh toán: 15/01/2027" thắng ngày ISO ở đầu trang); nhãn "Ký hiệu hóa đơn:" có thêm chữ nên không khớp; số theo sau `%` ("đã gồm VAT 10%:") bị lấy làm tổng tiền khi số tiền nằm ở dòng kế.
(c) `ContactCard`: website trả về chữ thường không dấu (bản bỏ dấu) thay vì như in; từ khoá "quan " khớp tên "Lê Quân Việt" thành địa chỉ, "tu van" khớp "Tú Vân", "cong ty" khớp "Công Tý" — sửa: địa chỉ cần từ khoá VÀ chữ số/dấu phẩy, bỏ "tu van", "cong ty " có dấu cách.
Ngoài ra rà tĩnh bắt thiếu `import android.graphics.Bitmap` ở `MainActivity` trước khi giao (B16-17), và tôi tự thấy 4 điểm yếu của luật khi nghĩ với văn bản thật trước khi viết bài kiểm (nhãn "(Serial)" xen giữa…). Hai lần đột biến LỌT vì bộ sinh thiếu biến thể (số tiền chỉ một số trên dòng; nhãn "(Serial)" được nhánh `serial` cứu) — thêm "hàng tổng của bảng thuế" và "(Series)".

**Hồi quy cuối 4.30:** toàn bộ 45 script `tools/verify` + `ci_error_summary.py --selftest` = 46/46 đạt (gồm 3 script mới); `static_refs_check.py` và `doc_sync_check.py` đạt. Vẫn chỉ là kiểm chứng trên JVM/Python — mã Kotlin chưa biên dịch.

**Chưa làm sau 4.30 (nêu thẳng):** QR/mã vạch (thêm `com.google.mlkit:barcode-scanning` + màn quét trực tiếp bằng CameraX: không kiểm được ngoài thiết bị, và phải cập nhật màn Giấy phép); máy ảnh (chụp liên tiếp, lưới, thước thăng bằng, phím âm lượng); chỉnh ảnh thủ công (sáng/tương phản/độ nét) và khử đốm; highlight/gạch chân trên chữ; chọn nhiều → xoá/chia sẻ hàng loạt, thùng rác, đổi tên hàng loạt, thư mục;
layout tablet/màn ngang; bản tiếng Anh (`values-en`: 679 chuỗi; `strings_check.py` sẵn sàng để kiểm khoá và chỉ số đối số); két mã hoá; PDF/A; máy quét WiFi eSCL. Mọi mã phiên 16 CHƯA biên dịch — nên build xanh trước (mục 10, 14).


### 4.31. Phiên 17 -- làm các mục "chưa làm sau 4.30" (chỉnh tay + khử đốm, chú thích chữ thật, thùng rác / chọn nhiều / đổi tên hàng loạt)

**Quy tắc làm việc đã dùng:** mỗi mục tra cứu cách giải quyết TRƯỚC khi viết mã (không ghi nhận thành "giới hạn" khi chưa tra), phần logic thuần có bản Java/Python song song và kiểm chứng bằng công cụ độc lập, mã Kotlin mới chỉ qua rà tĩnh (`static_refs_check`, `strings_check`, `accessibility_check`) vì môi trường làm việc không có trình biên dịch Kotlin / Gradle.

**A. Chỉnh tay + khử đốm** (`ManualAdjust.kt`, `Despeckle.kt`, nút "Chỉnh tay" trong `activity_crop.xml`, hộp thoại dựng bằng mã trong `CropActivity`). Năm thanh trượt áp SAU bộ lọc đã chọn (sáng, tương phản, đậm màu, độ nét, khử đốm); thứ tự cố định: khử đốm -> sáng/tương phản -> bão hòa -> làm nét. Tất cả = 0 thì trả đúng ảnh cũ. Làm việc trên RGB (bỏ alpha) vì phép sáng/tương phản làm tối cả kênh alpha khi tương phản < 1. Xem trước tính lại khi nhấc ngón tay, không phải mỗi nhịp kéo (khử đốm gán nhãn cả trang). Giá trị giữ từ trang này sang trang khác của một lượt (cả cuốn sách cùng một dáng).
*Khử đốm an toàn cho tiếng Việt:* một mảnh mực chỉ bị xoá khi NHỎ (diện tích <= 6/16/36 điểm ảnh ở cạnh dài 1500 px, co theo bình phương cạnh) VÀ không có mảnh mực "đáng kể" (diện tích > ngưỡng: thân chữ, đường kẻ, khung) nào trong bán kính 0,8 x chiều cao chữ trung vị. Dấu thanh, chấm i, dấu chấm, phẩy luôn nằm sát chữ nên được bảo vệ; bụi ở lề hay giấy trắng thì bị xoá; đám bụi nhỏ trên giấy trắng cũng bị xoá hết (hàng xóm nhỏ không bảo vệ nhau). Tự gán nhãn thành phần liên thông (union-find 8 hướng) thay vì `Imgproc.connectedComponentsWithStats` để phần này kiểm chứng được từng dòng bằng Java (và không phụ thuộc chỗ OpenCV 5 chuyển hàm đi, xem 7.2 B15-03).
*Kiểm chứng:* `manual_adjust_check.py` (bản Java `ManualAdjustCheck.java`, đối chiếu scipy độc lập từng điểm ảnh; trang A4 dựng từ chữ Việt đủ dấu).

**B. Tô sáng / gạch chân / gạch ngang chữ BẰNG CHÚ THÍCH PDF THẬT** (`PdfTextMarkup.kt`, `PdfMarkupActivity.kt`, `activity_pdf_markup.xml`, thẻ "Tô sáng & gạch chân chữ" ở màn chính, mục "Mở bằng" cho PDF nhận từ app khác; `RedactionView` thêm `setBoxColors` + `showFrame`). Không rasterize: trang không đổi, chữ vẫn chọn được, mọi trình đọc xoá/di chuyển được dấu. Chọn chữ bằng hai cách: kéo khung (các từ có TÂM trong khung được tô, mỗi dòng một dải; không có từ nào thì khung chính là dấu) hoặc gõ cụm từ để tô mọi chỗ (không phân biệt hoa/thường/dấu; từ cuối khớp TIỀN TỐ như khi đang gõ dở, các từ phải liền nhau). Từ lấy bằng OCR của trang đã vẽ (`OcrHelper.recognizeLines`, 2000 px) nên bản quét và PDF số cùng một đường; đọc một lần mỗi trang rồi giữ.
*Hình học:* hộp là tỷ lệ trên trang ĐANG HIỂN THỊ (cùng quy ước với `PdfRedactor`); `quadPoints` qua `PdfPageGeometry.toUser` (xoay + CropBox xử lý một chỗ), thứ tự TL, TR, BL, BR của hộp hiển thị ("chữ Z" - thứ tự mọi trình đọc thật viết; đọc đúng chữ trong đặc tả (ngược chiều kim đồng hồ) là thứ Acrobat KHÔNG ghi). `/Rect` = hộp bao của bốn góc.
*Luồng hiển thị (AP) luôn được ghi:* nhiều trình đọc cũ không vẽ gì cho chú thích thiếu AP. Tô sáng = đa giác đặc, chế độ trộn Multiply, độ đục 0,6 (trình đọc bỏ qua Multiply vẫn còn thấy chữ); gạch chân / gạch ngang = một đoạn thẳng tính từ bốn góc (theo hướng "lên" đã hiển thị, nên đúng cả trang xoay), dày 7% chiều cao hộp, tối thiểu 0,7 pt. Dựng bằng COS thuần (`createCOSStream`, `setItem`) - cùng idiom đã biên dịch ở `SearchablePdfBuilder` - thay vì `PDAnnotationTextMarkup.constructAppearances()` (chưa chắc có trong pdfbox-android).
*Kiểm chứng:* `text_markup_check.py` (24 tổ hợp xoay x CropBox x kiểu, poppler đo; `TextMarkupCheck.java` so với tham chiếu độc lập trên 3 000 ca ngẫu nhiên). Lỗi của CHÚ THÍCH trong mã (không phải lỗi mã) được bài kiểm bắt: B17-02.

**C. Thùng rác, chọn nhiều, đổi tên hàng loạt** (`TrashStore.kt`, `BulkRename.kt`, `menu_history_selection.xml`, `HistoryAdapter` thêm chế độ chọn + `cbSelect`, nút "Chọn nhiều" / "Thùng rác (n)" ở danh sách lịch sử, `MainActivity`). "Xoá" giờ CHUYỂN VÀO THÙNG RÁC 30 ngày thay vì xoá hẳn (`confirm_delete_file*` vẫn còn vì `ProjectSummaryActivity` dùng). Thùng nằm cạnh (không nằm trong) thư mục xuất để `BackupManager` không sao lưu tệp đã xoá. KHÔNG có tệp chỉ mục: mốc xoá nằm trong TÊN (`<mili giây>__<tên gốc>`), nên không thể lệch với thư mục sau sự cố; tệp `.txt` OCR kèm PDF vào thùng cùng mốc, bị ẩn khỏi danh sách và đi theo PDF khi khôi phục; tệp lạ trong thùng không bao giờ bị liệt kê / khôi phục / dọn; mốc ở TƯƠNG LAI (đồng hồ chỉnh sai) không bao giờ hết hạn. Khôi phục khi tên bị chiếm -> `tên (2)`. Sao/thẻ của tệp bị xoá vẫn bị `prune` dọn ngay như trước (khôi phục không mang theo).
Chọn nhiều dùng `startSupportActionMode` (thanh ghim trên cùng, không cuộn mất): chia sẻ nhiều tệp (`ACTION_SEND_MULTIPLE`), xoá vào thùng, gắn thẻ (chỉ THÊM, không bớt), đổi tên hàng loạt (xem trước 3 ví dụ rồi xác nhận). Trong chế độ chọn, các nút từng dòng bị ẩn để không bấm nhầm xoá.
*Đổi tên:* mẫu `{n}` (số thứ tự đệm 0 đến độ rộng của số CUỐI), `{name}`, `{date}`; đuôi giữ nguyên; tên mới không bao giờ trùng tên đang có trong thư mục hoặc tên đã gán trong lô (không phân biệt hoa/thường); chỉ tên y nguyên của chính tệp (không đổi) hoặc tên cũ của tệp ĐỨNG TRƯỚC trong lô được phép. Việc đổi tên vẫn qua `SmartNamer.rename` (mang theo tệp OCR kèm; không bao giờ đè).
*Kiểm chứng:* `trash_rename_check.py` (bản Java `TrashCheck.java` chạy trên thư mục thật, đọc lại bằng `os.listdir`; 2 000 ca đổi tên so với tham chiếu độc lập + mô phỏng đổi tên lần lượt trên hệ tệp ảo). Mô phỏng này tìm ra lỗi thật B17-01.

**D. Quét QR / mã vạch** (`BarcodeScanActivity.kt`, `activity_barcode_scan.xml`, thẻ "Quét mã QR / mã vạch", `BarcodeContent.kt`; phụ thuộc mới `com.google.mlkit:barcode-scanning:17.3.0` - mô hình đóng gói sẵn, ngoại tuyến, cùng điều khoản ML Kit với các thư viện ML Kit đã dùng; phiên bản theo tài liệu ML Kit). Camera trực tiếp (CameraX + `ImageAnalysis`, KEEP_ONLY_LATEST, một luồng nền) hoặc "Từ ảnh"; một mã chỉ được nhận khi HAI khung liên tiếp cùng chuỗi (một khung nhiễu có thể giải sai); tạm dừng khi hộp thoại kết quả mở, tiếp tục khi đóng. `BarcodeContent` hiểu WIFI, mailto/MATMSG, tel, sms/smsto, geo, MECARD/vCard, sự kiện lịch, URL (kể cả `www.` trần), mã sản phẩm (EAN/UPC; EAN-13 bắt đầu 978/979 là ISBN). Hành động: mở liên kết (hiện ĐẦY ĐỦ địa chỉ trước - mã QR có thể giấu liên kết giả), xem/sao chép mật khẩu Wi-Fi + mở cài đặt Wi-Fi, soạn thư, gọi, soạn tin, xem bản đồ, thêm danh bạ, tìm sản phẩm; không có gì tự mở khi chưa chạm. Quy tắc đã chốt: `%HH` giải mã nhưng `+` GIỮ NGUYÊN (hợp lệ trong địa chỉ thư và số điện thoại); ngoặc kép bao quanh giá trị chỉ bị bỏ khi KHÔNG escape (mật khẩu thật sự bắt đầu/kết thúc bằng `"` được ghi `\"..\"` và phải giữ); `smsto:số:nội dung` luôn tách ở dấu hai chấm đầu tiên, chỉ `sms:số?body=` mới là truy vấn. *Kiểm chứng:* `barcode_content_check.py` (bản Java `BarcodeContentCheck.java`; vòng đi-về với bộ mã hoá Python viết riêng). Bắt được B17-03; B17-04 được phát hiện khi rà lại trước khi chạy và bài kiểm giữ ca chống tái phát.

**E. Camera: lưới, thước thăng bằng, phím âm lượng** (`GridOverlayView.kt`, `LevelIndicator.kt`, `activity_capture.xml` thêm `gridOverlay`, `swGrid`, `tvLevel`, `CaptureActivity`). Lưới chia ba bật bằng công tắc. Thước thăng bằng: gia tốc kế -> góc giữa trục Z của máy và phương đứng `acos(|gz|/|g|)` (0 = song song mặt bàn, úp hay ngửa đều được), lọc mũ hệ số 0,2, chỉ cập nhật chữ khi đổi một độ tròn, xanh khi <= 3 độ; không có gia tốc kế thì ẩn. Phím âm lượng (lên/xuống) bấm chụp, nuốt cả key-down lẫn key-up để thanh âm lượng không hiện. *Chưa làm (đã tra cứu):* chụp liên tiếp (burst) - dự án đã có chế độ tự chụp khi ổn định và thêm trang liên tục vào lượt; giữ nguyên vì thêm burst sẽ trùng chức năng. *Kiểm chứng:* `level_check.py`.

**F. Màn hình lớn / ngang** (`LargeScreen.kt`, callback `LargeScreenCallbacks` trong `DocScannerApp.kt`, id `tag_large_screen`). MỘT quy tắc trung tâm thay vì ~30 bản `layout-sw600dp`: cửa sổ rộng hơn 640 dp thì cột nội dung giới hạn 640 dp và căn giữa, hai dải bên lấy nền của gốc bố cục; áp một lần mỗi màn từ `onActivityStarted` (cùng cách với `EdgeToEdgeInsetsCallbacks`). targetSdk 36 đã bỏ khoá `portrait` trên màn >= 600 dp nên máy tính bảng / gập MỞ các màn này rộng - đây là nửa còn lại. Màn xoay quanh một bức ảnh lớn (camera, cắt, quét mã, các màn xem trang PDF) nằm trong `FULL_WIDTH_SCREENS` và dùng cả cửa sổ. *Kiểm chứng:* `large_screen_check.py` (kiểm cả việc mọi tên trong danh sách là Activity thật có trong manifest).

**G. Chuyển sang PDF/A-2b** (`PdfAConverter.kt`, `PdfAXmp.kt`, `SrgbIcc.kt`, mục "Chuyển sang PDF/A (lưu trữ)" trong menu giữ lâu của PDF; job CI `pdfa`). *Tra cứu trước khi làm:* PdfBox-Android không có `xmpbox` -> gói XMP viết tay (hình dạng cố định, thoát ký tự XML, bỏ ký tự điều khiển XML 1.0 cấm); không có `sRGB.icc` (nằm trong pdfbox-examples) và không muốn mang tệp của bên khác nên hồ sơ ICC v2.1 ma trận + đường cong được SINH từ số sRGB công khai (2 592 byte, tất định - cả ngày trong đầu hồ sơ là hằng); kiểm chuẩn bằng veraPDF: ảnh Docker chính thức `verapdf/cli`. Bộ chuyển đổi ghi: Info + XMP từ CÙNG giá trị (cùng một `Calendar` cho hai dạng ngày), OutputIntent `GTS_PDFA1` + hồ sơ N=3 (giữ nguyên nếu tệp đã có), gỡ `/AA`, `/OpenAction` JavaScript/Launch, `Names/JavaScript`, hành động nguy hiểm của chú thích, đặt cờ Print và tắt Hidden/NoView, thêm `/ID`, lưu bằng `doc.save` THUẦN (KHÔNG qua `PdfStructureOptimizer` vì nó nén lại luồng và có thể đặt bộ lọc lên luồng XMP). Điểm CHẶN (không sửa được mà không đổi nội dung nên từ chối và nói rõ lý do): mã hoá, phiên bản > 1.7, phông chưa nhúng (kể cả 14 phông chuẩn), LZW, ảnh CMYK, tệp đính kèm, chú thích (trừ Link/Popup) thiếu AP. PDF do app tạo (trang quét, chữ vô hình Type3, chú thích của `PdfTextMarkup`/`PdfStamper`) không có điểm chặn nào. *Kiểm chứng:* `pdfa_check.py` (ICC đọc lại độc lập + lcms; XMP 9 bộ giá trị; PDF mẫu qua qpdf/lcms/pdftotext; dò điểm chặn) và job CI `pdfa` chạy veraPDF `--flavour 2b` trên mẫu do `pdfa_sample.py` dựng từ ĐÚNG các byte ICC/XMP của bản Java. **Giới hạn thật thà:** mã Kotlin chưa biên dịch/chạy, và veraPDF CHƯA từng chạy ở môi trường này - lần đầu job `pdfa` chạy trên GitHub mới cho biết mẫu có đạt không; nếu đỏ, đọc phần "List the failed rules" và sửa công thức ở CẢ `pdfa_sample.py` lẫn `PdfAConverter.kt` (hai nơi phải luôn giống nhau). Chưa quét phông trong form XObject (chỉ cấp trang).

**H. Két an toàn** (`VaultCrypto.kt`, `VaultStore.kt`, `VaultActivity.kt`, `activity_vault.xml`, thẻ "Két an toàn" ở màn chính, `file_paths.xml` thêm `vault_tmp`). *Tra cứu trước khi làm:* `androidx.security:security-crypto` (`EncryptedFile`) đã bị khai tử; Tink streaming AEAD là hướng thay thế được khuyến nghị và dùng cấu trúc STREAM (Hoang-Reyhanitabar-Rogaway-Vizár). Dự án giữ cấu trúc đó nhưng viết bằng AES-GCM của nền tảng để KHÔNG thêm thư viện và để định dạng chạy được trên JVM thường (kiểm chứng chéo với bản độc lập): tệp = đầu (`DSV1`, phiên bản, log2 khối, khoá tệp 32 byte được khoá chủ bọc bằng AES-GCM, tiền tố nonce 7 byte) + các khối 64 KiB, mỗi khối AES-256-GCM với nonce = tiền tố ‖ số khối (4 byte) ‖ cờ khối-cuối (1 byte) và AAD = cả phần đầu. Khoá tệp ngẫu nhiên mỗi tệp nên nonce không bao giờ lặp dưới cùng một khoá; số khối chống đảo/nhân đôi; cờ khối-cuối chống cắt đúng ranh giới khối (thử âm tính chứng minh cần cờ); AAD bảo vệ mọi trường của đầu. Tên tệp nằm TRONG dữ liệu mã hoá (khối đầu) nên thư mục két chỉ lộ kích thước; `peekName` chỉ giải mã khối đầu. Khoá chủ là khoá AES-256-GCM trong Android Keystore (không xuất ra được); app chỉ nhờ Keystore bọc/mở khoá tệp. "Thêm" an toàn trước mất mát: mã hoá ra `.part`, GIẢI MÃ LẠI để đếm byte và so tên, rồi mới đổi tên vào và xoá sạch bản gốc (ghi đè 0 rồi xoá; trên bộ nhớ flash chỉ là cố gắng tối đa - bản mã hoá mới là thứ bảo vệ). Mở xem = giải mã vào cache rồi `FileProvider`; xoá sạch khi rời màn. Màn mở bằng sinh trắc/khoá màn hình mỗi lần nếu máy có (`AppLock.authenticate`), `FLAG_SECURE` chặn chụp màn hình và hình thu nhỏ. **Điều người dùng phải biết (đã ghi trên màn):** két KHÔNG nằm trong bản sao lưu (`allowBackup=false` và khoá Keystore không khôi phục sang máy khác) - mất máy hay khôi phục cài đặt gốc là mất két. *Chưa làm (đã tra cứu hướng):* khoá yêu cầu xác thực MỖI LẦN dùng (`setUserAuthenticationRequired` + `BiometricPrompt.CryptoObject`): bảo vệ mạnh hơn nhưng khoá bị Android huỷ khi người dùng đổi/gỡ khoá màn hình hoặc thêm vân tay mới (`setInvalidatedByBiometricEnrollment`), tức mất két ngoài ý muốn; cần quyết định sản phẩm (xuất khoá khôi phục?) trước khi bật. *Kiểm chứng:* `vault_check.py`.

**I. Quét qua Wi-Fi (eSCL / AirScan)** (`EsclProtocol.kt`, `EsclClient.kt`, `EsclDiscovery.kt`, `WifiScanActivity.kt`, `activity_wifi_scan.xml`, `network_security_config.xml`, thẻ "Quét qua Wi-Fi"). Máy quét / MFP đời từ ~2013 nói eSCL qua HTTP, không cần trình điều khiển. *Giao thức (đã tra cứu):* `GET <gốc>/ScannerCapabilities`; `POST <gốc>/ScanJobs` với `scan:ScanSettings` (`pwg:Version` 2.0, vùng quét theo 1/300 inch, `pwg:InputSource` Platen/Feeder, `scan:ColorMode`, độ phân giải, `pwg:DocumentFormat`) -> `201` + `Location`; lặp `GET <Location>/NextDocument` (`200` = một trang, `503` = bận / đang khởi động nên hỏi lại, `404` = hết trang); `DELETE <Location>`. **Dùng NGUYÊN `Location`** (tuyệt đối hoặc tương đối, giải quyết theo địa chỉ POST), không tự ghép đường dẫn: một số máy trả đường dẫn khác sách giáo khoa (SANE backends #424, #479) - thử âm tính chứng minh. Năng lực đọc theo TÊN CỤC BỘ của phần tử (tiền tố HP, không gian tên mặc định kiểu Canon đều được); vùng quét tối đa đọc TRONG phần tử của từng nguồn (khay giấy có thể dài hơn kính, máy không có kính không được mượn số của kính) - bài kiểm tra bật ra lỗi B17-05. Độ phân giải chọn gần nhất trong số máy hỗ trợ, nguồn người dùng xin mà máy không có thì dùng nguồn còn lại. Trang trả về là JPEG, đi vào hàng đợi cắt/lọc như nhập từ thư viện ảnh, mang DPI thật của máy quét nên PDF xuất ra đúng khổ giấy.
**QUYẾT ĐỊNH QUYỀN RIÊNG TƯ (người dùng cần biết):** trước phiên 17 app KHÔNG khai báo quyền INTERNET và tài liệu / README nói "chạy hoàn toàn offline". Quét eSCL cần socket tới thiết bị trong mạng nội bộ nên bắt buộc phải khai báo `android.permission.INTERNET` (quyền thường, cấp lúc cài, không hỏi) và cho phép HTTP thường (`network_security_config.xml`: máy quét nói HTTP). Biện pháp giữ nguyên tinh thần riêng tư: (1) `EsclClient` TỪ CHỐI mọi địa chỉ không thuộc mạng nội bộ (10/8, 172.16/12, 192.168/16, 169.254/16, 127/8, IPv6 ::1, fe80::/10, fc00::/7; tên máy phải phân giải CHỈ ra các địa chỉ đó) - kiểm TRƯỚC khi kết nối, cả khi máy quét (hay kẻ giả mạo) trả `Location` sang địa chỉ công cộng; (2) đây là mã duy nhất của app dùng mạng; (3) **muốn app KHÔNG có quyền Internet: xoá dòng `<uses-permission ... INTERNET>` trong `AndroidManifest.xml`** - `WifiScanActivity.isAvailable` đọc quyền lúc chạy nên thẻ tự ẩn, không cần sửa mã. Trên Google Play, mục "An toàn dữ liệu" và mô tả cửa hàng phải khớp với lựa chọn này.
*Khám phá:* `NsdManager` loại `_uscan._tcp`, khoá TXT `rs` là gốc tài nguyên (mặc định `eSCL`), phân giải LẦN LƯỢT (NsdManager chỉ phân giải một dịch vụ một lúc), bỏ phạm vi IPv6 liên kết cục bộ. Máy chỉ quảng bá `_uscans._tcp` (TLS, chứng chỉ tự ký bị nền tảng từ chối) không được liệt kê - vẫn nhập địa chỉ tay được. *Kiểm chứng:* `escl_check.py` (máy quét giả; phần thuần + máy khách bản Java `EsclCheck.java`). **Chưa kiểm:** chưa chạy với máy quét thật; `EsclDiscovery` (mDNS) chỉ viết, chưa chạy.

### 4.32. Phiên 17 (tiếp) -- công cụ cấu trúc PDF: tách theo mục lục, ghép giữ chữ + mục lục

**Lý do (phát hiện khi đọc mã):** `PdfExporter.mergePdfs` RASTERIZE từng trang rồi dựng lại bằng `PdfDocument`: PDF ghép mất lớp chữ (không chọn / tìm được nữa), mất chất lượng vector, mất mục lục và phình to nhiều lần (B17-06). Không có cách tách một cuốn sách theo chương. Hai mục B14, B15 (và đọc mục lục B3) của danh sách PDF "Thiếu gì để bán app".
**Tra cứu trước khi làm:** PdfBox 2.0 có `PDDocumentOutline` / `PDOutlineItem` (`getFirstChild`, `getNextSibling`, `getTitle`), trang đích lấy bằng `PDOutlineItem.findDestinationPage(PDDocument)` (từ 2.0.7, xem PDFBOX-3859, xử lý cả hành động GoTo lẫn đích có tên), tạo bằng `PDOutlineItem` + `PDPageFitDestination`; tách bằng `multipdf.Splitter`, ghép bằng `PDFMergerUtility.appendDocument` - cả hai nhân bản trang kèm chú thích / tài nguyên đúng cách nên được dùng thay cho `importPage`; tài liệu nguồn phải giữ mở tới khi lưu xong kết quả.
**Làm gì** (`PdfBookmarks.kt`): (1) `read` / `write` mục lục; (2) `splitFile`: một PDF cho mỗi chương ở mức mục lục người dùng chọn (mục "Tách theo mục lục…" trong menu giữ lâu của PDF; chỉ liệt kê các mức cho ra >= 2 phần; trang đứng trước chương đầu thành "Phần đầu"; mỗi phần giữ các dấu trang nằm trong chương của nó, mức lùi về 1; tên `<gốc> - 01 <tên chương>.pdf`); (3) `mergeFiles` / `mergeUris`: ghép NGUYÊN BẢN (giữ chữ, ảnh, chú thích), mục lục ghép = một dấu trang cho mỗi tệp (tên tệp, trỏ trang đầu của tệp) chứa các dấu trang của chính tệp đó lùi một mức và dịch trang; `PdfExporter.mergePdfs` thử cách này TRƯỚC, chỉ khi một nguồn không ghép được (có mật khẩu, hỏng, thiếu bộ nhớ) mới quay về cách rasterize cũ. Quy tắc: mức < 1 thành 1, mỗi mức sâu hơn mức trước tối đa 1; nhiều dấu trang cùng trang bắt đầu chỉ tính một (cái đầu thắng); dấu trang không phân giải được ra trang bị bỏ.
**Kiểm chứng:** `bookmarks_check.py` (xem README). **Chưa kiểm:** các lời gọi PdfBox-Android (`Splitter`, `PDFMergerUtility`, `findDestinationPage`) chưa biên dịch/chạy; hai lớp này nằm trong gói `multipdf` của PdfBox-Android - nếu biên dịch báo thiếu, dùng `PDDocument.importPage` cho tách và nối thủ công cho ghép.

### 4.33. Phiên 17 (tiếp 2) -- khôi phục từ thùng rác mang theo sao và thẻ

Trước đây tài liệu khôi phục từ thùng rác mất sao và thẻ vì `refreshHistory` dọn ngay các mục không còn tệp. Sao / thẻ nằm NGOÀI tệp (SharedPreferences) nên không thể đi theo tệp; giờ `MainActivity.moveToTrash` viết chúng thành tệp đồng hành `<mốc>__<tên>.meta` ([TrashMeta]: `fav=1|0` và `tag=<hex UTF-8>` mỗi thẻ, nên thẻ chứa tab / xuống dòng / `=` / emoji vẫn nguyên; giải mã dễ tính: dòng lạ bị bỏ, thiếu `fav` = không sao, thẻ trùng gộp). `TrashStore` ẩn `.meta` khỏi danh sách (như `.txt` kèm), `readMeta` đọc TRƯỚC `restore`, `restore` / `deleteForever` / `purgeExpired` / `empty` đều xoá nó cùng tệp; `MainActivity` áp lại sao (`FavoriteStore.toggle`) và thẻ (`TagStore.setTags`) sau khi khôi phục. Vẫn không có tệp chỉ mục (mốc nằm trong tên). *Kiểm chứng:* mở rộng `trash_rename_check.py` (xem README).

### 4.34. Phiên 17 (tiếp 3) -- sửa mục lục PDF

`PdfBookmarkActivity` (`activity_pdf_bookmarks.xml`, mục "Sửa mục lục…" trong menu giữ lâu của PDF): danh sách thụt lề theo cấp, chạm một mục -> đổi tên / xoá KÈM MỤC CON; "Thêm dấu trang" (tên, trang 1..N, cấp 1-3); "Lưu bản mới" ghi một BẢN SAO (`<tên> (mục lục).pdf`, `PdfBookmarks.saveWithOutline`) - trang và tệp gốc không đổi. Các phép sửa là hàm thuần của `PdfBookmarks` (chỉ số theo danh sách ĐÃ chuẩn hoá mức - đúng thứ người dùng thấy): `delete` xoá mục và các mục ngay sau nó sâu hơn; `rename` (tên trống thì không đổi); `insert` đặt dấu trang ngay sau mục cuối cùng bắt đầu ở trang đó hoặc sớm hơn (giữ thứ tự trang) rồi `normalizeLevels` sửa cấp (không bao giờ sâu hơn mức mục liền trước cho phép). Mục không phân giải được ra trang hiện "tr. ?" và bị bỏ khi lưu. *Kiểm chứng:* `bookmarks_check.py` phần A2 + B3 (xem README). **Chưa làm (mục 6.5):** liên kết nội bộ và tệp đính kèm; di chuyển / đổi cấp một mục.

### 4.35. Phiên 18 -- công cụ EPUB (sửa thông tin, đổi bìa, tách, ghép, xuất HTML/Markdown)

**Nguồn yêu cầu:** PDF "Thiếu gì để bán app" mục C (C2 siêu dữ liệu, C3 ảnh bìa, C4 tách/ghép, C8 EPUB -> HTML, C9 EPUB -> Markdown); còn ghi "chưa làm" ở 6.9 trước phiên này.

**Quyết định chính (và lý do):**
- Làm ở MỨC GÓI ZIP (`EpubTools`), KHÔNG đi qua `EpubReader` + `EbookBuilder` (đọc ra chữ rồi dựng lại): đường đó làm mất ảnh, CSS, phông và bố cục. Chỉ xuất HTML/Markdown mới dùng `EpubReader` (vì kết quả vốn là chữ).
- Sửa thông tin: chỉ thay `dc:title/creator/language/publisher/description` trong OPF, mọi tệp khác chép NGUYÊN BYTE theo thứ tự cũ; `mimetype` luôn đứng đầu và KHÔNG nén (OCF). EPUB3 cập nhật `dcterms:modified`, EPUB2 không bị thêm. Luôn ra BẢN SAO, không sửa tệp gốc. Tên/ngôn ngữ để trống = giữ cũ; tác giả/nhà xuất bản/mô tả để trống = xoá (ý người dùng).
- Đổi bìa: sách ĐÃ có bìa -> GHI ĐÈ nội dung tại CHÍNH đường dẫn cũ (trang bìa XHTML trỏ tới tệp đó nên không hỏng) và đổi `media-type` theo ảnh mới; chưa có -> thêm mục manifest + `<meta name="cover">` (+ `properties="cover-image"` với EPUB3). Cách "xoá bìa cũ, thêm bìa mới" đã thử và bỏ: để lại tham chiếu hỏng (bài kiểm có thử âm tính chứng minh điều này).
- Ghép: mỗi sách nằm trong thư mục riêng `OEBPS/b<k>/` với CÂY THƯ MỤC GỐC của nó, nên mọi tham chiếu tương đối trong XHTML/CSS vẫn đúng mà không phải viết lại nội dung. id manifest/spine thêm tiền tố `b<k>-`. Mục lục mới (nav + toc.ncx) = tên sách -> các mục của chính sách đó (đọc từ nav hoặc ncx gốc); sách không có mục lục thì mỗi trang là "Phần k".
- Tách: dùng chung hàm dựng với ghép (một sách, một đoạn spine) nhưng CẮT TỈA: chỉ giữ ảnh/CSS/phông mà các trang giữ lại (và CSS của chúng, theo `url()`/`@import`) nhắc tới, cộng ảnh bìa. Phạm vi nhập kiểu `1-5, 6-` nghiêm ngặt: phần rỗng, số sai, ngoài [1, n], ngược đều bị từ chối (không cắt lặng lẽ).

**Hạn chế đã biết (nói thẳng):** (1) tách: liên kết từ phần này sang trang nằm ở phần khác sẽ hỏng (không có nơi để trỏ); (2) tham chiếu tài nguyên tìm bằng biểu thức chính quy trên `src/href/poster/data/xlink:href/url()/@import`, không phải trình phân tích HTML đầy đủ -> tham chiếu dựng bằng JavaScript không được thấy; (3) EPUB nhiều tệp OPF / có mã hoá (DRM, phông làm rối) chưa được xử lý riêng; (4) đã khai báo EPUB 3.0 cho sách ghép/tách, chưa chạy `epubcheck` (không có trong môi trường).

**Lỗi thật bắt được khi kiểm (B18-01):** bản Java `String.split(",")` bỏ phần rỗng ở cuối nên "1," bị nhận nhầm là hợp lệ; bản tham chiếu độc lập (Python) từ chối đúng. Sửa bản Java (`split(",", -1)`); bản Kotlin dùng `split(',')` vốn giữ phần rỗng nên đúng ngay từ đầu, nhưng hai bản phải phản chiếu nhau.

**Kiểm chứng** (`epub_tools_check.py`, 41 phép kiểm, mọi kết quả đọc lại bằng zipfile + lxml + pandoc chứ không tin lời báo của Java): giá trị đọc lại đúng (có `& < "` và chữ Việt, xuống dòng); mọi tệp khác giống từng byte; `mimetype` đầu + không nén; mọi href trong manifest/nav/ncx và mọi tham chiếu tương đối trong XHTML/CSS tồn tại; id duy nhất; ảnh có dấu cách trong tên giữ nguyên từng byte; pandoc đọc đủ 5 chương theo đúng thứ tự sau khi ghép; ảnh thừa bị bỏ khi tách; 611 chuỗi phạm vi khớp bản tham chiếu; HTML (html.parser + pandoc) và Markdown (pandoc commonmark, 10 đoạn đầy ký tự Markdown) khớp từng đoạn. **Chưa chạy:** bản Kotlin (chỉ rà tĩnh bằng `static_refs_check.py`), giao diện, `epubcheck`.

### 4.36. Phiên 18 (tiếp) -- dọn dẹp lưu trữ (dung lượng, tài liệu trùng, xoá hẳn có ghi đè)

**Nguồn yêu cầu:** PDF "Thiếu gì để bán app" D3 (xoá an toàn), E2 (phân tích dung lượng), E3 (tìm tài liệu trùng); còn ghi "chưa làm" ở 6.9.

**Quyết định chính:**
- Trùng = CÙNG NỘI DUNG, không phải cùng tên: nhóm theo dung lượng, rồi theo SHA-256 của 64 KB đầu, rồi theo SHA-256 TOÀN BỘ. Bước cuối là bắt buộc: hai tệp cùng cỡ và cùng 64 KB đầu nhưng khác phần cuối vẫn phải tách (bài kiểm có thử âm tính cho đúng lỗi này: bản chỉ so 64 KB đầu gộp nhầm ở 60/60 cây). Đọc từng khối 64 KB, không nạp cả tệp vào bộ nhớ. Tệp rỗng bỏ qua.
- Trong mỗi nhóm bản CŨ NHẤT đứng đầu và được GIỮ; các bản mới hơn là ứng viên và mặc định được tích sẵn, nhưng chỉ CHUYỂN VÀO THÙNG RÁC (khôi phục được 30 ngày, kèm sao/thẻ), không xoá thẳng.
- Lớp chữ OCR (`.txt` nằm cạnh `.pdf` cùng tên) bị loại khỏi báo cáo và tìm trùng: nó đi cùng PDF vào thùng rác (xem 4.31), tính riêng sẽ cho kết quả sai.
- Xoá hẳn khỏi Thùng rác (`deleteForever`, hết hạn 30 ngày, "Dọn sạch") gọi `StorageTools.wipe`: ghi đè bằng byte ngẫu nhiên (SecureRandom), `fd.sync()`, rồi xoá.

**Điều phải nói thẳng về "xoá sạch":** ghi đè KHÔNG bảo đảm trên bộ nhớ flash (eMMC/UFS) vì cân bằng mòn (wear levelling) có thể ghi sang ô vật lý khác. Tra cứu (nhiều nguồn, chất lượng không đều) đều cùng kết luận; một nhà cung cấp phần mềm nén còn bỏ hẳn tuỳ chọn "xoá an toàn" trên bản Android vì lý do này. Bảo vệ thật là mã hoá dữ liệu của máy. Vì vậy ghi đè chỉ là nỗ lực tốt nhất (tốn rất ít) và giao diện KHÔNG hứa "không thể khôi phục". Dữ liệu thật sự nhạy cảm nên ở trong Két an toàn (4.31 H, mã hoá).

**Hạn chế:** (1) báo cáo/tìm trùng chỉ quét thư mục xuất của app, không quét ảnh trong thư viện máy; (2) không tìm tài liệu GẦN giống (khác nhau một chút) - chỉ trùng từng byte; (3) `TrashCheck.java` (bản phản chiếu của thùng rác) vẫn dùng `File.delete()`: kết quả quan sát được (tệp biến mất) giống nhau, phần ghi đè được kiểm riêng ở `storage_tools_check.py`.

**Lỗi bắt được khi viết (B18-02):** `static_refs_check.py` bắt `R.string.dialog_close` không tồn tại (tôi tưởng có sẵn); thêm chuỗi `cleanup_close`. Nếu không có bài kiểm này, lỗi chỉ lộ ở bước biên dịch trên CI.

**Kiểm chứng** (`storage_tools_check.py`): 60 cây thư mục ngẫu nhiên (nhóm trùng cỡ 1 byte đến 300 KB, tệp gần giống, cùng cỡ khác nội dung, tệp rỗng, `.part`, thư mục lồng, cặp pdf+txt) khớp bản tham chiếu độc lập (os.walk + hashlib); bản cũ nhất đứng đầu nhóm; báo cáo (tổng, từng loại, 5 tệp lớn nhất đồng hạng theo tên) khớp; ghi đè giữ nguyên độ dài và không còn đoạn 16 byte nào của nội dung cũ; wipe xoá tệp, trả false với tệp không có. **Chưa chạy:** bản Kotlin, giao diện.

### 4.37. Phiên 18 (tiếp 2) -- nhập từ gói CBZ/ZIP, dung lượng trống, giữ màn hình sáng

**Nguồn yêu cầu:** PDF "Thiếu gì để bán app" (lượt 4: nhập từ gói ảnh; các tình huống cạnh biên 2.x: hết dung lượng giữa chừng, màn hình tắt khi xử lý lâu). Đối chiếu mã thật bằng grep trước khi làm: KHÔNG có `StatFs`/`usableSpace`, `FLAG_KEEP_SCREEN_ON`, CBZ.

**Quyết định chính:**
- CBZ/ZIP đi qua CÙNG hàng đợi cắt/lọc như ảnh thư viện (`startCropQueue`), nên hưởng mọi tính năng quét sẵn có (tách 2 trang, tự nhận diện màu...). Vào bằng bộ chọn nguồn quét, mục thứ 4.
- Thứ tự = so sánh "tự nhiên" theo TÊN ĐẦY ĐỦ trong gói: dãy số so theo GIÁ TRỊ (`p2` < `p10`), chữ không phân biệt hoa thường, số đứng trước chữ, bằng nhau hết thì so chuỗi thô cho ổn định. Không đọc `ComicInfo.xml` (thứ tự theo tên là quy ước chung của CBZ).
- An toàn: tên tệp ra do app đặt (`arc_<mốc>_NNNN.<đuôi>`), KHÔNG dùng tên trong gói -> `../x`, `/abs/x`, `a\b` không thể ghi ra ngoài thư mục đích. Zip-bomb: kích thước khai báo trong gói không đáng tin, nên ĐẾM byte thực đọc ra; tệp vượt 64 MB bị bỏ, tổng vượt 1 GB thì dừng, tối đa 2000 ảnh; tệp dở bị xoá.
- Dung lượng trống: cần `2 x đầu vào + 64 MB` (bản sao + kết quả + dự phòng), bão hoà ở `Long.MAX_VALUE`. Kiểm TRƯỚC khi bắt đầu (nhập gói, các thao tác EPUB), có thông báo nói rõ cần bao nhiêu / còn bao nhiêu và gợi ý nút "Dọn dẹp" (4.36). Hệ số 2 là ước lượng, không phải chứng minh: thao tác ra nhiều tệp hơn (tách EPUB thành nhiều phần) vẫn có thể thiếu.
- `setImporting(true)` đặt `FLAG_KEEP_SCREEN_ON` (và bỏ khi xong): màn hình không tự tắt giữa lúc đang xử lý. Không cần quyền nào.

**Còn thiếu tại thời điểm viết mục này (ĐÃ làm ở 4.38):** giữ màn hình sáng chỉ che trường hợp màn hình tắt; nếu người dùng chuyển sang app khác hoặc hệ thống thu hồi tiến trình thì thao tác dài vẫn có thể bị dừng. Cách giải quyết đúng là dịch vụ chạy nền (foreground service loại `dataSync`, kèm thông báo; hoặc WorkManager cho việc không cần thấy ngay). Chưa làm vì phải đưa các luồng coroutine hiện nằm trong `Activity` (OCR, nén, ghép...) sang dịch vụ, kèm quyền `POST_NOTIFICATIONS` (Android 13+) và khai báo loại dịch vụ (Android 14+); theo tài liệu Android loại `dataSync` còn có giới hạn thời gian mỗi lần chạy (cần kiểm lại số liệu cụ thể khi làm). Đây là việc kiến trúc, cần phiên riêng và máy thật để thử.

**Kiểm chứng** (`archive_images_check.py`, 12 phép kiểm): 400 danh sách tên ngẫu nhiên khớp key sắp xếp tham chiếu độc lập; 18 tên phân loại ảnh / không phải ảnh; giải nén 9 ảnh từ gói có `__MACOSX`, tệp ẩn, `Thumbs.db`, `.txt`, `../evil.jpg`, `/abs/evil.png`, đường dẫn `\` kiểu Windows: đúng thứ tự, từng byte khớp, không có tệp nào ngoài thư mục đích; trần số tệp; zip-bomb 5 MB số 0 bị bỏ khi trần 1 MB (hai tệp nhỏ còn lại giữ); trần tổng; gói hỏng -> lỗi; 210 cặp dung lượng sát biên và `Long.MAX_VALUE`. **Chưa chạy:** bản Kotlin, giao diện, trên máy thật.

### 4.38. Phiên 18 (tiếp 3) -- dịch vụ nền giữ việc dài sống (đã tra cứu, đã làm)

**Vì sao làm:** 4.37 ghi "chưa làm: dịch vụ chạy nền" (giữ màn hình sáng chỉ che trường hợp màn hình tắt). Quy tắc dự án: gặp giới hạn thì tra cứu cách giải quyết rồi làm, không để thành "chưa làm".

**Tra cứu (tài liệu Android chính thức, trang "Behavior changes: Apps targeting Android 15 or higher"):** dịch vụ foreground loại `dataSync` được chạy tổng cộng 6 giờ trong 24 giờ; hết hạn hệ thống gọi `Service.onTimeout(int, int)` (mới ở Android 15) và dịch vụ PHẢI tự dừng, nếu không ứng dụng bị đóng với `RemoteServiceException`; hết hạn mức thì khởi động tiếp ném `ForegroundServiceStartNotAllowedException` (quỹ giờ được đặt lại khi người dùng đưa app lên màn hình); chỉ nên khởi động dịch vụ do thao tác trực tiếp của người dùng. Dự án nhắm `targetSdk 36` nên các quy tắc này áp dụng. Phương án "WorkManager" bị loại cho việc này vì cần chạy NGAY khi người dùng bấm và gắn với luồng đang mở trong Activity.

**Thiết kế (nhỏ và có chủ đích):**
- `KeepAliveService` KHÔNG chạy việc thay Activity. Nó chỉ là dịch vụ foreground `dataSync` với một thông báo, để NÂNG ƯU TIÊN tiến trình và hệ thống không thu hồi khi người dùng chuyển sang app khác. Việc vẫn chạy trong coroutine của Activity như cũ => không phải viết lại hàng chục luồng.
- `KeepAlive.acquire/release` (bộ đếm `WorkTracker`): dịch vụ bật khi từ 0 lên 1, tắt khi về 0; `release` khi đang 0 bị bỏ qua; `reset` khi hệ thống ngắt. `KeepAlive.during(ctx) { ... }` luôn release kể cả khi lỗi hay bị huỷ.
- Điểm cắm: `MainActivity.setImporting` (mọi thao tác có hộp tiến trình; đúng MỘT acquire cho mỗi hộp, `onDestroy` release nếu Activity chết giữa chừng) và 10 chỗ `KeepAlive.during` quanh các `withContext` nặng (xuất PDF + lớp chữ OCR, ghép PDF, nén dự án, OCR dự án [bọc cả thân, không bọc từng trang để khỏi bật/tắt dịch vụ liên tục], xuất PDF dự án, xuất/chuyển ebook, chuyển tài liệu).
- `onTimeout` dừng dịch vụ + `reset`; `startForeground` bị từ chối (hết quỹ giờ, không đủ điều kiện) thì bắt lỗi, bỏ bảo vệ, việc vẫn chạy.
- Manifest: `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_DATA_SYNC` (Android 14+ bắt buộc cho loại dataSync), `POST_NOTIFICATIONS` (Android 13+). Quyền thông báo chỉ để người dùng THẤY thông báo, hỏi MỘT lần duy nhất (không nài); không cấp thì dịch vụ vẫn chạy.

**Chưa kiểm chứng được và rủi ro còn lại (nói thẳng):** (1) KHÔNG chạy được dịch vụ thật ở đây: bài kiểm chỉ chứng minh LOGIC bộ đếm (3 021 kịch bản so với mô hình). Hành vi thật (Android có khởi động / ngắt, thông báo hiện, ứng dụng sống khi sang app khác) phải thử trên máy thật, tốt nhất cả Android 13, 14, 15+. (2) Chưa rõ hành vi của hệ thống nếu `startForeground` ném lỗi SAU khi `startForegroundService` đã thành công: có thể vẫn có báo lỗi "did not call startForeground"; mã bắt lỗi và dừng dịch vụ nhưng chưa xác nhận được trên máy. (3) Không bảo vệ khi người dùng chủ động vuốt tắt ứng dụng, hay trên máy có trình tiết kiệm pin hung hãn của hãng (một số hãng vẫn giết tiến trình). (4) Còn khoảng 15 Activity có việc `withContext` nhẹ hơn chưa bọc (chỉnh trang, ký, che, chú thích, két...); thao tác lớn nhất đã bọc; thêm một chỗ chỉ cần bọc lệnh `withContext` bằng `KeepAlive.during(applicationContext) { ... }`. (5) Quỹ 6 giờ/24 giờ rất rộng so với việc quét tài liệu nhưng là giới hạn thật.

**Kiểm chứng** (`keepalive_check.py`): 3 021 kịch bản ngẫu nhiên (acquire/release/reset/during thành công, lỗi, lồng nhau) khớp mô hình tham chiếu; release khi đang 0 bị bỏ qua; sau khi hệ thống ngắt, acquire mới khởi động lại; `during` lồng nhau có tầng lỗi vẫn release hết. Ngoài ra: `static_refs_check` đạt, `xmllint` xác nhận manifest / strings / layout / menu hợp lệ, và bộ ghép ngoặc kiểm số ngoặc nhọn của từng tệp Kotlin trước và sau khi bọc không đổi.

### 4.39. Phiên 18 (tiếp 4) -- cấu trúc bên trong PDF: tệp đính kèm, lớp OCG, liên kết

**Nguồn yêu cầu:** PDF "Thiếu gì để bán app" B4 (liên kết), B5 (tệp đính kèm), B19 (lớp OCG); đối chiếu mã thật bằng grep: chỉ `PdfAConverter` đụng tới `OptionalContent` / `EmbeddedFile` / `PDAnnotationLink` (để khai báo PDF/A), người dùng chưa có công cụ nào.

**Quyết định chính:**
- Mọi thao tác ghi ra BẢN SAO (như `PdfMetadataTools`), PDF đặt mật khẩu bị từ chối với thông báo rõ.
- Tệp đính kèm: đọc cả cây tên có `Kids`; mọi thay đổi ghi lại cây PHẲNG; xoá hết thì gỡ hẳn mục `/EmbeddedFiles`. Trùng tên thì "a (2).txt", "a (3).txt"; tên không đuôi / nhiều dấu chấm xử lý đúng ("archive.tar (2).gz"). Trích ra thư mục tài liệu với tên đã làm sạch.
- Lớp OCG: đặt trạng thái bằng thao tác TRỰC TIẾP trên hai mảng `/D /ON` và `/D /OFF` theo đặc tả (thành viên rõ ràng của một mảng thắng `/BaseState`): bật = có trong ON và không có trong OFF; tắt = ngược lại. Không dùng `setGroupEnabled` của PdfBox vì không kiểm chứng được hành vi với `/BaseState` ở đây.
- Liên kết: phân loại web / nhảy trang (đích rõ, `/Dest` trực tiếp, tên đích kiểu cũ `/Dests` và kiểu mới `/Names /Dests`) / khác (Launch, tên không tồn tại). Xoá liên kết WEB riêng (lý do: bỏ đường dẫn theo dõi, `mailto:`) hoặc xoá MỌI liên kết; chú thích khác (Text, Highlight...) giữ nguyên. KHÔNG làm "thêm liên kết" (cần chọn vùng trên trang - việc giao diện riêng).

**Phát hiện thật khi kiểm (B18-03):** poppler liệt kê tên đính kèm theo thứ tự KHÁC thứ tự tôi ghi. Nguyên nhân: đặc tả PDF (ISO 32000, 7.9.6) bắt khoá cây tên sắp theo BYTE THÔ của chuỗi đã mã hoá; chuỗi Unicode bắt đầu bằng BOM `FE FF` nên đứng SAU mọi tên ASCII, trong khi `PDNameTreeNode.setNames` của PdfBox (và cách sắp chuỗi thông thường) cho thứ tự khác khi trộn tên ASCII với tên tiếng Việt. Trình xem tìm kiếm nhị phân có thể không thấy một số tên. Sửa: `storeEmbedded` tự dựng mảng `/Names`, sắp theo byte không dấu (`compareBytes`), và ghi mỗi đặc tả tệp thành đối tượng gián tiếp. Bài kiểm có hai thử âm tính (cây không sắp; cây sắp theo chuỗi) đều bị bộ kiểm bất biến bắt.

**Chưa làm / chưa kiểm chứng (nói thẳng):** (1) KHÔNG chạy được PdfBox ở đây: bài kiểm chứng minh CẤU TRÚC ĐÚNG và CÓ HIỆU LỰC (poppler thật sự vẽ / liệt kê / trích đúng) bằng cách dựng lại từng bước của hàm Kotlin trong pikepdf; nó KHÔNG chứng minh các lời gọi API PdfBox trong `PdfStructureTools.kt` biên dịch và chạy đúng - lỗi loại đó chỉ lộ ở CI hoặc trên máy. (2) Thêm tệp đính kèm vào PDF/A-1 hoặc PDF/A-2 làm mất tính tuân chuẩn (chỉ PDF/A-3 cho phép); chưa có cảnh báo. PDF đã ký số bị vô hiệu chữ ký khi sửa (vì ra bản sao nên bản gốc còn nguyên). (3) PDF Portfolio (B20) chưa làm: về cấu trúc là thêm `/Collection` vào Catalog trên nền các tệp đính kèm vừa có, nên việc này khả thi và nhỏ; để phiên sau kèm kiểm bằng trình xem. (4) Tuyến tính hoá (B12) làm ở 4.42; sửa PDF hỏng (B13) làm ở 4.40.

**Kiểm chứng** (`pdf_structure_check.py`, 23 phép kiểm): đính kèm - 10 tệp (tên Việt, trùng tên, rỗng, 70 KB không nén được) qua `qpdf --check`, `pdfdetach` (đếm, tên, trích TỪNG BYTE), pypdf; làm phẳng cây Kids; xoá hết; 2 thử âm tính. Lớp OCG - VẼ TRANG bằng poppler rồi đo màu điểm ảnh: danh sách trạng thái khớp cái poppler vẽ ở 3 cấu hình ban đầu và 24 ca (3 cấu hình x 8 tổ hợp) vẽ đúng sau khi đặt; lớp nằm ở cả hai mảng; phần tử mảng là tham chiếu thật. Liên kết - 8 liên kết đủ loại khớp bảng chân trị viết tay, pypdf đếm độc lập, xoá web / xoá hết giữ nguyên chú thích khác.

### 4.40. Phiên 18 (tiếp 5) -- sửa PDF hỏng, tự tạo liên kết, PDF Portfolio (và vì sao KHÔNG làm tuyến tính hoá)

**Nguồn yêu cầu:** PDF "Thiếu gì để bán app" B13 (sửa PDF hỏng), B4 (thêm liên kết), B20 (Portfolio), B12 (tuyến tính hoá) - đều ghi "chưa làm" ở 4.39.

**B13 sửa PDF hỏng (`PdfRepair`).** Tra cứu: `COSParser` của PdfBox có chế độ khoan dung (`setLenient`), khi `startxref` / bảng tham chiếu hỏng nó quét cả tệp để dựng lại; nên "sửa" = MỞ khoan dung rồi LƯU lại (ghi xref mới) + MỞ LẠI kết quả kiểm số trang bằng bản gốc; loại tệp mã hoá; không cứu được thì báo lỗi, KHÔNG tạo tệp rỗng. `diagnose` chỉ nhìn BYTE (tiêu đề, `%%EOF`, `startxref`, nội dung tại vị trí đó) và chỉ để nói cho người dùng biết tệp có hỏng không; việc sửa luôn chạy.
- Kiểm chứng với qpdf làm chứng (200 mẫu: 8 tệp lành xref cổ điển + luồng xref x 8 lớp hỏng x 3): 0 báo động nhầm trên tệp lành; mọi lần báo HỎNG NẶNG (74 lần) qpdf đều xác nhận phải dựng lại bảng tham chiếu. Hai mức: NẶNG (thiếu / sai `startxref`: bắt buộc dựng lại) và NHẸ (thiếu `%%EOF`, sai tiêu đề, rác trước tiêu đề: qpdf và PdfBox khoan dung vẫn mở được; chẩn đoán bù độ lệch do rác như qpdf).
- Độ bao phủ nói thẳng: qpdf kêu 85 mẫu hỏng, app xếp NẶNG được 74 (87%); phần còn lại là hỏng sâu bên trong (mục xref sai, luồng, đối tượng) mà chẩn đoán theo byte không thấy - việc sửa vẫn chạy cho mọi tệp.
- Khả năng cứu (qpdf làm chứng, KHÔNG phải PdfBox): trong 74 tệp hỏng nặng chỉ 52 được dựng lại (số trang bằng bản gốc 52/52); 22 tệp bị cắt giữa chừng mất cả nội dung không cứu được => `repair` phải báo lỗi chứ không được tạo tệp thiếu trang.

**B4 tự tạo liên kết (`PdfAutoLinks`).** Nhận MỘT từ liền (không khoảng trắng) là địa chỉ web (`http(s)://...`, `www....`) hoặc email, cắt dấu câu hai đầu (`(http://x.org/p).` -> `http://x.org/p`), `www.x` -> `https://www.x`, email -> `mailto:`. Quét văn bản bằng `PDFTextStripper` lấy hộp từng ký tự; vùng bấm = x của các ký tự đã cắt + đường cơ sở (-0,25 / +0,8 cỡ chữ); không đè lên liên kết sẵn có (chồng >= 50% diện tích thì bỏ). Hữu ích nhất cho PDF đã OCR (lớp chữ có sẵn).
- Phạm vi nói thẳng: chỉ trang KHÔNG xoay và chữ nằm ngang (trang khác được đếm và bỏ qua, không đoán toạ độ); địa chỉ bị ngắt dòng không nhận; PDF ảnh chưa OCR không có chữ nên không có gì để nối. Chưa làm "tự chọn vùng trên trang để gắn liên kết" (việc giao diện riêng).
- Kiểm chứng: bản Java của `classify` khớp 21 từ viết tay + 1 500 chuỗi ngẫu nhiên với bản Python viết riêng; dựng lại `addLinks` bằng pikepdf trên PDF chữ thật, pypdf thấy đúng 5 URI không dư không thiếu, poppler `pdftotext -bbox` xác nhận vùng bấm trùng hộp chữ (lệch trái <= 1,6 pt, phủ >= 70% chiều cao), chạy lần hai không thêm trùng, trang `/Rotate 90` bị bỏ qua và được đếm.

**B20 Portfolio (`PdfStructureTools.setPortfolio` / `isPortfolio`).** Thêm `/Collection << /Type /Collection /View /D >>` vào Catalog trên nền tệp đính kèm có sẵn; bật khi chưa có tệp đính kèm bị từ chối. Tắt thì gỡ `/Collection`, tệp đính kèm còn nguyên. Chưa khai báo `/Schema` (cột tuỳ chỉnh). Kiểm: qpdf, pdfdetach, pypdf, poppler vẫn mở như PDF thường; CHƯA mở bằng Adobe Acrobat (không có ở đây) nên "trình xem hỗ trợ sẽ hiện như thư mục" là theo đặc tả, chưa tự xác nhận.

**B12 tuyến tính hoá ("Fast Web View"):** ban đầu ghi "không làm được"; kết luận đó SAI và đã được sửa - xem mục 4.42 (đã tra cứu qpdf + gói Go Apache-2.0, đã làm, kiểm bằng `qpdf --check-linearization`).

**Phát hiện thật khi kiểm (B18-04):** chẩn đoán đầu tiên dừng sớm ở "thiếu `%%EOF`" (mức nhẹ) nên với tệp bị cắt đuôi (mất CẢ `%%EOF` lẫn `startxref`) nó chỉ báo nhẹ, bỏ sót việc bảng tham chiếu đã mất: độ bao phủ chỉ 61%. Sửa: xét `startxref` trước, thiếu `%%EOF` chỉ là mức nhẹ khi mọi thứ khác còn nguyên -> 87%. Ngoài ra bài kiểm cho thấy qpdf khoan dung hơn tôi tưởng với thiếu `%%EOF` / sai tiêu đề / rác đầu tệp (mở được không cần dựng lại), nên tôi tách hai mức thay vì gọi tất cả là "hỏng".

**Chưa kiểm chứng (nói thẳng):** các lời gọi PdfBox trong `PdfRepair`, `PdfAutoLinks` (`PDFTextStripper.writeString`, `TextPosition`, `PDAnnotationLink`...) và `setPortfolio` biên dịch / chạy đúng - chỉ lộ ở CI hoặc trên máy; toạ độ `TextPosition` của PdfBox có thể lệch vài phần trăm so với pdfplumber (bài kiểm đo bằng poppler với dung sai).

### 4.41. Phiên 18 (tiếp 6) -- chế độ riêng tư (không ghi lịch sử)

**Nguồn yêu cầu:** PDF "Thiếu gì để bán app" mục D; còn ghi "chưa làm" ở 6.9. Đối chiếu mã thật: "lịch sử" của app chính là thư mục tài liệu xuất (`PdfExporter.exportDir`) + các dự án quét (`FileUtils.projectsRootDir`) + Thùng rác + sao / thẻ (`FavoriteStore`, `TagStore`, lưu theo TÊN tệp); chỉ mục nội dung (`ContentIndex`) chỉ ở bộ nhớ.

**Quyết định chính:**
- ĐỔI HƯỚNG ở hai điểm tập trung: khi bật, `exportDir` trả `filesDir/private/documents` và `projectsRootDir` trả `filesDir/private/projects` (bộ nhớ trong, không phải thư mục ngoài); danh sách "Tài liệu đã xuất" liệt kê đúng `exportDir` nên trong chế độ riêng tư chỉ thấy tài liệu riêng tư, tắt chế độ thì danh sách thường quay lại và thư mục riêng không còn được liệt kê. Không phải sửa từng nơi xuất (16 tệp gọi `exportDir`).
- Xoá trong chế độ riêng tư = xoá HẲN (`StorageTools.wipe`: ghi đè rồi xoá), cả lớp chữ OCR đi kèm; không vào Thùng rác (thùng rác lưu tên tệp = dấu vết).
- Tắt = xoá sạch cả cây `private/` (`StorageTools.wipeTree`) rồi `prune` sao / thẻ để tên tài liệu riêng tư không còn trong cài đặt.
- Trạng thái BẬT lưu bền (không mất tài liệu nếu hệ thống thu hồi tiến trình) và LUÔN hiện: tiêu đề màn hình thêm " (riêng tư)", nút đổi thành "Riêng tư: BẬT". Hộp thoại bật nói rõ phải chia sẻ / lưu ra ngoài thứ cần giữ TRƯỚC khi tắt.

**Giới hạn (nói thẳng, không quảng cáo quá mức):** chế độ này KHÔNG làm app ẩn danh với hệ điều hành: tệp nằm trong bộ nhớ riêng của app (app khác không đọc được, người dùng root hoặc sao lưu ADB thì có); ảnh chụp tạm trong thư mục cache theo chu kỳ dọn thường (24 giờ) chứ không xoá ngay; "ghi đè trước khi xoá" chỉ là nỗ lực tốt nhất trên bộ nhớ flash (4.36); nơi người dùng chọn lưu hoặc chia sẻ ra ngoài nằm ngoài tầm kiểm soát của app; sao / thẻ khoá theo TÊN nên hai tài liệu cùng tên ở hai chế độ dùng chung một mục (hiếm). Chưa có: khoá chế độ riêng tư bằng khoá ứng dụng, chặn ảnh chụp màn hình (`FLAG_SECURE`) - hai việc tự nhiên tiếp theo.

**Kiểm chứng:** phần có thể kiểm bằng công cụ độc lập là `wipeTree` (`storage_tools_check.py` phần D: 8 tệp ở nhiều tầng kể cả tệp rỗng, thư mục không có, tệp lẻ). **Chưa chạy:** việc đổi hướng thư mục và giao diện (cần máy thật); đặc biệt cần thử: bật -> xuất PDF -> không thấy trong danh sách thường sau khi tắt; xoá trong chế độ riêng tư; tắt -> thư mục `private/` biến mất.

### 4.42. Phiên 18 (tiếp 7) -- tuyến tính hoá PDF ("Fast Web View", B12) - ĐÃ LÀM, thay cho kết luận "không làm được" ở 4.40

**Sửa sai của chính tài liệu này:** mục 4.40 từng ghi B12 "không làm được vì không có mạng / NDK". Điều đó SAI về cách làm việc: môi trường chạy lệnh không có mạng, nhưng công cụ tra cứu web (`web_search`, `web_fetch`) vẫn đọc được mã nguồn và tài liệu. Tôi đã lẫn hai chuyện và lấy đó làm cớ không làm. Đã tra cứu và làm theo đúng quy tắc dự án.

**Tra cứu và nguồn:** tài liệu tuyến tính hoá của qpdf (cách bố trí, các phần 1-11) và gói Go `linearize` của dự án byblos (github.com/dobbo-ca/byblos, giấy phép Apache-2.0, cũng dùng qpdf làm bộ kiểm), đọc cả ba tệp `layout.go`, `hints.go`, `write.go`. Thuật toán được chuyển thể sang Java (`LinearizerCheck.java`) rồi Kotlin (`Linearizer.kt`); ghi công nguồn trong đầu tệp. Giấy phép tương thích (Apache-2.0); không dùng mã AGPL nào, đúng chốt chặn của CI.

**Thiết kế:**
- LÕI THUẦN TUÝ (`Linearizer`): nhận đồ thị đối tượng + thân từng đối tượng đã tuần tự hoá (tham chiếu là dấu hiệu `\u0001<số>\u0002`), không biết gì về PDF/PdfBox: phân vùng theo Annex F (phần 4 catalog + đối tượng cấp tài liệu, 6 đoạn trang đầu, 7 các trang sau mỗi trang một nhóm, 8 đối tượng dùng chung của các trang sau, 9 còn lại: cây trang, Info...), đánh số lại, hai bảng xref cổ điển, từ điển tuyến tính hoá, luồng gợi ý (bảng gợi ý trang + bảng đối tượng dùng chung + mục lục), mọi vị trí được vá tại chỗ rồi xuất ba đoạn.
- LỚP NỐI (`PdfLinearizer`, PdfBox): chỉ giữ đối tượng với tới được từ Root / Info; đẩy thuộc tính kế thừa (Resources, MediaBox, CropBox, Rotate) từ nút Pages xuống trang; bỏ cạnh /Parent và /Thumb của trang khi phân vùng; luồng giữ nguyên byte thô (bộ lọc, tham số), chỉ /Length viết lại; không luồng đối tượng, không xref stream. Mở lại kết quả kiểm số trang và có `/Linearized` trước khi đổi tên; lỗi thì không để lại tệp.
- Bộ nhớ: bộ đệm duy nhất, vá tại chỗ rồi ghi ba đoạn (không dựng bản sao thứ hai), thân luồng đọc lười từng cái; tệp > 100 MB bị từ chối với thông báo (bộ đệm giữ gần hết tệp trong bộ nhớ).

**Kiểm chứng (`linearize_check.py`, 21 phép kiểm; trọng tài là chính qpdf):** 9 PDF đủ kiểu - ảnh quét 5 trang (Pillow), 1 trang, 6 trang với phông + 2 ảnh dùng chung giữa trang đầu và các trang sau + Info, mục lục có và không PageMode UseOutlines, tài nguyên + MediaBox kế thừa từ nút Pages, luồng đối tượng PDF 1.5 + OpenAction + AcroForm, 60 trang, và PDF thật 13 trang do LibreOffice dựng (phông nhúng) - đều đạt `qpdf --check-linearization` ngay lần chạy đầu, `qpdf --check`, `is_linearized`, và poppler vẽ GIỐNG TỪNG ĐIỂM ẢNH + cùng văn bản với tệp gốc. Thử âm tính: đổi /L thêm 1 -> qpdf không còn coi là tuyến tính hoá (nó đối chiếu /L với độ dài thật nên ở tệp đạt /L khớp từng byte); lật một byte luồng gợi ý -> qpdf từ chối; tệp chưa tuyến tính hoá không bị báo đạt nhầm.

**Phát hiện khi làm (B18-05):** thử âm tính đầu tiên của tôi kỳ vọng qpdf trả mã lỗi khi /L sai; thực tế qpdf coi tệp là "không tuyến tính hoá" và thoát mã 0. Sửa thử âm tính theo đúng hành vi (kiểm "không còn nói 'no linearization errors'" và `is_linearized` sai) thay vì sửa mã. Ngoài ra trong lúc dọn bộ chuyển đổi tôi thấy cách tôi lấy tham chiếu của đối tượng gián tiếp đi sâu thêm một tầng thừa; đã làm sạch (`direct_targets`) và chạy lại toàn bộ.

**Hạn chế và chưa kiểm chứng (nói thẳng):** (1) các lời gọi PdfBox trong `PdfLinearizer` (duyệt `COSObject`, `entrySet`, `createRawInputStream`...) CHƯA chạy được ở đây - lõi `Linearizer` được kiểm qua bản Java giữ cùng thuật toán, lớp nối được kiểm qua bản Python phản chiếu; hai phần cầu nối đó chỉ lộ lỗi ở CI / máy thật. (2) Chỉ xref cổ điển, không luồng đối tượng: tệp ra có thể LỚN HƠN tệp vào nếu tệp vào dùng ObjStm (hiếm với PDF của app). (3) Mục lục (Outlines) chỉ được gợi ý hoá khi có; tên đích (Names), thumbnail, luồng metadata đặt ở phần 9 (hợp lệ, nhưng một số bộ đọc muốn hiện sớm hơn thì chưa tối ưu). (4) PDF mã hoá và PDF đã ký số không được xử lý (tuyến tính hoá làm hỏng chữ ký; bản gốc còn nguyên vì ra bản sao). (5) Giá trị thực tế vẫn thấp cho app quét (chỉ có ích khi đưa tệp lên máy chủ web hỗ trợ tải theo dải byte) - làm vì yêu cầu đầy đủ danh sách, không phải vì đây là ưu tiên.

### 4.43. Phiên 18 (tiếp 8) -- thư mục theo dõi

**Nguồn yêu cầu:** PDF "Thiếu gì để bán app" mục F (tự động hoá: thư mục theo dõi); còn ghi "chưa làm" ở 6.9.

**Quyết định chính:**
- Dùng Storage Access Framework (`OpenDocumentTree` + quyền đọc lâu dài), KHÔNG xin quyền đọc bộ nhớ rộng: app chỉ ĐỌC đúng thư mục người dùng chọn, không ghi, không xoá. Liệt kê con trực tiếp của thư mục (không đệ quy).
- Thời điểm quét: MỖI LẦN MỞ app (`onResume`), không chạy nền. `FileObserver` không dùng được với URI của SAF, còn quét nền định kỳ cần dịch vụ / WorkManager với giới hạn pin; nên chọn đề nghị lúc mở app: đơn giản, đoán được, không bí mật nhập tệp.
- Logic chọn tệp (`WatchFolder.pick`, thuần tuý, kiểm chứng): (1) mỗi tệp chỉ đề nghị MỘT lần - nhớ theo mã tài liệu, tối đa 2000 mã mới nhất; (2) khi vừa chọn thư mục, tệp ĐÃ CÓ được đánh dấu đã thấy (không nhập hàng tồn); (3) tệp mới ghi dở (sửa đổi cách đây dưới 3 giây) hoặc rỗng hoãn tới lần mở sau; (4) bỏ tệp ẩn, `.trashed-*`, tạm (`.tmp`, `.part`, `.crdownload`, `.pending`, `.download`), loại lạ; (5) thứ tự: thời gian sửa rồi tên tự nhiên (IMG_2 trước IMG_10).
- Nhập: ảnh -> cùng hàng đợi cắt / lọc như ảnh thư viện; PDF -> SAO vào danh sách tài liệu (theo chế độ riêng tư nếu đang bật). Chỉ tệp nhập THÀNH CÔNG mới được đánh dấu đã thấy (tệp lỗi được đề nghị lại). Ba nút: Nhập / Bỏ qua (đánh dấu đã thấy, không hỏi lại) / Để sau.
- Mất quyền hoặc thư mục bị xoá: dừng theo dõi và báo một lần, không lỗi lặp mỗi lần mở app.

**Giới hạn (nói thẳng):** không bắt tệp tới LÚC app đang đóng cho tới lần mở sau; không đệ quy thư mục con; một số nhà cung cấp tài liệu không trả `lastModified` (coi như cũ -> đủ "ổn định" ngay) hoặc `size` (coi như 0 -> hoãn mãi, tệp không bao giờ được đề nghị); mã tài liệu của SAF ổn định trong một nhà cung cấp nhưng tệp bị xoá rồi tạo lại cùng tên có thể mã khác -> nhập lại. Phần Android (SAF, hộp thoại, nhập) CHƯA chạy; chỉ phần logic chọn tệp được kiểm bằng công cụ độc lập.

**Kiểm chứng** (`watch_folder_check.py`): ca viết tay (ẩn / tạm / rỗng / loại lạ / đang ghi dở / đã thấy, IMG_2 trước IMG_10); tệp ghi dở được đề nghị ở lần mở SAU; 300 danh sách ngẫu nhiên khớp bản tham chiếu Python viết riêng; mô phỏng 4 lần mở app liên tiếp có tệp tới giữa chừng: mỗi tệp đề nghị đúng một lần; `remember` 205 ca (giữ thứ tự, bỏ trùng, bỏ mã cũ nhất khi vượt trần).

### 4.44. Phiên 18 (tiếp 9) -- bố cục máy tính bảng hai khung

**Nguồn yêu cầu:** PDF "Thiếu gì để bán app" (giao diện máy tính bảng); còn ghi "chưa làm" ở 6.9: "bố cục hai khung thay vì chỉ cột giữa".

**Quyết định chính:**
- `res/layout-sw600dp/activity_main.xml`: gốc LinearLayout NGANG với hai ScrollView rộng bằng nhau (`0dp`, `weight 1`): khung TRÁI = tiêu đề + mọi thẻ công cụ (25 thẻ), khung PHẢI = lịch sử (tìm kiếm, nút Chọn / Riêng tư / Dọn dẹp / Thùng rác, danh sách) + khoá app + liên kết. Điện thoại giữ nguyên bản một cột.
- SINH TỰ ĐỘNG từ bản mặc định (`tablet_layout_check.py` ở chế độ ghi), không chép tay: ViewBinding bắt bản `sw600dp` có ĐỦ MỌI id của bản mặc định (thiếu id nào thì trường đó thành nullable và hỏng biên dịch khắp `MainActivity`), và hai bản phải luôn đồng bộ mỗi khi bản mặc định được sửa. Bài kiểm (chế độ mặc định) báo lệch ngay nếu ai sửa bản mặc định mà quên sinh lại.
- Chỉ thay đổi BỐ CỤC: không đụng mã `MainActivity` (`binding.root` chỉ dùng cho `setContentView`, kiểu gốc khác nhau giữa hai bản nên ViewBinding trả `View`, vẫn hợp lệ).

**Nói thẳng về phạm vi:** đây là bố cục HAI CỘT (công cụ | lịch sử), chưa phải "danh sách + khung xem" kiểu thư - danh sách bên trái, nội dung bên phải. Khung xem tài liệu ngay trong app cần một bộ xem PDF nhúng (hiện app mở tài liệu bằng ứng dụng ngoài) và là việc riêng, lớn; chưa làm. Cũng chưa xem trên máy tính bảng hay trình giả lập (không có ở đây): hai ScrollView lồng trong LinearLayout ngang là mẫu chuẩn, nhưng chiều rộng thẻ / chữ trên màn hình rất rộng (sw840dp trở lên) chưa được tinh chỉnh.

**Phát hiện khi kiểm (B18-06):** lần sinh đầu tiên chèn chú thích có `--write` vào đầu tệp; XML cấm hai dấu gạch liền trong chú thích nên `lxml` từ chối đọc lại - bài kiểm bắt lỗi ngay ở lần chạy đầu. Đã đổi nội dung chú thích.

**Kiểm chứng** (`tablet_layout_check.py`, 7 phép kiểm, cấu trúc): có tệp; khớp bản sinh lại; tập 40 id bằng nhau và không trùng; 58 view con đủ, đúng thứ tự, cùng thẻ + thuộc tính (so toàn bộ cây con); khung phải mở đầu bằng `tvHistoryTitle`; thẻ công cụ ở trái / lịch sử + khoá app ở phải; gốc ngang, hai khung 0dp weight 1; `xmllint` đạt.

### 4.45. Phiên 18 (tiếp 10) -- đa ngôn ngữ: kiến trúc, bản dịch, bộ sinh / kiểm

**Yêu cầu của chủ app (nguyên văn ý):** nhiều ngôn ngữ cho người dùng chọn; ban đầu theo ngôn ngữ máy (máy tiếng Nhật thì tự hiện tiếng Nhật, các ngôn ngữ khác cũng vậy); ngôn ngữ nào app không có thì hiện TIẾNG ANH. Phiên bản đầu của mục này (tiếng Việt mặc định + chỉ thêm `values-en`) làm ĐÚNG NGƯỢC yêu cầu (máy tiếng Pháp sẽ thấy tiếng Việt); đã làm lại như dưới đây.

**Kiến trúc (theo tài liệu Android về ngôn ngữ riêng của app - blog Android Developers "Per-app language preferences", và cơ chế chọn tài nguyên của Android):**
- `res/values/strings.xml` = TIẾNG ANH và là thư mục MẶC ĐỊNH: máy dùng ngôn ngữ app không có (Pháp, Đức, Thái...) tự rơi về đây.
- `res/values-<mã>/strings.xml` cho từng ngôn ngữ khác (hiện: `vi` tiếng Việt, `ja` tiếng Nhật): máy dùng ngôn ngữ đó tự thấy đúng ngôn ngữ đó, không cần làm gì thêm.
- `res/xml/locales_config.xml` + `android:localeConfig`: Android 13+ liệt kê các ngôn ngữ này trong Cài đặt hệ thống -> Ngôn ngữ ứng dụng.
- `res/values/languages.xml`: hai mảng (mã, tên bản ngữ như "Tiếng Việt", "日本語") cho bộ chọn trong app (4.46). Tên bản ngữ KHÔNG dịch.
- Tất cả sinh ra từ `tools/i18n/` bằng `tools/verify/i18n_check.py` (chế độ ghi): `languages.txt` (`mã | thư mục | tên bản ngữ`, dòng đầu PHẢI là en) và `<mã>_strings.txt` (mỗi dòng `tên ||| nội dung`, mảng là `@array`). Tiếng Anh là bản GỐC về thứ tự và tập khoá. Lý do sinh thay vì viết tay: aapt từ chối dấu nháy đơn trần (`device's` phải là `device\\'s`), `&`, `<` phải thoát, và hàng trăm chuỗi viết tay rất dễ sót.
- **THÊM MỘT NGÔN NGỮ:** viết `tools/i18n/<mã>_strings.txt` (dịch từ `en_strings.txt`), thêm một dòng vào `languages.txt`, chạy `python3 tools/verify/i18n_check.py --write` rồi `python3 tools/verify/i18n_check.py`. Bộ kiểm báo thiếu / thừa khoá, hỏng dấu thay thế, chữ chưa dịch.
- Tên mặc định GHI VÀO TỆP XUẤT theo ngôn ngữ giao diện (trước đây cứng "Trang N", "Chương N", "Dự án ..."): mẫu đánh số trang (`decorate_number_templates`), tên trang Excel / PowerPoint, tên chương mặc định, tên dự án mới. Lý do bắt buộc: nhãn người dùng chọn ("Page 1") phải trùng chữ sẽ in ra trang.
- Từ khoá dò mục lục (`TocDetector`) bổ sung Nhật / Trung / Hàn / Pháp / Đức / Tây Ban Nha / Nga / Indonesia để tính năng dò mục lục dùng được với sách đúng ngôn ngữ đang chọn.

**Ngôn ngữ hiện có (nói thẳng):** tiếng Anh (mặc định), tiếng Việt, tiếng Nhật. Mọi ngôn ngữ khác hiện hiển thị TIẾNG ANH (đúng yêu cầu "không có thì tiếng Anh"). Muốn nhiều ngôn ngữ hơn thì thêm từng ngôn ngữ theo quy trình trên; mỗi ngôn ngữ là ~1 000 chuỗi cần dịch và cần người bản ngữ đọc lại.

**Phát hiện khi làm:** (1) B18-07: rà mã Kotlin tìm chuỗi tiếng Việt viết cứng thấy 15 chỗ; nặng nhất là mẫu đánh số trang `"Trang {n}"` (nhãn "Page 1" nhưng PDF vẫn in "Trang 1"). Đã chuyển hết sang tài nguyên (`AppText` cho lớp tiện ích không có `Context`, 4.46); còn đúng 3 chỗ cố ý giữ: tên bản ngữ "Tiếng Việt" trong danh sách dịch, từ khoá "MỤC LỤC" dò mục lục, và nhận diện dòng giữ chỗ OCR cũ bằng tiếng Việt để đọc được tệp .txt đã tạo trước đây. (2) `doc_sync_check.py` đọc tên điểm vào (tiếng Việt) trong `values/strings.xml`, giờ là tiếng Anh nên báo lệch; đã cho nó tìm trong mọi `values*/strings.xml`. (3) Một lần chạy lệnh nối chuỗi bằng `&&` dừng giữa chừng vì lệnh `mv` thừa, khiến bản script cũ chạy tiếp và ghi lại `values-en` cũ: bộ kiểm có mục "thư mục values* trên đĩa = đúng danh sách ngôn ngữ" bắt được ngay.

**Kiểm chứng (`i18n_check.py`; `strings_check.py` có sẵn cũng đạt):** với MỌI ngôn ngữ: tập khoá = tiếng Anh (1 020 chuỗi + 3 mảng), dấu thay thế (`%1$s`, `%d`, `%%`, `{n}`, `{N}`...) giữ nguyên số lượng ở từng chuỗi, `\\n` khớp, mọi dấu nháy kép có thoát (ngoặc riêng như 「」 hợp lệ), không lẫn chữ Việt vào ngôn ngữ khác, chuỗi giống hệt tiếng Anh chỉ là tên riêng đã liệt kê (OK, PDF, EPUB, A4...), mọi tệp sinh ra khớp bản sinh lại, thư mục `values*` trên đĩa đúng danh sách, `locales_config.xml` và hai mảng khớp `languages.txt`. **Không kiểm được:** CHẤT LƯỢNG VĂN PHONG - bản dịch do mô hình ngôn ngữ viết, cần người bản ngữ đọc lại trước khi phát hành (đặc biệt các câu dài về nén, chữ ký số, chế độ riêng tư); giao diện chưa chạy trên máy với từng ngôn ngữ (chữ Anh / Nhật có thể dài hơn hoặc ngắn hơn chữ Việt, nút có thể tràn hoặc lệch).

### 4.46. Phiên 18 (tiếp 11) -- chọn ngôn ngữ trong app và chuỗi theo ngôn ngữ cho lớp tiện ích

- `AppLanguages` (`util`): `apply(tag)` gọi `AppCompatDelegate.setApplicationLocales` (androidx.appcompat 1.7 - chạy trên mọi phiên bản Android; màn hình đang mở được tạo lại tự động); `tag = null` = quay về THEO NGÔN NGỮ MÁY. `currentTag()` đọc lựa chọn hiện tại. `checkedIndex(tags, current)` chọn mục đang dùng trong bộ chọn: 0 = theo máy, khớp CHÍNH XÁC thắng khớp theo tiền tố ("pt-BR" chọn pt-BR chứ không phải pt), tiền tố dài nhất thắng, không khớp = 0.
- Bộ chọn: liên kết "🌐 Language / Ngôn ngữ / 言語" (theo ngôn ngữ đang dùng) ở cuối màn chính, trên liên kết Trợ giúp; hộp thoại liệt kê "Theo ngôn ngữ của máy" + từng ngôn ngữ bằng TÊN BẢN NGỮ. Lựa chọn được nhớ: Android 13+ lưu hệ thống (và đồng bộ với Cài đặt hệ thống); Android thấp hơn nhờ dịch vụ `AppLocalesMetadataHolderService` với `autoStoreLocales` khai báo trong manifest (đúng theo hướng dẫn của Android).
- `AppText` (`util`): chuỗi theo ngôn ngữ đang chọn cho các lớp tiện ích không có `Context` (`EbookBuilder`, `EpubReader`, `PdfExporter`, `PdfComparer`, `ContentIndex`): nội dung chúng GHI VÀO tệp xuất ("(không có văn bản)", "Chương N", chú thích báo cáo so sánh) phải theo ngôn ngữ giao diện. Từ Android 12 trở xuống chỉ Activity theo ngôn ngữ đã chọn nên `AppText.localized` tự áp ngôn ngữ đó lên `Context` ứng dụng (`DocScannerApp.instance`). `EpubTools.build` nhận nhãn "Phần N" qua tham số (`partLabel`) để lõi thuần tuý vẫn kiểm được bằng bản Java.
- `AppText.isOcrPlaceholder`: dòng giữ chỗ OCR trong `.txt` được nhận bằng chuỗi của ngôn ngữ hiện tại HOẶC bản Việt / Anh cũ, để chỉ mục tìm kiếm không lập dòng đó thành nội dung; dấu `--- Trang N ---` là ĐỊNH DẠNG tệp (không phải nhãn giao diện) nên giữ nguyên để đọc được tệp cũ.
- Kiểm chứng: `app_languages_check.py` (2 014 ca `checkedIndex`: bản Java so với bản tham chiếu Python viết riêng); `i18n_check.py` kiểm `locales_config.xml` + hai mảng ngôn ngữ khớp `languages.txt`; `static_refs_check` và `xmllint` đạt. **Chưa chạy:** hộp thoại chọn ngôn ngữ, việc tạo lại màn hình, dịch vụ lưu ngôn ngữ trên Android < 13 (cần máy thật); cần thử: đổi ngôn ngữ trong app -> màn chính đổi ngay; đổi ngôn ngữ máy sang tiếng Nhật -> app tự hiện tiếng Nhật; sang tiếng Thái -> hiện tiếng Anh.
### 4.47. Phiên 19 — đọc lại tài liệu + PDF "Thiếu gì để bán app", đối chiếu với MÃ THẬT, làm các mục còn thiếu (xuất ngay sau từng mục)

**Cách làm (theo nguyên tắc 0e00 và yêu cầu của chủ dự án):** đọc mục 0, 6, 10, 11, 4.35–4.46 và toàn bộ PDF (87 trang), rồi `grep` MÃ THẬT cho từng mục của PDF. Kết quả: phần lớn PDF đã được làm; phần chưa có trong mã (đã grep, không suy đoán) gồm: ghép tờ poster / lát trang, nhập Markdown/HTML/CSV/Word → PDF, tóm tắt / phân loại / gợi ý thẻ từ nội dung, TIFF nhiều trang, tạo mã QR, sao lưu theo lịch, cảnh báo PDF đã ký / pin yếu / máy nóng, widget quét nhanh, di chuyển / đổi cấp mục lục (mục 6.5 cũ), eSCL hai mặt, từ chữ thật cho tô sáng. Môi trường phiên này vẫn KHÔNG có Kotlin / Gradle / mạng tải gói nên mã Kotlin vẫn chỉ kiểm bằng bản Java / Python song song + `static_refs_check` (như 4.27–4.46). Mỗi mục dưới đây ghi rõ cái gì ĐÃ kiểm, cái gì CHƯA.

#### 4.47.1 Sửa mục lục PDF: đưa lên / xuống, thụt vào, đưa ra ngoài (`PdfBookmarks`, `PdfBookmarkActivity`)

Mục 6.5 cũ còn "di chuyển / đổi cấp một mục lục". Làm trên danh sách PHẲNG có mức (như mọi phép sửa ở 4.34), mỗi mục cùng các con của nó là một KHỐI:
- `moveUp` / `moveDown`: đổi chỗ khối với khối của ANH EM liền trước / sau (cùng cha); không chui ra khỏi cha; không có anh em thì không đổi.
- `indent`: khối thành con cuối của anh em liền trước (mức +1, giữ nguyên chỗ; chỉ khi mục liền trên cùng mức hoặc sâu hơn); `outdent`: mức -1, giữ nguyên chỗ; các anh em đứng sau thành CON của mục vừa đưa ra (danh sách giữ thứ tự nên trình soạn thảo hiển thị đúng thứ nhìn thấy). Mục cấp cao nhất không đưa ra ngoài được.
- `canMoveUp` / `canMoveDown` / `canIndent` / `canOutdent` quyết định nút nào hiện trong hộp thoại. **Cạm bẫy đã tránh khi viết:** `Entry` không phải `data class` và `normalizeLevels` tạo đối tượng mới, nên so `moveUp(...) != entries` LUÔN đúng (nút nào cũng hiện); phải dùng hàm `can*` (bài kiểm bắt lỗi này bằng cách so với "phép có thật sự đổi danh sách").
- Kiểm chứng: `bookmarks_check.py` phần A3 — bản Java theo MỨC so với MÔ HÌNH CÂY viết riêng (đổi chỗ anh em, đổi cha trên cây rồi trải phẳng) trên 3 000 ca; 2 000 ca cho các hàm `can*`; bất biến hoán vị (không mất / thêm / đổi tên / đổi trang) và hợp lệ về mức; thử âm tính (bản "đổi cấp một mình mục đó, bỏ con lại" khác mô hình cây ở 73/1500 ca). Bài kiểm đầu-cuối trên PDF thật (pikepdf, qpdf) của 4.34 vẫn đạt. **Chưa chạy:** hộp thoại trên máy (4 chuỗi mới + câu gợi ý đã có đủ Anh / Việt / Nhật).

#### 4.47.2 Nhập Markdown / HTML / Word (.docx) / CSV-TSV trong "Chuyển đổi" (`DocumentImport`, `TablePdfBuilder`, `ConvertDocumentActivity`)

PDF "Thiếu gì để bán app": mục 78-84 (Word / HTML / Markdown / CSV → PDF), L1-L5 và 9.11-9.14 (nhập định dạng khác). Trước phiên 19 công cụ chuyển đổi chỉ đọc PDF / EPUB / TXT / ảnh. Nay có hai nguồn mới trong hộp thoại "Chọn định dạng nguồn":
- **Markdown / HTML / Word (.docx) → PDF, EPUB hoặc FB2.** `DocumentImport` (thuần: chuỗi vào, khối ra; không Android, không PdfBox) đọc thành các KHỐI: tiêu đề (cấp 1-6), đoạn, mục danh sách (cấp lồng + dấu đầu dòng hoặc số), khối mã, hàng bảng (ô nối bằng " | "). `chapters()` mở một chương ở mỗi tiêu đề cấp 1-2 (chữ trước tiêu đề đầu tiên vào chương mang tên tệp), tiêu đề sâu hơn thành đoạn, mục danh sách thụt 2 dấu cách mỗi cấp; rồi `TextPdfBuilder` / `EbookBuilder` làm như mọi nguồn khác (kể cả dấu trang chương trong PDF). **Đây là chuyển đổi VĂN BẢN:** tiêu đề, đoạn, danh sách, mã, bảng theo thứ tự đọc; phông, màu, ảnh và bố cục trang gốc KHÔNG được giữ.
- **CSV / TSV → PDF.** `parseCsv` theo RFC 4180 (nháy kép, `""`, xuống dòng trong ô, CRLF / CR, BOM, dòng trống không thành hàng), `detectDelimiter` chọn `,` `;` TAB `|` theo số cột nhất quán ở 30 hàng đầu; `TablePdfBuilder` vẽ LƯỚI thật (chữ chọn / tìm được): hàng đầu là tiêu đề (nền xám, đậm, lặp ở đầu mỗi trang), ô dài tự xuống dòng trong cột, hàng không bị cắt qua trang, tự chuyển ngang khi các cột không vừa khổ dọc; `TableLayout.columnWidths` chia bề rộng (tổng = min(cần, có), không cột nào rộng quá nhu cầu hay hẹp dưới mức tối thiểu khi còn chỗ, giữ thứ tự độ rộng). Giới hạn có chủ ý: tệp nguồn ≤ 40 MB; bảng ≤ 60 000 hàng (PDF sẽ hàng nghìn trang); một ô dài hơn một trang bị cắt ở cuối trang kèm "…".
- **Mã hoá văn bản** (`decodeText`): BOM (UTF-8, UTF-16 LE / BE) → `charset=` trong 2 KB đầu của HTML → UTF-8 chặt → Windows-1252 (CSV xuất từ Excel cũ, trang web cũ; không bao giờ lỗi). **Thực thể ký tự:** bảng 252 tên HTML 4 (sinh từ `html.entities.name2codepoint`, `lang` / `rang` đặt theo HTML5), số thập phân / thập lục, 0x80-0x9F theo Windows-1252 như trình duyệt; tên lạ hoặc mã sai để nguyên.
- **Kiểm chứng (`doc_import_check.py` + `DocImportCheck.java`, bản Java cùng thuật toán):** Markdown so với CÂY CÚ PHÁP của `pandoc -f commonmark+pipe_tables` trên 700 tài liệu sinh ngẫu nhiên (6 944 khối: 826 tiêu đề, 1 299 mục danh sách từ cấp 2, bảng, mã, trích dẫn, ngắt dòng cứng, ký tự thoát, `3*4*5`, snake_case); HTML so với `lxml.html` (DOM thật) trên 600 trang; .docx so với `python-docx` (tạo tệp thật rồi đọc lại) trên 250 tệp; CSV so với `csv.reader` trên 1 500 tệp + 7 ca riêng; nhận dạng dấu ngăn đúng 800/800 tệp sạch và 600/600 khi ô chứa dấu ngăn khác; 360 thực thể = `html.unescape`; 12 ca mã hoá; 3 000 ca chia cột theo tính chất; 1 000 ca chương so với bản Python viết riêng; 6 thử âm tính (dòng trống làm mất độ sâu danh sách, không giải mã thực thể, xoá mã trong dấu backtick, nháy kép đôi, không bỏ `<script>`, không nhận Heading). **Lỗi tìm ra nhờ đối chiếu và đã sửa trước khi giao:** ngắt dòng cứng bị mất (đã cắt cả cuối dòng), ký tự thoát `\*` bị nuốt vào cặp nhấn (phải che ký tự thoát TRƯỚC khi bỏ dấu nhấn), danh sách có dòng trống giữa các mục mất độ sâu, front matter YAML nhận nhầm một đường kẻ `---`, thiếu thực thể `&eacute;` (nay có đủ bảng HTML 4), mức lồng của `List Bullet 2` trong .docx, dòng trống CSV thành hàng.
- **Chưa kiểm:** (1) mã Kotlin không chạy được ở đây (chỉ bản Java song song + `static_refs_check`); (2) `TablePdfBuilder` vẽ bằng `PdfDocument` / `Canvas` nên chưa thấy kết quả trên máy (chỉ phần tính cột đã kiểm); (3) hộp thoại hai nguồn mới và ba chuỗi (Anh / Việt / Nhật) chưa bấm thử; (4) Markdown ngoài phần giao với CommonMark đã liệt kê (mục danh sách có nhiều đoạn, khối mã trong mục danh sách, HTML dạng khối, tham chiếu liên kết `[a]: url` ở cuối) không được kiểm và có thể ra khác pandoc; (5) .docx: không đọc hộp văn bản, chú thích cuối trang, bảng lồng nhau; ODT / RTF / PPTX / XLSX chưa nhập (hướng đã tra: ODT, PPTX, XLSX cũng là ZIP + XML nên dùng được cùng cách `blocksFromDocx`; RTF cần bộ đọc riêng).

#### 4.47.3 Áp phích (poster): một trang phóng to ra nhiều tờ A4 (`PdfPoster`, menu "Gộp trang & in sổ gấp")

PDF "Thiếu gì để bán app" mục B10 / 8.2 (in poster / lát trang). Là phép NGƯỢC của `PdfImposer`: một trang trải ra nhiều tờ để in, cắt, dán. Người dùng chọn số tờ theo chiều ngang (2-5); số hàng suy ra từ tỉ lệ trang (tối thiểu để phủ hết chiều cao); trang dọc dùng tờ A4 dọc, trang ngang dùng tờ A4 ngang. Hai tờ kề nhau lặp một dải chồng **10 mm** để dán không hở, lề **7 mm** cho máy in, bốn dấu góc ngoài vùng in chỉ chỗ cắt. Không rasterize: trang được nhập thành form XObject (chữ vẫn là vector) và đặt bằng `[cửa sổ ô + co vừa] x [nghịch đảo ma trận hiển thị của PdfPageGeometry]`, cắt theo vùng in. Hiện chỉ làm **trang đầu** của tệp (hàm `poster(src, out, pageIndex, cols)` nhận chỉ số trang; chưa có hộp thoại chọn trang).
- **Kiểm chứng (`poster_check.py` + `PosterCheck.java`):** (1) `plan()` bản Java cùng công thức float trên 4 000 ca (9 cỡ trang x 2-6 tờ ngang) so với tính chất hình học tính lại độc lập: số ô, bề rộng phủ, số hàng tối thiểu, trang nằm trong vùng phủ, chồng đúng 10 mm; (2) với poppler: 16 tổ hợp (xoay 0/90/180/270 x CropBox lệch x 2-3 tờ ngang), dựng các tờ đúng phép biến đổi của Kotlin, vẽ từng tờ, GHÉP LẠI theo cửa sổ rồi so với MỘT tờ khổng lồ cùng phép biến đổi (khớp ≥ 99,5 % điểm ảnh và ≥ 97 % điểm có mực) + bốn ô màu đúng góc, đúng chiều; (3) thử âm tính: bản "bỏ chồng 10 mm" khớp 0,39 và bản "thiếu một hàng" khớp 0,46 trên điểm có mực (đúng: 0,996).
- **Chưa kiểm:** phần PdfBox (`LayerUtility`, `clip()`, `drawForm`, dấu góc) chưa chạy; hộp thoại chọn số tờ và 4 chuỗi mới (Anh / Việt / Nhật) chưa bấm thử; chưa in thử ra giấy. Một giới hạn đã biết: trang quá nhỏ so với số tờ (ví dụ thẻ căn cước phóng 6 tờ) sẽ mờ vì nguồn là ảnh quét có độ phân giải hữu hạn - đó là đặc tính của ảnh, không phải của phép phóng.

#### 4.47.4 Xuất TIFF nhiều trang: đen trắng Group 4 hoặc màu Deflate (`TiffWriter`, `ConvertDocumentActivity`)

PDF "Thiếu gì để bán app" mục 10.10 (xuất TIFF nhiều trang; định dạng của lưu trữ, máy chủ fax, nhiều quy trình OCR / pháp lý). Trong "Chuyển đổi" → nguồn PDF có thêm hai đích: **TIFF đen trắng, nhẹ nhất** (2480 px = A4 ở 300 dpi, bộ lọc BW, CCITT Group 4) và **TIFF màu** (1654 px = A4 ở 200 dpi, RGB + Deflate + predictor ngang). Mỗi trang được dựng bằng `PdfRenderer` và GHI NGAY ra đĩa (`TiffWriter.Writer` dùng `RandomAccessFile`: ghi dải dữ liệu rồi IFD, rồi vá con trỏ "IFD kế" của trang trước), nên tệp 100 trang màu không bao giờ nằm trọn trong bộ nhớ. Trang G4 được **giải mã lại để kiểm** (`Ccitt4Decoder.verify`) trước khi dùng; nếu kiểm hỏng (không dự kiến) trang đó lưu xám 8 bit + Deflate thay vì ghi dữ liệu hỏng.
- **Quy ước màu của G4 (tra cứu bằng thực nghiệm, không đoán):** ban đầu tôi giả định `PhotometricInterpretation = 0` (WhiteIsZero, kiểu fax). Bài kiểm cho thấy libtiff ghi chính luồng mà `Ccitt4Encoder` tạo ra (đã khớp từng byte với libtiff ở phiên 6-7, ảnh Pillow chế độ "1") với **thẻ 1 (BlackIsZero)**, và cùng luồng đó đọc lại bị ĐẢO MÀU nếu ghi thẻ 0. Điều này cũng khớp `/BlackIs1 false` của đường PDF (bit 0 = đen, bit 1 = trắng). Nay dùng thẻ 1; thẻ 317 (predictor) chỉ ghi cho trang Deflate (libtiff cảnh báo nếu có ở dải CCITT).
- **Kiểm chứng (`tiff_check.py` + `TiffCheck.java`, bản Java cùng bố cục tệp):** Java ghi, rồi đọc lại bằng BA bộ đọc độc lập: (1) bộ phân tích cấu trúc TIFF viết riêng (đầu tệp, chuỗi IFD không vòng, thẻ tăng dần, offset chẵn và trong tệp, các vùng không chồng nhau); (2) libtiff qua Pillow: 40 trang G4 (kích thước 1x1 … 310x438, trang trắng / đen / nhiễu / chữ giả / sọc, dpi 72-300) từng điểm ảnh + dpi; 5 trang xám / RGB (gồm nhiễu hoàn toàn và 1x1); (3) libtiff qua OpenCV (`imreadmulti`) và ImageMagick. Luồng G4 trong bài kiểm lấy từ chính libtiff (Pillow `group4`), không từ bộ mã hoá của ứng dụng. Thử âm tính: bản ghi predictor = 1 dù đã vi phân cho ảnh sai; bản G4 với thẻ 0 cho ảnh đảo màu; cả hai bị bắt.
- **Chưa kiểm:** (1) Kotlin chưa chạy; (2) đường `PdfRenderer` → `ImageProcessor.applyFilter(BW)` → `Ccitt4Encoder` → TIFF chưa chạy trên máy (các mảnh đã kiểm riêng: bộ mã hoá ở 4.11, bộ ghi ở đây); (3) 2 chuỗi mới (Anh / Việt / Nhật) và hộp thoại 4 đích chưa bấm thử; (4) `PdfRenderer` giới hạn chiều cao 6 000 px (`render` cắt ở đó) nên trang rất cao bị méo; (5) TIFF màu của một tài liệu dài có thể rất lớn (A4 màu 200 dpi ≈ vài MB / trang): chưa có cảnh báo dung lượng.

#### 4.47.5 Tạo mã QR: liên kết, văn bản, Wi-Fi (`QrEncoder`, `QrPdfBuilder`, thẻ công cụ "Mã QR")

PDF "Thiếu gì để bán app" mục L14 / M7 (xuất / chia sẻ bằng mã QR). `QrEncoder` là bộ mã hoá QR **thuần Kotlin, không thư viện**: phiên bản 1-40, bốn mức sửa lỗi L / M / Q / H, chế độ số / chữ-số / byte (UTF-8), tám mặt nạ + chấm điểm phạt theo ISO/IEC 18004 để chọn mặt nạ tốt nhất; tự chọn phiên bản nhỏ nhất và nâng mức sửa lỗi miễn phí khi còn chỗ (`boost`). Cấu trúc theo thuật toán của bộ mã hoá tham chiếu Project Nayuki (MIT): bảng số từ mã sửa lỗi / số khối theo phiên bản, Reed-Solomon trên GF(2^8) đa thức 0x11D, xen kẽ khối, đặt bit theo đường zig-zag, thông tin định dạng BCH(15,5) và phiên bản BCH(18,6). `wifiPayload` dựng chuỗi `WIFI:T:WPA;S:ssid;P:mật khẩu;;` (thoát `\\ ; , : "`). `QrPdfBuilder` vẽ mã thành một trang A4 bằng HÌNH VUÔNG vector (nét sắc ở mọi cỡ in, viền trắng 4 mô-đun) kèm dòng chú thích; chú thích của Wi-Fi chỉ ghi TÊN mạng, không bao giờ ghi mật khẩu (tờ giấy có thể dán ở nơi công cộng). Thẻ "Mã QR" ở màn hình chính: chọn "Liên kết hoặc văn bản" / "Mạng Wi-Fi", nhập, bấm Tạo mã; tệp PDF vào lịch như mọi tài liệu.
- **Kiểm chứng (`qr_check.py` + `QrCheck.java`, bản Java cùng thuật toán):** Java tạo ma trận; bài kiểm vẽ ra ảnh rồi giải bằng **BA bộ giải độc lập của OpenCV** (WeChat QR kiểu ZXing, `QRCodeDetectorAruco`, `QRCodeDetector` cổ điển; đúng khi ≥ 2 bộ đồng ý với chuỗi gốc, vì bộ cổ điển bỏ sót ~1/3 mã hợp lệ - đã xác nhận bằng cách giải đúng chính những mã đó bằng hai bộ kia): (1) **160 ô = 40 phiên bản x 4 mức** với tải ĐẦY sức chứa (chạm đúng phiên bản đó): 160/160 đạt, chọn đúng phiên bản nhỏ nhất; sức chứa khớp bảng ISO đã biết (1-L = 19 ... 40-L = 2 956); (2) 406 chuỗi số / chữ-số / byte (tiếng Việt, tiếng Nhật, URL, vCard, 7 089 chữ số ở phiên bản 40-L); (3) **khả năng sửa lỗi:** đảo hẳn một mảng mô-đun (L 2 %, M 4 %, Q 7 %, H 9 % diện tích) vẫn giải đúng, còn 30 % ở mức L thì hỏng (đối chứng); (4) thông tin định dạng và phiên bản kiểm bằng TOÁN BCH độc lập (chia hết đa thức sinh, hai bản khớp nhau, mức + mặt nạ + phiên bản khớp) và hằng số của chuẩn (v7 = 0x07C94, v40 = 0x28C69) - bước này cần vì bộ giải tự sửa 1-3 bit sai ở đó nên giải mã không bắt được lỗi; (5) chuỗi Wi-Fi; (6) thử âm tính: sai một số trong bảng sửa lỗi, sai vị trí mẫu căn chỉnh v32, xen kẽ sai thứ tự, đa thức sinh Reed-Solomon sai: đều bị bắt.
- **Lỗi của BÀI KIỂM tìm thấy khi viết (không phải của bộ mã hoá, ghi lại để khỏi lặp):** `QRCodeDetector` cổ điển của OpenCV không giải được khoảng 1/3 mã hợp lệ (nên cần nhiều bộ giải); bộ giải chuỗi byte không ASCII phụ thuộc đoán bảng mã; vùng "hư hại" cho thử sửa lỗi phải nằm trong vùng dữ liệu (không chạm mẫu tìm / định thời / định dạng).
- **Chưa kiểm:** Kotlin chưa chạy; `QrPdfBuilder` (vẽ `Canvas`) và hộp thoại chưa chạy trên máy; chưa quét thử mã trên PDF in ra bằng camera điện thoại; chế độ Kanji và ECI (chọn bảng mã) không làm (UTF-8 ở chế độ byte được hầu hết điện thoại đọc đúng); không có "nhiều mã trên một trang" hay logo ở giữa.

### 4.48. Phiên 20 — làm tiếp các mục còn lại của PDF "Thiếu gì để bán app" (xuất ngay sau từng mục)

Phiên 19 kết thúc với danh sách "Phần chưa làm" (nhập ODT/PPTX/XLSX/RTF, tóm tắt + phân loại, sao lưu theo lịch, cảnh báo sửa PDF đã ký, dấu thời gian, eSCL hai mặt,
lớp chữ thật cho tô sáng, thêm ngôn ngữ; mã QR đã làm ở 4.47.5). Đối chiếu với MÃ THẬT (grep từng mục) trước khi làm: tám mục đều chưa có trong mã. Theo nguyên tắc 0e00,
mỗi chỗ tài liệu ghi "chưa xác nhận" được tra lại bằng web trước khi viết mã (kết quả ghi ở từng mục dưới đây).

#### 4.48.1 Cảnh báo khi sửa PDF đã ký (`PdfSignatureProbe`, `SignedPdfGuard`)

**Vấn đề.** Mọi công cụ ghi lại PDF (PdfBox lưu toàn bộ, vẽ lại thành ảnh, gộp, nén...) làm MẤT HIỆU LỰC chữ ký số của tệp nguồn: tệp mới có byte khác với vùng
`/ByteRange` đã ký, Acrobat báo "tài liệu đã bị thay đổi" hoặc bỏ chữ ký. Ứng dụng luôn ghi ra tệp MỚI và để nguyên tệp gốc, nên người dùng chỉ cần được BIẾT điều đó
trước khi bấm tiếp, không cần bị chặn. `PdfFormFiller.isSigned` (4.25) chỉ biết "có chữ ký" bằng PdfBox (phải mở cả tệp, lỗi trên tệp hỏng) và chỉ dùng ở màn hình biểu mẫu.

**Bộ dò (`PdfSignatureProbe.kt`, thuần JVM, đọc byte).** Quét khoá `/ByteRange` theo khối 1 MiB (chồng thêm độ dài khoá, nên khoá cắt ngang mép khối vẫn tìm đúng một lần).
Một chữ ký THẬT thoả điều kiện cấu trúc mà văn bản vô tình chứa chữ "/ByteRange" hầu như không bao giờ thoả: `a == 0`, byte tại `a+b` là `<`, byte tại `c-1` là `>`,
`c+d` không vượt quá cuối tệp (vùng bị bỏ ra đúng là chuỗi hex `/Contents`). Chỗ dành sẵn chưa ký (`[0 ******** ...]`, `[0 0 0 0]`) tự bị loại. SubFilter, `/Type /DocTimeStamp`,
`/TransformMethod /DocMDP` + `/P` (mức 1 cấm mọi thay đổi / 2 cho điền biểu mẫu + ký / 3 thêm chú thích; thiếu `/P` là 2) đọc từ chữ của CHÍNH từ điển đó: hai cửa sổ 4 KiB,
trước chuỗi hex (lùi tới `endobj` trước) và sau nó (tới `endobj` sau), vì `/Contents` có thể đứng trước hoặc sau `/ByteRange`.
`effect(kết quả, công cụ)`: `READ_ONLY` -> không đổi; `REWRITES` -> BREAKS nếu có bất kỳ chữ ký / dấu thời gian nào; `APPENDS_FORM` và `APPENDS_SIGNATURE` (cập nhật tăng dần, giữ
chữ ký cũ) -> KEEPS, trừ khi tài liệu được CHỨNG NHẬN mức 1 -> BREAKS. Chỉ BREAKS mới hiện hộp thoại.

**Giao diện (`SignedPdfGuard.kt`).** `confirm(activity, file, tool)` / `confirmUri(...)` (tệp chỉ có Uri thì sao chép ra tệp tạm để đọc rồi xoá): đọc ở luồng IO, không có chữ ký hoặc không đọc được
thì KHÔNG hiện gì. Hộp thoại nêu số chữ ký, tệp gốc không đổi, bản mới sẽ không còn chữ ký hợp lệ, thêm một dòng nếu tài liệu được chứng nhận hoặc đã bị đổi sau chữ ký cuối.
Gắn vào 8 màn hình (Số trang / đầu chân trang, Tô sáng, Che thông tin, Ký & đóng dấu, Điền biểu mẫu [chỉ hỏi khi chứng nhận mức 1], Chú thích, Sửa chữ, Quản lý trang) và 9 công cụ trong
`MainActivity` (nén, thông tin PDF, mật khẩu / watermark, PDF tìm kiếm được, ký số [APPENDS_SIGNATURE], tuyến tính hoá, sửa PDF hỏng, tự thêm liên kết, PDF/A).
CHƯA gắn: xử lý hàng loạt (`runBatch`), gộp / tách / áp phích / sách gấp (tạo tài liệu MỚI từ trang, không phải "sửa" tệp ký).

**Đã kiểm (`signed_pdf_check.py` + `SignatureProbeCheck.java` + `signed_pdf_lib.py`).** Bản Java chạy đúng thuật toán của Kotlin. (A) 8 PDF ký THẬT (CMS do `CmsCheck.java` dựng, `pdfsig` báo
"Signature is Valid"): 1-3 chữ ký nối tiếp, `/Contents` trước / sau `/ByteRange`, DocMDP mức 1-3, chỉnh sửa sau khi ký; "Signed Ranges" của `pdfsig` khớp (a, a+b, c, c+d) từng chữ ký và
"Total document signed" khớp "không đổi sau chữ ký cuối". (B) 200 PDF ngẫu nhiên (CMS giả; 0-4 chữ ký, DocTimeStamp, đệm, 3 cỡ khối 997 / 4096 / 1 MiB): vị trí và mức DocMDP đúng với bộ dựng,
và khớp `pdfsig` ở mọi tệp mà `pdfsig` liệt kê được. (C) khoá `/ByteRange` cắt ngang mép khối ở 15 độ lệch: đúng một lần mỗi chữ ký. (D) không báo nhầm 5 kiểu (chữ "/ByteRange" trong luồng
nội dung, chỗ dành sẵn `****`, `[0 0 0 0]`, vùng chạy quá cuối tệp, `a != 0`). (E) 12 ô của bảng `effect()`. (F) 3 thử âm tính bị bắt: bộ dò ngây thơ ("có chữ /ByteRange") báo nhầm 5/5 ca D;
bản Java bỏ phần chồng của khối bỏ sót ở C; bản bỏ kiểm `<` / `>` báo nhầm ở D. Chạy ~1 phút (cần `cryptography`, `pdfsig`, `java`).
**Giới hạn nói thẳng:** một vật CỐ TÌNH giả đúng cấu trúc (có `<` và `>` đúng chỗ) bị coi là chữ ký; hướng sai này an toàn (chỉ thừa một cảnh báo). Chữ ký nằm trong luồng đối tượng nén
không được dò (đặc tả không cho phép từ điển chữ ký trong luồng đối tượng). Kotlin chưa biên dịch; `static_refs_check` đạt.

#### 4.48.2 Nhập ODT / PPTX / XLSX / RTF (`OfficeImport`, `RtfImport`, `TablePdfBuilder.buildSheets`)

**Phạm vi (nói thẳng).** Nhập VĂN BẢN, như `DocumentImport`: tiêu đề, đoạn, mục danh sách, hàng bảng theo thứ tự đọc. KHÔNG nhập: ảnh, biểu đồ, SmartArt, chú thích cuối trang / cuối bài, ghi chú, văn bản bị xoá
trong chế độ theo dõi thay đổi, mục lục tự sinh của ODT, ghi chú của người trình bày, trang tính ẩn, công thức (đọc KẾT QUẢ đã lưu), tiêu đề / chân trang. Hộp văn bản: ODT có (chữ trong khung được ghi TRƯỚC đoạn chứa khung),
RTF không. Ba định dạng văn bản (ODT, PPTX, RTF) đi qua `convertMarkup` (PDF / EPUB / FB2, mỗi slide là một chương vì tiêu đề slide là mục cấp 2); XLSX đi qua `convertTable` -> `TablePdfBuilder.buildSheets`.

**Máy quét XML (`OfficeImport.scanXml`).** Không phải bộ phân tích đầy đủ: thẻ, thuộc tính (cả nháy đơn và nháy kép, `>` trong giá trị), chữ, CDATA; bỏ chú thích / chỉ thị xử lý / DOCTYPE; 5 thực thể XML + tham chiếu số
(`&eacute;` của HTML không tồn tại trong XML nên KHÔNG dùng bảng HTML như `DocumentImport.decodeEntities`). XLSX bỏ tiền tố vùng tên (`x:row` = `row`). Mọi phần của gói ZIP đọc qua `zipTexts` (mỗi phần <= 64 MB, tổng <= 160 MB; quá thì trả rỗng).

**ODT.** `text:h` (mức = `text:outline-level`, 1..6), đoạn kiểu `Title` = mức 1, `text:list` lồng nhau (độ sâu = số `text:list` đang mở; đánh số hay gạch đầu dòng theo `text:list-level-style-number` / `-bullet` của kiểu danh sách ở
`content.xml` + `styles.xml`, kiểu kế thừa từ danh sách cha khi danh sách con không ghi), chỉ đoạn ĐẦU của mỗi mục là mục danh sách (đoạn nối tiếp là đoạn thường), bảng (chỉ hàng của bảng ngoài cùng; bảng lồng và nhiều đoạn
trong một ô gộp thành một ô; `covered-table-cell` bỏ). `text:s`, `text:tab`, `text:line-break`. **Lỗi thật bài kiểm bắt được:** chữ nằm trong phần tử bị bỏ (chú thích cuối trang) từng rò vào đoạn đang mở vì `text()` không kiểm tra
bộ đếm bỏ qua; đã sửa.

**PPTX.** Thứ tự slide = `p:sldIdLst` + `presentation.xml.rels` (KHÔNG theo số trong tên `slideN.xml`; bài kiểm xáo trộn thứ tự). Mỗi slide: tiêu đề (`ctrTitle` / `title`) = mục cấp 2 (không có tiêu đề -> nhãn
"Slide n" lấy từ `R.string.convert_slide_n`, n = vị trí trình chiếu; slide không có chữ nào bị bỏ), khung nội dung = mục danh sách (độ sâu = `lvl` + 1, trừ đoạn có `a:buNone`), hộp chữ thường = đoạn (mục danh sách chỉ khi có `buChar` /
`buAutoNum`), bảng = hàng, nhóm hình được duyệt theo thứ tự tài liệu; ô số trang / ngày / chân trang bỏ; **`mc:Fallback` bỏ** (PowerPoint ghi cùng một hình hai lần trong `mc:AlternateContent`).

**XLSX.** `sheetsFromXlsx`: trang theo thứ tự sổ, bỏ trang ẩn / `veryHidden` và trang không có ô nào; hàng trống bỏ, cột GIỮ ĐÚNG CHỖ (ô thưa `AB5` ở cột 28 cho 27 ô rỗng đứng trước); tối đa 100 000 hàng, 1 024 cột. Giá trị ô: chuỗi dùng chung
(bỏ `rPh` = furigana), `inlineStr`, `str`, lỗi, bool -> TRUE / FALSE, số. **Số:** "General" = tối đa 15 chữ số có nghĩa (BigDecimal từ CHÍNH chuỗi trong tệp), số mũ chỉ khi >= 1e15 hoặc < 1e-9; các định dạng ĐƠN GIẢN theo
mã của ô: `0`, `0.00`, `#,##0.00`, phần trăm, chữ / ký hiệu tiền trước hoặc sau (`"VND"`, `$`, `[$€-407]`), phần âm riêng (`#,##0;(#,##0)`), làm tròn nửa lên; mã khác (khoa học `0.00E+00`, phân số `# ?/?`, dấu phẩy chia nghìn
ở cuối, điều kiện `[>1000]`) lùi về General. **Ngày / giờ luôn ra ISO** (`yyyy-mm-dd`, `hh:mm[:ss]`, `[h]:mm:ss` cộng dồn), BẤT KỂ mã định dạng của người dùng (`d/m/yyyy` ra `2024-03-09`): nhận diện bằng mã (chữ trong dấu nháy,
`[Red]`, `[$-409]` không tính; `m` là phút khi đi cùng `h` hoặc `s`), không dùng `java.time` (minSdk 24). Hệ 1900 có "ngày 29/2/1900 không có thật" (serial 60) và serial 0 = `1900-01-00`; hệ 1904 qua `workbookPr date1904`.

**RTF (`RtfImport`).** Đầu vào là byte đọc dạng ISO-8859-1 (`RtfImport.decode`). `\'hh` giải mã bằng trang mã của PHÔNG HIỆN TẠI (`\fcharsetN` / `\cpgN` trong bảng phông, mặc định `\ansicpgN`), hai `\'hh` liên tiếp thành một ký tự
Shift-JIS / GBK / Big5 / Hàn; `\uN` kèm `\ucN` ký tự dự phòng; `\binN` nhảy qua dữ liệu nhị phân; nhóm `\*` bỏ trừ `\listtext` / `\pntext`; bảng kiểu (`heading 1..9`, `Title`) và `\outlinelevelN` cho tiêu đề; danh sách =
đoạn có nhóm `{\listtext ...}` / `{\pntext ...}` (đánh số nếu chữ đầu trông như `1.` / `a)` / `(i)`; độ sâu = `\ilvlN` + 1); bảng `\trowd ... \cell ... \row`; trường: giữ `\fldrslt`, bỏ `\fldinst`.

**Đã kiểm (`office_import_check.py` + `OfficeImportCheck.java`, 58 kiểm tra + 8 bản hỏng).** Bản Java chạy đúng thuật toán của Kotlin; tệp do công cụ THẬT tạo. (A/B) 24 tài liệu python-docx ngẫu nhiên (tiêu đề 0-4, danh sách đánh số / gạch đầu dòng tới
cấp 3, bảng, tab, ngắt dòng, chữ Việt / Nhật / Hàn / emoji) -> LibreOffice -> ODT và RTF: khối (loại, cấp, dấu danh sách, chữ) = nội dung đã dựng ở 24/24 (45 tiêu đề, 66 mục danh sách trong đó 40 từ cấp 2, 51 hàng bảng);
tệp do pandoc tạo: chuỗi từ đúng; `pandoc -f odt` đọc lại: cấu trúc khớp ở mọi tài liệu không có Title (pandoc làm mất chữ trong ô bảng ODT nên bảng không được so); chữ RTF = bản `txt` do chính LibreOffice xuất ở 24/24 và = `pandoc -f rtf`.
9 ca ODT và 14 ca RTF viết tay (thực thể, CDATA, danh sách lồng nhau, bảng lồng, mục bị bỏ, `\uc0` / `\uc2`, cặp thay thế emoji, Shift-JIS hai byte, cp1258, phông Cyrillic theo nhóm, `\bin`, nhóm bị bỏ, ngoặc không cân bằng).
(C) 24 bản PPTX python-pptx (thứ tự slide xáo trộn ở 19/24, bảng, nhóm hình, ô số trang) + 8 bản qua vòng LibreOffice pptx -> odp -> pptx: khớp python-pptx đọc lại ở 32/32 (137 tiêu đề slide, 51 mục nội dung từ cấp 2, 39 hàng bảng);
`mc:AlternateContent` chỉ cho một bản. (D) XLSX: 61 ô (chuỗi Unicode, 15 chữ số, bool, lỗi, ngày / giờ, 38 ô định dạng số so với CSV "như hiển thị" của LibreOffice), cả tệp openpyxl lẫn tệp LibreOffice lưu lại (có công thức đã tính);
hệ 1904; ô thưa; chữ giàu định dạng; `inlineStr`, `t="str"`, tiền tố `x:`, furigana; 79.999 số ngày hệ 1900 và 80.000 hệ 1904 = `openpyxl.from_excel`; 300 giờ ngẫu nhiên. (E) 8 bản Java cố ý hỏng đều bị bắt (sắp slide theo tên tệp, không bỏ
`mc:Fallback`, không bỏ ký tự dự phòng `\uc`, `\'hh` luôn cp1252, lỗi năm nhuận 1900, không bỏ furigana, bỏ qua kiểu ô, chữ rò từ phần tử bị bỏ).
**Khác biệt đã biết với LibreOffice (cố ý):** số rất lớn in `E+18` (LibreOffice in `E+018`); ngày luôn ISO. Kotlin chưa biên dịch; `static_refs_check` và `i18n_check` đạt (chuỗi mới `convert_slide_n`; 3 chuỗi nguồn đổi lời).

#### 4.48.3 Trí tuệ tài liệu: loại, thẻ gợi ý, tóm tắt (`DocInsight`) — PDF mục H1, H3, H6, N2

**Làm gì.** Menu nhấn giữ của lịch sử có thêm "Phân tích tài liệu (loại, thẻ, tóm tắt)" cho PDF: đọc chữ của 10 trang đầu (lớp chữ, hoặc OCR nếu là bản quét, như `extractInvoice`), rồi tính NGAY TRÊN MÁY: (1) loại tài liệu,
(2) tối đa 5 thẻ gợi ý, (3) tóm tắt 3 câu. Hộp thoại ghi rõ đây là gợi ý; thẻ chỉ được thêm khi người dùng bấm "Thêm thẻ…" rồi chọn (mặc định chọn hết, thêm VÀO thẻ sẵn có). Không gửi gì lên mạng.

**Mọi thứ trên chữ ĐÃ GẤP DẤU, chữ thường** (`PiiDetector.foldLower`: một ký tự thay một ký tự, nên vị trí tìm được cắt đúng chuỗi gốc): "Hợp đồng", "HOP DONG" và bản OCR mất dấu là một.

**Phân loại (`classify`).** 9 loại (hoá đơn, biên lai / phiếu thu, hợp đồng, giấy tờ tùy thân, sao kê ngân hàng, giấy chứng nhận / bằng cấp, CV, công văn / thư chính thức, đơn / tờ khai). Bảng `TABLE` trong mã (194 dòng
`LOẠI trọng-số cụm-từ`, tiếng Việt không dấu + tiếng Anh): điểm một loại = tổng trọng số x min(số lần xuất hiện, 3), chỉ tính khi cụm là CẢ TỪ (không chữ / số liền trước hoặc sau: "Reuben as" không phải "Bên A"). Dưới 5 điểm = không gán
loại; loại thứ hai đạt >= 70 % loại đầu thì hiện thêm "cũng có thể là". Chỉ xét 30 000 ký tự đầu.

**Thẻ (`keywords`).** TF-IDF với ứng viên là từ đơn (>= 4 chữ, không phải từ dừng) và CỤM HAI TỪ liền nhau không bị dấu câu / số / dòng trống ngăn (từ tiếng Việt thường hai âm tiết: "hợp đồng", không phải "hợp" + "đồng");
chỉ ứng viên xuất hiện >= 2 lần; điểm = (1 + ln đếm) x IDF x 1,5 nếu là cụm hai từ, IDF = ln((1 + n) / (1 + df)) + 1 (IDF "smooth" của scikit-learn) tính trên các tài liệu KHÁC của người dùng (chữ lấy từ `ContentIndex`, tối đa 200 tài liệu)
cộng chính tài liệu này. Chọn tối đa 3 cụm hai từ trước, rồi từ đơn không nằm trong cụm đã chọn; chữ hiện ra là chữ GỐC có dấu, thường hoá. Từ dừng Anh + Việt đã không dấu, kể cả tiêu ngữ hành chính ("xã hội chủ nghĩa", "độc lập"...).
Dưới 8 từ: không gợi ý. Giới hạn: tiêu ngữ "Cộng hòa" còn lọt khi người dùng chưa có tài liệu nào khác (IDF không giúp được); chữ Hán / Nhật liền nhau không có dấu cách nên không tách từ (không gợi ý thẻ cho chúng).

**Tóm tắt (`summary`, TextRank).** `sentences`: dòng trống kết thúc đoạn, xuống dòng đơn được NỐI bằng dấu cách (OCR / PDF ngắt dòng giữa câu), câu kết thúc ở `. ! ?` + khoảng trắng hoặc cuối đoạn, hoặc `。！？` (số thập phân `3.5` không cắt).
Ứng viên: 30-400 ký tự và >= 4 từ thật, tối đa 300 câu. Đồ thị: nút = câu, cạnh = độ tương đồng cosin của vector TF-IDF (IDF "smooth" trên các câu, chuẩn hoá L2); PageRank alpha 0,85 (nút không có cạnh chia đều cho mọi nút, như networkx);
chọn 3 câu điểm cao nhất, in theo THỨ TỰ xuất hiện. Không phải tóm tắt "viết lại": chỉ trích câu.

**Đã kiểm (`doc_insight_check.py` + `DocInsightCheck.java` + `doc_insight_corpus.py`).** Bản Java chạy đúng thuật toán của Kotlin; bảng và từ dừng được TRÍCH TỪ MÃ KOTLIN để bài kiểm dùng đúng dữ liệu thật. (A) `foldLower` = `unicodedata` của Python trên
1.012 ký tự Latin / Việt / Hy Lạp / Cyrillic, cùng độ dài. (B) 37 văn bản viết tay theo khuôn tài liệu thật (không lấy từ bảng) + 6 văn bản không thuộc loại nào: đúng 37/37 nguyên văn, 37/37 bỏ dấu + chữ thường, 37/37 xuống dòng giữa câu,
35/37 với nhiễu OCR 2 % (sai: một biên lai, một giấy tờ tùy thân, đều thành "không nhận ra loại"), 36/37 chỉ nửa đầu (sai: một công văn); 6/6 văn bản ngoài loại không bị gán loại; hợp đồng nhắc "hoá đơn" vẫn là hợp đồng. (C) điểm TF-IDF của 451 ứng viên (12 tài liệu x kho 36 tài liệu khác) = công thức với IDF của scikit-learn:
lệch 0 (đúng từng bit); df khớp; lựa chọn + chữ gốc có dấu khớp 12/12. (D) 6 ca tách câu. (E) 20 tài liệu ghép từ 22 câu mẫu: ma trận cosin = scikit-learn `TfidfVectorizer` (lệch 1,7e-16), PageRank = `networkx.pagerank` (lệch 2e-11; 19/20 tài liệu có nút cô lập),
3 câu chọn khớp 20/20. (F) 6 bản hỏng bị bắt (cụm không cần là cả từ, IDF hằng, bỏ nút treo, không nối dòng, không gấp dấu, cụm vượt dấu câu).
**CHƯA kiểm / giới hạn nói thẳng:** không có kho tài liệu thật có nhãn trong môi trường này, nên tỉ lệ đúng ở trên là trên 43 văn bản VIẾT TAY theo khuôn tài liệu thật, không phải con số cho tài liệu của người dùng; tài liệu lạ (hợp đồng
mua bán ô tô, hoá đơn điện...) có thể ra "không nhận ra loại" hoặc loại gần. Bảng cụm từ dễ mở rộng (thêm một dòng, chạy lại bài kiểm). Kotlin chưa biên dịch; `static_refs_check` và `i18n_check` đạt (21 chuỗi mới `insight_*`).

#### 4.48.4 eSCL quét HAI MẶT từ khay giấy (`EsclProtocol`, `WifiScanActivity`) — PDF mục 8.4

**Tra cứu trước khi làm (nguyên tắc 0e00; mục 6 cũ ghi "tên phần tử chưa xác nhận").** Đặc tả Mopria eSCL không tải được trong môi trường này, nên tên phần tử được xác nhận bằng HAI nguồn thực tế độc lập:
(1) client Go mã mở `stnokott/airscan` (cấu trúc `ScanSettings`: `pwg:InputSource` và `scan:Duplex` kiểu bool); (2) log `GET /eSCL/ScannerCapabilities` THẬT của máy Epson ET-4950 (issue #5 của `wleonhardt/ha-escl-scan`):
khối `scan:AdfSimplexInputCaps` và `scan:AdfDuplexInputCaps` có `MinWidth / MaxWidth / MinHeight / MaxHeight / MaxXOffset / MaxYOffset / MaxScanRegions` riêng. Từ log đó rút ra hai điều tài liệu cũ không biết:
**giới hạn hai mặt có thể NHỎ HƠN một mặt** (4200 so với 3510) và một vùng quét hai mặt vượt giới hạn hai mặt bị máy trả **409 Conflict**; và máy đó cho mặt sau (trang 2, 4, 6...) **ngược đầu 180°**.
**Chưa xác nhận bằng đặc tả gốc:** vị trí chính xác của `<scan:Duplex>` trong thứ tự phần tử (client Go đặt sau `YResolution`; bộ này làm theo, và chỉ gửi khi hai mặt được bật, nên một mặt không đổi).

**Làm gì.** `Capabilities.duplex` (có khối `AdfDuplexInputCaps`), `feederDuplexWidth/Height` (giới hạn của khối đó); giới hạn một mặt nay lấy từ `AdfSimplexInputCaps` (trước đây là "`MaxWidth` đầu tiên trong `Adf`", sẽ sai nếu máy liệt kê khối hai mặt trước).
`fit(..., duplex)`: hai mặt chỉ có hiệu lực khi nguồn là khay giấy VÀ máy có khối hai mặt, rồi vùng quét kẹp theo giới hạn HAI MẶT; `scanSettingsXml` thêm `<scan:Duplex>true</scan:Duplex>` ngay sau `YResolution` khi bật.
Màn hình quét Wi-Fi: hộp kiểm "Quét cả hai mặt của mỗi tờ" (chỉ hiện khi máy có khối hai mặt) và "Xoay các mặt sau 180°" (chỉ hiện khi bật hai mặt; áp cho trang chỉ số lẻ 1, 3, 5... bằng giải mã - xoay - mã hoá lại JPEG chất lượng 95; hết bộ nhớ thì giữ trang gốc).
Mỗi tờ cho hai ảnh liên tiếp qua `NextDocument` như các máy khác, nên phần tải trang không đổi.

**Đã kiểm (`escl_check.py` phần D, 79 kiểm tra cả phần cũ).** Ca Epson thật (4200 / 3510), khối hai mặt đứng TRƯỚC khối một mặt, máy không có khối hai mặt (hai mặt bị bỏ, không gửi `Duplex`), kính phẳng (bỏ qua), vùng quét kẹp 3000 so với A4 3508,
thứ tự phần tử của `ScanSettings`, máy quét giả 2 tờ x 2 mặt = 4 ảnh theo thứ tự, và máy giả trả **409** khi `Height` hai mặt vượt giới hạn hai mặt (đúng hành vi Epson); bản hỏng "dùng giới hạn một mặt cho hai mặt" bị bắt (máy trả 409).
**CHƯA kiểm với máy thật:** bài kiểm dùng máy quét giả (như phần cũ); không có máy hai mặt để thử, và việc xoay 180° chưa chạy trên Android (Kotlin chưa biên dịch). Vì mặt sau ngược đầu chỉ thấy ở MỘT máy báo cáo, tuỳ chọn xoay để TẮT mặc định.

#### 4.48.5 Sao lưu theo lịch (`BackupSchedule`, `AutoBackup`, `AutoBackupJobService`) — PDF mục 6.4

**Hành vi.** Công cụ "Sao lưu & khôi phục" có nút thứ ba "Hẹn giờ…". Người dùng chọn MỘT LẦN: thư mục (cây Storage Access Framework, quyền giữ bằng `takePersistableUriPermission` nên app KHÔNG cần quyền bộ nhớ),
chu kỳ (tắt / mỗi ngày / mỗi tuần / mỗi tháng = 1 / 7 / 30 ngày) và số bản giữ lại (3 / 5 / 10 / 30). Một job định kỳ của `JobScheduler` ghi `docscanner_auto_yyyyMMdd_HHmmss.zip` vào thư mục đó bằng đúng `BackupManager.backup`
(nội dung như sao lưu thủ công: tài liệu đã xuất và dự án; KHÔNG có két sắt, chữ ký tay, khoá ứng dụng), rồi xoá các bản tự động cũ vượt số giữ lại. Hộp thoại hiện thư mục, lần thành công gần nhất, sự cố gần nhất.

**Tra cứu trước khi làm (0e00; mục 6 cũ ghi hướng này "chưa tra").** Tài liệu Android và các ví dụ: `JobInfo.Builder.setPersisted(true)` cần quyền `RECEIVE_BOOT_COMPLETED` (đã khai báo; quyền thường, không hỏi người dùng);
`setPeriodic` tối thiểu 15 phút và hệ thống chỉ bảo đảm "không quá một lần mỗi chu kỳ" (giờ chạy cụ thể do hệ thống chọn, nên hộp thoại ghi "khoảng"); `getPendingJob` từ API 24; `setRequiresBatteryNotLow` / `setRequiresStorageNotLow` từ API 26 (có kiểm
`SDK_INT`). Chọn `JobScheduler` thay vì WorkManager vì không thêm phụ thuộc, không thêm quyền ngoài `RECEIVE_BOOT_COMPLETED`, và minSdk 24 đã có sẵn; cái giá là phải tự đăng ký lại sau khi người dùng đổi chu kỳ (`ensureScheduled`, chạy lúc mở app).
Job chỉ chạy khi đang SẠC, pin và bộ nhớ không thấp; `onStartJob` chạy trên luồng chính nên việc ghi ZIP chạy trên một luồng riêng và gọi `jobFinished`; lỗi thì ghi lại và xin chạy lại (có backoff của hệ thống).

**An toàn khi xoá (`BackupSchedule.toDelete`).** Thư mục là của NGƯỜI DÙNG (hay là thư mục đám mây có tệp khác), nên một tên chỉ bị xoá khi khớp `docscanner_auto_yyyyMMdd_HHmmss.zip` VÀ là ngày giờ có thật (kiểm bằng UTC, nơi không có giờ nào bị bỏ qua). Bản sao lưu
thủ công (`docscanner_backup_...`), ảnh, `.tmp`, tên giống nhưng ngày 30/2 hay 25:61 KHÔNG bao giờ bị đụng. "Mới nhất" sắp theo CHÍNH TÊN (dấu thời gian cố định độ rộng, năm đứng đầu) nên đổi múi giờ hay giờ mùa hè không đảo thứ tự.
Số giữ lại kẹp trong 1..30 (không bao giờ xoá hết). Bản ghi dở (lỗi giữa chừng) và bản rỗng (không có gì để sao lưu) bị xoá ngay, không để lại.

**Đã kiểm (`backup_schedule_check.py` + `BackupScheduleCheck.java`).** Phần THUẦN trên JVM: tên tệp cho 2.004 thời điểm x 6 múi giờ (UTC, TP.HCM, New York, Paris, St. John's UTC-3:30, Kathmandu UTC+5:45; kể cả hai ranh giới giờ mùa hè) = `datetime` + `zoneinfo` của Python;
nhận diện 16 tên (ngày 30/2, 25:61, tháng 13, năm nhuận 2024 / 2000, không nhuận 1900 / 2023, hậu tố lạ, chữ hoa); 400 thư mục ngẫu nhiên trộn tệp của ta với tệp lạ: tập bị xoá = tham chiếu Python, tệp lạ bị xoá 0 lần, phần còn lại luôn là N bản mới nhất; ranh giới "đến hạn";
3 bản hỏng bị bắt (xoá mọi `.zip` => xoá cả bản sao lưu thủ công; giữ bản CŨ nhất; không kẹp N: N = 0 xoá tất cả).
**CHƯA kiểm và nói thẳng:** `AutoBackup.kt` / `AutoBackupJobService` (JobScheduler, `DocumentsContract.createDocument` / truy vấn con / xoá, quyền SAF được giữ, hành vi ở Android 12+ khi app bị hạn chế nền) CHƯA chạy trên máy hay trình giả lập, vì môi trường này không có Android và Kotlin chưa biên dịch. Cần thử trên máy thật: tạo lịch,
rút sạc, khởi động lại, thu hồi quyền thư mục. Các hãng (Xiaomi, Oppo, Huawei...) có thể chặn job nền; hộp thoại không hứa giờ cụ thể. Tệp ZIP KHÔNG mã hoá (như bản thủ công); hộp thoại nói rõ. Thêm 18 chuỗi (`autobackup_*`, `backup_action_schedule`).

#### 4.48.6 Chữ ký có dấu thời gian RFC 3161 (PAdES-B-T) (`TimeStamp`, `CmsSigner`, `PdfDigitalSigner`) — PDF mục 3.4-3.8

**Vấn đề.** Chữ ký số của 4.24 chứng minh AI ký và nội dung không đổi, nhưng thời điểm ký chỉ là đồng hồ điện thoại (`signingTime`, do người ký tự khai). Dấu thời gian là lời xác nhận có chữ ký của một TSA rằng một giá trị băm đã tồn tại ở một thời điểm: gắn vào chữ ký
nó chứng minh KHI NÀO với bất kỳ ai, kể cả khi đồng hồ máy sai hoặc chứng thư ký sau này hết hạn.

**Cách làm.** Hộp thoại ký số có ô "Máy chủ dấu thời gian (không bắt buộc)", MẶC ĐỊNH TRỐNG (không có địa chỉ mặc định nào trong mã; ví dụ các TSA miễn phí hay đổi nên không ghi cứng). Trống = chữ ký như cũ và KHÔNG có cuộc gọi mạng. Có địa chỉ: sau khi
`CmsSigner` tính xong giá trị chữ ký RSA, `TimeStamp.obtain` băm SHA-256 CHÍNH GIÁ TRỊ ĐÓ, dựng `TimeStampReq` (v1, SHA-256, nonce 63 bit ngẫu nhiên, `certReq` TRUE để token mang chứng thư của TSA và đọc được ngoại tuyến), POST
`application/timestamp-query` (http hoặc https, không theo chuyển hướng, tối đa 256 KB trả về, 20 giây), đọc `TimeStampResp`, chấp nhận trạng thái 0 / 1, và token được gắn vào `unsignedAttrs` `[1]` của SignerInfo với OID `1.2.840.113549.1.9.16.2.14`
(`id-aa-signatureTimeStampToken`). `unsignedAttrs` KHÔNG nằm trong phần được ký nên chữ ký RSA không đổi (đã kiểm). Chỗ dành cho CMS trong PDF nâng từ 9 472 lên 20 000 byte khi có dấu thời gian (token mang chuỗi chứng thư của TSA, thường 3-6 KB).
**Quyền riêng tư:** chỉ MỘT giá trị băm 32 byte rời máy, tới địa chỉ người dùng tự gõ; không bao giờ có tài liệu hay chứng thư của người ký. Vẫn là một cuộc gọi mạng (dùng quyền INTERNET đã khai báo cho eSCL, 4.31 I) nên câu chữ về quyền riêng tư / khai báo an toàn dữ liệu trên Google Play
CẦN được xem lại trước khi bán (việc của chủ dự án; bản này không sửa chính sách quyền riêng tư).

**Đã kiểm trước khi gắn (`TimeStamp.tokenMatches`).** Token phải là `ContentInfo` có độ dài ngoài cùng ĐÚNG bằng độ dài token (bài kiểm bắt được một lỗi thật: bản đầu chấp nhận token bị cắt cụt nếu `TSTInfo` còn nguyên), `TSTInfo` lặp lại ĐÚNG băm SHA-256 và ĐÚNG nonce của yêu cầu (nên
trả lời dành cho yêu cầu khác không gắn được). **KHÔNG kiểm** chữ ký và chuỗi chứng thư của TSA (việc của trình đọc PDF, cần danh sách tin cậy mà app không có). Token BER độ dài không xác định (một số TSA cũ) bị TỪ CHỐI thay vì gắn không kiểm; lỗi được báo bằng
`digsign_tsa_failed` và KHÔNG ký (không có tệp nào được tạo).

**Đã kiểm (`timestamp_check.py` + `TimestampCheck.java`; mở rộng `CmsCheck.java`).** `openssl ts` làm TSA cục bộ (chứng thư có `extendedKeyUsage = critical,timeStamping`): (A) `openssl ts -query -text` đọc lại yêu cầu của bản Java đúng phiên bản 1, sha256, băm, nonce, `certReq` = yes;
(B) bản Java đọc `TimeStampResp` thật (trạng thái 0 = "Granted", token 2 344 byte) và `tokenMatches` đúng / sai theo băm, nonce, nonce ngắn hơn, mã băm SHA-384, BER độ dài không xác định, trả lời từ chối (status 2); (C) CMS có token: `openssl cms -verify` vẫn thành công,
token nằm đúng trong `unsignedAttrs` giống từng byte, giá trị chữ ký không đổi, và **`openssl ts -verify -data <giá trị chữ ký> -token_in` xác nhận token phủ đúng chữ ký** (dùng nhầm nội dung thì `openssl` từ chối, nên kiểm này phân biệt được); (D) PDF ký thật có token (3 609 byte trong
/Contents): `pdfsig` vẫn báo chữ ký HỢP LỆ, token đọc lại từ PDF giống từng byte; (E) 300 chuỗi ngẫu nhiên + 124 bản cắt cụt của trả lời + 424 lần `MATCH` trên rác / token cắt cụt: không sập, không bao giờ khớp; (F) 4 bản hỏng bị bắt (bỏ kiểm nonce, bỏ kiểm băm,
bỏ kiểm độ dài, `certReq` = FALSE). `digital_signature_check` cũ vẫn đạt.
**CHƯA kiểm:** không có TSA công cộng nào được gọi (môi trường không có mạng); `TimeStamp.post` (HttpURLConnection) và hộp thoại chưa chạy trên Android; PDF/A và PAdES-LTA (lưu thông tin thu hồi chứng thư) KHÔNG làm: dấu thời gian chỉ chứng minh thời điểm, không biến chữ ký tự cấp thành "tin cậy". Thêm 5 chuỗi `digsign_tsa_*`.

#### 4.48.7 Tô sáng bằng lớp chữ THẬT của PDF (`TextLayerWords`, `PdfTextLayer`, `PdfMarkupActivity.wordsFor`) — PDF mục 3.3-3.4

**Trước.** Màn hình "Tô sáng" luôn vẽ trang thành ảnh rồi OCR để biết từ nào nằm ở đâu: chậm, và hộp tô nằm theo cái OCR NGHĨ là thấy (lệch, hụt dấu, sai ở chữ nhỏ), cả với PDF vốn đã có lớp chữ (xuất từ app này kèm lớp OCR vô hình, xuất từ Word / web).
**Nay.** `wordsFor(page)` thử lớp chữ của chính PDF trước (`PdfTextLayer.words`): `PDFTextStripper` của PdfBox-Android gọi `writeString` một lần cho MỖI TỪ kèm các `TextPosition` của từ đó, `writeLineSeparator` tăng chỉ số dòng; mỗi từ thành một `PdfTextMarkup.WordBox` (hộp 0..1 trên trang
HIỂN THỊ, gốc trên-trái) nên `findPhrase`, `wordsInRect`, `lineBoxes` và bộ ghi chú `/Highlight` chạy NGUYÊN VẸN. Trang có ít hơn 3 từ (bản quét) hoặc lỗi thì rơi về OCR như trước; PDF mã hoá cũng rơi về OCR.

**Hình học (`TextLayerWords.wordBox`, thuần).** Từ các ô ký tự của một từ: trái / phải = hợp của `x` và `x + rộng`, đỉnh = đường cơ sở - `ASCENT` x cỡ chữ, đáy = đường cơ sở + `DESCENT` x cỡ chữ, chia cho cỡ trang rồi kẹp 0..1; null cho không ký tự, trang không kích thước, NaN, hộp suy biến (< 0,05 % trang).
**Dùng CỠ CHỮ (em), không dùng "chiều cao ký tự":** các thư viện định nghĩa chiều cao ký tự khác nhau (của PDFBox là ước lượng từ số đo phông, thường nhỏ hơn mực thật), còn cỡ chữ là cùng một đại lượng ở mọi nơi. **Hằng số ĐÃ CHỈNH TRÊN DỮ LIỆU THẬT, không đoán:** quét lưới trên 1.879 từ của 14 PDF thật; `ASCENT` 0,70-0,85 với `DESCENT` 0,10 cắt 3-9 % số từ
(mất dấu chồng trên chữ hoa tiếng Việt như Ệ, Ấ; mất chân chữ g, p, y); `ASCENT` = **0,95** với `DESCENT` >= 0,20 phủ 100 % mực. Chọn 0,95 / **0,25** (dư một chút). (Một lần đo đầu cho kết quả xấu giả vì vùng đo lẫn mực của dòng trên / dưới; đã đo lại đúng: mực nằm TRONG hộp poppler của từ.)

**Đã kiểm (`text_layer_check.py` + `TextLayerCheck.java`), trên mẫu KHÁC mẫu dùng để chỉnh hằng số.** 14 PDF thật (4 reportlab nhiều phông / cỡ / chữ Việt, 10 LibreOffice từ python-docx có tiêu đề và bảng), ký tự đọc bằng pdfminer (đọc thứ ba), 1.972 / 2.277 từ ghép được với hộp từ của poppler `pdftotext -bbox`
(phần không ghép được là khác cách tách từ giữa hai bộ đọc, không phải lỗi hộp): hai mép trái / phải khớp poppler trong 1,5 điểm ở **100 %**; hộp phủ **100 %** mực thật (`pdftoppm` 144 dpi, điểm tối < 128; trung vị và phân vị 1 % đều 100,0 %); diện tích / hộp poppler trung vị 0,92, phân vị 95 % 1,33 (không phình);
ca biên (không ký tự, trang không kích thước, NaN, từ một điểm; từ tràn trang bị kẹp; từ sát mép trên); 3 bản hỏng bị bắt (hằng số 0,70 / 0,10, không kẹp 0..1, hoán đổi chiều rộng / cao trang).
**CHƯA kiểm và nói thẳng:** `PdfTextLayer` (PDFBox `TextPosition`, `writeString` theo từ, `fontSizeInPt`, `pageWidth / pageHeight` đã tính xoay trang) CHƯA chạy trên Android và mã Kotlin chưa biên dịch; trang xoay (`/Rotate`), chữ dọc và chữ phải-sang-trái chưa kiểm; ký tự thật của PDFBox có thể khác pdfminer ở font Type 3 và chữ có biến đổi phức tạp.
Nếu thử trên máy thấy hộp lệch, chỉnh `ASCENT` / `DESCENT` ở MỘT chỗ (`TextLayerWords`) rồi chạy lại `text_layer_check`.

#### 4.48.8 Thêm ngôn ngữ (theo quy trình 4.45) — PDF mục 14.1

Chủ dự án yêu cầu "làm những ngôn ngữ phổ biến". Mỗi ngôn ngữ = `tools/i18n/<mã>_strings.txt` (1.102 dòng, cùng khoá và cùng thứ tự với bản Anh) + một dòng ở `languages.txt`, rồi `i18n_check.py --write` sinh `values-xx/strings.xml`, `locales_config.xml` và `languages.xml`; không sửa mã Kotlin
(`AppLanguages` đọc danh sách từ `languages.xml`). Danh sách đã làm, theo thứ tự: **Español (es)**, **Português (Brasil) (pt-BR)**, **Français (fr)**, **Deutsch (de)**, **Bahasa Indonesia (id)**, **한국어 (ko)**, **简体中文 (zh-CN)**, **हिन्दी (hi)**, **Русский (ru)** — tức ĐÃ XONG toàn bộ danh sách chủ dự án yêu cầu (cùng Anh / Việt / Nhật có sẵn: 12 ngôn ngữ). Mỗi nhóm ngôn ngữ xong là xuất zip ngay (yêu cầu của chủ dự án: không dồn qua nhiều phiên; chỉ giao MỘT `DocScanner.zip`, không xuất tệp rời; người dùng chọn ngôn ngữ trong cài đặt của app, mọi ngôn ngữ nằm chung một APK).
**Lỗi quy trình đã bắt được:** 15 chuỗi tiếng Anh có dấu cách ĐẦU hoặc CUỐI (ví dụ hậu tố " (edited)" nối sau tên tệp) mà bản dịch đầu tiên làm mất; `apply.py` nay giữ nguyên dấu cách đầu / cuối của bản Anh, và `i18n_check` ĐÃ được bổ sung luật này (phiên 21): dấu cách đầu / cuối của mọi chuỗi phải khớp bản Anh, kiểm cho cả 8 ngôn ngữ (không ngôn ngữ cũ nào vi phạm).
**Quy trình dịch (để làm tiếp ngôn ngữ khác):** in bản Anh theo từng đoạn với số dòng, dịch theo số dòng (không lặp lại khoá, `=` nghĩa là giữ nguyên tiếng Anh), dùng `{NL}` / `{Q}` thay cho xuống dòng / dấu nháy thoát rồi script đổi lại đúng dạng của tệp (`\n`, `\"`), ghép theo thứ tự khoá của bản Anh, rồi `i18n_check`.
**Bộ kiểm đã chỉnh:** (1) luật "không lẫn chữ có dấu tiếng Việt" trước đây coi MỌI chữ có dấu (á, é, ó...) là tiếng Việt, nên sai với mọi ngôn ngữ Latin khác; nay `en` và `ja` vẫn cấm mọi chữ có dấu Việt, còn các ngôn ngữ Latin khác chỉ cấm chữ CHỈ có trong tiếng Việt (ă ơ ư đ ĩ ũ và khối U+1EA0-1EF9);
(2) `ALLOW_SAME_LANG` theo ngôn ngữ cho những chuỗi giống hệt tiếng Anh mà vẫn ĐÚNG (pt-BR: `qr_wifi_caption`, `autobackup_keep_n` "%1$d backups", `bm_page`, `convert_slide_n` "Slide %1$d", `convert_source_markup`, `history_action_links` "Links…"; es: `bm_page` "p. %1$s", `convert_source_markup` toàn tên riêng, `markup_color_label`, `markup_color_title`, `qr_wifi_caption`, `wifi_color`, `wifi_color_rgb`).
**Đã kiểm:** `i18n_check` (đủ khoá, cùng chỗ giữ chỗ `%1$s` / `%d` / `{n}`, cùng số `\n`, dấu nháy thoát, mảng cùng độ dài, XML hợp lệ và khớp bản sinh lại) + quét heuristic từ tiếng Anh sót và dấu `¿` `¡` cân bằng.
**KHÔNG kiểm và nói thẳng:** bản dịch do trợ lý viết, CHƯA có người bản ngữ rà (như 4.45 đã yêu cầu). Dùng "tú" (Toca, Elige) và từ vựng trung tính cho cả Tây Ban Nha và Mỹ Latinh; thuật ngữ như "tachar información" (redactar), "sello", "etiqueta", "caja fuerte" nên được người bản ngữ xác nhận trước khi bán ở các nước nói tiếng Tây Ban Nha. Chưa chạy trên máy: cần xem các màn hình dày chữ (hộp thoại dài, nút) có tràn không vì tiếng Tây Ban Nha dài hơn tiếng Anh khoảng 20 %.

**Nhóm Français / Deutsch / Bahasa Indonesia / 한국어 / 简体中文 / हिन्दी / Русский (phiên 21).** (1) **Tiếng Indonesia: thư mục `values-in`, thẻ `id`.** Đã tra cứu (không đoán): Android vẫn dùng mã cũ `in` cho thư mục tài nguyên tiếng Indonesia (cảnh báo `LocaleFolder` của Android Lint nói rõ `id` là mã mới nhưng thư mục phải là `values-in`), còn thẻ BCP-47 trong `locales_config.xml` và `forLanguageTags` là `id`. Vì vậy `languages.txt` ghi `id | values-in | Bahasa Indonesia`: cột thứ nhất (thẻ) sinh `locales_config.xml` và `languages.xml`, cột thứ hai (thư mục) là nơi ghi `strings.xml`; `AppLanguages.currentTag()` trả `id` (Android đổi `in` thành `id` khi gọi `toLanguageTag()`), nên `checkedIndex` khớp đúng dòng. (2) **Số nhiều:** app dùng chuỗi `%1$d` chứ không dùng `<plurals>`, nên chỗ nào danh từ phải đổi dạng theo số (tiếng Pháp / Đức: \"1 Seiten\" sai) thì câu được viết lại theo dạng \"nhãn: số\" (Seiten: %1$d, Pages numérisées : %1$d); tiếng Indonesia không chia số nhiều nên giữ \"%1$d halaman\". Các ngôn ngữ còn lại (Nga có 3 dạng số nhiều, Hindi, Hàn, Trung) sẽ dùng cùng cách. (3) **Tiếng Pháp:** dấu cách KHÔNG NGẮT (U+00A0, viết `{S}` trong tệp nguồn dịch) trước `:` `?` `!` `;` và trong « » theo quy tắc bản địa; vì vậy vài chuỗi như `bm_page` (\"p.\u00a0%1$s\") không trùng bản Anh. Tiếng Đức dùng \"du\" (thân mật) và nháy kép „ “; tiếng Indonesia dùng \"Anda\" và `\\\"`. (4) Mục `tag` dịch: Pháp \"Étiquette\", Đức \"Tag\", Indonesia \"tag\"; thẻ `chapter_default` / `export_page_name` thống nhất \"Chapitre / Kapitel / Bab N\". (5) `ALLOW_SAME_LANG` thêm: fr (`annotate_page_indicator`, `barcode_kind_sms`, `cleanup_cat_image`, `convert_source_images`, `convert_source_markup`, `convert_target_images`, `epub_meta_description`, `export_page_name`, `stamp_urgent`), de (12 chuỗi \"Text\", \"Name\", \"Tags\", \"Links…\"...), id (`barcode_kind_email`, `card_field_email`, `redact_kind_email`, `convert_slide_n`, `qr_wifi_caption`, `autobackup_folder`, `tag_button_filtered`, `convert_source_markup`). (6) **한국어 và 简体中文:** tiếng Hàn dùng đuôi lịch sự \"-어요\" (kiểu app phổ thông), nháy “ ” và ‘ ’; tiếng Trung giản thể dùng dấu câu toàn chữ rộng (：（）“”) và không chèn dấu cách giữa chữ Hán với `%1$d`; cả hai không chia số nhiều nên các chuỗi giữ dạng \"%1$d + loại từ\" (페이지 %1$d개, %1$d 页). Thư mục `values-ko`, `values-zh-rCN` (thẻ `ko`, `zh-CN`); `ALLOW_SAME_LANG`: `convert_source_markup`, `qr_wifi_caption`. (7) **Sửa `AppLanguages.checkedIndex`:** Android có thể trả thẻ có chữ viết (\"zh-Hans-CN\") cho mục `zh-CN` của `locales_config.xml`; hàm nay bỏ thành phần chữ viết (4 chữ cái sau mã ngôn ngữ) rồi khớp lại (`stripScript`), nên mục tiếng Trung vẫn được đánh dấu đúng thay vì rơi về \"theo ngôn ngữ máy\"; \"zh-Hant-TW\" (phồn thể) vẫn KHÔNG khớp `zh-CN`, \"es-419\" vẫn khớp `es`. Kiểm: `app_languages_check.py` (Java chạy thật so với bản tham chiếu Python viết riêng, 2.018 ca; Kotlin chỉ rà tĩnh). (8) **Русский và हिन्दी:** tiếng Nga có 3 dạng số nhiều nên MỌI chỗ đếm đều viết lại dạng \"nhãn: số\" (\"Снято страниц: %1$d\", \"Копий: %1$d\", \"Страниц с обрезанными полями: %1$d\"), tỉ lệ nén viết \"меньше в %3$s×\" để khỏi phải chia \"раза / раз\"; nháy « » (thuần Unicode, không cần thoát); tên người dùng gọi \"вы\". Tiếng Hindi dùng chữ số Latin `%1$d` (không đổi sang chữ số Devanagari để khỏi lệch với `Locale` hệ thống), dấu chấm câu \"।\" ở cuối câu, các từ mượn đã quen (पेज, टेक्स्ट, कंप्रेस, एक्सपोर्ट, टैग, OCR) thay vì từ thuần Hindi; thông điệp phản hồi tránh động từ chia theo giới (\"मेरा फ़ीडबैक\" thay \"देना चाहता/चाहती हूँ\"). Phông chữ: Android có sẵn Cyrillic và Devanagari; chưa kiểm chiều cao dòng Devanagari trên máy thật (dấu mũ cao hơn Latin). (9) **OCR chữ Cyrillic (tiếng Nga...) — ĐÃ LÀM ở phiên 21, CHƯA biên dịch.** Gốc vấn đề (đã tra): bảng ngôn ngữ chính thức của ML Kit Text Recognition v2 (developers.google.com/ml-kit/vision/text-recognition/v2/languages) chỉ có 5 bộ chữ: Latin, Hán, Devanagari, Nhật, Hàn; KHÔNG có Cyrillic. Cách giải quyết: **Tesseract 5** qua `cz.adaptech.tesseract4android:tesseract4android:4.9.0` (Apache-2.0). Lưu ý đã sửa so với ghi chú trước: gói này nằm trên **JitPack**, KHÔNG phải Maven Central, nên `settings.gradle` có thêm kho `https://jitpack.io` với bộ lọc `includeGroupByRegex 'cz\\.adaptech.*'` (kho này chỉ được phục vụ đúng nhóm đó, gõ nhầm hay bị chiếm tên cũng không thay được thư viện khác). Dữ liệu: `rus.traineddata` của kho `tessdata_fast` (Apache-2.0, khoảng 3,7 MB, chỉ LSTM), tải MỘT lần khi người dùng chọn \"Cyrillic\" và bấm đồng ý (`ocr_cyr_download_ask`), lưu ở `filesDir/tesseract/tessdata`, sau đó chạy offline; không đóng gói sẵn để người không đọc chữ Cyrillic không phải gánh dung lượng. Mã: `OcrHelper.OcrScript.CYRILLIC` (đứng CUỐI vì hộp chọn liệt kê theo thứ tự `values()`) chuyển hướng cả ba hàm `recognize / recognizeBlocks / recognizeLines` sang `TesseractOcr`; `TesseractOcr` giữ MỘT `TessBaseAPI` sau một `Mutex` (không an toàn đa luồng), thu nhỏ ảnh quá 3 600 px cạnh dài rồi quy đổi toạ độ về ảnh gốc, nhả engine khi app xuống nền (`DocScannerApp.onTrimMemory`), và đọc kết quả bằng `getHOCRText(0)` + `HocrParser` (không dùng iterator của Tesseract để chỉ phụ thuộc vài hàm chắc chắn của thư viện: `init`, `setPageSegMode`, `setImage`, `getUTF8Text`, `getHOCRText`, `recycle`). Từ có độ tin cậy dưới 20 bị bỏ khỏi lớp chữ vô hình. Lớp chữ trong PDF dùng font Type3 + ToUnicode theo từng ký tự nên sao chép / tìm kiếm được chữ Cyrillic như chữ Hán. **Đã kiểm thật:** `hocr_check.py` (+ `HocrCheck.java`, bản Java chạy được của `HocrParser`) so với bộ đọc html.parser viết riêng trên đầu ra hOCR THẬT của Tesseract 5.3.4 cài sẵn (3 ảnh mẫu: chữ đậm, hai khối văn bản, dấu nháy / % / số) và 10 ca biên (thực thể `&amp; &lt; &#1087; &#x43F;`, thẻ lồng `<strong>`, từ thiếu `x_wconf`, hai đoạn, chữ Cyrillic) — TẤT CẢ ĐẠT. **KHÔNG kiểm và nói thẳng:** (a) không có mạng nên CHƯA tải được `rus.traineddata` và CHƯA đọc thử tiếng Nga thật (máy chỉ có dữ liệu tiếng Anh) — độ chính xác OCR tiếng Nga chưa đo; (b) CHƯA biên dịch Kotlin và chưa thử chữ ký thật của Tesseract4Android (đã đối chiếu README và ví dụ công khai, chỉ dùng sáu hàm nêu trên); (c) `EXPECTED_SHA256` trong `TesseractOcr.kt` còn TRỐNG vì không tải được tệp để lấy băm — việc đầu tiên sau lần chạy Actions đầu: tải `rus.traineddata`, chạy `sha256sum`, điền vào; trong lúc trống, tệp được bảo vệ bằng HTTPS, khung kích thước 1,5–40 MB, tên tạm chỉ đổi khi tải đủ và việc `init` của Tesseract từ chối tệp hỏng (khi đó tệp bị xoá và hỏi tải lại); (d) địa chỉ tải dùng nhánh `main` của `tessdata_fast` (có địa chỉ dự phòng `github.com/.../raw/main/...`); nếu nhánh đổi tên thì `download()` trả `false` và người dùng thấy `ocr_cyr_download_failed`. **Quyền riêng tư:** app giờ có HAI chức năng cần mạng, mỗi chức năng một lần (dịch và dữ liệu Cyrillic); đã sửa `help_privacy_body` ở cả 12 ngôn ngữ và thêm Tesseract / Leptonica / `rus.traineddata` vào `THIRD_PARTY_NOTICES.txt`; phải khai đúng trong Biểu mẫu An toàn dữ liệu của Google Play (tải về một tệp dữ liệu công khai, không gửi dữ liệu người dùng đi). **Phạm vi:** như chữ Hán / Nhật / Hàn, lựa chọn Cyrillic có trong hộp chọn bộ chữ của công cụ \"PDF tìm kiếm được\"; các chỗ OCR khác (tự tìm thông tin để che, dò mục lục, ebook từ OCR, dịch) vẫn dùng Latin. (10) **`runBatch` nay hỏi trước khi ghi đè chữ ký số:** mỗi file PDF đã ký trong danh sách xử lý hàng loạt hiện hộp thoại `SignedPdfGuard.confirm` (mọi phép hàng loạt đều ghi file MỚI nên chữ ký của file mới mất); từ chối = bỏ qua đúng file đó, đếm riêng bằng chuỗi mới `batch_skipped_signed` (đủ 12 ngôn ngữ) và KHÔNG tính vào \"file lỗi\". File không có chữ ký không bao giờ hiện hộp thoại. Kotlin chỉ rà tĩnh (`static_refs_check` đạt), chưa chạy trên máy. **Đã kiểm:** `i18n_check` TẤT CẢ ĐẠT cho 12 ngôn ngữ (1.099 chuỗi + 3 mảng mỗi ngôn ngữ). **KHÔNG kiểm và nói thẳng:** chưa có người bản ngữ rà; thuật ngữ nên được xác nhận: Pháp \"masquer définitivement\", \"filigrane\", \"liseuse\"; Đức \"schwärzen\", \"Wasserzeichen\", \"Tresor\"; Indonesia \"sensor informasi\", \"brankas aman\", \"tanda air\", \"penanda\" (bookmark). Tiếng Đức và Pháp dài hơn tiếng Anh khoảng 10-25 %, cần xem trên máy các hộp thoại dày chữ.

### 4.49. Phiên 22 — đọc lại tài liệu + PDF "Thiếu gì để bán app", đối chiếu danh mục A1–N9 với MÃ THẬT, làm các mục còn thiếu (xuất ngay sau từng mục)

**Cách làm (đúng dặn của chủ dự án: tra cứu để giải quyết, không để thành "chưa làm"; xuất ngay sau mỗi mục):** đọc mục 0, 6, 10, 11, 4.45–4.48 và các trang 40–59 của PDF (danh mục A1–N9 + lộ trình), rồi `grep` MÃ THẬT cho từng mã mục. Kết quả đối chiếu (chỉ liệt kê mục KHÔNG có trong mã trước phiên này; phần còn lại của danh mục đã có từ phiên 11–21): A5 chụp liên tiếp, C5–C7 đọc / chú thích / tìm trong EPUB, D6 mật khẩu ép buộc, D7 tự khoá theo thời gian chọn được, E6 / L13 / M2 / M4 nén nhiều tệp thành ZIP có mật khẩu, E8–E9 thư mục, F4 hàng đợi tác vụ, F6 API cho Tasker, F7 webhook, I2 điều khiển giọng nói, I3 tương phản cao, I4 chữ lớn, I6 phông dễ đọc, K1 widget, K5 dịch vụ in, K6 CameraX extension, L6 / L7 nhập từ clipboard / URL, L11 / L12 / L15 xuất JSON / XML / base64, M8 NFC, M9 Wi-Fi Direct, N4 chữ viết tay, N5 công thức, N10 OCR dịch trực tiếp. Môi trường phiên này vẫn KHÔNG có Kotlin / Gradle / mạng tải gói nên mã Kotlin chỉ kiểm bằng bản Java / Python song song + `static_refs_check` (như 4.27–4.48). Mỗi mục ghi rõ cái gì ĐÃ kiểm, cái gì CHƯA.

#### 4.49.1 Nén các tài liệu đã chọn thành ZIP, có thể đặt mật khẩu AES-256 (`ZipPack`, `MainActivity.zipSelected` / `runZip`)

PDF: E6 Archive, L13 Export as ZIP, M2 Share as ZIP, M4 Share with password (bốn dòng một việc). Trước phiên 22 chỉ có sao lưu toàn bộ (`BackupManager`) và chia sẻ nhiều tệp rời (`ACTION_SEND_MULTIPLE`); không có cách gửi MỘT tệp ZIP, càng không có mật khẩu.

- **Điểm vào:** Lịch sử -> chọn nhiều -> menu ⋮ -> "Nén thành ZIP…" -> hộp thoại hỏi mật khẩu (tuỳ chọn) -> ZIP ghi vào `cache/zip_share/` (thư mục mới `FileUtils.zipShareDir`, có trong `file_paths.xml` và trong `cleanOldCacheFiles`; mỗi lần tạo xoá ZIP cũ, nên không để lại bản sao tài liệu trong cache) -> hộp chia sẻ hệ thống (Drive / Dropbox / OneDrive / Gmail... nhận như mọi tệp).
- **Không mật khẩu:** `ZipOutputStream` thường (mở được mọi nơi, Windows Explorer gồm). Tệp đã nén sẵn (`pdf jpg png webp epub zip docx xlsx pptx cbz mp4 gz 7z`) lưu nguyên (STORED, một lượt tính CRC), còn lại Deflate mức nhanh.
- **Có mật khẩu: WinZip AES, bản AE-2, khoá 256 bit** - chuẩn thực tế mà 7-Zip, WinRAR, Keka, The Unarchiver, libarchive đọc. Cấu trúc đã đối chiếu với đặc tả (viết trong chú thích đầu `ZipPack.kt`): phương thức 99 + trường mở rộng `0x9901` {phiên bản 2, "AE", độ mạnh 3, phương thức thật}, cờ `0x0801` (mã hoá + tên UTF-8), CRC = 0 (AE-2 không lưu CRC; toàn vẹn do HMAC), dữ liệu = muối 16 byte | giá trị xác minh 2 byte | AES-CTR | 10 byte đầu của HMAC-SHA1(bản mã); khoá = PBKDF2-HMAC-SHA1(mật khẩu UTF-8, muối, **1 000 vòng**) -> 66 byte = khoá AES 32 | khoá HMAC 32 | xác minh 2. **Bộ đếm CTR là little-endian 16 byte bắt đầu từ 1** (khác CTR chuẩn big-endian của RFC 3686 / GCM: dễ viết sai, bài kiểm có thử âm tính). Mỗi mục có muối riêng. Ghi bằng `RandomAccessFile` để vá kích thước nén vào đầu cục bộ sau khi biết (không cần data descriptor, vì nhiều trình đọc kém xử lý nó cùng AES).
- **Quyết định: TỰ VIẾT PBKDF2 bằng `Mac` thay vì `SecretKeyFactory("PBKDF2WithHmacSHA1")`.** Lý do (đã nói trong bài kiểm bằng số liệu): nhà cung cấp mã hoá của Android có thể đổi mật khẩu thành byte bằng cách giữ 8 bit thấp của mỗi ký tự (kiểu PKCS#5 "8-bit"), khác UTF-8 mà mọi công cụ ZIP dùng; mật khẩu ASCII che mất chênh lệch đó, còn mật khẩu tiếng Việt có dấu thì tạo ra khoá KHÁC và tệp không mở được ở nơi khác. `zip_pack_check.py` chứng minh hai cách cho khoá khác nhau với "Mật khẩu" và bản tự viết = `hashlib.pbkdf2_hmac` trên UTF-8.
- **Giới hạn nói thẳng (hộp thoại nói hai điều đầu):** (1) TÊN TỆP trong ZIP không được mã hoá (định dạng AES của ZIP không có cách đó); (2) 1 000 vòng PBKDF2 do định dạng cố định, nên mật khẩu ngắn / phổ biến bị đoán nhanh - app đòi tối thiểu `MIN_PASSWORD_CHARS` = 8 ký tự (đếm theo ký tự Unicode) và hộp thoại khuyên dùng mật khẩu dài; (3) trình quản lý tệp có sẵn của một số bản Windows không mở được ZIP AES (cần 7-Zip...) - đã ghi trong hộp thoại; (4) không ZIP64: từ chối trước khi làm nếu tổng > 4 000 000 000 byte hoặc > 65 000 tệp (`ZipPack.TooBigException` -> chuỗi `zip_too_big`); (5) không phải mã hoá "két": ZIP rời khỏi app thì chỉ còn mật khẩu bảo vệ nó. Két thật vẫn là `VaultStore` (4.31 H).
- **Tên mục:** `entryNames` bỏ phần thư mục, ký tự điều khiển và `: * ? " < > |`, bỏ dấu chấm đầu / cuối, không để rỗng ("file"), và đánh số bản trùng KHÔNG phân biệt hoa thường (`a.pdf`, `A (2).PDF`) vì ZIP thường được giải nén trên Windows / macOS.
- **Kiểm chứng (`zip_pack_check.py` + `ZipPackCheck.java`, bản Java cùng thuật toán từng bước):** bộ đọc ĐỘC LẬP (viết trong script theo đặc tả, không dùng lại mã bản ghi) giải mã khớp từng byte 13 mục (rỗng, 1 / 15 / 16 / 17 byte, 64 KiB ±1, 5 MB ngẫu nhiên, 3 MB văn bản, tên emoji, trùng tên) với mật khẩu tiếng Việt + emoji; PBKDF2 Java = `hashlib` trên 24 ca; giờ DOS Java = `datetime` + `zoneinfo` trên 304 ca x 5 múi giờ; ZIP thường qua `zipfile.testzip()` và `unzip -t`; ZIP AES đọc được cấu trúc bởi `zipfile` (phương thức 99) và `zipinfo`; sai mật khẩu bị loại bởi giá trị xác minh, sửa 1 bit dữ liệu / mã xác thực bị HMAC bắt, sửa muối bị bắt; **thử âm tính:** bộ đếm big-endian và mật khẩu cắt 8-bit đều KHÔNG giải mã được; cùng hạt giống ngẫu nhiên cho cùng byte. **KHÔNG kiểm và nói thẳng:** (a) Kotlin chưa biên dịch; điểm nghi ngờ biên dịch: `ByteArray + ByteArray` nhiều toán hạng, `le32(0)` (số nguyên khai báo tham số `Long`), giải cấu trúc `Pair` ở `val (time, date)`, `trim { it.code <= 32 }`; (b) `Cipher("AES/ECB/NoPadding")` và `Mac("HmacSHA1")` của Android chưa chạy (JVM dùng cùng tên thuật toán; ECB dùng `doFinal` mỗi khối 16 byte để không phụ thuộc cách nhà cung cấp giữ đệm); (c) chưa thử mở tệp ZIP AES do app tạo bằng 7-Zip / WinRAR / Keka thật (môi trường không có chúng; bộ đọc độc lập là bằng chứng thay thế, cùng tác giả đặc tả nhưng khác mã); (d) hộp thoại, tiến trình, hộp chia sẻ chưa chạy trên máy. 8 chuỗi mới ở đủ 12 ngôn ngữ (`i18n_check` đạt; văn phong chưa có người bản ngữ rà).

#### 4.49.2 Xuất JSON / XML / Base64 (`TextExporters.json` / `xml` / `base64`, `MainActivity.exportText` / `exportBase64`)

PDF: L11 Export as JSON, L12 Export as XML, L15 Export as base64 (L8-L10 HTML / Markdown / CSV đã có từ 4.30).

- **JSON và XML** nằm cạnh HTML / Markdown trong hộp "Xuất văn bản" (mục lịch sử PDF hoặc TXT -> "Xuất HTML / Markdown / JSON / XML…"), cùng nguồn văn bản (lớp chữ hoặc OCR, `loadDocumentPages`) và cùng cách tách đoạn (`DocxWriter.paragraphsFromText`). JSON: `{"title", "pageCount", "pages": [{"page": N, "paragraphs": [...]}]}`, thụt 2 dấu cách, mỗi đoạn một dòng. XML: `<document title pages><page number><paragraph>`, UTF-8, XML 1.0.
- **Chi tiết đã xử lý (bài kiểm bắt, không đoán):** (1) nửa cặp thay thế (surrogate) ĐƠN ĐỘC không ghi được thành UTF-8 (sẽ thành "?"); JSON thay bằng U+FFFD, XML bỏ hẳn (như `DocxWriter.escape` làm từ trước: nó không phải ký tự XML 1.0); cặp hợp lệ (emoji) giữ nguyên; (2) ký tự điều khiển < 0x20 thoát `\u00XX`, không dùng `String.format` (tránh phụ thuộc ngôn ngữ máy); (3) XML: CR phải ghi là `&#13;` vì trình phân tích đổi CR chạy thành LF (bài kiểm có thử âm tính cho đúng điều này); thuộc tính `title` thoát thêm `"`, xuống dòng và tab; (4) U+2028 / U+2029 hợp lệ trong JSON nên giữ.
- **Base64** (`TextExporters.base64`): mọi tệp trong lịch sử -> `<tên>.b64` (menu "Lưu thành văn bản Base64 (.b64)"), RFC 4648 mục 4 có `=`, dòng 76 ký tự + LF (độ dài MIME; `base64 -d`, Python, Java MIME đều nhận; tham số 0 = một dòng). **Tự viết** thay vì `java.util.Base64` (cần API 26; app hỗ trợ API 24) và thay vì `android.util.Base64OutputStream` (không chạy trên JVM nên không kiểm được); đọc theo khối 12 288 byte (bội của 3) nên không cần mang số dư giữa các khối, chạy dòng (tệp PDF lớn không nằm trong bộ nhớ). Kiểm chỗ trống theo 4/3 kích thước tệp trước khi ghi. Đuôi `.b64` (không phải `.txt`, vì `.txt` cạnh `.pdf` cùng tên bị coi là tệp OCR đi kèm). Danh sách lịch sử nhận thêm đuôi `json`, `xml`, `b64`; MIME `application/json` / `application/xml`.
- **Kiểm chứng (`text_formats_check.py` + `TextFormatsCheck.java`):** xem bảng ở README; 11 phép kiểm đạt, gồm 2 thử âm tính. **KHÔNG kiểm và nói thẳng:** Kotlin chưa biên dịch (điểm nghi ngờ: `when` có nhánh `Character.isHighSurrogate(c) && ... -> { ...; i++ }` đổi biến vòng lặp trong nhánh; `c.code.toString(16).padStart(4, '0')`; hàm cục bộ `put` trong `base64` đóng trên `col` cục bộ); hộp thoại / ghi tệp trên máy chưa chạy; chưa đối chiếu JSON / XML với bộ đọc của app khác (chỉ các bộ đọc độc lập ở trên). 3 chuỗi mới + sửa nhãn `history_action_textformats` ở đủ 12 ngôn ngữ.

#### 4.49.3 Tự khoá lại sau thời gian chọn được (`AppLock.GRACE_OPTIONS_MS`, hàng "Khoá lại sau" ở màn chính)

PDF: D7 Auto-lock ("tự khoá sau N phút"). Trước phiên 22 thời gian ân hạn cố định 60 giây (`GRACE_MS`).

- **Mức chọn được:** 5 giây / 1 phút (mặc định, đúng như trước) / 5 / 15 / 30 phút, lưu ở `AppLock.graceIndex` (SharedPreferences `app_lock`, khoá `grace_index`, kẹp trong biên). `onActivityVisible` đọc mức đang chọn mỗi lần. Hàng "Khoá lại sau: …" (`tvLockDelay`) chỉ hiện khi khoá đang BẬT, bấm vào mở hộp chọn (RadioGroup dưới đoạn giải thích). Đổi mức KHÔNG đòi xác thực: nó chỉ quyết định bao lâu nữa app hỏi LẠI, không tắt khoá (tắt khoá vẫn đòi xác thực như cũ).
- **Vì sao mức ngắn nhất là 5 giây, không phải 0 ("khoá ngay"):** xoay màn hình làm Activity dừng rồi chạy lại trong vài trăm mili-giây; bộ đếm Activity thấy "không còn màn nào hiện" trong khoảnh khắc đó và đặt mốc `backgroundedAt`, nên mức 0 sẽ khoá app mỗi lần xoay. Bài kiểm có thử âm tính cho đúng điều này. Chuyển sang camera / bộ chọn tệp rồi quay lại trong 5 giây cũng không hỏi lại.
- **Hộp thoại:** không dùng `setMessage` cùng `setSingleChoiceItems` (AlertDialog có message sẽ KHÔNG hiện danh sách), nên dựng bằng `RadioGroup` dưới một `TextView` giải thích.
- **Kiểm chứng (`app_lock_check.py`, mở rộng):** bảng mức ĐỌC TỪ `AppLock.kt` và so với bản Python (nếu ai đổi một bên mà quên bên kia, bài kiểm đỏ); tăng dần, ngắn nhất >= 5 giây, mặc định = 60 000 ms; với MỖI mức: ra ngoài `g - 1` / `g` ms -> không khoá, `g + 1` ms -> khoá; xoay màn hình (300 ms) và đi lại trong app rất lâu -> không khoá; thử âm tính mức 0. **KHÔNG kiểm và nói thẳng:** Kotlin chưa biên dịch (`LinearLayout` / `RadioGroup` dựng bằng mã, `setOnCheckedChangeListener` cùng tên trong hai ngữ cảnh khác nhau); hộp thoại chưa chạy trên máy; `elapsedRealtime` ngừng đếm khi máy ngủ sâu nên "30 phút" tính theo thời gian máy thức, không phải đồng hồ treo tường (cùng hành vi với mức 60 giây cũ). Layout `sw600dp` sinh lại (43 id, 62 view con); 8 chuỗi mới ở 12 ngôn ngữ.

#### 4.49.4 Nhập từ liên kết web và từ clipboard (`LinkImport`, thẻ công cụ "Nhập từ liên kết hoặc clipboard")

PDF: L7 Import from URL, L6 Import from clipboard. Điểm vào: màn chính -> thẻ công cụ mới (`cardToolLink`, icon `ic_link`) -> hộp "Nhập từ…" ( "Liên kết web (https)…" chỉ hiện khi bản build có quyền INTERNET, cùng cờ `WifiScanActivity.isAvailable` với thẻ quét Wi-Fi; "Clipboard" luôn hiện).

- **Liên kết:** hộp nhập tự điền sẵn nếu clipboard đang chứa một liên kết hợp lệ. Tải một PDF (lưu vào danh sách tài liệu, đặt tên theo `Content-Disposition` hoặc đoạn cuối của đường dẫn) hoặc một ảnh JPEG / PNG / WebP (đi vào hàng đợi cắt như nhập từ thư viện ảnh). Ghi vào thư mục tạm trước (`FileUtils.tempDir`, tự dọn sau 24 giờ), xong mới chuyển vào danh sách.
- **Quy tắc an toàn (`LinkImport`, mọi quy tắc đều có ca kiểm):** (1) CHỈ https (`network_security_config` của app vẫn cho phép http toàn app vì máy quét eSCL cần; nên `LinkImport` tự từ chối http, không dựa vào cấu hình đó); (2) không thông tin đăng nhập trong liên kết (`user:pass@`), không khoảng trắng / ký tự điều khiển, tối đa 2 048 ký tự; (3) chuyển hướng theo dõi BẰNG TAY, tối đa 5 lần, KHÔNG BAO GIỜ hạ cấp https -> http, mỗi đích đi qua cùng bộ kiểm; (4) kiểu nội dung nhận dạng bằng BYTE ĐẦU (`%PDF-` trong 1 024 byte đầu theo ISO 32000, JPEG `FFD8FF`, PNG, WebP), KHÔNG tin `Content-Type` của máy chủ: trang HTML đăng nhập / báo lỗi bị từ chối sau 1 KB chứ không được lưu thành ".pdf"; (5) tối đa 100 MB (kiểm `Content-Length` khai báo trước, rồi đếm khi đang nhận: máy chủ nói dối hoặc gửi chunked mãi bị cắt); (6) tải cụt: JDK `HttpURLConnection` KHÔNG báo lỗi khi thân ngắn hơn `Content-Length` (Android thì có) - bài kiểm bắt được điều này nên mã tự so số byte với giá trị khai báo; (7) mọi lỗi xoá tệp dở; (8) liên kết có chữ có dấu / khoảng trắng được mã hoá %XX UTF-8, tên miền có dấu đổi sang punycode (`IDN.toASCII`).
- **Hai lỗi thật bài kiểm đã bắt (nên đã sửa):** `java.net.URI.resolve` theo RFC 2396 cũ nên Location kiểu `?page=2` làm mất tên tệp của địa chỉ gốc (`dir/page.pdf` -> `dir/?page=2`); mã tự xử lý trường hợp này theo RFC 3986. Và tải cụt (mục 6 ở trên).
- **Clipboard (`importFromClipboard`):** ảnh trong clipboard -> hàng đợi cắt; PDF -> lưu vào danh sách (`clipboard_<thời gian>.pdf`); văn bản -> hộp chọn: tải liên kết (nếu là một liên kết), lưu thành `.txt`, hoặc tạo PDF (`TextPdfBuilder`, đoạn tách bằng `DocxWriter.paragraphsFromText`). Chỉ đọc clipboard khi người dùng chọn mục này (Android 12+ hiện thông báo "đã dán từ clipboard").
- **Kiểm chứng (`link_import_check.py`):** xem README: 6 nhóm ca, gồm 21 tình huống mạng với máy chủ HTTP cục bộ do script dựng (không cần Internet). **KHÔNG kiểm và nói thẳng:** (a) Kotlin chưa biên dịch (điểm nghi ngờ: `fetch` trả về từ trong `use { }` lồng nhau và vòng `while (true)` không có `break`; `Uri.fromFile` đưa cho `importGalleryImages`, nó dùng `contentResolver.openInputStream` - đọc được `file://` trong cùng tiến trình nhưng chưa chạy; `runCatching { KeepAlive.during(...) { ... } }`); (b) chưa tải qua https thật (máy chủ thử là http trên 127.0.0.1; phần TLS do `HttpsURLConnection` của hệ thống lo); (c) chưa thử với trang bắt buộc đăng nhập / cookie / Cloudflare (sẽ báo "không phải PDF hoặc ảnh" hoặc "tải không thành công"; app không lưu cookie và không có trình duyệt); (d) Android tự thêm `Accept-Encoding: gzip` và giải nén, khi đó `Content-Length` bị bỏ nên phép so độ dài cụt không áp dụng (lỗi mạng giữa chừng vẫn do OkHttp báo); (e) tệp tải về chưa được quét mã độc: nó chỉ được mở bằng các thư viện PDF / ảnh của app, như mọi tệp nhận từ app khác. 17 chuỗi mới ở đủ 12 ngôn ngữ; layout `sw600dp` sinh lại (44 id).

#### 4.49.5 Tìm trong một cuốn EPUB (`EpubSearch`, menu "Tìm trong sách…")

PDF: C7 EPUB search. (C5 đọc EPUB trong app và C6 chú thích CHƯA làm; xem mục 6.) Điểm vào: Lịch sử -> giữ lâu một EPUB -> "Tìm trong sách…" -> gõ từ / cụm từ -> màn hình văn bản có sẵn (`TextResultActivity`, có nút sao chép) hiện: dòng tiêu đề "Kết quả cho “…”: N", rồi theo từng chương (số + tên) các dòng `• …ngữ cảnh «chỗ khớp» ngữ cảnh…`.

- **So khớp bỏ qua hoa / thường VÀ dấu**, như người dùng gõ trên điện thoại: "nguyen" tìm "Nguyễn", "duong" tìm "đường" (đ tính là d). **Sách lưu dấu dạng TÁCH RỜI** (chữ e + U+0301, nhiều trình chuyển đổi tạo ra) cũng tìm được: dấu bị bỏ khi gấp chữ, và bảng ánh xạ chỉ số đưa mọi chỗ khớp về VĂN BẢN GỐC của sách (chữ khớp giữ nguyên các dấu đi kèm). Dãy khoảng trắng (kể cả NBSP, xuống dòng) tính là một dấu cách ở cả hai phía nên cụm từ vắt qua xuống dòng vẫn khớp. Đường nhanh cho ASCII (chỉ chữ ≥ U+00C0 mới đi qua `Normalizer`) để cả cuốn sách vẫn nhanh.
- **Giới hạn:** tối đa 300 kết quả hiển thị, nhưng TỔNG số lần khớp vẫn được đếm đủ ("đang hiển thị 300 kết quả đầu tiên…" khi bị cắt); ngữ cảnh 60 ký tự mỗi bên, không cắt đôi cặp thay thế (emoji). Đọc sách bằng `EpubReader.read` mỗi lần tìm (không có chỉ mục lưu sẵn; sách thường chỉ vài MB nên chấp nhận được, chạy ở `Dispatchers.Default` với vòng quay chờ).
- **Kiểm chứng (`epub_search_check.py`):** xem README: 397 truy vấn ngẫu nhiên + 8 tình huống có tên + thử âm tính. Bài kiểm bắt được một kỳ vọng sai của CHÍNH MÌNH (đếm "Nguyễn Văn" 2 thay vì 1) - đã sửa bài kiểm, không phải mã. **KHÔNG kiểm và nói thẳng:** Kotlin chưa biên dịch (điểm nghi ngờ: `Character.NON_SPACING_MARK.toInt()` - hằng `Byte` của Java; `Triple` được tháo bằng `val (chapters, hits, total) = found`; `return@askText` trong lambda); hộp thoại / màn kết quả chưa chạy trên máy; chưa thử trên EPUB thật có TOC phức tạp (tên chương lấy từ `EpubReader`, có thể rỗng -> nhãn "Chương N"); chưa có bấm vào kết quả để nhảy tới vị trí (cần trình đọc EPUB trong app, mục C5 còn lại). 8 chuỗi mới ở đủ 12 ngôn ngữ.

#### 4.49.6 Widget "Quét nhanh" trên màn hình chính (`ScanWidgetProvider`, `widget_scan.xml`, `scan_widget_info.xml`)

PDF: K1 Widget. Ba nút một chạm: Quét, Ký PDF, PDF tìm kiếm được (thêm từ danh sách widget của launcher; nhãn "Quét nhanh", mô tả ở `widget_description`).

- **Dùng lại, không thêm đường mới:** mỗi nút mở `MainActivity` với ĐÚNG chuỗi hành động của phím tắt nhấn giữ biểu tượng (`AppShortcuts.ACTION_SCAN` / `ACTION_SIGN` / `ACTION_SEARCHABLE`), và `MainActivity.handleShortcutIntent` (đã có từ phiên 16) mở công cụ. Khoá ứng dụng vẫn đứng trước (Activity tự khoá khi khởi động). Widget KHÔNG hiển thị dữ liệu nào (chỉ nút), nên không thể làm lộ tài liệu trên màn hình khoá / màn hình chính; `updatePeriodMillis = 0` vì không có gì cần làm mới.
- **Intent dựng từ context của chính app** (như `AppShortcuts`), vì `applicationId` lấy từ biến kho `APP_ID` và không biết khi viết XML. Cờ `NEW_TASK | CLEAR_TOP | SINGLE_TOP`: nếu `MainActivity` đã mở thì nhận hành động qua `onNewIntent` thay vì chồng thêm một bản (MainActivity dùng launchMode mặc định nên thiếu `SINGLE_TOP` sẽ tạo bản thứ hai). `PendingIntent` có mã yêu cầu riêng cho từng nút (101 / 102 / 103) và `FLAG_IMMUTABLE`.
- **`<receiver android:exported="false">`** đúng như tài liệu Android cho widget (hệ thống gửi broadcast cập nhật). Layout chỉ dùng `LinearLayout` / `ImageView` / `TextView` vì `RemoteViews` không inflate được view khác; màu lấy từ `@color/surface`, `@color/primary`, `@color/text_primary` nên theo giao diện sáng / tối (có bản `values-night`); icon có `importantForAccessibility="no"`, mỗi nút có `contentDescription` (chuỗi "…_long" của phím tắt) - `accessibility_check` đạt.
- **Dùng lại chuỗi của phím tắt** (`shortcut_scan`, `shortcut_sign`, `shortcut_searchable` + bản `_long`) nên chỉ thêm 2 chuỗi mới (`widget_label`, `widget_description`) ở 12 ngôn ngữ. `targetCellWidth/Height`, `previewLayout`, `description` là thuộc tính từ Android 12 (bản cũ bỏ qua); `minWidth/minHeight` cho bản cũ.
- **KHÔNG kiểm và nói thẳng:** chưa thể thử trên launcher (môi trường không có Android): chưa xác nhận widget hiện trong danh sách, kích thước ô 3x1, nút bấm mở đúng công cụ, hay hành vi `onNewIntent` khi app đang mở; Kotlin chưa biên dịch (`Triple` được tháo trong vòng `for ((viewId, requestCode, action) in BUTTONS)`); `exported="false"` theo tài liệu nhưng nếu một launcher lạ không cập nhật được widget thì đổi sang `true` là điều đầu tiên cần thử.

#### 4.49.7 Chụp liên tiếp theo chu kỳ khi lật trang sách (`IntervalShooter`, nút "Chụp liên tiếp" ở màn chụp)

PDF: A5 Multi-shot / burst. Dùng cho sách đặt trên giá: chạm nút chụp MỘT lần, máy tự chụp mỗi 2 / 3 / 5 giây trong khi người dùng lật trang; chạm lần nữa để dừng. Nút `btnInterval` (dưới công tắc lưới) xoay vòng Tắt / 2 / 3 / 5 giây; khi chọn một chu kỳ, nút chụp và phím âm lượng đổi nghĩa thành "bắt đầu / dừng". Dòng gợi ý hiện số ảnh đã chụp và đếm ngược tới ảnh kế.

- **Vì sao không dùng luồng cũ:** ngoài chế độ Dự án, mỗi ảnh chụp thường mở NGAY màn cắt (`cropLauncher`) nên không thể rảnh tay. Ở chế độ liên tiếp, ảnh được xếp vào `burstPaths`; khi xong (nút Xong, nút X hoặc Back) cả loạt đi vào HÀNG ĐỢI CẮT như nhập từ thư viện ảnh (`PendingCropQueue.setAll(paths.drop(1))` + `CropActivity` ở `EXTRA_QUEUE_MODE = true`), KHÔNG xoá các trang đã có trong phiên. Trong chế độ Dự án, ảnh chụp đã được nối thẳng vào `pendingRawPaths` nên dùng nguyên luồng đó.
- **Đóng / Back không làm mất ảnh:** khi còn ảnh liên tiếp chờ, X và Back (qua `OnBackPressedCallback`, chỉ bật khi có ảnh chờ) đều đưa chúng vào hàng đợi cắt thay vì bỏ đi, giống ảnh thường đã cắt xong vốn được giữ trong phiên.
- **Không chạy cùng Tự động chụp:** bật cái này tắt cái kia (hai cơ chế cùng bấm màn sẽ chụp đúp). `onPause` dừng đồng hồ (máy ảnh không dùng được khi tạm dừng) nhưng giữ ảnh đã chụp.
- **Đồng hồ thuần (`IntervalShooter`, nhận đồng hồ từ ngoài):** ảnh đầu tới hạn NGAY khi bắt đầu; chu kỳ tính từ lúc BẮT ĐẦU một ảnh tới lúc bắt đầu ảnh sau; KHÔNG BAO GIỜ chụp chồng lên ảnh còn đang lưu (máy chậm thì chụp chậm lại, không xếp hàng); KHÔNG bù (màn hình đứng 10 chu kỳ thì chỉ có MỘT ảnh tới hạn); ảnh lỗi không chụp lại; tự dừng ở `MAX_SHOTS` = 300 để một lượt quên tắt không làm đầy bộ nhớ. `CaptureActivity.takePhoto(burst = true)` luôn báo `onShotFinished()` (kể cả khi lỗi hoặc thoát sớm) nếu không đồng hồ sẽ đứng vì tưởng ảnh còn đang lưu.
- **Kiểm chứng (`interval_shooter_check.py`):** 600 phiên mô phỏng, 8 tính chất + 2 tình huống có tên (ảnh lỗi vẫn đúng nhịp 3 s; ảnh lưu 6 s > chu kỳ 2 s thì nhịp theo ảnh chậm) + thử âm tính. Bản đầu bài kiểm có hai khẳng định RỖNG (`or True`, và điều kiện không bao giờ xảy ra) - đã tự bắt và thay bằng điều kiện thật (118 phiên chạm giới hạn). **KHÔNG kiểm và nói thẳng:** chưa chạy với camera thật; Kotlin chưa biên dịch (điểm nghi ngờ: `object : Runnable` tự gọi `postDelayed(this, …)`, `object : OnBackPressedCallback(false)`, tham số `burst` có giá trị mặc định trong lời gọi từ `Runnable`); một ảnh đang được lưu đúng lúc bấm Xong sẽ KHÔNG nằm trong loạt (cửa sổ dưới 1 giây; chưa xử lý); nếu hệ điều hành huỷ `CaptureActivity` khi đang tạm dừng thì danh sách `burstPaths` trong bộ nhớ mất (tệp ảnh vẫn nằm trong thư mục chụp, cache dọn sau 24 giờ); chưa có tiếng "tách" hay rung báo mỗi ảnh (chỉ có dòng chữ đếm ngược). 5 chuỗi mới ở 12 ngôn ngữ.

#### 4.49.8 Ký số bằng CHỨNG THƯ CỦA NGƯỜI DÙNG từ tệp `.p12` / `.pfx` (`Pkcs12Import`, `PdfDigitalSigner.importPkcs12`, `CmsSigner` có chuỗi chứng thư + ECDSA)

PDF mục 3.x "chứng thư từ tệp .p12" (còn lại từ phiên 17-19). Trước đây chỉ có chứng thư TỰ KÝ do app sinh trong Android Keystore: chữ ký chứng minh "tệp này nguyên vẹn kể từ khi ký" nhưng không ai tin được NGƯỜI ký là ai. Với chứng thư do nhà cung cấp chứng thư số cấp (người dùng Việt Nam thường có tệp `.pfx` / `.p12` mềm), trình xem PDF có thể dựng đường tới gốc tin cậy và hiện tên người ký.

- **Luồng:** ký số lần đầu (chưa có khoá) -> hộp "Dùng chứng thư nào để ký?": "Tạo chứng thư tự ký" (như cũ) hoặc "Dùng tệp chứng thư của tôi (.p12 / .pfx)…" -> chọn tệp (`OpenDocument`, tối đa 5 MB) -> hỏi mật khẩu (HỘP RIÊNG chứ không dùng `askText` vì mật khẩu RỖNG hợp lệ) -> nhập -> bước xác nhận + ký như cũ. Muốn đổi chứng thư về sau: "Xoá khoá" ở hộp xác nhận rồi nhập lại (hộp xác nhận đã hết nút).
- **`Pkcs12Import.read` (thuần `java.security`, có bản Java song song) kiểm theo thứ tự và báo đúng lý do:** `BAD_FILE_OR_PASSWORD` (định dạng không phân biệt được hai điều này), `NO_KEY` (tệp chỉ có chứng thư), `NOT_YET_VALID` / `EXPIRED` (ký bằng chứng thư ngoài hạn thì mọi trình xem báo sai), `UNSUPPORTED_KEY` (chỉ RSA và EC), `WEAK_KEY` (RSA < 2048 bit, EC < 256 bit), `KEY_MISMATCH` (ký thử 32 byte ngẫu nhiên rồi kiểm lại bằng khoá công khai của chứng thư: bắt trường hợp khoá không thuộc chứng thư).
- **Khoá được CHUYỂN vào Android Keystore** (`KeyStore.setEntry` + `KeyProtection`: chỉ ký, SHA-256, RSA thêm PKCS#1 v1.5), nên về sau không đọc ngược ra khỏi máy được; tệp và mật khẩu không được giữ (`password.fill`). Chuỗi chứng thư được lưu cùng khoá và NHÚNG vào mọi chữ ký.
- **`CmsSigner` mở rộng:** (1) trường `certificates` nhúng chứng thư người ký TRƯỚC rồi các chứng thư còn lại của chuỗi (không nhúng trùng); thiếu chuỗi thì trình xem không nối được chứng thư của CA với gốc và báo "người ký không xác định"; (2) khoá EC ký ECDSA-SHA256, mã nhận dạng thuật toán `1.2.840.10045.4.3.2` KHÔNG có tham số NULL (RFC 5758), khác RSA (có NULL). Chứng thư tự ký cũ không đổi một byte (chuỗi rỗng, RSA).
- **`PdfDigitalSigner.commonName`:** chứng thư của CA có tên đầy đủ (`CN=…,O=…,C=VN`); chỉ CN được ghi vào trường `/Name` của chữ ký, gỡ dấu thoát RFC 2253 (`A\, B` -> `A, B`).
- **Tra cứu và đo thêm (phiên 22, theo dặn "tra cứu rồi làm, đừng để thành giới hạn"):**
  - **Tệp `.p12` mặc định của OpenSSL 3 KHÔNG đọc được trên nhiều bản Android** (báo cáo trên Android 9, 12, 13; mã hoá PBES2 / AES-256 + MAC HMAC-SHA-256; chỉ bản mới của AOSP có commit "Bouncy Castle: Add support for PBES2 encrypted KeyStores") và báo nhầm là "sai mật khẩu". Tất cả công cụ xây trên OpenSSL 3 (Python `cryptography`, `openssl pkcs12 -export` mới, XCA, nhiều trang cấp chứng thư) tạo đúng loại này. -> **Đã làm `Pkcs12Modern.kt`**: bộ đọc dự phòng bằng `javax.crypto` thuần (RFC 7292: MAC HMAC SHA-1/224/256/384/512 trên hàm dẫn khoá của phụ lục B, SafeContents thường hoặc EncryptedData, khoá bọc PBES2 + PBKDF2 (PRF SHA-1/224/256/384/512) + AES-128/192/256-CBC, hoặc 3DES kiểu cũ). `Pkcs12Import` thử bộ đọc của hệ thống TRƯỚC (đọc được RC2-40 kiểu cũ mà bộ dự phòng không đọc), rồi mới dùng bộ dự phòng.
  - **Mật khẩu có dấu:** JDK từ chối mật khẩu ngoài ASCII ("Password is not ASCII"), nên bản Java của `Pkcs12Modern` KHÔNG dùng KeyStore để kiểm được mọi mật khẩu; BouncyCastle 1.77 có sẵn trong máy (`/usr/share/java/bcprov.jar`, cùng họ với bộ đọc `PKCS12` của Android) đọc được cả 24 tổ hợp mật khẩu ASCII / Việt NFC / Việt NFD / emoji / Nga / Hán x RSA / EC x 2 kiểu mã hoá (`pkcs12_bc_check.py`). **Phát hiện đo được:** BouncyCastle KHÔNG chuẩn hoá Unicode, nên mật khẩu gõ dạng NFC không mở được tệp tạo bằng mật khẩu NFD - và tệp xuất từ máy Mac hay mang dạng NFD. `Pkcs12Import.passwordVariants` vì thế thử mật khẩu như gõ, rồi dạng NFC, rồi NFD (đã kiểm hai chiều; mật khẩu sai / rỗng vẫn bị từ chối).
  - **Tin cậy bằng kho tin cậy THẬT:** `certutil` (NSS, thư viện xác thực chứng thư của Firefox mà poppler / `pdfsig` dùng) dựng kho tin cậy có gốc thử nghiệm: chữ ký có chuỗi nhúng -> `Certificate is Trusted` (RSA và EC); cùng gốc được tin nhưng KHÔNG nhúng chuỗi -> `Certificate issuer is unknown` (chứng minh việc nhúng chuỗi có tác dụng với trình xem thật); kho rỗng -> `issuer isn't Trusted`. Đây là bằng chứng gần nhất có thể làm ở đây thay cho Adobe Acrobat.
  - **`timestamp_check.py` có LỖI NGẪU NHIÊN có từ trước** (khoảng 1 lần trong 16): cắt phần đệm hex của `/Contents` bằng `rstrip("0")` làm mất luôn chữ số 0 cuối của dữ liệu thật. Đã sửa bằng cắt theo độ dài DER (chạy 8 lần liên tiếp không lỗi). Không phải lỗi của app.
- **Kiểm chứng:** `pkcs12_sign_check.py` (6 tệp đọc đúng, 8 từ chối đúng lý do, 4 chữ ký RSA / EC qua `pdfsig` + `openssl cms -verify -CAfile gốc` không `-untrusted`, NSS ở trên, 2 thử âm tính, `commonName` 10 tên đặc biệt); `pkcs12_bc_check.py` (BouncyCastle, 28 phép kiểm); `pkcs12_modern_check.py` (bộ đọc dự phòng: 21 tệp do `cryptography` và `openssl` tạo - AES-128/192/256, PRF và MAC SHA-1/256/384/512, 3DES, mật khẩu rỗng / Unicode, 1-3 chứng thư xáo trộn - khoá PKCS#8 và chuỗi chứng thư GIỐNG HỆT từng byte; từ chối đúng 5 kiểu mật khẩu sai; 30 tệp hỏng không bao giờ cho ra khoá sai; RC2-40 -> UNSUPPORTED). `digital_signature_check.py` và `timestamp_check.py` cũ vẫn đạt.
- **KHÔNG kiểm và nói thẳng:** (1) Kotlin chưa biên dịch (điểm nghi ngờ: `KeyProtection.Builder(...).setDigests(...).apply { ... }.build()`; `KeyStore.PrivateKeyEntry(key, chain.toTypedArray())`; `when` có nhánh `null ->` trên `reason` ở `MainActivity`; trong `Pkcs12Modern` các lớp lồng `Node` gọi hàm `read` của `object` bao ngoài; smart-cast của `key` / `chain` là `var` cục bộ ở `Pkcs12Import.readWith`); (2) `KeyStore.setEntry` nạp khoá phần mềm vào AndroidKeyStore chưa chạy trên máy; một số máy / bản Android có thể từ chối khoá EC hoặc kích thước lạ (thông báo chung "không nhập được chứng thư"); (3) BouncyCastle 1.77 trên JVM KHÔNG phải bản đóng gói trong từng phiên bản Android: nó chứng minh logic mật khẩu -> byte, không chứng minh từng bản Android (bộ đọc dự phòng `Pkcs12Modern` không phụ thuộc vào điều đó vì chỉ dùng `javax.crypto`, nhưng nếu một máy thiếu `HmacSHA224` / `PBKDF2` qua `Mac` thì chỉ ảnh hưởng PRF hiếm gặp); (4) chưa mở chữ ký bằng Adobe Acrobat (đã thay bằng NSS và `openssl`); chứng thư của CA chỉ được TIN trên máy người nhận khi gốc nằm trong kho tin cậy của họ (việc của CA); (5) không có OCSP / CRL nên chữ ký không "hợp lệ dài hạn" sau khi chứng thư hết hạn (dấu thời gian RFC 3161 ở 4.48.6 giúp một phần); (6) CHƯA làm dấu hiển thị cho chữ ký số (khung chữ ký có hình trên trang): vẫn là mục còn lại. 14 chuỗi mới ở 12 ngôn ngữ, thông báo `digsign_import_bad_file` sửa lại cho khớp (nhắc gõ mật khẩu đúng như lúc đặt).

#### 4.49.9 Rà Kotlin mức từ vựng khi không có trình biên dịch (`tools/verify/kotlin_lint_check.py`, bước CI mới)

Rủi ro lớn nhất còn lại của dự án là mã Kotlin từ phiên 16 đến 22 CHƯA được biên dịch (môi trường làm việc không có Kotlin / Gradle / mạng). Không có cách thay `kotlinc`, nhưng có thể bắt các LỚP lỗi rẻ và hay gặp:

- **Ngoặc cân bằng** trong từng tệp, có hiểu chuỗi, chuỗi thô `"""`, mẫu `${...}` lồng nhau, ký tự `'{'`, chú thích lồng. **Chữ Java lạc sang Kotlin:** `new Foo(`, `instanceof`, hàm tĩnh Java (`Integer.parseInt`, `Long.parseLong`, `Float.isNaN(x)`; hằng `Long.MAX_VALUE`, `Float.NaN` là Kotlin hợp lệ nên không bị báo). **API chưa có ở minSdk 24:** `java.time`, `java.util.Base64`, `java.nio.file.*` / `Files.*`, `InputStream.readAllBytes()` / `transferTo` (API 33), `List.of` / `Set.of` / `Map.of` (API 30), `ImageDecoder` (28), `Resources.getFont` (26)... Lớp lỗi cuối KHÔNG làm build đỏ (lint của Android chỉ cảnh báo) mà làm app SẬP trên máy cũ, nên có bước CI riêng.
- **Kết quả trên mã hiện có: 188 tệp, 0 phát hiện** (kể cả mã mới của phiên 22). Có 23 ca TỰ KIỂM chạy mỗi lần: lỗi thật bị bắt (thiếu / thừa ngoặc, `new`, `Integer.parseInt`, `java.time`, `readAllBytes`, `List.of`, `ImageDecoder`) và những thứ giống lỗi nhưng không phải thì không bị báo (cùng chữ trong chuỗi, mẫu `${map["k"]}`, mẫu lồng mẫu, chuỗi thô, chú thích lồng).
- **Một sai lầm của chính phiên này, ghi để khỏi lặp lại:** bản đầu của bộ rà có rule "độ ưu tiên toán tử" cho rằng `x and 0xFF == 0` là lỗi kiểu (Int and Boolean). SAI: trong Kotlin hàm trung tố (`and`, `or`, `shl`...) có độ ưu tiên CAO HƠN so sánh, nên đó là `(x and 0xFF) == 0`, hợp lệ (cái bẫy kiểu Java `x & 0xFF == 0` không tồn tại ở Kotlin). Phiên 22 đã thêm ngoặc thừa vào `Pkcs12Modern.kt` vì tưởng đúng: vô hại, nhưng rule đã bỏ và có ca tự kiểm khẳng định `x and 0xFF == 0` KHÔNG bị báo. Bẫy thật nằm ở phía cộng trừ (`1 shl n - 1` là `1 shl (n - 1)`).
- **Không bắt được (nói thẳng):** kiểu dữ liệu, tham số sai tên / sai kiểu, `when` làm biểu thức thiếu `else`, tham chiếu không tồn tại giữa các tệp (phần này do `static_refs_check` làm một phần), nullability, smart-cast, `suspend` gọi ngoài coroutine. Đã tự đối chiếu bằng tay chữ ký các hàm có sẵn mà mã mới của phiên 22 gọi (`FileUtils.tempDir`, `PdfExporter.exportDir`, `SmartNamer.uniqueFile`, `KeepAlive.during` là `suspend fun <T> during(context, block: suspend () -> T)`, `EpubReader.read(File): List<EbookBuilder.Chapter>`, `PendingCropQueue.setAll(List<String>, Float? = null)`, `TextResultActivity.EXTRA_TEXT_FILE_PATH`, `AppShortcuts.ACTION_SCAN / SIGN / SEARCHABLE`, `TextPdfBuilder.build(File, List<Chapter>)`): đều khớp. Một chỗ nghi ngờ đã loại: lớp lồng `Pkcs12Modern.Node` gọi `read` của `object` bao ngoài -> viết rõ `Pkcs12Modern.read(...)`.
- **CI:** `.github/workflows/android-build.yml` có thêm bước "Kotlin lexical lint" ngay sau "Docs sync check" (chạy trước khi cài JDK / SDK nên tốn chưa tới 1 giây). BẠN CẦN COMMIT bản workflow này lên kho (tệp trong zip đã sửa) để bước có hiệu lực.

#### 4.49.10 Dấu HIỂN THỊ cho chữ ký số (`VisibleSignature`, hộp "Hiện dấu chữ ký ở góc dưới bên phải của trang cuối")

Mục còn lại từ phiên 17-20. Chữ ký số trước đây vô hình: ai in PDF ra giấy hay mở bằng trình xem ẩn bảng chữ ký thì không thấy tài liệu đã được ký. Giờ có hộp chọn (nhớ lựa chọn, mặc định TẮT vì dấu nằm đè lên thứ đang ở góc đó) trong hộp xác nhận ký: dấu 200 x 58 pt, khung xanh, hai dòng "Ký số bởi <tên>" và ngày giờ, ở GÓC DƯỚI PHẢI THẤY ĐƯỢC của TRANG CUỐI.

- **Cơ chế (đúng cách ví dụ `CreateVisibleSignature` của PDFBox):** `SignatureOptions.setVisualSignature(InputStream)` + `setPage(trang cuối)` với một PDF MẪU MỘT TRANG chỉ chứa trường chữ ký + widget (Rect + luồng hiển thị = hình dấu). Mẫu được VIẾT TAY bằng byte (không gọi API PDFBox, nên giảm hẳn rủi ro biên dịch và kiểm được trên JVM): catalog có `/AcroForm` (SigFlags 3), trang cùng CropBox + Rotate với trang đích, widget `/FT /Sig /F 132` (in được + khoá, như `PDSignatureField` tạo), form XObject (BBox, Matrix, ảnh RGB 8 bit nén Flate). Hình dấu vẽ bằng `Canvas` (chữ Việt có dấu dùng phông hệ thống) ở độ phân giải 3 lần.
- **Phần khó là TRANG XOAY** (chú thích xoay theo trang): `userRect` đổi "góc dưới phải người dùng THẤY" sang toạ độ của chính trang (hiểu cả gốc CropBox khác 0 và ÂM, thu nhỏ dấu khi trang nhỏ), `formMatrix` xoay hình ngược chiều để sau khi trang xoay thì đọc xuôi. Kiểm bằng render poppler: 5 hộp trang x 4 góc xoay = 20 ca đạt (NCC thấp nhất 0,87 chỉ ở trang rất nhỏ do lấy mẫu lại; hộp bao điểm ảnh luôn trùng trong 2 điểm ảnh), mô phỏng ghép vào PDF 3 trang bằng pikepdf (NCC 0,991 cho cả 4 góc xoay), hai thử âm tính (ma trận đơn vị trên trang xoay 90 -> NCC 0,007; góc dưới trái -> phân biệt được).
- **An toàn khi ký:** `PdfDigitalSigner.sign(..., stampLines)` trả `true` nếu dấu có trong kết quả. Nếu dựng dấu / ghép dấu lỗi TRƯỚC lúc hàm ký được gọi (chưa ký gì, chưa gọi máy chủ dấu thời gian) thì ký LẠI không dấu và trả `false` (app báo "Đã ký, nhưng không thêm được dấu hiển thị"); lỗi SAU lúc đó (dấu thời gian, kiểm tra đầu ra) không thử lại để khỏi gọi mạng hai lần. Vì dấu là phần mới và ít được chứng minh nhất, "thiếu dấu" được ưu tiên hơn "thiếu chữ ký".
- **Sửa kèm (tìm ra khi rà đường ký):** từ 4.49.8 chuỗi chứng thư được nhúng vào CMS nhưng PDFBox chỉ dành sẵn 9 472 byte; chuỗi 3-4 chứng thư + chữ ký RSA 4096 có thể vượt và PDFBox từ chối "signature too large". Giờ vùng chữ ký = tổng kích cỡ chuỗi + 3 000 (+ 9 000 khi có dấu thời gian, tối thiểu 20 000 như trước), tối đa 60 000. Chứng thư tự ký một chứng thư vẫn dùng mặc định 9 472 như cũ.
- **KHÔNG kiểm và nói thẳng:** (1) lời gọi PDFBox thật (`SignatureOptions.setVisualSignature` / `setPage`, `PDPage.getCropBox`, `getRotation`) CHƯA chạy - môi trường chỉ có PDFBox 1.8, không có bản 2.0 của PDFBox-Android; PDFBox có thể từ chối mẫu viết tay vì một chi tiết mà ví dụ của nó tạo khác (khi đó cơ chế quay về ký không dấu sẽ chạy và app báo như trên); (2) hình dấu (`Canvas`) và việc dấu có hiện đúng sau khi PDFBox ghép chưa nhìn trên máy; mô phỏng ghép bằng pikepdf là sao chép widget + AcroForm, không phải thuật toán của PDFBox; (3) Kotlin chưa biên dịch (điểm nghi ngờ: `val (wPt, hPt) = VisibleSignature.visualSize(...)`, `for ((vx, vy) in listOf(x0 to y0, ...))` trong `userRect`, biến `signerCalled` bị lambda bắt và đổi); (4) dấu luôn ở góc dưới phải trang cuối: không cho kéo thả vị trí hay chọn trang; (5) không có ô chữ ký trống để người thứ hai ký sau (chỉ một dấu mỗi lần ký, `Signature1`); lần ký thứ hai trên tệp đã ký dùng cùng đường này nhưng tên trường trùng do PDFBox tự đặt lại. 3 chuỗi mới ở 12 ngôn ngữ.

#### 4.49.11 Thư mục phân cấp ẢO từ thẻ (`TagTree`; PDF E8 "chuyển / chép vào thư mục", E9 "phân cấp thư mục")

**Quyết định (có cân nhắc, không bỏ sót):** KHÔNG tạo thư mục thật. Danh sách lịch sử, thùng rác, sao lưu, ContentIndex, đổi tên, bộ theo dõi thư mục, két... đều giả định mọi tài liệu nằm phẳng trong một thư mục `exportDir`; thêm thư mục con thật sẽ chạm hàng chục chỗ mà môi trường này không biên dịch / chạy được, trong khi thẻ (`TagStore`, 4.31) đã đi theo mọi thao tác đó (đổi tên, thùng rác khôi phục `meta.tags`, sao lưu). Nên **thư mục = thẻ có dấu `/`**: thẻ `Công việc/Hoá đơn` là thư mục con `Hoá đơn` của `Công việc`.

- **Dùng:** gắn thẻ như cũ (giữ lâu một tài liệu hoặc chọn nhiều -> "Gắn thẻ…"), gõ `Công việc/Hoá đơn` vào ô tên (gợi ý trong ô đã đổi: "Tên thẻ hoặc thư mục (vd. Hợp đồng, Công việc/Hoá đơn)"). Hộp lọc (nút Thẻ) giờ hiện CÂY: cha trước con, thụt đầu dòng theo độ sâu, kèm số tài liệu; chọn thư mục cha thì thấy cả tài liệu trong thư mục con. Một tài liệu có thể nằm trong NHIỀU thư mục cùng lúc (vì là thẻ) - điều mà thư mục thật không làm được; "chuyển" và "chép" vì vậy là một việc (thay hoặc thêm thẻ).
- **Quy tắc:** so sánh không phân biệt hoa / thường và dấu (`công việc/Hoá đơn` = `Cong viec/hoa don`), `Workshop` KHÔNG thuộc `Work`, cha không thuộc con, bộ lọc rỗng không khớp gì; mỗi thư mục đếm số TÀI LIỆU khác nhau trong nó và dưới nó (không đếm trùng khi một tài liệu có hai thẻ dưới cùng một cha); `cleanTag` dọn dấu `/` (`Work / / Invoices/` -> `Work/Invoices`) và giới hạn thẻ tăng từ 30 lên 60 ký tự (đường dẫn dài hơn một từ). Cách viết hiển thị của một thư mục là cách viết gặp đầu tiên sau khi sắp theo tên tệp (không phụ thuộc thứ tự của Map).
- **Kiểm chứng (`history_filter_check.py` mở rộng):** bản port của `TagTree` + đối chứng VÉT CẠN độc lập (với mọi đường dẫn thư mục có thể có, đếm tài liệu bằng cách so từng thẻ) trên 300 bộ dữ liệu ngẫu nhiên có dấu / hoa thường / dấu `/` thừa: danh sách thư mục, độ sâu, nhãn, số tài liệu và kết quả lọc đều trùng; ví dụ có tên; thử âm tính (bộ lọc khớp-chính-xác cũ bỏ sót thư mục con). **Một lỗi của chính thay đổi này, tìm ra khi đọc lại các nơi gọi (4.49.12):** `MainActivity.renderHistory` tự BỎ bộ lọc thẻ nếu không có thẻ nào bằng đúng tên lọc; với thư mục cha chỉ tồn tại dưới dạng tiền tố (`Work` khi mọi thẻ là `Work/Invoices`) thì bộ lọc bị reset ngay. Đã sửa bằng `TagTree.matches`; các nơi khác dùng bộ lọc (`HistoryFilter.arrange`, hộp lọc) đã đúng. **KHÔNG kiểm và nói thẳng:** đây là bản PORT Python của Kotlin (cùng tác giả) chứ không phải bản Java chạy cùng thuật toán; Kotlin chưa biên dịch (điểm nghi ngờ: lớp cục bộ `Folder` trong `rows`, `Comparator<List<String>>` bằng SAM, smart-cast của `tagFilter` trong lambda của `arrange`); hộp lọc dạng cây chưa nhìn trên máy; KHÔNG có thư mục rỗng (một thư mục chỉ tồn tại khi có tài liệu mang thẻ dưới nó) và không có đổi tên / xoá cả thư mục một lượt; 2 chuỗi sửa ở 12 ngôn ngữ (`tag_new_hint`, `tag_filter_title`).

#### 4.49.12 Webhook khi có tài liệu mới + cách điều khiển app từ Tasker / Automate (PDF F7, F6)

**F7 Webhook (`DocumentWebhook`, hàng "Webhook: tắt / bật" ở màn chính, chỉ hiện khi bản build có quyền INTERNET).** TẮT cho tới khi người dùng nhập địa chỉ https. Khi có tài liệu MỚI trong danh sách, app POST một JSON ngắn `{"event":"document_created","app":"DocScanner","name","type","sizeBytes","modified"(UTC ISO)}` - **không bao giờ gửi nội dung, trang hay văn bản** (hộp thoại nói rõ). Có "Khoá ký" tuỳ chọn: mỗi tin kèm `X-DocScanner-Signature: sha256=<hex>` = HMAC-SHA256 của đúng byte thân tin (quy ước của GitHub / Stripe) để máy chủ nhận kiểm tra nguồn gốc và nguyên vẹn. Nút "Gửi thử" gửi tin `{"event":"test"}`.
- **Khi nào gửi:** chỉ khi app đang mở, mỗi lần danh sách được làm mới (không dịch vụ nền, không quyền mới). `pending` chọn tài liệu CHƯA báo, còn MỚI (trong 24 giờ), cũ nhất trước, tối đa 20 mỗi lượt; tin lỗi được thử lại ở lần làm mới sau chừng nào tài liệu còn mới; tài liệu quá cũ chưa báo được đánh dấu "đã thấy" (không thử mãi). **Lần đầu bật, mọi tài liệu đang có được coi là đã thấy** để bật webhook không phát loa cả thư viện.
- **An toàn:** chỉ https và không có tên đăng nhập trong địa chỉ (cùng `LinkImport.parse`); KHÔNG theo chuyển hướng (một chuyển hướng có thể đưa thân tin tới nơi người dùng chưa từng nhập); hạn 10 giây; chỉ mã 2xx tính là đã giao. Bí mật ký lưu trong SharedPreferences riêng của app (không mã hoá thêm: ai đọc được vùng dữ liệu riêng của app thì đã đọc được cả tài liệu).
- **Kiểm chứng (`webhook_check.py`):** xem README; 11 phép kiểm + thử âm tính. **KHÔNG kiểm và nói thẳng:** Kotlin chưa biên dịch; hộp thoại và việc gửi khi làm mới chưa chạy trên máy; chưa thử với n8n / Make thật; app không gửi khi đang đóng (muốn thế cần dịch vụ nền / WorkManager, là bước sau). 10 chuỗi mới ở 12 ngôn ngữ.

**F6 Tasker / Automate / MacroDroid: không cần mã mới, chỉ cần biết cách.** `MainActivity` được xuất (`exported="true"`) và xử lý các hành động của lối tắt qua `handleShortcutIntent` (`AppShortcuts.ACTION_SCAN`, `ACTION_SIGN`, `ACTION_SEARCHABLE`, `ACTION_PROJECT`); bất kỳ công cụ tự động hoá nào gửi Intent TƯỜNG MINH tới `<applicationId>/com.example.docscanner.MainActivity` với hành động đó đều mở đúng công cụ (đây cũng chính là cách widget "Quét nhanh" hoạt động, 4.49.6). Hành động chỉ MỞ màn hình cho người dùng bấm tiếp, không tự quét / tự ký, nên không mở ra đường cho ứng dụng khác thao tác tài liệu. Chiều ngược lại (app báo cho công cụ khác) là webhook ở trên. Không thêm broadcast "làm hộ" vì đó là bề mặt tấn công (ứng dụng lạ ra lệnh cho app đọc / ký tài liệu).

#### 4.49.13 Cỡ chữ trong app và chữ tương phản AAA (PDF I4 "chữ lớn", I3 "tương phản cao")

**I4 - hàng "Cỡ chữ: Chuẩn" ở màn chính** (4 mức: Chuẩn / Lớn / Lớn hơn / Lớn nhất = 1,0 / 1,15 / 1,3 / 1,5 lần), CỘNG THÊM vào cỡ chữ của điện thoại và chặn ở 2,0 tổng cộng. Chọn xong màn hình tải lại (`recreate()`); các màn khác nhận mức mới khi mở lần sau.
- **Cách làm:** mọi Activity (32, trước là `AppCompatActivity` trực tiếp) giờ kế thừa `BaseActivity`, nơi `attachBaseContext` gọi `FontScale.wrap(newBase)`. Mọi `textSize` trong layout đã là sp (kiểm tự động) nên chữ phóng theo. **Chuẩn (mặc định) trả về CHÍNH context đó**: người chưa mở cài đặt chạy đúng đường mã cũ; rủi ro của cách bọc ngữ cảnh chỉ rơi vào người chủ động bật.
- **Hệ quả cho bộ rà tĩnh (đã sửa):** `BaseActivity` là lớp TRỪU TƯỢNG (không phải màn hình, không cần có trong manifest); `static_refs_check.py` trước đó chỉ nhận lớp kế thừa `AppCompatActivity` là Activity nên sau khi đổi sang `BaseActivity` nó sẽ IM LẶNG ngừng bắt Activity thiếu trong manifest. Giờ nó nhận cả `BaseActivity`, bỏ qua lớp `abstract`, và đã thử âm tính bằng một `GhostActivity` giả (bị bắt).
- **Điều cố ý KHÔNG làm:** không ghi đè `applyOverrideConfiguration` để sao chép cấu hình nền - cách "sửa" phổ biến cho lỗi AppCompat 1.2.0 - vì AppCompat dùng đúng hook đó để áp NGÔN NGỮ RIÊNG của app (`setApplicationLocales`, 4.46): sao chép sẽ làm hỏng chọn ngôn ngữ. Với `fontScale` thì không cần: AppCompat đặt `fontScale = 0` ở cấu hình ghi đè, nghĩa là "không đổi", nên giá trị của ta được giữ.
- **I3 - chữ AAA, không phải "chế độ" riêng:** app dùng `@color/...` trực tiếp trong layout, nên không thể đổi sang bảng màu thứ ba bằng một công tắc mà không viết lại mọi layout. Thay vào đó đã đo và nâng tương phản của chữ: `text_secondary` giao diện sáng từ `#616161` (5,68:1 trên nền `#F5F5F5`, 6,19 trên mặt phẳng) lên `#525252` (7,17 / 7,81); chữ chính và cả hai màu chữ ở giao diện tối vốn đã >= 7:1. `night_theme_check.py` nay đòi **>= 7:1 (WCAG AAA)** cho chữ chính và chữ phụ trên nền và mặt phẳng ở cả hai giao diện. Nút (chữ trắng trên `primary`, 5,75 / 5,58) giữ ở mức AA vì đổi màu thương hiệu là quyết định thiết kế, không phải việc của một bản sửa trợ năng; chế độ "chữ tương phản cao" của hệ điều hành vẫn hoạt động như mọi ứng dụng.
- **Kiểm chứng:** `base_activity_check.py` (xem README) và `night_theme_check.py`; `accessibility_check`, `tablet_layout_check` (sinh lại, 46 id) đạt. **KHÔNG kiểm và nói thẳng:** (1) Kotlin chưa biên dịch; (2) CHƯA nhìn trên máy: ở mức 1,5 một số hàng có thể xuống dòng hoặc cắt chữ (layout dùng `wrap_content` nhưng chưa kiểm từng màn ở cỡ lớn, và đã có kiểm cho chữ hệ thống lớn từ phiên trước chứ không phải cho hệ số của app); (3) Activity đang mở ở màn khác (Chụp, Cắt...) không tự đổi cho tới khi mở lại; (4) `recreate()` mất trạng thái chưa lưu của màn chính (ô tìm kiếm, bộ lọc); (5) 7 chuỗi mới ở 12 ngôn ngữ.

#### 4.49.14 Chế độ ảnh HDR / ban đêm (CameraX Extensions; PDF K6)

Nút "Chế độ ảnh: thường" ở màn chụp (dưới nút "Chụp liên tiếp") xoay vòng thường / HDR / ban đêm, dùng phần mềm chụp ảnh CỦA CHÍNH ĐIỆN THOẠI qua `androidx.camera:camera-extensions:1.4.1` (cùng phiên bản CameraX, giấy phép Apache như các thư viện camera khác). **Mặc định là thường và `startCamera` đi đúng đường cũ** (`bindUseCases(provider, DEFAULT_BACK_CAMERA, withAnalysis = true)`: cùng Preview + ImageCapture + ImageAnalysis như trước phiên 22); người không chạm nút này không đi qua mã mới nào ngoài việc tách hàm.
- **Khi bật HDR / đêm:** `ExtensionsManager.getInstanceAsync` -> `isExtensionAvailable` -> `getExtensionEnabledCameraSelector` -> ràng lại. Máy không hỗ trợ thì tự về chế độ thường và báo ("Camera này không có chế độ đó nên dùng chế độ thường"). Một số máy không cho `ImageAnalysis` chạy cùng extension (`isImageAnalysisSupported`): khi đó bỏ ImageAnalysis, công tắc "Tự động chụp" (cần khung hình phân tích) bị tắt và vô hiệu hoá trong chế độ đó; chụp liên tiếp (`IntervalShooter`) không cần phân tích nên vẫn dùng được.
- **KHÔNG kiểm và nói thẳng:** hoàn toàn CHƯA chạy (không có máy ảnh, không có Android, không biên dịch được): API `ExtensionsManager` / `ExtensionMode` viết theo CameraX 1.4 nhưng chưa dịch; artifact `camera-extensions:1.4.1` chưa được Gradle giải quyết (nếu CI báo không tìm thấy, xoá đúng một dòng trong `build.gradle` và hàm `cycleExtension` / nút sẽ không biên dịch được: gỡ cả ba cùng lúc); hành vi chụp thật của HDR / đêm (thời gian chụp lâu hơn, bắt buộc giữ yên máy) chưa thử; `startCamera` được gọi lại mỗi lần đổi chế độ nên nhấp nháy xem trước một lúc; chế độ không được nhớ giữa các lần mở. `static_refs_check` đã bắt được một lỗi THẬT trong mã này khi viết (thiếu `import android.widget.Toast`) - đã sửa. 4 chuỗi mới ở 12 ngôn ngữ.

#### 4.49.15 Dịch một bức ảnh (thẻ "Dịch ảnh chụp"; PDF N10 dưới dạng MỘT ảnh, không phải lớp phủ trực tiếp)

Thẻ công cụ `cardToolSnap`: bấm -> máy ảnh CỦA HỆ THỐNG chụp một ảnh (`ActivityResultContracts.TakePicture`, ghi vào `cache/translate_snap/`, khai báo trong `file_paths.xml`; không cần quyền CAMERA của app) -> `OcrHelper` ML Kit đọc ảnh -> chọn ngôn ngữ đích -> `TextTranslator` (mô hình dịch trên máy, 4.xx) -> hộp hiện bản dịch + nút Sao chép. Ảnh bị xoá ngay sau khi đọc; không lưu gì vào danh sách.
- **Chọn bộ đọc chữ:** ML Kit không đoán được hệ chữ, nên chạy Latin trước; nếu thấy ít hơn 8 chữ cái thì thử thêm Trung, Nhật, Hàn, Devanagari và giữ kết quả nhiều chữ cái nhất. Tiếng Nga / Ukraina (Cyrillic, do `TesseractOcr` đọc và phải tải dữ liệu) KHÔNG nằm trong luồng này.
- **Vì sao một ảnh chứ không phải lớp phủ trực tiếp:** lớp phủ dịch từng khung hình cần OCR + dịch mỗi khung (tốn pin, nóng máy, mô hình dịch chạy chậm hơn nhịp khung hình) và một màn hình camera riêng không thử được ở đây; một ảnh chụp bằng máy ảnh hệ thống cho độ phân giải đầy đủ, ít rủi ro hơn và vẫn trả lời nhu cầu "đọc biển báo / thực đơn bằng ngôn ngữ khác". Thực tế khi đọc một biển báo, người ta cũng chụp một lần.
- **Riêng tư:** ảnh và văn bản không rời máy (ML Kit đọc và dịch trên máy); lần đầu dịch sang mỗi ngôn ngữ phải tải mô hình ~30 MB (đã nói trong hộp xác nhận, dùng lại chuỗi `translate_model_note`).
- **KHÔNG kiểm và nói thẳng:** hoàn toàn CHƯA chạy (không có máy ảnh / Android / biên dịch); điểm nghi ngờ biên dịch: `return@withContext ""` trong `withContext` có `try/finally` là biểu thức cuối; `fun letters(...)` cục bộ trong lambda. Một số máy ảnh hệ thống trả ảnh xoay bằng EXIF: `BitmapFactory.decodeFile` KHÔNG tự xoay, nên ảnh chụp dọc có thể bị OCR kém; chưa xử lý EXIF ở đây (chỗ cần làm đầu tiên nếu OCR kém trên máy thật). 3 chuỗi mới ở 12 ngôn ngữ; bộ kiểm tĩnh đã bắt được 0 lỗi lần này.

### 4.50. Phiên 23 — trình đọc EPUB trong app, tô sáng, dấu trang (PDF C5 / C6; nối với C7)

**Trước phiên này:** có `EpubReader` (đọc EPUB thành chương), `EpubSearch` (tìm, kết quả ra một tệp văn bản), nhưng KHÔNG có màn đọc: muốn đọc sách phải xuất ra tệp khác. Mục 6 "Còn lại sau phiên 22" ghi C5 / C6 là "làm được, chưa làm".

**Cách dùng:** Lịch sử -> nhấn giữ một tệp `.epub` -> "Đọc sách…". Màn đọc: tiêu đề chương + đoạn chữ chọn được. Chọn vài chữ -> menu chọn có thêm "Tô sáng" / "Bỏ tô sáng". Menu ⋮: Mục lục, Tìm trong sách (kết quả là danh sách, chạm để NHẢY tới đoạn), Đánh dấu chỗ này (dấu trang cho đoạn đang ở đầu màn hình; đoạn có dấu trang có nền hổ phách nhạt), Dấu trang / Tô sáng (danh sách: chạm để nhảy, GIỮ LÂU để xoá), Chữ lớn hơn / nhỏ hơn (12-32 sp, nhớ lại), Chép ghi chú của tôi (dấu trang + các đoạn đã tô, kèm nhãn chương, vào clipboard). Vị trí đọc được nhớ khi rời màn và mở lại đúng chỗ.

**`EpubNotes` (logic thuần, bản Java `EpubNotesCheck.java`):**
- một ghi chú trỏ tới (chương, đoạn) cùng chỉ số mà `EpubReader` / `EpubSearch` dùng; tô sáng thêm [bắt đầu, kết thúc) theo đơn vị UTF-16 của đoạn;
- thêm tô sáng: cắt khoảng trắng hai đầu (gồm NBSP; U+0085 KHÔNG phải khoảng trắng, như `Character.isWhitespace` của Java), không bao giờ cắt đôi cặp thay thế (emoji), gộp với mọi vùng của cùng đoạn mà CHỒNG hoặc KỀ nhau; xoá vùng cắt phần bị phủ (vùng chứa vùng xoá thì tách đôi); dấu trang là TẬP vị trí (đánh dấu lại = bỏ); trần 5 000 ghi chú (vùng gộp vào vùng có sẵn vẫn được);
- **dấu vân tay của sách** (CRC-32 trên cấu trúc chương + độ dài và byte UTF-8 từng đoạn, kèm số đoạn): offset chỉ có nghĩa với CHÍNH văn bản đó. Sách đã đổi (tách / ghép / xuất lại) -> tệp ghi chú cũ được ĐỔI TÊN thành `.stale` (không xoá), màn đọc báo một dòng và bắt đầu trống, thay vì tô nhầm chữ;
- tệp văn bản một dòng một ghi chú (`DOCSCANNER-EPUB-NOTES 1`, `F`, `L`, `B`, `H`), ghi qua tệp tạm rồi đổi tên; đọc KHÔNG BAO GIỜ ném lỗi: dòng hỏng bị bỏ, ghi chú ngoài sách bị bỏ, đầu vùng tô bị kẹp vào đoạn, trùng / chồng được gộp như thêm tay. Tệp nằm ở `filesDir/epub_notes/<tên sách>.notes` (riêng của app; KHÔNG nằm trong sao lưu ZIP của `BackupManager` - nếu cần, thêm thư mục này vào đó).

**Quyết định:** (1) đánh dấu trang bằng NỀN dòng chứ không chèn ký hiệu vào chữ, để offset chọn chữ luôn đúng; (2) tô sáng là nền vàng + chữ đen cố định (đọc được cả giao diện sáng và tối, không thêm tên màu vào `colors.xml`); (3) không dùng WebView: `EpubReader` đã trả đoạn chữ thuần, danh sách `RecyclerView` giữ nhẹ và cho chọn chữ bằng cơ chế sẵn có của `TextView`; (4) tìm tái dùng `EpubSearch` và chuỗi tìm kiếm có sẵn; chuỗi mới 22 cái x 12 ngôn ngữ (bản dịch do trợ lý viết, CHƯA có người bản ngữ rà).

**Đã kiểm (`epub_notes_check.py`, cần `java`):** dấu vân tay = bản CRC độc lập (300 cuốn) và đổi khi đổi chữ / dời đoạn / dời ranh giới chương / đổi chỗ chương / thêm đoạn rỗng; 700 phiên x tới 25 thao tác (9 103 trạng thái) so với MÔ HÌNH MẶT NẠ độc lập; 10 ví dụ có tên; trần 5 000; dấu trang 400 phiên; mã hoá = bản dựng độc lập, vòng đi - về 300 trạng thái; 900 tệp bị phá ngẫu nhiên; trích đoạn 500 chuỗi; "Chép ghi chú" 150 cuốn; tệp thật (lưu / đọc / `.stale` / không có tệp / không để lại `.tmp`); 5 thử âm tính; **5 ĐỘT BIẾN bản Java** (không gộp vùng kề nhau, bỏ cắt khoảng trắng, vân tay không độ dài đoạn, bỏ né cặp thay thế, xoá không tách đôi) đều làm bộ kiểm đỏ. Còn `i18n_check`, `strings_check`, `accessibility_check`, `night_theme_check`, `base_activity_check`, `large_screen_check`, `static_refs_check`, `kotlin_lint_check`, `doc_sync_check` đạt.

**CHƯA kiểm, nói thẳng:** mã Kotlin (`EpubNotes.kt`, `EpubReaderActivity.kt`, `EpubRowAdapter.kt`) chưa biên dịch; bản Java là bản chép từng câu nên bắt lỗi LOGIC chứ không bắt lỗi biên dịch. Điểm nghi ngờ biên dịch / chạy: `customSelectionActionModeCallback` trên `TextView` chọn được trong `RecyclerView` (chọn chữ có thể mất khi dòng được vẽ lại - đã tránh bằng `mode.finish()` trước khi cập nhật); `AlertDialog.listView.setOnItemLongClickListener` trong `setOnShowListener`; `scrollToPositionWithOffset` ngay sau `submit` (dùng `post`); sách rất dài (hàng chục nghìn đoạn) chưa đo. Việc thử trên máy: mở một EPUB do chính app xuất và một EPUB từ Calibre; tô sáng đoạn có dấu tiếng Việt tách rời; xoay màn hình giữa chừng; giữ lâu để xoá trong danh sách.

### 4.51. Phiên 23 — PAdES-B-LT: lưu dữ liệu thu hồi chứng thư (OCSP / CRL) vào PDF đã ký (`Revocation`, `PdfLtv`)

**Vì sao làm được lúc này:** từ phiên 22 (4.49.8) app ký được bằng chứng thư `.p12` do nhà cung cấp chứng thư số cấp, và CMS đã mang theo cả chuỗi chứng thư; manifest ĐÃ có `INTERNET` (dùng cho TSA, 4.48.6 và nhập liên kết, 4.49.4). Với chứng thư tự ký không có gì để thu hồi nên mục này chỉ có nghĩa với chứng thư của CA. (Ghi chú sửa: bản trả lời đầu phiên 23 nói nhầm rằng app "cố ý không xin INTERNET".)

**Dùng:** hộp "Ký số" có thêm ô "Lưu thêm dữ liệu thu hồi chứng thư (OCSP / CRL)…" (nhớ lại, mặc định TẮT vì gọi mạng). Sau khi ký xong, `PdfLtv.addValidationInfo` đọc các chứng thư trong CMS của mọi chữ ký, hỏi máy chủ OCSP (ưu tiên) hoặc tải CRL (dự phòng) cho từng chứng thư trừ gốc tự ký, rồi nối MỘT bản cập nhật tăng dần thêm `/DSS` (`/Certs`, `/OCSPs`, `/CRLs`) vào catalog. Lỗi ở bước này KHÔNG huỷ chữ ký: chỉ báo "đã ký, nhưng không lưu được dữ liệu thu hồi". Thông báo cuối nói "đã lưu cho X / Y chứng thư" hoặc "chưa lưu gì (không có máy chủ thu hồi hoặc không ai trả lời)". 4 chuỗi `digsign_ltv_*` x 12 ngôn ngữ.

**`Revocation` (thuần, bản Java `RevocationCheck.java`):** `fields` (serial / issuer / subject / bit khoá / extensions của chứng thư, đọc DER), `urlsOf` (chỉ http / https: AIA phương thức OCSP, CDP fullName; bỏ ldap://, ftp://), `certId` + `buildOcspRequest` (CertID SHA-1 chỉ để định danh, KHÔNG nonce để máy chủ trả từ bộ nhớ đệm như RFC 5019), `parseOcspResponse` (trạng thái, good / revoked / unknown, và trả lời CÓ đúng cho chứng thư này không), `cmsCertificates`, `issuerOf`, `collect` (OCSP nếu "good" và đúng chứng thư; nếu không thì CRL dạng DER; "revoked" / "unknown" / trả lời của chứng thư khác KHÔNG được nhúng; trùng không nhúng lặp). Mọi hàm đọc DER bắt `RuntimeException` nên byte hỏng chỉ cho kết quả rỗng. **Cố ý KHÔNG làm:** không kiểm chữ ký của máy chủ OCSP và thời hạn `thisUpdate/nextUpdate` (việc của trình đọc PDF khi xác thực sau này).

**`PdfLtv` (PdfBox 2.0.27):** `PDDocument.load` -> `signatureDictionaries` + `PDSignature.getContents` -> gom -> `COSDictionary` /DSS mới (nếu đã có /DSS thì MANG THEO các luồng cũ theo tham chiếu, không trùng byte) -> `setNeedToBeUpdated(true)` cho catalog, DSS, mảng, luồng -> `saveIncremental` vào tệp tạm -> `PdfVerify.opensAsPdf` -> thay tệp. Không có /VRI (tuỳ chọn; trình đọc nhận /DSS chung), không dấu thời gian tài liệu (đó là PAdES-B-LTA), chứng thư bên trong token dấu thời gian chưa được gom.

**Đã kiểm:** `revocation_check.py` (OpenSSL 3.0.13 + `cryptography`; PKI gốc -> trung gian -> chứng thư cuối có AIA / CDP): trường chứng thư và URL = `cryptography`; **OCSPRequest KHỚP TỪNG BYTE với `openssl ocsp -reqout -no_nonce`**; máy chủ `openssl ocsp -port` THẬT trả lời good / revoked / unknown cho 3 chứng thư và Java đọc đúng (đối chiếu `-resp_text`); trả lời của chứng thư khác không bị coi là của chứng thư này; trạng thái lỗi 1 / 2 / 3 / 5 / 6; `cmsCertificates` = `openssl cms -sign -certfile`; `collect` 9 kịch bản (OCSP, rơi sang CRL, revoked không nhúng, mạng chết, chuỗi lặp, thiếu trung gian, CRL dạng PEM); 3 526 lệnh trên byte rác / bản cắt cụt / đổi byte của chứng thư, OCSP, CMS, CRL thật không ném lỗi; 4 thử âm tính (băm cả SPKI, bỏ kiểm certID, nhận revoked như good, không bỏ gốc tự ký) đều bị bắt. `ltv_pdf_check.py` (PDF ký thật bằng CMS của `CmsCheck.java`): nối /DSS bằng cập nhật tăng dần -> `pdfsig` VẪN "Signature is Valid", 13 158 byte đã ký còn nguyên ở đầu tệp, `qpdf --check` sạch, `pikepdf` đọc đúng từng byte DER, chứng nhận DocMDP mức 1 vẫn hợp lệ, DSS lần hai mang theo mục cũ và hai chữ ký còn hợp lệ; ĐỐI CHỨNG: ghi lại cả tệp bằng pikepdf làm chữ ký mất hiệu lực.

**CHƯA kiểm, nói thẳng:** (1) `PdfLtv.kt` và `MainActivity` chưa biên dịch, và các lời gọi PdfBox (`signatureDictionaries`, `PDSignature.getContents(InputStream)`, `createCOSStream`, `createOutputStream(FLATE_DECODE)`, `setNeedToBeUpdated`, `saveIncremental` với tệp xref-stream / object-stream do `PdfStructureOptimizer` tạo) chưa chạy; `ltv_pdf_check.py` dựng TAY bản cập nhật cùng cấu trúc, nên chứng minh cấu trúc đó hợp lệ chứ KHÔNG chứng minh PdfBox ghi đúng. (2) Chưa có CA thật: chưa thử OCSP / CRL của một nhà cung cấp chứng thư số Việt Nam; máy chủ thật có thể đòi nonce, trả `unauthorized`, hoặc chỉ có CRL dạng PEM / LDAP (khi đó chứng thư đó "không được phủ"). (3) Chưa thử mở bằng Adobe Acrobat: cần xem "Long Term Validation enabled" và không có cảnh báo; `ltv_pdf_check.py` không có EU DSS validator. (4) Không có cuộc gọi mạng thật nào của `httpPost` / `httpGet`. (5) Khai báo an toàn dữ liệu của Google Play: có thêm các cuộc gọi tới máy chủ của CA khi người dùng bật ô này (không gửi dữ liệu cá nhân, chỉ số serial và băm của tên / khoá nhà phát hành).

### 4.52. Phiên 23 — tìm kiếm lịch sử bằng giọng nói (PDF I2, phiên bản gọn)

**Quyết định:** PDF I2 nói "điều khiển bằng giọng nói". Ngữ pháp lệnh ("quét", "mở lịch sử"...) vừa khó đúng ở 12 ngôn ngữ vừa ít dùng; phần có ích nhất và rủi ro thấp nhất là **nói để điền vào ô tìm kiếm lịch sử**. Nút micro (`btnHistoryVoice`, `ic_mic.xml`, mô tả "Tìm bằng giọng nói") nằm cạnh ô; bấm thì mở bộ nhận giọng nói CỦA HỆ THỐNG (`RecognizerIntent.ACTION_RECOGNIZE_SPEECH`, mô hình tự do, ngôn ngữ = ngôn ngữ hiện hành của app, lời nhắc `history_voice_prompt`); kết quả đầu tiên được điền vào ô, và `doAfterTextChanged` sẵn có tự lọc danh sách. Không có bộ phân tích lệnh nên không có gì để đối chứng bằng Java.

**Vì sao không xin `RECORD_AUDIO`:** `SpeechRecognizer` (API nhận giọng nói trong tiến trình app) đòi quyền này, còn `RecognizerIntent` chạy bộ nhận giọng của ứng dụng khác (thường Google) trong màn hình của nó, nên chính app không nghe micro. Nguồn đã tra là bài blog Android Developers 2015 viết cho Android TV; CHƯA xác nhận trên điện thoại. Không có `<queries>` trong manifest: app bắt `ActivityNotFoundException` rồi báo `history_voice_unavailable`, thay vì dò trước bằng `resolveActivity` (việc dò mới bị giới hạn khả năng nhìn thấy gói từ Android 11, còn khởi chạy intent ngầm thì không).

**Quyền riêng tư (cần chủ dự án quyết):** âm thanh do dịch vụ nhận giọng của HỆ THỐNG xử lý và có thể gửi lên máy chủ của hãng; app chỉ nhận chuỗi chữ. `help_privacy_body` (12 ngôn ngữ) hiện KHÔNG nhắc điều này. Nên thêm một câu ("tìm bằng giọng nói dùng bộ nhận giọng của hệ thống") và rà biểu mẫu An toàn dữ liệu của Google Play trước khi phát hành.

**Đã kiểm:** `i18n_check` (3 chuỗi `history_voice_*` x 12), `accessibility_check` (nút có mô tả), `night_theme_check` (tô màu bằng `text_primary`), `static_refs_check`, `kotlin_lint_check`, `tablet_layout_check` (đã sinh lại bản sw600dp). **CHƯA kiểm:** biên dịch; chạy trên máy (máy không có bộ nhận giọng thì thấy thông báo `history_voice_unavailable`); độ chính xác với tiếng Việt có dấu; cách bộ nhận giọng của hãng máy (Samsung, Xiaomi) phản hồi `EXTRA_LANGUAGE`.

### 4.53. Phiên 23 — kiểm kê lại danh mục PDF A1–N10 với MÃ THẬT, M8 / M9 tra cứu, và quyền mạng cục bộ của Android 17

**Câu hỏi của chủ dự án:** "Các kỹ thuật trong PDF đã áp dụng vào dự án hết chưa?" **Trả lời sau khi đối chiếu (134 mã A1–N10 ở các trang 40–59 của PDF):** mọi mục đã có trong mã HOẶC bị loại CÓ LÝ DO ghi trong tài liệu, trừ ba mục còn mở: **F4** (hàng đợi tác vụ), **I6** (phông dễ đọc), **M9** (Wi-Fi Direct); và **M8** (NFC) không làm được. Cách đối chiếu: danh sách "chưa có trong mã" của 4.49 + `grep` từ khoá đặc trưng cho từng mã + đọc lại 4.49.1–4.49.15 và "Còn lại sau phiên 22". Lưu ý: kiểm kê bằng từ khoá chỉ là gợi ý (nhiều mục làm dưới tên khác, ví dụ A8 là dò góc trong `FrameDocumentAnalyzer` / `ImageProcessor`, D7 là `AppLock.shouldLock` có thời gian chờ, D2 là `VaultStore` dùng AES + Android Keystore); nguồn quyết định là tài liệu từng phiên. **Chưa rà lại trong phiên này:** các trang 1–39 của PDF (cuộc trò chuyện về "thiếu gì để bán app": Play Console, chính sách, thanh toán, ASO) vì chủ yếu là việc ngoài mã, đã xử lý ở các mục 4.x đầu tiên.

| Nhóm | Tình trạng |
|---|---|
| A (ảnh), B (PDF), C (EPUB), D (bảo mật), E (quản lý), F1-F3 / F5-F7, G (tích hợp), H (AI / trích xuất), I1 / I3-I5, J (ngành), K, L, M1-M7, N1-N3 / N6-N10 | ĐÃ CÓ trong mã, hoặc loại có lý do (G2 / G3 / G7 / G9 và G5 / G6 / G10: lưu qua Storage Access Framework và hộp chia sẻ hệ thống thay cho SDK riêng; M1 / M5 chia sẻ liên kết cần máy chủ riêng; H7 / H8 / N1 trò chuyện với tài liệu cần dịch vụ AI ngoài) |
| C5 / C6 / C7 | ĐÃ LÀM ở phiên 23 (4.50) |
| I2 | ĐÃ LÀM bản gọn ở phiên 23 (4.52) |
| PAdES-LT (J4 mở rộng) | ĐÃ LÀM ở phiên 23 (4.51) |
| D6, N4, N5 | CỐ Ý KHÔNG làm (lý do ở "Còn lại sau phiên 22") |
| **F4** | CÒN MỞ: WorkManager 2.12.0 dùng được (4.51 / mục 6); chưa làm vì phần lớn là mã nối khó kiểm khi chưa biên dịch |
| **I6** | CÒN MỞ: cần tệp phông Lexend (OFL, có tiếng Việt) do chủ dự án đặt vào `res/font/` |
| **M8 NFC** | KHÔNG LÀM ĐƯỢC: Android Beam bị loại bỏ từ Android 10 và GỠ HẲN ở Android 14; "chạm để gửi" nay chạy qua hộp chia sẻ của Quick Share (không cần mã của ta) |
| **M9 Wi-Fi Direct** | KHÔNG LÀM: hộp chia sẻ hệ thống (`ACTION_SEND`) đã dẫn tới Quick Share; xem "phương án đã cân nhắc" dưới đây |

**Phương án đã cân nhắc cho M8 / M9 và vì sao loại:** máy chủ HTTP tạm trong app + mã QR (người nhận quét bằng bất kỳ điện thoại nào, kể cả iPhone). Kỹ thuật được (`ServerSocket`, ZXing đã có), nhưng: (1) nhận kết nối TCP đến thuộc diện cần quyền mạng cục bộ (mục dưới); (2) mở một cổng trên mạng của người dùng và truyền tài liệu bằng HTTP không mã hoá; (3) không hơn Quick Share ở trải nghiệm. Nếu sau này cần chia sẻ cho người không có Quick Share, đây là hướng làm: mã thông báo ngẫu nhiên trong đường dẫn, tải MỘT lần, hết hạn sau vài phút, chỉ bind địa chỉ Wi-Fi, và kiểm bằng `curl` (logic máy chủ thuần kiểm được bằng bản Java).

**Quyền mạng cục bộ của Android 17 (phát hiện mới, ảnh hưởng mã ĐÃ CÓ):** theo developer.android.com/privacy-and-security/local-network-permission, từ Android 17 mạng LAN bị chặn mặc định cho app NHẮM `targetSdk >= 37`: gọi ra TCP, NHẬN TCP đến, UDP đơn / nhóm / quảng bá đều cần quyền chạy `ACCESS_LOCAL_NETWORK` (thuộc nhóm NEARBY_DEVICES); thiếu quyền thì kết nối báo timeout / EPERM. App nhắm dưới 37 có `INTERNET` được cấp NGẦM tạm thời. Hiện `targetSdk 36` nên chưa ảnh hưởng, nhưng **quét qua Wi-Fi (eSCL, A6: `EsclDiscovery` dùng `NsdManager`, `EsclClient` gọi HTTP tới máy quét trong LAN) sẽ hỏng âm thầm khi nâng lên 37** nếu quên. Đường thay cho `NsdManager`: `DiscoveryRequest#FLAG_SHOW_PICKER` (người dùng chọn thiết bị bằng hộp chọn của hệ thống, không cần quyền) nếu máy quét cho phép. `tools/verify/local_network_check.py` canh điều này: `targetSdk < 37` -> đạt và liệt kê `EsclClient.kt`, `EsclDiscovery.kt`, `EsclProtocol.kt`; `targetSdk >= 37` -> đòi khai `ACCESS_LOCAL_NETWORK` trong manifest VÀ mã xin quyền lúc chạy. `--selftest` 9 ca đạt. **Chưa kiểm:** hành vi thật trên Android 17 (không có máy / emulator), và chưa xác định `NsdManager` của ta có tính là "ngoài tiến trình" (không bị ảnh hưởng theo trang tài liệu) hay không.

### 4.54. Phiên 23 — LẦN ĐẦU biên dịch thật (CI #21): một lỗi, và bộ kiểm chặn cả lớp lỗi đó

**Kết quả CI #21 (đây là lần đầu mã phiên 16 -> 23 được biên dịch bởi trình biên dịch thật):** các bước kho, giấy phép, đồng bộ tài liệu, lint Kotlin, JDK, SDK và 32 tác vụ Gradle trước `compileDebugKotlin` đều qua (kể cả `dataBindingGenBaseClassesDebug`, tức layout / ID mới của phiên 23 hợp lệ). `compileDebugKotlin` báo ĐÚNG MỘT lỗi: `PdfAutoLinks.kt:102:44 'internal' function exposes its 'private-in-class' parameter type 'Found'`.

**Nguyên nhân và sửa:** `PdfAutoLinks.overlaps(r, f: Found)` khai `internal` nhưng `Found` là `private class` lồng trong cùng đối tượng; Kotlin cấm hàm có phạm vi rộng hơn lộ kiểu có phạm vi hẹp hơn. Hàm chỉ được gọi trong chính đối tượng (dòng 86) và không có chỗ nào khác dùng (đã `grep`), nên đổi thành `private fun`. Mã này có từ phiên trước, KHÔNG phải mã phiên 23.

**Điều có thể và không thể rút ra:** trình biên dịch K2 báo tất cả lỗi giai đoạn phân tích trong một lần, nên việc chỉ có MỘT dòng `e:` cho thấy nhiều khả năng mã phiên 23 (`EpubNotes`, `EpubReaderActivity`, `EpubRowAdapter`, `Revocation`, `PdfLtv`, sửa `MainActivity`) không có lỗi phân tích. KHÔNG chắc: sau khi sửa lỗi này, giai đoạn sinh mã / dexing / đóng gói chưa chạy tới lần nào, nên vẫn có thể có lỗi mới; chạy lại Actions mới biết.

**`tools/verify/kotlin_exposure_check.py` (chặn cả lớp lỗi):** quét mọi `.kt`: tìm kiểu `private class|object|interface` rồi tìm thành viên / hàm cấp tệp KHÔNG private có tên kiểu đó trong chữ ký. Theo dõi khối `{}` để KHÔNG báo nhầm biến cục bộ trong hàm và thành viên của lớp private (lần chạy đầu ra 5 báo nhầm kiểu này, đều đã loại bằng việc theo dõi khối). `--selftest` 20 ca (tái hiện đúng lỗi #21, kiểu trả về, thuộc tính, companion object, lớp private, tham số lớp xuống dòng, lambda). Quét dự án: 0 lỗi sau khi sửa. **Giới hạn:** chỉ soi kiểu viết rõ trong chữ ký; kiểu SUY RA (`val x = HashMap<String, Item>()` ở thành viên của lớp công khai) chưa soi; kiểu private khai ở tệp khác không thể bị thấy nên không có trường hợp nào để soi. Gắn vào workflow, bước "Kotlin exposure check".

### 4.55. Phiên 23 — rà soát "chưa làm / chưa có giao diện / chưa nối dây" và gom nhóm màn hình chính

**Bối cảnh:** CI #22 build THÀNH CÔNG (sau khi sửa lỗi ở 4.54). Chủ dự án yêu cầu rà soát và gom nhóm vì màn hình chính lộn xộn.

**Phương pháp (đều chạy trên mã thật, không dựa vào tài liệu):** (1) lớp / đối tượng nào không tệp nào khác tham chiếu; (2) hàm có tên chỉ xuất hiện đúng 1 lần trong toàn dự án; (3) chuỗi trong `strings.xml` không được `R.string` / `@string` nào dùng; (4) id trong layout không được mã nào dùng; (5) Activity trong manifest không ai mở bằng `::class`; (6) đồ thị phụ thuộc từ các màn hình: tệp nào không với tới được.

**Kết quả:** (1) 210 khai báo cấp tệp, 7 "không ai tham chiếu" đều có lý do (gọi từ manifest hoặc layout XML, hoặc dùng trong cùng tệp) -> KHÔNG có lớp mồ côi. (2) 32 hàm, phần lớn là hàm gọi lại của Android; mã chết thật: `PdfImportHelper.getPageCount`, `DocumentImport.htmlTitle`, `PendingCropQueue.hasNext / remainingCount`, `ScanSessionManager.hasSavedSession`, `StampPlacementView.hasStamp`, `EpubRowAdapter.rowAt` (vô hại, để đó). Thiếu nối dây THẬT: `SignaturePadView.undoStroke` (chưa có nút hoàn tác), `PdfTextEditor.findMissingGlyphs` (chưa cảnh báo ký tự thiếu trong phông khi gõ; `applyEdit` vẫn kiểm lại trước khi ghi nên không hỏng dữ liệu). (3) 16 / 1 225 chuỗi không dùng; đáng kể nhất `permission_camera_denied` (xem dưới). (4) 377 id, không có nút chết (id dư là dòng chữ gợi ý tĩnh). (5) mọi Activity đều có đường mở. (6) 198 / 198 tệp với tới được.

**Đã sửa trong phiên:** `CaptureActivity`: từ chối quyền camera trước đây chỉ `finish()` IM LẶNG dù đã có chuỗi `permission_camera_denied`; nay hiện thông báo rồi đóng. Xoá hàm thừa `MainActivity.showOcrNote` (ghi chú "văn bản lấy từ OCR" thực ra ĐÃ nối dây qua chuỗi `text_from_ocr_note` ở 6 chỗ; ban đầu tôi phân loại nhầm là thiếu).

**Gom nhóm màn hình chính (`activity_main.xml`):** 28 thẻ xếp phẳng -> thẻ "Dự án quét sách" ở trên cùng (luồng riêng) + 27 công cụ độc lập chia 6 nhóm có tiêu đề (`tool_group_*`, 6 chuỗi x 12 ngôn ngữ):

| Nhóm | Thẻ |
|---|---|
| Quét & nhập (6) | Scan, Wifi, Link, Barcode, Snap, IdCard |
| Sắp xếp & ghép (5) | Merge, PageManager, Impose, Compress, Compare |
| Chỉnh sửa & chú thích (6) | TextEdit, Annotate, Markup, Form, Decorate, Searchable |
| Ký & bảo mật (4) | Sign, Redact, Security, Vault |
| Chuyển đổi & sách (3) | Convert, Ebook, Eink |
| Tiện ích (3) | Batch, Backup, Qr |

Chỉ sắp xếp lại khối XML và chèn tiêu đề: cùng tập 48 id (đã đối chiếu trước / sau), KHÔNG sửa dòng Kotlin nào (mã chỉ gắn sự kiện theo id; một chỗ ẩn / hiện thẻ Wi-Fi), bản `layout-sw600dp` sinh lại bằng `tablet_layout_check.py --write`. **CHƯA kiểm:** hình dạng thật trên máy (khoảng cách tiêu đề, máy tính bảng, chữ lớn); chưa có thu gọn / mở rộng từng nhóm (cần Kotlin).

**Vấn đề còn lại về khả năng tìm thấy (CHƯA làm):** 31 hành động chỉ nằm trong menu NHẤN GIỮ một tệp ở Lịch sử, người dùng rất khó tự khám phá: mọi tệp 4, có văn bản 5, PDF 12, EPUB 10. Hướng làm: chia menu thành các cụm có tiêu đề cùng 6 nhóm trên, hoặc một mục "Công cụ cho tệp này…" mở hộp có nhóm.

### 4.56. Phiên 23 — làm các mục "chưa làm" của 4.55: menu nhấn giữ chia nhóm, nút hoàn tác chữ ký, và các mục cố ý không làm

**Menu nhấn giữ một tệp ở Lịch sử (31 hành động) -> chia 5 nhóm:** tệp ít hành động (<= 8, ví dụ tệp .txt) vẫn hiện danh sách phẳng như cũ; tệp nhiều hành động hiện hộp chọn NHÓM trước (kèm số hành động), chọn nhóm xong mới ra các hành động của nhóm. 5 nhóm: Sắp xếp & đặt tên (4), Đọc & dịch (4), Chuyển đổi & xuất (8), Công cụ cho tài liệu (12), Trích xuất thông tin (3). KHÔNG sửa 31 dòng `actions.add` hiện có: nhóm được gán bằng bảng `HISTORY_ACTION_GROUPS` (khoá chuỗi -> nhóm) trong `MainActivity`, hiển thị bằng `showGroupedActions`. Hành động không có trong bảng rơi vào nhóm "Công cụ cho tài liệu". `tools/verify/history_menu_groups_check.py` (`--selftest` 6 ca) đòi: mọi hành động đều có nhóm, bảng không có mục chết, nhóm trong 0..4, đủ cả 5 nhóm, đủ chuỗi. 5 chuỗi `history_group_*` x 12 ngôn ngữ. Giới hạn: chọn nhóm xong không có nút "quay lại" (nhấn giữ lại tệp); thứ tự hành động trong nhóm theo thứ tự thêm trong mã.

**Nút "Hoàn tác" ở ô ký tay:** `SignaturePadView.undoStroke()` có từ lâu nhưng không có nút. Hộp thoại đã dùng hết 3 nút chuẩn (Xoá / Huỷ / Dùng) nên nút `sign_pad_undo` đặt trên khung ô vẽ (góc trên phải, cao tối thiểu 48dp). 1 chuỗi x 12 ngôn ngữ.

**Cố ý KHÔNG làm, và lý do:** (1) cảnh báo ký tự thiếu phông KHI GÕ (`PdfTextEditor.findMissingGlyphs`): hàm phân tích lại nội dung cả trang PDF mỗi lần gọi, gọi mỗi phím trên luồng giao diện dễ gây giật; hiện người dùng được báo `text_edit_missing_glyphs` (kèm danh sách ký tự) khi bấm OK và dữ liệu không hỏng, đủ dùng; nếu muốn làm thì phải trễ ~300 ms và chạy ngoài luồng chính. (2) F4 hàng đợi tác vụ (WorkManager): mã nối nhiều, kiểm được rất ít; làm khi chủ dự án xác nhận cần chạy nền khi app bị đóng (tác vụ hiện đã sống qua `KeepAlive`). (3) I6 phông Lexend: cần tệp `.ttf` do chủ dự án đặt vào `res/font/`. (4) Thu gọn / mở rộng từng nhóm ở màn hình chính: cần thêm Kotlin và trạng thái lưu, lợi ích nhỏ so với tiêu đề nhóm đã có.

**Đã kiểm:** `history_menu_groups_check` (31 hành động, nhóm [4, 4, 8, 12, 3]), `i18n_check`, `strings_check`, `accessibility_check`, `night_theme_check`, `kotlin_lint_check`, `kotlin_exposure_check`, `static_refs_check`, `base_activity_check`. **CHƯA kiểm:** biên dịch (CI chưa chạy lại sau các thay đổi này) và giao diện thật.

## 5. Quyết định kỹ thuật quan trọng & lý do (đọc để không hỏi lại/làm lại)

1. **Không commit Gradle Wrapper** (`gradlew`, `gradle-wrapper.jar`). Lý do: môi trường viết code
   này không có mạng để tải file `.jar` nhị phân thật, không thể tự "gõ" ra 1 file jar hợp lệ. Giải
   pháp: workflow CI dùng action `gradle/actions/setup-gradle@v4` (input `gradle-version: 8.9`) để
   tự cài Gradle, chạy trực tiếp bằng lệnh `gradle` (không phải `./gradlew`). Đã tra cứu xác nhận
   action này hỗ trợ đúng kịch bản "project không có wrapper". Nếu sau này có mạng ổn định, có thể
   đổi lại sang wrapper thật (`gradle wrapper --gradle-version 8.9` chạy 1 lần rồi commit).
2. **Không dùng thư viện PDF thật (iText/PDFBox/...)** cho merge/split/rotate/page-manager. Lý do:
   giảm rủi ro sai tên artifact/API mà không ai kiểm tra được (không build được ngay lúc viết code)
   — chỉ dùng 2 API framework Android chắc chắn có sẵn (`PdfRenderer`, `PdfDocument`). Đánh đổi đã
   nêu ở mục 2. Nếu sau này người dùng cần giữ được chữ thật (không rasterize), cần đổi hướng này —
   `com.tom-roush:pdfbox-android` là ứng viên hay được dùng nhưng **CHƯA được tra cứu/xác minh** cho
   dự án này. **[CẬP NHẬT phiên 11: phần "đổi hướng" này đã xảy ra cho nhóm tính năng (b) ở mục 2 — PdfBox-Android 2.0.27.0 được dùng
   cho nén "Sửa trực tiếp", sửa chữ, PDF tìm kiếm được, mật khẩu/watermark; riêng merge/split/rotate/page-manager vẫn rasterize như
   quyết định gốc này. Lý do chọn PdfBox: Apache 2.0, bán trả phí được — mục 4.18.]**
3. **OpenCV**: xác nhận qua tra cứu web (không đoán từ trí nhớ) rằng `org.opencv:opencv:5.0.0.1` là
   artifact chính thức trên Maven Central, khởi tạo bằng `OpenCVLoader.initLocal()` (API mới của
   nhánh 5.0, KHÔNG phải `initDebug()`/`initAsync()` của các hướng dẫn cũ trên mạng — dùng nhầm API
   cũ vẫn compile được nhưng dùng sai best-practice hiện tại). Chỉ dùng module `core`/`imgproc`/
   `android` (Utils) — các module `ml`, `objdetect` (Haar/HOG), `gapi`, `face` đã bị tách sang gói
   "Pro"/contrib riêng, KHÔNG có trong AAR miễn phí, nên code cố tình không đụng tới các API đó.
   **(Phiên 15) Cạm bẫy OpenCV 5 — viết theo API OpenCV 4 là KHÔNG biên dịch:** các hàm hình học đã chuyển khỏi `Imgproc` sang `org.opencv.geometry.Geometry`
   (`contourArea`, `arcLength`, `approxPolyDP`, `getPerspectiveTransform`, `getRotationMatrix2D`, và `convexHull`, `convexityDefects`, `isContourConvex`, `minEnclosingCircle`,
   `minEnclosingTriangle`, `minAreaRect`, `fitEllipse`, `Subdiv2D`); `calib3d` tách thành `geometry` + `calib` + …; `features2d` đổi tên `features`. Vẫn nằm ở `Imgproc`:
   `cvtColor`, `resize`, `warpAffine`, `warpPerspective`, `findContours`, `threshold`, `adaptiveThreshold`, `morphologyEx`, `connectedComponentsWithStats`, `remap`… (trình biên dịch
   không phàn nàn các hàm này ở run #15). Nguồn: wiki "OpenCV 4 to 5 migration", docs.opencv.org/5.0 (`geometry_shape`). Quyết định: GIỮ OpenCV 5.0.0.1, sửa lời gọi — không lùi về 4.x.
4. **ML Kit dùng bản bundled** (`com.google.mlkit:text-recognition`), không dùng bản
   `com.google.android.gms:play-services-mlkit-text-recognition` (bản unbundled cần tải model lần
   đầu qua Play Services, có thể lỗi nếu máy không có Play Services hoặc không có mạng lúc đó).
5. **Icon app**: dựng bằng script Python/PIL (chạy 1 lần lúc build project, KHÔNG có trong repo),
   xuất thẳng ra PNG ở cả 5 mật độ màn hình, KHÔNG dùng adaptive-icon XML — vì `minSdk=24` vẫn cần
   icon PNG thường cho API 24-25 (adaptive icon chỉ từ API 26), nên dùng PNG thường cho mọi API luôn
   cho đơn giản, chấp nhận mất hiệu ứng "adaptive shape" trên máy mới (thuần thẩm mỹ, không phải lỗi
   chức năng).
6. **Tránh mọi style resource Material3 không chắc chắn tồn tại** (vd.
   `Widget.Material3.Chip.Filter`, `Widget.Material3.Button.OutlinedButton/TonalButton`) — vì
   tham chiếu 1 style không tồn tại làm lỗi AAPT (link resource), hỏng cả build, mà không ai kiểm
   tra được lúc viết code. Giải pháp: Chip dùng mặc định (`android:checkable="true"`, không set
   `style=`), nút phụ dùng `MaterialButton` mặc định + `backgroundTint`/`textColor` thủ công thay vì
   named style.
7. **`ChipGroup.setOnCheckedChangeListener` (bản cũ, 1 checkedId)** được chọn thay vì
   `setOnCheckedStateChangeListener` (bản mới, `List<Int>`) — đã tra cứu tận source code Material
   Components (bản 1.14.0) xác nhận API cũ tuy `@Deprecated` nhưng vẫn tồn tại thật (chỉ delegate
   sang API mới bên trong) → chắc chắn compile được, an toàn hơn là đoán chữ ký API mới.
8. **`activity_main.xml` dùng `<ScrollView>` thường**, không dùng `CoordinatorLayout` +
   `NestedScrollView` như bản nháp đầu — để không phụ thuộc ngầm vào `androidx.coordinatorlayout`
   (dù nhiều khả năng có sẵn qua Material lib, dùng ScrollView thường loại bỏ hẳn nghi ngờ này).
9. **Không dùng database (Room/SQLite)** cho phiên quét hiện tại — `ScanSessionManager` in-memory
   là đủ vì 1 phiên quét ngắn hạn. Lịch sử các PDF đã xuất thì đọc thẳng từ thư mục
   `Documents/` (liệt kê file), không có bảng riêng.
10. **[Phiên bản hiện hành: xem bảng ở mục 2 — AGP 8.13.0, Kotlin 2.2.10, Gradle 8.13, compileSdk/targetSdk 36 (Google Play bắt buộc
    targetSdk 36 từ 31/8/2026); các số cũ ghi tiếp theo đây (AGP 8.5.2, Kotlin 2.0.20, Gradle 8.9, targetSdk 34) là LỊCH SỬ của quyết định gốc.]**
    Mọi phiên bản thư viện lúc đó (AGP 8.5.2, Kotlin 2.0.20, Gradle 8.9, compileSdk/targetSdk 34, minSdk
    24, CameraX 1.4.1, coroutines 1.8.1...) được chọn vì là **bản chắc chắn đã tồn tại từ trước mốc
    kiến thức của Claude (khoảng đầu 2026)** — chọn kiểu này để dù có "phiên bản mới nhất" khác vào
    thời điểm build thật, các phiên bản cũ hơn vẫn luôn resolve được từ Maven Central (kho artifact
    không xoá bản cũ). Không cố tình dùng bản "mới nhất" vì không kiểm chứng được.
11. **EPUB tự viết bằng `java.util.zip`, không dùng thư viện ebook ngoài nào** — cùng triết lý với
    quyết định 2 (không PDF library ngoài): EPUB về bản chất chỉ là 1 file ZIP có cấu trúc XML quy
    định rõ ràng, hoàn toàn dựng được bằng `ZipOutputStream`/`ZipEntry` có sẵn trong JDK. Đã tra cứu
    xác nhận Amazon ngừng nhận MOBI từ 18/3/2025 và Kindle nhận EPUB thẳng qua Send-to-Kindle từ
    2022 → cố tình KHÔNG làm MOBI/AZW3 (định dạng nhị phân độc quyền phức tạp, không cách nào kiểm
    chứng đúng/sai khi không build-test được, và giờ cũng không còn cần thiết).
12. **`isColorPage`/`detectGutterX` chỉ dùng để GỢI Ý, không bao giờ tự áp dụng mà không cho chỉnh
    tay** — cả 2 heuristic OpenCV đều chưa test với ảnh thật (xem mục 6), nên mọi nơi dùng chúng đều
    thiết kế sao cho đoán sai vẫn không gây hại: `isColorPage` chỉ chọn sẵn 1 chip lọc (đổi được),
    `detectGutterX` chỉ đặt vị trí khởi tạo cho đường kéo-thả (kéo lại được). Đây là nguyên tắc
    chung nên giữ cho MỌI heuristic thêm sau này trong dự án.
13. **Tách 2 trang luôn chuyển `CropActivity` sang `queueMode = true`, kể cả khi bắt đầu từ camera
    (single mode)** — vì tách 1 ảnh ra 2 trang nghĩa là chắc chắn còn nhiều hơn 1 trang cần xử lý
    tiếp; cách đơn giản và ít rủi ro nhất là từ lúc đó luôn kết thúc bằng cách vào thẳng
    `PageListActivity` thay vì cố giữ hành vi "quay lại xem trước camera" của single mode — tránh
    phải theo dõi trạng thái phức tạp (đã cân nhắc & bỏ, xem mục 8).
14. **`PdfCompressor` tự viết PDF ở mức byte thô (`PdfByteWriter`), không dùng `PdfDocument`** —
    khác với MỌI tính năng PDF khác trong app (`PdfExporter` vẫn dùng `PdfDocument` bình thường).
    Lý do riêng cho tính năng này: đã tra cứu xác nhận `PdfDocument` (qua Skia PDF backend) không
    hề nén ảnh đưa vào — lưu gần như nguyên trạng trừ khi cắm JPEG encoder qua API Skia cấp thấp mà
    Android không lộ ra công khai. Một tính năng cam kết tỉ lệ nén cụ thể mà không kiểm soát được
    cách ảnh được lưu vào PDF thì vô nghĩa, nên bắt buộc phải tự viết object/xref PDF thay vì dùng
    `PdfDocument`.
15. **Kỹ thuật xác nhận thuật toán phức tạp khi không có môi trường build/test thật: viết bằng
    Python trước, đối chiếu với 1 thư viện đáng tin cậy đã có sẵn, rồi mới chuyển sang Kotlin** —
    áp dụng cho CCITT Group 4 (mục 4.11): viết encoder/decoder bằng Python, đối chiếu byte-for-byte
    với libtiff (qua Pillow) trên hàng chục mẫu ảnh, CHỈ SAU KHI khớp 100% mới chuyển bảng mã (sinh
    tự động bằng script, không gõ tay lại) và logic thuật toán (chuyển tay, rà soát kỹ) sang Kotlin.
    Đây là kỹ thuật NÊN DÙNG LẠI cho bất kỳ thuật toán/định dạng nhị phân phức tạp nào cần thêm vào
    dự án sau này, thay vì viết thẳng bằng Kotlin rồi hy vọng đúng.
16. **Khi phải dựa vào hành vi KHÔNG được tài liệu hoá công khai (vd. cấu trúc byte thật của file
    `PdfDocument` ghi ra) mà không có cách nào kiểm chứng trước (khác CCITT G4 — không có "libtiff"
    nào để đối chiếu cho trường hợp này): viết code thử làm việc đó, nhưng LUÔN bọc trong try/catch
    trả về `null`/rỗng ở BẤT KỲ bước nào không đúng như kỳ vọng, và nơi gọi PHẢI coi kết quả đó là
    "best-effort, có thể không xảy ra" chứ không phải "chắc chắn có" — không bao giờ để 1 giả định
    chưa kiểm chứng được có khả năng làm hỏng kết quả chính (ở đây: file PDF vẫn hợp lệ dù có hay
    không có bookmark). Áp dụng cho `PdfBookmarkInjector` (mục 4.12).
17. **`PdfImportHelper.renderAllPagesToFiles()` nhận thêm tham số `fileFactory` thay vì tách hàm
    riêng cho từng nơi gọi** — mặc định `null` giữ nguyên hành vi cũ (ghi vào cache qua
    `FileUtils.newImportedFile`), nơi nào cần bền thì tự truyền vào 1 lambda trỏ sang thư mục
    `filesDir` riêng của mình (mục 4.14). Chọn cách này thay vì viết 1 hàm
    `renderAllPagesToFilesDurable()` riêng để tránh trùng lặp gần như toàn bộ logic render/đóng
    `PdfRenderer` giữa 2 hàm — rủi ro thấp vì tham số có giá trị mặc định, mọi nơi gọi cũ không cần
    sửa gì vẫn chạy y hệt trước.
18. **Mỗi màn hình có backup/restore riêng (`PdfEditorState`/`EbookEditorState`/`PdfMergeState`),
    không dồn chung 1 object hay 1 hộp thoại ở `MainActivity`** — dù hơi lặp code JSON đọc/ghi so
    với gộp chung, nhưng dữ liệu cần lưu khác hẳn nhau giữa 3 màn hình và việc hỏi-khôi-phục đặt
    ngay trong `onCreate` của từng Activity liên quan tránh phải tự xếp thứ tự ưu tiên khi có nhiều
    phiên dở cùng lúc (mục 4.14).
19. **`EbookEditorState` không lưu văn bản OCR, chỉ lưu đánh dấu chương + đường dẫn trang** — vì
    OCR lại rẻ (offline, vài chục trang), lưu lại text sẽ tốn dung lượng JSON không cần thiết; khi
    khôi phục thì OCR lại rồi khớp theo đường dẫn để áp lại đánh dấu cũ (mục 4.14).
20. **`EbookEditorState.clear()` chỉ xoá file nằm trong đúng thư mục nó sở hữu
    (`ebookImportDir()`), không xoá mọi đường dẫn có trong state JSON** — vì trang nguồn của ebook
    có thể đến từ `ScanSessionManager` (thuộc phiên quét, do manager khác quản lý vòng đời) thay vì
    từ PDF nhập riêng; xoá không phân biệt nguồn sẽ có nguy cơ phá phiên quét đang hoạt động của
    manager kia (mục 4.14). Nguyên tắc chung nên áp dụng cho bất kỳ tính năng dọn-file nào thêm sau
    này có khả năng đụng tới file do nơi khác sở hữu: luôn kiểm tra quyền sở hữu trước khi xoá, chứ
    không suy luận từ việc "đường dẫn có xuất hiện trong state của mình".
21. **`PdfCompressor.compress()` tự viết object Outline (mục lục PDF) thẳng bằng `PdfByteWriter`,
    KHÔNG dùng lại `PdfBookmarkInjector`** — dù cả 2 đều là "thêm bookmark vào PDF", chúng ghi vào 2
    loại PDF khác nguồn: `PdfBookmarkInjector` viết riêng để vá PDF do `android.graphics.pdf.
    PdfDocument` xuất ra (byte-patching, vì lớp đó không có API bookmark - mục 4.12), còn
    `PdfCompressor` tự ghi toàn bộ PDF bằng `PdfByteWriter` nên ĐÃ BIẾT TRƯỚC số hiệu object của mọi
    trang → ghi object Outline cùng lúc, trỏ thẳng tới đúng object trang, không cần "vá" gì cả, an
    toàn hơn hẳn cách vá byte hậu kỳ (mục 4.15).
22. **`ProjectManager` (thuần dữ liệu) và `ProjectFlow` (điều hướng UI) tách làm 2 file, 2 package
    khác nhau, dù cùng phục vụ 1 tính năng** — theo đúng nguyên tắc đã có sẵn trong dự án: mọi file
    trong `model/` không được biết tới Activity nào cả (không file `model/` nào import 1 class
    Activity, trước giờ luôn vậy). `ProjectManager` (trong `model/`) chỉ lo đọc/ghi JSON; việc
    "stage nào mở Activity nào" là quyết định thuộc tầng UI, đặt ở `ProjectFlow.kt` (package gốc,
    ngang hàng với các Activity) (mục 4.15).
23. **Tách `PageListActivity`'s `BulkPreset`/`einkTextResult`/`einkColorResult` ra `util/
    ScanPresetApplier.kt`, sửa `PageListActivity` gọi lại object mới** — để `ProjectScanActivity`
    (bước 4 của Dự án) áp dụng ĐÚNG cùng 1 logic thay vì chép lại thành 2 bản dễ lệch nhau khi sửa
    sau này. Đã kiểm tra kỹ để hành vi công cụ "Lọc hàng loạt" gốc không đổi (mục 4.15).
24. **`ProjectEbookActivity` dùng lại NGUYÊN `activity_ebook_editor.xml`/
    `ActivityEbookEditorBinding`/`EbookPageAdapter` của `EbookExportActivity` thay vì tạo layout
    mới** — ViewBinding sinh ra theo TỪNG FILE layout, không buộc 1 layout chỉ được 1 Activity dùng;
    2 Activity khác nhau gọi `ActivityEbookEditorBinding.inflate(...)` là hợp lệ. Tiết kiệm hẳn 1
    layout gần như trùng lặp 100% (cùng cần: ô tên sách, 2 checkbox định dạng, list trang đánh dấu
    chương, nút xuất) (mục 4.15).
25. **`FileUtils.openFile()`/`shareFile()` mới được thêm để `ProjectSummaryActivity` dùng, KHÔNG
    sửa `MainActivity.shareFile()` gốc để gọi lại hàm chung** — dù hơi trùng lặp code, tránh đụng
    vào 1 Activity đã hoạt động ổn định (`MainActivity`) chỉ để đổi cách gọi nội bộ, rủi ro không
    đáng với lợi ích nhỏ thu được. `MainActivity.openTextResult()` KHÔNG được tái dùng cho
    `ProjectSummaryActivity` vì bản chất khác hẳn: hàm đó mở file `.txt` OCR ĐI KÈM 1 PDF, không
    phải mở chính file đó bằng app xem tương ứng - 2 hành vi khác nhau, dùng nhầm sẽ sai (mục 4.15).
26. **Thẻ "Dự án" được đặt vị trí ĐẦU TIÊN và mang kiểu highlight mà trước đây thuộc về thẻ "Quét";
    thẻ "Quét" bị hạ xuống thành thẻ thường, thêm dòng tiêu đề "Hoặc dùng riêng từng công cụ" phía
    trên các công cụ độc lập** — phản ánh đúng yêu cầu: quy trình Dự án giờ là con đường chính,
    trong khi "Quét" và mọi công cụ khác VẪN giữ nguyên 100% chức năng, chỉ đổi vị trí/kiểu hiển thị
    để phân biệt "luồng đầy đủ" với "công cụ dùng nhanh 1 việc" (mục 4.15).

## 6. Việc CÒN TỒN ĐỌNG / cố ý bỏ qua (làm tiếp từ đây)

### Còn lại sau phiên 23 (mỗi mục kèm lý do và hướng làm)

0. **Biên dịch mã phiên 16 -> 23 (ƯU TIÊN SỐ 1).** Phiên 23 thêm `EpubNotes.kt`, `EpubReaderActivity.kt`, `adapter/EpubRowAdapter.kt`, 3 tệp tài nguyên, 1 `<activity>`, sửa `MainActivity` (một dòng trong menu EPUB). Lưu ý: `.github/workflows/android-build.yml` trong kho của chủ dự án (bản tải lên phiên này) KHÔNG có bước "Kotlin lexical lint" mà bản trong gói zip có - nên đồng bộ hai bản.
1. **Đã làm ở phiên 23:** C5 (đọc EPUB), C6 (tô sáng / dấu trang), nối C7 với màn đọc (4.50).
2. **Còn làm được, chưa làm:**
   - **F4 hàng đợi tác vụ:** PDF gợi ý WorkManager (bản ổn định 2.12.0 ngày 23/09/2026, minSdk 23, giấy phép Apache 2.0; GitHub Actions có mạng nên giải phụ thuộc được - lý do "không có mạng" chỉ đúng với môi trường của trợ lý). CHƯA làm vì phần lớn là mã nối (Worker, thông báo tiền cảnh, lưu tham số) không kiểm được nếu chưa biên dịch; mật khẩu / chữ watermark KHÔNG được đưa vào dữ liệu của WorkManager (lưu rõ trong cơ sở dữ liệu) nên thao tác "đặt mật khẩu" phải ở lại luồng hiện tại. Các tác vụ nặng hiện đã chạy qua `KeepAlive` (4.38). Hướng làm: hàng đợi tuần tự trong `KeepAlive` cho các thao tác dài (OCR, nén, xử lý hàng loạt) rồi mới cân nhắc WorkManager nếu cần sống sót khi app bị đóng.
   - **I2 điều khiển bằng giọng nói: ĐÃ LÀM bản gọn ở 4.52** (nút micro điền vào ô tìm kiếm lịch sử, qua `RecognizerIntent`, không xin quyền micro). Chưa làm: ngữ pháp lệnh điều khiển cả app (quét, mở lịch sử...), vì khó đúng ở 12 ngôn ngữ và ít dùng; nếu làm, phần phân tích lệnh thuần kiểm được bằng Java như các mục khác.
   - **I6 phông dễ đọc (OpenDyslexic):** giấy phép OFL cho đóng gói, nhưng cần TỆP phông (môi trường này không tải được); khi có tệp: `res/font/` + công tắc trong `FontScale`.
   - **(Cập nhật phiên 23, 4.53)** M8: Android Beam đã GỠ HẲN ở Android 14 - không làm được. M9: loại, có phương án máy chủ HTTP + QR đã cân nhắc nhưng chưa nên làm. **Trước khi nâng `targetSdk` lên 37:** khai và xin `ACCESS_LOCAL_NETWORK` cho eSCL (`local_network_check.py` sẽ báo đỏ nếu quên).
   - **M9 Wi-Fi Direct, M8 NFC (ghi chú phiên trước):** M8 dựa trên Android Beam đã bị gỡ khỏi Android (PDF ghi "deprecated", độ khả thi "Thấp") - KHÔNG làm. M9 (`WifiP2pManager`) cần quyền vị trí / `NEARBY_WIFI_DEVICES` và hai máy thật để thử; chia sẻ qua hộp chia sẻ hệ thống (Quick Share) đã thay được.
   - **PAdES-LT: ĐÃ LÀM ở 4.51** (còn thử với CA thật, Acrobat, PAdES-B-LTA). **Băm dữ liệu OCR tiếng Nga: CÔNG CỤ ĐÃ LÀM, CHƯA CÓ GIÁ TRỊ.** Con số tìm được trên mạng là băm của GÓI phân phối chứ không phải của `rus.traineddata` nên KHÔNG dùng. Job `tessdata` mới trong `android-build.yml` (`continue-on-error`, không bao giờ làm đỏ bản build) chạy `tools/verify/tessdata_pin_check.py`: đọc URL, khung kích thước và `EXPECTED_SHA256` từ chính `TesseractOcr.kt`, tải tệp, kiểm khung rồi so băm; khi hằng còn trống nó in đúng dòng cần dán (cả trong Job summary). VIỆC CỦA CHỦ DỰ ÁN: sau lần chạy Actions đầu, mở job `tessdata`, chép dòng `private const val EXPECTED_SHA256 = "..."` vào `TesseractOcr.kt`; từ đó mọi lần chạy so băm (tệp ở nhánh `main` của tessdata_fast đổi thì job báo đỏ, và app từ chối tệp khác băm). **Người bản ngữ rà bản dịch:** giữ nguyên.
3. **Cố ý KHÔNG làm (giữ nguyên lý do ở "Còn lại sau phiên 22"):** D6, N4, N5.

### Còn lại sau phiên 22 (mỗi mục kèm lý do và hướng làm - KHÔNG phải "giới hạn" bỏ ngỏ)

0. **Biên dịch mã phiên 16 → 22 (ƯU TIÊN SỐ 1).** Phiên 22 thêm rất nhiều mã Kotlin chưa từng được biên dịch (xem điểm nghi ngờ ở từng mục 4.49.x; `kotlin_lint_check.py` + `static_refs_check.py` chỉ bắt lớp lỗi từ vựng / tham chiếu). Chạy Actions, sửa lỗi biên dịch nếu có. **Thứ tự nên thử trên máy thật:** ZIP AES mở bằng 7-Zip / WinRAR / Keka (4.49.1); nhập `.p12` thật của nhà cung cấp chứng thư, kể cả mật khẩu có dấu (4.49.8); chữ ký có dấu hiển thị trong Acrobat (4.49.10); camera HDR / đêm và chụp liên tiếp (4.49.14, 4.49.7); dịch ảnh chụp (4.49.15, kiểm ảnh xoay EXIF).
1. **Đã làm trong phiên 22 (mục 4.49.1 – 4.49.15):** nén ZIP + mật khẩu AES-256 (E6, L13, M2, M4); xuất JSON / XML / Base64 (L11, L12, L15); tự khoá chọn được thời gian (D7); nhập từ liên kết / clipboard (L7, L6); tìm trong EPUB (C7); widget Quét nhanh (K1); chụp liên tiếp (A5); ký số bằng `.p12` có chuỗi + ECDSA + bộ đọc dự phòng cho OpenSSL 3 (3.x); dấu hiển thị cho chữ ký số; thư mục phân cấp ảo từ thẻ (E8, E9); webhook (F7) và cách dùng Tasker (F6); cỡ chữ trong app + chữ AAA (I4, I3); chế độ ảnh HDR / đêm (K6); dịch một bức ảnh (N10, dạng một ảnh). K5 (in) KHÔNG cần làm: đã có từ 4.22 (`PrintManager` + `PdfPrintAdapter`); mục tôi từng ghi "dịch vụ in" nhầm với `PrintService` (viết dịch vụ in cho nhà sản xuất máy in, không liên quan).
2. **Cố ý KHÔNG làm, kèm lý do để không hỏi lại:**
   - **D6 mật khẩu ép buộc (duress):** khoá app dùng thông tin xác thực của chính điện thoại (BiometricPrompt, 4.x), app không có mã PIN riêng nên không có "mã PIN thứ hai"; thêm mã PIN riêng chỉ để có chức năng này là thêm bề mặt tấn công, và hành vi "mã lạ thì XOÁ tài liệu" mất dữ liệu không khôi phục được, có thể gây hại cho chính người dùng (bấm nhầm mã). Nếu cần giấu: két (`VaultStore`) đã có.
   - **N5 công thức → LaTeX:** ML Kit không có; mô hình nguồn mở (pix2tex, TrOCR-math) nặng hàng chục đến hàng trăm MB và cần thêm bộ chạy (ONNX / TFLite), không phù hợp bản phát hành hiện tại. Đường thay: chụp -> OCR văn bản, công thức dán tay.
   - **N4 chữ viết tay:** ML Kit Text Recognition v2 là bộ đọc chữ IN; "Digital Ink Recognition" của ML Kit chỉ đọc nét viết trên màn hình cảm ứng, không đọc chữ viết tay trong ảnh. Không có mô hình miễn phí chạy trên máy cho ảnh chữ viết tay; chữ viết tay rõ ràng đôi khi vẫn đọc được bằng OCR hiện có.
3. **Còn làm được, chưa làm (lớn, nên làm SAU khi bản build xanh để thử được):**
   - **C5 / C6 trình đọc EPUB trong app + đánh dấu / chú thích:** màn đọc (danh sách đoạn, cỡ chữ, nhảy tới kết quả của 4.49.5, đánh dấu trang, tô sáng bằng chọn chữ) gần như toàn giao diện không kiểm được ở đây; phần logic thuần (gộp khoảng tô sáng) sẽ có bản Java + đối chứng như các mục khác.
   - **OCSP / CRL (chữ ký hợp lệ dài hạn, PAdES-LT):** cần dựng yêu cầu OCSP bằng tay, gọi máy chủ CA (thường `http`), rồi ghi thêm một bản cập nhật tăng dần chứa từ điển `/DSS` SAU chữ ký; phần OCSP có thể kiểm bằng `openssl ocsp` cục bộ, nhưng phần ghi `/DSS` cần PDFBox 2.0 thật. Chỉ có ý nghĩa cho chứng thư `.p12` của CA (chứng thư tự ký không có OCSP).
   - **Mã băm cho dữ liệu OCR tiếng Nga (4.45):** chưa tra được giá trị SHA-256 ở môi trường không tải được tệp; hướng làm: ghim URL theo mã commit của `tessdata_fast` (URL bất biến) hoặc tính băm khi đã tải lần đầu rồi so ở các lần sau.
   - **Người bản ngữ rà bản dịch 12 ngôn ngữ** (nhiều chuỗi mới ở phiên 22).

### Còn lại sau phiên 21 (mỗi mục kèm hướng làm - KHÔNG phải "giới hạn")

0. **Biên dịch mã phiên 16 → 21 (ƯU TIÊN SỐ 1)**, nay thêm sửa nhỏ `AppLanguages.kt` (`stripScript`); chạy Actions, sửa lỗi biên dịch nếu có, rồi mới làm tiếp.
1. **OCR tiếng Nga / Cyrillic: ĐÃ LÀM ở phiên 21 (4.48.8 (9)), cần kiểm chứng bằng Actions + máy thật:** biên dịch; tải `rus.traineddata`, điền `EXPECTED_SHA256`; đọc 20 trang mẫu tiếng Nga in rõ và so với văn bản gốc (tỉ lệ từ khớp). Mở rộng Cyrillic sang các chỗ OCR khác (tự tìm thông tin để che, dò mục lục, ebook) là việc sau khi độ chính xác đạt.
2. **Người bản ngữ rà 10 ngôn ngữ mới** (es, pt-BR, fr, de, id, ko, zh-CN, hi, ru + ja có sẵn) và xem trên máy các hộp thoại dày chữ: tiếng Đức / Pháp / Nga dài hơn tiếng Anh 10-25 %, tiếng Hindi cao dòng hơn.
3. Các mục còn lại của "Còn lại sau phiên 20" bên dưới (trừ mục 3 "Thêm ngôn ngữ" đã xong).

### Còn lại sau phiên 20 (mỗi mục kèm hướng làm - KHÔNG phải "giới hạn")

0. **Biên dịch mã phiên 16 → 20 (ƯU TIÊN SỐ 1).** Phiên 20 thêm `PdfSignatureProbe.kt`, `SignedPdfGuard.kt`, `OfficeImport.kt`, `RtfImport.kt`, `DocInsight.kt`, `BackupSchedule.kt`, `AutoBackup.kt` (+ `AutoBackupJobService`), sửa `TablePdfBuilder.kt` (tách `drawSheet`), `EsclProtocol.kt`, `WifiScanActivity.kt`, `ConvertDocumentActivity.kt`, `MainActivity.kt` (9 chỗ gọi `SignedPdfGuard`, `showDocInsight`, `showAutoBackupDialog`), 8 Activity (guard), `AndroidManifest.xml` (quyền `RECEIVE_BOOT_COMPLETED`, dịch vụ job). Điểm nghi ngờ biên dịch: lambda có `return` lồng trong `OfficeImport` (`scanXml` + `object : XmlHandler`), `class Ref` cục bộ trong `sheetsFromXlsx`, `compareBy` nhiều bộ chọn trong `DocInsight`, `registerForActivityResult(OpenDocumentTree())` khai báo cùng nhóm launcher, `JobInfo.isPeriodic` / `intervalMillis`.
1. **Dấu thời gian RFC 3161: ĐÃ LÀM ở 4.48.6.** Còn lại: thử với một TSA công cộng thật (môi trường kiểm thử không có mạng), xem lại chính sách quyền riêng tư / khai báo an toàn dữ liệu của Google Play (có một cuộc gọi mạng mới khi người dùng nhập địa chỉ TSA), và nếu cần PAdES-LTA (lưu OCSP / CRL) — không làm.
2. **Tô sáng bằng lớp chữ thật: ĐÃ LÀM ở 4.48.7.** Còn lại: chạy trên máy thật (PdfBox `TextPosition`), trang xoay, chữ dọc / phải-sang-trái.
3. **Thêm ngôn ngữ (6.4 cũ): ĐÃ XONG ở phiên 21 (4.48.8)** — 12 ngôn ngữ; còn lại: người bản ngữ rà (xem "Còn lại sau phiên 21" mục 2).
4. **Những mục nhỏ còn sót của phiên 20:** (`SignedPdfGuard` cho xử lý hàng loạt `runBatch`: ĐÃ LÀM ở phiên 21, xem 4.48.8 (10)); thử `AutoBackup` / eSCL hai mặt / xoay mặt sau trên máy thật; mở rộng bảng cụm từ của `DocInsight` bằng tài liệu thật của người dùng (đã nói rõ ở 4.48.3: các tỉ lệ đúng là trên 43 văn bản viết tay).
5. Phần còn lại của "Còn lại sau phiên 19" mục 0, 6 (chứng thư từ `.p12`: ĐÃ LÀM ở 4.49.8; dấu hiển thị cho chữ ký số: ĐÃ LÀM ở 4.49.10), 7 (két xác thực mỗi lần, khung đọc máy tính bảng), 8: giữ nguyên bên dưới.

### Còn lại sau phiên 19 (mỗi mục kèm hướng làm - KHÔNG phải "giới hạn"; hướng ghi từ hiểu biết sẵn, chưa tra lại bằng tìm kiếm web trong phiên này, nên kiểm lại API khi bắt tay làm)

0. **Biên dịch mã phiên 16 → 19 (ƯU TIÊN SỐ 1).** Phiên 19 thêm `DocumentImport.kt`, `TablePdfBuilder.kt`, `PdfPoster.kt`, `TiffWriter.kt`, sửa `PdfBookmarks.kt`, `PdfBookmarkActivity.kt`, `ConvertDocumentActivity.kt`, `MainActivity.kt` (menu poster), `PdfPageBitmap.kt`, `TextPdfBuilder.kt` (`wrapText` thành `internal`). Điểm nghi ngờ biên dịch riêng của phiên này: lambda `use` lồng nhau trong `convertPdfToTiff`; `ESCAPED.replace` với `.code` / `toChar()` ở `DocumentImport.mdInline`; `Math.ceil` trên `Double` ở `PdfPoster.plan`; destructuring `for ((cx, dx) in listOf(l to -1f, r to 1f))`. Đã xong ở phiên 19 trong số mục cũ: **6.5 di chuyển / đổi cấp mục lục** (4.47.1).
1. **Nhập thêm định dạng:** ODT, PPTX, XLSX (cũng là ZIP + XML: dùng đúng cách `blocksFromDocx` với `content.xml` / `ppt/slides/slideN.xml` / `xl/sharedStrings.xml` + `sheetN.xml`), RTF (cần bộ đọc nhóm `{\...}` riêng; tham chiếu độc lập: `pandoc -f rtf`), URL (cần quyền INTERNET - xem 4.31 I). Kiểm bằng cùng cách `doc_import_check.py` (python-pptx / openpyxl tạo tệp, pandoc đọc).
2. **Trí tuệ tài liệu từ văn bản OCR (PDF mục H1, H3, H6):** phân loại loại tài liệu (hoá đơn / hợp đồng / CCCD / biên lai ...) bằng điểm từ khoá có trọng số, gợi ý thẻ bằng TF-IDF trên kho tài liệu của người dùng, tóm tắt bằng TextRank (đồ thị câu, độ tương đồng cosin). Tất cả thuần chuỗi → làm được bản Java + so với cài đặt tham chiếu (`sklearn` / `networkx` nếu có) như các mục khác; gắn vào menu nhấn giữ của lịch sử.
3. **Mã QR để tạo / chia sẻ (L14, M7):** bộ mã hoá QR thuần (Reed-Solomon trên GF(256), mặt nạ, version 1-10 đủ cho URL / văn bản ngắn / vCard / Wi-Fi); kiểm bằng `cv2.QRCodeDetector` (OpenCV đã có trong môi trường) giải lại 1 000 mã ngẫu nhiên.
4. **Sao lưu theo lịch (6.4), lịch sử phiên bản (6.1), widget quét nhanh (K1), cảnh báo pin yếu / máy nóng (2.15, 2.16), cảnh báo trước khi sửa PDF ĐÃ KÝ (2.6):** `JobScheduler` định kỳ + cây SAF đã cấp quyền lâu dài + xoay vòng giữ N bản (phần xoay vòng thuần, kiểm bằng Java); `AppWidgetProvider` + `PendingIntent` mở camera; `BatteryManager` / `PowerManager.getCurrentThermalStatus()` (API 29); phát hiện chữ ký bằng quét `/ByteRange` + `/Type /Sig` trong byte tệp (kiểm bằng PDF thật do `pyhanko` hoặc phần ký của app tạo).
5. **Chữ ký số nâng cao (3.4-3.8):** dấu thời gian RFC 3161 (PAdES-B-T): dựng `TimeStampReq` DER (đã có `DerWriter`), POST `application/timestamp-query`, gắn `id-aa-signatureTimeStampToken` vào `unsignedAttrs`; kiểm cả vòng bằng `openssl ts` làm TSA giả cục bộ; chứng thư từ tệp `.p12` (`KeyStore.getInstance("PKCS12")`); dấu hiển thị (widget annotation + AP stream). Cần quyết định quyền INTERNET trước.
6. **eSCL:** quét hai mặt (hướng nghĩ: `<pwg:InputSource>Feeder</pwg:InputSource>` + một phần tử Duplex trong ScanSettings và các khả năng ADF trong ScannerCapabilities; **tên phần tử chính xác CHƯA xác nhận** - một lần tìm web trong phiên 19 chỉ ra tài liệu SDK của hãng khác, không ra văn bản đặc tả Mopria eSCL; phải đọc đặc tả eSCL hoặc `/eSCL/ScannerCapabilities` của một máy quét thật có ADF hai mặt trước khi viết; rồi thêm vào máy quét giả của `escl_check.py`), vùng tin cậy IPv6 link-local (`Inet6Address` + scope id), ghim chứng chỉ TLS (`TrustManager` chỉ nhận đúng vân tay lần đầu), thử máy thật.
7. **`PdfTextMarkup` đường chữ-lớp** (mục 6.6 cũ), **két xác thực mỗi lần + khoá khôi phục** (6.7 cũ), **khung đọc PDF nhúng cho máy tính bảng** (6.9a cũ: `PdfRenderer` + `RecyclerView` / `ViewPager2`), **thêm ngôn ngữ** (6.4 cũ: mỗi ngôn ngữ ~1 000 chuỗi theo quy trình 4.45; cần người bản ngữ rà): giữ nguyên hướng đã ghi ở "Còn lại sau phiên 17".
8. **Chưa có và chưa cần quyết ngay (ghi để khỏi quên, không phải bỏ sót):** nhận dạng chữ viết tay và công thức (ML Kit Text Recognition không hỗ trợ chính thức; `Digital Ink Recognition` nhận NÉT VIẾT chứ không nhận ảnh nên không dùng được cho ảnh chụp), tìm kiếm ngữ nghĩa (cần mô hình nhúng chạy trên máy), điều khiển bằng giọng nói, phông chữ cho người đọc khó (OpenDyslexic: giấy phép OFL cho phép đóng gói, cần tệp phông).

### Còn lại sau phiên 17 (mỗi mục kèm hướng đã tra cứu - không phải "giới hạn")

1. **Biên dịch mã phiên 16 + 17 (ƯU TIÊN SỐ 1).** Chưa có dòng Kotlin nào của hai phiên này được biên dịch. Chạy Actions; điểm nghi ngờ mới của phiên 17: `@ExperimentalGetImage` đặt trên `BarcodeScanActivity` (nếu Kotlin đòi opt-in kiểu khác, đổi sang `@androidx.annotation.OptIn(ExperimentalGetImage::class)`), `startSupportActionMode` ở `MainActivity` trên theme không có ActionBar, `doc.document.objects` / `PDFont.isEmbedded` / `PDDocument.version` / `COSDictionary.setInt/setString` trong `PdfAConverter`, `COSFloat` + `setItem(String, ...)` trong `PdfTextMarkup`, `KeyGenParameterSpec` trong `VaultStore`, `compareBy` trong `VaultStore.list`.
2. **PDF/A: chạy job `pdfa` lần đầu.** Mẫu do `pdfa_sample.py` dựng đã qua qpdf/lcms/XML nhưng CHƯA qua veraPDF. Nếu đỏ, đọc bước "List the failed rules"; sửa công thức ở CẢ `pdfa_sample.py` lẫn `PdfAConverter.kt`. Kiểm bản Kotlin thật trên JVM (hướng đã tra): thêm `testImplementation` Robolectric + pdfbox-android, `PDFBoxResourceLoader.init(context)`, gọi `PdfAConverter.convert` trên PDF dựng sẵn rồi đưa kết quả cho veraPDF trong CI.
3. **eSCL: thử máy quét thật và các phần chưa phủ.** Lõi giao thức + máy khách đã làm và kiểm với máy quét giả (4.31 I). Còn: thử với máy thật (nhất là máy dùng đường dẫn riêng, máy chỉ có `_uscans._tcp` TLS - hướng đã tra: `HttpsURLConnection` với `TrustManager` chỉ chấp nhận chứng chỉ tự ký CỦA ĐÚNG địa chỉ IP đã chọn và ghim vân tay chứng chỉ ở lần đầu, để không tắt xác minh toàn cục); quét hai mặt khay nạp (`scan:AdfDuplexInputCaps`, `pwg:InputSource` Feeder + `scan:Duplex` true); xem trước (`Intent`/`Preview` thấp độ phân giải); IPv6 liên kết cục bộ (cần `%scope` trong URL, hiện bỏ qua); `EsclDiscovery` chưa chạy. **Quyết định cần bạn:** quyền INTERNET (xem 4.31 I) - giữ để có tính năng, hoặc xoá dòng quyền khỏi manifest để app giữ lời hứa "không có quyền Internet".
4. **Đa ngôn ngữ.** XONG ở phiên 18 (4.45, 4.46): tiếng Anh là mặc định (`values/`), có `values-vi` và `values-ja`, người dùng chọn trong app hoặc theo ngôn ngữ máy; ngôn ngữ app không có thì hiện tiếng Anh. CÒN: thêm các ngôn ngữ khác (mỗi ngôn ngữ ~1 000 chuỗi, theo quy trình ở 4.45) và người bản ngữ đọc lại văn phong cả ba ngôn ngữ.
5. **Công cụ cấu trúc PDF - phần còn lại.** ĐÃ làm: đọc mục lục, tách theo mục lục, ghép giữ chữ + mục lục (4.32), sửa mục lục (4.34). Còn: liên kết nội bộ (`PDAnnotationLink` + `PDPageFitDestination`), tệp đính kèm (`PDComplexFileSpecification` + `PDEmbeddedFile` trong `Names/EmbeddedFiles`; lưu ý PDF/A-2 cấm tệp đính kèm, xem điểm chặn `embedded_file`), di chuyển / đổi cấp một mục lục.
6. **Đường chữ-lớp cho `PdfTextMarkup`.** Hiện lấy từ bằng OCR của trang đã vẽ (đồng đều cho bản quét và PDF số, chậm hơn ~1 s/trang, kém chính xác hơn lớp chữ thật). Hướng đã tra: lớp con `PDFTextStripper` ghi đè `writeString(String, List<TextPosition>)`, dùng `xDirAdj`, `yDirAdj`, `heightDir`, `widthDirAdj` (đã hiệu chỉnh theo xoay) chia theo khoảng trắng thành từ; `TextPosition.getPageWidth()/getPageHeight()` cho tỷ lệ. Chưa làm.
7. **Két: xác thực MỖI LẦN dùng khoá** (xem 4.31 H): cần quyết định sản phẩm (khoá khôi phục?) vì Android huỷ khoá khi đổi khoá màn hình / thêm vân tay.
8. ~~Thùng rác: khôi phục chưa mang theo sao/thẻ~~ - ĐÃ làm ở 4.33.
9. **Danh sách PDF "Thiếu gì để bán app" - hiện trạng sau phiên 18 (ghi lại từng mục để khỏi nhầm):** XONG ở phiên 18 - nhóm tệp PDF: lớp OCG, liên kết, tệp đính kèm, PDF Portfolio, sửa PDF hỏng, thêm liên kết tự động (4.39, 4.40), tuyến tính hoá (4.42; kết luận "không làm được" ở bản 4.40 cũ là sai và đã được sửa); ebook: sửa thông tin / ảnh bìa, tách / ghép, EPUB -> HTML / Markdown (4.35); trình phân tích dung lượng + tìm tài liệu trùng + ghi đè khi xoá hẳn (4.36); chế độ riêng tư (4.41); thư mục theo dõi (4.43); bố cục máy tính bảng hai cột (4.44); đa ngôn ngữ Anh / Việt / Nhật + bộ chọn ngôn ngữ (4.45, 4.46); dịch vụ nền giữ việc dài sống (4.38). **CÒN LẠI (nói thẳng):** (a) khung XEM tài liệu ngay trong app cho máy tính bảng (bố cục "danh sách + xem") - cần bộ xem PDF nhúng, việc riêng và lớn; (b) thêm các ngôn ngữ khác ngoài Anh / Việt / Nhật và người bản ngữ đọc lại bản dịch (4.45); (c) [ĐÃ XONG: ngôn ngữ mặc định là tiếng Anh, ngôn ngữ app không có thì hiện tiếng Anh]; (d) mọi lời gọi PdfBox / Android của các tính năng phiên 18 CHƯA chạy (chỉ logic và cấu trúc được kiểm bằng công cụ độc lập) - việc đầu tiên nên làm là chạy CI và thử trên máy thật; (e) tuyến tính hoá chưa chạy PdfBox; xref cổ điển nên tệp ra có thể lớn hơn tệp vào dùng luồng đối tượng.
10. **Chụp liên tiếp (burst):** KHÔNG làm có chủ ý - đã có tự chụp khi ổn định và thêm trang liên tục.


> **Lưu ý (phiên 14):** các mục dưới đây viết ở phiên 1-10, khi engine sửa PDF còn là iText. Chỗ nào nhắc "iText" là LỊCH SỬ — code thật dùng
> PdfBox-Android từ phiên 11 (mục 4.18). Trạng thái mới nhất của các việc phiên 11-14 nằm ở mục 4.18-4.21 và 10.

- [x] ~~**"Sửa lại đúng câu chữ đã có sẵn trong PDF" (như Word) — phần người dùng đã chọn làm SAU
      phần đánh dấu/chú thích (mục 0/4.16, phiên thứ 7), CHƯA BẮT ĐẦU LÀM GÌ, kể cả thiết kế.**~~ —
      **đã làm ở phiên thứ 8, phạm vi ĐÃ ĐƯỢC THU HẸP RÕ RÀNG và người dùng đã xác nhận TRƯỚC khi
      code** (không phải "sửa tự do như Word" — tìm & thay 1 đoạn chữ NGẮN trong CÙNG 1 dòng, chỉ
      khi đủ ký tự trong font, tự co giãn ngang cho vừa khung, không tự xuống dòng lại). Xem mục
      4.17 để biết đầy đủ cơ chế (`PdfCanvasEditor`/`PdfTextEditor`, port từ mã nguồn thật
      `mkl-public/testarea-itext7`, không tự sáng tác). **VẪN CẦN TEST THẬT TRÊN NHIỀU PDF THẬT
      TRƯỚC KHI TIN DÙNG** — đây là tính năng DUY NHẤT trong dự án ghi trực tiếp vào object chữ của
      1 PDF có sẵn, chưa mở thử lần nào (môi trường này không build được), rủi ro sai sót nặng hơn
      hẳn (PDF hỏng/chữ lệch) so với 1 lỗi giao diện thông thường — xem mục 9/10 để biết cách test.
- [ ] **Chưa build-test thật lần nào** — việc quan trọng nhất, xem mục 0 và mục 9.
- [x] ~~`PdfAnnotateActivity` (tool mới "Chú thích PDF", phiên thứ 7) chưa có backup/restore qua
      chết tiến trình~~ — cố tình để vậy cho bản đầu, đã ghi rõ trong mục 4.16 (không phải quên).
      Có hộp thoại xác nhận trước khi mất chú thích chưa lưu, không phải lưu JSON đầy đủ như
      `PdfEditorState`/`EbookEditorState`. Đánh dấu `[x]` ở đây vì đây là quyết định đã chốt (chấp
      nhận), không phải việc đang chờ làm — khác các mục `[ ]` khác trong danh sách này.
- [x] ~~`PdfTextEditActivity` (tool mới "Sửa chữ PDF", phiên thứ 8) chưa có backup/restore qua chết
      tiến trình~~ — **cập nhật phiên thứ 9**: khác 2 mục `[x]` chấp nhận-là-được ở trên (annotate,
      Project ebook) — mục NÀY người dùng hỏi thẳng vì sao không tra cứu cách giải quyết, và câu
      trả lời là "không cần tra cứu, chỉ là chưa làm" — nên ĐÃ LÀM THẬT, không phải chấp nhận bỏ
      qua. Xem mục 0/4.17 (phiên thứ 9) để biết cơ chế riêng (lưu bản gốc + danh sách lần sửa, khôi
      phục bằng áp lại từ đầu, khác khuôn mẫu `PdfEditorState` thường dùng vì lý do kỹ thuật của
      iText stamping mode). Vẫn CHƯA test thật (cùng lý do môi trường như mọi phần khác).
- [ ] **`PdfTextEditActivity`/`PdfTextEditor` CHƯA TỪNG được test bằng 1 file PDF thật nào** — mục
      quan trọng NHẤT cần làm ngay khi build được (mục 9/10), ưu tiên cao hơn cả việc build-test các
      tool khác, vì đây là tính năng DUY NHẤT ghi trực tiếp vào object chữ của 1 PDF có sẵn — lỗi ở
      đây cho ra PDF hỏng/chữ sai vị trí/lệch font, không phải 1 lỗi giao diện thông thường có thể
      sửa nhẹ nhàng sau. Xem mục 4.17 (bảng "mức độ tin cậy API") để biết đúng 3 hàm iText nào chưa
      được tra cứu riêng trong phiên viết code này, nên nghi ngờ đầu tiên nếu build lỗi ở đây.
      **[Phiên 11: iText đã thay bằng PdfBox — bảng mức tin cậy MỚI nằm ở mục 4.18; nghi ngờ đầu tiên giờ là các API PdfBox nhóm "Trung bình".]**
- [x] ~~Bài so sánh Kotlin vs Java mà người dùng hỏi ban đầu~~ — đã viết, xem `KOTLIN_VS_JAVA.md`.
- [x] ~~Tự lưu/khôi phục (mục 4.13) mới chỉ áp dụng cho phiên quét~~ — đã mở rộng sang cả 3 luồng
      còn lại (ghép PDF, quản lý trang PDF, soạn mục lục ebook), xem mục 4.14. Còn vài cửa sổ rủi ro
      hẹp chưa xử lý hết (mất trang đang render/OCR dở nếu app bị tắt đúng lúc đó) — xem "Giới hạn
      đã biết" cuối mục 4.14, chấp nhận được, không chặn gì.
- [ ] `isColorPage()` (ngưỡng saturation=40, tỉ lệ=2%) chưa test với ảnh/máy thật — nhiều khả năng
      cần chỉnh ngưỡng sau khi thấy kết quả thật (đặc biệt ảnh chụp bằng đèn vàng/flash dễ bị lệch
      màu, có thể bị nhận nhầm là "có màu").
- [ ] `detectGutterX()` (gợi ý vị trí gáy sách để tách 2 trang) **cũng chưa test với ảnh thật** —
      cùng rủi ro như `isColorPage()`. Vì chỉ là gợi ý ban đầu cho đường kéo tay (xem quyết định 12),
      đoán sai không hỏng tính năng, nhưng có thể cần tinh chỉnh vùng tìm kiếm (hiện cố định 30%-70%
      chiều rộng ảnh) sau khi thấy ảnh thật.
- [ ] Ebook (EPUB) **chưa từng mở thử bằng app đọc sách thật nào** (Google Play Books, Apple Books,
      calibre, gửi thử lên Kindle...) — cấu trúc XML/OPF/NCX được viết đúng theo chuẩn đã biết,
      nhưng chưa có xác nhận thực tế là file sinh ra mở được không lỗi. Việc ưu tiên khi test: mở
      thử 1 file EPUB xuất ra bằng vài app đọc sách khác nhau.
- [x] ~~FB2~~ — đã làm ở phiên 16 (mục 4.27). **MOBI/AZW3 vẫn KHÔNG hỗ trợ** (cố ý, quyết định 11: Amazon ngừng nhận MOBI từ 3/2025, Kindle nhận EPUB trực tiếp); FB2 chưa mở thử bằng
      trình đọc thật.
- [ ] **`Ccitt4Encoder`/`Ccitt4Decoder` (nén CCITT G4) chưa từng chạy trên Android thật** — thuật
      toán/bảng mã đã kiểm chứng rất kỹ bằng Python+libtiff (xem mục 4.11), nhưng code KOTLIN thực
      tế (chuyển tay từ Python) thì chưa. Có lưới an toàn tự giải mã lại trước khi dùng
      (`Ccitt4Decoder.verify()`), nên rủi ro cao nhất nếu có lỗi port là tự động rơi về cách an
      toàn (1-bit+Deflate) nhiều hơn dự kiến, không phải ra file hỏng — nhưng vẫn cần test thật để
      biết chế độ CCITT G4 có thực sự chạy được (không throw exception/crash) trên thiết bị.
      Việc ưu tiên khi test: bấm thử "Nén sâu hơn (CCITT G4)" với 1 PDF nhiều trang chữ, xem app có
      chạy được không và tỉ lệ nén thực tế đạt bao nhiêu so với "An toàn".
- [ ] `EpubReader` chỉ test đọc lại đúng EPUB mà `EbookBuilder` tự tạo ra (chưa test với EPUB từ
      nguồn khác — Calibre, Kindle export, v.v. — có thể có cấu trúc XHTML/CSS phức tạp hơn khiến
      `Html.fromHtml()` cho kết quả kém hơn, ví dụ mất định dạng bảng/danh sách phức tạp).
- [ ] `PdfBookmarkInjector` (bookmark thật trong PDF xuất từ EPUB/TXT) **chưa test trên thiết bị
      thật** — dựa vào giả định về cấu trúc byte PdfDocument ghi ra mà KHÔNG có cách nào kiểm chứng
      trước (khác CCITT G4 có libtiff để đối chiếu). Có lưới an toàn (trả `null` → dùng file gốc
      không bookmark) nên không thể ra file hỏng, nhưng chưa biết trên máy thật bookmark có thật sự
      xuất hiện hay không. Việc ưu tiên khi test: mở PDF xuất ra từ EPUB/TXT bằng 1 app đọc PDF có
      khung bookmark (Adobe Acrobat, hầu hết app đọc PDF trên Android) xem có thấy mục lục bấm được
      không.
- [x] ~~`TextPdfBuilder` ngắt dòng theo khoảng trắng~~ — đã sửa ở phiên 16 (4.27, B16-01): điểm ngắt theo UAX #14 qua `android.icu.text.BreakIterator`, `TextWrapper` chọn điểm vừa khổ. CÒN: chưa chạy
      ICU thật của Android và chưa xem PDF ra trên thiết bị với phông CJK thật.
- [ ] Công cụ "Chuyển đổi định dạng" **chưa test trên thiết bị thật** cho cả 8 cặp chuyển đổi (PDF→
      Ebook, PDF→Ảnh chuyển tiếp sang màn có sẵn; EPUB→PDF, EPUB→TXT, TXT→PDF, TXT→EPUB, Ảnh→PDF
      tự làm mới).
- [x] ~~Trường hợp xuất CẢ EPUB lẫn TXT cùng lúc... UI không báo rõ cho người dùng biết cả 2 sẽ
      mất~~ — đã sửa: `MainActivity.confirmDeleteHistoryFile()` giờ kiểm tra riêng trường hợp xoá 1
      dòng `.epub` có file `.txt` cùng tên đang hiện thành dòng riêng trong lịch sử, và đổi nội dung
      hộp thoại xác nhận để nói rõ cả 2 sẽ bị xoá trước khi người dùng bấm Đồng ý. Hành vi xoá vẫn
      giữ nguyên (xoá cả cặp) — chỉ thêm cảnh báo, không đổi logic xoá.
- [~] OCR lúc XUẤT PDF ra file `.txt`. **Đã giải quyết ở phiên 12-13 và 16:** công cụ riêng "PDF tìm kiếm được (OCR)" (4.19/4.20) và, từ phiên 16 (4.27), chính ô OCR của luồng Quét và bước OCR của luồng Dự án
      gắn lớp chữ vô hình vào PDF (`SearchablePdfBuilder.embedInPlace`; lỗi thì PDF giữ nguyên). CÒN: CHƯA thử với Chrome/Acrobat/trình đọc Android và chưa chạy trên thiết bị; trong luồng Dự án chỉ bản PDF
      đã nén (nếu có) nhận lớp chữ, bản chưa nén thì không.
- [ ] (Phiên 16) **Mã Kotlin phiên 16 chưa biên dịch**: `ScanPresetApplier` (nhập `R` và `androidx.annotation.StringRes`), `SearchablePdfBuilder.embedInPlace` (`PDDocument.documentCatalog.documentOutline?.firstChild`/`nextSibling`),
      `PdfExporter.ocrExportedPdf`, `ProjectOcrActivity.runOcr`, `TextWrapper`, `TextPdfBuilder.lineBreakOffsets` (`android.icu.text.BreakIterator`), `EbookBuilder.buildFb2`, `ConvertDocumentActivity` (enum `Target`),
      hai `SavedState` (`wantFb2`), `activity_ebook_editor.xml` (`cbFormatFb2`).
- [ ] Công cụ Ghép PDF / Quản lý trang PDF làm mất chữ thật (chọn/copy được) của PDF gốc do
      rasterize — nếu cần giữ chữ thật, phải đổi hướng kỹ thuật (xem mục 5.2).
- [x] ~~File tạm trong cache không bao giờ tự dọn~~ — đã thêm `FileUtils.cleanOldCacheFiles()`,
      chạy 1 lần mỗi khi app khởi động (nền, không chặn startup), xoá file cũ hơn 24h trong
      `cache/captures/`, `cache/imported/`, `cache/temp/`. Lưu ý: `session_pages/` không còn nằm
      trong cache từ mục 4.13 (đã chuyển sang `filesDir`) nên tên thư mục trong dòng gốc phía trên
      không còn chính xác — giữ nguyên dòng gốc để không xoá lịch sử, đính chính ở đây.
- [ ] Không có test tự động (unit test/instrumented test) của APP nào được viết, dù đã khai báo dependency
      `junit`/`espresso-core` trong `build.gradle`. (Phiên 11-14 có thêm script Python ở `tools/verify/` kiểm chứng THUẬT TOÁN bằng công cụ độc lập, và
      `doc_sync_check.py` kiểm tài liệu khớp mã — nhưng chúng KHÔNG chạy mã Kotlin.)
- [x] ~~Chỉ có build type `debug` — chưa ký release/AAB~~ — **đã làm ở phiên 11:** `bundleRelease` ký bằng biến môi trường (`KEYSTORE_PATH`...), `versionCode`
      = số lần chạy CI, `applicationId` lấy từ biến `APP_ID` (Play từ chối `com.example.*`), workflow `create-keystore.yml` tạo khoá upload 1 lần (mục 4.18, README).
      Nhánh debug đã biên dịch ở run #18; nhánh `bundleRelease` (có khoá thật) CHƯA chạy lần nào.
- [ ] Icon app là icon tạm tự vẽ bằng code (hình chữ nhật xanh + trang giấy trắng + góc bẻ + móc góc
      vàng), chưa ai duyệt về mặt thiết kế.
- [x] ~~Chưa có `values-night`~~ — đã có ở phiên 16 (4.29, B16-09), CHƯA xem trên máy. [ ] Vẫn chưa có layout riêng cho tablet/màn ngang và bản tiếng Anh (4.29, mục "Chưa làm").
- [ ] Chưa test go-through thực tế toàn bộ luồng nào (chụp→crop→lọc→xuất, ghép PDF, quản lý trang)
      trên thiết bị/emulator thật — mọi thứ mới chỉ được rà soát tĩnh (đọc code + đối chiếu resource,
      xem mục 9). Từ mục 4.14: thêm 3 hộp thoại khôi phục mới (page-editor/ebook/merge) cũng chưa
      test thật — cùng cách test như mục 4.13 đã gợi ý cho phiên quét (chụp/chọn vài thứ, force-stop
      app, mở lại xem hộp thoại có hiện đúng không), làm riêng cho từng màn hình trong 3 màn đó.
- [ ] **Toàn bộ luồng "Dự án" (mục 4.15) — 9 màn hình mới, CHƯA test go-through dù 1 lần.** Đây là
      việc test ưu tiên cao nhất sau khi build qua được (xem mục 10 đã xếp lại thứ tự). Test tối
      thiểu: 1 dự án đi hết cả 8 bước với 1 quyển sách thật (2-3 ảnh chụp trang đôi là đủ để test cả
      tách trang), có bật mục lục tự động 1 lần để xem `TocDetector` phản ứng ra sao với ảnh thật -
      gần như chắc chắn cần chỉnh lại regex sau lần test đầu (mục 4.15 đã nói rõ heuristic này chưa
      test với ảnh thật nào).
- [x] ~~`ProjectEbookActivity` (bước cuối của Dự án) không có backup/restore mức "đang gõ dở" như
      `EbookEditorState` làm cho công cụ độc lập tương ứng~~ — đã làm ở phiên thứ 4, file mới
      `ProjectEbookEditorState.kt` (backup theo từng dự án, xem mục 0/3/4.15). Vẫn CHƯA test thật
      (cùng hạn chế môi trường) — cách test gợi ý giống mục 4.13/4.14: làm dở vài đánh dấu chương ở
      bước 8, ép buộc dừng app, mở lại dự án xem có khôi phục đúng không.
- [x] ~~**Lỗi khai sai kích thước vật lý trang PDF (mục 7, "`ASSUMED_DPI` sai...") chưa được sửa
      hết** — còn đúng 1 đường: `MainActivity.importPdfForScanning()` (nút "Quét" → nguồn PDF) →
      hàng đợi crop ở `CropActivity` (chế độ queue) → `ScanSessionManager.addPage()` tại
      `CropActivity.kt` dòng có `ScanPage(ScanSessionManager.newPageId(), outFile.absolutePath)` —
      đang thiếu tham số `sourceDpi`.~~ — đã sửa ở phiên thứ 4, đúng theo cách mô tả ở đây (DPI
      truyền qua `PendingCropQueue` + Intent extra của `CropActivity`, giữ nguyên qua cả tách
      trang). Xem mục 0/7 để biết chi tiết. Vẫn CHƯA test thật trên thiết bị (cùng hạn chế môi
      trường) — cách test gợi ý: quét từ nguồn PDF, xuất ra, mở bằng app đọc PDF có hiện kích thước
      trang (hoặc so `/MediaBox` bằng tay) để xác nhận không còn bị khai to hơn thật ~1.47 lần
      (220/150) mỗi chiều.

## 7. Lỗi thật đã phát hiện & sửa trong lúc làm

- **EXIF orientation bị bỏ qua khi decode ảnh** (phát hiện lúc rà lại dependency
  `androidx.exifinterface` đã khai báo nhưng chưa dùng ở đâu — soi ra thiếu sót thật, không phải chủ
  động tìm bug). Ảnh chụp bằng camera hoặc lấy từ thư viện ảnh, nhất là ảnh chụp dọc máy, thường lưu
  ở hướng cảm biến gốc + thẻ EXIF ghi góc xoay, chứ không xoay vật lý pixel. `BitmapFactory.decodeFile`
  mặc định BỎ QUA thẻ EXIF này → ảnh có thể bị nạp sai hướng (nằm ngang dù chụp dọc), làm hỏng bước
  phát hiện góc + làm phẳng phối cảnh. **Đã sửa**: thêm `FileUtils.decodeBitmapWithExifOrientation()`
  (đọc `androidx.exifinterface.media.ExifInterface`, áp `Matrix` xoay/lật đúng chiều), dùng hàm này
  thay cho `BitmapFactory.decodeFile` thường tại đúng 1 điểm — `CropActivity.loadImage()` — vì đây
  là nơi DUY NHẤT ảnh "nguồn thô" (camera/thư viện/PDF) được nạp lần đầu, sửa 1 chỗ này là đủ cho cả
  3 nguồn ảnh (ảnh render từ PDF không có thẻ EXIF nên hàm này tự động là no-op, an toàn).
- **`PdfPageEditorActivity.setBusy()` gọi sai số tham số** (phát hiện ở phiên làm việc tiếp theo, lúc
  đang chuẩn bị sửa file này cho mục 4.14 — không phải tự nhiên soi ra, mà nhờ viết thêm 1 script
  Python đối chiếu số tham số bắt buộc của mọi hàm `fun` tự định nghĩa với số tham số thực tế truyền
  vào ở mọi lời gọi trong cùng file, xem mục 9). Hàm khai báo `setBusy(busy: Boolean, message:
  String?)` — không có giá trị mặc định cho `message` — nhưng lại được gọi ở 4 chỗ chỉ với 1 tham số
  (`setBusy(false)`). Đây CHẮC CHẮN sẽ là lỗi biên dịch thật (`Kotlin: No value passed for parameter
  'message'`) nếu build — đúng loại lỗi mục 0/9 đã dự đoán trước sẽ có ở lần build đầu tiên, chỉ khác
  là lần này tìm được bằng rà soát tĩnh trước khi có CI thật để báo. **Đã sửa**: thêm giá trị mặc
  định `message: String? = null` cho tham số đó (cách sửa ít thay đổi nhất — không phải sửa lại 4
  lời gọi). Đã quét lại toàn bộ file `.kt` khác bằng cùng script, không thấy trường hợp tương tự nào
  khác (chỉ có duy nhất hàm này bị lỗi).
- **`ASSUMED_DPI` sai cho mọi trang render từ 1 PDF có sẵn — làm trang xuất ra SAI KÍCH THƯỚC VẬT
  LÝ** (phát hiện khi trả lời câu hỏi của người dùng về so sánh cách nén "render ảnh" vs "sửa thẳng
  object PDF" cho trang scan — không phải câu hỏi về lỗi, nhưng đi sâu vào chi tiết thì lộ ra lỗi
  thật). `PdfExporter`/`PdfCompressor` đều có hằng số `ASSUMED_DPI = 150f`, dùng để suy ngược từ
  kích thước pixel của bitmap ra kích thước vật lý (point) khi ghi `/MediaBox` cho trang PDF xuất
  ra — hằng số này ĐÚNG cho ảnh chụp bằng camera (không có "DPI thật" nào để tham chiếu, 150 chỉ là
  quy ước hợp lý), nhưng SAI cho bitmap render từ 1 PDF có sẵn qua `PdfImportHelper.renderPage()` -
  nơi đó DPI thật đã biết chính xác (220/250/200 tuỳ chỗ gọi, không phải 150), vì
  `PdfRenderer`/`renderPage()` tính `scale = dpi/72f` dựa trên kích thước THẬT (point) của trang
  gốc. Dùng nhầm 150 thay vì DPI thật khi ghi ngược lại khiến trang xuất ra bị khai kích thước vật
  lý TO HƠN THẬT (to hơn đúng bằng tỉ lệ dpi_thật/150 — ví dụ trang A4 lúc render ở 250dpi rồi xuất
  với giả định 150dpi sẽ bị khai to gấp ~1.67 lần mỗi chiều). Hầu hết app xem PDF trên điện thoại tự
  fit-to-width nên không thấy gì bất thường, nhưng **nhiều máy đọc sách e-ink thật sự tôn trọng kích
  thước trang khai báo** — đúng use-case chính mà app này nhắm tới — nên đây là lỗi có ảnh hưởng thật
  tới đúng nhóm người dùng app phục vụ, không phải lỗi lý thuyết suông.
  **Đã sửa** cho các đường đi ĐÃ XÁC ĐỊNH RÕ DPI (không lẫn nguồn trong cùng 1 lần gọi):
  - `PdfCompressor.compress()` / `PdfExporter.exportSession()` / `exportImagePaths()`: thêm tham số
    tuỳ chọn (`assumedDpi`/`sourceDpi`, mặc định vẫn 150 — không đổi hành vi nơi nào chưa được sửa)
    để nơi gọi biết chắc DPI thật thì truyền vào đúng giá trị đó.
  - `ScanPage` thêm trường `sourceDpi: Float?` (mặc định `null` = ảnh chụp, dùng quy ước 150) để
    `ScanSessionManager`/`PdfExporter.exportSession()` biết DPI thật CHO TỪNG TRANG (1 phiên có thể
    trộn cả trang chụp camera lẫn trang import từ PDF) — có cập nhật cả lưu/khôi phục JSON (mục
    4.13) để không mất thông tin này khi backup/restore.
  - Đã sửa đúng 3 nơi biết chắc DPI: `MainActivity.importPdfForEink()` (250), `MainActivity`
    công cụ "Nén PDF" độc lập (250), `PdfPageEditorActivity` (200 — luôn nạp từ 1 PDF được chọn,
    không có nguồn camera nào khác trộn vào Activity này nên áp dụng chắc chắn cho cả file).
  - **CHƯA sửa (đã sửa ở phiên thứ 4 — xem cập nhật ngay dưới)**: đường
    `MainActivity.importPdfForScanning()` → hàng đợi crop (`PendingCropQueue`/`CropActivity` chế độ
    queue) → `ScanSessionManager.addPage()` ở `CropActivity.kt`. Đường này CŨNG bị lỗi tương tự
    (render ở 220dpi, `warpDocument()` đã xác nhận giữ nguyên mật độ pixel qua bước crop nên DPI
    220 vẫn đúng cho ảnh sau khi cắt — không phải lo ngại kỹ thuật, chỉ là CHƯA làm), nhưng cần
    truyền DPI qua `PendingCropQueue`/Intent extra của `CropActivity` — nhiều việc hơn, chưa làm
    trong lượt này để tránh sửa vội 1 luồng có logic phức tạp hơn (hàng đợi, tách trang) mà không
    kiểm chứng được gì trong môi trường này.
  - `ConvertDocumentActivity.convertImagesToPdf()` KHÔNG bị lỗi này — ảnh đầu vào ở đó là ảnh người
    dùng tự chọn trực tiếp (không phải render từ PDF), không có "DPI thật" nào để mất, quy ước 150
    vẫn hợp lý như với ảnh chụp camera.
  - **Cập nhật (phiên thứ 4)**: đã sửa nốt đường còn lại ở trên. `PendingCropQueue` thêm 1 thuộc
    tính `sourceDpi: Float?` DÙNG CHUNG cho cả lô đang xếp hàng (hợp lý vì 1 lần gọi `setAll()` luôn
    chỉ đến từ 1 nguồn duy nhất — hoặc toàn bộ ảnh thư viện, hoặc toàn bộ trang của 1 PDF đang import
    — không bao giờ trộn 2 nguồn trong cùng 1 lô, nên không cần lưu riêng theo từng ảnh). `MainActivity.
    startCropQueue()` nhận thêm tham số tuỳ chọn `sourceDpi` (mặc định `null`, không đổi hành vi nơi
    gọi cũ - `importGalleryImages()`), truyền vào `PendingCropQueue.setAll()` VÀ gắn vào Intent qua
    hằng số mới `CropActivity.EXTRA_SOURCE_DPI` (chỉ đặt khi khác `null`) - cần cả 2 đường vì ảnh ĐẦU
    TIÊN của lô đi thẳng qua Intent extra `EXTRA_IMAGE_PATH`, không qua `PendingCropQueue` (chỉ ảnh
    thứ 2 trở đi mới nằm trong hàng đợi). `importPdfForScanning()` gọi `startCropQueue(paths,
    sourceDpi = 220f)` (220 khớp đúng DPI đã render ở dòng `renderAllPagesToFiles(..., dpi = 220)`
    ngay phía trên). Phía `CropActivity`: đọc `EXTRA_SOURCE_DPI` đúng 1 lần trong `onCreate()`, giữ
    trong 1 field `sourceDpi: Float?` suốt vòng đời Activity (không đọc lại từ `PendingCropQueue` mỗi
    lần lấy ảnh tiếp theo trong hàng đợi - không cần thiết vì 1 Activity chỉ xử lý đúng 1 lô, kể cả
    khi tự xử lý tiếp ảnh trong hàng đợi qua `loadImage()` mà KHÔNG tạo Activity mới), rồi gán field
    này vào MỌI `ScanPage` được lưu ra ở `savePage()` - bao gồm cả 2 nửa sau khi tách trang, vì nửa
    phải được đẩy lại vào chính `PendingCropQueue` này (`pushFront()`) rồi cũng được nạp lại và lưu
    ra bởi CÙNG Activity, CÙNG field `sourceDpi` đó, nên tự động đúng mà không cần thêm code riêng
    cho trường hợp tách trang. Đường ảnh chụp máy ảnh (`CaptureActivity`, chế độ single) không đặt
    `EXTRA_SOURCE_DPI` nên `sourceDpi` vẫn là `null` như trước khi sửa - hành vi hoàn toàn không đổi
    cho 2 nguồn ảnh còn lại (thư viện, camera). Đã rà lại bằng đủ 6 cách ở mục 9 sau khi sửa, không
    phát hiện vấn đề gì mới. **Vẫn CHƯA test thật trên thiết bị** (cùng hạn chế môi trường mọi phiên).


### 7.1 Chỉ mục các lỗi đã ghi rải rác ở mục 0 (phiên 2–10) — trước đây KHÔNG nằm trong mục 7

Mục 7 ban đầu chỉ có 3 lỗi (EXIF, `setBusy`, `ASSUMED_DPI`, ở trên). Các lỗi sau đã được viết trong mục 0 của từng phiên nhưng không được dồn về đây:

| ID | Phiên | Loại | Lỗi / chẩn đoán | Sửa |
|---|---|---|---|---|
| B06-01 | 6 | bản nháp bắt kịp trước khi chạy | tách OCR khỏi `PdfExporter.exportSession()`: bản nháp đầu giữ TẤT CẢ bitmap trong RAM (mất tính chất "decode → OCR → giải phóng từng ảnh") | viết lại `writeOcrTextFile()` giữ bộ nhớ giới hạn |
| B07-01 | 7 | rò bộ nhớ | `AnnotationCanvasView.loadPage()` không `recycle()` bitmap trang cũ → tích luỹ mỗi lần chuyển trang | giải phóng bitmap cũ trước khi gán mới |
| B07-02 | 7 | rò file tạm | `FileUtils.annotatePagesDir` không được dọn sau khi xuất hoặc huỷ → tích luỹ qua nhiều lần dùng | dọn sau khi xuất thành công VÀ khi xác nhận huỷ |
| B08-01 | 8 | LỖI BIÊN DỊCH thật | `trySubstituteAndWrite` được gọi kèm lambda cuối nhưng khai báo thiếu tham số callback (`substitute`) — bắt bằng script đối chiếu số tham số (mục 9) | thêm tham số `substitute: () -> Unit` (hàm này sau đó bị bỏ ở phiên 10) |
| B09-01 | 9 | LỖI LOGIC âm thầm (nghiêm trọng) | bước ĐỌC chữ (iText `PdfCanvasProcessor`) đi sâu vào Form XObject còn bước GHI thì không → 2 bộ đếm lệch nhau → với trang có chữ trong Form XObject, "sửa đoạn N" sửa NHẦM sang đoạn khác không cảnh báo | phiên 9: handler rỗng cho `Do`; phiên 10: bỏ hẳn 2 cơ chế duyệt, ĐỌC và GHI dùng chung 1 lớp (tận gốc) |
| B10-01 | 10 | LẬP LUẬN sai của tôi (người dùng chỉ ra) | phiên 9 từ chối "ghép chữ nhiều mảnh `TJ`" vì tưởng cần đoán; thực ra các mảnh trong CÙNG mảng `TJ` là sự thật cấu trúc | 1 lệnh hiện chữ = 1 `TextChunk`; chỉ ghép xuyên 2 operator khác nhau mới cần heuristic → vẫn không làm |
| B04-01 | 4 | lỗi còn sót của B-ASSUMED_DPI | đường `importPdfForScanning()` → `PendingCropQueue` → `CropActivity` còn khai sai kích thước trang | thêm `sourceDpi` qua `PendingCropQueue` + `EXTRA_SOURCE_DPI` (mô tả đầy đủ ở trên) |
| B04-02 | 4 | lệch tài liệu (không phải lỗi code) | bản đồ file (mục 3) thiếu hẳn `PdfObjectRecompressor.kt` dù file đã có code thật và đã mô tả ở 4.11; mô tả `ScanPage.kt`/`PendingCropQueue.kt` chưa nhắc trường `sourceDpi` | đã sửa cả 3 chỗ ở mục 3 |

### 7.2 Phiên 11–15: lỗi, chẩn đoán, sửa

Nhãn "loại": **[mã đã giao]** = lỗi nằm trong mã Kotlin đã có từ trước; **[trước khi vào Kotlin]** = bắt được ở bản thử Python/khi thiết kế, chưa từng nằm trong Kotlin; **[thiết kế/giấy phép]** = không phải lỗi dòng lệnh mà là quyết định sai/không dùng được; **[lệch tài liệu]**.
"Kiểm chứng" luôn nói rõ bằng gì. **Không mục nào trong số này đã được chạy trên Android** (về biên dịch: xem "Trạng thái build hiện hành" ở mục 0; sổ này bắt đầu từ lúc Kotlin còn chưa build lần nào).

| ID | Phiên | Loại | Triệu chứng / chẩn đoán | Nguyên nhân gốc | Sửa (file) | Kiểm chứng |
|---|---|---|---|---|---|---|
| B11-01 | 11 | thiết kế/giấy phép | không bán trả phí được nếu nhúng iText | iText 7 = AGPL hoặc giấy phép thương mại trả theo năm | gỡ iText, dùng PdfBox-Android 2.0.27.0 (Apache 2.0); xoá `PdfCanvasEditor.kt` (port từ mã mẫu iText ⇒ nguy cơ phái sinh); CI `Licence guard` | CI chặn chuỗi `com.itextpdf`/`mupdf`; đọc điều khoản (không phải tư vấn pháp lý) |
| B11-02 | 11 | thiết kế/phát hành | AAB sẽ bị Play Console từ chối | `applicationId = com.example.docscanner`; Play không nhận `com.example.*` (tra cứu xác nhận) | `applicationId` lấy từ biến `APP_ID`; workflow bỏ qua build release nếu rỗng/`com.example*` (`app/build.gradle`, `android-build.yml`) | đọc cấu hình; chưa build |
| B11-03 | 11 | [mã đã giao] tương thích | ở targetSdk 36 (Android 15+) nội dung vẽ dưới thanh trạng thái/điều hướng; bàn phím không còn đẩy layout | edge-to-edge bắt buộc, bỏ cờ opt-out | `DocScannerApp.EdgeToEdgeInsetsCallbacks` đệm theo inset (toolbar kéo dài xuống dưới status bar; có tính IME) | đọc quy tắc Android; CHƯA thử máy thật — nguy cơ lệch giao diện ở từng màn hình |
| B11-04 | 11 | [mã đã giao] tương thích | nút Back không chạy logic xác nhận ở `PdfTextEditActivity` và `PdfAnnotateActivity` | `Activity.onBackPressed()` không còn được gọi khi targetSdk 36 (back dự đoán) | `onBackPressedDispatcher.addCallback` ở cả 2 màn | đọc tài liệu Android; chưa thử máy |
| B11-05 | 11 | [mã đã giao] sai chuẩn PDF | bản sửa chữ iText bọc `q…Q` BÊN TRONG `BT…ET`; hệ số co chữ bỏ qua `Tz/Tc/Tw` đang có | ISO 32000 không cho `q/Q` trong đối tượng chữ; công thức scale thiếu trạng thái hiện hành | `PdfTextEditor` viết lại: bọc bằng `s Tz … <cũ> Tz`, theo dõi Tz/Tc/Tw/font qua `q/Q` | đọc đặc tả; chưa chạy trên PDF thật |
| B11-06 | 11 | [mã đã giao] mất dữ liệu | nén "Sửa trực tiếp" bản iText dựng XObject ảnh MỚI nên làm rơi `/SMask`, `/Mask`, `/Decode` (đọc mã cũ khi viết lại; chưa từng quan sát trên PDF thật). Bản mới còn bảo đảm ảnh dùng chung nhiều trang chỉ nén 1 lần (tránh mất chất lượng chồng; chưa kiểm chứng bản cũ có nén lặp hay không) | dựng XObject ảnh mới thay vì sửa tại chỗ | `PdfObjectRecompressor`: sửa tại chỗ `COSStream`, BỎ QUA ảnh có mặt nạ, xử lý mỗi ảnh 1 lần (tập định danh), và (phiên 13) chỉ thay khi JPEG mới nhỏ hơn bản gốc | đọc mã; chưa thử PDF thật |
| B11-07 | 11 | rủi ro bộ nhớ | PdfBox nạp cả tài liệu vào heap (iText đọc lười) → OOM với bản quét lớn | mặc định `MemoryUsageSetting` chỉ dùng RAM | `PDDocument.load(file, setupMixed(24 MB).setTempDir(...))` ở recompressor, sửa chữ, tìm kiếm được, watermark | đọc API; API này thuộc nhóm "Trung bình" (mục 4.18) |
| B11-08 | 11 | [mã đã giao] thiếu kiểm tra | bản iText không kiểm bất kỳ gì sau khi ghi → PDF hỏng sẽ được trao như bình thường | — | `PdfVerify`: mở bằng `PdfRenderer` + (khi tối ưu) nạp lại bằng PdfBox so số trang/kích thước/băm nội dung từng trang; "Sửa chữ" và "PDF tìm kiếm được" cũng kiểm | `structure_optimizer_check.py` mô phỏng bằng qpdf/poppler/pypdf; `PdfVerify` chưa chạy |
| B11-09 | 11 | [trước khi vào Kotlin] | thử object-stream bằng Python: `qpdf --check` báo "unable to find /Root dictionary" | bản thử ghi THAM CHIẾU (`n 0 R`) thay vì NỘI DUNG đối tượng ở đầu mỗi mục trong object stream | sửa bản thử (cờ `top`); bản Kotlin lưu đối tượng đã giải tham chiếu nên không mắc | sau sửa: qpdf sạch, poppler/pypdf đọc giống bản gốc, poppler render đúng từng điểm ảnh |
| B11-10 | 11 | thiết kế | PdfBox không có object stream/dedupe như "full compression + smart mode" của iText | PdfBox 2.x không có bộ ghi object stream | `PdfStructureOptimizer` tự viết theo đặc tả (7.5.7/7.5.8); rơi về file PdfBox thường khi mã hóa/tên ngoài ASCII/ >40 MB/ không qua `PdfVerify`/ không nhỏ hơn | bản Python: −25% (12 trang), −48% (2 ảnh trùng) |
| B11-11 | 11 | giới hạn font | PdfBox `font.encode()` không biến Unicode thành mã cho font CID nhúng (Word/Chrome/LibreOffice) | encode chỉ viết cho font do người gọi tạo | `ToUnicodeReverse` đảo ngược bảng `/ToUnicode` (bfchar/bfrange); font đơn giản vẫn thử `font.encode()` trước | `tounicode_check.py` (bản Python song song ra đúng mã); chưa thử PDF thật |
| B11-12 | 11 | cấu hình (nguy cơ, chưa quan sát) | `allowBackup=true`: dữ liệu phiên quét/dự án lưu đường dẫn tuyệt đối trong thư mục riêng của app; sao lưu đám mây có thể khôi phục lên máy khác với đường dẫn không còn đúng | — | `allowBackup=false` | đọc |
| B11-13 | 11 | giấy phép | Apache 2.0 yêu cầu kèm bản giấy phép/NOTICE khi phát hành | — | `LicensesActivity` + `assets/THIRD_PARTY_NOTICES.txt` | đọc |
| B12-01 | 12 | thiết kế | cần 1 font để gắn `/ToUnicode` cho lớp chữ OCR; font TrueType rỗng kiểu Tesseract bị chính Ghostscript/Tesseract ghi nhận là không hợp lệ và PDFium đọc sai `/W` | issue Tesseract #2879, Ghostscript bug 695869 | font Type3 mà mọi glyph không vẽ gì (`500 0 d0`) — không nhúng file font nào | qpdf sạch; poppler, pdfminer, pypdf trích đúng tiếng Việt, 4 hướng xoay. CHƯA thử Chrome/Acrobat |
| B12-02 | 12 | [mã đã giao] giới hạn | `PdfStructureOptimizer` từ chối mọi PDF có stream tạo trong bộ nhớ (content stream/ToUnicode vừa thêm) → file vừa gắn lớp chữ không bao giờ được nén | stream chưa có `COSObject` nên bị coi là "lồng trong đối tượng khác" | đánh số stream theo định danh (`IdentityHashMap`); gộp trùng theo định danh | bản Python song song: PDF lớp chữ 2353 → 1723 byte (−27%) |
| B12-03 | 12 | tham số | Sauvola k=0,34 làm mất chữ nhạt (IoU 0,655), k=0,5 mất gần hết (0,012) | mặc định phổ biến không hợp ảnh chụp mờ nhạt | k = 0,25 (`SAUVOLA_K`) | `image_algorithms_check.py` (quét k) |
| B12-04 | 12 | [trước khi vào Kotlin] thiết kế | bản đầu của `sauvolaBinarize` thu nhỏ CẢ ảnh → đổi kích thước điểm ảnh trang → trang PDF xuất ra sai kích thước vật lý (xem B-ASSUMED_DPI ở 7) | — | chỉ tính BỀ MẶT NGƯỠNG ở ≤2000 px rồi phóng lại; ảnh ra cùng cỡ | đo: IoU bằng hoặc nhỉnh hơn full-res |
| B13-01 | 13 | [trước khi vào Kotlin] | nhận hướng bản đầu đảo 180° trang BẢNG SỐ với độ tin cậy cao | dấu phẩy/chấm bị đếm là "nét xuống" | chỉ đếm nét cao ≥ 0,35 x-height + yêu cầu đủ số nét + 3-sigma + từ chối khi thiếu đối lập | `orientation_check.py`: 480 trang, 0 sai; số/chữ hoa/trắng/nhiễu bị từ chối |
| B13-02 | 13 | [trước khi vào Kotlin] | nhận hướng từ chối gần hết trang NGHIÊNG | chỉ thấy 1 dải dòng khi trang nghiêng | làm thẳng trước khi bỏ phiếu; chọn trục chữ bằng điểm profile sau làm thẳng | cùng script: nghiêng +3/−4/+6°, nhiễu — 0 sai |
| B13-03 | 13 | [trước khi vào Kotlin] | duỗi dòng cong: chỉ thấy 5/34 dòng khi cong mạnh → từ chối | các dòng dính thành 1 khối | kiểm độ dày TỪNG CỘT thay vì cả khối | `dewarp_check.py` |
| B13-04 | 13 | [mã đã giao] rò bộ nhớ native | `ImageProcessor.detectDocumentCorners` không `release()` các `MatOfPoint` contour và kernel; nay được gọi ~5 lần/giây trong tự động chụp | — | giải phóng `contours` và `kernel` | đọc mã; chưa đo |
| B13-05 | 13 | tham số | "Xóa bóng" để quầng sáng/tối dọc viền bóng gắt | làm mờ nền rộng (480 px, 9x9, median 15, Gauss 21) | 1000 px, dilate 5x5, median 3. ĐÁNH ĐỔI: ô xám đặc (bảng) 128 → 241 bị làm sáng ⇒ dành cho trang CHỮ | `shadow_edge_check.py`: độ lệch chuẩn giấy sát viền 45,7 → 20,5 |
| B13-06 | 13 | giấy phép | water-filling (Jung 2018) là hướng mạnh hơn cho bóng gắt | README của tác giả: không dùng thương mại khi chưa xin phép (bằng sáng chế) | KHÔNG cài | đọc README (không phải tư vấn pháp lý) |
| B13-07 | 13 | [mã đã giao] độ chính xác | lớp chữ OCR dùng khung ngang-trục → lệch ở dòng nghiêng | `boundingBox` không theo góc | dùng `cornerPoints` dựng ma trận chữ | `rotated_words_check.py`: góc đường cơ sở đúng 0,00/15,00/−25,00° ở 4 hướng xoay |
| B13-08 | 13 | giới hạn | ML Kit chỉ Latin | — | thêm 4 mô hình Hán/Nhật/Hàn/Devanagari + hộp chọn hệ chữ | chưa build; kiểm lại số phiên bản khi build |
| B13-09 | 13 | chẩn đoán, KHÔNG sửa được | vùng bôi chọn lớp chữ chỉ cao ~52% trong poppler | poppler tự chọn ascent/descent cho Type3 (thử FontDescriptor, FontBBox lớn: không giúp, FontDescriptor còn tệ hơn); pdfminer đo đúng | giữ nguyên | `highlight_height_check.py` |
| B13-10 | 13 | [mã đã giao] LỖI BIÊN DỊCH | `MainActivity` thiếu import `SearchablePdfBuilder`, `PdfSecurityTools`, `OcrHelper`, `PdfObjectRecompressor` | các lệnh vá import bằng `str.replace` KHÔNG báo lỗi khi mẫu không khớp ⇒ import không bao giờ được thêm | thêm 4 import; bài học: dùng script rà import (mục 9) sau mọi lần vá bằng tay | script rà import (`findall` định danh tự viết ↔ import) |
| B14-01 | 14 | giới hạn | dewarp chưa sửa độ co ngang gần gáy | — | mô hình trụ + camera lỗ kim, độ dài cung (mục 4.21) | sai số lưới chấm 2,36% → 1,21% → 0,62% (27 ca mô phỏng vật lý) |
| B14-02 | 14 | tham số | camera gần: dòng cong tới 8,6% chiều cao ⇒ cổng 8% từ chối | cổng quá chặt | trần 12% (`MAX_DISP_FRACTION`) | `dewarp_horizontal_check.py` (không còn ca bị từ chối) |
| B14-03 | 14 | [lệch tài liệu] | các mục hiện trạng §2/§3/§4.1/§4.2/§4.5/§5/§6/§8/§10 + README còn mô tả iText/targetSdk 34/AGP 8.5.2; thiếu class/layout phiên 11–14 | tài liệu không được cập nhật cùng lúc với mã | sửa từng mục, đánh dấu lịch sử | `doc_sync_check.py` (cấu trúc) |
| B14-04 | 14 | [lệch tài liệu] | bản Python Sauvola/xóa bóng khác Kotlin; script chép ở nhiều thời điểm nên import chéo hỏng; nhiều số liệu trong tài liệu không tái hiện được | chép tay, không chạy lại | đồng bộ bản Python, dựng lại `tools/verify`, thay số cho đúng kết quả script | chạy lại 11 script |
| B14-05 | 14 | [lệch tài liệu] | TÀI LIỆU THIẾU nhật ký/bug/chẩn đoán của phiên 11–14: mục 7 không có phiên 11+, mục 8 và 9 không có phiên 12+; mục 7 thiếu 7 lỗi đã ghi ở mục 0; không có danh mục tính năng; công cụ E-ink và `TextResultActivity` không có mục mô tả riêng | lần kiểm toán đầu của tôi kiểm sai trục (cấu trúc/phiên bản/hằng số) thay vì tường thuật — người dùng chỉ ra | mục 7.1, 7.2, 8, 9 (bảng chẩn đoán), 11 (danh mục tính năng), 12 (nhật ký thay đổi) | `doc_sync_check.py` mục 7: mọi ID ở bảng nhật ký phải có trong mục 7 và ngược lại |
| B15-01 | 15 | [hạ tầng CI] | Actions run #7 thất bại ở bước "Docs sync check": `python3: can't open file .../tools/verify/doc_sync_check.py`. Repo GitHub chỉ có `.github/workflows` và `DocScanner.zip` (zip chưa giải nén) nên `tools/`, `app/`, `settings.gradle` không tồn tại ở gốc repo | mã nguồn được đẩy lên dưới dạng tệp zip. Phát hiện kèm theo: bước "Licence guard (source)" cũ QUA ÂM THẦM trên repo trống (grep thoát mã 2 khi thiếu thư mục, mà `if grep` chỉ coi mã 0 là "tìm thấy") | `.github/workflows/android-build.yml`: bước "Locate the project" tự giải nén `DocScanner.zip` nếu thiếu `settings.gradle` (kèm cảnh báo), báo lỗi rõ khi thiếu cả hai, kiểm 5 đường dẫn bắt buộc; licence guard phân biệt mã 0/1/≥2 | giả lập 5 tình huống (chỉ có zip / đã giải nén / repo trống / zip sai / cài lại iText): đúng kết quả cả 5; chạy lại thật trên Actions CHƯA |
| B15-02 | 15 | [hạ tầng CI] | Actions run #11 qua được "Locate the project", licence guard và docs sync, rồi thất bại ở "Set up Android SDK": `Warning: Failed to find package 'tools'`, `sdkmanager` thoát mã 1 | `android-actions/setup-android@v3` mặc định cài danh sách `tools platform-tools`; Google đã ngừng phát gói `tools` cũ (README của chính action ghi rõ: yêu cầu nó sẽ lỗi `Failed to find package 'tools'`) | `.github/workflows/android-build.yml`: `with: packages: ''` (input có tài liệu, bỏ qua danh sách mặc định). Không mất gì: platform 36 + build-tools 36.0.0 đã được cài tường minh ở bước "Install SDK platform 36" ngay sau, và bản build không gọi `adb` (platform-tools). Tra cứu: README `android-actions/setup-android` (bản v3 và bản mới) | đọc 2 nguồn khớp nhau; chạy lại thật trên Actions CHƯA |
| B16-01 | 16 | [lỗi thật trong mã đã giao] | `TextPdfBuilder`: đoạn tiếng Trung/Nhật (không dấu cách), URL hoặc dãy số dài hơn khổ chạy ra ngoài lề phải trang PDF | `wrapText` tách bằng `" "` — cả đoạn là MỘT "từ" | điểm ngắt theo UAX #14 (`BreakIterator`) + `TextWrapper` tham lam, cắt theo code point khi mảnh quá rộng | `text_wrap_check.py` (thuật toán cũ làm tràn ZH/JA/URL/DIGITS; mới 0 dòng tràn trên 12 mẫu x 3 khổ + 900 đoạn ngẫu nhiên; 3 đột biến bị bắt) |
| B16-02 | 16 | [lỗi tiềm ẩn trong mã đã giao] | EPUB có thể không mở được khi văn bản chứa mã điều khiển (U+0000–0008, 000B, 000C, 000E–001F), surrogate lẻ, U+FFFE/FFFF | `EbookBuilder.esc` chỉ escape `& < > " '`, không loại ký tự mà XML 1.0 cấm hẳn; OCR và lớp chữ PDF có thể sinh ra chúng | `xmlSafe` loại chúng trước khi escape (dùng cho cả EPUB lẫn FB2) | `fb2_check.py`: `xmllint` từ chối bản chưa làm sạch, chấp nhận bản đã làm sạch; đột biến "bỏ làm sạch" bị bắt |
| B16-03 | 16 | [rủi ro tránh được trước khi giao] | nhúng lớp chữ vào PDF trong `PdfExporter.exportSession` sẽ chạy PdfBox + dựng trang trên LUỒNG CHÍNH (hàm này được gọi từ `lifecycleScope.launch` mặc định) → nguy cơ ANR | — | `ocrExportedPdf` tự bọc `withContext(Dispatchers.Default)` | đọc mã (chưa chạy) |
| B16-04 | 16 | [bài kiểm sai, không phải mã sai] | lần chạy đầu `text_wrap_check.py` báo 12 "LỖI" | bài kiểm: (1) không phân biệt ngắt ở dấu cách với cắt giữa từ, (2) so "dòng đầy" bằng độ rộng có kerning với độ rộng cộng từng ký tự, (3) coi kinsoku là tính chất của thuật toán (thực ra của bộ tách dòng; JDK không áp LB13) | cho Java trả điểm ngắt và kiểm tính chất độc lập nguồn điểm ngắt | chạy lại: 0 lỗi; 3 đột biến bị bắt |
| B16-05 | 16 | [lỗ hổng bài kiểm] | đột biến "tách chữ khỏi dấu kết hợp" LỌT HAI LẦN (kể cả sau khi thêm mẫu NFD dài) | bảng độ rộng gán dấu = 0 ⇒ thêm dấu không bao giờ làm vượt khổ ⇒ đoạn bảo vệ trong `splitInside` không bao giờ chạy | thêm biến thể bộ đo cho dấu rộng 4 (phông thiếu glyph dấu / dấu rơi về phông dự phòng) | đột biến bị bắt (3 lỗi); bản gốc 0 lỗi |
| B16-11 | 16 | [lỗi có sẵn từ lượt FB2] | tệp `.fb2` xuất ra không hiện trong "Tài liệu đã xuất" | bộ lọc `refreshHistory` chỉ liệt kê `pdf/epub/docx/txt` | thêm `fb2, xlsx, pptx, html, md` | đọc mã (chưa chạy) |
| B16-12 | 16 | [lỗi có sẵn từ phiên 15] | chia sẻ tệp Word (.docx) đã xuất gửi đi kiểu `text/plain` | `shareFile` có bảng MIME riêng chỉ biết pdf/epub | dùng `FileUtils.mimeTypeFor` (thêm xlsx, pptx, html, md, fb2, vcf, csv) | đọc mã |
| B16-13 | 16 | [lỗi thật của mã mới, bắt bởi bài kiểm] | `TableExtractor`: ô dài nhất của cột căn phải (vd tiêu đề "Thành tiền") bị xếp sang cột bên trái | ranh giới đặt ở GIỮA khe "dung sai", khe này lấn vào đầu cột phải | ranh giới = điểm bắt đầu phần khe không hàng nào chạm (đã thử và bỏ hai hướng khác, xem 4.30) | `export_check.py`: 800 bảng khớp từng ô, đột biến "ranh giới giữa khe" bị bắt |
| B16-14 | 16 | [lỗi thật của mã mới, bắt bởi bài kiểm] | `InvoiceFields`: ngày sai khi có ngày thanh toán dạng khác; "Ký hiệu hóa đơn:" không nhận; số `10` của "(đã gồm VAT 10%):" bị lấy làm tổng | chọn ngày theo kiểu viết thay vì vị trí; nhãn thiếu biến thể; phần trăm lẫn vào số tiền | ngày đầu tiên theo vị trí; nhãn `ky hieu( hoa don)?`; bỏ số theo sau `%` | `extract_check.py` 1500 hoá đơn; đột biến bị bắt |
| B16-15 | 16 | [điểm yếu của luật, thấy khi nghĩ với văn bản thật + bắt bởi bài kiểm] | `ContactCard`: website thành chữ thường không dấu; tên "Lê Quân Việt" thành địa chỉ; "Tú Vân" thành chức danh tư vấn | khớp trên bản bỏ dấu rồi lấy giá trị từ chính bản đó; từ khoá quá ngắn | cắt từ dòng gốc; địa chỉ cần từ khoá VÀ chữ số/dấu phẩy; bỏ "tu van"; "cong ty " có dấu cách | `extract_check.py` 1200 danh thiếp; đột biến bị bắt |
| B16-16 | 16 | [thiếu sót trong mã đã giao] | 7 chuỗi có dấu ngoặc kép trần ("Lưu & thoát"...) mất dấu khi hiển thị | Android coi `"` không escape là dấu bao bọc và bỏ nó | thêm `\"`; `strings_check.py` giữ cho không tái diễn (cả nháy đơn — lỗi biên dịch aapt2, hiện không có) | `strings_check.py` (679 chuỗi; thử âm tính) |
| B16-17 | 16 | [lỗi biên dịch, bắt bởi rà tĩnh] | `MainActivity` dùng `Bitmap` nhưng thiếu import | viết mã mới không kiểm import | thêm `import android.graphics.Bitmap` | `static_refs_check.py` bắt trước khi giao |
| B17-01 | 17 | [tìm thấy bởi mô phỏng, trước khi vào Kotlin] | đổi tên hàng loạt: hai tệp chỉ khác hoa/thường (`x.pdf` và `x.PDF`) nhận CÙNG một tên mới | tập tên viết thường và bỏ "tên cũ của tệp này" khỏi tập: tệp thứ hai bỏ luôn tên MỚI của tệp thứ nhất | bộ đếm tên đang có + tập tên đã gán; chỉ tên y nguyên của chính tệp mới được trùng | `trash_rename_check.py`: 62 lỗi -> 0 trong 2 000 ca |
| B17-02 | 17 | [chú thích sai, bắt bởi bài kiểm] | chú thích của `findPhrase` nói "thue nha" không khớp "bạn thuê nhàn", trong khi quy tắc (từ cuối khớp TIỀN TỐ) làm chúng khớp | viết chú thích theo ý định trước khi chạy ví dụ | sửa chú thích + ca kiểm: khớp "thuê nhà" và "thuê nhàn", không khớp "thuê ở nhà" | `text_markup_check.py` ca tay |
| B17-03 | 17 | [tìm thấy bởi vòng đi-về] | `smsto:số:nội dung` mà nội dung có dấu `?` bị hiểu thành dạng `sms:số?body=` (mất nội dung) | quy tắc chọn dạng dựa vào việc chuỗi có `?` thay vì dựa vào tiền tố | `smsto:` luôn tách ở dấu hai chấm đầu; chỉ `sms:` mới xét `?body=` | `barcode_content_check.py`: 2 ca lệch -> 0 |
| B17-04 | 17 | [phát hiện khi rà lại, trước khi chạy] | (1) mật khẩu Wi-Fi thật sự bắt đầu và kết thúc bằng `"` mất ngoặc kép; (2) ký tự ngoài BMP (emoji) bị hỏng khi giải mã `%HH` | (1) bỏ ngoặc kép sau khi đã gỡ escape nên không phân biệt được ngoặc bao quanh với ngoặc thật; (2) ghi từng `Char` vào bộ đệm byte | (1) ghi nhận từng ký tự đã escape hay chưa, chỉ bỏ ngoặc KHÔNG escape; (2) chỉ gom các `%HH` liền nhau thành byte, ký tự khác chép nguyên | `barcode_content_check.py` giữ ca chống tái phát |
| B17-05 | 17 | [tìm thấy bởi kiểm chứng máy quét giả] | eSCL: vùng quét tối đa lấy từ phần tử `MaxWidth/MaxHeight` ĐẦU TIÊN trong XML (khay Platen) cho mọi nguồn: máy chỉ có khay giấy, hoặc khay dài hơn kính, quét sai vùng | đọc con số theo thứ tự tài liệu thay vì theo nguồn được chọn | đọc `MaxWidth/MaxHeight` BÊN TRONG phần tử `Platen` và `Adf` riêng; `fit` lấy theo nguồn đã chọn | `escl_check.py`: 3 ca lệch -> 0 |
| B17-06 | 17 | [phát hiện khi đọc mã] | ghép PDF làm mất lớp chữ, mục lục và chất lượng vector, file phình to | `PdfExporter.mergePdfs` rasterize mọi trang rồi dựng lại bằng `PdfDocument` | ghép nguyên bản bằng `PDFMergerUtility.appendDocument` + mục lục ghép (`PdfBookmarks.mergeFiles`); cách cũ chỉ còn làm dự phòng | `bookmarks_check.py`: pdftotext lấy được chữ trang ghép, mọi dấu trang trỏ đúng |
| B18-01 | 18 | [lỗi thật của mã mới, bắt bởi bài kiểm] | `EpubToolsCheck.java` (bản phản chiếu): khoảng tách "1," hoặc "," bị nhận là hợp lệ | `String.split(",")` của Java BỎ phần rỗng ở cuối nên không thấy khoảng rỗng | `split(",", -1)`; bản Kotlin dùng `split(\',\')` giữ phần rỗng nên đúng sẵn, hai bản phải phản chiếu nhau | `epub_tools_check.py`: 611 chuỗi phạm vi khớp bản tham chiếu độc lập |
| B18-02 | 18 | [lỗi thật của mã mới, bắt bởi bài kiểm] | `MainActivity`: dùng `R.string.dialog_close` không tồn tại | tôi nhớ nhầm là có chuỗi "Đóng" dùng chung | thêm chuỗi riêng `cleanup_close` | `static_refs_check.py` (tham chiếu tài nguyên) |
| B18-03 | 18 | [phát hiện bởi bài kiểm - poppler liệt kê khác thứ tự ghi] | `PdfStructureTools.storeEmbedded` dự định dùng `PDNameTreeNode.setNames`: khoá cây tên sắp theo chuỗi, trái đặc tả khi trộn tên ASCII với tên tiếng Việt | đặc tả bắt sắp theo BYTE THÔ của chuỗi đã mã hoá (Unicode mở đầu bằng BOM FE FF đứng sau ASCII); `setNames` sắp theo chuỗi Java | tự dựng mảng `/Names` sắp bằng `compareBytes`, đặc tả tệp ghi thành đối tượng gián tiếp | `pdf_structure_check.py`: `sorted_invariant` theo byte thô + thử âm tính cây sắp theo chuỗi |
| B18-04 | 18 | [phát hiện bởi bài kiểm - độ bao phủ 61% so với qpdf] | `PdfRepair.diagnose`: tệp bị cắt đuôi (mất cả `%%EOF` và `startxref`) chỉ bị báo NHẸ | chẩn đoán trả "thiếu %%EOF" ngay, không xét tiếp `startxref` | xét `startxref` trước; thiếu `%%EOF` chỉ là mức nhẹ khi mọi thứ khác còn nguyên; tách hai mức nặng / nhẹ | `pdf_repair_check.py`: 74 lần báo nặng đều được qpdf xác nhận, bao phủ 87% |
| B18-05 | 18 | [kỳ vọng sai của thử âm tính + lệch của chính tôi] | `linearize_check.py`: thử âm tính "đổi /L" kỳ vọng qpdf thoát mã lỗi | qpdf đối chiếu /L với độ dài thật; sai thì coi là "không tuyến tính hoá" và thoát mã 0, không phải lỗi | sửa thử âm tính theo hành vi thật (kiểm không còn "no linearization errors" và `is_linearized` sai); tệp đạt có /L khớp từng byte; đồng thời làm sạch `direct_targets` (không đi sâu thêm một tầng) | `linearize_check.py`: 21 phép kiểm đạt sau khi sửa |
| B18-06 | 18 | [bắt bởi bài kiểm ở lần chạy đầu] | `layout-sw600dp/activity_main.xml` sinh ra không đọc lại được | chú thích XML đầu tệp chứa `--write`; XML cấm `--` trong chú thích | đổi nội dung chú thích (không dùng `--`) | `tablet_layout_check.py`: `lxml` đọc lại + `xmllint` đạt |
| B18-07 | 18 | [phát hiện khi rà mã tìm chuỗi Việt viết cứng] | `PdfDecorateActivity`: mẫu đánh số trang "Trang {n}" viết cứng trong mã nên nhãn tiếng Anh "Page 1" nhưng PDF vẫn in "Trang 1"; tương tự tên trang Excel / PowerPoint, tên chương và tên dự án mặc định | chuỗi nằm trong mã Kotlin thay vì tài nguyên | chuyển sang tài nguyên theo ngôn ngữ (`decorate_number_templates`, `export_page_name`, `default_chapter_name`, `default_project_name`); liệt kê 9 chỗ còn lại ở 4.45 | rà bằng bộ lọc chuỗi có dấu tiếng Việt trong tệp .kt (còn 9 chỗ đã biết, đều ghi ở 4.45); `static_refs_check` đạt |
| B18-08 | 18 | [chủ app chỉ ra yêu cầu đúng; bản đầu hiểu ngược] | bản đầu của mục đa ngôn ngữ đặt tiếng Việt làm mặc định và chỉ thêm `values-en` | hiểu "có tiếng Anh" là đủ; không đối chiếu với yêu cầu "ngôn ngữ app không có thì hiện tiếng Anh" (máy tiếng Pháp sẽ thấy tiếng Việt) | đảo cấu trúc: `values/` = tiếng Anh, `values-vi`, `values-ja`...; cả ba bộ kiểm cũ đọc `values/strings.xml` được chỉnh theo (`doc_sync_check` tìm tên điểm vào ở mọi ngôn ngữ) | `i18n_check.py`: thư mục `values*` trên đĩa = đúng danh sách; `strings_check.py`; `doc_sync_check.py` |
| B16-07 | 16 | [lỗi thiết kế, bắt được nhờ bài kiểm] | `PiiDetector`: số tài khoản có nhãn ("SỐ TÀI KHOẢN: 0490911917972", 13 chữ số tình cờ qua Luhn) bị gán loại THẺ thay vì TÀI KHOẢN (vùng che vẫn đúng, loại sai — sai khi người dùng chỉ tick một loại) | luật thẻ có ưu tiên cao hơn luật số-có-nhãn | số có nhãn ưu tiên trên thẻ (email > số có nhãn > thẻ > CCCD trần > điện thoại) | `pii_check.py` (2 000 văn bản dựng sẵn bắt được; 4 đột biến) |
| B16-08 | 16 | [rủi ro tránh được trước khi giao] | hộp chọn loại của "Tự động tìm" sẽ KHÔNG hiện danh sách | `AlertDialog` có `setMessage` thì danh sách `setMultiChoiceItems` không hiển thị (hai thứ loại trừ nhau) | bỏ `setMessage`, chuyển cảnh báo sang dòng gợi ý `redact_hint` trên màn hình | đọc mã (chưa chạy) |
| B16-09 | 16 | [lỗi tiềm ẩn trong mã đã giao] | chế độ tối: theme DayNight không có màu đêm ⇒ EditText / hộp thoại nhận chữ sáng trên nền sáng; chữ phụ ban ngày #757575 trên #F5F5F5 chỉ 4,23:1 (< 4,5) | thiếu `values-night`; màu chữ phụ chọn theo nền trắng | `values-night` (màu + theme) và `text_secondary` #616161 | `night_theme_check.py` (4 đột biến); chưa xem trên máy |
| B16-10 | 16 | [thiếu sót trong mã đã giao] | 30/48 ảnh/nút ảnh không có mô tả — TalkBack đọc "chưa gắn nhãn" | không ai kiểm trợ năng | `importantForAccessibility="no"` cho biểu tượng trang trí, `contentDescription` cho ảnh có nghĩa | `accessibility_check.py` |
| B16-06 | 16 | [lệch tài liệu] | tài liệu lệch mã dù `doc_sync_check` đạt: 2 dòng cùng số 35 trong mục 11; câu "MỌI tính năng CHƯA build" / "Kotlin chưa build lần nào" / "54 file hiện tại" sai sau run #18; mô tả thẻ Ebook/Chuyển đổi chưa nhắc FB2 | script chỉ kiểm tên file/lớp/hằng số, không kiểm số thứ tự, tên thẻ trích dẫn hay câu nói về trạng thái; các câu "chưa build" cũ không có chỗ nào là nguồn duy nhất | sửa 6 chỗ; khối "Trạng thái build hiện hành" ở mục 0 là nguồn duy nhất; `doc_sync_check.py` kiểm 8 (số thứ tự, tên thẻ trong `strings.xml`, khối trạng thái, câu cấm) | 4 đột biến bị bắt (một lần đầu nhắm nhầm dòng) |
| B15-03 | 15 | [biên dịch Kotlin — LẦN ĐẦU mã phiên 1-15 được biên dịch] | Actions run #15: `compileDebugKotlin` thất bại với **11 lỗi** (ảnh chụp màn hình log do người dùng gửi, tìm "e: file" ra 11 kết quả): (1) `ProjectSummaryActivity.kt:47` `No value passed for parameter 'onPrint'`; (2-4) `DocumentEnhancer.kt:257,308` và `PageOrientation.kt:76` `Unresolved reference 'getRotationMatrix2D'`; (5-10) `ImageProcessor.kt:76,77,80,82,134` `Unresolved reference` cho `contourArea` ×2, `arcLength`, `approxPolyDP`, `getPerspectiveTransform` (+ `:76:34 Cannot infer type for this parameter` là hệ quả của `contourArea`); (11) `PdfExporter.kt:124` `Suspend function 'recognize' can only be called from a coroutine` | **Ba nguyên nhân gốc.** (a) **OpenCV 5 tách module**: `org.opencv:opencv:5.0.0.1` đã chuyển các hàm hình học khỏi `Imgproc` sang lớp mới `org.opencv.geometry.Geometry` — `contourArea`, `arcLength`, `approxPolyDP`, `getPerspectiveTransform`, `getRotationMatrix2D` (và theo wiki "OpenCV 4 to 5 migration": `convexHull`, `convexityDefects`, `isContourConvex`, `minEnclosingCircle`, `minEnclosingTriangle`, `minAreaRect`, `fitEllipse`, `Subdiv2D`). Mã phiên 1-14 viết theo API của OpenCV 4. (b) **LỖI CỦA PHIÊN 15**: thêm tham số `onPrint` vào `HistoryAdapter` nhưng chỉ cập nhật `MainActivity`, quên nơi tạo thứ hai (`ProjectSummaryActivity`). (c) `PdfExporter.writeOcrTextFile` (phiên 6) không phải `suspend` mà gọi `OcrHelper.recognize` (suspend) — lỗi từ lúc viết, chưa từng bị lộ vì chưa biên dịch | (a) 8 lời gọi đổi `Imgproc.x` → `Geometry.x` ở `ImageProcessor`, `DocumentEnhancer`, `PageOrientation` + `import org.opencv.geometry.Geometry` (xác nhận qua wiki OpenCV, tài liệu OpenCV 5.0 `geometry_shape` và báo lỗi Debian cùng chủ đề; KHÔNG đổi phiên bản OpenCV). (b) truyền `onPrint` ở `ProjectSummaryActivity`; gom thành `PdfPrintAdapter.print(context, file)` dùng chung cho cả hai nơi. (c) `suspend fun writeOcrTextFile` — hai nơi gọi (`exportSession` đã là suspend; `PageListActivity` gọi trong `withContext`) đều hợp lệ. Thêm kiểm tra tĩnh số 8 (tham số hàm tạo) — thử âm tính: bỏ `onPrint` → báo đúng lỗi này | chạy lại `static_refs_check.py` sạch; **chưa biên dịch lại**. Rủi ro còn lại: (i) nếu AAR 5.0.0.1 KHÔNG đóng gói lớp `org.opencv.geometry.Geometry`, lần build sau sẽ báo `Unresolved reference: geometry` ở dòng import — khi đó phải xem lại phiên bản OpenCV; (ii) trình biên dịch có thể còn lỗi ở giai đoạn sau (sinh mã) mà giai đoạn phân tích chưa lộ |

## 8. Cạm bẫy / hướng đã cân nhắc rồi bỏ (để không thử lại mất công)

- Định dùng **adaptive-icon XML** (`mipmap-anydpi-v26` + vector foreground/background) cho icon app
  — bỏ vì `minSdk=24` vẫn cần fallback PNG cho API 24-25, nên chuyển hẳn sang PNG thường cho mọi
  API cho đỡ phức tạp (xem mục 5.5).
- Định dùng style `Widget.Material3.Chip.Filter` cho các Chip chọn bộ lọc — bỏ vì không chắc chắn
  100% tên style này tồn tại đúng như vậy trong bản Material Components đang dùng, mà sai thì hỏng
  cả build không ai sửa kịp lúc đó (xem mục 5.6).
- Định gộp toàn bộ 3 nguồn ảnh (camera/thư viện/PDF) kể cả bước chụp camera vào chung 1 hàng đợi
  `PendingCropQueue` để code gọn hơn nữa — bỏ vì sẽ phá vỡ trải nghiệm "chụp xong hiện crop ngay,
  xong quay lại xem trước camera liền" của luồng camera (vốn là luồng chính hay dùng nhất) — quyết
  định giữ camera dùng cơ chế "single mode" riêng (trả `ActivityResult`), chỉ dùng hàng đợi cho
  thư viện ảnh/nhập PDF (xem mục 2).
- Định tạo 3 màn hình riêng cho Tách trang / Xoá & Sắp xếp / Xoay trang PDF (đúng như đề xuất ban
  đầu với người dùng) — sau đó gộp lại thành 1 màn `PdfPageEditorActivity` duy nhất (có cả xoay +
  xoá + sắp xếp + chọn-để-tách) vì cả 3 việc đều dùng chung 1 kiểu dữ liệu (danh sách trang PDF) và
  cùng 1 kiểu thao tác trên lưới ảnh — gộp lại đỡ trùng lặp code, UX cũng gọn hơn là bắt người dùng
  nhảy qua lại nhiều màn hình cho cùng 1 file.
- Định để bộ lọc E-ink chỉ có 1 preset chung (trắng đen) — sau khi người dùng chỉ ra e-ink màu đã
  phổ biến, tách thành 2 preset (văn bản/màu), rồi lại thêm preset thứ 3 "Tự động" nhận diện theo
  từng trang — xem toàn bộ diễn tiến ở mục 4.3.
- Định làm tính năng tách 2 trang thành 1 **màn hình riêng hoàn toàn** (stage 0 chặn toàn màn hình
  trước khi vào crop) — bỏ, gộp thành 1 nút "Tách 2 trang" ngay trong giai đoạn crop hiện có, chỉ
  hiện UI tách khi người dùng chủ động bấm — đỡ phải hỏi "đây có phải ảnh 2 trang không" cho MỌI
  ảnh (đa số ảnh không phải cảnh 2 trang), giảm số bước cho trường hợp thường gặp nhất.
- Định giữ nguyên hành vi "single mode quay lại camera" ngay cả sau khi tách trang (tách xong quay
  lại xem trước camera, không nhảy sang page list) — bỏ vì phải theo dõi thêm trạng thái "mode gốc
  là gì, khi nào coi là xử lý xong" phức tạp không cần thiết; chuyển hẳn sang quy tắc đơn giản "đã
  tách thì luôn xem như queue mode" (quyết định 13, mục 5).
- Định tự động ÁP DỤNG LUÔN gợi ý của `detectGutterX`/`isColorPage` mà không cho chỉnh tay (để bớt 1
  bước bấm) — bỏ, vì cả 2 đều là heuristic OpenCV thuần, chưa test với ảnh thật (mục 6), tự động áp
  dụng cứng sẽ biến 1 lần đoán sai thành lỗi không sửa được; giữ nguyên tắc "gợi ý + luôn cho sửa
  tay" cho mọi heuristic trong dự án (quyết định 12, mục 5).
- Định làm thêm định dạng MOBI/AZW3/FB2 cho ebook — bỏ MOBI/AZW3 hẳn (lý do ở quyết định 11, mục 5),
  tạm bỏ FB2 dù kỹ thuật dễ thêm (cũng chỉ là XML, tái dùng được cấu trúc `Chapter`) để không dàn
  trải, ưu tiên làm đúng EPUB/TXT trước. (Phiên 16: FB2 đã làm — 4.27; MOBI/AZW3 vẫn bỏ.)
- Định để `PdfCompressor` cũng dùng `PdfDocument` như các tính năng khác cho gọn code — bỏ ngay khi
  phát hiện `PdfDocument` không hề nén ảnh (mục 5, quyết định 14) — đổi hẳn sang tự viết PDF thô.
- Định thử "nén ảnh JPEG trước rồi decode lại thành Bitmap rồi vẽ qua `PdfDocument`" để lách qua
  giới hạn trên — bỏ ngay khi nhận ra decode ngược lại mất hết lợi ích nén (PdfDocument vẫn lưu lại
  pixel thô sau khi decode, không "nhớ" được là ảnh từng qua JPEG) — đây chính là lý do phải tự
  viết PDF thô thay vì tìm cách vòng qua `PdfDocument`.
- Định chỉ làm 1 cách nén cho trang chữ (an toàn, 1-bit+Deflate) vì lo CCITT G4 tự viết rủi ro cao
  — sau khi người dùng hỏi kỹ và yêu cầu làm cả 2 để tự chọn, đã làm CCITT G4 thật nhưng kèm quy
  trình kiểm chứng nghiêm ngặt (mục 4.11) thay vì bỏ hẳn — bài học: rủi ro cao không có nghĩa là
  "không làm được", mà là "cần kiểm chứng kỹ hơn trước khi làm".
- Cân nhắc bỏ EOFB (3 byte cuối luồng CCITT G4) vì PDF không bắt buộc khi đã có `/Rows` +
  `/EndOfBlock false` — vẫn giữ lại vì chỉ tốn 3 byte, đổi lại tương thích rộng hơn với mọi đầu đọc
  PDF (kể cả loại không tôn trọng `/EndOfBlock false`).
- **[CẬP NHẬT — quyết định này đã ĐẢO NGƯỢC, xem mục 4.11 "Sửa trực tiếp"]** Ban đầu cân nhắc thêm 1
  thư viện đọc/sửa cấu trúc PDF thật (kiểu PDFBox) để công cụ "Nén PDF" độc lập có thể sửa thẳng
  object ảnh trong PDF thay vì phải render cả trang ra ảnh rồi dựng lại từ đầu (đúng cách Ghostscript/
  qpdf làm) — LÚC ĐẦU đã bỏ, với lý do: đây sẽ là phụ thuộc ngoài ĐẦU TIÊN của cả dự án mà không có
  cách nào kiểm chứng dù chỉ 1 phần trong môi trường này. Người dùng phản đối cách trả lời đó (đúng):
  chỉ nói "cần thêm thư viện" rồi dừng lại, không thật sự đi tìm xem thư viện đó có tồn tại hay
  không, là né tránh có giải thích chứ không phải không né tránh. Đã tra lại nghiêm túc bằng
  web_search (không đoán mò): tìm ra `TomRoush/PdfBox-Android` (Apache 2.0, nhưng 3 năm không có bản
  mới, có CVE chưa vá trong dependency), `iText 7/8` (được bảo trì thật, có Android build chính
  thức, nhưng AGPL/trả phí), `DroidPDF` (Kotlin-native, mới hơn, nhưng danh sách tính năng công khai
  không xác nhận hỗ trợ đúng việc lấy-ảnh-nhúng-ra-nén-lại cần làm). Người dùng chọn iText, chấp
  nhận AGPL. **[ĐÃ BỊ THAY ở phiên 11: yêu cầu bán trả phí trên Google Play làm AGPL không còn chấp nhận được — iText đã gỡ, dùng PdfBox-Android; mục 4.18. Phần dưới là lịch sử.]** **Đã làm** — xem mục 4.11 "Sửa trực tiếp" để biết chi tiết, và bài học rút ra: "tao
  không kiểm chứng được" là lý do hợp lý để CẨN TRỌNG hơn, KHÔNG phải lý do để không thử — vẫn có thể
  làm với đầy đủ rà soát tài liệu chính thức + ví dụ thật thay vì đoán API, miễn là nói rõ phần nào
  đã xác nhận được, phần nào chưa.
- Cân nhắc bỏ EOFB (3 byte cuối luồng CCITT G4) vì PDF không bắt buộc khi đã có `/Rows` +
  `/EndOfBlock false` — vẫn giữ lại vì chỉ tốn 3 byte, đổi lại tương thích rộng hơn với mọi đầu đọc
  PDF (kể cả loại không tôn trọng `/EndOfBlock false`).


### 8.x Hướng đã cân nhắc rồi bỏ ở phiên 11–14 (đừng thử lại mất công)

- **Đóng gói iText bản thương mại / giữ AGPL và công bố mã** — bỏ: người dùng muốn bán trả phí không tốn phí bản quyền hằng năm. Mục 4.18.
- **MuPDF** (ứng viên thay iText) — loại ngay: theo hiểu biết chung cũng AGPL/thương mại (Artifex) — CHƯA tra cứu lại trong phiên. CI chặn `com.artifex`/`mupdf`.
- **OpenPDF / PDFBox desktop trên Android** — nhận định chung (CHƯA thử, CHƯA tra cứu kỹ): cả hai dựa nhiều vào `java.awt` không có trên Android; chọn bản port PdfBox-Android.
- **Font TrueType "rỗng" kiểu Tesseract cho lớp chữ OCR** — bỏ: bị ghi nhận là không hợp lệ, PDFium đọc sai `/W` (B12-01). Dùng Type3 không glyph.
- **Chép/port mã mẫu iText ("PdfCanvasEditor")** — bỏ và xoá file: nguy cơ tác phẩm phái sinh của AGPL (B11-01).
- **Thêm font Unicode (OFL) để nhúng cho lớp chữ OCR** — bỏ: Type3 không cần font; thêm font chỉ làm to APK.
- **Water-filling (Jung 2018) cho xóa bóng** — bỏ vì bằng sáng chế (B13-06). Dùng bộ lọc cổ điển cấu hình lại (B13-05).
- **Mô hình học máy dewarp (DocUNet/DewarpNet/UVDoc)** — bỏ: cần file mô hình, không tải được trong môi trường làm việc, phải kiểm giấy phép trọng số riêng.
- **Dewarp chỉ chia độ phóng đại (V1) thay vì độ dài cung (V2)** — V1 tốt hơn khi camera xa (0,09% so với 0,28–0,45%) nhưng kém ở trung bình (0,66% so với 0,62%) và ở độ cong rộng/mạnh; chọn V2 với f=0,7. Mục 4.21.
- **Ước lượng tiêu cự f từ ảnh** — không thấy cách làm từ nội dung trang; có thể truyền từ EXIF nếu có (chưa làm).
- **Nhận hướng bằng hit-or-miss SEL như Leptonica** — bỏ: phụ thuộc độ phân giải quét; dùng đếm nét theo dải dòng (B13-01).
- **Nhận hướng bằng OCR 4 hướng** — bỏ: chậm gấp 4 và phụ thuộc hệ chữ; giữ làm hướng dự phòng nếu bản hiện tại từ chối quá nhiều.
- **Sauvola k = 0,34 hoặc 0,5** — bỏ (B12-03).
- **Redaction (xoá chữ gốc dưới ô che) viết riêng** — không cần: "Chú thích PDF" đã nung ô che vào điểm ảnh rồi dựng lại PDF chỉ gồm ảnh. Chạy "PDF tìm kiếm được" sau đó để lấy lại tìm chữ.
- **PDF/A, chữ ký số** — đã tra cứu, CHƯA làm: không có veraPDF để xác nhận tuân chuẩn (không được tuyên bố "PDF/A" khi chưa xác nhận); chữ ký số cần biết BouncyCastle nào PdfBox-Android kéo theo (xem `dependencies.txt` của CI). Mục 4.20.
- **Ép `doc_sync_check` thành thước đo "tài liệu đúng"** — bỏ: nó chỉ kiểm cấu trúc (file, phiên bản, hằng số, ID bug); nội dung tường thuật phải do người viết giữ đồng bộ (mục 11, 12).

- **(Phiên 15) Khoá theo thư mục ("hidden folder") thay vì khoá cả app** — bỏ: app chưa có khái niệm thư mục tài liệu; khoá cả app một lần bao phủ lịch sử, mọi trình soạn thảo và danh sách chia sẻ,
  và code chỉ ở một chỗ (`AppLockCallbacks`). Nếu sau này có thư mục/thẻ, có thể thêm khoá riêng bên trên.
- **(Phiên 15) `BIOMETRIC_STRONG | DEVICE_CREDENTIAL`** — bỏ: androidx.biometric không hỗ trợ tổ hợp này trên Android 9–10; dùng `BIOMETRIC_WEAK | DEVICE_CREDENTIAL` (mọi sinh trắc đã đăng ký HOẶC PIN/hình mở khoá).
- **(Phiên 15) Đưa chữ ký tay đã lưu vào tệp sao lưu ZIP** — bỏ: ZIP là loại tệp hay được tải lên đám mây/gửi đi; ảnh chữ ký lấy ra được thì phá mục đích giữ nó ở bộ nhớ riêng.
- **(Phiên 15) Chữ ký bằng cách làm phẳng trang (như `PdfAnnotateActivity`)** — bỏ cho chữ ký/tem: rasterize làm mất chữ thật của PDF; thêm ảnh vào nội dung trang giữ nguyên chữ.
- **(Phiên 15) Nhãn trang bằng cách luôn vẽ thành ảnh** — bỏ: ASCII dùng Helvetica dựng sẵn thì file nhỏ hơn và chữ chọn/sao chép được; chỉ chữ ngoài ASCII mới thành ảnh.
- **(Phiên 15) Chỉ sửa từ điển Info khi đổi tiêu đề PDF** — bỏ: XMP cũ vẫn thắng ở nhiều trình đọc (đã chứng minh bằng `metadata_check.py`); luôn bỏ cả XMP cấp tài liệu.
- **(Phiên 15) Dùng `MediaBox` thay vì `CropBox` để đặt nhãn/ảnh** — bỏ: người xem và `PdfRenderer` thấy theo CropBox; dùng MediaBox làm nhãn lệch trên PDF có CropBox. (Kiểm thử cũng phải bật `-cropbox` của poppler.)

- **(Phiên 15, tiếp) Dùng BouncyCastle (`bcpkix`) để ký PDF** — bỏ: provider "BC" của Android trùng tên với bản đóng gói (phải gỡ/gắn provider), chưa chắc nằm trên classpath biên dịch, và phần cần dùng chỉ ~150 dòng DER tự viết, kiểm được bằng Java + `pdfsig` + `openssl`.
- **(Phiên 15, tiếp) Khoá ký lưu trong tệp PKCS#12 của app** — bỏ: cần mật khẩu bảo vệ tệp và dễ bị sao chép cùng dữ liệu app; Android Keystore giữ khoá không xuất được và còn tự sinh chứng thư tự ký.
- **(Phiên 15, tiếp) Lưu ký số bằng `PdfStructureOptimizer.save` (ghi lại cả tệp)** — bỏ: chữ ký phải phủ đúng các byte đã ghi; dùng `saveIncremental` để nối bản cập nhật và giữ nguyên byte gốc.

- **(Phiên 15, tiếp) So sánh PDF bằng trích văn bản** — bỏ: bản quét không có văn bản, và người dùng muốn thấy CHỖ nào khác; so ảnh dùng được cho cả bản quét lẫn PDF chữ, kể cả dấu/chữ ký.
- **(Phiên 15, tiếp) Xử lý hàng loạt kèm nén** — bỏ: nén cần chọn mức nén (một tham số phức tạp) nên không dùng chung một câu trả lời cho mọi tệp được.
- **(Phiên 15, tiếp) Điền biểu mẫu bằng `acroForm.flatten()`** — bỏ: chưa chắc có/đúng trong PdfBox-Android 2.0.27; không làm phẳng thì ô vẫn sửa được ở trình đọc, và không phải dựa vào một API chưa xác nhận.
- **(Phiên 15, tiếp) Mỗi lần "Thêm vào trang" ghi thẳng ra thư mục xuất** — bỏ: điền một bản quét cần nhiều lần, mỗi lần một tệp sẽ rải rác; dùng bản làm việc tạm và một bước "Lưu & thoát".

## 9. Rủi ro build & cách đã giảm thiểu (viết khi chưa build được lần nào; hiện trạng: mục 0)

**Trước hết, ưu tiên test khi build được lần đầu tiên**: `PdfTextEditActivity`/`PdfTextEditor` (mục
4.17, phiên thứ 8) — tính năng DUY NHẤT ghi trực tiếp vào object chữ thật của 1 PDF có sẵn, chưa mở
thử lần nào, lỗi ở đây cho ra PDF hỏng chứ không phải lỗi giao diện thông thường. Xem mục 6/10.

Vì môi trường viết code này **không có Android SDK, không có mạng để chạy Gradle**, không có cách
nào build thử thật. Để giảm rủi ro, đã làm các việc sau (viết script Python dùng 1 lần, không nằm
trong project, chỉ để tự rà soát):
- Parse toàn bộ layout XML để chắc chắn không lỗi cú pháp XML.
- Đối chiếu từng `binding.<tên>` dùng trong mỗi Activity/Adapter với đúng `android:id` có thật trong
  layout XML tương ứng — không thấy thiếu.
- Đối chiếu toàn bộ `R.string/id/drawable/color/menu/layout` dùng trong code Kotlin với resource
  thật sự tồn tại — không thấy thiếu.
- Đếm cân bằng ngoặc `{}`/`()` trong mọi file `.kt` — không thấy lệch.
- Kiểm tra trùng tên `<string name="...">` trong `strings.xml` — không có trùng.
- Tra cứu web (không đoán từ trí nhớ) để xác nhận: artifact OpenCV, API `OpenCVLoader.initLocal()`,
  cách dùng `gradle/actions/setup-gradle` không cần wrapper, `android-actions/setup-android` còn
  được bảo trì, API `ChipGroup.setOnCheckedChangeListener` còn tồn tại dù deprecated.
- **(Thêm ở phiên sau)** Đối chiếu số tham số BẮT BUỘC (không có giá trị mặc định) của mọi hàm `fun`
  tự định nghĩa trong từng file `.kt` với số tham số thực tế truyền vào ở mọi lời gọi cùng file (đếm
  dấu phẩy ở độ sâu ngoặc = 0, có bỏ qua string/char/comment) — cách này soi ra lỗi thật ở mục 7
  (`setBusy()` thiếu tham số) mà 5 cách rà soát phía trên KHÔNG bắt được (chúng chỉ đối chiếu
  resource/XML, không đối chiếu chữ ký hàm Kotlin với nhau). Nên chạy lại cách này mỗi khi sửa xong
  1 đợt code, giống các cách phía trên.
- **(Thêm ở phiên thứ 4)** Viết lại cách rà số tham số ở trên thành bản ĐỐI CHIẾU TOÀN DỰ ÁN (không
  chỉ trong cùng 1 file nữa): gom chữ ký MỌI hàm `fun`/constructor (kể cả data class) ở MỌI file
  `.kt` thành 1 bảng tra theo tên, rồi so với MỌI lời gọi ở MỌI file — bắt được cả lỗi gọi sai tham
  số CHÉO FILE (ví dụ 1 hàm ở `util/` bị gọi sai từ 1 Activity khác file), điều cách cũ (chỉ so trong
  cùng file) bỏ sót. Chạy trên toàn bộ 54 file `.kt` lúc đó (phiên 4; nay 110) (kể cả luồng Dự án ở mục 4.15 và
  `PdfObjectRecompressor.kt`), thu được 413 chữ ký cho 280 tên hàm khác nhau, đối chiếu 457 lượt gọi.
  Kết quả: 41 chỗ bị báo "lệch số tham số", nhưng kiểm tra tay xác nhận CẢ 41 CHỖ ĐỀU CÙNG 1 LOẠI BÁO
  ĐỘNG GIẢ — mọi Activity đều gọi `finish()` kế thừa từ `android.app.Activity` (0 tham số, đúng), tên
  này trùng với 1 hàm riêng không liên quan `PdfByteWriter.finish(catalogObjNum: Int)` (1 tham số bắt
  buộc, dùng nội bộ trong chính `PdfByteWriter.kt` để đóng object PDF) — vì cách rà này chỉ so tên
  hàm, không biết class/phạm vi (không phải trình biên dịch Kotlin thật), nó đối chiếu nhầm 2 hàm
  trùng tên nhưng khác class này với nhau. **Ghi chú cho lần rà sau**: nếu thấy lại đúng 41 báo động
  này (hoặc bất kỳ báo động nào có dạng "gọi `finish(...)` với 0 tham số nhưng cần 1..1") thì ĐÓ LÀ
  BÁO ĐỘNG GIẢ ĐÃ BIẾT, không cần kiểm tra lại - chỉ cần kiểm tra tay các báo động MỚI (tên hàm khác,
  hoặc file khác `PdfByteWriter.kt` cho `finish`). Không phát hiện lỗi thật nào mới ở lần chạy này.
- **(Thêm ở phiên thứ 5)** Sau khi thêm `PdfObjectRecompressor.wrapAsMinimalPng()` (mục 4.11, dựng
  file PNG tối giản để bọc byte Predictor), rà lại thấy thêm ĐÚNG 1 LOẠI báo động giả MỚI: 7 chỗ gọi
  `write(...)` (các lệnh ghi từng byte header PNG qua `ByteArrayOutputStream.write()` có sẵn của
  Java) bị đối chiếu nhầm với `Ccitt4Encoder.kt`'s `BitWriter.write(length, value)` — 1 hàm riêng
  không liên quan, chỉ trùng tên, khác hẳn class. Kiểm tra tay xác nhận cả 7 đều vô hại. **Ghi chú
  cho lần rà sau**: báo động dạng "gọi `write(...)` với 1 tham số nhưng cần 2..2 (theo
  `Ccitt4Encoder.kt`)" cũng là BÁO ĐỘNG GIẢ ĐÃ BIẾT, cùng loại với `finish()` ở trên — chỉ do trùng
  tên hàm giữa các class khác nhau, không phải lỗi thật.
- Cũng đã chạy lại cả 5 cách rà soát còn lại (XML, `binding.<id>`, `R.*`, cân bằng ngoặc, trùng tên
  string) trên TOÀN BỘ code hiện tại (không chỉ phần mới sửa) — không phát hiện gì.

**Rủi ro riêng của luồng Dự án (mục 4.15)** — khối lượng code mới lớn nhất từ trước đến giờ trong 1
phiên làm việc (9 Activity + 3 adapter + 10 layout + 2 file model + 1 file util hoàn toàn mới), nên
rủi ro có lỗi build cao hơn hẳn các phần trước, dù đã chạy đúng 6 cách rà soát tĩnh ở trên trên toàn
bộ code MỚI (không chỉ phần cũ) và đối chiếu tay chữ ký từng hàm dùng chéo file (`ImageProcessor`,
`PdfExporter`, `PdfCompressor`, `OcrHelper`, `EbookBuilder`, `CropOverlayView`, `SplitLineOverlayView`
...) so với định nghĩa gốc trước khi dùng — không dựa vào trí nhớ cho bất kỳ chữ ký hàm nào. Vẫn có
những thứ CHỈ build/chạy thật mới biết chắc, đặc biệt: `ItemHistoryBinding`/`ActivityEbookEditor
Binding` dùng lại ở 2 Activity khác nhau (`ProjectAdapter`/`ProjectSummaryActivity` và
`ProjectEbookActivity`) có build đúng như lý thuyết ViewBinding hay không; layout `activity_project_
edit.xml` tái dùng `CropOverlayView`/`SplitLineOverlayView` (vốn viết cho `CropActivity`) có hoạt
động đúng khi được nhúng trong 1 `ConstraintLayout` khác cấu trúc constraint không.

**Những gì KHÔNG được kiểm tra** (vì không thể, cần build thật mới biết):
- AGP/Kotlin/Gradle/thư viện có thật sự tương thích với nhau ở đúng phiên bản đã chọn hay không.
- OpenCV AAR có tải/link đúng trên môi trường CI (Ubuntu runner) hay không.
- Toàn bộ luồng runtime (permission camera, CameraX bind lifecycle, ML Kit model tải/chạy...) có
  chạy đúng trên thiết bị thật hay không.

→ **Khi build lần đầu có lỗi, đó là chuyện bình thường đã lường trước — gửi log lỗi để sửa tiếp,
không phải hiện tượng bất thường.**


### 9.x Bảng chẩn đoán nhanh cho tính năng phiên 11–15 (triệu chứng → nghi ngờ đầu tiên → cách kiểm)

Mọi tính năng ở đây CHƯA chạy trên Android. Khi build/chạy lần đầu, tra bảng này trước.

| Triệu chứng | Nghi ngờ đầu tiên | Cách kiểm |
|---|---|---|
| Build lỗi "Unresolved reference" ở `MainActivity` | thiếu import (B13-10) | chạy script rà import (định danh tự viết ↔ `import`) |
| Build lỗi ở các hàm `com.tom_roush.pdfbox.*` | API nhóm "Trung bình": `PDDocument.load(File, MemoryUsageSetting)`, `PDPageContentStream(..., APPEND, true, true)`, `appendRawCommands`, `COSDocument.createCOSStream`, `PDFTextStripper`, `PDPage.getCropBox/getRotation`, `StandardProtectionPolicy`/`encryptionKeyLength`, `LosslessFactory.createFromImage(doc, Bitmap)`, `PDDocument.isAllSecurityToBeRemoved` | đọc đúng chữ ký trong log, sửa theo bản 2.0.27.0 |
| Build lỗi ML Kit "Could not find ...text-recognition-chinese" | phiên bản 16.0.1 của 4 artifact chưa kiểm | xem `dependencies.txt` của CI; hạ/nâng cho khớp, hoặc xoá dòng và mục tương ứng trong `OcrHelper.OcrScript` |
| Lên Play bị từ chối | `applicationId` bắt đầu bằng `com.example`; hoặc `.so` OpenCV/ML Kit chưa căn lề 16 KB | biến `APP_ID`; kiểm AAB bằng công cụ của Android |
| Giao diện bị che dưới thanh trạng thái / nút bấm dưới bị che | `EdgeToEdgeInsetsCallbacks` không áp (máy API < 35 thì cố ý không làm gì), layout con tự nhận inset | thử Android 15+; kiểm `R.id.toolbar` có trong layout màn hình đó |
| "PDF tìm kiếm được" chạy xong nhưng không tìm được chữ | (1) trang đã bị coi là có chữ thật (bỏ qua); (2) hệ chữ sai; (3) trình đọc không hỗ trợ Type3+ToUnicode | thông báo "% từ khớp" lúc xong (đọc lại bằng PdfBox); mở bằng ≥2 trình đọc; kiểm `extractChunks` của trang |
| Lớp chữ lệch so với chữ in | tọa độ từ OCR ↔ trang: DPI render (200), `/Rotate`, CropBox | `rotated_words_check.py` (toán học đã đúng); in `bitmapW/H` và `visibleWidth/Height` ra log |
| PDF tối ưu "không nhỏ hơn" hoặc rơi về file thường | `PdfStructureOptimizer` ném `Unsupported` (mã hoá, tên ngoài ASCII, >40 MB) hoặc `PdfVerify` không qua | `Outcome.reason` (cần log ở nơi gọi); thử `structure_optimizer_check.py` với đúng file |
| "Sửa chữ" báo `UnsupportedFont` với PDF Word/Chrome | font Type0 không có `/ToUnicode` usable | kiểm font có `/ToUnicode` không; `ToUnicodeReverse.parse` trả rỗng? |
| "Trắng đen+" mất chữ nhạt / còn lốm đốm | `SAUVOLA_K` (0,25) | `image_algorithms_check.py`; chỉnh k |
| "Xóa bóng" làm sáng bảng/ô xám | đánh đổi đã biết (B13-05) | dùng "Trắng đen+" hoặc "Gốc" cho trang có vùng nền đặc |
| "Tự xoay" xoay sai hướng / không làm gì | `PageOrientation` từ chối là bình thường (số, chữ hoa, trang trắng, chữ không Latin); xoay SAI là lỗi thật | siết `MIN_CONF`/`MIN_COUNT`; chạy `orientation_check.py`; báo lại ảnh |
| "Duỗi dòng cong" kéo giãn quá tay / không làm gì | `F_REL` (0,7); cổng từ chối (<4 dòng, dịch chuyển <2 px hoặc >12%, không giảm ≥15% độ cong) | hạ `F_REL` xuống 0,6; `dewarp_horizontal_check.py`; gáy phải chạy dọc |
| "Tự động chụp" không bắn / bắn quá sớm | `CaptureStability` (HOLD_MS 1200, MOVE_TOL 0,018, SHARP_KEEP 0,6); `detectDocumentCorners` trả null; thiếu quyền camera | `stability_check.py` mô phỏng; log trạng thái từ `FrameDocumentAnalyzer` |
| RAM tăng dần khi bật tự động chụp | rò native Mat trong `FrameDocumentAnalyzer`/`detectDocumentCorners` (B13-04 đã sửa phần có sẵn) | Android Studio profiler → native memory |
| Mật khẩu PDF: mở được mà không hỏi mật khẩu / không mở được bằng mật khẩu đúng | `StandardProtectionPolicy` + `encryptionKeyLength=256` không hợp bản PdfBox-Android | `protect()` tự kiểm cả hai chiều và xoá file nếu sai ⇒ thông báo "không xử lý được file"; kiểm log |
| Watermark lệch tâm / sai góc | `/Rotate`, CropBox | `watermark_check.py` (45,3–45,4° đo được trên 4 hướng + CropBox) |
| CI: `can't open file .../tools/verify/doc_sync_check.py` (hoặc thiếu `settings.gradle`) | repo chỉ chứa `DocScanner.zip`, mã nguồn chưa giải nén ở gốc repo | mở tab Code trên GitHub: phải thấy `app/`, `tools/`, `build.gradle`, `settings.gradle` cạnh `.github/`; bước "Locate the project" tự giải nén zip và in cảnh báo |
| Bước "Licence guard (source)" xanh nhưng không có gì để quét | `grep` thoát mã 2 khi thiếu thư mục, bị `if grep` coi như "không tìm thấy" | phiên bản mới phân biệt mã 0/1/≥2 và kiểm đường dẫn trước; xem log bước "Locate the project" |
| CI: `Warning: Failed to find package 'tools'` rồi `sdkmanager ... exit code 1` ở bước Set up Android SDK | `setup-android@v3` đòi gói `tools` (Google đã ngừng phát) | `with: packages: ''` trong workflow; kiểm `Install SDK platform 36` vẫn cài `platforms;android-36` và `build-tools;36.0.0` |
| Kotlin báo `Unresolved reference` cho tên lớp (Bitmap, File, …) | thiếu `import` | `python3 tools/verify/static_refs_check.py` (mục 6 của script) liệt kê file và tên lớp thiếu nguồn |
| CI đỏ ở "Build debug APK" nhưng không thấy dòng lỗi (log cần đăng nhập, dấu vết ngăn xếp che mất) | lỗi biên dịch nằm ở TRÊN dấu vết; người xem chỉ dán đuôi | mở trang chạy → hộp Annotations: chú thích "Compile errors (N)" liệt kê file:dòng:cột; hoặc Job summary; hoặc tải artifact `build-log` và tìm `e: file`. Workflow cũ (trước phiên 15 cuối) chưa có các bước này |
| Kotlin: `Unresolved reference 'contourArea'` (hoặc `arcLength`, `approxPolyDP`, `getPerspectiveTransform`, `getRotationMatrix2D`, `convexHull`, `minAreaRect`, `fitEllipse`…) trên `Imgproc` | OpenCV 5 chuyển hàm hình học sang `org.opencv.geometry.Geometry` | `import org.opencv.geometry.Geometry` và gọi `Geometry.x(...)`; nếu import cũng lỗi thì AAR không có module geometry — xem lại phiên bản OpenCV (mục 5) |
| Kotlin: `No value passed for parameter 'x'` sau khi thêm tham số vào hàm tạo | còn một nơi gọi chưa cập nhật | `python3 tools/verify/static_refs_check.py` (kiểm tra 8) liệt kê file và tham số thiếu |
| Kotlin: `Suspend function 'x' can only be called from a coroutine` | hàm gọi `suspend fun` mà bản thân không phải `suspend` | thêm `suspend` vào hàm gọi (kiểm tra người gọi nó cũng ở ngữ cảnh coroutine) hoặc bọc `runBlocking`/`launch` đúng chỗ |

Phương pháp rà tĩnh MỚI ở phiên 13–14 (thêm vào 6 cách ở trên): (7) **rà import**: mọi định danh tự viết dùng trong file phải có import hoặc cùng package; (8) **rà cân bằng ngoặc** mọi file `.kt` sau mỗi lần vá bằng chuỗi; (9) **bản Python song song** cho mọi thuật toán ảnh/PDF mới, chạy bằng trình đọc độc lập; (10) **thử âm tính** của chính bộ kiểm (cố ý làm sai rồi xem nó có bắt được không).

## 10. Việc cần làm tiếp theo (gợi ý thứ tự ưu tiên)

00000. **(Phiên 23) Khi nâng `targetSdk` lên 37:** chạy `python3 tools/verify/local_network_check.py`; thêm `ACCESS_LOCAL_NETWORK` + xin quyền lúc chạy cho quét eSCL (4.53), nếu không thì tìm máy quét sẽ im lặng thất bại.
0000. **(Phiên 23, ƯU TIÊN SỐ 1) Chạy Actions cho mã phiên 16 -> 23 và sửa lỗi biên dịch.** Sau khi xanh, thử trình đọc EPUB (4.50) theo danh sách ở cuối 4.50. Đồng bộ `android-build.yml` (thêm bước "Kotlin lexical lint" nếu kho chưa có).
000. **(Phiên 19, ƯU TIÊN SỐ 1) Chạy Actions cho mã phiên 16 → 19 và sửa lỗi biên dịch** (vòng lặp quen thuộc ở 0e0). Chưa có dòng Kotlin nào của bốn phiên này được biên dịch. Sau khi xanh: thử trên máy theo thứ tự rủi ro của phiên 19: (1) "Chuyển đổi" → "Tệp Markdown / HTML / Word" với một tệp `.md` có tiêu đề / danh sách / bảng tiếng Việt, một `.docx` từ Word, một `.html` khai báo `charset=windows-1252`; (2) "Chuyển đổi" → "Bảng (.csv / .tsv)" với CSV xuất từ Excel (dấu `;`, Windows-1252) và một bảng 8 cột (phải chuyển sang khổ ngang); (3) menu "Gộp trang & in sổ gấp" → "Áp phích", in thật ra giấy ở 100 %, kiểm dải chồng 10 mm khớp khi dán; (4) PDF → TIFF đen trắng và màu, mở bằng Windows Photos / Preview / IrfanView (kiểm màu không đảo) và `tiffinfo`; (5) "Sửa mục lục" → đưa lên / xuống / thụt vào / đưa ra, lưu rồi mở bằng Chrome và Adobe.
000b. **(Phiên 20)** Sau khi build xanh, thử trên máy theo thứ tự rủi ro: (1) "Chuyển đổi" với một `.odt`, `.pptx`, `.rtf` và một `.xlsx` nhiều trang tính (4.48.2); (2) mở một PDF đã ký số bằng một công cụ ghi lại PDF và xem hộp thoại cảnh báo (4.48.1); (3) nhấn giữ một tài liệu → "Phân tích tài liệu" (4.48.3); (4) "Sao lưu & khôi phục" → "Hẹn giờ…": chọn thư mục, chu kỳ hằng ngày, cắm sạc, đợi hoặc dùng `adb shell cmd jobscheduler run -f <gói> 7301` (4.48.5); (5) quét Wi-Fi hai mặt trên một máy có khay giấy hai mặt (4.48.4); (6) ký số với một địa chỉ TSA thật (4.48.6), mở PDF kết quả trong Acrobat / Foxit và xem thông tin dấu thời gian; (7) "Tô sáng" một PDF xuất từ app này và một PDF Word, so hộp với chữ (4.48.7).
000a. Sau đó làm tiếp theo thứ tự ở 6 "Còn lại sau phiên 19" (nay chỉ còn: thêm ngôn ngữ; xem "Còn lại sau phiên 20"): nhập ODT/PPTX/XLSX/RTF, trí tuệ tài liệu, mã QR, sao lưu theo lịch + cảnh báo, chữ ký nâng cao, eSCL hai mặt.

00. **(Phiên 17, ƯU TIÊN SỐ 1) Chạy Actions cho mã phiên 16 + 17 và sửa lỗi biên dịch** theo vòng lặp quen thuộc (xem 0e0): lấy danh sách lỗi từ hộp Annotations / `ci_error_summary.py`, sửa, lặp tới khi `assembleDebug` xanh rồi mới `bundleRelease`. Điểm nghi ngờ mới nêu ở mục 6 "Còn lại sau phiên 17", mục 1.
00a. **Xem kết quả job `pdfa`** (veraPDF, mục 6.2). Chưa từng chạy: có thể đỏ lần đầu.
00b. **Thử trên máy thật theo thứ tự rủi ro:** Két (Keystore + sinh trắc), quét QR (CameraX + ML Kit), chọn nhiều / thùng rác (ActionMode), tô sáng chữ (mở kết quả bằng nhiều trình đọc: Chrome, Acrobat, Drive, trình mặc định của máy - kiểm AP của chú thích), chỉnh tay + khử đốm trên trang thật, thước thăng bằng và phím âm lượng.
00c. Sau đó làm tiếp theo thứ tự: thử eSCL trên máy quét thật (6.3), tiếng Anh (6.4), công cụ cấu trúc PDF (6.5). **Trước khi phát hành: quyết định giữ hay xoá quyền INTERNET (4.31 I) và cập nhật mục "An toàn dữ liệu" trên Google Play cho khớp.**


0e00. **NGUYÊN TẮC (người dùng đã nhắc nhiều lần): không được ghi "hạn chế" hay "chưa làm" khi chưa tra cứu cách giải quyết.** Phiên 15 vi phạm hai lần ở các mục "Hạn chế đã biết" của 4.25 (thẻ ngược đầu, so sánh trang lệch, điền biểu mẫu mất chữ ký) và chỉ sửa sau khi bị nhắc — xem 4.25 để biết cách tra cứu và kiểm chứng. Mỗi mục "chưa làm" dưới đây đã kèm HƯỚNG ĐÃ TRA CỨU:
   - **(ĐÃ LÀM ở 4.26)** nén hàng loạt, thẻ trong lịch sử, đọc to, dịch, PDF→Word, che vĩnh viễn, đăng ký affine cho so sánh — các gạch đầu dòng dưới đây giữ lại như hồ sơ tra cứu. Nhận định "nén hàng loạt cần chọn mức nén" là SAI: `PdfObjectRecompressor.recompress` chỉ có một chế độ.
   - **Dịch**: ML Kit Translation chạy trên máy (phụ thuộc `com.google.mlkit:translate`, 50+ ngôn ngữ gồm tiếng Việt, mô hình ~30 MB/ngôn ngữ tải về một lần, cặp không có tiếng Anh dịch qua tiếng Anh nên chất lượng thấp hơn; Google ghi là dành cho "dịch đơn giản/thông thường"). Cần kiểm điều khoản và thêm vào THIRD_PARTY_NOTICES + licence guard.
   - **Đọc to (TTS)**: `android.speech.tts.TextToSpeech` có sẵn, không phụ thuộc thêm; giọng tiếng Việt tuỳ máy. Nguồn văn bản: tệp `.txt` OCR đi kèm.
   - **PDF→Word**: không có thư viện .docx nhẹ phù hợp cho Android; đường đi: viết tay gói .docx tối thiểu (ZIP + `document.xml`) từ văn bản OCR theo dòng/đoạn (tái dùng `ZipOutputStream` như `BackupManager`), kiểm bằng LibreOffice/python-docx ở máy tính.
   - **Che thông tin vĩnh viễn (redaction)**: PdfBox không xoá được chữ dưới hộp đen; đường duy nhất an toàn là dựng trang thành ảnh, vẽ hộp đen lên ảnh rồi thay trang bằng ảnh (mất lớp chữ của trang đó); tái dùng `StampPlacementView`-kiểu vẽ hộp + `PdfPageBitmap` + `PdfExporter`.
   - **Thẻ/thư mục trong lịch sử**: lưu `Map<tên tệp, danh sách thẻ>` cạnh `FavoriteStore`; lọc trong `HistoryFilter.arrange` (thêm tham số thẻ).
   - **Đăng ký affine cho so sánh (xoay ≥ 1°)**: OpenCV có `findTransformECC` (module video) nhưng phải tra vị trí lớp trong bản 5.0.0.1 trước.
0e0. **(Phiên 15, ƯU TIÊN SỐ 1) Vòng sửa lỗi biên dịch (B15-03)**: 11 lỗi đầu tiên đã sửa (xem 7.2). Chạy lại Actions; lấy danh sách lỗi kế tiếp từ hộp Annotations ("Compile errors (N)") hoặc dòng `e: file` trong log, sửa, lặp tới khi `assembleDebug` xanh, rồi mới tới `bundleRelease`. Điểm nghi ngờ còn lại: lớp `org.opencv.geometry.Geometry` có trong AAR 5.0.0.1 hay không (lỗi sẽ hiện ở dòng import); lời gọi PdfBox trong `PdfDecorator`/`PdfStamper`/`PdfMetadataTools`; `PdfPrintAdapter`; `AppLock`. Mỗi lần đổi chữ ký hàm/hàm tạo PHẢI chạy `static_refs_check.py` (kiểm tra số 8 bắt thiếu tham số).
0e. **(Phiên 15) Thử trên máy thật, theo thứ tự rủi ro**: (1) build lần đầu — lỗi nhiều khả năng ở `PdfDecorator`/`PdfStamper`/`PdfMetadataTools` (API PdfBox "Trung bình" ở bảng 4.22) và `PdfPrintAdapter`; chạy
   `python3 tools/verify/static_refs_check.py` trước khi push để bắt lỗi tham chiếu; (2) "Ký & đóng dấu PDF" trên PDF có `/Rotate 90` và PDF có CropBox — mở kết quả bằng ≥2 trình đọc, ảnh phải nằm đúng chỗ xem trước
   và nền chữ ký trong suốt; (3) "Số trang" với tiếng Việt (đường bitmap) và Bates `ABC-` 4 chữ số trên PDF 3 trang; (4) In → "Lưu thành PDF" của hệ thống; (5) Khoá ứng dụng: bật/tắt, quay lại <60 s và >60 s, xoay màn hình,
   gỡ khoá màn hình rồi mở app; (6) Sao lưu → xoá dữ liệu app → Khôi phục, kiểm dự án mở lại được (đường dẫn đã rebase); (7) "Sửa thông tin tài liệu": mở kết quả bằng Chrome và Adobe, tiêu đề phải là bản mới.
   **Làm tiếp theo ưu tiên** (theo file "Thiếu gì để bán app", chọn thứ tái dùng được code sẵn có): (a) ~~chữ ký số thật~~ ĐÃ LÀM (4.24, chứng thư tự ký; còn phải thử Adobe trên máy thật; sau này: dấu thời gian RFC 3161 + LTV, chứng thư từ tệp .p12, dấu hiển thị); (b) ~~lịch sử: tìm kiếm + sắp xếp + yêu thích~~ ĐÃ LÀM (4.23); (c) ~~preset thẻ căn cước/hộ chiếu~~ ĐÃ LÀM (4.25); (e) ~~tự đặt tên file theo dòng đầu OCR~~ ĐÃ LÀM (4.25); (f) ~~xử lý hàng loạt~~ ĐÃ LÀM (4.25, trừ nén); còn lại: nén hàng loạt (cần chọn mức nén), thẻ/thư mục trong lịch sử, PDF→Word/Excel, TTS, dịch, redaction thật (che chữ rồi xoá hẳn nội dung bên dưới: phải rasterize trang), N-up với ghi chú in. Mục (a)-(d) đã có hướng giải quyết cụ thể — không được ghi thành "giới hạn" rồi bỏ đó.
0d. **(Phiên 14) Thử dewarp co ngang trên ảnh sách thật**: chụp 1 trang gần gáy, bật "Duỗi thẳng dòng chữ cong"; nếu chữ bị kéo giãn quá tay thì giảm `F_REL` xuống 0,6
   (kéo giãn ít hơn); nếu gáy ở trên/dưới thay vì trái/phải thì phần ngang không đúng — xoay ảnh trước khi duỗi (bật "Tự xoay đúng chiều" cùng lúc).
0c. **(Phiên 13) Thử thêm trên máy thật**: (1) ô "Tự xoay đúng chiều và thẳng chữ" và "Duỗi thẳng dòng chữ cong" trên ảnh chụp sách thật
   (kiểm toast nói gì; nếu nhận sai hướng thì siết `MIN_CONF`/`MIN_COUNT` trong `PageOrientation`); (2) công tắc "Tự động chụp"
   (điều chỉnh `HOLD_MS`, `MOVE_TOL`, `SHARP_KEEP` ở `CaptureStability`); (3) "PDF tìm kiếm được" với tiếng Trung/Nhật/Hàn;
   (4) "Mật khẩu & watermark PDF": mở file đã đặt mật khẩu bằng ≥2 trình đọc; (5) mở `dependencies.txt` của CI xem BouncyCastle
   nào được kéo theo để quyết định làm chữ ký số.
0b. **(Phiên 12) Thử chức năng mới trên máy thật**: (1) "PDF tìm kiếm được" trên 1 PDF quét — mở kết quả bằng Chrome + 1
   ứng dụng PDF khác, gõ tìm 1 từ tiếng Việt có dấu, bôi chọn/sao chép đoạn chữ; (2) chip "Trắng đen+" và "Xóa bóng" trên ảnh chụp
   thật có bóng; (3) ô "Tự thẳng chữ" trên trang chụp nghiêng nhẹ; (4) xem toast chất lượng có báo nhầm/sót không rồi chỉnh
   ngưỡng ở `ScanQuality`. Nếu ổn: cân nhắc bật mặc định "Tự thẳng chữ". (Lớp chữ OCR trong bước OCR của luồng Dự án: đã làm ở phiên 16, 4.27.)
0. **(Phiên 11) Build lần đầu sau khi đổi sang PdfBox**: chạy Actions; lỗi biên dịch nhiều khả năng nằm ở các API
   "Trung bình" trong bảng mức tin cậy (mục 4.18). Sau đó thử "Nén PDF → Sửa trực tiếp" trên 1 PDF có chữ thật +
   1 PDF ghép từ nhiều nguồn (kiểm tra thông báo "đã nén thêm cấu trúc file" có xuất hiện, mở file kết quả bằng
   ít nhất 2 trình đọc khác nhau) và "Sửa chữ PDF" trên PDF xuất từ Word/Chrome (font CID) — mục 2 bên dưới vẫn áp
   dụng. Rồi: đặt `APP_ID`, tạo keystore, kiểm căn lề 16 KB, tải lên thử nghiệm nội bộ.
1. Push code lên GitHub, chạy Actions, sửa lỗi build đầu tiên (nếu có) — xem mục 9. Khối lượng code
   mới nhất (mục 4.17, phiên thứ 8) làm bước này càng quan trọng hơn — xác suất build lỗi ngay lần
   đầu cao hơn các phiên trước, và đây là lần đầu dự án phụ thuộc sâu vào API nội bộ của iText
   (`PdfCanvasProcessor`/`registerContentOperator`) chứ không chỉ API công khai đơn giản. **[Lịch sử — từ phiên 11 engine là PdfBox-Android, rủi ro build nằm ở bảng mức tin cậy mục 4.18; các số liệu phiên bản ở mục 2.]**
2. **Test `PdfTextEditActivity` ("Sửa chữ PDF", mục 4.17) TRƯỚC MỌI THỨ KHÁC** — ưu tiên cao nhất
   trong toàn bộ mục này, xem lý do đầy đủ ở đầu mục 9. Test tối thiểu: chuẩn bị vài PDF CÓ CHỮ THẬT
   từ nhiều nguồn khác nhau (xuất từ Word, xuất từ Google Docs, 1 PDF từ LaTeX nếu có, 1 PDF có OCR
   text layer) — không dùng PDF app này tự quét ra (đó là ảnh, không có chữ thật để sửa). Với mỗi
   file: mở tool, thử sửa vài đoạn chữ ngắn (đổi vài ký tự, đổi 1 từ ngắn thành từ dài hơn/ngắn hơn
   để xem cơ chế co giãn `Tz` có ra kết quả đọc được không), xuất PDF, MỞ LẠI FILE XUẤT RA bằng 1
   trình đọc PDF khác (không phải app này) để xác nhận: (a) file không bị lỗi/hỏng, mở được bình
   thường; (b) đoạn đã sửa hiện đúng chữ mới, không bị chồng chữ cũ hoặc lệch vị trí rõ rệt; (c) phần
   còn lại của trang (chữ khác, ảnh, định dạng) không bị ảnh hưởng gì. Thử cả trường hợp NÊN bị từ
   chối (gõ 1 ký tự lạ chắc chắn không có trong font gốc, ví dụ ký tự Hàn/Nhật vào 1 PDF tiếng Anh)
   để xác nhận tool từ chối đúng như thiết kế thay vì âm thầm ghi sai.
3. **Test đi hết cả 8 bước của 1 "Dự án" thật (mục 4.15)** — tính năng lớn, chưa được ai chạm vào
   lần nào. Test tối thiểu: chụp/chọn vài
   ảnh (có ít nhất 1 ảnh 2 trang để test luôn bước tách trang), đi hết crop → chọn preset → xuất PDF
   (bật mục lục tự động 1 lần để xem `TocDetector` phản ứng ra sao với ảnh thật - gần như chắc chắn
   cần chỉnh regex) → nén → OCR → tạo ebook, xong thử thoát giữa chừng ở vài bước khác nhau rồi mở
   lại dự án xem có tiếp tục đúng chỗ không.
4. Cài APK debug lên máy thật, test đủ 3 luồng CÔNG CỤ ĐỘC LẬP còn lại: quét (cả 3 nguồn ảnh), ghép
   PDF, quản lý trang PDF, chú thích PDF (mục 4.16). Test riêng backup/restore cho cả 5 màn hình có
   (phiên quét, quản lý trang PDF, soạn ebook, ghép PDF, và từ phiên thứ 4: soạn ebook trong luồng Dự
   án — xem mục 4.13/4.14/6):
   làm dở vài thao tác, ép buộc dừng app (vuốt khỏi Recents hoặc Settings → Apps → Force stop), mở
   lại app/màn hình đó xem hộp thoại/trạng thái khôi phục có hiện đúng không, tiếp tục có ra đúng
   trạng thái cũ không. Riêng luồng "quét từ nguồn PDF" (bước 3 luồng độc lập), tiện thể kiểm tra
   luôn kích thước trang PDF xuất ra có đúng không (xem lỗi `ASSUMED_DPI` đã sửa ở mục 0/6/7, phiên
   thứ 4 — chưa có cách nào kiểm chứng được ngoài chạy thật).
5. Test riêng heuristic `isColorPage()` và `detectGutterX()` với vài ảnh thật (chữ đen thường, chữ
   có highlight màu, trang có ảnh chụp màu; ảnh chụp 2 trang sách mở phẳng) — chỉnh ngưỡng nếu
   nhận/gợi ý sai.
7. Mở thử file `.epub` xuất ra bằng vài app đọc sách khác nhau (Google Play Books/Apple
   Books/calibre/gửi thử Send-to-Kindle) để xác nhận cấu trúc EPUB thật sự hợp lệ.
8. Test công cụ "Nén PDF" cả 2 cách (An toàn / CCITT G4) trên vài PDF thật (tài liệu chữ nhiều
   trang, tài liệu có cả trang màu) — xem tỉ lệ nén thực tế đạt bao nhiêu, CCITT G4 có tự rơi về
   cách an toàn nhiều không (nếu có, xem log để biết `Ccitt4Decoder.verify()` fail ở đâu). Áp dụng
   luôn cho bước "Nén PDF" trong luồng Dự án (dùng chung `PdfCompressor`).
9. Test công cụ "Chuyển đổi định dạng" — đặc biệt EPUB→PDF/TXT (thử với cả EPUB do chính app tạo
   ra và 1 EPUB từ nguồn khác để xem `EpubReader` chịu được cấu trúc phức tạp hơn tới đâu), và mở
   PDF xuất ra bằng app có khung bookmark để xem `PdfBookmarkInjector` có thêm được mục lục thật
   không (không thấy bookmark cũng không sao — file vẫn dùng bình thường, chỉ là chưa thêm được).
10. ~~Bài so sánh Kotlin vs Java~~ — đã xong, xem `KOTLIN_VS_JAVA.md`.
11. ~~Dọn file cache tạm định kỳ~~ — đã xong (mục 4.14), chỉ cần xác nhận thật sự chạy đúng trên máy
   thật khi test (mục cần làm số 3 ở trên).
12. Nếu người dùng cần giữ chữ thật khi ghép/tách PDF (không rasterize) — nghiên cứu đổi sang
   `pdfbox-android` hoặc tương đương, đánh giá lại rủi ro build khi đó đã có thể build-test thật.
13. Nếu người dùng cần thêm định dạng ebook: FB2 ĐÃ có (phiên 16); MOBI/AZW3 vẫn không khuyến khích — xem quyết
    định 11; làm thêm khi được yêu cầu, tái dùng cấu trúc `EbookBuilder.Chapter` có sẵn.
15. **(Phiên 16 — đã làm một phần ở 4.29; phần còn lại ở cuối 4.29)** Tính năng còn thiếu thật so với PDF "Thiếu gì để bán app"** — danh sách có thứ tự và cách làm ở mục 4.28 (mở bằng/chia sẻ tới app, phím tắt, giao diện tối + tablet + tiếng Anh, trợ giúp + nhật ký sự cố, công cụ trang PDF, quản lý tài liệu
    + tìm theo nội dung, che tự động thông tin cá nhân, xuất PPTX/XLSX/HTML/MD, trích trường hoá đơn, máy ảnh, chỉnh ảnh, highlight trên chữ). **Đề xuất: build mã phiên 16 và các mục 4.23–4.27 cho xanh TRƯỚC khi thêm mã mới** — chưa biên dịch càng nhiều thì lần
    build tới càng dễ đỏ hàng loạt và khó định vị lỗi.
14. **(Phiên 16) Build lần tới — việc đầu tiên.** Mã Kotlin của phiên 16 chưa biên dịch (danh sách ở mục 6). Nếu đỏ: mở Job summary (`ci_error_summary.py`). Điểm nghi ngờ đầu tiên theo thứ tự: (a) `documentOutline?.firstChild`
    /`nextSibling` trong `SearchablePdfBuilder.topLevelBookmarks` (tên thuộc tính PdfBox-Android); (b) `android.icu.text.BreakIterator.getLineInstance()` trong `TextPdfBuilder`; (c) `R.string.preset_*` ở `ScanPresetApplier`
    (thiếu chuỗi → `Unresolved reference`); (d) `binding.cbFormatFb2` (thiếu id trong layout → ViewBinding không sinh trường). Sau khi xanh, thử trên thiết bị: OCR một PDF 10 trang ở luồng Quét và ở luồng Dự án, mở PDF ra
    trong Chrome/Acrobat/Drive để tìm chữ và bấm bookmark; tạo TXT tiếng Trung → PDF; xuất FB2 mở bằng FBReader/Calibre.


## 11. Danh mục tính năng của ứng dụng (cập nhật phiên 17)

Mỗi dòng: tính năng người dùng thấy → điểm vào → mã chính → mục mô tả → mức kiểm chứng. **"Kiểm chứng" nói thẳng:** CHƯA tính năng nào được CHẠY trên Android. Về BIÊN DỊCH (chi tiết: mục 0, "Trạng thái build hiện hành"): các dòng 1–20 và X đã biên dịch được ở CI run #18, TRỪ những chỗ phiên 16 sửa vào (2g, 6, 8, 11 — xem 4.27); các dòng 21–51 (từ mục 4.23 trở đi) chưa qua biên dịch lần nào.
Cột đó chỉ cho biết có bằng chứng ĐỘC LẬP nào khác: `rà tĩnh` = 6 cách rà ở mục 9 (+ rà import, ngoặc từ phiên 13); `py:<script>` = bản Python song song ở `tools/verify/` đã chạy với công cụ độc lập;
`libtiff` = so sánh với libtiff (theo mục 4.11).

| # | Tính năng | Điểm vào | Mã chính | Mục | Kiểm chứng |
|---|---|---|---|---|---|
| 1 | Dự án: quy trình bắt buộc 8 bước (tạo → chọn ảnh → chỉnh → kiểu quét → xuất PDF + mục lục → nén → OCR → ebook), tự dò mục lục sách | thẻ "Dự án" | `Project*Activity` ×9, `ProjectManager`, `TocDetector` | 4.15 | rà tĩnh |
| 2 | Quét: camera / thư viện / PDF khác → cắt bốn góc → lọc → danh sách trang → xuất PDF (3 cách nén) | thẻ "Quét" | `CaptureActivity`, `CropActivity`, `PageListActivity`, `ImageProcessor`, `PdfExporter` | 4.1–4.4 | rà tĩnh |
| 2a | Tự động chụp khi giữ yên máy (công tắc, mặc định TẮT) | màn camera | `CaptureStability`, `FrameDocumentAnalyzer` | 4.20 | py:`stability_check.py` (logic); CameraX chưa thử |
| 2b | 6 bộ lọc trang: Gốc / Tăng sáng / Xám / Trắng đen / Trắng đen+ (Sauvola) / Xóa bóng | chip ở `CropActivity` | `ImageProcessor`, `DocumentEnhancer` | 4.2, 4.19 | py:`image_algorithms_check.py`, `shadow_edge_check.py` |
| 2c | Tự xoay đúng chiều (0/90/180/270) + thẳng chữ (ô tích, TẮT) | `CropActivity` | `PageOrientation`, `DocumentEnhancer` | 4.20 | py:`orientation_check.py`, `image_algorithms_check.py` |
| 2d | Duỗi thẳng dòng chữ cong + sửa co ngang gần gáy (ô tích, TẮT) | `CropActivity` | `TextLineDewarp` | 4.21 | py:`dewarp_check.py`, `dewarp_horizontal_check.py` |
| 2e | Gợi ý chất lượng ảnh (mờ / tối / thiếu tương phản) — chỉ toast | `CropActivity` | `ScanQuality` | 4.19 | py:`image_algorithms_check.py` (ngưỡng chưa thử ảnh thật) |
| 2f | Tách ảnh chụp 2 trang sách | `CropActivity` | `SplitLineOverlayView`, `ImageProcessor` | 4.9 | rà tĩnh |
| 2g | Bộ lọc hàng loạt (9 preset gồm Trắng đen+ và Xóa bóng, mặc định "Tự động"); cùng danh sách ở bước quét của luồng Dự án | menu `PageListActivity`, `ProjectScanActivity` | `ScanPresetApplier` | 4.3, 4.4, 4.27 | rà tĩnh; thuật toán 2 bộ lọc: `image_algorithms_check.py`, `shadow_edge_check.py` |
| 2h | Chú thích 1 trang đang quét dở | nút từng trang | `PdfAnnotateActivity` | 4.16 | rà tĩnh |
| 2i | Tự lưu & khôi phục phiên quét / ghép / quản lý trang / ebook | tự động | `ScanSessionManager`, `*State` | 4.13, 4.14 | rà tĩnh |
| 3 | Ghép nhiều PDF | thẻ "Ghép PDF" | `PdfMergeActivity` | 4.6 | rà tĩnh |
| 4 | Quản lý trang PDF: xoá, sắp xếp, xoay, tách | thẻ "Quản lý trang" | `PdfPageEditorActivity` | 4.7 | rà tĩnh |
| 5 | Tối ưu cho máy đọc sách (render 250 dpi → bộ lọc hàng loạt) | thẻ "E-ink" | `MainActivity.importPdfForEink` | 4.8a | rà tĩnh |
| 6 | Ebook EPUB/TXT có mục lục từ OCR | thẻ "Ebook" / menu danh sách trang | `EbookExportActivity` | 4.10 | rà tĩnh |
| 7 | Nén PDF: An toàn / CCITT G4 / Sửa trực tiếp (+ nén cấu trúc, phiên 11–12) | thẻ "Nén PDF" | `PdfCompressor`, `Ccitt4*`, `PdfObjectRecompressor`, `PdfStructureOptimizer` | 4.11, 4.18 | `libtiff` (G4); py:`structure_optimizer_check.py` (cấu trúc) |
| 8 | Chuyển đổi định dạng PDF/EPUB/TXT/ảnh | thẻ "Chuyển đổi" | `ConvertDocumentActivity` | 4.12 | rà tĩnh |
| 9 | Chú thích PDF: bút, chữ, che (nung vào điểm ảnh ⇒ che thật) | thẻ "Chú thích PDF" | `PdfAnnotateActivity`, `AnnotationCanvasView` | 4.16 | rà tĩnh |
| 10 | Sửa chữ PDF (đoạn ngắn, không rasterize; hỗ trợ font CID qua ToUnicode) | thẻ "Sửa chữ PDF" | `PdfTextEditor`, `PdfTextEditActivity` | 4.17, 4.18 | py:`tounicode_check.py` (chỉ bộ đảo ToUnicode); CHƯA thử PDF thật |
| 11 | PDF tìm kiếm được: OCR 5 hệ chữ → lớp chữ vô hình (Type3) | thẻ "PDF tìm kiếm được" | `SearchablePdfBuilder`, `OcrHelper` | 4.19, 4.20 | py:`text_layer_check.py`, `rotated_words_check.py`, `highlight_height_check.py`; CHƯA thử Chrome/Acrobat |
| 12 | Mật khẩu AES-256 / gỡ mật khẩu / watermark chéo | thẻ "Mật khẩu & watermark PDF" | `PdfSecurityTools` | 4.20 | py:`watermark_check.py` (hình học); AES chưa thử |
| 13 | Giấy phép mã nguồn mở | liên kết cuối màn chính | `LicensesActivity` | 4.18 | rà tĩnh |
| 14 | Lịch sử & chia sẻ file kết quả (PDF/EPUB/TXT; mở `.txt` OCR đi kèm) | màn chính | `MainActivity.refreshHistory` | 4.8, 4.8b | rà tĩnh |
| 15 | Số trang / đầu-chân trang / số Bates (`{n}` `{N}` `{b}`), bỏ qua trang bìa, tiếng Việt qua bitmap | thẻ "Số trang & đầu/chân trang" | `PdfDecorator`, `PdfPageGeometry`, `PdfDecorateActivity` | 4.22 | py:`decorate_check.py`, `page_geometry_check.py` (poppler, trang xoay + CropBox); PdfBox chưa chạy |
| 16 | Ký tay / chọn chữ ký đã lưu / đóng tem (ĐÃ DUYỆT, BẢN SAO, ngày, tự nhập), kéo-chụm đặt vị trí, áp cho 1 / tất cả / trang cuối — KHÔNG rasterize | thẻ "Ký & đóng dấu PDF" | `PdfStamper`, `PdfSignActivity`, `SignaturePadView`, `StampPlacementView`, `SignatureStore`, `StampRenderer` | 4.22 | py:`stamp_check.py` (24 tổ hợp, poppler); giao diện chưa chạy |
| 17 | In PDF (hộp thoại in hệ thống / lưu PDF) | nút "In" ở lịch sử | `PdfPrintAdapter` | 4.22 | py:`print_ranges_check.py` (chỉ phạm vi trang); in thật CHƯA thử |
| 18 | Khoá ứng dụng: vân tay/PIN, 60 s ân hạn, chặn chụp màn hình & ẩn đa nhiệm | công tắc ở màn chính | `AppLock`, `LockActivity`, `DocScannerApp` (AppLockCallbacks) | 4.22 | py:`app_lock_check.py` (logic); BiometricPrompt CHƯA thử |
| 19 | Sao lưu / khôi phục ZIP (tài liệu + dự án; không ghi đè; chống zip-slip; đổi đường dẫn khi đổi máy) | thẻ "Sao lưu & khôi phục" | `BackupManager` | 4.22 | py:`backup_check.py` (trên đĩa, có thử tấn công); SAF CHƯA thử |
| 20 | Sửa tiêu đề/tác giả/chủ đề/từ khoá PDF; xoá thông tin ẩn (Info + XMP) | menu thẻ Mật khẩu & watermark | `PdfMetadataTools` | 4.22 | py:`metadata_check.py` (ý tưởng, poppler); PdfBox CHƯA chạy |
| 21 | Lịch sử: ô tìm kiếm không dấu, sắp xếp (mới nhất / tên / lớn nhất), gắn sao đưa lên đầu | ô tìm + nút sắp xếp + nút sao ở danh sách "Tài liệu đã xuất" | `HistoryFilter`, `FavoriteStore`, `HistoryAdapter`, `MainActivity` | 4.23 | py:`history_filter_check.py` (18 ý); giao diện CHƯA chạy |
| 22 | Gộp 2/4 trang lên một tờ A4 và xếp trang in sổ gấp (booklet), không rasterize | thẻ "Gộp trang & in sổ gấp" | `PdfImposer`, `PdfPageGeometry` | 4.23 | py:`imposition_check.py` (thứ tự sổ gấp 1..60 + 8 tổ hợp poppler); PdfBox CHƯA chạy |
| 23 | Ký số PDF (chữ ký mật mã, chứng thư tự ký, khoá trong Android Keystore, bản cập nhật tăng dần), chia sẻ chứng thư .cer | menu thẻ Mật khẩu & watermark → "Ký số" | `PdfDigitalSigner`, `CmsSigner`, `DerWriter`, `MainActivity` | 4.24 | py+java:`digital_signature_check.py` (pdfsig + openssl, 2 loại chứng thư, 3 thử âm tính); Keystore/PdfBox CHƯA chạy |
| 24 | Đổi tên tài liệu; gợi ý tên từ dòng tiêu đề trang 1 (OCR, bỏ quốc hiệu); sao đi theo tên mới | nhấn giữ một dòng ở "Tài liệu đã xuất" | `SmartNamer`, `PdfPageBitmap`, `FavoriteStore`, `MainActivity` | 4.25 | py:`smart_namer_check.py` (25 ý); OCR/giao diện CHƯA chạy |
| 25 | Xử lý hàng loạt: đánh số trang / watermark / mật khẩu / xoá thông tin ẩn / gộp 2 trang, nhiều PDF một lượt | thẻ "Xử lý hàng loạt" | `BatchProcessor`, `SmartNamer`, `MainActivity` | 4.25 | py: tên đầu ra; các thao tác tái dùng hàm đã có; CHƯA chạy |
| 26 | Ghép thẻ CCCD/GPLX/hộ chiếu lên A4 đúng kích thước thật (cắt, nắn phẳng, tự nhận chiều thẻ, nút xoay 180° khi không chắc, mặt trước/sau) | thẻ "Ghép thẻ lên A4" | `IdCardComposer`, `ImageProcessor`, `MainActivity` | 4.25 | py:`idcard_check.py` (poppler 300 dpi đo mm), `card_orientation_check.py` (192 ảnh thẻ giả: 66% đúng, 34% từ chối, 0 sai); tìm góc thẻ trên ảnh thật CHƯA thử |
| 27 | So sánh hai PDF theo hình ảnh: ghép trang chèn/xoá, căn chỉnh theo ô, so có dung sai, báo cáo PDF (đổi/thêm/xoá) | thẻ "So sánh hai PDF" | `PdfComparer`, `PdfPageBitmap`, `MainActivity` | 4.25 | py+java:`compare_check.py` (dịch→0 hộp, xoay/co nhẹ ≤12%, vẫn nhạy với đổi số), `compare_java_check.py` (bản Java trên JVM = numpy); PdfRenderer CHƯA chạy |
| 28 | Điền biểu mẫu PDF có ô sẵn (văn bản, ô tích, danh sách chọn), dự phòng cho chữ có dấu, cập nhật tăng dần với PDF đã ký số | thẻ "Điền biểu mẫu PDF" | `PdfFormFiller`, `PdfFormActivity` | 4.25 | py:`form_check.py` (NeedAppearances, poppler), `signed_form_check.py` (điền tăng dần giữ chữ ký, pdfsig); PdfBox CHƯA chạy |
| 29 | "Ký & đóng dấu": thêm nhiều lần vào bản làm việc rồi "Lưu & thoát"; chữ không khung để điền bản quét | thẻ "Ký & đóng dấu PDF" | `PdfSignActivity`, `StampRenderer` | 4.25 | giao diện CHƯA chạy (dùng lại `PdfStamper` đã kiểm) |
| 30 | Nén hàng loạt (thêm vào Xử lý hàng loạt) | thẻ "Xử lý hàng loạt" | `BatchProcessor`, `PdfObjectRecompressor` | 4.26 | tái dùng hàm đã có; CHƯA chạy |
| 31 | Thẻ cho tài liệu: gắn nhiều thẻ, lọc theo thẻ, tìm theo chữ trong thẻ | nhấn giữ → "Gắn thẻ…"; nút "Thẻ" | `TagStore`, `HistoryFilter`, `MainActivity` | 4.26 | py:`history_filter_check.py` (thẻ); giao diện CHƯA chạy |
| 32 | Đọc to nội dung tài liệu (TTS, giọng Việt nếu có) | nhấn giữ → "Đọc to nội dung" | `SpeechReader`, `PdfTextExtractor`, `TextChunker` | 4.26 | py:`text_chunker_check.py`; engine/giọng CHƯA thử |
| 33 | Dịch nội dung sang 6 ngôn ngữ, offline sau lần tải mô hình đầu | nhấn giữ → "Dịch nội dung…" | `TextTranslator`, `PdfTextExtractor`, `TextChunker` | 4.26 | py:`text_chunker_check.py`; ML Kit CHƯA thử |
| 34 | Xuất PDF sang Word (.docx) | nhấn giữ → "Xuất sang Word (.docx)" | `DocxWriter`, `PdfTextExtractor` | 4.26 | py+java:`docx_check.py` (python-docx + LibreOffice); OCR CHƯA thử |
| 35 | Lớp chữ OCR gắn thẳng vào PDF khi bấm ô OCR (luồng Quét) và ở bước OCR (luồng Dự án); `.txt` đi kèm từ cùng lần OCR | ô "Nhận diện văn bản (OCR)"; bước 7 của Dự án | `SearchablePdfBuilder.embedInPlace`, `PdfExporter.ocrExportedPdf`, `ProjectOcrActivity` | 4.27 | đọc mã; lớp chữ: 4.19 (`text_layer_check.py`); CHƯA build, CHƯA thử trên thiết bị |
| 36 | Ngắt dòng theo Unicode (Trung/Nhật/Hàn, URL, số dài) khi tạo PDF từ EPUB/TXT | Chuyển đổi định dạng | `TextWrapper`, `TextPdfBuilder` | 4.27 | java+py:`text_wrap_check.py` (phông Noto CJK thật, 3 đột biến); ICU Android CHƯA chạy |
| 37 | Xuất ebook FB2 (và chuyển EPUB/TXT → FB2); EPUB/FB2 loại ký tự cấm của XML | ô FB2 ở màn tạo ebook; Chuyển đổi định dạng | `EbookBuilder.buildFb2`, `ConvertDocumentActivity` | 4.27 | java+py:`fb2_check.py` (xmllint + lxml + pandoc, 2 đột biến); chưa mở bằng FBReader/Calibre |
| 38 | Che thông tin vĩnh viễn (hộp đen nung vào ảnh trang, chữ bên dưới không còn trong tệp) | thẻ "Che thông tin vĩnh viễn" | `PdfRedactor`, `RedactionView`, `PdfRedactActivity` | 4.26 | py:`redact_check.py` (poppler: che giả lộ chữ, che thật không); PdfBox CHƯA chạy |
| 39 | Mở bằng / Chia sẻ tới DocScanner (PDF, ảnh) | chọn Mở bằng hoặc Chia sẻ trong ứng dụng khác (menu của app đó, không phải của DocScanner) | `IncomingFile`, `MainActivity.handleIncomingIntent`, `pickPdfOrUseIncoming` ở 7 màn PDF | 4.29 | rà tĩnh; CHƯA chạy |
| 40 | Phím tắt ứng dụng (Quét, Dự án, PDF tìm kiếm, Ký) | nhấn giữ biểu tượng ứng dụng | `AppShortcuts` | 4.29 | rà tĩnh; CHƯA chạy |
| 41 | Giao diện tối (và chữ phụ ban ngày đạt tương phản WCAG AA) | tự theo chế độ tối của hệ thống | `values-night`, `text_secondary` | 4.29 | py: `night_theme_check.py` (6 tỉ lệ x 2 bảng màu, 4 đột biến); chưa xem trên máy |
| 42 | Hướng dẫn & phản hồi; nhật ký sự cố cục bộ + hộp hỏi gửi báo cáo | liên kết "Hướng dẫn & phản hồi" cuối màn hình chính | `HelpActivity`, `CrashLog` | 4.29 | java+py: `crash_log_check.py` (không lộ tên tài liệu; thử âm tính); phần giao diện CHƯA chạy |
| 43 | Công cụ trang PDF: thêm trang từ PDF khác, nhân đôi, trang trắng, cắt lề, đổi khổ giấy, tách theo khoảng / mỗi N trang | menu ⋮ của "Quản lý trang PDF" ("Thêm trang từ PDF khác…", "Cắt lề…", "Đổi khổ giấy…") | `PageEditorTools`, `PageRanges`, `PdfPageEditorActivity` | 4.29 | java+py: `page_ranges_check.py` (20 000 ca ngẫu nhiên vs tham chiếu độc lập, 3 đột biến), `page_tools_check.py` (6 000 ca, 2 đột biến); phần ảnh CHƯA chạy |
| 44 | Che tự động thông tin cá nhân (CCCD/CMND, điện thoại, email, thẻ, MST, STK) | nút "Tự động tìm" ở "Che thông tin vĩnh viễn" | `PiiDetector`, `PiiScanner`, `PdfRedactActivity` | 4.29 | java+py: `pii_check.py` (2 000 văn bản dựng sẵn + mồi nhử, 4 đột biến); OCR + giao diện CHƯA chạy |
| 45 | Tìm tài liệu theo NỘI DUNG đã OCR (file `.txt` cạnh PDF) | ô tìm kiếm của "Tài liệu đã xuất" | `ContentIndex`, `HistoryFilter` | 4.29 | py (phản chiếu): `history_filter_check.py` +9 ca; nạp nền CHƯA chạy |
| 46 | Trợ năng: mô tả cho ảnh / nút ảnh | — (TalkBack) | các layout, 4 chuỗi `cd_*` | 4.29 | py: `accessibility_check.py` (48 ảnh; thử âm tính) |
| 47 | Xuất HTML / Markdown từ chữ của tài liệu | nhấn giữ → "Xuất HTML / Markdown…" | `TextExporters` | 4.30 | java+py: `export_check.py` (html.parser + `pandoc`; 60 trang đầy ký tự đặc biệt; đột biến) |
| 48 | Xuất bảng sang Excel (.xlsx) từ PDF (OCR + nhận bảng bằng khe cột) | nhấn giữ → "Xuất bảng sang Excel (.xlsx)" | `TableExtractor`, `XlsxWriter` | 4.30 | java+py: `export_check.py` (800 bảng dựng sẵn; `openpyxl`, LibreOffice; 8 đột biến); OCR + giao diện CHƯA chạy |
| 49 | Xuất PDF sang PowerPoint (.pptx), mỗi trang một ảnh | nhấn giữ → "Xuất sang PowerPoint (.pptx)" | `PptxWriter` | 4.30 | java+py: `export_check.py` (`python-pptx`, LibreOffice → PDF); chưa mở bằng PowerPoint thật |
| 50 | Trích thông tin hoá đơn VN (ngày, số, ký hiệu, MST, tổng, thuế) + sao chép / CSV | nhấn giữ → "Trích thông tin hoá đơn" | `InvoiceFields` | 4.30 | java+py: `extract_check.py` (1500 hoá đơn dựng sẵn; 7 đột biến); giao diện CHƯA chạy |
| 51 | Danh thiếp → liên hệ (form thêm liên hệ của hệ thống) hoặc vCard 3.0 | nhấn giữ → "Danh thiếp → thêm vào danh bạ" | `ContactCard` | 4.30 | java+py: `extract_check.py` (1200 danh thiếp; vCard đọc lại bằng bộ đọc RFC 2426 độc lập); OCR + giao diện CHƯA chạy |
| 52 | Chỉnh tay 5 thanh trượt (sáng, tương phản, đậm màu, độ nét) + khử đốm an toàn cho dấu tiếng Việt | Cắt/lọc -> nút "Chỉnh tay" | `CropActivity`, `ManualAdjust`, `Despeckle` | 4.31 A | py:manual_adjust_check (+ Java, scipy) |
| 53 | Tô sáng / gạch chân / gạch ngang chữ bằng chú thích PDF thật | Màn chính -> thẻ "Tô sáng & gạch chân chữ"; "Mở bằng" cho PDF | `PdfMarkupActivity`, `PdfTextMarkup` | 4.31 B | py:text_markup_check (poppler, 24 tổ hợp) |
| 54 | Thùng rác 30 ngày + khôi phục | Lịch sử -> nút "Thùng rác"; xoá một tài liệu | `TrashStore`, `MainActivity` | 4.31 C | py:trash_rename_check (thư mục thật) |
| 55 | Chọn nhiều (chia sẻ, xoá, gắn thẻ) + đổi tên hàng loạt | Lịch sử -> "Chọn nhiều" / giữ lâu | `HistoryAdapter`, `BulkRename`, `MainActivity` | 4.31 C | py:trash_rename_check (mô phỏng không đè) |
| 56 | Quét QR / mã vạch (camera hoặc ảnh), hiểu nội dung và gợi ý hành động | Màn chính -> thẻ "Quét mã QR / mã vạch" | `BarcodeScanActivity`, `BarcodeContent` | 4.31 D | py:barcode_content_check (vòng đi-về) |
| 57 | Camera: lưới, thước thăng bằng, phím âm lượng chụp | Màn chụp | `CaptureActivity`, `LevelIndicator`, `GridOverlayView` | 4.31 E | py:level_check |
| 58 | Màn hình lớn / ngang: cột nội dung tối đa 640 dp | Mọi màn (trừ camera/cắt/trang) | `LargeScreen`, `DocScannerApp` | 4.31 F | py:large_screen_check |
| 59 | Chuyển PDF sang PDF/A-2b (dò điểm chặn, OutputIntent, XMP) | Lịch sử -> giữ lâu một PDF | `PdfAConverter`, `PdfAXmp`, `SrgbIcc` | 4.31 G | py:pdfa_check (lcms, qpdf) + veraPDF trong CI (chưa chạy) |
| 60 | Két an toàn (mã hoá AES-256-GCM, Keystore, mở bằng sinh trắc) | Màn chính -> thẻ "Két an toàn" | `VaultActivity`, `VaultStore`, `VaultCrypto` | 4.31 H | py:vault_check (chéo với `cryptography`, 21 kiểu phá hoại) |
| 61 | Quét qua Wi-Fi bằng máy quét eSCL / AirScan (không cần cáp, không cần trình điều khiển) | Màn chính -> thẻ "Quét qua Wi-Fi" (ẩn nếu không có quyền INTERNET) | `WifiScanActivity`, `EsclClient`, `EsclProtocol`, `EsclDiscovery` | 4.31 I | py:escl_check (máy quét giả); chưa thử máy thật |
| 62 | Tách PDF theo mục lục (chương) + ghép PDF giữ chữ và mục lục | Lịch sử -> giữ lâu một PDF -> "Tách theo mục lục…"; màn Ghép PDF | `PdfBookmarks`, `PdfExporter.mergePdfs`, `MainActivity` | 4.32 | py:bookmarks_check (đầu-cuối) |
| 63 | Sửa mục lục PDF (đổi tên, xoá kèm mục con, thêm dấu trang; từ phiên 19: đưa lên / xuống, thụt vào, đưa ra ngoài) | Lịch sử -> giữ lâu một PDF -> "Sửa mục lục…" | `PdfBookmarkActivity`, `PdfBookmarks` | 4.34 | py:bookmarks_check (2 500 ca + PDF thật) |
| 64 | Công cụ EPUB: sửa thông tin sách, đổi ảnh bìa, tách theo khoảng, ghép nhiều sách, xuất HTML / Markdown | Lịch sử -> giữ lâu một .epub (4 mục đầu + 2 mục xuất); chọn nhiều .epub -> "Ghép EPUB…" | `EpubTools`, `TextExporters.htmlFromChapters` / `markdownFromChapters`, `MainActivity` | 4.35 | java+py: `epub_tools_check.py` (zipfile, lxml, pandoc; 41 phép kiểm + thử âm tính); giao diện CHƯA chạy |
| 65 | Dọn dẹp: thống kê dung lượng theo loại + 5 tệp lớn nhất; tìm tài liệu TRÙNG NỘI DUNG (giữ bản cũ nhất, bản mới hơn vào Thùng rác); xoá hẳn khỏi Thùng rác có ghi đè trước | Lịch sử -> nút "Dọn dẹp"; nút "Thùng rác" | `StorageTools`, `TrashStore`, `MainActivity` | 4.36 | java+py: `storage_tools_check.py` (60 cây ngẫu nhiên so với hashlib, thử âm tính, 14 phép kiểm); giao diện CHƯA chạy |
| 66 | Nhập ảnh từ gói CBZ / ZIP vào hàng đợi quét; kiểm dung lượng trống trước thao tác dài; giữ màn hình sáng khi đang xử lý | Màn chính -> chọn nguồn quét -> "Gói ảnh (CBZ / ZIP)" | `ArchiveImages`, `StorageTools.requiredSpace`, `MainActivity` | 4.37 | java+py: `archive_images_check.py` (400 danh sách, zip-slip, zip-bomb, trần, gói hỏng, 210 ca dung lượng); giao diện CHƯA chạy |
| 67 | Việc dài không bị hệ thống thu hồi khi chuyển sang app khác (dịch vụ nền loại dataSync + thông báo "Đang xử lý tài liệu") | tự động khi đang xử lý: màn chính (mọi thao tác có hộp tiến trình), xuất PDF/OCR, ghép PDF, nén dự án, OCR dự án, xuất PDF dự án, xuất/chuyển ebook, chuyển tài liệu | `KeepAlive` (kèm dịch vụ KeepAliveService), `MainActivity.setImporting` + 10 chỗ `KeepAlive.during` | 4.38 | java+py: `keepalive_check.py` (3 021 kịch bản của bộ đếm); dịch vụ thật CHƯA chạy (cần máy thật) |
| 68 | Cấu trúc bên trong PDF: xem / trích / thêm / xoá TỆP ĐÍNH KÈM; bật tắt LỚP hiển thị (OCG); xem và xoá LIÊN KẾT (chỉ liên kết web, hoặc mọi liên kết) | Lịch sử -> giữ lâu một PDF: "Tệp đính kèm…", "Lớp hiển thị…", "Liên kết…" (mọi thay đổi ra BẢN SAO) | `PdfStructureTools`, `MainActivity` | 4.39 | py: `pdf_structure_check.py` (pikepdf dựng lại cấu trúc + poppler `pdfdetach`, vẽ trang đo màu, pypdf, qpdf; 23 phép kiểm); lời gọi PdfBox CHƯA chạy |
| 69 | Sửa PDF hỏng cấu trúc: chẩn đoán (nặng / nhẹ / lành) rồi mở khoan dung + lưu lại + kiểm lại số trang; không cứu được thì báo lỗi, không tạo tệp rỗng | Lịch sử -> giữ lâu một PDF -> "Sửa PDF hỏng…" (ra bản sao) | `PdfRepair`, `MainActivity` | 4.40 | java+py: `pdf_repair_check.py` (200 mẫu so với qpdf; 0 báo nhầm nặng; độ bao phủ 87%); PdfBox CHƯA chạy |
| 70 | Tự tạo liên kết cho địa chỉ web / email có trong văn bản PDF (trang không xoay) | Lịch sử -> giữ lâu một PDF -> "Tự tạo liên kết web / email" (ra bản sao) | `PdfAutoLinks`, `MainActivity` | 4.40 | java+py: `pdf_links_portfolio_check.py` (1 521 ca nhận diện; hình học đo bằng poppler); PdfBox CHƯA chạy |
| 71 | PDF Portfolio: bật / tắt chế độ hiển thị tệp đính kèm như thư mục (`/Collection` trong Catalog) | Lịch sử -> giữ lâu một PDF -> "PDF Portfolio…" (ra bản sao) | `PdfStructureTools`, `MainActivity` | 4.40 | py: `pdf_links_portfolio_check.py` (cấu trúc qua qpdf / pdfdetach / pypdf); CHƯA mở bằng Acrobat |
| 72 | Chế độ riêng tư (không ghi lịch sử): tài liệu và dự án mới vào thư mục riêng, không hiện trong danh sách thường, xoá là xoá hẳn, tắt thì xoá sạch | Lịch sử -> nút "Riêng tư" | `PrivateMode`, `PdfExporter.exportDir`, `FileUtils.projectsRootDir`, `MainActivity` | 4.41 | java+py: `storage_tools_check.py` (phần D: `wipeTree`); đổi hướng thư mục và giao diện CHƯA chạy |
| 73 | Tối ưu xem nhanh trên web (tuyến tính hoá PDF, "Fast Web View") ra bản sao | Lịch sử -> giữ lâu một PDF -> "Tối ưu xem nhanh trên web…" | `Linearizer`, `PdfLinearizer`, `MainActivity` | 4.42 | java+py: `linearize_check.py` (9 PDF đủ kiểu, `qpdf --check-linearization` + vẽ từng điểm ảnh + thử âm tính; 21 phép kiểm); lớp PdfBox CHƯA chạy |
| 74 | Thư mục theo dõi: chọn một thư mục; mỗi lần mở app, ảnh / PDF MỚI trong đó được đề nghị nhập (ảnh -> hàng đợi quét, PDF -> danh sách tài liệu) | Lịch sử -> "Dọn dẹp" -> "Thư mục theo dõi…" | `WatchFolder`, `MainActivity` | 4.43 | java+py: `watch_folder_check.py` (logic chọn tệp, 300 danh sách + 205 ca `remember`); phần Android (SAF) CHƯA chạy |
| 75 | Bố cục máy tính bảng hai khung cho màn chính (rộng >= 600dp): trái = công cụ, phải = lịch sử | tự động trên máy tính bảng / màn hình rộng | `res/layout-sw600dp/activity_main.xml` (sinh tự động) | 4.44 | py: `tablet_layout_check.py` (cấu trúc: đủ 40 id, 58 view đúng thứ tự, khớp bản sinh lại); CHƯA xem trên máy |
| 76 | Đa ngôn ngữ: giao diện theo ngôn ngữ máy (tiếng Anh mặc định; hiện có Việt, Nhật), người dùng tự chọn trong app; tên mặc định ghi vào tệp xuất theo ngôn ngữ | tự động theo ngôn ngữ máy; "🌐 Language" ở cuối màn chính; Android 13+: Cài đặt hệ thống -> Ngôn ngữ ứng dụng | `res/values*/strings.xml` (SINH từ `tools/i18n/`), `AppLanguages`, `AppText`, `res/xml/locales_config.xml`, `MainActivity` | 4.45, 4.46 | py: `i18n_check.py` (đủ khoá cho MỌI ngôn ngữ, giữ dấu thay thế, thư mục đúng danh sách), `app_languages_check.py` (2 014 ca); VĂN PHONG chưa có người bản ngữ đọc; chưa chạy trên máy |
| 77 | Nhập Markdown / HTML / Word (.docx) → PDF / EPUB / FB2 và CSV / TSV → PDF dạng lưới (phiên 19) | `DocumentImport`, `TablePdfBuilder`, `ConvertDocumentActivity` | 4.47.2 | -- |
| 78 | Áp phích: phóng một trang ra 2-5 tờ A4 ngang, chồng 10 mm, dấu góc (phiên 19) | menu "Gộp trang & in sổ gấp" → mục thứ 4 | 4.47.3 | -- |
| 79 | Xuất TIFF nhiều trang (đen trắng G4 hoặc màu Deflate) từ PDF trong "Chuyển đổi" (phiên 19) | `TiffWriter`, `ConvertDocumentActivity` | 4.47.4 | -- |
| 80 | Tạo mã QR (liên kết, văn bản, Wi-Fi) thành trang PDF vector (phiên 19) | thẻ "Mã QR" → `QrEncoder`, `QrPdfBuilder` | 4.47.5 | -- |
| 81 | Cảnh báo trước khi sửa PDF ĐÃ KÝ số (phiên 20): nói rõ tệp mới sẽ mất chữ ký, tệp gốc giữ nguyên | 8 màn hình + 9 công cụ ghi lại PDF | `PdfSignatureProbe`, `SignedPdfGuard` | 4.48.1 | py + java: `signed_pdf_check` (PDF ký thật so với `pdfsig`) |
| 82 | Nhập ODT / PPTX / RTF → PDF / EPUB / FB2 và Excel .xlsx → PDF dạng lưới nhiều trang tính (phiên 20) | "Chuyển đổi" | `OfficeImport`, `RtfImport`, `TablePdfBuilder.buildSheets` | 4.48.2 | py + java: `office_import_check` (LibreOffice, pandoc, python-pptx, openpyxl) |
| 83 | Phân tích tài liệu: loại, thẻ gợi ý (TF-IDF), tóm tắt 3 câu (TextRank) (phiên 20) | nhấn giữ mục lịch sử | `DocInsight`, `MainActivity.showDocInsight` | 4.48.3 | py + java: `doc_insight_check` (scikit-learn, networkx) |
| 84 | Quét Wi-Fi hai mặt từ khay giấy + xoay mặt sau 180° (phiên 20) | "Quét qua Wi-Fi" | `EsclProtocol`, `WifiScanActivity` | 4.48.4 | py + java: `escl_check` phần D (máy giả); CHƯA thử máy thật |
| 85 | Sao lưu theo lịch vào thư mục tự chọn, giữ N bản mới nhất (phiên 20) | "Sao lưu & khôi phục" → Hẹn giờ… | `BackupSchedule`, `AutoBackup`, `AutoBackupJobService` | 4.48.5 | py + java: `backup_schedule_check` (phần thuần); JobScheduler / SAF CHƯA chạy |
| 86 | Chữ ký số có dấu thời gian RFC 3161 (PAdES-B-T) tới TSA do người dùng nhập; trống = không gọi mạng (phiên 20) | "Ký số" | `TimeStamp`, `CmsSigner`, `PdfDigitalSigner` | 4.48.6 | py + java: `timestamp_check` (openssl ts); cuộc gọi mạng thật CHƯA thử |
| 87 | Tô sáng bằng lớp chữ thật của PDF (chính xác, không cần OCR); bản quét rơi về OCR (phiên 20) | "Tô sáng" | `TextLayerWords`, `PdfTextLayer`, `PdfMarkupActivity` | 4.48.7 | py + java: `text_layer_check` (14 PDF thật); PdfBox CHƯA chạy |
| 88 | Nén các tài liệu đã chọn thành MỘT ZIP, có thể đặt mật khẩu (AES-256, WinZip AE-2) rồi chia sẻ (phiên 22) | Lịch sử -> chọn nhiều -> ⋮ -> "Nén thành ZIP…" | `ZipPack`, `MainActivity.zipSelected` | 4.49.1 | py + java: `zip_pack_check` (bộ đọc độc lập; thử âm tính); mở bằng 7-Zip / WinRAR thật CHƯA thử |
| 89 | Xuất văn bản của tài liệu ra JSON / XML, và bất kỳ tệp nào ra văn bản Base64 (`.b64`) (phiên 22) | Lịch sử -> giữ lâu một mục -> "Xuất HTML / Markdown / JSON / XML…" và "Lưu thành văn bản Base64…" | `TextExporters`, `MainActivity` | 4.49.2 | py + java: `text_formats_check` (bộ đọc độc lập; thử âm tính) |
| 90 | Khoá app: chọn sau bao lâu rời app thì hỏi lại (5 giây / 1 / 5 / 15 / 30 phút) (phiên 22) | màn chính -> hàng "Khoá lại sau" (hiện khi khoá bật) | `AppLock`, `MainActivity` | 4.49.3 | py: `app_lock_check` (mô phỏng sự kiện cho từng mức) |
| 91 | Nhập từ liên kết https (PDF / ảnh) và từ clipboard (ảnh / PDF / văn bản -> .txt hoặc PDF) (phiên 22) | màn chính -> thẻ "Nhập từ liên kết hoặc clipboard" | `LinkImport`, `MainActivity` | 4.49.4 | py + java: `link_import_check` (máy chủ HTTP cục bộ); tải qua https thật CHƯA thử |
| 92 | Tìm trong một cuốn EPUB: không phân biệt hoa / thường và dấu, liệt kê theo chương kèm ngữ cảnh (phiên 22) | Lịch sử -> giữ lâu một EPUB -> "Tìm trong sách…" | `EpubSearch`, `MainActivity` | 4.49.5 | py + java: `epub_search_check` (đối chứng độc lập) |
| 93 | Widget màn hình chính "Quét nhanh": Quét / Ký PDF / PDF tìm kiếm được (phiên 22) | thêm widget từ launcher | `ScanWidgetProvider`, `widget_scan.xml` | 4.49.6 | chỉ rà tĩnh; CHƯA thử trên launcher |
| 94 | Chụp liên tiếp theo chu kỳ 2 / 3 / 5 giây khi lật trang, ảnh vào hàng đợi cắt khi xong (phiên 22) | màn chụp -> nút "Chụp liên tiếp" -> chạm nút chụp | `IntervalShooter`, `CaptureActivity` | 4.49.7 | py + java: `interval_shooter_check`; chưa chạy với camera thật |
| 95 | Ký số bằng chứng thư của chính người dùng (.p12 / .pfx, RSA hoặc EC, kèm chuỗi chứng thư) (phiên 22) | ký số -> "Dùng tệp chứng thư của tôi" | `Pkcs12Import`, `PdfDigitalSigner`, `CmsSigner` | 4.49.8 | py + java + openssl + pdfsig: `pkcs12_sign_check`; Keystore Android CHƯA chạy |
| 96 | Dấu hiển thị cho chữ ký số: ô chọn ở góc dưới phải trang cuối, đúng cả trang xoay (phiên 22) | ký số -> hộp "Hiện dấu chữ ký…" | `VisibleSignature`, `PdfDigitalSigner` | 4.49.10 | py + java + poppler: `visible_signature_check`; PDFBox 2.0 thật CHƯA chạy (có đường lui ký không dấu) |
| 97 | Thư mục phân cấp ảo: thẻ dạng `Công việc/Hoá đơn`, lọc thư mục cha gồm cả con, đếm tài liệu (phiên 22) | Lịch sử -> nút Thẻ -> cây thư mục | `TagTree`, `HistoryFilter`, `MainActivity` | 4.49.11 | py: port + đối chứng vét cạn (history_filter_check) |
| 98 | Webhook: báo một địa chỉ https khi có tài liệu mới (tên / loại / cỡ / giờ, không nội dung), có chữ ký HMAC (phiên 22) | màn chính -> hàng "Webhook" | `DocumentWebhook`, `MainActivity` | 4.49.12 | py + java: `webhook_check` (máy chủ cục bộ); gửi khi app đóng KHÔNG có |
| 99 | Cỡ chữ trong app (Chuẩn / Lớn / Lớn hơn / Lớn nhất) cộng thêm cỡ chữ hệ thống; chữ chính và chữ phụ đạt tương phản AAA 7:1 (phiên 22) | màn chính -> hàng "Cỡ chữ" | `BaseActivity`, `FontScale` | 4.49.13 | py: `base_activity_check`, `night_theme_check`; chưa nhìn trên máy |
| 100 | Chế độ ảnh HDR / ban đêm của camera điện thoại (CameraX Extensions), mặc định thường (phiên 22) | màn chụp -> nút "Chế độ ảnh" | `CaptureActivity` | 4.49.14 | chỉ rà tĩnh; CHƯA chạy trên camera thật |
| 101 | Dịch một bức ảnh (biển báo, thực đơn, trang giấy): máy ảnh hệ thống -> OCR -> dịch trên máy (phiên 22) | màn chính -> thẻ "Dịch một bức ảnh" | `MainActivity`, `OcrHelper`, `TextTranslator` | 4.49.15 | chỉ rà tĩnh; chưa chạy; ảnh xoay EXIF chưa xử lý |
| 102 | Trình đọc EPUB trong app: mục lục, tìm + nhảy tới kết quả, tô sáng bằng chọn chữ, dấu trang, nhớ vị trí đọc, cỡ chữ, chép ghi chú; ghi chú gắn với dấu vân tay của sách (phiên 23) | Lịch sử -> nhấn giữ tệp EPUB -> "Đọc sách…" | `EpubNotes`, `EpubReaderActivity`, `EpubRowAdapter`, `EpubSearch`, `EpubReader` | 4.50 | py + java: `epub_notes_check` (mô hình mặt nạ độc lập, 5 đột biến); giao diện chỉ rà tĩnh, CHƯA chạy |
| 103 | Ký số có thể lưu thêm dữ liệu thu hồi chứng thư (OCSP / CRL) vào /DSS của PDF để kiểm tra chữ ký dài hạn (PAdES-B-LT; phiên 23) | Ký số -> ô "Lưu thêm dữ liệu thu hồi chứng thư…" | `Revocation`, `PdfLtv`, `PdfDigitalSigner` | 4.51 | py + java: `revocation_check` (openssl ocsp thật), `ltv_pdf_check` (pdfsig / qpdf); PdfBox ghi /DSS và CA thật CHƯA thử |
| 104 | Tìm kiếm lịch sử bằng giọng nói (PDF I2, bản gọn; phiên 23) | Lịch sử -> nút micro cạnh ô tìm kiếm | `MainActivity` (`voiceSearchLauncher`, `btnHistoryVoice`), `ic_mic.xml` | 4.52 | tĩnh: i18n, accessibility, night_theme, tablet_layout, static_refs, kotlin_lint; CHƯA biên dịch / chạy |
| X | Xuyên suốt: tràn viền Android 15+, nút Back dự đoán, AAB ký release, CI chặn giấy phép | — | `DocScannerApp`, `app/build.gradle`, workflows | 4.18 | đọc; CHƯA build |

**Tính năng có mã nhưng CHƯA có thao tác tương ứng ở chỗ khác (nói thẳng):** (hết các mục của phiên 15 — Trắng đen+/Xóa bóng và lớp chữ OCR đã tích hợp ở phiên 16.) Còn: trong luồng Dự án chỉ bản PDF đã nén nhận lớp chữ.

## 12. Nhật ký thay đổi theo phiên

Quy ước: **Thêm / Đổi / Sửa lỗi (ID ở mục 7) / Gỡ**. Cột "Kiểm chứng" luôn là mức cao nhất đạt được trong phiên đó. Phiên 1 không có bản ghi riêng — mục 4.1–4.12 là kết quả cộng dồn của phiên 1–2
(suy ra từ mục 4, KHÔNG phải trích nhật ký).

| Phiên | Thêm | Đổi | Sửa lỗi | Gỡ | Kiểm chứng |
|---|---|---|---|---|---|
| 1 (suy ra) | app quét (camera/crop/lọc), OCR `.txt`, ghép/quản lý trang PDF, E-ink, tách trang sách, ebook, nén An toàn/G4, chuyển đổi, tự lưu phiên | — | (EXIF bị bỏ qua — mục 7 không ghi phiên nào) | — | rà tĩnh; G4 so `libtiff` |
| 2 | tự lưu/khôi phục cho 3 luồng còn lại, dọn cache định kỳ | cảnh báo xoá cặp EPUB+TXT | `setBusy` thiếu tham số (mục 7) | — | rà tĩnh (script số tham số) |
| 3 | luồng Dự án 8 bước, `TocDetector`, `ProjectManager`, 9 màn | tái cấu trúc nhẹ để dùng chung logic | `ASSUMED_DPI` (đa số đường) | — | rà tĩnh |
| 4 | `ProjectEbookEditorState` | `PendingCropQueue.sourceDpi` + `EXTRA_SOURCE_DPI` | B04-01, B04-02 | — | rà tĩnh (6 cách) |
| 5 | nén cấu trúc iText (full compression + smart), Predictor PNG cho ảnh Flate | tra cứu JBIG2/JPX → quyết định KHÔNG tích hợp | — | — | rà tĩnh; tra cứu |
| 6 | `CompressOptionsDialog`, lựa chọn nén ở luồng Quét | `PdfCompressor.compress(pageDpis)`; `PdfExporter.writeOcrTextFile()` tách ra | B06-01 | — | rà tĩnh |
| 7 | Chú thích PDF (`PdfAnnotateActivity`, `AnnotationCanvasView`) | — | B07-01, B07-02 | — | rà tĩnh |
| 8 | Sửa chữ PDF (iText, `PdfCanvasEditor` port mã mẫu) | — | B08-01 | — | rà tĩnh; API iText đã tra cứu (mục 4.17) |
| 9 | backup/restore Sửa chữ (`PdfTextEditState`) | — | B09-01 (Form XObject lệch bộ đếm) | — | rà tĩnh |
| 10 | — | 1 lệnh hiện chữ = 1 `TextChunk`; ĐỌC và GHI dùng chung 1 lớp duyệt | B10-01 | `newProcessor()` | rà tĩnh |
| 11 | `PdfStructureOptimizer`, `PdfVerify`, `LicensesActivity`, `ToUnicodeReverse`, edge-to-edge, AAB ký + CI (licence guard, create-keystore), `THIRD_PARTY_NOTICES` | engine PDF: iText → PdfBox-Android; `applicationId` từ `APP_ID`; targetSdk 36; AGP 8.13/Kotlin 2.2.10; Back → dispatcher; `allowBackup=false` | B11-01…B11-13 | iText, `PdfCanvasEditor.kt` | bản Python song song cho object stream (qpdf/poppler/pypdf); Kotlin chưa build |
| 12 | `SearchablePdfBuilder`, `DocumentEnhancer` (Sauvola, xóa bóng, tự thẳng chữ), `ScanQuality`, chip/ô tích mới ở `CropActivity`, thẻ "PDF tìm kiếm được" | `PdfStructureOptimizer` hỗ trợ stream trong bộ nhớ; k=0,25 | B12-01…B12-04 | — | py: lớp chữ Type3 (4 hướng), Sauvola vs skimage, tự thẳng chữ |
| 13 | `PageOrientation`, `TextLineDewarp` (dọc), `CaptureStability`+`FrameDocumentAnalyzer`, `PdfSecurityTools`, OCR 5 hệ chữ, từ OCR nghiêng theo `cornerPoints` | xóa bóng 1000 px/5x5/median 3; ô tích gộp "Tự xoay đúng chiều và thẳng chữ"; thêm "Duỗi dòng cong" | B13-01…B13-10 | — | py: 480 trang nhận hướng, 10 tình huống tự chụp, dewarp, watermark, từ nghiêng |
| 14 | sửa co ngang dewarp (độ dài cung), `doc_sync_check.py`, `tools/verify` dựng lại, mục 7.1/7.2/8.x/9.x/11/12 | trần dịch chuyển dọc 8% → 12%; mục hiện trạng §2/§3/§4/§5/§6/§8/§10 + README viết lại cho đúng | B14-01…B14-05 | — | py: `dewarp_horizontal_check.py` (27 ca vật lý); `doc_sync_check.py` có thử âm tính |
| 15 | `PdfPageGeometry`, `PdfDecorator`+`PdfDecorateActivity`, `PdfStamper`+`PdfSignActivity`+`SignaturePadView`+`StampPlacementView`+`SignatureStore`+`StampRenderer`, `PdfPrintAdapter`, `AppLock`+`LockActivity`, `BackupManager`, `PdfMetadataTools`, 3 thẻ + công tắc ở màn chính, nút In, `androidx.biometric:1.1.0`, 8 script `tools/verify` | (tiếp, sau khi build xanh) `HistoryFilter`, `FavoriteStore`, `PdfImposer`, `PdfDigitalSigner`+`CmsSigner`+`DerWriter`, `SmartNamer`+`PdfPageBitmap`, `TextChunker`, `TagStore`, `PdfTextExtractor`, `SpeechReader`, `TextTranslator`, `DocxWriter`, `PdfRedactor`+`RedactionView`+`PdfRedactActivity`, `BatchProcessor`, `IdCardComposer`, `PdfComparer`, `PdfFormFiller`+`PdfFormActivity`, thẻ Gộp trang, ô tìm/sắp xếp/sao ở lịch sử | menu Bảo mật thêm 2 mục; `HistoryAdapter` có `onPrint` + `onToggleFavorite`/`isFavorite` (mặc định); `DocScannerApp` đăng ký `AppLockCallbacks` | B15-01 + B15-02 (CI: repo chỉ chứa zip; gói SDK `tools` không còn) + B15-03 (11 lỗi biên dịch Kotlin đầu tiên: OpenCV 5 tách `Geometry`, quên `onPrint` ở nơi tạo thứ hai, `writeOcrTextFile` thiếu `suspend`; sửa khi rà lại: `PdfPrintAdapter` không đóng descriptor của khung in) | — | py: 12 + 8 + 24 tổ hợp poppler, 10 kịch bản khoá, sao lưu trên đĩa, `static_refs_check.py` có thử âm tính; Kotlin CHƯA build |
| 16 | (tiếp 2, 4.30: `TableExtractor`, `XlsxWriter`, `PptxWriter`, `TextExporters`, `InvoiceFields`, `ContactCard`, `PiiDetector.foldLower`, 3 script `export_check` / `extract_check` / `strings_check` + 2 bản Java; sửa danh sách lịch sử và MIME chia sẻ; B16-11…B16-17) (tiếp, 4.29: `IncomingFile`, `AppShortcuts`, `HelpActivity`/`activity_help.xml`, `CrashLog`, `PageEditorTools`, `PageRanges`, `PiiDetector`, `PiiScanner`, `ContentIndex`, `values-night`, menu `menu_pdf_page_editor.xml`, 6 script + 6 bản Java/mở rộng `history_filter_check`) `TextWrapper`, `EbookBuilder.buildFb2`/`xmlSafe`, `SearchablePdfBuilder.embedInPlace`/`onPageText`, `PdfExporter.ocrExportedPdf`/`writeTranscript`, `ScanPresetApplier.Preset.BW_SAUVOLA`/`CLEAN` + `labelRes`, ô FB2 + `wantFb2`, đích FB2 ở chuyển đổi, 2 script (`text_wrap_check.py`, `fb2_check.py`) + 2 bản Java | hai hộp thoại preset dựng từ enum; `TextPdfBuilder.wrapText` dùng UAX #14; ô OCR gắn lớp chữ (rơi về `.txt` cũ); `ProjectOcrActivity` một lần OCR cho lớp chữ + `.txt`; `ConvertDocumentActivity`: `Boolean` → enum `Target`; chuỗi `ocr_text_note`/`checkbox_ocr`/`convert_target_ebook_group` | B16-01…B16-17 | — | java+py: `text_wrap_check.py` (3 đột biến), `fb2_check.py` (2 đột biến); `static_refs_check.py` + `doc_sync_check.py` đạt; Kotlin CHƯA build |
| 17 | `ManualAdjust`, `Despeckle`, `PdfTextMarkup`, `PdfMarkupActivity`, `TrashStore`, `BulkRename`, chế độ chọn nhiều trong `HistoryAdapter`/`MainActivity`, nút "Chỉnh tay" ở `CropActivity` (mục 4.31) | khử đốm = nhỏ VÀ cách xa chữ; chú thích PDF thật có AP tự dựng bằng COS; thùng rác không chỉ mục (mốc trong tên tệp); đổi tên không bao giờ đè | B17-01, B17-02 | -- | py + java: `manual_adjust_check`, `text_markup_check` (poppler), `trash_rename_check` (thư mục thật); Kotlin chỉ rà tĩnh |
| 17 (tiếp) | `BarcodeScanActivity`, `BarcodeContent`, `LevelIndicator`, `GridOverlayView`, `LargeScreen`, `PdfAConverter`, `PdfAXmp`, `SrgbIcc` (mục 4.31 D-G) | một mã chỉ nhận khi hai khung liên tiếp cùng chuỗi; `+` không thành dấu cách; một quy tắc trung tâm cho màn rộng; ICC sinh từ số sRGB; PDF/A lưu bằng `doc.save` thuần, điểm chặn nêu rõ lý do | B17-03, B17-04 | -- | py + java: `barcode_content_check`, `level_check`, `large_screen_check`, `pdfa_check` (lcms, qpdf); veraPDF trong CI (job `pdfa`, chưa từng chạy) |
| 17 (tiếp 2) | `VaultCrypto`, `VaultStore`, `VaultActivity` (mục 4.31 H) | két mã hoá kiểu STREAM bằng AES-GCM nền tảng (không thêm thư viện, kiểm chứng chéo với `cryptography`); khoá chủ trong Keystore; thêm = mã hoá, giải mã lại để kiểm, rồi mới xoá bản gốc | -- | -- | py + java: `vault_check` (21 kiểu phá hoại, hai chiều); Kotlin chỉ rà tĩnh |
| 17 (tiếp 3) | `EsclProtocol`, `EsclClient`, `EsclDiscovery`, `WifiScanActivity`, `network_security_config.xml`, quyền INTERNET (mục 4.31 I) | dùng nguyên `Location`; chỉ mạng nội bộ (kiểm trước khi kết nối); quyền INTERNET khai báo có điều kiện: xoá dòng quyền thì thẻ tự ẩn | B17-05 | -- | py + java: `escl_check` (máy quét giả, 14 tình huống); Kotlin chỉ rà tĩnh; chưa thử máy quét thật |
| 17 (tiếp 4) | `PdfBookmarks` (mục 4.32); `PdfExporter.mergePdfs` đổi sang ghép nguyên bản trước | tách theo mục lục, ghép giữ chữ + mục lục; Splitter / appendDocument thay importPage | B17-06 | cách ghép rasterize chỉ còn là dự phòng | py + java: `bookmarks_check` (đầu-cuối bằng pikepdf, pdftotext, qpdf); Kotlin chỉ rà tĩnh |
| 17 (tiếp 5) | `TrashMeta`, `TrashStore.readMeta` / tham số `meta` (mục 4.33) | sao + thẻ đi cùng tệp vào thùng bằng `.meta` (không chỉ mục); áp lại khi khôi phục | -- | -- | py + java: `trash_rename_check` (thư mục thật + vòng đi-về 600 ca); Kotlin chỉ rà tĩnh |
| 17 (tiếp 6) | `PdfBookmarkActivity`, các phép sửa trong `PdfBookmarks` (mục 4.34) | sửa mục lục lưu thành BẢN SAO; xoá kèm mục con; chỉ số theo danh sách đã chuẩn hoá | -- | -- | py + java: `bookmarks_check` (2 500 ca + PDF thật); Kotlin chỉ rà tĩnh |
| 18 | `EpubTools`, `TextExporters` (hàm theo chương), `MainActivity` (menu EPUB + Ghép EPUB), 25 chuỗi mới (mục 4.35) | làm ở MỨC GÓI ZIP (không dựng lại từ văn bản) nên giữ ảnh/CSS; đổi bìa GHI ĐÈ tại đường dẫn cũ; ghép = mỗi sách một thư mục `b<k>/` giữ nguyên cây gốc; tách chỉ giữ tài nguyên các trang dùng | B18-01 | -- | py + java: `epub_tools_check` (41 phép kiểm); Kotlin chỉ rà tĩnh |
| 18 (tiếp) | `StorageTools`, `TrashStore` (xoá hẳn gọi `StorageTools.wipe`), nút "Dọn dẹp" + 18 chuỗi (mục 4.36) | trùng = cùng cỡ -> cùng SHA-256 64 KB đầu -> cùng SHA-256 toàn bộ; lớp chữ OCR (.txt cạnh .pdf cùng tên) không tính; ghi đè là nỗ lực tốt nhất, UI không hứa xoá sạch | B18-02 | -- | py + java: `storage_tools_check` (14 phép kiểm); Kotlin chỉ rà tĩnh |
| 18 (tiếp 2) | `ArchiveImages`, `StorageTools.requiredSpace`/`enoughSpace`, `MainActivity` (nguồn "Gói ảnh", `hasRoomFor`, `FLAG_KEEP_SCREEN_ON` trong `setImporting`) + 3 chuỗi (mục 4.37) | tên tệp ra do app đặt (không tin tên trong gói); đếm byte thực thay vì tin kích thước khai báo; cần trống = 2 x đầu vào + 64 MB | -- | -- | py + java: `archive_images_check` (12 phép kiểm); Kotlin chỉ rà tĩnh |
| 18 (tiếp 3) | `KeepAlive` (`WorkTracker`, `KeepAliveService`), `AndroidManifest.xml` (3 quyền + dịch vụ dataSync), `MainActivity.setImporting` / `onDestroy` / xin quyền thông báo, 10 chỗ `KeepAlive.during` trong 8 Activity + 3 chuỗi (mục 4.38) | dịch vụ chỉ NÂNG ƯU TIÊN tiến trình, không chạy việc thay Activity; đếm tham chiếu (đúng một acquire cho mỗi hộp tiến trình); cài `onTimeout` (Android 15) để không bị crash; không khởi động được thì việc vẫn chạy | -- | -- | py + java: `keepalive_check` (3 021 kịch bản); Kotlin chỉ rà tĩnh |
| 18 (tiếp 4) | `PdfStructureTools`, `MainActivity` (3 mục menu PDF + hộp thoại + bộ chọn tệp) + 28 chuỗi (mục 4.39) | cây tên đính kèm tự sắp theo BYTE THÔ (không dùng `setNames`); lớp OCG đặt bằng thao tác trực tiếp trên mảng ON/OFF; mọi thay đổi ra bản sao | B18-03 | -- | py: `pdf_structure_check` (23 phép kiểm, có thử âm tính); Kotlin chỉ rà tĩnh |
| 18 (tiếp 5) | `PdfRepair`, `PdfAutoLinks`, `PdfStructureTools.setPortfolio` / `isPortfolio`, `MainActivity` (3 mục menu PDF) + 19 chuỗi (mục 4.40) | chẩn đoán 2 mức (nặng = qpdf xác nhận; nhẹ = đọc được); sửa = mở khoan dung + lưu + mở lại kiểm số trang; liên kết chỉ cho từ liền không khoảng trắng, trang không xoay, không đè liên kết có sẵn; Portfolio = `/Collection` tối thiểu | B18-04 | -- | py + java: `pdf_repair_check`, `pdf_links_portfolio_check`; Kotlin chỉ rà tĩnh |
| 18 (tiếp 6) | `PrivateMode`, `StorageTools.wipeTree`, đổi hướng ở `PdfExporter.exportDir` + `FileUtils.projectsRootDir`, `MainActivity` (nút Riêng tư, chỉ báo trên tiêu đề, xoá hẳn thay vì Thùng rác) + 10 chuỗi (mục 4.41) | đổi hướng ở HAI điểm tập trung thay vì sửa từng nơi xuất; trạng thái bật được lưu bền; tắt thì xoá sạch + gỡ sao / thẻ | -- | -- | py + java: `storage_tools_check` (phần D); Kotlin chỉ rà tĩnh |
| 18 (tiếp 7) | `Linearizer` (lõi), `PdfLinearizer` (PdfBox), `MainActivity` (mục menu PDF) + 6 chuỗi (mục 4.42) | chuyển thể từ gói Go `linearize` (Apache-2.0) sau khi đọc mã nguồn trên web; qpdf làm trọng tài; ghi một bộ đệm vá tại chỗ rồi xuất ba đoạn (không bản sao thứ hai); tệp > 100 MB bị từ chối | B18-05 | -- | py + java: `linearize_check` (21 phép kiểm); Kotlin chỉ rà tĩnh |
| 18 (tiếp 8) | `WatchFolder` (logic), `MainActivity` (chọn thư mục SAF, quét khi mở app, hộp thoại nhập, nút trong "Dọn dẹp") + 18 chuỗi (mục 4.43) | mỗi tệp đề nghị đúng một lần (nhớ theo mã tài liệu, tối đa 2000); tệp có sẵn lúc chọn không bị nhập; tệp đang ghi dở hoặc rỗng hoãn; chỉ ĐỌC thư mục | -- | -- | py + java: `watch_folder_check`; Kotlin chỉ rà tĩnh |
| 18 (tiếp 9) | `res/layout-sw600dp/activity_main.xml` (SINH từ bản mặc định bởi `tablet_layout_check.py`) (mục 4.44) | sinh tự động để không lệch với bản mặc định và để ViewBinding có đủ id; lỗi XML (`--` trong chú thích) do chính bài kiểm bắt | B18-06 | -- | py: `tablet_layout_check` (7 phép kiểm cấu trúc) |
| 18 (tiếp 10) | Đa ngôn ngữ: `values/` = tiếng Anh mặc định, `values-vi`, `values-ja`, `locales_config.xml`, `languages.xml` (đều SINH từ `tools/i18n/`), `AppLanguages`, `AppText`, bộ chọn ngôn ngữ + `AppLocalesMetadataHolderService`, 7 chuỗi + 1 mảng mới, từ khoá mục lục thêm ngôn ngữ (mục 4.45, 4.46) | tiếng Anh là mặc định để ngôn ngữ app không có rơi về tiếng Anh; ngôn ngữ nào cũng sinh từ một tệp nguồn; chuỗi ghi vào tệp xuất theo ngôn ngữ giao diện qua `AppText` | B18-07, B18-08 | -- | py: `i18n_check`, `app_languages_check`, `strings_check` |
| 19 | `PdfBookmarks.moveUp/moveDown/indent/outdent` + `can*`, `PdfBookmarkActivity` (4 mục hộp thoại) + 4 chuỗi (mục 4.47.1) | chỉ hiện nút có tác dụng (hàm `can*`, không so danh sách bằng `!=`) | -- | -- | py + java: `bookmarks_check` phần A3 (mô hình cây độc lập, 3 000 + 2 000 ca, thử âm tính); Kotlin chỉ rà tĩnh |
| 19 | `DocumentImport.kt`, `TablePdfBuilder.kt` (`TableLayout`), `ConvertDocumentActivity` (2 nguồn mới), `TextPdfBuilder.wrapText` thành `internal` + 3 chuỗi (mục 4.47.2) | ký tự thoát phải được che TRƯỚC khi bỏ dấu nhấn; danh sách có dòng trống giữa mục vẫn giữ độ sâu; chỉ coi là front matter khi dòng đầu là `khoá:`; bảng 252 thực thể HTML 4 thay danh sách rút gọn | -- | -- | py + java: `doc_import_check` (pandoc, lxml, python-docx, csv, html.unescape; 6 thử âm tính); Kotlin chỉ rà tĩnh |
| 19 | `PdfPoster.kt` (+ mục thứ 4 trong menu `showImposeMenu`, `showPosterColsDialog`, `runPoster`) + 4 chuỗi, sửa `tool_impose_desc` (mục 4.47.3) | cửa sổ ô cách nhau `pw - 10 mm`; số hàng tính với dung sai 1e-4 để trang vừa khít không sinh thừa một hàng | -- | -- | py + java: `poster_check` (4 000 ca tính chất, 16 tổ hợp poppler ghép lại = một tờ khổng lồ, 2 thử âm tính); phần PdfBox chưa chạy |
| 19 | `TiffWriter.kt` (`Writer`, `Page`, `Kind`, `dpiFor`, `predictor`, `deflate`), `PdfPageBitmap.Session.pageWidthPoints`, `ConvertDocumentActivity` (2 đích TIFF, `convertPdfToTiff`, `tiffPage`) + 2 chuỗi (mục 4.47.4) | G4 trong TIFF dùng `PhotometricInterpretation = 1` (không phải 0: cùng luồng đọc ngược màu); không ghi thẻ predictor cho dải CCITT; ghi từng trang ra đĩa bằng `RandomAccessFile` | -- | -- | py + java: `tiff_check` (cấu trúc tự viết + libtiff qua Pillow / OpenCV + ImageMagick, 2 thử âm tính); Kotlin + đường PdfRenderer chưa chạy |
| 19 | `QrEncoder.kt`, `QrPdfBuilder.kt`, thẻ `cardToolQr` trong `activity_main.xml`, `MainActivity` (`showQrKindDialog`, `promptQrText`, `promptQrWifi`, `makeQr`) + 12 chuỗi (mục 4.47.5) | chú thích Wi-Fi KHÔNG ghi mật khẩu; kiểm thông tin định dạng / phiên bản bằng toán BCH vì bộ giải tự sửa lỗi ở đó | -- | -- | py + java: `qr_check` (160 ô phiên bản x mức, 3 bộ giải độc lập, sửa lỗi, BCH, 4 thử âm tính); Kotlin + vẽ Canvas chưa chạy |
| 20 | `PdfSignatureProbe.kt`, `SignedPdfGuard.kt`, gắn vào 8 màn hình + 9 công cụ của `MainActivity` (`afterSignedCheck`) + 7 chuỗi `signed_warn_*` (mục 4.48.1); `OfficeImport.kt`, `RtfImport.kt`, `TablePdfBuilder.buildSheets`, nguồn ODT / PPTX / XLSX / RTF trong `ConvertDocumentActivity`, chuỗi `convert_slide_n` (mục 4.48.2); `DocInsight.kt` + `showDocInsight` / `askInsightTags` trong `MainActivity` + 21 chuỗi `insight_*` (mục 4.48.3); eSCL hai mặt: `EsclProtocol` (`duplex`, `feederDuplex*`, `fit(..., duplex)`, `<scan:Duplex>`), `WifiScanActivity` (hộp kiểm + `rotate180`), 2 chuỗi `wifi_duplex` / `wifi_rotate_back` (mục 4.48.4); `BackupSchedule.kt`, `AutoBackup.kt` (+ `AutoBackupJobService`), quyền `RECEIVE_BOOT_COMPLETED`, hộp thoại "Hẹn giờ…" trong `MainActivity`, 18 chuỗi `autobackup_*` (mục 4.48.5); `TimeStamp.kt`, `CmsSigner` (`timestamper`), `PdfDigitalSigner.sign(..., tsaUrl)`, ô địa chỉ TSA trong `confirmDigitalSign`, 5 chuỗi `digsign_tsa_*` (mục 4.48.6); `TextLayerWords.kt`, `PdfTextLayer.kt`, `PdfMarkupActivity.wordsFor` thử lớp chữ trước OCR (mục 4.48.7); ngôn ngữ mới (mục 4.48.8): `es_strings.txt`, `pt-BR_strings.txt` + `values-es`, `values-pt-rBR`; `i18n_check` chỉnh luật chữ Việt và thêm `ALLOW_SAME_LANG` | cấu trúc chữ ký thật (`a == 0`, `<` tại `a+b`, `>` tại `c-1`) thay vì tìm chữ "/ByteRange"; chỉ BREAKS mới hỏi; điền biểu mẫu / ký thêm chỉ hỏi khi chứng nhận DocMDP mức 1 | -- | -- | py + java: `text_layer_check` (14 PDF thật, hộp phủ 100 % mực, hằng số chỉnh trên dữ liệu thật; PdfBox chưa chạy), `timestamp_check` (openssl ts làm TSA cục bộ; `openssl ts -verify` xác nhận token phủ đúng chữ ký; 4 bản hỏng bị bắt), `backup_schedule_check` (phần thuần; Android chưa chạy), `escl_check` phần D (79 kiểm tra, máy giả trả 409), `doc_insight_check` (37 + 6 văn bản; TF-IDF = scikit-learn, PageRank = networkx; 6 bản hỏng bị bắt), `office_import_check` (58 kiểm tra, 8 bản hỏng bị bắt), `signed_pdf_check` (8 PDF ký thật so với `pdfsig`, 200 ngẫu nhiên, ranh giới khối, 3 thử âm tính); Kotlin chưa biên dịch, `static_refs_check` đạt |
| 21 | `tools/i18n/{fr,de,id,ko,zh-CN,hi,ru}_strings.txt` (1.102 dòng mỗi ngôn ngữ) + 7 dòng `languages.txt` + `values-fr`, `values-de`, `values-in`, `values-ko`, `values-zh-rCN`, `values-hi`, `values-ru` sinh bởi `i18n_check` (mục 4.48.8) | `i18n_check`: thêm luật dấu cách đầu / cuối của chuỗi phải khớp bản Anh (cả 12 ngôn ngữ), `ALLOW_SAME_LANG` cho 7 ngôn ngữ mới; `AppLanguages.checkedIndex` bỏ thành phần chữ viết của thẻ (`stripScript`); `runBatch` gắn `SignedPdfGuard` + chuỗi `batch_skipped_signed` (12 ngôn ngữ); `OcrScript.CYRILLIC` + `TesseractOcr.kt` + `HocrParser.kt` + 4 chuỗi `ocr_cyr_*` / `ocr_script_cyrillic` (12 ngôn ngữ) + kho JitPack có bộ lọc + `tesseract4android:4.9.0` + sửa `help_privacy_body` / `help_ocr_body` + `THIRD_PARTY_NOTICES.txt` | -- | -- | py + java: `i18n_check` TẤT CẢ ĐẠT cho 12 ngôn ngữ, `app_languages_check` 2.018 ca; bản dịch do trợ lý viết, chưa có người bản ngữ rà; Kotlin chỉ rà tĩnh, chưa chạy trên máy; OCR Cyrillic (tiếng Nga) đã viết nhưng chưa biên dịch / chưa đọc thử tiếng Nga thật (4.48.8 (9)) |
| 22 | `ZipPack.kt`, `MainActivity` (mục "Nén thành ZIP…" trong chế độ chọn nhiều: `zipSelected`, `runZip`), `FileUtils.zipShareDir`, `file_paths.xml` (`zip_share`), `menu_history_selection.xml` + 8 chuỗi ở 12 ngôn ngữ (mục 4.49.1) | PBKDF2 tự viết bằng `Mac` (không dùng `SecretKeyFactory`: khác cách đổi mật khẩu ra byte giữa JVM và Android); ZIP AE-2 vá kích thước bằng `RandomAccessFile`; mật khẩu tối thiểu 8 ký tự | -- | -- | py + java: `zip_pack_check` (bộ đọc độc lập theo đặc tả WinZip; 2 thử âm tính); Kotlin chỉ rà tĩnh |
| 22 | (tiếp) `TextExporters.jsonString` / `jsonFromParagraphs` / `json` / `xmlAttr` / `xmlFromParagraphs` / `xml` / `base64`, `MainActivity` (`askTextFormat` 4 lựa chọn, `exportText(kind)`, `exportBase64`, danh sách lịch sử nhận `json` `xml` `b64`), `FileUtils.mimeTypeFor` + 3 chuỗi mới và 1 nhãn sửa ở 12 ngôn ngữ (mục 4.49.2) | `exportText` nhận tên loại thay cho cờ `asHtml`; Base64 tự viết, đọc theo khối bội của 3 | -- | -- | py + java: `text_formats_check` (json / lxml / xmllint / `base64 -d`; 2 thử âm tính); Kotlin chỉ rà tĩnh |
| 22 | (tiếp) `AppLock.GRACE_OPTIONS_MS` / `graceIndex` / `setGraceIndex` (bỏ `GRACE_MS`), `MainActivity` (`tvLockDelay`, `updateLockDelayRow`, `showLockDelayDialog`), `activity_main.xml` + `layout-sw600dp` (sinh lại), 8 chuỗi ở 12 ngôn ngữ (mục 4.49.3) | mức ngắn nhất 5 giây vì xoay màn hình; đổi mức không đòi xác thực; hộp thoại bằng RadioGroup | -- | `GRACE_MS` | py: `app_lock_check` (hằng số đọc từ Kotlin, 5 mức x 5 tình huống, thử âm tính); Kotlin chỉ rà tĩnh |
| 22 | (tiếp) `LinkImport.kt` (`parse`, `resolveRedirect`, `sniffExtension`, `dispositionName`, `fileName`, `download`), `MainActivity` (`showLinkImportMenu`, `askLinkUrl`, `importFromLink`, `importFromClipboard`, `savePdfFromUri`, `saveClipboardText`), thẻ `cardToolLink` + `ic_link.xml` + `layout-sw600dp` (sinh lại), 17 chuỗi ở 12 ngôn ngữ (mục 4.49.4) | chỉ https và tự từ chối http dù cấu hình mạng cho phép; nhận dạng bằng byte đầu; so độ dài khai báo vì JDK không báo tải cụt; chuyển hướng theo dõi tay | -- | -- | py + java: `link_import_check` (máy chủ cục bộ, 21 tình huống mạng); Kotlin chỉ rà tĩnh |
| 22 | (tiếp) `EpubSearch.kt` (`fold`, `search`, `render`), `MainActivity.searchInEpub` + mục menu EPUB "Tìm trong sách…", 8 chuỗi ở 12 ngôn ngữ (mục 4.49.5) | gấp chữ có bảng ánh xạ chỉ số về văn bản gốc (chịu được dấu tách rời); tổng đếm đủ dù cắt 300; kết quả mở bằng `TextResultActivity` có sẵn | -- | -- | py + java: `epub_search_check` (đối chứng độc lập, 397 truy vấn; thử âm tính); Kotlin chỉ rà tĩnh |
| 22 | (tiếp) `ScanWidgetProvider.kt`, `widget_scan.xml`, `scan_widget_info.xml`, `bg_widget.xml`, `<receiver>` trong `AndroidManifest.xml`, 2 chuỗi ở 12 ngôn ngữ (mục 4.49.6) | dùng lại hành động của lối tắt (`handleShortcutIntent`), không đường mới; cờ SINGLE_TOP để không chồng bản thứ hai | -- | -- | chỉ rà tĩnh (`i18n_check`, `accessibility_check`, `night_theme_check`, `doc_sync_check`); CHƯA thử trên launcher |
| 22 | (tiếp) `IntervalShooter.kt`, `CaptureActivity` (`btnInterval`, `onShutter`, `startBurst` / `stopBurst`, `burstTick`, `takePhoto(burst)`, `closeCapture`, `handOverBurst`), `activity_capture.xml`, 5 chuỗi ở 12 ngôn ngữ (mục 4.49.7) | chu kỳ tính từ lúc bắt đầu ảnh, không chồng, không bù; ảnh liên tiếp chờ trong bộ nhớ rồi vào hàng đợi cắt mà không xoá phiên; X / Back không bỏ ảnh | -- | -- | py + java: `interval_shooter_check` (600 phiên mô phỏng, tính chất trên vết); Kotlin / camera chưa chạy |
| 22 | (tiếp) `Pkcs12Import.kt`, `PdfDigitalSigner.importPkcs12` / `commonName` + chuỗi chứng thư khi ký, `CmsSigner` (chuỗi chứng thư nhúng, ECDSA không NULL), `MainActivity` (hộp chọn chứng thư, `certificatePicker`, `importCertificateFile`), `CmsCheck.java` mở rộng, `timestamp_check.py` sửa lỗi ngẫu nhiên, 14 chuỗi ở 12 ngôn ngữ (mục 4.49.8) | khoá chuyển vào Android Keystore (không đọc ngược); kiểm khoá khớp chứng thư bằng ký-rồi-kiểm; mật khẩu rỗng được phép (hộp riêng); chỉ ghi CN vào /Name | -- | -- | py + java + openssl + pdfsig: `pkcs12_sign_check` (27+ phép kiểm, 2 thử âm tính); Keystore / BouncyCastle Android CHƯA chạy |
| 22 | (tiếp) `Pkcs12Modern.kt` (bộ đọc `.p12` dự phòng), `Pkcs12Import.readWith` (thử hệ thống rồi dự phòng) + `passwordVariants` (gõ / NFC / NFD), chuỗi `digsign_import_bad_file` sửa ở 12 ngôn ngữ, `pkcs12_bc_check`, `pkcs12_modern_check`, NSS trong `pkcs12_sign_check` (mục 4.49.8) | tra cứu: OpenSSL 3 `.p12` không đọc được trên nhiều Android và bị báo nhầm sai mật khẩu; đo: BouncyCastle không chuẩn hoá Unicode | -- | -- | py + java + openssl + certutil + pdfsig + BouncyCastle: 3 bộ kiểm; Kotlin / Android chưa chạy |
| 22 | (tiếp) `tools/verify/kotlin_lint_check.py` + bước CI "Kotlin lexical lint" trong `android-build.yml`, `Pkcs12Modern.Node` gọi `Pkcs12Modern.read` có tiền tố (mục 4.49.9) | rà từ vựng thay cho trình biên dịch; bỏ rule độ ưu tiên sai | -- | -- | py: 188 tệp 0 phát hiện, 23 ca tự kiểm; không thay được kotlinc |
| 22 | (tiếp) `VisibleSignature.kt`, `PdfDigitalSigner.sign(stampLines)` (trả true / false, ký lại không dấu nếu lỗi trước khi ký) + vùng chữ ký theo chuỗi chứng thư, `MainActivity` (hộp chọn dấu trong `confirmDigitalSign`, `runDigitalSign(visibleStamp)`), 3 chuỗi ở 12 ngôn ngữ (mục 4.49.10) | PDF mẫu viết tay (không gọi API PDFBox khác ngoài `SignatureOptions`); ma trận bù xoay; mặc định tắt | -- | -- | py + java + poppler + qpdf + pikepdf: `visible_signature_check` (20 ca xoay + 4 ghép + 2 thử âm tính); PDFBox 2.0 thật CHƯA chạy |
| 22 | (tiếp) `TagTree.kt`, `HistoryFilter.arrange` (lọc thư mục cha gồm con), `TagStore.cleanTag` (dọn dấu /, giới hạn 60), `MainActivity.showTagFilterDialog` (cây thư mục), `history_filter_check.py` mở rộng, 2 chuỗi sửa ở 12 ngôn ngữ (mục 4.49.11) | thư mục = thẻ có dấu / (không di chuyển tệp, không đổi đường nào khác); một tài liệu nằm được trong nhiều thư mục | -- | `MAX_TAG_LENGTH` 30 | py: port + đối chứng vét cạn 300 bộ; Kotlin chưa biên dịch |
| 22 | (tiếp) `DocumentWebhook.kt`, `MainActivity` (`updateWebhookRow`, `showWebhookDialog`, `maybeSendWebhooks`, gọi sau `refreshHistory`), `tvWebhook` trong `activity_main.xml` + `layout-sw600dp` (sinh lại), 10 chuỗi ở 12 ngôn ngữ; SỬA: `renderHistory` không còn tự bỏ bộ lọc thư mục cha (so bằng `TagTree.matches`) (mục 4.49.12 và 4.49.11) | webhook TẮT mặc định, https, không theo chuyển hướng, HMAC-SHA256, lần đầu bật coi mọi tài liệu có sẵn là đã thấy; F6 = Intent tường minh có sẵn, không thêm broadcast | -- | -- | py + java: `webhook_check` (máy chủ cục bộ); Kotlin chưa biên dịch |
| 22 | (tiếp) `BaseActivity.kt` (32 Activity chuyển sang), `FontScale.kt`, `MainActivity` (`tvTextSize`, `showTextSizeDialog`), `colors.xml` (`text_secondary` sáng #616161 -> #525252), `night_theme_check.py` đòi AAA, `base_activity_check.py` mới, 7 chuỗi ở 12 ngôn ngữ (mục 4.49.13) | Chuẩn trả về chính context (không đổi hành vi); không ghi đè applyOverrideConfiguration (ngôn ngữ riêng); chữ AAA thay cho chế độ tương phản riêng | -- | -- | py: `base_activity_check` (32 Activity, FontScale, sp, AAA), `night_theme_check` AAA; Kotlin / máy thật chưa chạy |
| 22 | (tiếp) `build.gradle` (`camera-extensions:1.4.1`), `CaptureActivity` (`startCamera` tách thành `bindUseCases`, `cycleExtension`, `updateExtensionLabel`), `activity_capture.xml` (`btnExtension`), 4 chuỗi ở 12 ngôn ngữ (mục 4.49.14) | mặc định thường = đúng đường cũ; máy không hỗ trợ tự về thường; bỏ ImageAnalysis nếu extension không chạy chung | -- | -- | chỉ rà tĩnh (`static_refs_check` bắt thiếu import); CameraX Extensions CHƯA chạy / chưa biên dịch |
| 22 | (tiếp) `MainActivity` (`cardToolSnap`, `snapLauncher`, `startSnapTranslate`, `readSnap`, `translateSnap`), `file_paths.xml` (`translate_snap`), `activity_main.xml` + `layout-sw600dp` (sinh lại), 3 chuỗi ở 12 ngôn ngữ (mục 4.49.15) | máy ảnh hệ thống + OCR ML Kit + dịch trên máy; một ảnh chứ không phải lớp phủ trực tiếp; ảnh xoá ngay | -- | -- | chỉ rà tĩnh; CHƯA chạy; EXIF xoay chưa xử lý |
| 23 | `EpubNotes.kt`, `EpubReaderActivity.kt`, `adapter/EpubRowAdapter.kt`, `activity_epub_reader.xml`, `item_epub_row.xml`, `menu_epub_reader.xml`, `<activity>` trong `AndroidManifest.xml`, `MainActivity` (mục "Đọc sách…" trong menu EPUB), 22 chuỗi ở 12 ngôn ngữ (mục 4.50) | ghi chú gắn dấu vân tay sách, sách đổi thì tệp cũ thành `.stale`; đánh dấu bằng nền dòng không chèn ký tự; tô sáng nền vàng + chữ đen; không WebView | -- | -- | py + java: `epub_notes_check` (9 103 trạng thái, 900 tệp bị phá, 5 đột biến); giao diện chưa chạy / chưa biên dịch |
| 23 | (tiếp) `tools/verify/large_screen_check.py` nhận cả `BaseActivity` | sau phiên 22 mọi Activity kế thừa `BaseActivity`, bộ kiểm cũ tìm `: AppCompatActivity` nên đỏ giả | -- | -- | py: `large_screen_check` đạt |
| 23 | (tiếp) `Revocation.kt`, `PdfLtv.kt`, `MainActivity` (ô LT trong hộp ký số, `runDigitalSign(storeRevocation)`), 4 chuỗi `digsign_ltv_*` x 12 ngôn ngữ (mục 4.51) | /DSS chung, không /VRI; lỗi LT không huỷ chữ ký; chỉ nhúng OCSP "good" đúng chứng thư, không kiểm chữ ký máy chủ OCSP | -- | -- | py + java: `revocation_check` (3 526 lệnh bền vững, 4 thử âm tính), `ltv_pdf_check`; PdfBox / CA thật chưa chạy |
| 23 | (tiếp) `tools/verify/tessdata_pin_check.py`, job `tessdata` trong `.github/workflows/android-build.yml` | công cụ lấy băm `rus.traineddata` trong CI thay vì đoán; đọc hằng từ chính mã Kotlin; không làm đỏ build | -- | -- | py: `tessdata_pin_check.py --selftest` (10 ca, không cần mạng); đường tải thật CHƯA chạy (không có mạng) |
| 23 | (tiếp) `ic_mic.xml`, `activity_main.xml` (+ bản sw600dp sinh lại), `MainActivity` (nút micro, `voiceSearchLauncher`), 3 chuỗi `history_voice_*` x 12 ngôn ngữ (mục 4.52) | nhận giọng bằng `RecognizerIntent` của hệ thống: không quyền micro, không `<queries>`; câu quyền riêng tư cần chủ dự án quyết | -- | -- | tĩnh; CHƯA biên dịch / chạy |
| 23 | (tiếp) `tools/verify/local_network_check.py`, mục 4.53 (kiểm kê PDF A1-N10 với mã, M8 / M9, quyền mạng cục bộ Android 17) | bộ kiểm chặn việc nâng targetSdk 37 mà quên ACCESS_LOCAL_NETWORK; M8 bỏ vì Android Beam đã gỡ | -- | -- | py: `local_network_check.py --selftest` (9 ca) và chạy trên dự án; hành vi Android 17 thật chưa kiểm |
| 23 | (tiếp) `PdfAutoLinks.kt` (`overlaps` -> `private`), `tools/verify/kotlin_exposure_check.py`, workflow (bước "Kotlin exposure check"), mục 4.54 | lỗi biên dịch thật đầu tiên (CI #21) và bộ kiểm chặn cả lớp lỗi "lộ kiểu private" | -- | -- | CI #21 đỏ 1 lỗi; sau sửa: `kotlin_exposure_check` 20 ca tự kiểm + 0 lỗi trên 198 tệp; CI chạy lại CHƯA biết |\n
| 23 | (tiếp) `activity_main.xml` (+ sw600dp sinh lại), 6 chuỗi `tool_group_*` x 12 ngôn ngữ, `CaptureActivity` (thông báo khi từ chối quyền camera), `MainActivity` (xoá `showOcrNote`), mục 4.55 | gom 27 công cụ độc lập thành 6 nhóm; sửa lỗi im lặng khi từ chối quyền camera | -- | -- | tĩnh: i18n, tablet_layout, accessibility, night_theme, static_refs, kotlin_lint, kotlin_exposure; CHƯA xem trên máy |
| 23 | (tiếp) `MainActivity` (`showGroupedActions`, `HISTORY_ACTION_GROUPS`), `PdfSignActivity` (nút hoàn tác), 6 chuỗi mới x 12 ngôn ngữ (`history_group_*`, `sign_pad_undo`), `tools/verify/history_menu_groups_check.py`, mục 4.56 | menu nhấn giữ chia 5 nhóm khi > 8 hành động; nút hoàn tác ô ký; cố ý không làm cảnh báo glyph theo phím | -- | -- | tĩnh: history_menu_groups_check và các bộ kiểm khác đạt; CHƯA biên dịch / chạy |
