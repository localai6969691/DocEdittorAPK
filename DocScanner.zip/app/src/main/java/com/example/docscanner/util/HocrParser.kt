package com.example.docscanner.util

/**
 * Reads the hOCR text (a small HTML dialect) that Tesseract's `getHOCRText(0)` returns, into paragraphs -> lines -> words with
 * their pixel boxes. Used by [TesseractOcr] only; no Android classes here, so the same algorithm runs unchanged in
 * `tools/verify/HocrCheck.java` against REAL Tesseract output (see TECHNICAL_DOCS 4.48.8 (9)).
 *
 * Why hOCR and not the result iterator: `getHOCRText` is a single call that already groups words into lines and paragraphs in
 * reading order, and its format is the same in every Tesseract version (checked against Tesseract 5.3.4 output):
 * `<p class='ocr_par' ...>`, `<span class='ocr_line' ... title="bbox x0 y0 x1 y1; baseline ...">`,
 * `<span class='ocrx_word' ... title='bbox x0 y0 x1 y1; x_wconf 96'>text</span>`.
 */
object HocrParser {

    class Word(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int, val confidence: Int)

    class Line(val words: List<Word>)

    /** Words below this confidence (0-100) are noise (specks, page edges...) and are dropped from the invisible text layer. */
    const val MIN_CONFIDENCE = 20

    private val TAG = Regex("""<(p|span)\s+class=['"](ocr_par|ocr_line|ocrx_word)['"][^>]*?title\s*=\s*(?:'([^']*)'|"([^"]*)")[^>]*>""")
    private val BBOX = Regex("""bbox\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)""")
    private val WCONF = Regex("""x_wconf\s+(\d+)""")
    private val ANY_TAG = Regex("<[^>]*>")
    private val NUM_ENTITY = Regex("&#(x[0-9a-fA-F]+|\\d+);")

    /** Paragraphs in reading order; each is a list of lines; each line a list of words (left to right). */
    fun paragraphs(hocr: String): List<List<Line>> {
        val result = ArrayList<List<Line>>()
        var paragraph = ArrayList<Line>()
        var words: ArrayList<Word>? = null
        fun closeLine() {
            val w = words
            if (w != null && w.isNotEmpty()) paragraph.add(Line(w))
            words = null
        }
        fun closeParagraph() {
            closeLine()
            if (paragraph.isNotEmpty()) result.add(paragraph)
            paragraph = ArrayList()
        }
        var pos = 0
        while (true) {
            val m = TAG.find(hocr, pos) ?: break
            val cls = m.groupValues[2]
            val title = if (m.groupValues[3].isNotEmpty()) m.groupValues[3] else m.groupValues[4]
            pos = m.range.last + 1
            when (cls) {
                "ocr_par" -> closeParagraph()
                "ocr_line" -> { closeLine(); words = ArrayList() }
                else -> {
                    val end = hocr.indexOf("</span>", pos)
                    if (end < 0) break
                    val raw = hocr.substring(pos, end)
                    pos = end + "</span>".length
                    val box = BBOX.find(title) ?: continue
                    val text = decode(ANY_TAG.replace(raw, "")).trim()
                    if (text.isEmpty()) continue
                    val conf = WCONF.find(title)?.groupValues?.get(1)?.toIntOrNull() ?: 100
                    if (conf < MIN_CONFIDENCE) continue
                    if (words == null) words = ArrayList()
                    val g = box.groupValues
                    words!!.add(Word(text, g[1].toInt(), g[2].toInt(), g[3].toInt(), g[4].toInt(), conf))
                }
            }
        }
        closeParagraph()
        return result
    }

    fun lines(hocr: String): List<Line> = paragraphs(hocr).flatten()

    /** `&amp; &lt; &gt; &quot; &#39; &apos;` and numeric references (`&#1087;`, `&#x43F;`). `&amp;` is decoded LAST so `&amp;lt;` stays `&lt;`. */
    internal fun decode(s: String): String {
        if (s.indexOf('&') < 0) return s
        val numeric = NUM_ENTITY.replace(s) { m ->
            val body = m.groupValues[1]
            val cp = if (body.startsWith("x")) body.substring(1).toIntOrNull(16) else body.toIntOrNull()
            if (cp == null || cp <= 0 || cp > 0x10FFFF) m.value else String(Character.toChars(cp))
        }
        return numeric.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
    }
}
