package com.example.docscanner.util

import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream

/**
 * How wide each table column is (phiên 19, mục 4.47.2). Pure arithmetic, mirrored in tools/verify/DocImportCheck.java (`columnWidths`) and checked by doc_import_check.py:
 * the widths add up to `min(sum of natural widths, available)`, no column is wider than it wants or narrower than `min(natural, minWidth)` while there is room, and a column that
 * wants more than another never gets less.
 */
object TableLayout {
    /**
     * @param natural the width each column needs to show its longest line without wrapping
     * @param available the width of the page between the margins
     * @param minWidth a column is not squeezed below this (or below its own natural width when that is smaller) as long as the others can give way
     */
    fun columnWidths(natural: FloatArray, available: Float, minWidth: Float): FloatArray {
        val n = natural.size
        if (n == 0) return FloatArray(0)
        val total = natural.sum()
        if (total <= available) return natural.copyOf()
        val base = FloatArray(n) { minOf(natural[it], minWidth) }
        val sumBase = base.sum()
        if (sumBase >= available) return FloatArray(n) { base[it] * available / sumBase }   // even the minimums do not fit: shrink them all in proportion
        val extra = available - sumBase
        val sumNeed = total - sumBase
        return FloatArray(n) { base[it] + (natural[it] - base[it]) * extra / sumNeed }      // share what is left in proportion to what each column still wants
    }
}

/**
 * Draws a CSV / TSV table as real text in a grid (A4; landscape when the columns do not fit the width of a portrait page): the first row is the header (grey, bold, repeated at the
 * top of every page), long cells wrap inside their column, and a row is never split across pages. The cell text stays selectable and searchable because it is drawn with
 * `drawText`, like [TextPdfBuilder].
 */
object TablePdfBuilder {
    private const val MARGIN = 36f
    private const val FONT = 9f
    private const val LINE = 12f
    private const val PAD = 4f
    private const val MAX_NATURAL = 260f
    private const val MIN_COL = 48f
    private const val SAMPLE_ROWS = 2000
    private const val MAX_ROWS = 60000

    /** Writes [rows] to [outFile]; false (nothing written) when there are no rows or more than 60 000 of them (the PDF would be thousands of pages). */
    fun build(outFile: File, rows: List<List<String>>): Boolean = buildSheets(outFile, listOf(OfficeImport.Sheet("", rows)))

    /**
     * One PDF for several sheets (a workbook, phiên 20 4.48.2): every sheet starts on a NEW page with its name as a title above the grid, and has its own column widths and
     * orientation; with a single sheet no title is drawn (that is [build]). False (nothing written) when no sheet has a cell or the sheets together have more than 60 000 rows.
     */
    fun buildSheets(outFile: File, sheets: List<OfficeImport.Sheet>): Boolean {
        val usable = sheets.filter { it.rows.isNotEmpty() && it.rows.maxOf { r -> r.size } > 0 }
        if (usable.isEmpty() || usable.sumOf { it.rows.size } > MAX_ROWS) return false
        val document = PdfDocument()
        var pageNumber = 0
        for (sheet in usable) pageNumber = drawSheet(document, pageNumber, if (usable.size > 1) sheet.name else null, sheet.rows)
        FileOutputStream(outFile).use { document.writeTo(it) }
        document.close()
        return true
    }

    /** Draws one sheet starting on a new page; returns the number of the last page used. */
    private fun drawSheet(document: PdfDocument, firstPage: Int, title: String?, rows: List<List<String>>): Int {
        val cols = rows.maxOf { it.size }

        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = FONT }
        val head = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = FONT; isFakeBoldText = true }
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 12f; isFakeBoldText = true }
        val border = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 0.5f; color = Color.GRAY }
        val fill = Paint().apply { style = Paint.Style.FILL; color = Color.rgb(0xEE, 0xEE, 0xEE) }

        // natural width of every column: its longest line (header in bold) + padding, from the first rows
        val natural = FloatArray(cols)
        for ((r, row) in rows.withIndex()) {
            if (r >= SAMPLE_ROWS) break
            val paint = if (r == 0 && rows.size > 1) head else body
            for (c in 0 until cols) {
                val cell = row.getOrElse(c) { "" }
                var longest = 0f
                for (line in cell.lines()) longest = maxOf(longest, paint.measureText(line))
                natural[c] = maxOf(natural[c], minOf(longest + 2 * PAD, MAX_NATURAL))
            }
        }
        val portraitWidth = 595f
        val landscape = natural.sum() > portraitWidth - 2 * MARGIN
        val pageW = if (landscape) 842 else 595
        val pageH = if (landscape) 595 else 842
        val widths = TableLayout.columnWidths(natural, pageW - 2 * MARGIN, MIN_COL)
        val maxLines = ((pageH - 2 * MARGIN) / LINE).toInt() - 2

        fun wrapped(row: List<String>, paint: Paint): List<List<String>> = List(cols) { c ->
            val lines = TextPdfBuilder.wrapText(row.getOrElse(c) { "" }, paint, widths[c] - 2 * PAD)
            when {
                lines.isEmpty() -> listOf("")
                lines.size > maxLines -> lines.take(maxLines - 1) + (lines[maxLines - 1].trimEnd() + "\u2026")
                else -> lines
            }
        }

        var pageNumber = firstPage
        var page: PdfDocument.Page? = null
        var y = MARGIN
        var pendingTitle = title
        val hasHeader = rows.size > 1

        fun drawRow(cells: List<List<String>>, paint: Paint, shaded: Boolean) {
            val h = cells.maxOf { it.size } * LINE + 2 * PAD
            val canvas = page!!.canvas
            var x = MARGIN
            for (c in 0 until cols) {
                if (shaded) canvas.drawRect(x, y, x + widths[c], y + h, fill)
                canvas.drawRect(x, y, x + widths[c], y + h, border)
                for ((k, line) in cells[c].withIndex()) canvas.drawText(line, x + PAD, y + PAD + (k + 1) * LINE - 3f, paint)
                x += widths[c]
            }
            y += h
        }

        var headerCells: List<List<String>>? = null
        fun newPage() {
            page?.let { document.finishPage(it) }
            pageNumber++
            page = document.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNumber).create())
            y = MARGIN
            pendingTitle?.let {
                page!!.canvas.drawText(it, MARGIN, y + 12f, titlePaint)
                y += 22f
                pendingTitle = null
            }
            headerCells?.let { drawRow(it, head, true) }
        }
        if (hasHeader) headerCells = wrapped(rows[0], head)
        newPage()
        for ((r, row) in rows.withIndex()) {
            if (r == 0 && hasHeader) continue
            val cells = wrapped(row, body)
            val h = cells.maxOf { it.size } * LINE + 2 * PAD
            if (y + h > pageH - MARGIN && y > MARGIN + 1f) newPage()
            drawRow(cells, body, false)
        }
        page?.let { document.finishPage(it) }
        return pageNumber
    }
}
