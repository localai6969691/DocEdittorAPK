package com.example.docscanner.util

import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.text.Normalizer

/**
 * "What did the words change between these two versions?" (PDF 11.3; phiên 24, TECHNICAL_DOCS.md 4.68), next to [PdfComparer], which compares what the pages LOOK like. This compares the
 * TEXT of the two PDFs word by word and writes an HTML report of the new version with the added words marked green and the removed words red and struck through. It needs a text layer
 * (a scan has none: the caller says so and offers the picture comparison).
 *
 * The comparison ([diff]) is exact for ordinary documents: after removing the words the two share at the start and the end, a longest-common-subsequence table is used when it has at
 * most [EXACT_CELLS] cells (about 2 000 x 2 000 words of real change); beyond that it works like patience diff: the words that occur exactly once in BOTH texts are anchors (kept in order),
 * and the stretches between anchors are compared the same way; a stretch with no anchors that is still too big is reported as wholly replaced and the result is flagged approximate.
 * Pure; `tools/verify/text_diff_check.py` compares it with an independent LCS and runs the PdfBox extraction on real PDFs.
 */
object TextDiff {

    const val EQUAL = '='
    const val DELETE = '-'
    const val INSERT = '+'
    const val EXACT_CELLS = 4_000_000L

    /** [kind]: EQUAL (a word in both), DELETE (only in the old text, at [oldIndex]) or INSERT (only in the new text, at [newIndex]); the index of the side that has no such word is -1. */
    class Edit(val kind: Char, val oldIndex: Int, val newIndex: Int)

    class Outcome(val edits: List<Edit>, val approximate: Boolean) {
        val kept: Int get() = edits.count { it.kind == EQUAL }
        val removed: Int get() = edits.count { it.kind == DELETE }
        val added: Int get() = edits.count { it.kind == INSERT }
    }

    fun diff(a: List<String>, b: List<String>): Outcome {
        val out = ArrayList<Edit>(maxOf(a.size, b.size) + 16)
        val flag = BooleanArray(1)
        range(a, 0, a.size, b, 0, b.size, out, flag)
        return Outcome(out, flag[0])
    }

    private fun range(a: List<String>, a0: Int, a1: Int, b: List<String>, b0: Int, b1: Int, out: MutableList<Edit>, approx: BooleanArray) {
        var i = a0
        var j = b0
        var ei = a1
        var ej = b1
        while (i < ei && j < ej && a[i] == b[j]) {
            out.add(Edit(EQUAL, i, j))
            i++
            j++
        }
        var tail = 0
        while (ei > i && ej > j && a[ei - 1] == b[ej - 1]) {
            ei--
            ej--
            tail++
        }
        middle(a, i, ei, b, j, ej, out, approx)
        for (k in 0 until tail) out.add(Edit(EQUAL, ei + k, ej + k))
    }

    private fun middle(a: List<String>, a0: Int, a1: Int, b: List<String>, b0: Int, b1: Int, out: MutableList<Edit>, approx: BooleanArray) {
        val n = a1 - a0
        val m = b1 - b0
        if (n == 0 || m == 0) {
            for (i in a0 until a1) out.add(Edit(DELETE, i, -1))
            for (j in b0 until b1) out.add(Edit(INSERT, -1, j))
            return
        }
        if (n.toLong() * m.toLong() <= EXACT_CELLS) {
            exact(a, a0, a1, b, b0, b1, out)
            return
        }
        val anchors = anchors(a, a0, a1, b, b0, b1)
        if (anchors.isEmpty()) {
            approx[0] = true
            for (i in a0 until a1) out.add(Edit(DELETE, i, -1))
            for (j in b0 until b1) out.add(Edit(INSERT, -1, j))
            return
        }
        var pa = a0
        var pb = b0
        for ((ia, ib) in anchors) {
            range(a, pa, ia, b, pb, ib, out, approx)
            out.add(Edit(EQUAL, ia, ib))
            pa = ia + 1
            pb = ib + 1
        }
        range(a, pa, a1, b, pb, b1, out, approx)
    }

    /** Longest common subsequence by the textbook table; on a tie a word is taken out of the old text before a word is put in (the removed words come first). */
    private fun exact(a: List<String>, a0: Int, a1: Int, b: List<String>, b0: Int, b1: Int, out: MutableList<Edit>) {
        val n = a1 - a0
        val m = b1 - b0
        val width = m + 1
        val table = IntArray((n + 1) * width)
        for (i in n - 1 downTo 0) {
            for (j in m - 1 downTo 0) {
                table[i * width + j] = if (a[a0 + i] == b[b0 + j]) table[(i + 1) * width + j + 1] + 1
                else maxOf(table[(i + 1) * width + j], table[i * width + j + 1])
            }
        }
        var i = 0
        var j = 0
        while (i < n && j < m) {
            if (a[a0 + i] == b[b0 + j]) {
                out.add(Edit(EQUAL, a0 + i, b0 + j))
                i++
                j++
            } else if (table[(i + 1) * width + j] >= table[i * width + j + 1]) {
                out.add(Edit(DELETE, a0 + i, -1))
                i++
            } else {
                out.add(Edit(INSERT, -1, b0 + j))
                j++
            }
        }
        while (i < n) {
            out.add(Edit(DELETE, a0 + i, -1))
            i++
        }
        while (j < m) {
            out.add(Edit(INSERT, -1, b0 + j))
            j++
        }
    }

    /** Words that occur exactly once in a[a0, a1) and exactly once in b[b0, b1), as (index in a, index in b) pairs in increasing order of both (the longest such chain). */
    private fun anchors(a: List<String>, a0: Int, a1: Int, b: List<String>, b0: Int, b1: Int): List<Pair<Int, Int>> {
        val countA = HashMap<String, Int>()
        val countB = HashMap<String, Int>()
        val posB = HashMap<String, Int>()
        for (i in a0 until a1) countA[a[i]] = (countA[a[i]] ?: 0) + 1
        for (j in b0 until b1) {
            countB[b[j]] = (countB[b[j]] ?: 0) + 1
            posB[b[j]] = j
        }
        val pairs = ArrayList<Pair<Int, Int>>()
        for (i in a0 until a1) {
            val w = a[i]
            if (countA[w] == 1 && countB[w] == 1) pairs.add(Pair(i, posB[w]!!))
        }
        if (pairs.isEmpty()) return pairs
        // longest increasing subsequence of the b positions (patience sorting), pairs are already in increasing order of the a position
        val tails = ArrayList<Int>()
        val previous = IntArray(pairs.size) { -1 }
        for (k in pairs.indices) {
            var lo = 0
            var hi = tails.size
            while (lo < hi) {
                val mid = (lo + hi) / 2
                if (pairs[tails[mid]].second < pairs[k].second) lo = mid + 1 else hi = mid
            }
            if (lo > 0) previous[k] = tails[lo - 1]
            if (lo == tails.size) tails.add(k) else tails[lo] = k
        }
        val chain = ArrayList<Pair<Int, Int>>()
        var k = tails[tails.size - 1]
        while (k >= 0) {
            chain.add(pairs[k])
            k = previous[k]
        }
        chain.reverse()
        return chain
    }

    // ------------------------------------------------------------------------------------------------ PDF text

    /** The words of a PDF, each with the 0-based page it is on; null for an encrypted or unreadable file. A PDF with no text layer gives an empty list. */
    class Words(val words: List<String>, val pages: IntArray)

    fun words(file: File): Words? {
        return try {
            PDDocument.load(file).use { doc ->
                if (doc.isEncrypted) return null
                val out = ArrayList<String>()
                val pageOf = ArrayList<Int>()
                val stripper = PDFTextStripper()
                stripper.sortByPosition = true
                for (p in 0 until doc.numberOfPages) {
                    stripper.startPage = p + 1
                    stripper.endPage = p + 1
                    val text = Normalizer.normalize(stripper.getText(doc), Normalizer.Form.NFC)
                    for (token in text.split(Regex("\\s+"))) {
                        if (token.isNotEmpty()) {
                            out.add(token)
                            pageOf.add(p)
                        }
                    }
                }
                Words(out, pageOf.toIntArray())
            }
        } catch (e: Exception) {
            null
        }
    }

    class Result(val oldWords: Int, val newWords: Int, val kept: Int, val removed: Int, val added: Int, val pagesChanged: List<Int>, val approximate: Boolean) {
        val identical: Boolean get() = removed == 0 && added == 0
    }

    /**
     * Compares the text of [oldFile] and [newFile] and writes the report to [report] (HTML, UTF-8). null when either file cannot be read. [pagesChanged] are 1-based page numbers of the NEW file
     * where a word was added, or where words were removed (a removal is shown on the page of the word that follows it).
     */
    fun compare(oldFile: File, newFile: File, report: File, title: String): Result? {
        val old = words(oldFile) ?: return null
        val new = words(newFile) ?: return null
        val outcome = diff(old.words, new.words)
        val changed = java.util.TreeSet<Int>()
        var page = 0
        val body = StringBuilder()
        var currentPage = -1
        fun pageFor(edit: Edit): Int = if (edit.newIndex >= 0) new.pages[edit.newIndex] else page
        for (edit in outcome.edits) {
            val p = pageFor(edit)
            if (edit.kind != EQUAL) changed.add(p + 1)
            if (edit.newIndex >= 0) page = new.pages[edit.newIndex]
            if (p != currentPage) {
                if (currentPage >= 0) body.append("</p>\n")
                body.append("<h2>Trang ").append(p + 1).append("</h2>\n<p>")
                currentPage = p
            }
            when (edit.kind) {
                EQUAL -> body.append(escape(new.words[edit.newIndex])).append(' ')
                INSERT -> body.append("<ins>").append(escape(new.words[edit.newIndex])).append("</ins> ")
                else -> body.append("<del>").append(escape(old.words[edit.oldIndex])).append("</del> ")
            }
        }
        if (currentPage >= 0) body.append("</p>\n")
        val html = StringBuilder()
        html.append("<!DOCTYPE html>\n<html lang=\"vi\"><head><meta charset=\"utf-8\"><title>").append(escape(title)).append("</title>\n")
        html.append("<style>body{font-family:serif;max-width:46em;margin:2em auto;padding:0 1em;line-height:1.6}ins{background:#c8f7c5;text-decoration:none}del{background:#f7c5c5}h2{font-size:1em;color:#555;border-top:1px solid #ccc;padding-top:.6em}</style>\n")
        html.append("</head><body>\n<h1>").append(escape(title)).append("</h1>\n")
        html.append("<p><ins>+").append(outcome.added).append("</ins> <del>-").append(outcome.removed).append("</del> (").append(outcome.kept).append(" =)</p>\n")
        html.append(body).append("</body></html>\n")
        report.writeText(html.toString(), Charsets.UTF_8)
        return Result(old.words.size, new.words.size, outcome.kept, outcome.removed, outcome.added, changed.toList(), outcome.approximate)
    }

    private fun escape(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
}
