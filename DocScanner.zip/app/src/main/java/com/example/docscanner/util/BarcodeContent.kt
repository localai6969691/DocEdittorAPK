package com.example.docscanner.util

import java.io.ByteArrayOutputStream

/**
 * What a scanned QR / barcode MEANS (phiên 17, mục 4.31): turns the raw string ML Kit reads into a kind and named fields so the screen can offer the right action
 * (open the link, join the Wi-Fi, write the e-mail, dial, add the contact...). Pure string code, mirrored in tools/verify/BarcodeContentCheck.java and
 * checked by tools/verify/barcode_content_check.py with round trips (build the code string the way ZXing / phones write it, parse it, get the same fields back).
 *
 * Formats (ZXing wiki "Barcode Contents", the de-facto standard that phones and generators follow):
 *  - `WIFI:T:WPA;S:name;P:password;H:true;;` - fields separated by `;`, values escape `\ ; , : "` with a backslash; a value that is all hex digits may be quoted `"..."`.
 *  - `mailto:a@b.c?subject=..&body=..` (RFC 6068) and DoCoMo `MATMSG:TO:a@b.c;SUB:..;BODY:..;;`
 *  - `tel:+84...`, `smsto:number:text`, `sms:number?body=text`, `geo:lat,lon[,alt][?q=..]`
 *  - `BEGIN:VCARD ... END:VCARD` and DoCoMo `MECARD:N:Last,First;TEL:..;EMAIL:..;;`, `BEGIN:VEVENT` (calendar event, shown as text)
 *  - plain `http(s)://...` or a bare `www.` address; product codes (EAN / UPC / ISBN) arrive as digits with a product barcode FORMAT.
 * Percent-escapes are decoded WITHOUT turning `+` into a space (a `+` is legal in a mail address and in a phone number).
 * Nothing is ever fetched or opened by this class: the screen shows the FULL address before it is opened (a QR code can hide a look-alike link).
 */
object BarcodeContent {

    enum class Kind { URL, WIFI, EMAIL, PHONE, SMS, GEO, CONTACT, EVENT, PRODUCT, TEXT }

    class Parsed(val kind: Kind, val raw: String, val fields: Map<String, String>)

    fun parse(rawInput: String, productFormat: Boolean = false): Parsed {
        val raw = rawInput.trim()
        val upper = raw.uppercase()
        fun p(kind: Kind, vararg f: Pair<String, String>) = Parsed(kind, raw, linkedMapOf(*f))
        if (raw.isEmpty()) return p(Kind.TEXT)
        when {
            upper.startsWith("WIFI:") -> {
                val f = semicolonFields(raw, 5)
                val ssid = f["S"] ?: ""
                if (ssid.isNotEmpty()) {
                    val sec = (f["T"] ?: "nopass").let { if (it.isEmpty()) "nopass" else it.uppercase().let { u -> if (u == "NOPASS") "nopass" else u } }
                    return p(Kind.WIFI, "ssid" to ssid, "password" to (f["P"] ?: ""), "security" to sec, "hidden" to (f["H"] ?: "false").lowercase())
                }
            }
            upper.startsWith("MATMSG:") -> {
                val f = semicolonFields(raw, 7)
                return p(Kind.EMAIL, "address" to (f["TO"] ?: ""), "subject" to (f["SUB"] ?: ""), "body" to (f["BODY"] ?: ""))
            }
            upper.startsWith("MAILTO:") -> {
                val rest = raw.substring(7)
                val q = rest.indexOf('?')
                val addr = percentDecode(if (q >= 0) rest.substring(0, q) else rest)
                val query = if (q >= 0) queryMap(rest.substring(q + 1)) else emptyMap()
                return p(Kind.EMAIL, "address" to addr, "subject" to (query["subject"] ?: ""), "body" to (query["body"] ?: ""))
            }
            upper.startsWith("TEL:") -> return p(Kind.PHONE, "number" to percentDecode(raw.substring(4)).trim())
            upper.startsWith("SMSTO:") || upper.startsWith("SMS:") -> {
                val rest = raw.substring(raw.indexOf(':') + 1)
                // `smsto:number:text` (what ZXing writes) is ALWAYS split at the first colon, even if the text contains `?`;
                // only `sms:number?body=text` (RFC 5724) is a query.
                if (upper.startsWith("SMS:") && rest.contains('?')) {
                    val q = rest.indexOf('?')
                    val query = queryMap(rest.substring(q + 1))
                    return p(Kind.SMS, "number" to percentDecode(rest.substring(0, q)), "body" to (query["body"] ?: ""))
                }
                val c = rest.indexOf(':')
                return if (c >= 0) p(Kind.SMS, "number" to rest.substring(0, c), "body" to rest.substring(c + 1))
                else p(Kind.SMS, "number" to rest, "body" to "")
            }
            upper.startsWith("GEO:") -> {
                val rest = raw.substring(4).substringBefore('?')
                val parts = rest.split(',')
                val lat = parts.getOrNull(0)?.trim()?.toDoubleOrNull()
                val lon = parts.getOrNull(1)?.trim()?.toDoubleOrNull()
                if (lat != null && lon != null && lat in -90.0..90.0 && lon in -180.0..180.0) {
                    return p(Kind.GEO, "lat" to parts[0].trim(), "lon" to parts[1].trim())
                }
            }
            upper.startsWith("MECARD:") -> {
                val f = semicolonFields(raw, 7)
                val n = f["N"] ?: ""
                val name = if (n.contains(',')) n.substringAfter(',').trim() + " " + n.substringBefore(',').trim() else n
                return p(Kind.CONTACT, "name" to name.trim(), "phone" to (f["TEL"] ?: ""), "email" to (f["EMAIL"] ?: ""), "org" to (f["ORG"] ?: ""))
            }
            upper.startsWith("BEGIN:VCARD") -> {
                val v = vLines(raw)
                return p(Kind.CONTACT, "name" to (v["FN"] ?: v["N"]?.split(';')?.filter { it.isNotEmpty() }?.reversed()?.joinToString(" ") ?: ""), "phone" to (v["TEL"] ?: ""), "email" to (v["EMAIL"] ?: ""), "org" to (v["ORG"] ?: ""))
            }
            upper.startsWith("BEGIN:VEVENT") || upper.startsWith("BEGIN:VCALENDAR") -> {
                val v = vLines(raw)
                return p(Kind.EVENT, "summary" to (v["SUMMARY"] ?: ""), "start" to (v["DTSTART"] ?: ""), "end" to (v["DTEND"] ?: ""), "location" to (v["LOCATION"] ?: ""))
            }
            upper.startsWith("HTTP://") || upper.startsWith("HTTPS://") -> if (!raw.any { it.isWhitespace() }) return p(Kind.URL, "url" to raw)
            upper.startsWith("WWW.") && !raw.any { it.isWhitespace() } && raw.contains('.') -> return p(Kind.URL, "url" to "https://$raw")
        }
        if (productFormat && raw.isNotEmpty() && raw.all { it in '0'..'9' }) {
            val isbn = raw.length == 13 && (raw.startsWith("978") || raw.startsWith("979"))
            return p(Kind.PRODUCT, "code" to raw, "isbn" to (if (isbn) raw else ""))
        }
        return p(Kind.TEXT, "text" to raw)
    }

    /** `PREFIX k:v;k:v;;` with `\x` escapes. Keys are upper-cased. Quotes AROUND a value (`"0123"`, how generators mark an all-digit value) are removed - but only
     *  UNESCAPED ones: a password that really starts and ends with `"` is written `\"..\"` and must keep them. */
    fun semicolonFields(raw: String, from: Int): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        var i = from
        while (i < raw.length) {
            val c = raw.indexOf(':', i)
            if (c < 0) break
            val key = raw.substring(i, c).trim().uppercase()
            i = c + 1
            val chars = StringBuilder()
            val escaped = ArrayList<Boolean>()
            while (i < raw.length) {
                val ch = raw[i]
                if (ch == '\\' && i + 1 < raw.length) { chars.append(raw[i + 1]); escaped.add(true); i += 2 }
                else if (ch == ';') { i++; break }
                else { chars.append(ch); escaped.add(false); i++ }
            }
            var v = chars.toString()
            if (v.length >= 2 && v[0] == '"' && !escaped[0] && v[v.length - 1] == '"' && !escaped[escaped.size - 1]) v = v.substring(1, v.length - 1)
            if (key.isNotEmpty() && !out.containsKey(key)) out[key] = v
            if (i < raw.length && raw[i] == ';') break   // the closing ";;"
        }
        return out
    }

    /** vCard / vCalendar: `NAME;params:value` per line; the FIRST value of each name wins, names upper-cased without parameters. */
    fun vLines(raw: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for (line in raw.split('\n')) {
            val l = line.trim('\r', ' ')
            val c = l.indexOf(':')
            if (c <= 0) continue
            val name = l.substring(0, c).substringBefore(';').trim().uppercase()
            if (name == "BEGIN" || name == "END" || name == "VERSION") continue
            if (!out.containsKey(name)) out[name] = l.substring(c + 1).trim()
        }
        return out
    }

    fun queryMap(q: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for (pair in q.split('&')) {
            val e = pair.indexOf('=')
            if (e <= 0) continue
            val k = percentDecode(pair.substring(0, e)).lowercase()
            if (!out.containsKey(k)) out[k] = percentDecode(pair.substring(e + 1))
        }
        return out
    }

    /** `%HH` runs -> bytes -> UTF-8; a malformed `%` stays as it is; `+` stays `+`; every other character (emoji included) is copied as it is. */
    fun percentDecode(s: String): String {
        if (!s.contains('%')) return s
        val out = StringBuilder()
        val pending = ByteArrayOutputStream()
        fun flush() { if (pending.size() > 0) { out.append(String(pending.toByteArray(), Charsets.UTF_8)); pending.reset() } }
        var i = 0
        while (i < s.length) {
            val ch = s[i]
            if (ch == '%' && i + 2 < s.length && hex(s[i + 1]) >= 0 && hex(s[i + 2]) >= 0) {
                pending.write(hex(s[i + 1]) * 16 + hex(s[i + 2])); i += 3
            } else {
                flush(); out.append(ch); i++
            }
        }
        flush()
        return out.toString()
    }

    private fun hex(c: Char): Int = when (c) { in '0'..'9' -> c - '0'; in 'a'..'f' -> c - 'a' + 10; in 'A'..'F' -> c - 'A' + 10; else -> -1 }
}
