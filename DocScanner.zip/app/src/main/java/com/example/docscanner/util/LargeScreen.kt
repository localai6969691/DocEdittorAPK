package com.example.docscanner.util

import android.app.Activity
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import com.example.docscanner.R

/**
 * Tablet / landscape layout (phiên 17, mục 4.31), ONE central rule instead of ~30 `layout-sw600dp` copies: when the window is wider than
 * [MAX_CONTENT_DP] the screen's content column is limited to that width and centred, so lists, cards and forms keep a readable line length instead of
 * stretching across a 10" tablet or a phone held sideways. targetSdk 36 already ignores `screenOrientation="portrait"` on screens >= 600 dp, so
 * tablets and foldables DO open these screens wide - this is the other half of that change.
 *
 * The column is set once per Activity from `onActivityStarted` (see `LargeScreenCallbacks` in DocScannerApp.kt; `setContentView` has run by then). The window
 * side bands take the root's own background so no white strip appears beside a coloured screen. Screens whose whole point is a big picture - the camera,
 * the crop / page views - are listed in [FULL_WIDTH_SCREENS] and keep the full window. [contentWidthDp] is pure and checked in
 * tools/verify/large_screen_check.py, which also checks that every name in the list is a real Activity (a typo would silently exclude nothing).
 */
object LargeScreen {

    /** Widest content column, in dp (a comfortable reading width; wider windows get side bands). */
    const val MAX_CONTENT_DP = 640

    /** Simple class names of screens that use the whole window: camera and every screen built around a page picture. */
    val FULL_WIDTH_SCREENS = setOf(
        "CaptureActivity", "CropActivity", "BarcodeScanActivity", "PdfMarkupActivity", "PdfRedactActivity",
        "PdfAnnotateActivity", "PdfSignActivity", "PdfDecorateActivity"
    )

    /** The column width for a window [windowWidthDp] wide, or null when the window is not wider than the limit (nothing to do). */
    fun contentWidthDp(windowWidthDp: Int): Int? = if (windowWidthDp > MAX_CONTENT_DP) MAX_CONTENT_DP else null

    fun apply(activity: Activity) {
        if (activity.javaClass.simpleName in FULL_WIDTH_SCREENS) return
        val content = activity.findViewById<View>(android.R.id.content) as? FrameLayout ?: return
        if (content.getTag(R.id.tag_large_screen) == true) return
        content.setTag(R.id.tag_large_screen, true)
        val child = content.getChildAt(0) ?: return
        val widthDp = contentWidthDp(activity.resources.configuration.screenWidthDp) ?: return
        val px = (widthDp * activity.resources.displayMetrics.density).toInt()
        child.layoutParams = FrameLayout.LayoutParams(px, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER_HORIZONTAL)
        child.background?.constantState?.newDrawable()?.let { content.background = it }
    }
}
