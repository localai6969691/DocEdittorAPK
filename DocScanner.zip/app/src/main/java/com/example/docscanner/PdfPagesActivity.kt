package com.example.docscanner

import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.util.LruCache
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.databinding.ActivityPdfPagesBinding
import com.example.docscanner.databinding.ItemPagePlanBinding
import com.example.docscanner.util.KeepAlive
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfPageBitmap
import com.example.docscanner.util.PdfPageOps
import com.example.docscanner.util.SignedPdfGuard
import com.example.docscanner.util.SmartNamer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

/**
 * "Rotate, delete, reorder pages (keeps text)" (phiên 24, TECHNICAL_DOCS.md 4.64): the pages of ONE PDF as a grid of thumbnails. Tap a page for its actions (rotate, move,
 * delete) or press and hold it and drag it to a new place. Nothing is written until "Save a copy": that runs [PdfPageOps.apply], which edits the page tree of the document
 * itself, so text, links and drawings stay exactly as they were (the older [PdfPageEditorActivity] rebuilds the file from page IMAGES). The thumbnails are rendered one at a
 * time ([renderLock]) because a PdfRenderer allows only one open page. The plan ([PdfPageOps.Entry] list) is a copy in memory; Back with unsaved changes asks first.
 */
class PdfPagesActivity : BaseActivity() {

    companion object {
        const val EXTRA_PDF_PATH = "extra_pdf_path"
        private const val THUMB_WIDTH = 360
    }

    private lateinit var binding: ActivityPdfPagesBinding
    private lateinit var source: File
    private lateinit var adapter: PlanAdapter
    private var session: PdfPageBitmap.Session? = null
    private var originalCount = 0
    private var plan: MutableList<PdfPageOps.Entry> = ArrayList()
    private var changed = false
    private var busy = false
    private val thumbs = LruCache<Int, Bitmap>(64)
    private val requested = HashSet<Int>()
    private val renderLock = Mutex()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfPagesBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.pages_title)
        val path = intent.getStringExtra(EXTRA_PDF_PATH)
        if (path == null || !File(path).isFile) { finish(); return }
        source = File(path)
        val opened = PdfPageBitmap.open(source)
        if (opened == null) {
            Toast.makeText(this, R.string.pages_open_failed, Toast.LENGTH_LONG).show()
            finish()
            return
        }
        session = opened
        originalCount = opened.pageCount
        plan = ArrayList(PdfPageOps.identity(originalCount))

        val metrics = resources.displayMetrics
        val span = (metrics.widthPixels / metrics.density / 140f).toInt().coerceIn(2, 6)
        adapter = PlanAdapter()
        binding.rvPages.layoutManager = GridLayoutManager(this, span)
        binding.rvPages.adapter = adapter
        val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
        ) {
            override fun onMove(recyclerView: RecyclerView, viewHolder: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder): Boolean {
                if (busy) return false
                val from = viewHolder.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
                plan = ArrayList(PdfPageOps.moved(plan, from, to))
                adapter.notifyItemMoved(from, to)
                changed = true
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}
        })
        touchHelper.attachToRecyclerView(binding.rvPages)

        binding.btnPagesReset.setOnClickListener {
            if (busy) return@setOnClickListener
            plan = ArrayList(PdfPageOps.identity(originalCount))
            changed = false
            refresh()
        }
        binding.btnPagesSave.setOnClickListener { if (!busy) save() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!changed || busy) { isEnabled = false; onBackPressedDispatcher.onBackPressed(); return }
                AlertDialog.Builder(this@PdfPagesActivity)
                    .setMessage(R.string.pages_discard)
                    .setNegativeButton(R.string.dialog_cancel, null)
                    .setPositiveButton(R.string.sign_discard_exit) { _, _ -> isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                    .show()
            }
        })
        refresh()
    }

    override fun onDestroy() {
        runCatching { session?.close() }
        session = null
        super.onDestroy()
    }

    private fun refresh() {
        binding.tvPagesCount.text = getString(R.string.pages_count, plan.size, originalCount)
        adapter.notifyDataSetChanged()
    }

    private fun edit(updated: List<PdfPageOps.Entry>) {
        plan = ArrayList(updated)
        changed = true
        refresh()
    }

    /** The actions for the page at [position]; only the ones that would change something are offered (the first page cannot move earlier, the last one cannot be deleted). */
    private fun askActions(position: Int) {
        if (busy || position < 0 || position >= plan.size) return
        val actions = ArrayList<Pair<String, () -> Unit>>()
        actions.add(getString(R.string.pages_rotate_right) to { edit(PdfPageOps.rotated(plan, position, 90)) })
        actions.add(getString(R.string.pages_rotate_left) to { edit(PdfPageOps.rotated(plan, position, 270)) })
        if (position > 0) actions.add(getString(R.string.pages_move_earlier) to { edit(PdfPageOps.moved(plan, position, position - 1)) })
        if (position < plan.size - 1) actions.add(getString(R.string.pages_move_later) to { edit(PdfPageOps.moved(plan, position, position + 1)) })
        if (plan.size > 1) actions.add(getString(R.string.pages_delete) to { edit(PdfPageOps.deleted(plan, position)) })
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.pages_page_n, position + 1))
            .setItems(actions.map { it.first }.toTypedArray()) { _, which -> actions[which].second() }
            .show()
    }

    private fun setBusy(value: Boolean) {
        busy = value
        binding.btnPagesSave.isEnabled = !value
        binding.btnPagesReset.isEnabled = !value
    }

    private fun save() {
        if (PdfPageOps.isUnchanged(plan, originalCount)) {
            Toast.makeText(this, R.string.reader_edit_nothing, Toast.LENGTH_SHORT).show()
            return
        }
        setBusy(true)
        val snapshot = ArrayList(plan)
        lifecycleScope.launch {
            // A signed PDF loses its signature when the pages change: ask first (SignedPdfGuard), like every other tool that writes a new file.
            if (!SignedPdfGuard.confirm(this@PdfPagesActivity, source)) {
                setBusy(false)
                return@launch
            }
            val out = SmartNamer.uniqueFile(PdfExporter.exportDir(this@PdfPagesActivity), source.nameWithoutExtension + " (" + getString(R.string.pages_suffix) + ")", "pdf")
            val written = KeepAlive.during(applicationContext) {
                withContext(Dispatchers.Default) { PdfPageOps.apply(source, out, snapshot) }
            }
            setBusy(false)
            if (written <= 0) {
                runCatching { out.delete() }
                Toast.makeText(this@PdfPagesActivity, R.string.pages_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            changed = false
            Toast.makeText(this@PdfPagesActivity, getString(R.string.pages_saved, out.name), Toast.LENGTH_LONG).show()
            finish()
        }
    }

    /** Renders the thumbnail of ORIGINAL page [sourceIndex] once, one page at a time, then redraws the grid. */
    private fun requestThumb(sourceIndex: Int) {
        if (thumbs.get(sourceIndex) != null || !requested.add(sourceIndex)) return
        lifecycleScope.launch {
            val bitmap = renderLock.withLock { withContext(Dispatchers.IO) { runCatching { session?.render(sourceIndex, THUMB_WIDTH) }.getOrNull() } }
            if (bitmap != null) {
                thumbs.put(sourceIndex, bitmap)
                adapter.notifyDataSetChanged()
            }
        }
    }

    private inner class PlanAdapter : RecyclerView.Adapter<PlanHolder>() {
        override fun getItemCount(): Int = plan.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PlanHolder =
            PlanHolder(ItemPagePlanBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun onBindViewHolder(holder: PlanHolder, position: Int) {
            val entry = plan[position]
            val thumb = thumbs.get(entry.source)
            if (thumb == null) {
                holder.item.ivPageThumb.setImageDrawable(null)
                requestThumb(entry.source)
            } else if (entry.turn == 0) {
                holder.item.ivPageThumb.setImageBitmap(thumb)
            } else {
                val matrix = Matrix()
                matrix.postRotate(entry.turn.toFloat())
                holder.item.ivPageThumb.setImageBitmap(Bitmap.createBitmap(thumb, 0, 0, thumb.width, thumb.height, matrix, true))
            }
            val number = if (entry.source == position) (position + 1).toString() else getString(R.string.pages_was, position + 1, entry.source + 1)
            holder.item.tvPageLabel.text = if (entry.turn == 0) number else number + "  \u21BB" + entry.turn + "\u00B0"
            holder.item.root.setOnClickListener {
                val current = holder.bindingAdapterPosition
                if (current != RecyclerView.NO_POSITION) askActions(current)
            }
        }
    }
}

private class PlanHolder(val item: ItemPagePlanBinding) : RecyclerView.ViewHolder(item.root)
