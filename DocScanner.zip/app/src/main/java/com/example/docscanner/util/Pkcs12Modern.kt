package com.example.docscanner.util

import java.io.ByteArrayInputStream
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * A PKCS#12 reader of last resort for files that Android's own KeyStore("PKCS12") refuses with "wrong password" although the password is right.
 *
 * Why it exists: OpenSSL 3 (and every tool built on it: Python's `cryptography`, recent `openssl pkcs12 -export`, XCA, certificate authorities' web
 * pages) writes `.p12` files with PBES2 / AES-256-CBC encryption and an HMAC-SHA-256 MAC by default, and the BouncyCastle inside many Android
 * versions cannot read them (reports on Android 9, 12 and 13; only newer releases added PBES2 support). The person sees "wrong password" and cannot
 * tell. This file reads that format with plain `javax.crypto`, which every Android version has, so the import works there too.
 *
 * What it reads (RFC 7292): the MAC (HMAC with SHA-1 / 224 / 256 / 384 / 512 over the PKCS#12 key derivation of appendix B), SafeContents that are plain
 * or EncryptedData, certificate bags, and key bags that are plain or shrouded with PBES2 (PBKDF2 with HMAC-SHA-1 / 224 / 256 / 384 / 512 and AES-128 / 192 /
 * 256-CBC) or with pbeWithSHA1And3-KeyTripleDES-CBC. Anything else (for example RC2-40, which the system reader handles) -> [Failure.UNSUPPORTED].
 * The password is turned into bytes the way the standard says: UTF-16BE with a 0x0000 terminator for the MAC and the PKCS#12 key derivation, UTF-8 for PBKDF2 - so
 * accented, Cyrillic and Chinese passwords work (tools/verify/Pkcs12ModernCheck.java mirrors this file and is tested against files made by OpenSSL and `cryptography`).
 */
object Pkcs12Modern {

    enum class Failure { WRONG_PASSWORD, UNSUPPORTED, MALFORMED }

    class ParseException(val failure: Failure) : Exception(failure.name)

    /** [privateKey] belongs to one of [certificates]; [chain] is that certificate first, then its issuers as far as they are in the file. */
    class Parsed(val privateKey: PrivateKey, val chain: List<X509Certificate>)

    // ---- object identifiers (dotted) ----
    private const val OID_DATA = "1.2.840.113549.1.7.1"
    private const val OID_ENCRYPTED_DATA = "1.2.840.113549.1.7.6"
    private const val OID_KEY_BAG = "1.2.840.113549.1.12.10.1.1"
    private const val OID_SHROUDED_KEY_BAG = "1.2.840.113549.1.12.10.1.2"
    private const val OID_CERT_BAG = "1.2.840.113549.1.12.10.1.3"
    private const val OID_PBES2 = "1.2.840.113549.1.5.13"
    private const val OID_PBKDF2 = "1.2.840.113549.1.5.12"
    private const val OID_PBE_SHA1_3DES = "1.2.840.113549.1.12.1.3"
    private const val OID_RSA = "1.2.840.113549.1.1.1"
    private const val OID_EC = "1.2.840.10045.2.1"

    private val HASHES = mapOf(                       // digest OID -> (JCA digest, JCA HMAC, block size v, output size u)
        "1.3.14.3.2.26" to Hash("SHA-1", "HmacSHA1", 64, 20),
        "2.16.840.1.101.3.4.2.4" to Hash("SHA-224", "HmacSHA224", 64, 28),
        "2.16.840.1.101.3.4.2.1" to Hash("SHA-256", "HmacSHA256", 64, 32),
        "2.16.840.1.101.3.4.2.2" to Hash("SHA-384", "HmacSHA384", 128, 48),
        "2.16.840.1.101.3.4.2.3" to Hash("SHA-512", "HmacSHA512", 128, 64)
    )
    private val PRFS = mapOf(                         // PBKDF2 PRF OID -> HMAC
        "1.2.840.113549.2.7" to "HmacSHA1", "1.2.840.113549.2.8" to "HmacSHA224", "1.2.840.113549.2.9" to "HmacSHA256",
        "1.2.840.113549.2.10" to "HmacSHA384", "1.2.840.113549.2.11" to "HmacSHA512"
    )
    private val AES_KEY_BYTES = mapOf("2.16.840.1.101.3.4.1.2" to 16, "2.16.840.1.101.3.4.1.22" to 24, "2.16.840.1.101.3.4.1.42" to 32)

    private class Hash(val digest: String, val hmac: String, val blockSize: Int, val outSize: Int)

    // ---- a minimal DER reader ----
    private class Node(val data: ByteArray, val tag: Int, val start: Int, val contentStart: Int, val end: Int) {
        val content: ByteArray get() = data.copyOfRange(contentStart, end)
        val children: List<Node> get() {
            val out = ArrayList<Node>(); var p = contentStart
            while (p < end) { val n = Pkcs12Modern.read(data, p, end); out.add(n); p = n.end }       // qualified: Node is a nested class, not an inner one
            return out
        }
    }

    private fun read(data: ByteArray, at: Int, limit: Int = data.size): Node {
        if (at + 2 > limit) throw ParseException(Failure.MALFORMED)
        var p = at
        val tag = data[p++].toInt() and 0xFF
        if ((tag and 0x1F) == 0x1F) throw ParseException(Failure.MALFORMED)          // multi-byte tags do not occur in PKCS#12
        var len = data[p++].toInt() and 0xFF
        if ((len and 0x80) != 0) {
            val n = len and 0x7F
            if (n == 0 || n > 4 || p + n > limit) throw ParseException(Failure.MALFORMED)         // indefinite lengths (BER) are not supported
            len = 0
            repeat(n) { len = (len shl 8) or (data[p++].toInt() and 0xFF) }
            if (len < 0) throw ParseException(Failure.MALFORMED)
        }
        if (p + len > limit) throw ParseException(Failure.MALFORMED)
        return Node(data, tag, at, p, p + len)
    }

    private fun oid(n: Node): String {
        if (n.tag != 0x06 || n.end <= n.contentStart) throw ParseException(Failure.MALFORMED)
        val sb = StringBuilder(); var value = 0L
        var first = true
        for (i in n.contentStart until n.end) {
            val b = n.data[i].toInt() and 0xFF
            value = (value shl 7) or (b and 0x7F).toLong()
            if ((b and 0x80) == 0) {
                if (first) { val a = if (value < 80) (value / 40).toInt() else 2; sb.append(a).append('.').append(value - 40L * a); first = false }
                else sb.append('.').append(value)
                value = 0
            }
        }
        return sb.toString()
    }

    private fun int(n: Node): Int {
        var v = 0
        for (i in n.contentStart until n.end) v = (v shl 8) or (n.data[i].toInt() and 0xFF)
        return v
    }

    // ---- password forms ----
    private fun bmp(password: CharArray): ByteArray {
        val out = ByteArray(password.size * 2 + 2)                  // UTF-16BE + two zero bytes; the terminator is part of the password for the MAC and the key derivation
        for (i in password.indices) { out[2 * i] = (password[i].code shr 8).toByte(); out[2 * i + 1] = password[i].code.toByte() }
        return out
    }

    private fun utf8(password: CharArray): ByteArray = String(password).toByteArray(Charsets.UTF_8)

    // ---- RFC 7292 appendix B key derivation ----
    private fun pkcs12Kdf(h: Hash, id: Int, password: ByteArray, salt: ByteArray, iterations: Int, length: Int): ByteArray {
        val v = h.blockSize; val u = h.outSize
        fun fill(src: ByteArray): ByteArray {
            if (src.isEmpty()) return ByteArray(0)
            val out = ByteArray(v * ((src.size + v - 1) / v))
            for (i in out.indices) out[i] = src[i % src.size]
            return out
        }
        val d = ByteArray(v) { id.toByte() }
        val inp = fill(salt) + fill(password)
        val md = MessageDigest.getInstance(h.digest)
        val out = ByteArray(length)
        var produced = 0
        while (produced < length) {
            md.update(d); md.update(inp)
            var a = md.digest()
            for (k in 1 until iterations) a = md.digest(a)
            val n = minOf(u, length - produced)
            System.arraycopy(a, 0, out, produced, n)
            produced += n
            if (produced >= length) break
            val b = ByteArray(v) { a[it % u] }
            var j = 0
            while (j < inp.size) {                                  // I_j = (I_j + B + 1) mod 2^(8v)
                var carry = 1
                for (k in v - 1 downTo 0) {
                    val sum = (inp[j + k].toInt() and 0xFF) + (b[k].toInt() and 0xFF) + carry
                    inp[j + k] = sum.toByte(); carry = sum shr 8
                }
                j += v
            }
        }
        return out
    }

    private fun pbkdf2(hmac: String, password: ByteArray, salt: ByteArray, iterations: Int, length: Int): ByteArray {
        val mac = Mac.getInstance(hmac)
        mac.init(SecretKeySpec(if (password.isEmpty()) ByteArray(1) else password, hmac))          // SecretKeySpec rejects an empty key; a zero byte is the same HMAC key
        val hLen = mac.macLength
        val out = ByteArray(length)
        for (block in 1..((length + hLen - 1) / hLen)) {
            mac.update(salt)
            mac.update(byteArrayOf((block ushr 24).toByte(), (block ushr 16).toByte(), (block ushr 8).toByte(), block.toByte()))
            var u = mac.doFinal(); val t = u.copyOf()
            for (j in 2..iterations) { u = mac.doFinal(u); for (k in t.indices) t[k] = (t[k].toInt() xor u[k].toInt()).toByte() }
            System.arraycopy(t, 0, out, (block - 1) * hLen, minOf(hLen, length - (block - 1) * hLen))
        }
        return out
    }

    /** Decrypts [encrypted] as described by [alg] (an AlgorithmIdentifier: PBES2 or the PKCS#12 3DES scheme). */
    private fun decrypt(alg: Node, encrypted: ByteArray, password: CharArray): ByteArray {
        val parts = alg.children
        val algOid = oid(parts[0])
        try {
            when (algOid) {
                OID_PBES2 -> {
                    val params = parts[1].children
                    val kdf = params[0].children
                    if (oid(kdf[0]) != OID_PBKDF2) throw ParseException(Failure.UNSUPPORTED)
                    val kp = kdf[1].children
                    val salt = kp[0].let { if (it.tag != 0x04) throw ParseException(Failure.UNSUPPORTED) else it.content }
                    val iterations = int(kp[1])
                    var keyLength: Int? = null; var prf = "HmacSHA1"
                    for (extra in kp.drop(2)) {
                        if (extra.tag == 0x02) keyLength = int(extra)
                        else if (extra.tag == 0x30) prf = PRFS[oid(extra.children[0])] ?: throw ParseException(Failure.UNSUPPORTED)
                    }
                    val scheme = params[1].children
                    val size = AES_KEY_BYTES[oid(scheme[0])] ?: throw ParseException(Failure.UNSUPPORTED)
                    if (keyLength != null && keyLength != size) throw ParseException(Failure.MALFORMED)
                    val iv = scheme[1].content
                    val key = pbkdf2(prf, utf8(password), salt, iterations, size)
                    val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
                    cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), IvParameterSpec(iv))
                    return cipher.doFinal(encrypted)
                }
                OID_PBE_SHA1_3DES -> {
                    val params = parts[1].children
                    val salt = params[0].content; val iterations = int(params[1])
                    val sha1 = HASHES.getValue("1.3.14.3.2.26")
                    val key = pkcs12Kdf(sha1, 1, bmp(password), salt, iterations, 24)
                    val iv = pkcs12Kdf(sha1, 2, bmp(password), salt, iterations, 8)
                    val cipher = Cipher.getInstance("DESede/CBC/PKCS5Padding")
                    cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "DESede"), IvParameterSpec(iv))
                    return cipher.doFinal(encrypted)
                }
                else -> throw ParseException(Failure.UNSUPPORTED)
            }
        } catch (e: ParseException) {
            throw e
        } catch (e: javax.crypto.BadPaddingException) {
            throw ParseException(Failure.WRONG_PASSWORD)                 // a wrong password almost always shows up as bad padding
        } catch (e: javax.crypto.IllegalBlockSizeException) {
            throw ParseException(Failure.MALFORMED)
        } catch (e: IndexOutOfBoundsException) {
            throw ParseException(Failure.MALFORMED)
        }
    }

    fun parse(file: ByteArray, password: CharArray): Parsed {
        try {
            return parseUnchecked(file, password)
        } catch (e: ParseException) {
            throw e
        } catch (e: Exception) {
            throw ParseException(Failure.MALFORMED)
        }
    }

    private fun parseUnchecked(file: ByteArray, password: CharArray): Parsed {
        val pfx = read(file, 0)
        if (pfx.tag != 0x30) throw ParseException(Failure.MALFORMED)
        val top = pfx.children
        val authSafeInfo = top[1].children
        if (oid(authSafeInfo[0]) != OID_DATA) throw ParseException(Failure.UNSUPPORTED)
        val authSafeOctets = authSafeInfo[1].children[0]                           // [0] EXPLICIT OCTET STRING
        val authSafe = authSafeOctets.content

        // 1. the MAC proves the password (and that the file is whole) before anything is decrypted
        val macData = top.getOrNull(2) ?: throw ParseException(Failure.UNSUPPORTED)
        val md = macData.children
        val digestInfo = md[0].children
        val hash = HASHES[oid(digestInfo[0].children[0])] ?: throw ParseException(Failure.UNSUPPORTED)
        val expected = digestInfo[1].content
        val macSalt = md[1].content
        val macIterations = if (md.size > 2) int(md[2]) else 1
        val macKey = pkcs12Kdf(hash, 3, bmp(password), macSalt, macIterations, hash.outSize)
        val mac = Mac.getInstance(hash.hmac).apply { init(SecretKeySpec(macKey, hash.hmac)) }
        if (!MessageDigest.isEqual(mac.doFinal(authSafe), expected)) throw ParseException(Failure.WRONG_PASSWORD)

        // 2. the contents: each ContentInfo is plain data or EncryptedData
        val certs = ArrayList<X509Certificate>(); var keyBytes: ByteArray? = null
        val factory = CertificateFactory.getInstance("X.509")
        for (info in read(authSafe, 0).children) {
            val kind = oid(info.children[0])
            val body = info.children[1].children[0]
            val safeContents: ByteArray = when (kind) {
                OID_DATA -> body.content
                OID_ENCRYPTED_DATA -> {
                    val eci = body.children[1].children                            // EncryptedContentInfo: type, algorithm, [0] IMPLICIT encryptedContent
                    val encrypted = eci[2].let { if (it.tag == 0xA0) it.content else if (it.tag == 0x80) it.content else throw ParseException(Failure.MALFORMED) }
                    decrypt(eci[1], encrypted, password)
                }
                else -> throw ParseException(Failure.UNSUPPORTED)
            }
            for (bag in read(safeContents, 0).children) {
                val parts = bag.children
                val value = parts[1].children[0]
                when (oid(parts[0])) {
                    OID_CERT_BAG -> certs.add(factory.generateCertificate(ByteArrayInputStream(value.children[1].children[0].content)) as X509Certificate)
                    OID_SHROUDED_KEY_BAG -> { val epki = value.children; if (keyBytes == null) keyBytes = decrypt(epki[0], epki[1].content, password) }
                    OID_KEY_BAG -> if (keyBytes == null) keyBytes = value.data.copyOfRange(value.start, value.end)       // value.data is the decrypted SafeContents, not the file
                }
            }
        }
        val pkcs8 = keyBytes ?: throw ParseException(Failure.MALFORMED)
        val keyAlgorithm = when (oid(read(pkcs8, 0).children[1].children[0])) { OID_RSA -> "RSA"; OID_EC -> "EC"; else -> throw ParseException(Failure.UNSUPPORTED) }
        val key = KeyFactory.getInstance(keyAlgorithm).generatePrivate(PKCS8EncodedKeySpec(pkcs8))
        if (certs.isEmpty()) throw ParseException(Failure.MALFORMED)
        return Parsed(key, orderChain(key, certs))
    }

    /** The certificate that belongs to [key] first (a sign + verify round trip decides), then its issuers in order. */
    private fun orderChain(key: PrivateKey, certs: List<X509Certificate>): List<X509Certificate> {
        val algorithm = if (key.algorithm.equals("EC", ignoreCase = true)) "SHA256withECDSA" else "SHA256withRSA"
        val probe = byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8)
        val signature = java.security.Signature.getInstance(algorithm).apply { initSign(key); update(probe) }.sign()
        val leaf = certs.firstOrNull { c ->
            try { java.security.Signature.getInstance(algorithm).apply { initVerify(c.publicKey); update(probe) }.verify(signature) } catch (e: Exception) { false }
        } ?: certs[0]
        val chain = arrayListOf(leaf)
        val rest = ArrayList(certs.filter { it !== leaf })
        while (true) {
            val last = chain.last()
            if (last.subjectX500Principal == last.issuerX500Principal) break                    // reached a self-signed root
            val issuer = rest.firstOrNull { it.subjectX500Principal == last.issuerX500Principal } ?: break
            chain.add(issuer); rest.remove(issuer)
        }
        return chain
    }
}
