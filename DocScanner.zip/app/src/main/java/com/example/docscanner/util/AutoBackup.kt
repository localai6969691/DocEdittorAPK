package com.example.docscanner.util

import android.app.job.JobInfo
import android.app.job.JobScheduler
import android.content.ComponentName
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import java.io.IOException

/**
 * Scheduled backup (phiên 20, mục 4.48.5; PDF "Thiếu gì để bán app" mục 6.4). The pure part (file names, which old backups to delete) is [BackupSchedule] and is checked on the JVM;
 * THIS file is the Android glue and has NOT been run on a device or an emulator: it is written against the documented framework APIs (JobScheduler, DocumentsContract) and listed as unverified.
 *
 * How it works: the user picks a FOLDER once (Storage Access Framework tree, permission kept with `takePersistableUriPermission`, so the app needs no storage permission), an interval
 * (daily / weekly / monthly) and how many backups to keep. A periodic [JobScheduler] job (only while charging, battery and storage not low, kept across reboots by RECEIVE_BOOT_COMPLETED)
 * writes `docscanner_auto_yyyyMMdd_HHmmss.zip` with [BackupManager.backup] (the same content as the manual backup: exports and projects, NOT the vault, signatures or app lock), then deletes
 * the older automatic ones beyond the number to keep. The system decides the exact time inside each period ("not more than once per period"; at least 15 minutes) - that is why the dialog says
 * "about once a week", not "at 3 a.m.". The ZIP is NOT encrypted (like the manual one): choose a folder you trust.
 */
object AutoBackup {

    const val JOB_ID = 7301
    private const val PREFS = "auto_backup"
    private const val K_TREE = "tree"
    private const val K_DAYS = "days"
    private const val K_KEEP = "keep"
    private const val K_LAST = "last_success"
    private const val K_ERROR = "last_error"

    class Settings(val tree: Uri?, val interval: BackupSchedule.Interval, val keep: Int, val lastSuccess: Long, val lastError: String?)

    fun settings(context: Context): Settings {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val days = p.getInt(K_DAYS, 0)
        val interval = BackupSchedule.Interval.values().firstOrNull { it.days == days } ?: BackupSchedule.Interval.OFF
        return Settings(
            p.getString(K_TREE, null)?.let { Uri.parse(it) }, interval,
            p.getInt(K_KEEP, 5).coerceIn(BackupSchedule.MIN_KEEP, BackupSchedule.MAX_KEEP), p.getLong(K_LAST, 0L), p.getString(K_ERROR, null)
        )
    }

    fun save(context: Context, tree: Uri?, interval: BackupSchedule.Interval, keep: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(K_TREE, tree?.toString()).putInt(K_DAYS, interval.days).putInt(K_KEEP, keep.coerceIn(BackupSchedule.MIN_KEEP, BackupSchedule.MAX_KEEP)).apply()
    }

    internal fun recordSuccess(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong(K_LAST, System.currentTimeMillis()).remove(K_ERROR).apply()
    }

    internal fun recordError(context: Context, message: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(K_ERROR, message).apply()
    }

    /**
     * Registers the periodic job to match the settings, or cancels it. A pending job that already has the right period is LEFT ALONE, so opening the app does not push the next
     * backup further away every time.
     */
    fun ensureScheduled(context: Context) {
        val js = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
        val s = settings(context)
        if (s.interval == BackupSchedule.Interval.OFF || s.tree == null) {
            js.cancel(JOB_ID)
            return
        }
        val period = BackupSchedule.periodMillis(s.interval)
        val pending = js.getPendingJob(JOB_ID)
        if (pending != null && pending.isPeriodic && pending.intervalMillis == period) return
        val b = JobInfo.Builder(JOB_ID, ComponentName(context, AutoBackupJobService::class.java))
            .setPeriodic(period)
            .setRequiresCharging(true)
            .setPersisted(true)
        if (Build.VERSION.SDK_INT >= 26) {
            b.setRequiresBatteryNotLow(true)
            b.setRequiresStorageNotLow(true)
        }
        js.schedule(b.build())
    }

    /** Writes one backup into the chosen folder and prunes the old ones. Returns the number of files in the ZIP (0 = nothing to back up, no file left behind); throws [IOException] with a readable message. */
    fun runNow(context: Context): Int {
        val s = settings(context)
        val tree = s.tree ?: throw IOException("no folder chosen")
        val resolver = context.contentResolver
        if (resolver.persistedUriPermissions.none { it.uri == tree && it.isWritePermission }) throw IOException("the app lost its permission to the folder: choose it again")
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val name = BackupSchedule.fileName(System.currentTimeMillis())
        val doc = DocumentsContract.createDocument(resolver, parent, "application/zip", name) ?: throw IOException("cannot create $name in the folder")
        val count = try {
            val out = resolver.openOutputStream(doc) ?: throw IOException("cannot open $name for writing")
            out.use { BackupManager.backup(context, it) }
        } catch (e: Exception) {
            runCatching { DocumentsContract.deleteDocument(resolver, doc) }   // never leave a half ZIP behind
            throw if (e is IOException) e else IOException(e.message ?: e.javaClass.simpleName, e)
        }
        if (count == 0) {
            runCatching { DocumentsContract.deleteDocument(resolver, doc) }
            return 0
        }
        prune(context, tree, s.keep)
        return count
    }

    /** Deletes the automatic backups beyond [keep]; [BackupSchedule.toDelete] only ever returns names this module made. */
    private fun prune(context: Context, tree: Uri, keep: Int) {
        val resolver = context.contentResolver
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val ids = HashMap<String, String>()
        resolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0) ?: continue
                val name = c.getString(1) ?: continue
                ids[name] = id
            }
        }
        for (name in BackupSchedule.toDelete(ids.keys.toList(), keep)) {
            val id = ids[name] ?: continue
            runCatching { DocumentsContract.deleteDocument(resolver, DocumentsContract.buildDocumentUriUsingTree(tree, id)) }
        }
    }
}
