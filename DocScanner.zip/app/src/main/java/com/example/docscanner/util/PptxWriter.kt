package com.example.docscanner.util

import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Writes a PowerPoint file (.pptx) with no library: one slide per page, each holding the page picture (JPEG) fitted and centred. A .pptx
 * is a ZIP of XML parts; the minimal set that PowerPoint, LibreOffice and python-pptx accept is the presentation, one slide master, one
 * blank layout, a theme, and the slides with their pictures (`tools/verify/export_check.py` opens the result with python-pptx and converts it
 * with LibreOffice). The slide size follows the first picture (longest side 12 192 000 EMU = 13.33 in, the widescreen width), so a portrait
 * scan gives portrait slides; a later page of another shape is fitted inside.
 *
 * What it does not do: the slides carry the picture only - no editable text. (The text of the page is available through the Word / HTML
 * exports.) The alt text of each picture holds [Slide.altText] for screen readers.
 */
object PptxWriter {

    class Slide(val jpeg: ByteArray, val widthPx: Int, val heightPx: Int, val altText: String)

    private const val LONGEST_SIDE_EMU = 12_192_000L
    private const val XML_HEAD = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
    private const val NS_A = "http://schemas.openxmlformats.org/drawingml/2006/main"
    private const val NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val NS_P = "http://schemas.openxmlformats.org/presentationml/2006/main"
    private const val REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

    /** Slide size in EMU for a first picture of [widthPx] x [heightPx]: the longer side is [LONGEST_SIDE_EMU]. */
    fun slideSize(widthPx: Int, heightPx: Int): Pair<Long, Long> =
        if (widthPx >= heightPx) Pair(LONGEST_SIDE_EMU, maxOf(1L, LONGEST_SIDE_EMU * heightPx / widthPx))
        else Pair(maxOf(1L, LONGEST_SIDE_EMU * widthPx / heightPx), LONGEST_SIDE_EMU)

    /** Position and size (EMU) of a picture fitted inside the slide, keeping its aspect ratio, centred: x, y, cx, cy. */
    fun fit(widthPx: Int, heightPx: Int, slideCx: Long, slideCy: Long): LongArray {
        // compare widthPx/slideCx with heightPx/slideCy without floating point
        val cx: Long
        val cy: Long
        if (widthPx * slideCy >= heightPx * slideCx) {
            cx = slideCx
            cy = maxOf(1L, slideCx * heightPx / widthPx)
        } else {
            cy = slideCy
            cx = maxOf(1L, slideCy * widthPx / heightPx)
        }
        return longArrayOf((slideCx - cx) / 2, (slideCy - cy) / 2, cx, cy)
    }

    private const val GROUP_PROPS = "<p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr>" +
        "<p:grpSpPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"0\" cy=\"0\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"0\" cy=\"0\"/></a:xfrm></p:grpSpPr>"

    fun slideXml(number: Int, slide: Slide, slideCx: Long, slideCy: Long): String {
        val f = fit(slide.widthPx, slide.heightPx, slideCx, slideCy)
        return XML_HEAD + "<p:sld xmlns:a=\"$NS_A\" xmlns:r=\"$NS_R\" xmlns:p=\"$NS_P\"><p:cSld><p:spTree>" + GROUP_PROPS +
            "<p:pic><p:nvPicPr><p:cNvPr id=\"2\" name=\"Trang $number\" descr=\"${DocxWriter.escape(slide.altText).replace("\"", "&quot;")}\"/>" +
            "<p:cNvPicPr><a:picLocks noChangeAspect=\"1\"/></p:cNvPicPr><p:nvPr/></p:nvPicPr>" +
            "<p:blipFill><a:blip r:embed=\"rId2\"/><a:stretch><a:fillRect/></a:stretch></p:blipFill>" +
            "<p:spPr><a:xfrm><a:off x=\"${f[0]}\" y=\"${f[1]}\"/><a:ext cx=\"${f[2]}\" cy=\"${f[3]}\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr></p:pic>" +
            "</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>"
    }

    private fun fills(): String = "<a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill>".repeat(3)
    private fun lines(): String = "<a:ln w=\"6350\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln>".repeat(3)

    private fun themeXml(): String = XML_HEAD + "<a:theme xmlns:a=\"$NS_A\" name=\"Office Theme\"><a:themeElements>" +
        "<a:clrScheme name=\"Office\"><a:dk1><a:sysClr val=\"windowText\" lastClr=\"000000\"/></a:dk1><a:lt1><a:sysClr val=\"window\" lastClr=\"FFFFFF\"/></a:lt1>" +
        "<a:dk2><a:srgbClr val=\"44546A\"/></a:dk2><a:lt2><a:srgbClr val=\"E7E6E6\"/></a:lt2>" +
        "<a:accent1><a:srgbClr val=\"4472C4\"/></a:accent1><a:accent2><a:srgbClr val=\"ED7D31\"/></a:accent2><a:accent3><a:srgbClr val=\"A5A5A5\"/></a:accent3>" +
        "<a:accent4><a:srgbClr val=\"FFC000\"/></a:accent4><a:accent5><a:srgbClr val=\"5B9BD5\"/></a:accent5><a:accent6><a:srgbClr val=\"70AD47\"/></a:accent6>" +
        "<a:hlink><a:srgbClr val=\"0563C1\"/></a:hlink><a:folHlink><a:srgbClr val=\"954F72\"/></a:folHlink></a:clrScheme>" +
        "<a:fontScheme name=\"Office\"><a:majorFont><a:latin typeface=\"Calibri Light\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:majorFont>" +
        "<a:minorFont><a:latin typeface=\"Calibri\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:minorFont></a:fontScheme>" +
        "<a:fmtScheme name=\"Office\"><a:fillStyleLst>" + fills() + "</a:fillStyleLst><a:lnStyleLst>" + lines() + "</a:lnStyleLst>" +
        "<a:effectStyleLst>" + "<a:effectStyle><a:effectLst/></a:effectStyle>".repeat(3) + "</a:effectStyleLst><a:bgFillStyleLst>" + fills() + "</a:bgFillStyleLst></a:fmtScheme>" +
        "</a:themeElements></a:theme>"

    private fun masterXml(): String = XML_HEAD + "<p:sldMaster xmlns:a=\"$NS_A\" xmlns:r=\"$NS_R\" xmlns:p=\"$NS_P\"><p:cSld>" +
        "<p:bg><p:bgRef idx=\"1001\"><a:schemeClr val=\"bg1\"/></p:bgRef></p:bg><p:spTree>" + GROUP_PROPS + "</p:spTree></p:cSld>" +
        "<p:clrMap bg1=\"lt1\" tx1=\"dk1\" bg2=\"lt2\" tx2=\"dk2\" accent1=\"accent1\" accent2=\"accent2\" accent3=\"accent3\" accent4=\"accent4\" accent5=\"accent5\" accent6=\"accent6\" hlink=\"hlink\" folHlink=\"folHlink\"/>" +
        "<p:sldLayoutIdLst><p:sldLayoutId id=\"2147483649\" r:id=\"rId1\"/></p:sldLayoutIdLst></p:sldMaster>"

    private fun layoutXml(): String = XML_HEAD + "<p:sldLayout xmlns:a=\"$NS_A\" xmlns:r=\"$NS_R\" xmlns:p=\"$NS_P\" type=\"blank\" preserve=\"1\">" +
        "<p:cSld name=\"Blank\"><p:spTree>" + GROUP_PROPS + "</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>"

    private fun rels(vararg items: Triple<String, String, String>): String =
        XML_HEAD + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            items.joinToString("") { "<Relationship Id=\"${it.first}\" Type=\"$REL/${it.second}\" Target=\"${it.third}\"/>" } + "</Relationships>"

    fun write(slides: List<Slide>, out: File) {
        require(slides.isNotEmpty()) { "a presentation needs at least one slide" }
        val (cx, cy) = slideSize(slides[0].widthPx, slides[0].heightPx)
        ZipOutputStream(FileOutputStream(out)).use { zip ->
            fun part(name: String, content: String) = writePart(zip, name, content.toByteArray(Charsets.UTF_8))
            val slideOverrides = slides.indices.joinToString("") {
                "<Override PartName=\"/ppt/slides/slide${it + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/>"
            }
            part("[Content_Types].xml", XML_HEAD + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/><Default Extension=\"jpeg\" ContentType=\"image/jpeg\"/>" +
                "<Override PartName=\"/ppt/presentation.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml\"/>" +
                "<Override PartName=\"/ppt/slideMasters/slideMaster1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml\"/>" +
                "<Override PartName=\"/ppt/slideLayouts/slideLayout1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml\"/>" +
                "<Override PartName=\"/ppt/theme/theme1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.theme+xml\"/>" +
                slideOverrides + "</Types>")
            part("_rels/.rels", rels(Triple("rId1", "officeDocument", "ppt/presentation.xml")))
            val slideIds = slides.indices.joinToString("") { "<p:sldId id=\"${256 + it}\" r:id=\"rId${it + 2}\"/>" }
            part("ppt/presentation.xml", XML_HEAD + "<p:presentation xmlns:a=\"$NS_A\" xmlns:r=\"$NS_R\" xmlns:p=\"$NS_P\">" +
                "<p:sldMasterIdLst><p:sldMasterId id=\"2147483648\" r:id=\"rId1\"/></p:sldMasterIdLst><p:sldIdLst>$slideIds</p:sldIdLst>" +
                "<p:sldSz cx=\"$cx\" cy=\"$cy\"/><p:notesSz cx=\"6858000\" cy=\"9144000\"/></p:presentation>")
            val presRels = ArrayList<Triple<String, String, String>>()
            presRels.add(Triple("rId1", "slideMaster", "slideMasters/slideMaster1.xml"))
            for (i in slides.indices) presRels.add(Triple("rId${i + 2}", "slide", "slides/slide${i + 1}.xml"))
            presRels.add(Triple("rId${slides.size + 2}", "theme", "theme/theme1.xml"))
            part("ppt/_rels/presentation.xml.rels", rels(*presRels.toTypedArray()))
            part("ppt/slideMasters/slideMaster1.xml", masterXml())
            part("ppt/slideMasters/_rels/slideMaster1.xml.rels", rels(Triple("rId1", "slideLayout", "../slideLayouts/slideLayout1.xml"), Triple("rId2", "theme", "../theme/theme1.xml")))
            part("ppt/slideLayouts/slideLayout1.xml", layoutXml())
            part("ppt/slideLayouts/_rels/slideLayout1.xml.rels", rels(Triple("rId1", "slideMaster", "../slideMasters/slideMaster1.xml")))
            part("ppt/theme/theme1.xml", themeXml())
            for ((i, s) in slides.withIndex()) {
                part("ppt/slides/slide${i + 1}.xml", slideXml(i + 1, s, cx, cy))
                part("ppt/slides/_rels/slide${i + 1}.xml.rels", rels(Triple("rId1", "slideLayout", "../slideLayouts/slideLayout1.xml"), Triple("rId2", "image", "../media/image${i + 1}.jpeg")))
                writePart(zip, "ppt/media/image${i + 1}.jpeg", s.jpeg)
            }
        }
    }

    private fun writePart(zip: ZipOutputStream, name: String, bytes: ByteArray) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(bytes)
        zip.closeEntry()
    }
}
