package com.example.docscanner.util

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.tasks.await

/**
 * Offline translation with ML Kit: the language of the text is identified on the device, the translation model of each language involved
 * is downloaded once (about 30 MB each, the first time), then everything runs without a network. Quality is that of Google's small
 * on-device models - fine for understanding a document, not for publishing; two languages that are not English are translated through
 * English, which loses more. Text is cut by [TextChunker] and translated piece by piece.
 */
object TextTranslator {

    /** (language tag shown to the user, code ML Kit's translator uses, label) of the target languages offered. */
    val targets: List<Pair<String, String>> = listOf(
        TranslateLanguage.VIETNAMESE to "Tiếng Việt",
        TranslateLanguage.ENGLISH to "English",
        TranslateLanguage.CHINESE to "中文",
        TranslateLanguage.JAPANESE to "日本語",
        TranslateLanguage.KOREAN to "한국어",
        TranslateLanguage.FRENCH to "Français"
    )

    /** The language of [text] as a translator code (e.g. "vi"), or null when it is not recognised or not translatable. */
    suspend fun identify(text: String): String? {
        val sample = text.trim().take(1500)
        if (sample.isEmpty()) return null
        val tag = LanguageIdentification.getClient().identifyLanguage(sample).await()
        if (tag == "und") return null
        return TranslateLanguage.fromLanguageTag(tag)
    }

    /**
     * Translates [text] from [source] to [target] (translator codes). Downloads the models when missing (network needed that time).
     * [onProgress] gets (piece, total). Throws when a model cannot be downloaded.
     */
    suspend fun translate(text: String, source: String, target: String, onProgress: (Int, Int) -> Unit): String {
        val options = TranslatorOptions.Builder().setSourceLanguage(source).setTargetLanguage(target).build()
        val translator = Translation.getClient(options)
        try {
            translator.downloadModelIfNeeded(DownloadConditions.Builder().build()).await()
            val pieces = TextChunker.split(text, 1000)
            val out = StringBuilder()
            for ((i, piece) in pieces.withIndex()) {
                onProgress(i + 1, pieces.size)
                if (out.isNotEmpty()) out.append("\n")
                out.append(translator.translate(piece).await())
            }
            return out.toString()
        } finally {
            translator.close()
        }
    }
}
