package com.example.docscanner.util

import com.example.docscanner.R
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Compares two PDFs by LOOKING at them and boxes in red, on the new version, what changed. A report PDF with the changed,
 * added and removed pages is written next to the exports. Comparing pictures (not text or objects) is what "what changed
 * between these two versions" means to a person, and it works for scans, typed PDFs, stamps and signatures alike.
 *
 * What it takes care of (each was a "limitation" first and was then solved - the measurements are in
 * tools/verify/compare_check.py):
 *  - PAGES INSERTED OR DELETED: pages of the two files are matched first, by a signature of each page (ink density on a
 *    96x128 grid, blurred, with the average page of both documents subtracted so that the shared margins and line spacing
 *    do not make every text page look alike) and a longest-common-subsequence style alignment ([alignPages]). Matched pages
 *    are compared; unmatched new pages are reported as added, unmatched old pages as removed - one inserted page no longer
 *    turns every later page into a "difference".
 *  - A PAGE SHIFTED, ROTATED OR SCALED (a re-scan, another printer): the new page is registered to the old one before
 *    comparing - a whole-page shift first (sum of absolute differences of ink, quarter resolution, +-20 px), then an AFFINE
 *    transform found by a coarse-to-fine pyramid ([estimateAffinePyramid]), then a +-1 px residual per 128-pixel tile
 *    ([refineTiles], [alignB]). Measured on text pages: shifts up to +-20 px, rotation up to 3 degrees and scaling up to 3%
 *    (alone or combined) leave no box at all, where an unregistered comparison boxes more than half of the page.
 *  - Remaining noise: both pages are blurred slightly and a pixel counts as different only when it lies outside the
 *    min-max range of the other page's 3x3 neighbourhood by more than [THRESHOLD] ([toleranceMask]).
 *
 * Still not handled: a rotation beyond about 3 degrees or scaling beyond about 3-5% (the registration then fails to converge
 * and the page is boxed over a good part of its area); pages whose proportions differ by more than 2% are reported as "size
 * changed" with one box over the whole page; a password-protected PDF cannot be rendered.
 *
 * The algorithm is a literal Kotlin twin of tools/verify/CompareCheck.java, which runs on a JVM and is checked against the
 * numpy model (compare_java_check.py); keep the three in step.
 */
object PdfComparer {

    const val RENDER_WIDTH = 800
    private const val THRESHOLD = 32.0
    private const val BLOCK = 16
    private const val MIN_PIXELS = 8
    private const val TILE = 64
    private const val GLOBAL_RANGE = 5
    private const val AFFINE_MIN_TILES = 6
    private const val AFFINE_MAX_LINEAR = 0.08
    private val PYRAMID = intArrayOf(8, 4, 2)
    private const val LEVEL_RANGE = 2
    private val PYR_OUTLIER_PX = doubleArrayOf(8.0, 4.0, 2.5)
    private const val SHIFT_PENALTY = 0.05
    private const val FLAT_SPREAD = 40.0
    private const val BLUR_SIGMA = 1.0
    private const val SIG_W = 96
    private const val SIG_H = 128
    private const val SIG_SIGMA = 1.5
    private const val MATCH_MIN = 0.5
    private const val SIZE_TOLERANCE = 0.02f

    class Result(
        val pagesOld: Int,
        val pagesNew: Int,
        /** Number of pages that were matched between the two files. */
        val matched: Int,
        /** Pages (numbers in the NEW file) that were matched and differ. */
        val changed: List<Int>,
        /** Pages (numbers in the NEW file) with no counterpart in the old file. */
        val added: List<Int>,
        /** Pages (numbers in the OLD file) with no counterpart in the new file. */
        val removed: List<Int>,
        val reportWritten: Boolean
    ) {
        val identical: Boolean get() = changed.isEmpty() && added.isEmpty() && removed.isEmpty()
    }

    private class Plane(val w: Int, val h: Int, val d: DoubleArray)

    // ---------------------------------------------------------------- registration

    private fun ink(lum: DoubleArray): DoubleArray = DoubleArray(lum.size) { 255.0 - lum[it] }

    private fun boxDown(src: DoubleArray, w: Int, h: Int, f: Int): Plane {
        val nw = w / f
        val nh = h / f
        val out = DoubleArray(nw * nh)
        for (y in 0 until nh) for (x in 0 until nw) {
            var s = 0.0
            for (j in 0 until f) for (i in 0 until f) s += src[(y * f + j) * w + x * f + i]
            out[y * nw + x] = s / (f * f)
        }
        return Plane(nw, nh, out)
    }

    /** Mean |a[y,x] - b[y+v,x+u]| over the overlap; a huge value when they do not overlap. */
    private fun sad(a: Plane, b: Plane, u: Int, v: Int): Double {
        val w = a.w
        val h = a.h
        val x0 = max(0, -u)
        val x1 = min(w, w - u)
        val y0 = max(0, -v)
        val y1 = min(h, h - v)
        if (x1 <= x0 || y1 <= y0) return 1e9
        var s = 0.0
        for (y in y0 until y1) for (x in x0 until x1) s += abs(a.d[y * w + x] - b.d[(y + v) * w + x + u])
        return s / ((x1 - x0).toDouble() * (y1 - y0))
    }

    /** Whole-page shift `[dx, dy]` in real pixels (multiple of 4): b[y+dy, x+dx] ~ a[y, x]. */
    private fun estimateGlobal(a: DoubleArray, b: DoubleArray, w: Int, h: Int): IntArray {
        val a4 = boxDown(ink(a), w, h, 4)
        val b4 = boxDown(ink(b), w, h, 4)
        var best = 0.0
        var bu = 0
        var bv = 0
        var have = false
        for (v in -GLOBAL_RANGE..GLOBAL_RANGE) for (u in -GLOBAL_RANGE..GLOBAL_RANGE) {
            val c = sad(a4, b4, u, v) + SHIFT_PENALTY * (abs(u) + abs(v))
            if (!have || c < best) { best = c; bu = u; bv = v; have = true }
        }
        return intArrayOf(bu * 4, bv * 4)
    }

    /** `pq = [p0, p1, p2, q0, q1, q2]`: the shift of a pixel (x, y) is (p0 + p1 x + p2 y, q0 + q1 x + q2 y). Bilinear; outside is white. */
    private fun warpAffine(b: DoubleArray, w: Int, h: Int, pq: DoubleArray): DoubleArray {
        val out = DoubleArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val sx = x + pq[0] + pq[1] * x + pq[2] * y
            val sy = y + pq[3] + pq[4] * x + pq[5] * y
            val x0 = Math.floor(sx).toInt()
            val y0 = Math.floor(sy).toInt()
            val fx = sx - x0
            val fy = sy - y0
            out[y * w + x] = at(b, w, h, y0, x0) * (1 - fx) * (1 - fy) + at(b, w, h, y0, x0 + 1) * fx * (1 - fy) +
                at(b, w, h, y0 + 1, x0) * (1 - fx) * fy + at(b, w, h, y0 + 1, x0 + 1) * fx * fy
        }
        return out
    }

    private fun at(b: DoubleArray, w: Int, h: Int, y: Int, x: Int): Double =
        if (y in 0 until h && x in 0 until w) b[y * w + x] else 255.0

    /** Least squares for `v = c0 + c1*cx + c2*cy` over the kept points (`pts[i] = [cx, cy, dx, dy]`, [col] 2 or 3); null if degenerate. */
    private fun leastSquares(pts: List<DoubleArray>, keep: BooleanArray, col: Int): DoubleArray? {
        val m = Array(3) { DoubleArray(4) }
        for (i in pts.indices) {
            if (!keep[i]) continue
            val p = pts[i]
            val row = doubleArrayOf(1.0, p[0], p[1])
            for (r in 0 until 3) {
                for (c in 0 until 3) m[r][c] += row[r] * row[c]
                m[r][3] += row[r] * p[col]
            }
        }
        for (c in 0 until 3) {
            var piv = c
            for (r in c + 1 until 3) if (abs(m[r][c]) > abs(m[piv][c])) piv = r
            if (abs(m[piv][c]) < 1e-9) return null
            val tmp = m[c]; m[c] = m[piv]; m[piv] = tmp
            for (r in 0 until 3) {
                if (r == c) continue
                val f = m[r][c] / m[c][c]
                for (k in c until 4) m[r][k] -= f * m[c][k]
            }
        }
        return doubleArrayOf(m[0][3] / m[0][0], m[1][3] / m[1][1], m[2][3] / m[2][2])
    }

    /**
     * Affine registration of [b] onto [a] by a coarse-to-fine pyramid (1/8, 1/4, 1/2 resolution). At the coarsest level the shifts
     * are 8 times smaller, so a +-2 pixel search there covers +-16 real pixels; each level warps b by the affine found so far,
     * finds the small RESIDUAL shift of each 128-pixel tile, and refits the affine (least squares, with outlier rejection) to the
     * total shifts. Measured: rotation up to 3 degrees and scaling up to 3% leave no box at all (tools/verify/compare_check.py).
     * Returns `[p0, p1, p2, q0, q1, q2]`; starts from the whole-page shift [g] and keeps the previous level's result when a fit fails.
     */
    private fun estimateAffinePyramid(a: DoubleArray, b: DoubleArray, w: Int, h: Int, g: IntArray): DoubleArray {
        val nty = (h / 2 + TILE - 1) / TILE
        val ntx = (w / 2 + TILE - 1) / TILE
        var pq = doubleArrayOf(g[0].toDouble(), 0.0, 0.0, g[1].toDouble(), 0.0, 0.0)
        val inkA = ink(a)
        for (f in PYRAMID) {
            val bw = ink(warpAffine(b, w, h, pq))
            val aPlane = boxDown(inkA, w, h, f)
            val bPlane = boxDown(bw, w, h, f)
            val tile = 128 / f
            val pts = ArrayList<DoubleArray>()
            for (ty in 0 until nty) for (tx in 0 until ntx) {
                val y0 = ty * tile
                val y1 = min((ty + 1) * tile, aPlane.h)
                val x0 = tx * tile
                val x1 = min((tx + 1) * tile, aPlane.w)
                if (y1 <= y0 || x1 <= x0) continue
                var mx = -1e18
                var mn = 1e18
                for (y in y0 until y1) for (x in x0 until x1) {
                    val v = aPlane.d[y * aPlane.w + x]
                    if (v > mx) mx = v
                    if (v < mn) mn = v
                }
                if (mx - mn < FLAT_SPREAD) continue
                var best = 0.0
                var bu = 0
                var bv = 0
                var have = false
                for (dv in -LEVEL_RANGE..LEVEL_RANGE) for (du in -LEVEL_RANGE..LEVEL_RANGE) {
                    var s = 0.0
                    for (y in y0 until y1) {
                        val sy = y + dv
                        for (x in x0 until x1) {
                            val sx = x + du
                            val bv2 = if (sy in 0 until bPlane.h && sx in 0 until bPlane.w) bPlane.d[sy * bPlane.w + sx] else 0.0
                            s += abs(aPlane.d[y * aPlane.w + x] - bv2)
                        }
                    }
                    val c = s / ((y1 - y0).toDouble() * (x1 - x0)) + SHIFT_PENALTY * (abs(du) + abs(dv))
                    if (!have || c < best) { best = c; bu = du; bv = dv; have = true }
                }
                val cx = tx * 128 + 64.0
                val cy = ty * 128 + 64.0
                val px = pq[0] + pq[1] * cx + pq[2] * cy
                val py = pq[3] + pq[4] * cx + pq[5] * cy
                pts.add(doubleArrayOf(cx, cy, px + bu * f, py + bv * f))
            }
            if (pts.size < AFFINE_MIN_TILES) continue
            val keep = BooleanArray(pts.size) { true }
            var fit: DoubleArray? = null
            for (thr in PYR_OUTLIER_PX) {
                if (keep.count { it } < AFFINE_MIN_TILES) break
                val p = leastSquares(pts, keep, 2)
                val q = leastSquares(pts, keep, 3)
                if (p == null || q == null) break
                for (i in pts.indices) {
                    val pt = pts[i]
                    val rx = abs(p[0] + p[1] * pt[0] + p[2] * pt[1] - pt[2])
                    val ry = abs(q[0] + q[1] * pt[0] + q[2] * pt[1] - pt[3])
                    keep[i] = max(rx, ry) <= thr
                }
                fit = doubleArrayOf(p[0], p[1], p[2], q[0], q[1], q[2])
            }
            val candidate = fit
            if (candidate != null && keep.count { it } >= AFFINE_MIN_TILES &&
                max(max(abs(candidate[1]), abs(candidate[2])), max(abs(candidate[4]), abs(candidate[5]))) <= AFFINE_MAX_LINEAR
            ) {
                pq = candidate
            }
        }
        return pq
    }

    /** +-1 px refinement of each tile's shift at full resolution (in place). */
    private fun refineTiles(a: DoubleArray, b: DoubleArray, w: Int, h: Int, shifts: IntArray, nty: Int, ntx: Int) {
        val ts = TILE * 2
        val order = intArrayOf(0, -1, 1)
        for (ty in 0 until nty) for (tx in 0 until ntx) {
            val y0 = ty * ts
            val y1 = min((ty + 1) * ts, h)
            val x0 = tx * ts
            val x1 = min((tx + 1) * ts, w)
            if (y0 >= h || x0 >= w) continue
            var mx = -1e18
            var mn = 1e18
            for (y in y0 until y1) for (x in x0 until x1) {
                val v = 255.0 - a[y * w + x]
                if (v > mx) mx = v
                if (v < mn) mn = v
            }
            if (mx - mn < FLAT_SPREAD) continue
            val dx = shifts[2 * (ty * ntx + tx)]
            val dy = shifts[2 * (ty * ntx + tx) + 1]
            var best = 0.0
            var bx = dx
            var by = dy
            var have = false
            for (j in order) for (i in order) {
                val u = dx + i
                val v = dy + j
                var s = 0.0
                for (y in y0 until y1) {
                    val sy = y + v
                    for (x in x0 until x1) {
                        val sx = x + u
                        val bv = if (sy in 0 until h && sx in 0 until w) 255.0 - b[sy * w + sx] else 0.0
                        s += abs((255.0 - a[y * w + x]) - bv)
                    }
                }
                val c = s / ((y1 - y0).toDouble() * (x1 - x0))
                if (!have || c < best - 1e-9) { best = c; bx = u; by = v; have = true }
            }
            shifts[2 * (ty * ntx + tx)] = bx
            shifts[2 * (ty * ntx + tx) + 1] = by
        }
    }

    /** b resampled so that it lines up with a: each tile reads b at its own shift; outside the picture it is white. */
    private fun alignB(b: DoubleArray, w: Int, h: Int, shifts: IntArray, nty: Int, ntx: Int): DoubleArray {
        val out = DoubleArray(w * h) { 255.0 }
        val ts = TILE * 2
        for (ty in 0 until nty) for (tx in 0 until ntx) {
            val y0 = ty * ts
            val y1 = min((ty + 1) * ts, h)
            val x0 = tx * ts
            val x1 = min((tx + 1) * ts, w)
            if (y0 >= h || x0 >= w) continue
            val dx = shifts[2 * (ty * ntx + tx)]
            val dy = shifts[2 * (ty * ntx + tx) + 1]
            for (y in y0 until y1) {
                val sy = y + dy
                if (sy < 0 || sy >= h) continue
                for (x in x0 until x1) {
                    val sx = x + dx
                    if (sx in 0 until w) out[y * w + x] = b[sy * w + sx]
                }
            }
        }
        return out
    }

    // ---------------------------------------------------------------- comparing

    private fun gaussianBlur(src: DoubleArray, w: Int, h: Int, sigma: Double): DoubleArray {
        val r = max(1, ceil(3 * sigma).toInt())
        val k = DoubleArray(2 * r + 1)
        var sum = 0.0
        for (i in -r..r) { k[i + r] = exp(-0.5 * (i / sigma) * (i / sigma)); sum += k[i + r] }
        for (i in k.indices) k[i] /= sum
        val tmp = DoubleArray(w * h)
        val out = DoubleArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0.0
            for (i in -r..r) s += k[i + r] * src[y * w + min(max(x + i, 0), w - 1)]
            tmp[y * w + x] = s
        }
        for (y in 0 until h) for (x in 0 until w) {
            var s = 0.0
            for (i in -r..r) s += k[i + r] * tmp[min(max(y + i, 0), h - 1) * w + x]
            out[y * w + x] = s
        }
        return out
    }

    /** 3x3 window minimum and maximum of every pixel (edge pixels repeated). */
    private fun windowMinMax(src: DoubleArray, w: Int, h: Int, lo: DoubleArray, hi: DoubleArray) {
        val rl = DoubleArray(w * h)
        val rh = DoubleArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var mn = Double.MAX_VALUE
            var mx = -Double.MAX_VALUE
            for (i in -1..1) {
                val v = src[y * w + min(max(x + i, 0), w - 1)]
                if (v < mn) mn = v
                if (v > mx) mx = v
            }
            rl[y * w + x] = mn
            rh[y * w + x] = mx
        }
        for (y in 0 until h) for (x in 0 until w) {
            var mn = Double.MAX_VALUE
            var mx = -Double.MAX_VALUE
            for (i in -1..1) {
                val yy = min(max(y + i, 0), h - 1)
                val l = rl[yy * w + x]
                val hh = rh[yy * w + x]
                if (l < mn) mn = l
                if (hh > mx) mx = hh
            }
            lo[y * w + x] = mn
            hi[y * w + x] = mx
        }
    }

    /** A pixel differs when it is outside the other page's 3x3 min-max range by more than [THRESHOLD] (either way round). */
    private fun toleranceMask(a: DoubleArray, b: DoubleArray, w: Int, h: Int): BooleanArray {
        val n = w * h
        val aLo = DoubleArray(n); val aHi = DoubleArray(n); val bLo = DoubleArray(n); val bHi = DoubleArray(n)
        windowMinMax(a, w, h, aLo, aHi)
        windowMinMax(b, w, h, bLo, bHi)
        return BooleanArray(n) { i ->
            val da = max(max(bLo[i] - a[i], a[i] - bHi[i]), 0.0)
            val db = max(max(aLo[i] - b[i], b[i] - aHi[i]), 0.0)
            max(da, db) > THRESHOLD
        }
    }

    /** Boxes `[x, y, width, height]` around the regions of [mask]: see the class comment for the block rules. */
    private fun boxesFromMask(mask: BooleanArray, w: Int, h: Int): List<IntArray> {
        val bw = (w + BLOCK - 1) / BLOCK
        val bh = (h + BLOCK - 1) / BLOCK
        val counts = IntArray(bw * bh)
        for (y in 0 until h) for (x in 0 until w) if (mask[y * w + x]) counts[(y / BLOCK) * bw + x / BLOCK]++
        val changed = BooleanArray(bw * bh) { counts[it] >= MIN_PIXELS }
        val grouped = BooleanArray(bw * bh)
        for (by in 0 until bh) for (bx in 0 until bw) {
            if (!changed[by * bw + bx]) continue
            for (dy in -1..1) for (dx in -1..1) {
                val nx = bx + dx
                val ny = by + dy
                if (nx in 0 until bw && ny in 0 until bh) grouped[ny * bw + nx] = true
            }
        }
        val seen = BooleanArray(bw * bh)
        val boxes = ArrayList<IntArray>()
        for (start in 0 until bw * bh) {
            if (!grouped[start] || seen[start]) continue
            var minX = Int.MAX_VALUE; var minY = Int.MAX_VALUE; var maxX = -1; var maxY = -1
            val stack = ArrayDeque<Int>()
            stack.addLast(start)
            seen[start] = true
            while (stack.isNotEmpty()) {
                val cur = stack.removeLast()
                val cx = cur % bw
                val cy = cur / bw
                if (changed[cur]) {
                    if (cx < minX) minX = cx
                    if (cx > maxX) maxX = cx
                    if (cy < minY) minY = cy
                    if (cy > maxY) maxY = cy
                }
                for (dy in -1..1) for (dx in -1..1) {
                    val nx = cx + dx
                    val ny = cy + dy
                    if (nx !in 0 until bw || ny !in 0 until bh) continue
                    val idx = ny * bw + nx
                    if (grouped[idx] && !seen[idx]) { seen[idx] = true; stack.addLast(idx) }
                }
            }
            if (maxX < 0) continue
            val x0 = minX * BLOCK
            val y0 = minY * BLOCK
            val x1 = min((maxX + 1) * BLOCK, w)
            val y1 = min((maxY + 1) * BLOCK, h)
            boxes.add(intArrayOf(x0, y0, x1 - x0, y1 - y0))
        }
        return boxes
    }

    /** Boxes where [a] (old) and [b] (new) differ; both are [w] x [h] luminance pictures. */
    fun comparePages(a: DoubleArray, b: DoubleArray, w: Int, h: Int): List<IntArray> {
        val g = estimateGlobal(a, b, w, h)
        val nty = (h / 2 + TILE - 1) / TILE
        val ntx = (w / 2 + TILE - 1) / TILE
        val pq = estimateAffinePyramid(a, b, w, h, g)
        val warped = warpAffine(b, w, h, pq)
        val shifts = IntArray(nty * ntx * 2)             // residual per tile, starting from zero
        refineTiles(a, warped, w, h, shifts, nty, ntx)
        val aligned = alignB(warped, w, h, shifts, nty, ntx)
        return boxesFromMask(toleranceMask(gaussianBlur(a, w, h, BLUR_SIGMA), gaussianBlur(aligned, w, h, BLUR_SIGMA), w, h), w, h)
    }

    // ---------------------------------------------------------------- matching pages

    /** Blurred ink-density grid of a page, as a vector. */
    private fun rawSignature(lum: DoubleArray, w: Int, h: Int): DoubleArray {
        val g = DoubleArray(SIG_W * SIG_H)
        for (i in 0 until SIG_H) {
            val y0 = (i.toLong() * h / SIG_H).toInt()
            val y1 = max((((i + 1).toLong() * h / SIG_H).toInt()), y0 + 1)
            for (j in 0 until SIG_W) {
                val x0 = (j.toLong() * w / SIG_W).toInt()
                val x1 = max((((j + 1).toLong() * w / SIG_W).toInt()), x0 + 1)
                var s = 0.0
                var n = 0
                var y = y0
                while (y < y1 && y < h) {
                    var x = x0
                    while (x < x1 && x < w) { s += 255.0 - lum[y * w + x]; n++; x++ }
                    y++
                }
                g[i * SIG_W + j] = if (n > 0) s / n else 0.0
            }
        }
        return gaussianBlur(g, SIG_W, SIG_H, SIG_SIGMA)
    }

    /** Subtracts the average page of ALL given pages, then each vector's own mean, and scales to length 1. */
    private fun normalizedSignatures(raws: List<DoubleArray>): List<DoubleArray> {
        val n = raws[0].size
        val mean = DoubleArray(n)
        for (r in raws) for (i in 0 until n) mean[i] += r[i]
        for (i in 0 until n) mean[i] /= raws.size
        return raws.map { r ->
            val x = DoubleArray(n)
            var m = 0.0
            for (i in 0 until n) { x[i] = r[i] - mean[i]; m += x[i] }
            m /= n
            var norm = 0.0
            for (i in 0 until n) { x[i] -= m; norm += x[i] * x[i] }
            norm = sqrt(norm)
            if (norm > 1e-9) for (i in 0 until n) x[i] /= norm
            x
        }
    }

    private fun dot(a: DoubleArray, b: DoubleArray): Double {
        var s = 0.0
        for (i in a.indices) s += a[i] * b[i]
        return s
    }

    /** Pairs `[oldIndex, newIndex]` (0-based) matched by dynamic programming over page similarity (>= [MATCH_MIN]). */
    private fun alignPages(sOld: List<DoubleArray>, sNew: List<DoubleArray>): List<IntArray> {
        val n = sOld.size
        val m = sNew.size
        val sim = Array(n) { i -> DoubleArray(m) { j -> dot(sOld[i], sNew[j]) } }
        val dp = Array(n + 1) { DoubleArray(m + 1) }
        for (i in 1..n) for (j in 1..m) {
            var best = max(dp[i - 1][j], dp[i][j - 1])
            val s = sim[i - 1][j - 1]
            if (s >= MATCH_MIN) best = max(best, dp[i - 1][j - 1] + s)
            dp[i][j] = best
        }
        val pairs = ArrayList<IntArray>()
        var i = n
        var j = m
        while (i > 0 && j > 0) {
            val s = sim[i - 1][j - 1]
            if (s >= MATCH_MIN && abs(dp[i][j] - (dp[i - 1][j - 1] + s)) < 1e-9) {
                pairs.add(intArrayOf(i - 1, j - 1)); i--; j--
            } else if (abs(dp[i][j] - dp[i - 1][j]) < 1e-9) {
                i--
            } else {
                j--
            }
        }
        pairs.reverse()
        return pairs
    }

    // ---------------------------------------------------------------- the whole comparison

    private fun luminance(bmp: Bitmap, rows: Int): DoubleArray {
        val w = bmp.width
        val px = IntArray(w * rows)
        bmp.getPixels(px, 0, w, 0, 0, w, rows)
        return DoubleArray(px.size) { i ->
            val c = px[i]
            ((299 * Color.red(c) + 587 * Color.green(c) + 114 * Color.blue(c)) / 1000).toDouble()
        }
    }

    private fun banner(canvas: Canvas, width: Int, color: Int, text: String) {
        val bg = Paint().apply { this.color = color }
        canvas.drawRect(0f, 0f, width.toFloat(), 44f, bg)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = Color.WHITE; textSize = 28f; isFakeBoldText = true }
        canvas.drawText(text, 12f, 32f, tp)
    }

    /**
     * Compares [oldFile] with [newFile] and writes [report] when anything differs. [onProgress] gets (done, total) over both
     * passes (signatures, then matched pairs). Blocking - call from a background thread. Throws
     * IllegalStateException("unreadable") when either file cannot be rendered.
     */
    fun compare(oldFile: File, newFile: File, report: File, onProgress: (Int, Int) -> Unit): Result {
        val oldSession = PdfPageBitmap.open(oldFile) ?: throw IllegalStateException("unreadable")
        val newSession = PdfPageBitmap.open(newFile)
        if (newSession == null) {
            oldSession.close()
            throw IllegalStateException("unreadable")
        }
        val out = PdfDocument()
        try {
            val nOld = oldSession.pageCount
            val nNew = newSession.pageCount
            var done = 0
            val total = nOld + nNew + minOf(nOld, nNew)

            // pass 1: a signature per page (the bitmaps are dropped at once: a long document must not sit in memory)
            val raws = ArrayList<DoubleArray>()
            for (session in listOf(oldSession, newSession)) {
                for (i in 0 until session.pageCount) {
                    val bmp = session.render(i, RENDER_WIDTH) ?: throw IllegalStateException("unreadable")
                    raws.add(rawSignature(luminance(bmp, bmp.height), bmp.width, bmp.height))
                    bmp.recycle()
                    onProgress(++done, total)
                }
            }
            val sigs = normalizedSignatures(raws)
            val pairs = alignPages(sigs.subList(0, nOld), sigs.subList(nOld, nOld + nNew))
            val matchedOld = pairs.map { it[0] }.toSet()
            val matchedNew = pairs.map { it[1] }.toSet()
            val added = (0 until nNew).filter { it !in matchedNew }
            val removed = (0 until nOld).filter { it !in matchedOld }

            val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.RED; style = Paint.Style.STROKE; strokeWidth = 3f }
            val fillPaint = Paint().apply { color = Color.argb(40, 255, 0, 0) }
            var reportPages = 0
            val changed = ArrayList<Int>()

            // pass 2: compare the matched pairs
            for (pair in pairs) {
                onProgress(++done, total)
                val pa = oldSession.render(pair[0], RENDER_WIDTH) ?: continue
                val pb = newSession.render(pair[1], RENDER_WIDTH)
                if (pb == null) { pa.recycle(); continue }
                try {
                    val sameShape = abs(pa.height - pb.height) <= SIZE_TOLERANCE * pb.height
                    val boxes: List<IntArray> = if (!sameShape) {
                        listOf(intArrayOf(0, 0, pb.width, pb.height))
                    } else {
                        val h = min(pa.height, pb.height)
                        comparePages(luminance(pa, h), luminance(pb, h), pb.width, h)
                    }
                    if (boxes.isNotEmpty()) {
                        changed.add(pair[1] + 1)
                        val page = out.startPage(PdfDocument.PageInfo.Builder(pb.width, pb.height, ++reportPages).create())
                        page.canvas.drawBitmap(pb, 0f, 0f, null)
                        for (b in boxes) {
                            val r = floatArrayOf(b[0].toFloat(), b[1].toFloat(), (b[0] + b[2]).toFloat(), (b[1] + b[3]).toFloat())
                            page.canvas.drawRect(r[0], r[1], r[2], r[3], fillPaint)
                            page.canvas.drawRect(r[0], r[1], r[2], r[3], boxPaint)
                        }
                        out.finishPage(page)
                    }
                } finally {
                    pa.recycle()
                    pb.recycle()
                }
            }
            // added pages of the new file (blue banner) and removed pages of the old file (grey banner)
            for (i in added) {
                val bmp = newSession.render(i, RENDER_WIDTH) ?: continue
                val page = out.startPage(PdfDocument.PageInfo.Builder(bmp.width, bmp.height, ++reportPages).create())
                page.canvas.drawBitmap(bmp, 0f, 0f, null)
                banner(page.canvas, bmp.width, Color.rgb(21, 101, 192), AppText.get(R.string.compare_banner_added, i + 1))
                out.finishPage(page)
                bmp.recycle()
            }
            for (i in removed) {
                val bmp = oldSession.render(i, RENDER_WIDTH) ?: continue
                val page = out.startPage(PdfDocument.PageInfo.Builder(bmp.width, bmp.height, ++reportPages).create())
                page.canvas.drawBitmap(bmp, 0f, 0f, null)
                page.canvas.drawRect(0f, 0f, bmp.width.toFloat(), bmp.height.toFloat(), Paint().apply { color = Color.argb(60, 90, 90, 90) })
                banner(page.canvas, bmp.width, Color.rgb(97, 97, 97), AppText.get(R.string.compare_banner_removed, i + 1))
                out.finishPage(page)
                bmp.recycle()
            }
            val written = reportPages > 0
            if (written) FileOutputStream(report).use { out.writeTo(it) }
            return Result(nOld, nNew, pairs.size, changed, added.map { it + 1 }, removed.map { it + 1 }, written)
        } finally {
            runCatching { out.close() }
            oldSession.close()
            newSession.close()
        }
    }
}
