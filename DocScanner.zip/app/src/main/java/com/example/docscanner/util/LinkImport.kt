package com.example.docscanner.util

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.IDN
import java.net.URI
import java.net.URL
import java.net.URLDecoder

/**
 * "Import from a web link" (PDF list L7): downloads ONE PDF or picture from an https link the person typed or pasted.
 *
 * Deliberately narrow, because this is the only place the app fetches something the person chose from the open internet:
 *  - https only (a plain http link is refused; [parse] has a switch for the tests, which talk to a local server);
 *  - no credentials inside the link (`https://user:pass@host/...`), no whitespace / control characters, at most [MAX_URL_CHARS];
 *  - redirects are followed by hand, at most [MAX_REDIRECTS], and NEVER from https to http (a downgrade would undo the point of https);
 *  - what arrives must LOOK like a PDF or a JPEG / PNG / WebP picture by its first bytes ([sniffExtension]); an HTML page, a login wall or an
 *    error page is rejected after the first kilobyte instead of being saved with a ".pdf" name; the web server's Content-Type is not trusted;
 *  - at most [MAX_BYTES] (declared Content-Length is checked first, and the count is enforced while streaming: a server that lies or sends
 *    chunked data forever is cut off); a partly written file is always deleted;
 *  - the name comes from Content-Disposition (RFC 6266 / 5987, `filename*` first) or the last path segment, cleaned like a ZIP entry name
 *    ([ZipPack.entryNames]) and given the extension that matches the real content.
 *
 * Pure parts ([parse], [resolveRedirect], [sniffExtension], [fileName], [encodeIllegal]) are mirrored by tools/verify/LinkImportCheck.java;
 * [download] is the same HttpURLConnection code and is exercised there against a local test server.
 */
object LinkImport {

    const val MAX_BYTES = 100L * 1024 * 1024
    const val MAX_REDIRECTS = 5
    const val MAX_URL_CHARS = 2048
    private const val SNIFF_BYTES = 1100
    private const val NAME_MAX_CHARS = 80

    enum class Reason { BAD_URL, FAILED, TOO_BIG, UNSUPPORTED }

    class LinkException(val reason: Reason, message: String? = null) : IOException(message ?: reason.name)

    /** What [download] leaves behind: the file is already at the destination you gave. */
    class Downloaded(val extension: String, val suggestedName: String)

    /**
     * Percent-encodes what a URL may not contain raw but people paste anyway (spaces, accented letters, `"<>\^`{|}`), as UTF-8,
     * and leaves everything else - including existing `%XX` escapes - alone. Applied to the whole text AFTER the host has been split off.
     */
    fun encodeIllegal(s: String): String {
        val sb = StringBuilder(s.length + 16)
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            i += Character.charCount(cp)
            val keep = cp in 0x21..0x7E && cp != '"'.code && cp != '<'.code && cp != '>'.code && cp != '\\'.code &&
                cp != '^'.code && cp != '`'.code && cp != '{'.code && cp != '|'.code && cp != '}'.code
            if (keep) sb.append(cp.toChar()) else for (b in String(Character.toChars(cp)).toByteArray(Charsets.UTF_8)) {
                sb.append('%').append("0123456789ABCDEF"[(b.toInt() shr 4) and 15]).append("0123456789ABCDEF"[b.toInt() and 15])
            }
        }
        return sb.toString()
    }

    /** The link as a [URL] to download, or null when it must not be fetched (see the rules in the class comment). */
    fun parse(input: String, allowCleartext: Boolean = false): URL? {
        val text = input.trim()
        if (text.isEmpty() || text.length > MAX_URL_CHARS) return null
        val lower = text.lowercase()
        val prefixLen = when {
            lower.startsWith("https://") -> 8
            allowCleartext && lower.startsWith("http://") -> 7
            else -> return null
        }
        // split "authority" from the rest so that an accented host can be turned into punycode while the path is only percent-encoded
        var rest = text.substring(prefixLen)
        val cut = rest.indexOfFirst { it == '/' || it == '?' || it == '#' }
        val authority = if (cut < 0) rest else rest.substring(0, cut)
        val tail = if (cut < 0) "" else rest.substring(cut)
        if (authority.isEmpty() || authority.any { it.code <= 32 || it == '@' || it == '\\' } ) return null    // '@' = credentials in the link
        val hostPort = authority
        val colon = hostPort.lastIndexOf(':')
        val host = if (colon > 0 && hostPort.substring(colon + 1).all { it.isDigit() } && !hostPort.endsWith("]")) hostPort.substring(0, colon) else hostPort
        val port = if (host.length != hostPort.length) hostPort.substring(colon) else ""
        if (host.isEmpty()) return null
        val asciiHost = try { if (host.startsWith("[")) host else IDN.toASCII(host, IDN.ALLOW_UNASSIGNED) } catch (e: IllegalArgumentException) { return null }
        if (asciiHost.isEmpty() || asciiHost.any { it.code <= 32 }) return null
        if (tail.any { it.code < 32 || it.code == 127 }) return null
        return try {
            val uri = URI(text.substring(0, prefixLen).lowercase() + asciiHost + port + encodeIllegal(tail))
            if (uri.host.isNullOrEmpty() || uri.userInfo != null) null else uri.toURL()
        } catch (e: Exception) { null }
    }

    /** Where a redirect leads: the Location header resolved against the current address, under the same rules; https -> http is refused. */
    fun resolveRedirect(base: URL, location: String, allowCleartext: Boolean = false): URL? {
        val loc = location.trim()
        if (loc.isEmpty()) return null
        val target = try {
            if (loc.startsWith("?")) {
                // java.net.URI.resolve follows the old RFC 2396 and would drop the file name of the base ("dir/page.pdf" + "?p=2" -> "dir/?p=2");
                // RFC 3986 keeps the path of the base and replaces only the query
                base.toString().substringBefore('#').substringBefore('?') + encodeIllegal(loc)
            } else URI(base.toString()).resolve(URI(encodeIllegal(loc))).toString()
        } catch (e: Exception) { return null }
        val next = parse(target, allowCleartext) ?: return null
        if (base.protocol.equals("https", ignoreCase = true) && !next.protocol.equals("https", ignoreCase = true)) return null
        return next
    }

    /** "pdf", "jpg", "png" or "webp" when the first bytes say so, else null. A PDF header may sit anywhere in the first 1 024 bytes (ISO 32000). */
    fun sniffExtension(head: ByteArray, length: Int = head.size): String? {
        val n = minOf(length, head.size)
        fun at(i: Int) = if (i < n) head[i].toInt() and 0xFF else -1
        if (at(0) == 0xFF && at(1) == 0xD8 && at(2) == 0xFF) return "jpg"
        if (at(0) == 0x89 && at(1) == 0x50 && at(2) == 0x4E && at(3) == 0x47 && at(4) == 0x0D && at(5) == 0x0A && at(6) == 0x1A && at(7) == 0x0A) return "png"
        if (at(0) == 'R'.code && at(1) == 'I'.code && at(2) == 'F'.code && at(3) == 'F'.code &&
            at(8) == 'W'.code && at(9) == 'E'.code && at(10) == 'B'.code && at(11) == 'P'.code) return "webp"
        val limit = minOf(n, 1024 + 5)
        for (i in 0..limit - 5) {
            if (at(i) == '%'.code && at(i + 1) == 'P'.code && at(i + 2) == 'D'.code && at(i + 3) == 'F'.code && at(i + 4) == '-'.code) return "pdf"
        }
        return null
    }

    private fun percentDecode(s: String, charset: String): String? = try {
        URLDecoder.decode(s.replace("+", "%2B"), charset)          // '+' is a literal plus in a path and in RFC 5987 values, not a space
    } catch (e: Exception) { null }

    /** The `filename` a Content-Disposition header proposes (`filename*` of RFC 5987 beats plain `filename`), or null. */
    fun dispositionName(header: String?): String? {
        if (header.isNullOrBlank()) return null
        var plain: String? = null
        var extended: String? = null
        // split on ';' that are not inside quotes
        val parts = ArrayList<String>(); val cur = StringBuilder(); var quoted = false
        for (c in header) { if (c == '"') quoted = !quoted; if (c == ';' && !quoted) { parts.add(cur.toString()); cur.setLength(0) } else cur.append(c) }
        parts.add(cur.toString())
        for (part in parts.drop(1)) {
            val eq = part.indexOf('=')
            if (eq < 0) continue
            val key = part.substring(0, eq).trim().lowercase()
            var value = part.substring(eq + 1).trim()
            if (key == "filename*") {
                val first = value.indexOf('\''); val second = if (first >= 0) value.indexOf('\'', first + 1) else -1
                if (first > 0 && second > first) {
                    val cs = value.substring(0, first).lowercase()
                    val charset = when (cs) { "utf-8" -> "UTF-8"; "iso-8859-1" -> "ISO-8859-1"; else -> null }
                    if (charset != null) extended = percentDecode(value.substring(second + 1), charset)
                }
            } else if (key == "filename") {
                if (value.length >= 2 && value.startsWith("\"") && value.endsWith("\"")) value = value.substring(1, value.length - 1).replace("\\\"", "\"").replace("\\\\", "\\")
                plain = value
            }
        }
        return (extended ?: plain)?.takeIf { it.isNotBlank() }
    }

    /** File name to save under: the proposed name (header, else last path segment) cleaned, shortened, with the extension of the real content. */
    fun fileName(url: URL, contentDisposition: String?, extension: String): String {
        val proposed = dispositionName(contentDisposition)
            ?: percentDecode(url.path.substringAfterLast('/'), "UTF-8")
            ?: ""
        var base = ZipPack.entryNames(listOf(proposed))[0]
        if (proposed.isBlank()) base = "download"
        // drop an extension the name already has when it is one of ours (".pdf" on a JPEG would lie), keep other dots ("v1.2 report")
        val dot = base.lastIndexOf('.')
        if (dot > 0 && base.substring(dot + 1).lowercase() in setOf("pdf", "jpg", "jpeg", "png", "webp", "php", "html", "htm", "asp", "aspx", "jsp", "download")) base = base.substring(0, dot)
        if (base.codePointCount(0, base.length) > NAME_MAX_CHARS) base = base.substring(0, base.offsetByCodePoints(0, NAME_MAX_CHARS)).trim()
        if (base.isEmpty()) base = "download"
        return "$base.$extension"
    }

    /**
     * Downloads [url] into [dest] (replaced if it exists). Throws [LinkException]; on any failure [dest] is deleted.
     * [maxBytes] and [allowCleartext] exist for the tests; the app uses the defaults.
     */
    fun download(url: URL, dest: File, maxBytes: Long = MAX_BYTES, allowCleartext: Boolean = false): Downloaded {
        try {
            return fetch(url, dest, maxBytes, allowCleartext)
        } catch (e: LinkException) {
            dest.delete(); throw e
        } catch (e: Exception) {
            dest.delete(); throw LinkException(Reason.FAILED, e.toString())
        }
    }

    private fun fetch(first: URL, dest: File, maxBytes: Long, allowCleartext: Boolean): Downloaded {
        var current = first
        var hops = 0
        while (true) {
            val c = current.openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 15_000
            c.readTimeout = 30_000
            c.setRequestProperty("Accept", "application/pdf,image/*;q=0.9,*/*;q=0.5")
            try {
                val code = c.responseCode
                if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                    if (++hops > MAX_REDIRECTS) throw LinkException(Reason.FAILED, "too many redirects")
                    current = resolveRedirect(current, c.getHeaderField("Location") ?: "", allowCleartext)
                        ?: throw LinkException(Reason.FAILED, "bad redirect")
                    continue
                }
                if (code != 200) throw LinkException(Reason.FAILED, "HTTP $code")
                if (c.contentLengthLong > maxBytes) throw LinkException(Reason.TOO_BIG)
                val disposition = c.getHeaderField("Content-Disposition")
                val declared = c.contentLengthLong          // -1 when unknown (chunked, or the platform removed it because it decoded gzip for us)
                c.inputStream.use { input ->
                    val head = ByteArray(SNIFF_BYTES)
                    var have = 0
                    while (have < head.size) { val r = input.read(head, have, head.size - have); if (r < 0) break; have += r }
                    val ext = sniffExtension(head, have) ?: throw LinkException(Reason.UNSUPPORTED)
                    var total = have.toLong()
                    if (total > maxBytes) throw LinkException(Reason.TOO_BIG)
                    FileOutputStream(dest).use { out ->
                        out.write(head, 0, have)
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val r = input.read(buf)
                            if (r < 0) break
                            total += r
                            if (total > maxBytes) throw LinkException(Reason.TOO_BIG)
                            out.write(buf, 0, r)
                        }
                    }
                    // the JDK's HttpURLConnection (unlike Android's) does not report a body that ends before its Content-Length: check it here
                    if (declared >= 0 && total != declared) throw LinkException(Reason.FAILED, "truncated: $total of $declared bytes")
                    return Downloaded(ext, fileName(current, disposition, ext))
                }
            } finally {
                c.disconnect()
            }
        }
    }
}
