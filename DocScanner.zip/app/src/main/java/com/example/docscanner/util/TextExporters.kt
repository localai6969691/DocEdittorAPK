package com.example.docscanner.util

/**
 * Plain-text documents as HTML and Markdown, from the text of each page (text layer or OCR, see `loadDocumentPages`). Paragraphs are
 * rebuilt by [DocxWriter.paragraphsFromText] exactly as for Word. Pure; `tools/verify/export_check.py` checks both outputs with
 * independent readers (an HTML parser; pandoc for Markdown, so what a Markdown reader shows must equal the text that went in).
 */
object TextExporters {

    private fun paragraphsOf(page: String): List<String> =
        DocxWriter.paragraphsFromText(page).filter { it != DocxWriter.PAGE_BREAK }

    /** A self-contained UTF-8 HTML page: title, one `<section class="page">` per page with its `<p>` paragraphs, and a small stylesheet (no external files). */
    fun html(title: String, pages: List<String>): String {
        val sb = StringBuilder()
        sb.append("<!DOCTYPE html>\n<html lang=\"vi\">\n<head>\n<meta charset=\"utf-8\">\n")
        sb.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n")
        sb.append("<title>").append(DocxWriter.escape(title)).append("</title>\n")
        sb.append("<style>body{max-width:42em;margin:2em auto;padding:0 1em;font-family:Georgia,'Times New Roman',serif;line-height:1.6}")
        sb.append("section.page{border-top:1px solid #ccc;margin-top:2em;padding-top:1em}h2{font-size:1em;color:#666;font-weight:normal}</style>\n")
        sb.append("</head>\n<body>\n<h1>").append(DocxWriter.escape(title)).append("</h1>\n")
        for ((i, page) in pages.withIndex()) {
            sb.append("<section class=\"page\" id=\"p").append(i + 1).append("\">\n<h2>Trang ").append(i + 1).append("</h2>\n")
            for (p in paragraphsOf(page)) sb.append("<p>").append(DocxWriter.escape(p)).append("</p>\n")
            sb.append("</section>\n")
        }
        sb.append("</body>\n</html>\n")
        return sb.toString()
    }

    /** CommonMark: `# title`, `## Trang N` per page, one paragraph per block, `---` between pages. Characters that Markdown would read as markup are backslash-escaped. */
    fun markdown(title: String, pages: List<String>): String {
        val sb = StringBuilder()
        sb.append("# ").append(mdEscape(title.replace('\n', ' '), startOfBlock = false)).append("\n\n")
        for ((i, page) in pages.withIndex()) {
            if (i > 0) sb.append("---\n\n")
            sb.append("## Trang ").append(i + 1).append("\n\n")
            for (p in paragraphsOf(page)) sb.append(mdEscape(p, startOfBlock = true)).append("\n\n")
        }
        return sb.toString()
    }

    /** Ebook (chuong = tieu de + cac doan, nhu [EpubReader.read] tra ve) thanh HTML: `<h1>` ten sach, moi chuong mot `<section class="chapter">` co `<h2>` ten chuong. */
    fun htmlFromChapters(title: String, chapters: List<EbookBuilder.Chapter>): String {
        val sb = StringBuilder()
        sb.append("<!DOCTYPE html>\n<html lang=\"vi\">\n<head>\n<meta charset=\"utf-8\">\n")
        sb.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n")
        sb.append("<title>").append(DocxWriter.escape(title)).append("</title>\n")
        sb.append("<style>body{max-width:42em;margin:2em auto;padding:0 1em;font-family:Georgia,'Times New Roman',serif;line-height:1.6}")
        sb.append("section.chapter{border-top:1px solid #ccc;margin-top:2em;padding-top:1em}</style>\n")
        sb.append("</head>\n<body>\n<h1>").append(DocxWriter.escape(title)).append("</h1>\n")
        for ((i, ch) in chapters.withIndex()) {
            sb.append("<section class=\"chapter\" id=\"c").append(i + 1).append("\">\n<h2>").append(DocxWriter.escape(ch.title)).append("</h2>\n")
            for (p in ch.paragraphs) sb.append("<p>").append(DocxWriter.escape(p)).append("</p>\n")
            sb.append("</section>\n")
        }
        sb.append("</body>\n</html>\n")
        return sb.toString()
    }

    /** Ebook thanh CommonMark: `# ten sach`, `## ten chuong`, moi doan mot khoi; ky tu Markdown duoc escape nhu [markdown]. */
    fun markdownFromChapters(title: String, chapters: List<EbookBuilder.Chapter>): String {
        val sb = StringBuilder()
        sb.append("# ").append(mdEscape(title.replace('\n', ' '), startOfBlock = false)).append("\n\n")
        for (ch in chapters) {
            sb.append("## ").append(mdEscape(ch.title.replace('\n', ' '), startOfBlock = false)).append("\n\n")
            for (p in ch.paragraphs) sb.append(mdEscape(p, startOfBlock = true)).append("\n\n")
        }
        return sb.toString()
    }

    private const val INLINE_SPECIALS = "\\`*_[]<>&|"

    // ---- JSON / XML / Base64 (PDF list L11, L12, L15; phiên 22, mục 4.49.2) ----

    /**
     * JSON text of [s] with its quotes: `"` `\\` and every control character are escaped (`\\u00XX`, short forms for `\\n` `\\t`...), valid pairs
     * of surrogates (emoji) stay as they are, and a LONE surrogate - which cannot be written as UTF-8 and would turn into "?" - becomes
     * U+FFFD. U+2028 / U+2029 are legal in JSON and stay.
     */
    fun jsonString(s: String): String {
        val sb = StringBuilder(s.length + 2)
        sb.append('"')
        var i = 0
        while (i < s.length) {
            val c = s[i]
            when {
                c == '"' -> sb.append("\\\"")
                c == '\\' -> sb.append("\\\\")
                c == '\n' -> sb.append("\\n")
                c == '\r' -> sb.append("\\r")
                c == '\t' -> sb.append("\\t")
                c == '\b' -> sb.append("\\b")
                c == '\u000C' -> sb.append("\\f")
                c.code < 0x20 -> sb.append("\\u").append(c.code.toString(16).padStart(4, '0'))
                Character.isHighSurrogate(c) && i + 1 < s.length && Character.isLowSurrogate(s[i + 1]) -> { sb.append(c).append(s[i + 1]); i++ }
                Character.isSurrogate(c) -> sb.append('\uFFFD')
                else -> sb.append(c)
            }
            i++
        }
        return sb.append('"').toString()
    }

    /** `{"title", "pageCount", "pages": [{"page": N, "paragraphs": [...]}]}`, two-space indent, one paragraph per line. */
    fun jsonFromParagraphs(title: String, pages: List<List<String>>): String {
        val sb = StringBuilder()
        sb.append("{\n  \"title\": ").append(jsonString(title)).append(",\n  \"pageCount\": ").append(pages.size).append(",\n  \"pages\": [")
        for ((i, paras) in pages.withIndex()) {
            sb.append(if (i == 0) "\n" else ",\n").append("    {\"page\": ").append(i + 1).append(", \"paragraphs\": [")
            for ((j, p) in paras.withIndex()) sb.append(if (j == 0) "\n      " else ",\n      ").append(jsonString(p))
            sb.append(if (paras.isEmpty()) "]}" else "\n    ]}")
        }
        sb.append(if (pages.isEmpty()) "]\n}\n" else "\n  ]\n}\n")
        return sb.toString()
    }

    fun json(title: String, pages: List<String>): String = jsonFromParagraphs(title, pages.map { paragraphsOf(it) })

    /** Escapes [s] for an XML ATTRIBUTE value in double quotes: [DocxWriter.escape] (drops characters XML 1.0 forbids) plus `"` and line breaks. */
    fun xmlAttr(s: String): String =
        DocxWriter.escape(s).replace("\"", "&quot;").replace("\r", "&#13;").replace("\n", "&#10;").replace("\t", "&#9;")

    /** `<document title pages><page number><paragraph>…`; UTF-8, XML 1.0 (forbidden characters dropped, so any parser accepts it). */
    fun xmlFromParagraphs(title: String, pages: List<List<String>>): String {
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<document title=\"").append(xmlAttr(title)).append("\" pages=\"").append(pages.size).append("\">\n")
        for ((i, paras) in pages.withIndex()) {
            sb.append("  <page number=\"").append(i + 1).append("\">\n")
            for (p in paras) sb.append("    <paragraph>").append(DocxWriter.escape(p).replace("\r", "&#13;")).append("</paragraph>\n")   // a literal CR would be read back as LF
            sb.append("  </page>\n")
        }
        sb.append("</document>\n")
        return sb.toString()
    }

    fun xml(title: String, pages: List<String>): String = xmlFromParagraphs(title, pages.map { paragraphsOf(it) })

    private const val B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

    /**
     * Streams [input] to [output] as standard Base64 (RFC 4648 section 4, with `=` padding), wrapped at [lineLength] characters with LF
     * (76 = the MIME line length, which every decoder accepts; 0 = one single line). Written by hand because `java.util.Base64` needs
     * Android 8 (API 26) and this app supports API 24; `android.util.Base64OutputStream` would not run on a plain JVM for the checks.
     */
    fun base64(input: java.io.InputStream, output: java.io.OutputStream, lineLength: Int = 76) {
        val inBuf = ByteArray(3 * 4096)
        val outBuf = java.io.ByteArrayOutputStream(4 * 4096 + 4 * 4096 / 76 + 16)
        var col = 0
        fun put(c: Char) {
            if (lineLength > 0 && col == lineLength) { outBuf.write('\n'.code); col = 0 }
            outBuf.write(c.code); col++
        }
        while (true) {
            var n = 0
            while (n < inBuf.size) { val r = input.read(inBuf, n, inBuf.size - n); if (r < 0) break; n += r }
            var i = 0
            while (i + 3 <= n) {
                val v = ((inBuf[i].toInt() and 0xFF) shl 16) or ((inBuf[i + 1].toInt() and 0xFF) shl 8) or (inBuf[i + 2].toInt() and 0xFF)
                put(B64[v ushr 18]); put(B64[(v ushr 12) and 63]); put(B64[(v ushr 6) and 63]); put(B64[v and 63])
                i += 3
            }
            val rest = n - i
            if (rest > 0) {
                val v = ((inBuf[i].toInt() and 0xFF) shl 16) or (if (rest == 2) (inBuf[i + 1].toInt() and 0xFF) shl 8 else 0)
                put(B64[v ushr 18]); put(B64[(v ushr 12) and 63])
                put(if (rest == 2) B64[(v ushr 6) and 63] else '='); put('=')
            }
            outBuf.writeTo(output); outBuf.reset()
            if (n < inBuf.size) break
        }
        if (lineLength > 0 && col > 0) output.write('\n'.code)
        output.flush()
    }

    /** Escapes [text] for Markdown; with [startOfBlock] also the markers that only matter at the start of a paragraph (`#`, `+`, `-`, `=`, `~`, `1.`, `1)`). */
    fun mdEscape(text: String, startOfBlock: Boolean): String {
        val sb = StringBuilder(text.length + 8)
        for (c in text) {
            if (c in INLINE_SPECIALS) sb.append('\\')
            sb.append(c)
        }
        var out = sb.toString()
        if (startOfBlock) {
            val m = Regex("^(#{1,6}|[+\\-=~]|[0-9]{1,9}[.)])").find(out)
            if (m != null) {
                // put the backslash in front of the marker character that Markdown would act on
                val marker = m.value
                val at = if (marker[0] in '0'..'9') marker.length - 1 else 0
                out = out.substring(0, at) + "\\" + out.substring(at)
            }
        }
        return out
    }
}
