package com.example.docscanner.util

import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Don dep luu tru (phien 18, PDF "Thieu gi de ban app" muc D3 / E2 / E3): bao cao dung luong, tim tai lieu trung, ghi de truoc khi xoa han.
 * Chi dung java.io + java.security; ban Java chay duoc `tools/verify/StorageToolsCheck.java`, kiem chung boi `tools/verify/storage_tools_check.py`.
 *
 * **Xoa sach ([wipe]) la NO LUC TOT NHAT, khong phai bao dam:** bo nho flash phan bo deu mon (wear levelling) nen ban ghi de khong chac
 * trung dung o vat ly cu. Bao ve thuc su la ma hoa du lieu cua may (thiet bi ra mat voi Android 10 tro len phai ma hoa theo tep; kiem tra theo may).
 * Ghi de khong ton gi them nen duoc dung o cho "xoa han" (thung rac); giao dien KHONG hua "xoa sach khong khoi phuc duoc" - xem TECHNICAL_DOCS.md 4.36.
 */
object StorageTools {

    class Report(val fileCount: Int, val totalBytes: Long, val byCategory: Map<String, Pair<Int, Long>>, val biggest: List<File>)

    fun category(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "pdf" -> "pdf"
        "epub" -> "epub"
        "txt", "md", "html", "htm" -> "text"
        "docx", "xlsx", "pptx" -> "office"
        "jpg", "jpeg", "png", "webp" -> "image"
        else -> "other"
    }

    /** Moi tep thuong trong [dir] (de quy), bo tep dang ghi do `.part`. */
    fun walk(dir: File): List<File> {
        val out = ArrayList<File>()
        val kids = dir.listFiles() ?: return out
        for (f in kids) {
            if (f.isDirectory) out.addAll(walk(f)) else if (f.isFile && !f.name.endsWith(".part")) out.add(f)
        }
        return out
    }

    /** `.txt` canh mot `.pdf` cung ten la lop chu OCR cua PDF do (di cung no vao thung rac): khong tinh la tai lieu rieng. */
    fun isOcrSidecar(f: File): Boolean {
        val n = f.name
        if (!n.lowercase().endsWith(".txt")) return false
        return File(f.parentFile, n.substring(0, n.length - 4) + ".pdf").isFile
    }

    /** Cac tep nguoi dung thay: [walk] bo lop chu OCR. */
    fun visibleFiles(dir: File): List<File> = walk(dir).filter { !isOcrSidecar(it) }

    fun report(files: List<File>, top: Int): Report {
        var total = 0L
        val cat = java.util.TreeMap<String, LongArray>()
        for (f in files) {
            val len = f.length(); total += len
            val c = cat.getOrPut(category(f.name)) { LongArray(2) }
            c[0]++; c[1] += len
        }
        val sorted = files.sortedWith(compareBy<File>({ -it.length() }, { it.name }))
        return Report(files.size, total, cat.mapValues { it.value[0].toInt() to it.value[1] }, sorted.take(top))
    }

    private fun sha(f: File, limit: Long): String {
        val md = MessageDigest.getInstance("SHA-256")
        FileInputStream(f).use { input: InputStream ->
            val buf = ByteArray(65536)
            var left = limit
            while (left != 0L) {
                val want = if (left < 0) buf.size else minOf(buf.size.toLong(), left).toInt()
                val n = input.read(buf, 0, want)
                if (n < 0) break
                md.update(buf, 0, n)
                if (left > 0) left -= n
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    /**
     * Nhom cac tep co NOI DUNG giong het nhau: cung dung luong -> cung SHA-256 cua [prefix] byte dau -> cung SHA-256 TOAN BO (hai tep cung cua va cung
     * [prefix] byte dau nhung khac phan cuoi van phai tach - bai kiem co thu am tinh cho dung loi nay). Tep rong bi bo qua. Trong nhom: tep CU NHAT dung dau
     * (la ban nen giu), cac nhom xep theo dung luong giam dan. Doc tung tep luong 64 KB, khong nap ca tep vao bo nho.
     */
    fun findDuplicates(files: List<File>, prefix: Int = 65536): List<List<File>> {
        val bySize = java.util.TreeMap<Long, MutableList<File>>()
        for (f in files) { val len = f.length(); if (len > 0) bySize.getOrPut(len) { ArrayList() }.add(f) }
        val out = ArrayList<MutableList<File>>()
        for (g1 in bySize.values) {
            if (g1.size < 2) continue
            val byHead = LinkedHashMap<String, MutableList<File>>()
            for (f in g1) byHead.getOrPut(sha(f, prefix.toLong())) { ArrayList() }.add(f)
            for (g2 in byHead.values) {
                if (g2.size < 2) continue
                val byAll = LinkedHashMap<String, MutableList<File>>()
                for (f in g2) byAll.getOrPut(sha(f, -1)) { ArrayList() }.add(f)
                for (g3 in byAll.values) if (g3.size >= 2) out.add(g3)
            }
        }
        for (g in out) g.sortWith(compareBy<File>({ it.lastModified() }, { it.name }))
        out.sortWith(compareBy<MutableList<File>>({ -it[0].length() }, { it[0].name }))
        return out
    }

    /** Ghi de noi dung tai cho bang byte ngau nhien (giu nguyen do dai) roi dong bo xuong dia. @return false neu khong ghi duoc. */
    fun overwrite(f: File): Boolean = try {
        RandomAccessFile(f, "rw").use { raf ->
            val len = raf.length()
            val rnd = SecureRandom()
            val buf = ByteArray(65536)
            raf.seek(0)
            var done = 0L
            while (done < len) {
                val n = minOf(buf.size.toLong(), len - done).toInt()
                rnd.nextBytes(buf)
                raf.write(buf, 0, n)
                done += n
            }
            raf.fd.sync()
        }
        true
    } catch (_: IOException) { false }

    /** Ghi de (neu la tep) roi xoa. @return true neu tep da bi xoa; ghi de that bai van co xoa (nhu cach cu). */
    fun wipe(f: File): Boolean {
        if (!f.exists()) return false
        if (f.isFile) overwrite(f)
        return f.delete()
    }

    private const val SPACE_MARGIN = 64L * 1024 * 1024

    /** Dung luong trong can co de xu ly mot dau vao [inputBytes]: gap doi dau vao (ban sao + ket qua) + 64 MB du phong; bao hoa o Long.MAX_VALUE, khong tran so. */
    fun requiredSpace(inputBytes: Long): Long {
        val twice = if (inputBytes > Long.MAX_VALUE / 2) Long.MAX_VALUE else inputBytes * 2
        return if (twice > Long.MAX_VALUE - SPACE_MARGIN) Long.MAX_VALUE else twice + SPACE_MARGIN
    }

    fun enoughSpace(freeBytes: Long, inputBytes: Long): Boolean = freeBytes >= requiredSpace(inputBytes)

    /** Xoa sach ca thu muc [dir] (de quy): moi tep di qua [wipe] (ghi de roi xoa), roi xoa thu muc con va chinh [dir]. @return so TEP da xoa; thu muc khong co thi 0. */
    fun wipeTree(dir: File): Int {
        if (!dir.exists()) return 0
        if (dir.isFile) return if (wipe(dir)) 1 else 0
        var n = 0
        dir.listFiles()?.forEach { n += wipeTree(it) }
        dir.delete()
        return n
    }
}
