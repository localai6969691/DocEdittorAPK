package com.example.docscanner.util

import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

/**
 * Chon ngon ngu giao dien (phien 18, TECHNICAL_DOCS.md 4.46). Mac dinh (chua chon gi) = THEO NGON NGU MAY: neu ngon ngu may co trong app thi dung no, neu KHONG co thi
 * Android roi ve thu muc tai nguyen mac dinh = tieng Anh. Chon ro mot ngon ngu = [apply]; Android 13+ dong bo voi muc "Ngon ngu cua ung dung" trong Cai dat he thong,
 * cac may cu nho lua chon qua dich vu AppLocalesMetadataHolderService (autoStoreLocales). Danh sach ngon ngu: res/xml/locales_config.xml + hai mang app_language_*
 * (sinh boi tools/verify/i18n_check.py tu tools/i18n/languages.txt).
 */
object AppLanguages {
    /** @param tag ma BCP-47 (vi, ja, pt-BR...) hoac null = theo ngon ngu may. Activity dang mo duoc tao lai tu dong. */
    fun apply(tag: String?) {
        AppCompatDelegate.setApplicationLocales(if (tag == null) LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(tag))
    }

    fun currentTag(): String = AppCompatDelegate.getApplicationLocales().toLanguageTags()

    /**
     * Vi tri muc dang chon trong danh sach [system mac dinh] + [tags]: 0 = theo ngon ngu may (chua chon), i + 1 = tags[i]. [current] khop [tags] khong phan biet hoa thuong,
     * hoac la bien the cua no ("vi-VN" chon "vi"); khop CHINH XAC duoc uu tien hon khop theo tien to ("pt-BR" chon "pt-BR" chu khong phai "pt"). Khong khop gi -> 0.
     */
    fun checkedIndex(tags: List<String>, current: String): Int {
        if (current.isEmpty()) return 0
        val exact = tags.indexOfFirst { it.equals(current, ignoreCase = true) }
        if (exact >= 0) return exact + 1
        // Android 13+ co the tra the co chu viet ("zh-Hans-CN") cho muc "zh-CN" trong locales_config: bo phan chu viet (4 chu cai) roi khop lai.
        val plain = stripScript(current)
        val exactPlain = tags.indexOfFirst { it.equals(plain, ignoreCase = true) }
        if (exactPlain >= 0) return exactPlain + 1
        var best = -1
        for ((i, t) in tags.withIndex()) if (plain.startsWith("$t-", ignoreCase = true) && (best < 0 || t.length > tags[best].length)) best = i
        return best + 1
    }

    /** "zh-Hans-CN" -> "zh-CN": bo moi thanh phan 4 chu cai o sau ma ngon ngu (chu viet); "es-419" va "pt-BR" giu nguyen. */
    internal fun stripScript(tag: String): String =
        tag.split('-').filterIndexed { i, p -> !(i > 0 && p.length == 4 && p.all { it.isLetter() }) }.joinToString("-")
}
