package com.example.docscanner.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File

/**
 * Renders pages of a PDF to bitmaps with the platform's [PdfRenderer] (the page as displayed: rotation and CropBox
 * applied). A password-protected PDF cannot be opened by it: [open] then returns null. Use [Session] for several pages
 * of one file; [renderFirstPage] is the one-shot form used to read a title for [SmartNamer].
 */
object PdfPageBitmap {

    class Session private constructor(private val fd: ParcelFileDescriptor, private val renderer: PdfRenderer) : AutoCloseable {
        val pageCount: Int get() = renderer.pageCount

        /** Page [index] scaled so its width is [targetWidth] pixels (height follows), on a white background. */
        fun render(index: Int, targetWidth: Int): Bitmap? {
            if (index !in 0 until renderer.pageCount) return null
            val page = renderer.openPage(index)
            try {
                val w = targetWidth.coerceAtLeast(1)
                val h = (page.height.toFloat() * w / page.width).toInt().coerceIn(1, 6000)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                Canvas(bmp).drawColor(Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                return bmp
            } finally {
                page.close()
            }
        }

        /** Width of page [index] in points (1/72 inch) as [PdfRenderer] reports it, or 0 when there is no such page; used to turn a pixel width into a resolution (dpi). */
        fun pageWidthPoints(index: Int): Float {
            if (index !in 0 until renderer.pageCount) return 0f
            val page = renderer.openPage(index)
            try {
                return page.width.toFloat()
            } finally {
                page.close()
            }
        }

        override fun close() {
            runCatching { renderer.close() }
            runCatching { fd.close() }
        }

        companion object {
            fun open(file: File): Session? {
                var fd: ParcelFileDescriptor? = null
                return try {
                    fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                    val r = PdfRenderer(fd)
                    if (r.pageCount == 0) { r.close(); fd.close(); null } else Session(fd, r)
                } catch (e: Throwable) {
                    runCatching { fd?.close() }
                    null
                }
            }
        }
    }

    fun open(file: File): Session? = Session.open(file)

    fun renderFirstPage(file: File, targetWidth: Int = 1400): Bitmap? =
        open(file)?.use { it.render(0, targetWidth) }
}
