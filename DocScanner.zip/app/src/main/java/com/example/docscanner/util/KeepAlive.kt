package com.example.docscanner.util

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.docscanner.R

/**
 * Dem so viec dang chay: goi [onFirst] khi tu 0 len 1 va [onLast] khi ve lai 0. [release] khi dang o 0 bi BO QUA (khong am);
 * [reset] dua ve 0 (goi [onLast] neu dang > 0) - dung khi he thong ngat dich vu vi het gio. Ban Java chay duoc: `tools/verify/KeepAliveCheck.java`.
 */
class WorkTracker(private val onFirst: () -> Unit, private val onLast: () -> Unit) {
    private var n = 0

    @Synchronized fun acquire() { n++; if (n == 1) onFirst() }

    @Synchronized fun release() { if (n == 0) return; n--; if (n == 0) onLast() }

    @Synchronized fun reset() { if (n > 0) { n = 0; onLast() } }

    @get:Synchronized val active: Int get() = n
}

/**
 * Giu tien trinh song khi mot viec dai dang chay (nen, OCR, ghep, xuat...) ma nguoi dung chuyen sang app khac (phien 18, TECHNICAL_DOCS.md 4.38).
 * Cach dung: [acquire] truoc viec, [release] sau do - hoac [during] bao quanh mot khoi suspend (luon release, ke ca khi loi / huy).
 * Phia sau la [KeepAliveService]: dich vu foreground loai `dataSync` voi mot thong bao "Dang xu ly tai lieu". Dich vu KHONG chay viec thay Activity,
 * no chi nang do uu tien cua tien trinh de he thong khong thu hoi no; viec van chay trong coroutine cua Activity nhu cu.
 * Neu khong khoi dong duoc dich vu (Android tu choi, het han muc 6 gio / 24 gio cua dataSync...), viec van chay, chi khong duoc bao ve.
 */
object KeepAlive {
    @Volatile private var appContext: Context? = null
    private val tracker = WorkTracker(onFirst = { startService() }, onLast = { stopService() })

    fun acquire(context: Context) {
        appContext = context.applicationContext
        tracker.acquire()
    }

    fun release() = tracker.release()

    /** He thong da ngat dich vu vi het gio (Android 15+): dua dem ve 0; viec dang chay van tiep tuc nhung khong con duoc bao ve. */
    fun onServiceTimeout() = tracker.reset()

    suspend fun <T> during(context: Context, block: suspend () -> T): T {
        acquire(context)
        try {
            return block()
        } finally {
            release()
        }
    }

    private fun startService() {
        val ctx = appContext ?: return
        try {
            ContextCompat.startForegroundService(ctx, Intent(ctx, KeepAliveService::class.java))
        } catch (e: Exception) {
            Log.w("KeepAlive", "khong khoi dong duoc dich vu nen: " + e.javaClass.simpleName)
        }
    }

    private fun stopService() {
        val ctx = appContext ?: return
        try {
            ctx.stopService(Intent(ctx, KeepAliveService::class.java))
        } catch (e: Exception) {
            Log.w("KeepAlive", "khong dung duoc dich vu nen: " + e.javaClass.simpleName)
        }
    }
}

/** Dich vu foreground `dataSync` chi de nang do uu tien tien trinh; khong lam viec gi khac. Khai bao trong AndroidManifest.xml cung loai dich vu. */
class KeepAliveService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val notification = buildNotification()
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(NOTIFICATION_ID, notification)
        } catch (e: Exception) {
            // Android tu choi (khong du dieu kien chay nen, het han muc dataSync...): bo, viec van chay khong duoc bao ve
            Log.w("KeepAlive", "startForeground bi tu choi: " + e.javaClass.simpleName)
            KeepAlive.onServiceTimeout()
            stopSelf()
        }
        return START_NOT_STICKY
    }

    /** Android 15+: sau 6 gio dataSync trong 24 gio he thong goi ham nay; PHAI dung dich vu, neu khong ung dung bi dong voi RemoteServiceException. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        KeepAlive.onServiceTimeout()
        stopSelf()
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL_ID) == null) {
                nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, getString(R.string.keepalive_channel), NotificationManager.IMPORTANCE_LOW))
            }
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_convert)
            .setContentTitle(getString(R.string.keepalive_title))
            .setContentText(getString(R.string.keepalive_text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private companion object {
        const val CHANNEL_ID = "long_task"
        const val NOTIFICATION_ID = 4101
    }
}
