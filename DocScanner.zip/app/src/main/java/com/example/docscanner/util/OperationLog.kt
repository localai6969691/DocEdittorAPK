package com.example.docscanner.util

import android.content.Context
import java.io.File
import java.security.MessageDigest

/**
 * An operation log whose entries are CHAINED by SHA-256 so that a change made behind the app's back shows (phiên 25, TECHNICAL_DOCS.md 4.73; PDF list item 7.6 "audit trail").
 *
 * Every entry holds the hash of the entry before it, and its own hash covers the previous hash, its number, its time, its action and its detail. So editing an entry, removing one from the middle,
 * inserting one or putting two in another order breaks the chain from that point on, and [verify] names the first entry that no longer fits.
 *
 * What this does NOT give (said plainly, and shown in the log screen): there is no secret key, so someone who rewrites the WHOLE file and recomputes every hash cannot be told from the
 * real thing, and cutting entries off the END leaves a valid shorter chain. The last hash ([Verification.head]) is shown so that a person can write it down or send it elsewhere: a log whose
 * last hash no longer matches what was noted has been cut or rewritten. The log is kept on the device only; nothing is sent anywhere.
 *
 * The functions on strings ([hashOf], [next], [encode], [parse], [verify], [trim]) are pure and are what tools/verify/operation_log_real_run_check.py runs for real, comparing the hash with an
 * independent Python SHA-256. [record], [syncLibrary] and [read] add the file and the preferences.
 */
object OperationLog {

    /** The "previous hash" of the first entry ever written. */
    const val GENESIS = "0000000000000000000000000000000000000000000000000000000000000000"

    /** Past this many entries the oldest are dropped, down to [KEEP_LINES] (the chain of those that stay still verifies: see [verify]). */
    const val MAX_LINES = 2000
    const val KEEP_LINES = 1500

    /** A single sync that finds more new or removed files than this logs ONE summary entry instead of one each (restoring a backup would otherwise flood the log). */
    const val MAX_INDIVIDUAL = 20

    const val ACTION_BASELINE = "baseline"
    const val ACTION_CREATED = "created"
    const val ACTION_REMOVED = "removed"
    const val ACTION_SHARED = "shared"

    class Entry(val seq: Long, val time: Long, val action: String, val detail: String, val prev: String, val hash: String)

    enum class Status { EMPTY, OK, BROKEN }

    /** [status] OK / EMPTY / BROKEN; [count] entries read; [badSeq] the number of the first entry that does not fit (BROKEN only, -1 for an unreadable line); [head] the last hash. */
    class Verification(val status: Status, val count: Int, val badSeq: Long, val head: String)

    private fun utf8Length(s: String): Int = s.toByteArray(Charsets.UTF_8).size

    /** SHA-256 (lower-case hex) of `prev \n seq \n time \n <bytes>:action \n <bytes>:detail`, where <bytes> is the UTF-8 length, so no value can run into the next one. */
    fun hashOf(prev: String, seq: Long, time: Long, action: String, detail: String): String {
        val text = prev + "\n" + seq + "\n" + time + "\n" + utf8Length(action) + ":" + action + "\n" + utf8Length(detail) + ":" + detail
        val digest = MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder(digest.size * 2)
        for (b in digest) sb.append(String.format("%02x", b.toInt() and 0xFF))
        return sb.toString()
    }

    /** The entry that follows [last] (null = the first entry of a new log). */
    fun next(last: Entry?, time: Long, action: String, detail: String): Entry {
        val seq = (last?.seq ?: 0L) + 1L
        val prev = last?.hash ?: GENESIS
        return Entry(seq, time, action, detail, prev, hashOf(prev, seq, time, action, detail))
    }

    private fun escape(s: String): String {
        val sb = StringBuilder(s.length + 8)
        for (c in s) {
            when (c) {
                '\\' -> sb.append("\\\\")
                '\t' -> sb.append("\\t")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun unescape(s: String): String? {
        val sb = StringBuilder(s.length)
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c != '\\') {
                sb.append(c)
                i++
                continue
            }
            if (i + 1 >= s.length) return null
            when (s[i + 1]) {
                '\\' -> sb.append('\\')
                't' -> sb.append('\t')
                'n' -> sb.append('\n')
                'r' -> sb.append('\r')
                else -> return null
            }
            i += 2
        }
        return sb.toString()
    }

    /** One line of the file: `seq TAB time TAB action TAB detail TAB prev TAB hash`, with backslash, tab, newline and carriage return escaped in action and detail. */
    fun encode(e: Entry): String = e.seq.toString() + "\t" + e.time + "\t" + escape(e.action) + "\t" + escape(e.detail) + "\t" + e.prev + "\t" + e.hash

    /** The entry on [line], or null when it is not a well-formed line (wrong number of fields, a number that is not one, a hash that is not 64 hex digits, a bad escape). */
    fun parse(line: String): Entry? {
        val f = line.split("\t")
        if (f.size != 6) return null
        val seq = f[0].toLongOrNull() ?: return null
        val time = f[1].toLongOrNull() ?: return null
        val action = unescape(f[2]) ?: return null
        val detail = unescape(f[3]) ?: return null
        if (!isHash(f[4]) || !isHash(f[5])) return null
        return Entry(seq, time, action, detail, f[4], f[5])
    }

    private fun isHash(s: String): Boolean = s.length == 64 && s.all { it in '0'..'9' || it in 'a'..'f' }

    /**
     * Checks [lines] from the first: every line must parse, its number must be the previous number + 1, its `prev` must be the previous hash and its hash must be what [hashOf] gives.
     * The FIRST line sets the anchor: when it is entry 1 its `prev` must be [GENESIS]; any other first line (the log was trimmed, see [trim]) is taken as it stands, so a trimmed log
     * still verifies from where it now begins. Empty lines are ignored.
     */
    fun verify(lines: List<String>): Verification {
        var last: Entry? = null
        var count = 0
        for (raw in lines) {
            if (raw.isEmpty()) continue
            val e = parse(raw) ?: return Verification(Status.BROKEN, count, -1L, last?.hash ?: GENESIS)
            val l = last
            val fits = if (l == null) {
                (e.seq != 1L || e.prev == GENESIS) && e.hash == hashOf(e.prev, e.seq, e.time, e.action, e.detail)
            } else {
                e.seq == l.seq + 1L && e.prev == l.hash && e.hash == hashOf(e.prev, e.seq, e.time, e.action, e.detail)
            }
            if (!fits) return Verification(Status.BROKEN, count, e.seq, l?.hash ?: GENESIS)
            last = e
            count++
        }
        return Verification(if (count == 0) Status.EMPTY else Status.OK, count, -1L, last?.hash ?: GENESIS)
    }

    /** [lines] with the oldest dropped down to [keep] once there are more than [MAX_LINES]; unchanged otherwise. */
    fun trim(lines: List<String>, keep: Int = KEEP_LINES): List<String> = if (lines.size > MAX_LINES) lines.subList(lines.size - keep, lines.size) else lines

    // ---------------------------------------------------------------------------------------
    // The file and the library watch
    // ---------------------------------------------------------------------------------------

    private val lock = Any()
    private const val FILE_NAME = "operation_log.txt"
    private const val PREFS = "operation_log"
    private const val KEY_SEEN = "seen"

    private fun file(context: Context): File = File(context.applicationContext.filesDir, FILE_NAME)

    private fun readLinesLocked(context: Context): List<String> {
        val f = file(context)
        return if (f.exists()) f.readLines().filter { it.isNotEmpty() } else emptyList()
    }

    private fun writeLocked(context: Context, lines: List<String>) {
        val f = file(context)
        val tmp = File(f.parentFile, "$FILE_NAME.tmp")
        tmp.writeText(lines.joinToString("\n") + "\n")
        if (!tmp.renameTo(f)) {
            f.writeText(tmp.readText())
            tmp.delete()
        }
    }

    /** Appends entries for [events] (action to detail) in ONE write; the time is now. */
    fun recordAll(context: Context, events: List<Pair<String, String>>) {
        if (events.isEmpty()) return
        synchronized(lock) {
            try {
                val lines = ArrayList(readLinesLocked(context))
                var last = lines.lastOrNull()?.let { parse(it) }
                val now = System.currentTimeMillis()
                for ((action, detail) in events) {
                    val entry = next(last, now, action, detail)
                    lines.add(encode(entry))
                    last = entry
                }
                writeLocked(context, trim(lines))
            } catch (e: Exception) {
                // a log that cannot be written must never stop the work it describes
            }
        }
    }

    fun record(context: Context, action: String, detail: String) = recordAll(context, listOf(Pair(action, detail)))

    /**
     * Compares the documents now in the library ([current] file names) with the ones seen last time and logs what appeared ([ACTION_CREATED]) and what went ([ACTION_REMOVED], which is also
     * what moving to the bin looks like). The very first call only logs a [ACTION_BASELINE] with the number of files, so the files that were already there are not all "created".
     * More than [MAX_INDIVIDUAL] at once become one summary entry whose detail is the count.
     */
    fun syncLibrary(context: Context, current: Set<String>) = synchronized(lock) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val seen = prefs.getStringSet(KEY_SEEN, null)
        if (seen == null) {
            record(context, ACTION_BASELINE, current.size.toString())
            prefs.edit().putStringSet(KEY_SEEN, HashSet(current)).apply()
            return@synchronized
        }
        val created = (current - seen).sorted()
        val removed = (seen - current).sorted()
        if (created.isEmpty() && removed.isEmpty()) return@synchronized
        val events = ArrayList<Pair<String, String>>()
        if (created.size > MAX_INDIVIDUAL) {
            events.add(Pair(ACTION_CREATED, created.size.toString() + " files"))
        } else {
            for (n in created) events.add(Pair(ACTION_CREATED, n))
        }
        if (removed.size > MAX_INDIVIDUAL) {
            events.add(Pair(ACTION_REMOVED, removed.size.toString() + " files"))
        } else {
            for (n in removed) events.add(Pair(ACTION_REMOVED, n))
        }
        recordAll(context, events)
        prefs.edit().putStringSet(KEY_SEEN, HashSet(current)).apply()
    }

    /** Every line of the file, as written (for [verify]); empty when there is no log. */
    fun readLines(context: Context): List<String> = synchronized(lock) { readLinesLocked(context) }

    /** The entries that parse, oldest first. */
    fun read(context: Context): List<Entry> = readLines(context).mapNotNull { parse(it) }

    /** Deletes the log and forgets which files were seen (the next sync starts a new chain with a baseline). */
    fun clear(context: Context) {
        synchronized(lock) {
            runCatching { file(context).delete() }
            context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        }
    }
}
