package com.example.docscanner.util

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import java.io.File
import kotlin.math.ceil
import kotlin.math.floor

/**
 * REAL redaction: hides parts of pages so that what is underneath is gone from the file, not merely covered.
 *
 * Drawing a black rectangle over a PDF page leaves the text under it in the file - anyone can select, copy or extract it
 * (tools/verify/redact_check.py shows this next to the real thing). PDFBox cannot reliably remove the text under an area, so the only
 * safe method is the blunt one: every page that has at least one redaction is rendered to a picture, the black boxes are painted
 * INTO the picture, and the page is replaced by that picture - the original text, fonts and objects of the page are not in the new
 * file at all. Pages without redactions are copied unchanged. The price, said on the screen: a redacted page is an image (its text is no
 * longer selectable or searchable) and bookmarks/forms/metadata of the source are not carried over.
 *
 * Positions are fractions of the page AS DISPLAYED (left, top, right, bottom, 0..1), the same convention as [PdfStamper]. Writes a NEW
 * file; the input is only read.
 */
object PdfRedactor {

    const val DEFAULT_DPI = 200f

    /** Pixel box `[left, top, right, bottom]` of fractions [f] on a [w] x [h] picture: rounded outwards, clamped, at least 1 pixel. Pure. */
    fun pixelRect(f: FloatArray, w: Int, h: Int): IntArray {
        val l = floor(minOf(f[0], f[2]).coerceIn(0f, 1f) * w).toInt().coerceIn(0, w - 1)
        val t = floor(minOf(f[1], f[3]).coerceIn(0f, 1f) * h).toInt().coerceIn(0, h - 1)
        val r = ceil(maxOf(f[0], f[2]).coerceIn(0f, 1f) * w).toInt().coerceIn(l + 1, w)
        val b = ceil(maxOf(f[1], f[3]).coerceIn(0f, 1f) * h).toInt().coerceIn(t + 1, h)
        return intArrayOf(l, t, r, b)
    }

    /**
     * @param rectsByPage 0-based page -> boxes (fractions, see above); pages not in the map are copied unchanged.
     * @return the number of pages that were replaced by pictures.
     */
    fun redact(src: File, out: File, rectsByPage: Map<Int, List<FloatArray>>, dpi: Float = DEFAULT_DPI): Int {
        val srcDoc = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
        var session: PdfPageBitmap.Session? = null
        val outDoc = PDDocument()
        try {
            if (srcDoc.isEncrypted) throw IllegalStateException("encrypted")
            val pages = srcDoc.numberOfPages
            session = PdfPageBitmap.open(src) ?: throw IllegalStateException("unreadable")
            val paint = Paint().apply { color = Color.BLACK; style = Paint.Style.FILL }
            var replaced = 0
            for (i in 0 until pages) {
                val rects = rectsByPage[i]
                if (rects.isNullOrEmpty()) {
                    outDoc.importPage(srcDoc.getPage(i))      // the source stays open until the new file is saved
                    continue
                }
                val geo = PdfPageGeometry.of(srcDoc.getPage(i))
                val widthPx = (geo.displayWidth * dpi / 72f).toInt().coerceIn(200, 3000)
                val bmp = session.render(i, widthPx) ?: throw IllegalStateException("render failed")
                try {
                    val canvas = Canvas(bmp)
                    for (r in rects) {
                        val px = pixelRect(r, bmp.width, bmp.height)
                        canvas.drawRect(px[0].toFloat(), px[1].toFloat(), px[2].toFloat(), px[3].toFloat(), paint)
                    }
                    val page = PDPage(PDRectangle(geo.displayWidth, geo.displayHeight))
                    outDoc.addPage(page)
                    PDPageContentStream(outDoc, page).use { cs ->
                        cs.drawImage(LosslessFactory.createFromImage(outDoc, bmp), 0f, 0f, geo.displayWidth, geo.displayHeight)
                    }
                } finally {
                    bmp.recycle()
                }
                replaced++
            }
            PdfStructureOptimizer.save(outDoc, out)
            if (!PdfVerify.opensAsPdf(out, pages)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
            return replaced
        } catch (e: Throwable) {
            runCatching { out.delete() }
            throw e
        } finally {
            runCatching { session?.close() }
            runCatching { outDoc.close() }
            runCatching { srcDoc.close() }
        }
    }
}
