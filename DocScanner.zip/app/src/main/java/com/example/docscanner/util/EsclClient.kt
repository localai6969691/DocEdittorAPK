package com.example.docscanner.util

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL

/**
 * eSCL client over plain HttpURLConnection (phiên 17, mục 4.31): reads a scanner's capabilities and runs one scan job, handing every page to a callback as soon as it
 * arrives. Protocol rules are in [EsclProtocol]. Behaviour worth knowing:
 *  - it refuses any host that is not on the local network ([EsclProtocol.isPrivateAddress]; a hostname must resolve ONLY to such addresses);
 *  - 503 on `NextDocument` means "busy / warming up" - it waits [retryDelayMs] and asks again, for at most [maxWaitMs] in total, then gives up;
 *  - 404 on `NextDocument` is the NORMAL end of the job (a flatbed returns it right after its one page); 404 before any page is an error;
 *  - the job is always deleted at the end (best effort), also after an error; the job URL is the `Location` header as given;
 *  - pages are capped ([maxPages]) and each page body is capped ([MAX_PAGE_BYTES]) so a misbehaving device cannot fill the phone.
 * Mirrored in tools/verify/EsclCheck.java and tested against a mock scanner (escl_check.py). NOT yet run against a real scanner.
 */
class EsclClient(private val base: String, private val retryDelayMs: Long = 1000, private val maxWaitMs: Long = 60_000, private val sleeper: (Long) -> Unit = { Thread.sleep(it) }) {

    class EsclException(val code: String, message: String) : IOException(message)

    companion object {
        const val MAX_PAGE_BYTES = 120L * 1024 * 1024
        const val CONNECT_TIMEOUT_MS = 8000
        const val READ_TIMEOUT_MS = 120_000
    }

    class Response(val code: Int, val location: String?, val body: ByteArray)

    private fun checkLocal(url: String) {
        val host = URL(url).host.removePrefix("[").removeSuffix("]")
        val addresses = try { InetAddress.getAllByName(host) } catch (e: Exception) { throw EsclException("unreachable", "cannot resolve $host") }
        if (addresses.isEmpty() || !addresses.all { EsclProtocol.isPrivateAddress(it) }) throw EsclException("not_local", "$host is not on the local network")
    }

    private fun call(method: String, url: String, body: ByteArray? = null, contentType: String? = null): Response {
        checkLocal(url)
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = CONNECT_TIMEOUT_MS
            c.readTimeout = READ_TIMEOUT_MS
            c.instanceFollowRedirects = false
            if (body != null) {
                c.doOutput = true
                if (contentType != null) c.setRequestProperty("Content-Type", contentType)
                c.outputStream.use { it.write(body) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val out = ByteArrayOutputStream()
            if (stream != null) {
                stream.use { s ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = s.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        if (out.size() > MAX_PAGE_BYTES) throw EsclException("too_big", "response too large")
                    }
                }
            }
            return Response(code, c.getHeaderField("Location"), out.toByteArray())
        } finally {
            c.disconnect()
        }
    }

    fun capabilities(): EsclProtocol.Capabilities {
        val r = call("GET", "$base/ScannerCapabilities")
        if (r.code != 200) throw EsclException("http_${r.code}", "capabilities returned ${r.code}")
        return try { EsclProtocol.parseCapabilities(String(r.body, Charsets.UTF_8)) } catch (e: Exception) { throw EsclException("bad_xml", "unreadable capabilities") }
    }

    /** Runs one job; [onPage] gets (0-based index, page bytes). @return the number of pages received. */
    fun scan(settings: EsclProtocol.Settings, maxPages: Int = 100, onPage: (Int, ByteArray) -> Unit): Int {
        val postUrl = "$base/ScanJobs"
        val post = call("POST", postUrl, EsclProtocol.scanSettingsXml(settings).toByteArray(Charsets.UTF_8), "text/xml")
        if (post.code == 503) throw EsclException("busy", "scanner is busy")
        if (post.code != 201 && post.code != 200 && post.code != 202) throw EsclException("http_${post.code}", "job refused (${post.code})")
        val job = EsclProtocol.resolveLocation(postUrl, post.location) ?: throw EsclException("no_location", "no Location header")
        checkLocal(job)
        var pages = 0
        try {
            var waited = 0L
            while (pages < maxPages) {
                val r = call("GET", "$job/NextDocument")
                when {
                    r.code == 200 -> { onPage(pages, r.body); pages++; waited = 0 }
                    r.code == 404 -> {
                        if (pages == 0) throw EsclException("no_pages", "scanner returned no page")
                        break
                    }
                    r.code == 503 -> {
                        if (waited >= maxWaitMs) throw EsclException("busy", "scanner stayed busy")
                        sleeper(retryDelayMs); waited += retryDelayMs
                    }
                    else -> throw EsclException("http_${r.code}", "page request returned ${r.code}")
                }
            }
        } finally {
            try { call("DELETE", job) } catch (e: Exception) { /* best effort */ }
        }
        return pages
    }
}
