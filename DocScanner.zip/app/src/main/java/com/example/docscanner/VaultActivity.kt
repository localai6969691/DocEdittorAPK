package com.example.docscanner

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityVaultBinding
import com.example.docscanner.util.AppLock
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.VaultStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * "Két an toàn" (phiên 17): documents encrypted on the device ([VaultStore] / [VaultCrypto]). The screen asks for the phone's biometric / screen lock each time it opens when one
 * is set up ([AppLock.authenticate]); screenshots and the recent-apps thumbnail are blocked (FLAG_SECURE); files opened for viewing are decrypted into the cache and wiped when
 * the screen closes. Move a document in from the history list ("Thêm tài liệu"), take it back out ("Lấy ra"), open it, or delete it.
 */
class VaultActivity : BaseActivity() {

    private lateinit var binding: ActivityVaultBinding
    private var items: List<VaultStore.Item> = emptyList()
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        binding = ActivityVaultBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.vault_title)
        binding.lvVault.setOnItemClickListener { _, _, position, _ -> items.getOrNull(position)?.let { if (!busy) askAction(it) } }
        binding.btnVaultAdd.setOnClickListener { if (!busy) askWhatToAdd() }
        binding.lvVault.visibility = View.INVISIBLE
        binding.btnVaultAdd.isEnabled = false
        if (AppLock.isSupported(this)) {
            AppLock.authenticate(this, getString(R.string.vault_unlock)) { ok -> if (ok) unlocked() else finish() }
        } else {
            unlocked()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        VaultStore.clearTemp(this)
    }

    private fun unlocked() {
        binding.btnVaultAdd.isEnabled = true
        refresh()
    }

    private fun setBusy(value: Boolean) {
        busy = value
        binding.btnVaultAdd.isEnabled = !value
    }

    private fun refresh() {
        setBusy(true)
        lifecycleScope.launch {
            items = withContext(Dispatchers.IO) { runCatching { VaultStore.list(this@VaultActivity) }.getOrDefault(emptyList()) }
            val labels = items.map { (it.name ?: getString(R.string.vault_unreadable)) + "  ·  " + android.text.format.Formatter.formatShortFileSize(this@VaultActivity, it.size) }
            binding.lvVault.adapter = ArrayAdapter(this@VaultActivity, android.R.layout.simple_list_item_1, labels)
            binding.lvVault.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
            binding.tvVaultEmpty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
            setBusy(false)
        }
    }

    private fun askAction(item: VaultStore.Item) {
        val actions = ArrayList<Pair<String, () -> Unit>>()
        if (item.name != null) {
            actions.add(getString(R.string.vault_open) to { openItem(item) })
            actions.add(getString(R.string.vault_take_out) to { takeOut(item) })
        }
        actions.add(getString(R.string.vault_delete) to { confirmDelete(item) })
        AlertDialog.Builder(this)
            .setTitle(item.name ?: getString(R.string.vault_unreadable))
            .setItems(actions.map { it.first }.toTypedArray()) { _, which -> actions[which].second() }
            .show()
    }

    private fun openItem(item: VaultStore.Item) {
        setBusy(true)
        lifecycleScope.launch {
            val plain = withContext(Dispatchers.IO) { VaultStore.openTemp(this@VaultActivity, item) }
            setBusy(false)
            if (plain == null) {
                Toast.makeText(this@VaultActivity, R.string.vault_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            val uri = FileProvider.getUriForFile(this@VaultActivity, "$packageName.fileprovider", plain)
            val view = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, FileUtils.mimeTypeFor(plain))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try { startActivity(view) } catch (e: Exception) { Toast.makeText(this@VaultActivity, R.string.barcode_no_app, Toast.LENGTH_LONG).show() }
        }
    }

    private fun takeOut(item: VaultStore.Item) {
        setBusy(true)
        lifecycleScope.launch {
            val out = withContext(Dispatchers.IO) { VaultStore.takeOut(item, PdfExporter.exportDir(this@VaultActivity)) }
            setBusy(false)
            if (out == null) Toast.makeText(this@VaultActivity, R.string.vault_failed, Toast.LENGTH_LONG).show()
            else Toast.makeText(this@VaultActivity, getString(R.string.vault_taken_out, out.name), Toast.LENGTH_LONG).show()
            refresh()
        }
    }

    private fun confirmDelete(item: VaultStore.Item) {
        AlertDialog.Builder(this)
            .setMessage(getString(R.string.vault_delete_confirm, item.name ?: getString(R.string.vault_unreadable)))
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.dialog_yes) { _, _ ->
                lifecycleScope.launch {
                    withContext(Dispatchers.IO) { VaultStore.wipe(item.file) }
                    refresh()
                }
            }
            .show()
    }

    /** Pick documents from the history folder (PDF, ebooks, text...; the OCR .txt sidecar of a PDF is wiped with it, since it holds the same text in the clear). */
    private fun askWhatToAdd() {
        val dir = PdfExporter.exportDir(this)
        val files = (dir.listFiles { f -> f.isFile && !f.name.startsWith(".") } ?: emptyArray())
            .filter { f -> !(f.extension.equals("txt", true) && File(dir, f.nameWithoutExtension + ".pdf").exists()) }
            .sortedByDescending { it.lastModified() }
        if (files.isEmpty()) {
            Toast.makeText(this, R.string.vault_nothing_to_add, Toast.LENGTH_LONG).show()
            return
        }
        val checked = BooleanArray(files.size)
        AlertDialog.Builder(this)
            .setTitle(R.string.vault_add_title)
            .setMultiChoiceItems(files.map { it.name }.toTypedArray(), checked) { _, which, isChecked -> checked[which] = isChecked }
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.vault_add) { _, _ -> addFiles(files.filterIndexed { i, _ -> checked[i] }) }
            .show()
    }

    private fun addFiles(files: List<File>) {
        if (files.isEmpty()) return
        setBusy(true)
        lifecycleScope.launch {
            val moved = withContext(Dispatchers.IO) {
                files.count { f ->
                    val sidecar = File(f.parentFile, f.nameWithoutExtension + ".txt")
                    val ok = VaultStore.add(this@VaultActivity, f) != null
                    if (ok && f.extension.equals("pdf", true) && sidecar.isFile) VaultStore.wipe(sidecar)
                    ok
                }
            }
            setBusy(false)
            Toast.makeText(this@VaultActivity, getString(R.string.vault_added, moved, files.size), Toast.LENGTH_LONG).show()
            refresh()
        }
    }
}
