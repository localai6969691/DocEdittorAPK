package com.example.docscanner.util

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay

/**
 * How a failed step of a long job should be treated (PDF "Thieu gi de ban app" 2.9 file locked by another app, 2.10 out of storage, 2.11 lost connection;
 * TECHNICAL_DOCS.md 4.63):
 *  - [TRANSIENT]: worth trying again in a moment (file busy / locked, provider hiccup, interrupted call);
 *  - [DISK_FULL]: no point in going on - every following file would fail the same way, so the queue stops and says why;
 *  - [PERMANENT]: this file cannot be processed (wrong password, damaged, out of memory): report it and go on with the next.
 */
enum class TaskFailure { TRANSIENT, DISK_FULL, PERMANENT }

/**
 * Pure rules (no Android) for [TaskFailure] and the retry schedule; `tools/verify/BatchQueueCheck.java` is a line-by-line Java copy that
 * `batch_queue_check.py` runs against an independent Python model, so the table below cannot drift from what is tested.
 */
object TaskFailures {
    const val MAX_ATTEMPTS = 3
    const val BASE_DELAY_MS = 400L
    const val MAX_DELAY_MS = 3000L

    // Markers are matched against the LOWER-CASED exception message; Android / Linux errors reach us as text ("open failed: EBUSY (Device or resource busy)").
    private val DISK_FULL_MARKERS = listOf("enospc", "no space left", "not enough space", "disk full", "edquot", "quota exceeded")
    private val TRANSIENT_MARKERS = listOf(
        "ebusy", "text file busy", "resource busy", "being used by another", "eagain", "try again",
        "temporarily unavailable", "eintr", "interrupted system call", "estale", "stale file"
    )
    private val TRANSIENT_CLASSES = listOf("deadobjectexception", "interruptedioexception")
    private val PERMANENT_CLASSES = listOf("invalidpasswordexception", "outofmemoryerror")

    /** [chain] = (class name, message) of the exception and of each cause, outermost first. Priority: DISK_FULL anywhere, then PERMANENT class, then TRANSIENT, else PERMANENT. */
    fun classify(chain: List<Pair<String, String?>>): TaskFailure {
        for ((_, message) in chain) {
            val m = (message ?: "").lowercase()
            if (DISK_FULL_MARKERS.any { m.contains(it) }) return TaskFailure.DISK_FULL
        }
        for ((className, _) in chain) {
            val c = className.lowercase()
            if (PERMANENT_CLASSES.any { c.contains(it) }) return TaskFailure.PERMANENT
        }
        for ((className, message) in chain) {
            val c = className.lowercase()
            val m = (message ?: "").lowercase()
            if (TRANSIENT_CLASSES.any { c.contains(it) } || TRANSIENT_MARKERS.any { m.contains(it) }) return TaskFailure.TRANSIENT
        }
        return TaskFailure.PERMANENT
    }

    fun classify(t: Throwable): TaskFailure {
        val chain = ArrayList<Pair<String, String?>>()
        var current: Throwable? = t
        while (current != null && chain.size < 8) {
            chain.add(Pair(current.javaClass.name, current.message))
            current = if (current.cause === current) null else current.cause
        }
        return classify(chain)
    }

    /** [attempt] counts from 1 (the attempt that just failed). Only transient failures are retried, at most [MAX_ATTEMPTS] attempts in total. */
    fun shouldRetry(kind: TaskFailure, attempt: Int): Boolean = kind == TaskFailure.TRANSIENT && attempt < MAX_ATTEMPTS

    /** Wait before attempt number attempt + 1: 400 ms, 800 ms, 1600 ms ... never above [MAX_DELAY_MS]. */
    fun delayMs(attempt: Int): Long {
        val shift = (attempt - 1).coerceIn(0, 10)
        return minOf(MAX_DELAY_MS, BASE_DELAY_MS shl shift)
    }

    /**
     * Runs [block]; a transient failure is retried after a short wait, anything else is thrown at once. Coroutine cancellation is NEVER swallowed
     * (a cancelled job must stop, not retry).
     */
    suspend fun <T> retrying(block: suspend () -> T): T {
        var attempt = 1
        while (true) {
            try {
                return block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (!shouldRetry(classify(e), attempt)) throw e
                delay(delayMs(attempt))
                attempt++
            }
        }
    }
}

/**
 * The sequential queue behind "one operation on many files" (PDF F4 task queue; 4.63): files are taken ONE at a time, each ends in exactly one final
 * state, and [stop] (the Stop button, or a full disk) cancels everything not yet started while the file in progress is allowed to finish.
 * Invariant (checked by `batch_queue_check.py` on thousands of random scripts against an independent model): the six counts always add up to [total].
 */
class BatchQueue(val total: Int) {

    enum class State { QUEUED, RUNNING, DONE, FAILED, SKIPPED, STOPPED }

    private val states = Array(maxOf(0, total)) { State.QUEUED }

    @Volatile var stopped = false
        private set

    /** Index of the next file to process, now marked RUNNING; -1 when nothing is left to start (all started, or [stop] was called). */
    @Synchronized fun next(): Int {
        if (stopped) return -1
        for (i in states.indices) {
            if (states[i] == State.QUEUED) {
                states[i] = State.RUNNING
                return i
            }
        }
        return -1
    }

    @Synchronized fun done(i: Int) = finish(i, State.DONE)

    @Synchronized fun failed(i: Int) = finish(i, State.FAILED)

    @Synchronized fun skipped(i: Int) = finish(i, State.SKIPPED)

    /** Only a RUNNING file can finish; anything else (unknown index, finished twice) is ignored so the counts stay consistent. */
    private fun finish(i: Int, to: State) {
        if (i >= 0 && i < states.size && states[i] == State.RUNNING) states[i] = to
    }

    /** Cancels every file not yet started; the one in progress (if any) is left to finish. Calling it again changes nothing. */
    @Synchronized fun stop() {
        stopped = true
        for (i in states.indices) {
            if (states[i] == State.QUEUED) states[i] = State.STOPPED
        }
    }

    @Synchronized fun count(s: State): Int = states.count { it == s }
}
