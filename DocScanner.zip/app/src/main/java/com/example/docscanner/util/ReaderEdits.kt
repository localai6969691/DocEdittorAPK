package com.example.docscanner.util

/**
 * The edits made on a page INSIDE the PDF reader's toolbar (session 23, 4.61), kept until the person saves them as a new PDF. Nothing here touches the PDF: the reader
 * shows the marks over the page, and on "Save a copy" hands them to the same writers the full screens use (PdfTextMarkup, PdfRedactor, PdfStamper).
 * Plain Kotlin on numbers, mirrored by tools/verify/ReaderLogicCheck.java. Every box is `[x0, y0, x1, y1]` as fractions 0..1 of the DISPLAYED page, measured from the TOP-LEFT.
 */
class ReaderEdits {

    enum class Kind { HIGHLIGHT, UNDERLINE, STRIKE, BLACKBOX, TEXT }

    /** [text] is set for [Kind.TEXT] only. */
    class Item(val kind: Kind, val page: Int, val box: FloatArray, val text: String? = null)

    private val list = ArrayList<Item>()

    val items: List<Item> get() = list
    val count: Int get() = list.size

    fun isEmpty(): Boolean = list.isEmpty()

    /** Past [MAX_ITEMS] a new mark is refused (a runaway drag cannot grow without limit). */
    fun add(item: Item): Boolean {
        if (list.size >= MAX_ITEMS) return false
        list.add(item)
        return true
    }

    /** Removes and returns the most recent mark, or null when there is none. */
    fun undo(): Item? = if (list.isEmpty()) null else list.removeAt(list.size - 1)

    fun clear() = list.clear()

    fun on(page: Int): List<Item> = list.filter { it.page == page }

    companion object {
        const val MAX_ITEMS = 500

        /** A drag shorter than this fraction of the page (either side) is a tap, not a frame. */
        const val MIN_SIDE = 0.01f

        /**
         * A drag from (ax, ay) to (bx, by) in view pixels on a page view of [width] x [height] pixels -> a box in 0..1: corners put in order (any drag direction),
         * clamped to the page, null when it is only a tap or the view has no size.
         */
        fun frame(ax: Float, ay: Float, bx: Float, by: Float, width: Float, height: Float): FloatArray? {
            if (width <= 0f || height <= 0f) return null
            val x0 = (minOf(ax, bx) / width).coerceIn(0f, 1f)
            val x1 = (maxOf(ax, bx) / width).coerceIn(0f, 1f)
            val y0 = (minOf(ay, by) / height).coerceIn(0f, 1f)
            val y1 = (maxOf(ay, by) / height).coerceIn(0f, 1f)
            if (x1 - x0 < MIN_SIDE || y1 - y0 < MIN_SIDE) return null
            return floatArrayOf(x0, y0, x1, y1)
        }

        /**
         * The box of a text stamp placed by a tap at (x, y) view pixels: centred on the tap, [widthFraction] of the page wide (kept between 5% and 90%), as tall as the
         * stamp picture's [aspect] (width / height) makes it, shrunk if it would be taller than the page, and moved inward so it never hangs over an edge.
         */
        fun stampBox(x: Float, y: Float, width: Float, height: Float, widthFraction: Float, aspect: Float): FloatArray? {
            if (width <= 0f || height <= 0f || aspect <= 0.01f) return null
            var bw = widthFraction.coerceIn(0.05f, 0.9f)
            var bh = (bw * width / aspect) / height
            if (bh > 1f) {
                bh = 1f
                bw = bh * height * aspect / width
            }
            val cx = (x / width).coerceIn(0f, 1f)
            val cy = (y / height).coerceIn(0f, 1f)
            val x0 = (cx - bw / 2f).coerceIn(0f, 1f - bw)
            val y0 = (cy - bh / 2f).coerceIn(0f, 1f - bh)
            return floatArrayOf(x0, y0, x0 + bw, y0 + bh)
        }
    }
}
