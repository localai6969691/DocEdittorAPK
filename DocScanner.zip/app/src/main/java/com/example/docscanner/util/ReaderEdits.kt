package com.example.docscanner.util

/**
 * The edits made on a page INSIDE the PDF reader's toolbar (session 23, 4.61), kept until the person saves them as a new PDF. Nothing here touches the PDF: the reader
 * shows the marks over the page, and on "Save a copy" hands them to the same writers the full screens use (PdfTextMarkup, PdfRedactor, PdfStamper).
 * Plain Kotlin on numbers, mirrored by tools/verify/ReaderLogicCheck.java. Every box is `[x0, y0, x1, y1]` as fractions 0..1 of the DISPLAYED page, measured from the TOP-LEFT.
 */
class ReaderEdits {

    /** ERASER is a TOOL only (it removes the mark under the finger, see [hit] and [erase]); no [Item] ever has that kind. */
    enum class Kind { HIGHLIGHT, UNDERLINE, STRIKE, BLACKBOX, TEXT, PEN, MARKER, EDITTEXT, FORM, ERASER }

    /**
     * [text] is set for [Kind.TEXT] only; [points] (x0, y0, x1, y1, ... as fractions of the page) for [Kind.PEN] and [Kind.MARKER], whose [box] is then the box around them;
     * [color] is an ARGB int used by every kind that is drawn in a colour of the person's choice: since 4.69 that includes the highlight and the marker, which are no longer
     * always yellow (they START yellow, see [defaultColor], and then follow the colour picked for them).
     * [width] is the thickness of a [Kind.PEN] / [Kind.MARKER] stroke as a fraction of the page WIDTH (4.72); 0 = the tool's usual thickness.
     * [name] and [text] are set for [Kind.FORM] only: the fully qualified name of a form field and the value typed for it ("true" / "false" for a check box); [box] is where its widget sits (4.71).
     * [chunk] is set for [Kind.EDITTEXT] only: the number of the existing piece of text (see PdfTextEditor.TextChunk.index) whose words [text] replaces; [box] is where that piece sits.
     */
    class Item(
        val kind: Kind,
        val page: Int,
        val box: FloatArray,
        val text: String? = null,
        val points: FloatArray? = null,
        val color: Int = DEFAULT_COLOR,
        val chunk: Int = -1,
        val name: String? = null,
        val width: Float = 0f,
        /** Items made by ONE drag over several lines share a non-zero group (see [newGroup]) and are undone together; 0 = a single mark. */
        val group: Int = 0
    )

    private val list = ArrayList<Item>()

    /** One step of history, so Undo and Redo can walk it both ways (4.72): a mark added, a mark replaced by a newer one of the same piece / field, marks erased. */
    private sealed class Change {
        class Added(val item: Item) : Change()
        class Replaced(val index: Int, val before: Item, val after: Item) : Change()
        /** [removed] = (position in the list at the time, the mark), positions ascending. */
        class Erased(val removed: List<Pair<Int, Item>>) : Change()
    }

    private val undoStack = ArrayList<Change>()
    private val redoStack = ArrayList<Change>()

    val items: List<Item> get() = list
    val count: Int get() = list.size

    fun isEmpty(): Boolean = list.isEmpty()

    /** True when [redo] has something to put back (a new mark, or [clear], empties it). */
    fun canRedo(): Boolean = redoStack.isNotEmpty()

    /** Past [MAX_ITEMS] a new mark is refused (a runaway drag cannot grow without limit). */
    fun add(item: Item): Boolean {
        // editing the same piece of text again replaces the earlier edit of it (only the last wording is written into the copy); a form field filled again keeps only its last value
        val at = when (item.kind) {
            Kind.EDITTEXT -> list.indexOfFirst { it.kind == Kind.EDITTEXT && it.page == item.page && it.chunk == item.chunk }
            Kind.FORM -> list.indexOfFirst { it.kind == Kind.FORM && it.page == item.page && it.name == item.name }
            else -> -1
        }
        if (at >= 0) {
            undoStack.add(Change.Replaced(at, list[at], item))
            list[at] = item
            redoStack.clear()
            return true
        }
        if (list.size >= MAX_ITEMS) return false
        list.add(item)
        undoStack.add(Change.Added(item))
        redoStack.clear()
        return true
    }

    private var groupCounter = 0

    /** A new group number for the marks of one drag (4.67): Undo then takes back the WHOLE selection, not one line of it. */
    fun newGroup(): Int {
        groupCounter++
        return groupCounter
    }

    /** Takes [change] back from the list and returns a mark it touched (for the page to redraw). */
    private fun revert(change: Change): Item? = when (change) {
        is Change.Added -> {
            val at = list.indexOfLast { it === change.item }
            if (at >= 0) list.removeAt(at)
            change.item
        }
        is Change.Replaced -> {
            if (change.index in list.indices) list[change.index] = change.before
            change.before
        }
        is Change.Erased -> {
            for ((index, item) in change.removed) list.add(minOf(index, list.size), item)
            change.removed.firstOrNull()?.second
        }
    }

    /** Does [change] again (Redo). */
    private fun reapply(change: Change): Item? = when (change) {
        is Change.Added -> {
            if (list.size < MAX_ITEMS) list.add(change.item)
            change.item
        }
        is Change.Replaced -> {
            if (change.index in list.indices) list[change.index] = change.after
            change.after
        }
        is Change.Erased -> {
            for ((_, item) in change.removed) {
                val at = list.indexOfFirst { it === item }
                if (at >= 0) list.removeAt(at)
            }
            change.removed.firstOrNull()?.second
        }
    }

    /**
     * Takes back the most recent step and returns a mark it touched, or null when there is nothing to undo. A step that is one of the marks of a group (one drag over several lines)
     * takes the whole group with it; an erase is taken back by putting the marks where they were. What is taken back can be put back with [redo] until a new mark is made.
     */
    fun undo(): Item? {
        val top = undoStack.lastOrNull() ?: return null
        val group = if (top is Change.Added) top.item.group else 0
        var touched: Item? = null
        do {
            val change = undoStack.removeAt(undoStack.size - 1)
            touched = revert(change)
            redoStack.add(change)
            val next = undoStack.lastOrNull()
            val again = group != 0 && next is Change.Added && next.item.group == group
        } while (again)
        return touched
    }

    /** Puts back what [undo] took back (the whole group when it was one), or returns null when there is nothing to redo. */
    fun redo(): Item? {
        val top = redoStack.lastOrNull() ?: return null
        val group = if (top is Change.Added) top.item.group else 0
        var touched: Item? = null
        do {
            val change = redoStack.removeAt(redoStack.size - 1)
            touched = reapply(change)
            undoStack.add(change)
            val next = redoStack.lastOrNull()
            val again = group != 0 && next is Change.Added && next.item.group == group
        } while (again)
        return touched
    }

    /** The LATEST mark on [page] that a touch at (x, y) (fractions of the page) lands on, see [touches]; null when none. */
    fun hit(page: Int, x: Float, y: Float, radius: Float = ERASE_RADIUS): Item? {
        for (i in list.indices.reversed()) {
            val item = list[i]
            if (item.page == page && touches(item, x, y, radius)) return item
        }
        return null
    }

    /** Removes [item] and the other marks of its group (the lines of one selection), as ONE step that [undo] puts back; returns how many marks went (0 when it is not in the list). */
    fun erase(item: Item): Int {
        val at = list.indexOfFirst { it === item }
        if (at < 0) return 0
        val gone = ArrayList<Pair<Int, Item>>()
        for ((i, m) in list.withIndex()) {
            if (m === item || (item.group != 0 && m.group == item.group)) gone.add(Pair(i, m))
        }
        for ((_, m) in gone.reversed()) {
            val i = list.indexOfFirst { it === m }
            if (i >= 0) list.removeAt(i)
        }
        undoStack.add(Change.Erased(gone))
        redoStack.clear()
        return gone.size
    }

    fun clear() {
        list.clear()
        undoStack.clear()
        redoStack.clear()
    }

    fun on(page: Int): List<Item> = list.filter { it.page == page }

    companion object {
        const val MAX_ITEMS = 500

        /** The tools that mark TEXT (selected like text, by a drag along the lines): highlight, underline, strike-out. The black box stays a rectangle; the pen and marker draw. */
        fun isTextMark(kind: Kind?): Boolean = kind == Kind.HIGHLIGHT || kind == Kind.UNDERLINE || kind == Kind.STRIKE

        /** Red, the colour a mark has until the person picks another. */
        val DEFAULT_COLOR: Int = 0xFFD91A1A.toInt()

        /** Yellow: where the highlight and the marker START (a highlighter is yellow); the person can pick any colour of [PALETTE] for them (4.69). */
        val MARKER_COLOR: Int = 0xFFFFEB3B.toInt()

        /** The colours offered by the colour button: red, orange, yellow, green, blue, purple, pink, black. */
        val PALETTE: IntArray = intArrayOf(
            0xFFD91A1A.toInt(), 0xFFF57C00.toInt(), 0xFFFFEB3B.toInt(), 0xFF2E7D32.toInt(),
            0xFF1976D2.toInt(), 0xFF7B1FA2.toInt(), 0xFFE91E63.toInt(), 0xFF000000.toInt()
        )

        /** The colour a tool has until a colour is picked for it: yellow for the highlight and the marker, red for the rest. */
        fun defaultColor(kind: Kind?): Int = if (kind == Kind.HIGHLIGHT || kind == Kind.MARKER) MARKER_COLOR else DEFAULT_COLOR

        /** How close to a mark (fraction of the page) a touch of the eraser still lands on it. */
        const val ERASE_RADIUS = 0.015f

        /** The thicknesses offered for the pen and the marker, as multiples of their usual width: thin, usual, thick (4.72). */
        val WIDTH_FACTORS: FloatArray = floatArrayOf(0.5f, 1f, 2f)

        /** Distance from (px, py) to the segment (ax, ay)-(bx, by). */
        internal fun segmentDistance(px: Float, py: Float, ax: Float, ay: Float, bx: Float, by: Float): Float {
            val dx = bx - ax
            val dy = by - ay
            val lengthSquared = dx * dx + dy * dy
            val t = if (lengthSquared <= 0f) 0f else (((px - ax) * dx + (py - ay) * dy) / lengthSquared).coerceIn(0f, 1f)
            val cx = ax + t * dx
            val cy = ay + t * dy
            val ex = px - cx
            val ey = py - cy
            return kotlin.math.sqrt(ex * ex + ey * ey)
        }

        /** Whether a touch at (x, y) lands on [item]: within [radius] (plus half the thickness) of a pen / marker line, or inside the mark's box grown by [radius] for every other kind. */
        fun touches(item: Item, x: Float, y: Float, radius: Float): Boolean {
            val pts = item.points
            if ((item.kind == Kind.PEN || item.kind == Kind.MARKER) && pts != null && pts.size >= 2) {
                val reach = radius + item.width / 2f
                if (pts.size == 2) return segmentDistance(x, y, pts[0], pts[1], pts[0], pts[1]) <= reach
                var i = 0
                while (i + 3 < pts.size) {
                    if (segmentDistance(x, y, pts[i], pts[i + 1], pts[i + 2], pts[i + 3]) <= reach) return true
                    i += 2
                }
                return false
            }
            val b = item.box
            return x >= b[0] - radius && x <= b[2] + radius && y >= b[1] - radius && y <= b[3] + radius
        }

        /** `[minX, minY, maxX, maxY]` of x, y pairs; an empty list gives an empty box at the origin. */
        fun boundsOf(points: FloatArray): FloatArray {
            if (points.size < 2) return floatArrayOf(0f, 0f, 0f, 0f)
            var minX = points[0]; var maxX = points[0]; var minY = points[1]; var maxY = points[1]
            var i = 2
            while (i + 1 < points.size) {
                minX = minOf(minX, points[i]); maxX = maxOf(maxX, points[i])
                minY = minOf(minY, points[i + 1]); maxY = maxOf(maxY, points[i + 1])
                i += 2
            }
            return floatArrayOf(minX, minY, maxX, maxY)
        }

        /** A drag shorter than this fraction of the page (either side) is a tap, not a frame. */
        const val MIN_SIDE = 0.01f

        /**
         * A drag from (ax, ay) to (bx, by) in view pixels on a page view of [width] x [height] pixels -> a box in 0..1: corners put in order (any drag direction),
         * clamped to the page, null when it is only a tap or the view has no size.
         */
        fun frame(ax: Float, ay: Float, bx: Float, by: Float, width: Float, height: Float): FloatArray? {
            if (width <= 0f || height <= 0f) return null
            val x0 = (minOf(ax, bx) / width).coerceIn(0f, 1f)
            val x1 = (maxOf(ax, bx) / width).coerceIn(0f, 1f)
            val y0 = (minOf(ay, by) / height).coerceIn(0f, 1f)
            val y1 = (maxOf(ay, by) / height).coerceIn(0f, 1f)
            if (x1 - x0 < MIN_SIDE || y1 - y0 < MIN_SIDE) return null
            return floatArrayOf(x0, y0, x1, y1)
        }

        /**
         * The box of a text stamp placed by a tap at (x, y) view pixels: centred on the tap, [widthFraction] of the page wide (kept between 5% and 90%), as tall as the
         * stamp picture's [aspect] (width / height) makes it, shrunk if it would be taller than the page, and moved inward so it never hangs over an edge.
         */
        fun stampBox(x: Float, y: Float, width: Float, height: Float, widthFraction: Float, aspect: Float): FloatArray? {
            if (width <= 0f || height <= 0f || aspect <= 0.01f) return null
            var bw = widthFraction.coerceIn(0.05f, 0.9f)
            var bh = (bw * width / aspect) / height
            if (bh > 1f) {
                bh = 1f
                bw = bh * height * aspect / width
            }
            val cx = (x / width).coerceIn(0f, 1f)
            val cy = (y / height).coerceIn(0f, 1f)
            val x0 = (cx - bw / 2f).coerceIn(0f, 1f - bw)
            val y0 = (cy - bh / 2f).coerceIn(0f, 1f - bh)
            return floatArrayOf(x0, y0, x0 + bw, y0 + bh)
        }
    }
}
