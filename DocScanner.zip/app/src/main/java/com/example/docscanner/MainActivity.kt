package com.example.docscanner

import android.app.ProgressDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.core.widget.doAfterTextChanged
import com.example.docscanner.adapter.HistoryAdapter
import com.example.docscanner.databinding.ActivityMainBinding
import com.example.docscanner.model.PendingCropQueue
import com.example.docscanner.model.ScanPage
import com.example.docscanner.model.ScanSessionManager
import com.example.docscanner.util.CompressOptionsDialog
import com.example.docscanner.util.AppShortcuts
import com.example.docscanner.util.CrashLog
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.IncomingFile
import com.example.docscanner.util.ImageProcessor
import com.example.docscanner.util.PdfCompressor
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfImportHelper
import com.example.docscanner.util.OcrHelper
import com.example.docscanner.util.PdfObjectRecompressor
import com.example.docscanner.util.PdfSecurityTools
import com.example.docscanner.util.SearchablePdfBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : BaseActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var historyAdapter: HistoryAdapter
    private var importingDialog: ProgressDialog? = null
    /** Which of the 3 compression approaches the user picked in [showCompressMethodPicker], kept
     *  as this small local enum (rather than reusing [PdfCompressor.TextCompressionMethod]
     *  directly) since DIRECT_EDIT doesn't correspond to a `PdfCompressor` method at all - it
     *  routes to `PdfObjectRecompressor` instead. See [compressExistingPdf]'s doc comment. */
    private enum class CompressChoice { SAFE, G4, DIRECT_EDIT }
    private var pendingCompressionMethod = CompressChoice.SAFE

    // "Open or add a file": the manual way in, for when a drag from a file manager does not work (4.60). One PDF -> the reader, several -> the batch menu, pictures -> a scan session.
    private val openFilesPicker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) handleIncomingUris(uris, openInReader = true)
        }

    // Voice search (PDF list I2): the SYSTEM speech recogniser does the listening, so the app needs no microphone permission; the text lands in the history search box,
    // whose text watcher filters the list. See TECHNICAL_DOCS.md 4.52.
    private val voiceSearchLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val heard = result.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
                if (!heard.isNullOrBlank()) binding.etHistorySearch.setText(heard.trim())
            }
        }

    private val galleryPicker =
        registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(20)) { uris ->
            if (uris.isNotEmpty()) importGalleryImages(uris)
        }

    private val scanPdfPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { importPdfForScanning(it) }
        }

    /** The PDF an attachment is being added to while the system file picker is open (see [addAttachmentTo]). */
    private var pendingAttachmentPdf: File? = null

    private val attachmentPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val target = pendingAttachmentPdf
            pendingAttachmentPdf = null
            if (uri != null && target != null) addAttachmentTo(target, uri)
        }

    /** The PDF waiting to be signed while the person picks a .p12 / .pfx certificate file (see [importCertificateFile]). */
    private var pendingSignUri: Uri? = null

    private val certificatePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val target = pendingSignUri
            if (uri != null && target != null) importCertificateFile(uri, target) else pendingSignUri = null
        }

    /** The photo being taken by the system camera for "Translate a photo" (see [startSnapTranslate]). */
    private var snapFile: File? = null

    private val snapLauncher =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { taken ->
            val photo = snapFile
            if (taken && photo != null) readSnap(photo) else photo?.delete()
        }

    private val watchFolderPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri?.let { setWatchFolder(it) }
        }

    /** True while the "new files in the watched folder" dialog is up, so that onResume never stacks a second one. */
    private var watchDialogShown = false

    private val scanArchivePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { importArchiveForScanning(it) }
        }

    private val einkPdfPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { importPdfForEink(it) }
        }

    /** The EPUB whose cover is being replaced while the system image picker is open (see [applyEpubCover]). */
    private var pendingCoverEpub: File? = null

    private val epubCoverPicker =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            val target = pendingCoverEpub
            pendingCoverEpub = null
            if (uri != null && target != null) applyEpubCover(target, uri)
        }

    private var searchableScript = OcrHelper.OcrScript.LATIN

    private val searchablePdfPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { makeSearchablePdf(it) }
        }

    private var pendingIdPreset = com.example.docscanner.util.IdCardComposer.Preset.ID1
    private var pendingIdFront: Uri? = null

    private val idFrontPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                pendingIdFront = uri
                askIdCardBack()
            }
        }

    private val idBackPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val front = pendingIdFront
            if (uri != null && front != null) runIdCard(listOf(front, uri))
        }

    private var pendingCompareOld: Uri? = null

    private val compareOldPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                pendingCompareOld = uri
                Toast.makeText(this, R.string.compare_pick_new, Toast.LENGTH_SHORT).show()
                compareNewPicker.launch(arrayOf("application/pdf"))
            }
        }

    private val compareNewPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val old = pendingCompareOld
            if (uri != null && old != null) runCompare(old, uri)
        }

    private val batchPicker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) showBatchMenu(uris)
        }

    private val imposePdfPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { showImposeMenu(it) }
        }

    private val backupCreator =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
            uri?.let { runBackup(it) }
        }

    /** The folder of the scheduled backup (a Storage Access Framework tree; its permission is kept, so no storage permission is needed). */
    private val autoBackupFolderPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri?.let { onAutoBackupFolder(it) }
        }

    private val restorePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { runRestore(it) }
        }

    private val securityPdfPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { showSecurityMenu(it) }
        }

    private val compressPdfPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            uri?.let { compressExistingPdf(it) }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        runCatching { com.example.docscanner.util.AutoBackup.ensureScheduled(this) }   // scheduled backup: register the job if it is on and not yet registered

        historyAdapter = HistoryAdapter(
            onClick = { file -> openHistoryFile(file) },
            onShare = { file -> shareFile(file) },
            onPrint = { file -> com.example.docscanner.util.PdfPrintAdapter.print(this, file) },
            onDelete = { file -> confirmDeleteHistoryFile(file) },
            onToggleFavorite = { file ->
                com.example.docscanner.util.FavoriteStore.toggle(this, file)
                renderHistory()
            },
            isFavorite = { file -> file.name in historyFavorites },
            onLongClick = { file -> showHistoryItemMenu(file) }
        )
        binding.rvHistory.layoutManager = LinearLayoutManager(this)
        binding.rvHistory.adapter = historyAdapter
        historyAdapter.onSelectionChanged = { updateSelectionTitle() }
        binding.btnHistorySelect.setOnClickListener { startSelection(null) }
        binding.btnHistoryTrash.setOnClickListener { showTrashDialog() }
        binding.btnHistoryCleanup.setOnClickListener { showCleanupDialog() }
        binding.btnHistoryPrivate.setOnClickListener { showPrivateModeDialog() }
        setupHistorySearchAndSort()

        binding.cardToolProject.setOnClickListener {
            startActivity(Intent(this, ProjectHubActivity::class.java))
        }
        binding.cardToolScan.setOnClickListener { showScanSourcePicker() }
        binding.cardToolMerge.setOnClickListener {
            startActivity(Intent(this, PdfMergeActivity::class.java))
        }
        binding.cardToolPageManager.setOnClickListener {
            startActivity(Intent(this, PdfPageEditorActivity::class.java))
        }
        binding.cardToolEink.setOnClickListener {
            einkPdfPicker.launch(arrayOf("application/pdf"))
        }
        binding.cardToolEbook.setOnClickListener {
            ScanSessionManager.clear()
            startActivity(Intent(this, EbookExportActivity::class.java))
        }
        binding.cardToolCompress.setOnClickListener {
            showCompressMethodPicker()
        }
        binding.cardToolConvert.setOnClickListener {
            startActivity(Intent(this, ConvertDocumentActivity::class.java))
        }
        binding.cardToolAnnotate.setOnClickListener {
            startActivity(Intent(this, PdfAnnotateActivity::class.java))
        }
        setupAppLockSwitch()
        binding.cardToolIdCard.setOnClickListener { showIdCardPresetMenu() }
        binding.cardToolCompare.setOnClickListener {
            Toast.makeText(this, R.string.compare_pick_old, Toast.LENGTH_SHORT).show()
            compareOldPicker.launch(arrayOf("application/pdf"))
        }
        binding.cardToolBatch.setOnClickListener { batchPicker.launch(arrayOf("application/pdf")) }
        binding.cardToolImpose.setOnClickListener { imposePdfPicker.launch(arrayOf("application/pdf")) }
        binding.cardToolQr.setOnClickListener { showQrKindDialog() }
        binding.cardToolBackup.setOnClickListener { showBackupDialog() }
        binding.cardToolForm.setOnClickListener {
            startActivity(Intent(this, PdfFormActivity::class.java))
        }
        setupCollapsibleGroups()
        setupPdfDrop()
        binding.btnOpenFile.setOnClickListener { openFilesPicker.launch(arrayOf("application/pdf", "image/*")) }
        // the Wi-Fi scanner card exists only when the manifest declares INTERNET (see WifiScanActivity.isAvailable)
        binding.cardToolWifi.visibility = if (WifiScanActivity.isAvailable(this)) View.VISIBLE else View.GONE
        binding.cardToolWifi.setOnClickListener {
            startActivity(Intent(this, WifiScanActivity::class.java))
        }
        binding.cardToolLink.setOnClickListener { showLinkImportMenu() }
        binding.cardToolSnap.setOnClickListener { startSnapTranslate() }
        binding.cardToolVault.setOnClickListener {
            startActivity(Intent(this, VaultActivity::class.java))
        }
        binding.cardToolBarcode.setOnClickListener {
            startActivity(Intent(this, BarcodeScanActivity::class.java))
        }
        binding.cardToolMarkup.setOnClickListener {
            startActivity(Intent(this, PdfMarkupActivity::class.java))
        }
        binding.cardToolRedact.setOnClickListener {
            startActivity(Intent(this, PdfRedactActivity::class.java))
        }
        binding.cardToolSign.setOnClickListener {
            startActivity(Intent(this, PdfSignActivity::class.java))
        }
        binding.cardToolDecorate.setOnClickListener {
            startActivity(Intent(this, PdfDecorateActivity::class.java))
        }
        binding.cardToolTextEdit.setOnClickListener {
            startActivity(Intent(this, PdfTextEditActivity::class.java))
        }
        binding.cardToolSecurity.setOnClickListener {
            securityPdfPicker.launch(arrayOf("application/pdf"))
        }
        binding.cardToolSearchable.setOnClickListener {
            askOcrScript { searchablePdfPicker.launch(arrayOf("application/pdf")) }
        }
        binding.tvLanguageLink.setOnClickListener { showLanguageDialog() }
        binding.tvWebhook.setOnClickListener { showWebhookDialog() }
        updateWebhookRow()
        binding.tvTextSize.setOnClickListener { showTextSizeDialog() }
        updateTextSizeRow()
        binding.tvHelpLink.setOnClickListener {
            startActivity(Intent(this, HelpActivity::class.java))
        }
        binding.tvLicensesLink.setOnClickListener {
            startActivity(Intent(this, LicensesActivity::class.java))
        }
        AppShortcuts.publish(this)
        if (savedInstanceState == null) {
            handleIncomingIntent(intent)
            handleShortcutIntent(intent)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
        handleShortcutIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        applyPrivateModeIndicator()   // the person must always SEE that private mode is on, also after the app was restarted
        refreshHistory()
        checkWatchFolder()
        if (!offerCrashReport()) maybeOfferSessionRestore()
    }

    /** If a previous process left an unfinished, unexported scan session on disk (killed by the
     *  OS, crashed, phone restarted...) and this process doesn't already have one active in
     *  memory, ask whether to pick it back up instead of silently losing it. */
    /** ML Kit reads one script family per recognizer: ask which one, then run [then]. */
    private fun askOcrScript(then: () -> Unit) {
        val scripts = OcrHelper.OcrScript.values()
        val labels = arrayOf(
            getString(R.string.ocr_script_latin), getString(R.string.ocr_script_chinese), getString(R.string.ocr_script_japanese),
            getString(R.string.ocr_script_korean), getString(R.string.ocr_script_devanagari), getString(R.string.ocr_script_cyrillic)
        )
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.ocr_script_title)
            .setItems(labels) { _, which ->
                val chosen = scripts[which]
                if (chosen == OcrHelper.OcrScript.CYRILLIC && !com.example.docscanner.util.TesseractOcr.isReady(this)) {
                    // ML Kit has no Cyrillic model: that script is read by Tesseract, whose ~4 MB data is fetched once, with the person's consent.
                    offerCyrillicDownload { searchableScript = chosen; then() }
                } else {
                    searchableScript = chosen
                    then()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** Asks before the one-time download of the Tesseract Russian data (privacy: nothing is fetched without a yes), then runs [onReady]. */
    private fun offerCyrillicDownload(onReady: () -> Unit) {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.ocr_script_cyrillic)
            .setMessage(R.string.ocr_cyr_download_ask)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val progress = androidx.appcompat.app.AlertDialog.Builder(this)
                    .setMessage(R.string.ocr_cyr_downloading)
                    .setCancelable(false)
                    .create()
                progress.show()
                lifecycleScope.launch {
                    val ok = com.example.docscanner.util.TesseractOcr.download(this@MainActivity)
                    progress.dismiss()
                    if (ok) onReady()
                    else android.widget.Toast.makeText(this@MainActivity, R.string.ocr_cyr_download_failed, android.widget.Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /**
     * "Open with" / "Share" from another app (manifest filters on this activity). One PDF -> a list of tools to hand it to;
     * several PDFs -> the batch menu; pictures -> straight into a scan session. The intent is replaced afterwards so that a
     * rotation or a return to this screen does not ask again.
     */
    private fun handleIncomingIntent(incoming: Intent?) {
        val action = incoming?.action ?: return
        if (action == PdfReaderActivity.ACTION_PDF_TOOLS) {
            // from the reader's Edit button: the tools for the PDF it is showing; the reader stays underneath (REORDER_TO_FRONT), Back returns to it
            val path = incoming.getStringExtra(PdfReaderActivity.EXTRA_PDF_PATH)
            val name = incoming.getStringExtra(PdfReaderActivity.EXTRA_TITLE)
            setIntent(Intent(this, MainActivity::class.java))
            if (path != null && File(path).isFile) showPdfTools(File(path), name)
            return
        }
        if (action != Intent.ACTION_VIEW && action != Intent.ACTION_SEND && action != Intent.ACTION_SEND_MULTIPLE) return
        val uris = IncomingFile.urisOf(incoming)
        setIntent(Intent(this, MainActivity::class.java))
        // "Open with" (VIEW) means "read it": the in-app reader, whose Edit button holds the tools. "Share" (SEND) means "do something with it": the tool list.
        handleIncomingUris(uris, openInReader = action == Intent.ACTION_VIEW)
    }

    /**
     * The type of a file a sender handed over. The type the sender DECLARES is used when it is specific; when it is missing, a wildcard or application/octet-stream
     * (file managers and drags differ) the first bytes decide ([IncomingFile.sniffType]), so no per-app list is needed.
     */
    private fun resolveMime(uri: Uri): String? {
        val declared = contentResolver.getType(uri)
        if (declared != null && declared != "application/octet-stream" && !declared.contains('*')) return declared
        val sniffed = try {
            contentResolver.openInputStream(uri)?.use { input ->
                val head = ByteArray(16)
                val n = input.read(head)
                if (n > 0) IncomingFile.sniffType(head.copyOf(n)) else null
            }
        } catch (e: Exception) {
            null
        }
        return sniffed ?: declared
    }

    /** Shared by [handleIncomingIntent], a drop on the main screen ([setupPdfDrop]) and the "Open a file" button. */
    private fun handleIncomingUris(uris: List<Uri>, openInReader: Boolean) {
        if (uris.isEmpty()) return
        val kind = IncomingFile.classify(uris.map { resolveMime(it) }, uris.map { IncomingFile.displayName(this, it) })
        when (kind) {
            IncomingFile.Kind.PDF -> if (openInReader) openPdfReaderUri(uris[0]) else showIncomingPdfMenu(uris[0])
            IncomingFile.Kind.PDF_MANY -> showBatchMenu(uris)
            IncomingFile.Kind.IMAGES -> importGalleryImages(uris)
            IncomingFile.Kind.UNSUPPORTED -> Toast.makeText(this, R.string.incoming_unsupported, Toast.LENGTH_LONG).show()
        }
    }

    /** A launcher shortcut (see [AppShortcuts]) opens its tool right away. */
    private fun handleShortcutIntent(incoming: Intent?) {
        val action = incoming?.action ?: return
        if (action !in AppShortcuts.ALL_ACTIONS) return
        setIntent(Intent(this, MainActivity::class.java))
        when (action) {
            AppShortcuts.ACTION_SCAN -> showScanSourcePicker()
            AppShortcuts.ACTION_PROJECT -> startActivity(Intent(this, ProjectHubActivity::class.java))
            AppShortcuts.ACTION_SEARCHABLE -> askOcrScript { searchablePdfPicker.launch(arrayOf("application/pdf")) }
            AppShortcuts.ACTION_SIGN -> startActivity(Intent(this, PdfSignActivity::class.java))
        }
    }

    private fun showIncomingPdfMenu(uri: Uri) {
        val entries: List<Pair<Int, () -> Unit>> = listOf(
            R.string.incoming_page_manager to { openPdfIn(PdfPageEditorActivity::class.java, uri) },
            R.string.incoming_searchable to { askOcrScript { makeSearchablePdf(uri) } },
            R.string.incoming_compress to { showCompressMethodPicker(uri) },
            R.string.incoming_security to { showSecurityMenu(uri) },
            R.string.incoming_sign to { openPdfIn(PdfSignActivity::class.java, uri) },
            R.string.incoming_form to { openPdfIn(PdfFormActivity::class.java, uri) },
            R.string.incoming_annotate to { openPdfIn(PdfAnnotateActivity::class.java, uri) },
            R.string.incoming_markup to { openPdfIn(PdfMarkupActivity::class.java, uri) },
            R.string.incoming_redact to { openPdfIn(PdfRedactActivity::class.java, uri) },
            R.string.incoming_decorate to { openPdfIn(PdfDecorateActivity::class.java, uri) },
            R.string.incoming_impose to { showImposeMenu(uri) },
            R.string.incoming_scan to { importPdfForScanning(uri) },
            R.string.incoming_print to { printIncomingPdf(uri) }
        )
        val name = IncomingFile.displayName(this, uri) ?: getString(R.string.incoming_name_unknown)
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.incoming_title, name))
            .setItems(entries.map { getString(it.first) }.toTypedArray()) { _, which -> entries[which].second() }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** Starts a PDF screen with [uri] as its data; the screen uses it instead of opening the file picker (`pickPdfOrUseIncoming`). */
    private fun openPdfIn(screen: Class<*>, uri: Uri) {
        startActivity(Intent(this, screen).apply {
            data = uri
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        })
    }

    private fun printIncomingPdf(uri: Uri) {
        lifecycleScope.launch {
            val file = withContext(Dispatchers.IO) { copyUriToTempPdfFile(uri) }
            if (file != null) {
                com.example.docscanner.util.PdfPrintAdapter.print(this@MainActivity, file)
            } else {
                Toast.makeText(this@MainActivity, R.string.incoming_print_failed, Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * The previous run ended in a crash (see [CrashLog]): ask once whether to send the report. Returns true when the question is
     * shown, so that the "continue the last scan?" question does not appear on top of it.
     */
    private fun offerCrashReport(): Boolean {
        val report = CrashLog.latest(this) ?: return false
        AlertDialog.Builder(this)
            .setTitle(R.string.crash_prompt_title)
            .setMessage(R.string.crash_prompt_message)
            .setPositiveButton(R.string.crash_prompt_send) { _, _ ->
                CrashLog.markAsked(report)
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, getString(R.string.help_crash_subject))
                    putExtra(Intent.EXTRA_TEXT, CrashLog.reportText(this@MainActivity, report))
                }
                startActivity(Intent.createChooser(send, getString(R.string.help_crash_subject)))
            }
            .setNegativeButton(R.string.crash_prompt_skip) { _, _ -> CrashLog.markAsked(report) }
            .setOnCancelListener { CrashLog.markAsked(report) }
            .show()
        return true
    }

    private fun maybeOfferSessionRestore() {
        if (ScanSessionManager.pages.isNotEmpty()) return
        val count = ScanSessionManager.savedSessionPageCount()
        if (count <= 0) return
        AlertDialog.Builder(this)
            .setTitle(R.string.restore_session_title)
            .setMessage(getString(R.string.restore_session_message, count))
            .setCancelable(false)
            .setPositiveButton(R.string.restore_session_continue) { _, _ ->
                ScanSessionManager.restoreSavedSession()
                startActivity(Intent(this, PageListActivity::class.java))
            }
            .setNegativeButton(R.string.restore_session_discard) { _, _ ->
                ScanSessionManager.discardSavedSession()
            }
            .show()
    }

    // ---- rename / suggest a name from the first page (see util.SmartNamer) ----

    private fun showHistoryItemMenu(file: File) {
        val ext = file.extension.lowercase()
        val isPdf = ext == "pdf"
        val hasText = isPdf || ext == "txt"
        val actions = ArrayList<Pair<String, () -> Unit>>()
        actions.add(getString(R.string.history_select_more) to { startSelection(file) })
        actions.add(getString(R.string.history_action_rename) to { showRenameDialog(file, file.nameWithoutExtension) })
        actions.add(getString(R.string.history_action_tag) to { showTagDialog(file) })
        if (isPdf) actions.add(getString(R.string.history_action_suggest) to { suggestNameFromContent(file) })
        if (hasText) {
            // tapping a PDF now opens the reader; its extracted text (what a tap used to open) stays one step away
            if (isPdf) actions.add(getString(R.string.action_view_text) to { openTextResult(file) })
            actions.add(getString(R.string.history_action_read) to { readAloud(file) })
            actions.add(getString(R.string.history_action_translate) to { pickTranslateTarget(file) })
        }
        if (isPdf) actions.add(getString(R.string.history_action_word) to { exportWord(file) })
        if (isPdf) actions.add(getString(R.string.history_action_pdfa) to { exportPdfA(file) })
        if (isPdf) actions.add(getString(R.string.history_action_split_bookmarks) to { splitAtBookmarks(file) })
        if (isPdf) {
            actions.add(getString(R.string.history_action_attachments) to { showAttachmentsDialog(file) })
            actions.add(getString(R.string.history_action_layers) to { showLayersDialog(file) })
            actions.add(getString(R.string.history_action_links) to { showLinksDialog(file) })
            actions.add(getString(R.string.history_action_autolinks) to { autoLinkPdf(file) })
            actions.add(getString(R.string.history_action_portfolio) to { showPortfolioDialog(file) })
            actions.add(getString(R.string.history_action_repair) to { repairPdf(file) })
            actions.add(getString(R.string.history_action_linearize) to { linearizePdf(file) })
        }
        if (ext == "epub") {
            actions.add(getString(R.string.history_action_epub_read) to { startActivity(Intent(this, EpubReaderActivity::class.java).putExtra(EpubReaderActivity.EXTRA_EPUB_PATH, file.absolutePath)) })
            actions.add(getString(R.string.history_action_epub_meta) to { showEpubMetaDialog(file) })
            actions.add(getString(R.string.history_action_epub_cover) to { pendingCoverEpub = file; epubCoverPicker.launch("image/*") })
            actions.add(getString(R.string.history_action_epub_split) to { showEpubSplitDialog(file) })
            actions.add(getString(R.string.history_action_epub_html) to { exportEpubText(file, true) })
            actions.add(getString(R.string.history_action_epub_md) to { exportEpubText(file, false) })
            actions.add(getString(R.string.history_action_epub_search) to { searchInEpub(file) })
        }
        if (isPdf) actions.add(getString(R.string.history_action_bookmarks) to { startActivity(Intent(this, PdfBookmarkActivity::class.java).putExtra(PdfBookmarkActivity.EXTRA_PDF_PATH, file.absolutePath)) })
        if (hasText) actions.add(getString(R.string.history_action_textformats) to { askTextFormat(file) })
        actions.add(getString(R.string.history_action_base64) to { exportBase64(file) })
        if (isPdf) {
            actions.add(getString(R.string.history_action_excel) to { exportExcel(file) })
            actions.add(getString(R.string.history_action_pptx) to { exportPowerPoint(file) })
            actions.add(getString(R.string.history_action_invoice) to { extractInvoice(file) })
            actions.add(getString(R.string.history_action_insight) to { showDocInsight(file) })
            actions.add(getString(R.string.history_action_card) to { cardToContact(file) })
        }
        showGroupedActions(file.name, actions)
    }

    private val FLAT_MENU_MAX = 8

    /** Group of each entry of the history long-press menu: 0 organize, 1 read & translate, 2 convert & export, 3 document tools, 4 extract information. */
    private val HISTORY_ACTION_GROUPS: Map<Int, Int> = mapOf(
        R.string.history_select_more to 0,
        R.string.history_action_rename to 0,
        R.string.history_action_tag to 0,
        R.string.history_action_suggest to 0,
        R.string.history_action_read to 1,
        R.string.action_view_text to 1,
        R.string.history_action_translate to 1,
        R.string.history_action_epub_read to 1,
        R.string.history_action_epub_search to 1,
        R.string.history_action_word to 2,
        R.string.history_action_pdfa to 2,
        R.string.history_action_textformats to 2,
        R.string.history_action_base64 to 2,
        R.string.history_action_excel to 2,
        R.string.history_action_pptx to 2,
        R.string.history_action_epub_html to 2,
        R.string.history_action_epub_md to 2,
        R.string.history_action_split_bookmarks to 3,
        R.string.history_action_attachments to 3,
        R.string.history_action_layers to 3,
        R.string.history_action_links to 3,
        R.string.history_action_autolinks to 3,
        R.string.history_action_portfolio to 3,
        R.string.history_action_repair to 3,
        R.string.history_action_linearize to 3,
        R.string.history_action_bookmarks to 3,
        R.string.history_action_epub_meta to 3,
        R.string.history_action_epub_cover to 3,
        R.string.history_action_epub_split to 3,
        R.string.history_action_invoice to 4,
        R.string.history_action_insight to 4,
        R.string.history_action_card to 4
    )

    /**
     * The long-press menu of a history file has up to 31 entries (4.55): above [FLAT_MENU_MAX] they are shown in 5 groups, a group picker first and then the entries of the chosen
     * group. [HISTORY_ACTION_GROUPS] maps each entry's string to its group; tools/verify/history_menu_groups_check.py fails if an entry is not listed there, so a new action
     * cannot silently end up in the wrong place. An entry missing from the map falls into the "document tools" group (index 3).
     */
    private fun showGroupedActions(
        title: String, actions: List<Pair<String, () -> Unit>>,
        groups: Map<Int, Int> = HISTORY_ACTION_GROUPS, names: IntArray = HISTORY_GROUP_NAMES, fallback: Int = 3
    ) {
        val groupOf = groups.entries.associate { getString(it.key) to it.value }
        val buckets = names.indices.map { g -> actions.filter { (groupOf[it.first] ?: fallback) == g } }
        val shown = buckets.indices.filter { buckets[it].isNotEmpty() }
        if (actions.size <= FLAT_MENU_MAX || shown.size <= 1) {
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(actions.map { it.first }.toTypedArray()) { _, which -> actions[which].second() }
                .setNegativeButton(R.string.dialog_cancel, null)
                .show()
            return
        }
        val labels = shown.map { getString(names[it]) + " (" + buckets[it].size + ")" }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(labels) { _, which ->
                val group = shown[which]
                androidx.appcompat.app.AlertDialog.Builder(this)
                    .setTitle(names[group])
                    .setItems(buckets[group].map { it.first }.toTypedArray()) { _, i -> buckets[group][i].second() }
                    .setNegativeButton(R.string.dialog_cancel, null)
                    .show()
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    // ---- tags (see util.TagStore) ----

    private fun updateTagButtonText() {
        val filter = historyTagFilter
        binding.btnHistoryTag.text = if (filter == null) getString(R.string.tag_button) else getString(R.string.tag_button_filtered, filter)
    }

    private fun showTagFilterDialog() {
        val rows = com.example.docscanner.util.TagTree.rows(historyTags)          // tags written Work/Invoices form folders (E8, E9)
        if (rows.isEmpty()) {
            Toast.makeText(this, R.string.tag_none_yet, Toast.LENGTH_LONG).show()
            return
        }
        val current = historyTagFilter
        val labels = arrayOf(getString(R.string.tag_all)) + rows.map { "    ".repeat(it.depth - 1) + it.label + " (" + it.count + ")" }
        val selected = if (current == null) 0 else rows.indexOfFirst {
            com.example.docscanner.util.TagTree.matches(it.path, current) && com.example.docscanner.util.TagTree.matches(current, it.path)
        } + 1
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.tag_filter_title)
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                historyTagFilter = if (which == 0) null else rows[which - 1].path
                renderHistory()
                dialog.dismiss()
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun showTagDialog(file: File) {
        val all = com.example.docscanner.util.TagStore.all(this)
        val mine = all[file.name] ?: emptySet()
        val known = com.example.docscanner.util.TagStore.tagCounts(all).map { it.first }.toMutableList()
        for (t in mine) if (t !in known) known.add(t)
        val names = known.toTypedArray()
        val checked = BooleanArray(names.size) { names[it] in mine }
        fun selected(): List<String> = names.filterIndexed { i, _ -> checked[i] }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.tag_dialog_title)
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton(R.string.dialog_ok) { _, _ ->
                com.example.docscanner.util.TagStore.setTags(this, file, selected())
                renderHistory()
            }
            .setNeutralButton(R.string.tag_new) { _, _ ->
                val keep = selected()
                askText(R.string.tag_new, R.string.tag_new_hint, secret = false) { name ->
                    com.example.docscanner.util.TagStore.setTags(this, file, keep + name)
                    renderHistory()
                }
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    // ---- read aloud, translate, export to Word (all start from util.PdfTextExtractor) ----

    /** Pages of text of [file] (text layer, OCR sidecar, or OCR of up to [maxOcrPages] pages) shown with a busy indicator; null/empty -> message. */
    private suspend fun loadDocumentPages(file: File, maxOcrPages: Int, scanned: BooleanArray): List<String>? {
        val pages = withContext(Dispatchers.Default) {
            com.example.docscanner.util.PdfTextExtractor.pages(file, maxOcrPages, { _, _ -> }, scanned)
        }
        if (pages == null || pages.all { it.isBlank() }) {
            Toast.makeText(this, R.string.text_none_found, Toast.LENGTH_LONG).show()
            return null
        }
        return pages
    }

    private fun readAloud(file: File) {
        setImporting(true)
        lifecycleScope.launch {
            val scanned = BooleanArray(1)
            val pages = loadDocumentPages(file, 10, scanned)
            setImporting(false)
            if (pages == null) return@launch
            val text = pages.joinToString("\n\n").trim()
            val preview = (if (scanned[0]) getString(R.string.text_from_ocr_note) + "\n\n" else "") + text.take(800) + (if (text.length > 800) "…" else "")
            var reader: com.example.docscanner.util.SpeechReader? = null
            val dialog = androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                .setTitle(R.string.read_title)
                .setMessage(preview)
                .setPositiveButton(R.string.read_play, null)
                .setNeutralButton(R.string.read_stop, null)
                .setNegativeButton(R.string.read_close, null)
                .create()
            dialog.setOnDismissListener { reader?.shutdown() }
            dialog.show()
            val play = dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE)
            play.isEnabled = false
            reader = com.example.docscanner.util.SpeechReader(this@MainActivity) { ready, vietnamese ->
                runOnUiThread {
                    play.isEnabled = ready
                    if (!ready) Toast.makeText(this@MainActivity, R.string.read_engine_missing, Toast.LENGTH_LONG).show()
                    else if (!vietnamese) Toast.makeText(this@MainActivity, R.string.read_no_vietnamese, Toast.LENGTH_LONG).show()
                }
            }
            play.setOnClickListener { reader?.speak(text) }
            dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_NEUTRAL).setOnClickListener { reader?.stop() }
        }
    }

    private fun pickTranslateTarget(file: File) {
        val targets = com.example.docscanner.util.TextTranslator.targets
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.translate_pick_target)
            .setItems(targets.map { it.second }.toTypedArray()) { _, which ->
                androidx.appcompat.app.AlertDialog.Builder(this)
                    .setMessage(R.string.translate_model_note)
                    .setNegativeButton(R.string.dialog_cancel, null)
                    .setPositiveButton(R.string.translate_continue) { _, _ -> runTranslate(file, targets[which]) }
                    .show()
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun runTranslate(file: File, target: Pair<String, String>) {
        val progress = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.history_action_translate)
            .setMessage(R.string.translate_reading)
            .setCancelable(false)
            .create()
        progress.show()
        lifecycleScope.launch {
            val scanned = BooleanArray(1)
            val pages = loadDocumentPages(file, 10, scanned)
            if (pages == null) { progress.dismiss(); return@launch }
            val text = pages.joinToString("\n\n").trim()
            val source = runCatching { com.example.docscanner.util.TextTranslator.identify(text) }.getOrNull()
            if (source == null) {
                progress.dismiss()
                Toast.makeText(this@MainActivity, R.string.translate_unknown_language, Toast.LENGTH_LONG).show()
                return@launch
            }
            if (source == target.first) {
                progress.dismiss()
                Toast.makeText(this@MainActivity, R.string.translate_same_language, Toast.LENGTH_LONG).show()
                return@launch
            }
            progress.setMessage(getString(R.string.translate_working, 0, 0))
            val result = runCatching {
                com.example.docscanner.util.TextTranslator.translate(text, source, target.first) { i, n ->
                    progress.setMessage(getString(R.string.translate_working, i, n))
                }
            }
            progress.dismiss()
            val translated = result.getOrNull()
            if (translated.isNullOrBlank()) {
                Toast.makeText(this@MainActivity, R.string.translate_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            val out = com.example.docscanner.util.SmartNamer.uniqueFile(
                PdfExporter.exportDir(this@MainActivity), file.nameWithoutExtension + "_" + target.first, "txt"
            )
            runCatching { out.writeText(translated, Charsets.UTF_8) }
            refreshHistory()
            androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                .setTitle(getString(R.string.translate_done, out.name))
                .setMessage((if (scanned[0]) getString(R.string.text_from_ocr_note) + "\n\n" else "") + translated.take(1200) + (if (translated.length > 1200) "…" else ""))
                .setPositiveButton(R.string.dialog_ok, null)
                .show()
        }
    }

    /** HTML, Markdown, JSON or XML from the text of the document (text layer or OCR), one section per page. */
    private fun askTextFormat(file: File) {
        val options = arrayOf(getString(R.string.textexport_html), getString(R.string.textexport_md), getString(R.string.textexport_json), getString(R.string.textexport_xml))
        val kinds = arrayOf("html", "md", "json", "xml")
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.textexport_title)
            .setItems(options) { _, which -> exportText(file, kinds[which]) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    /** [kind]: "html", "md", "json" or "xml" - also the extension of the file written (see util.TextExporters). */
    private fun exportText(file: File, kind: String) {
        setImporting(true)
        lifecycleScope.launch {
            val scanned = BooleanArray(1)
            val pages = loadDocumentPages(file, 30, scanned)
            if (pages == null) { setImporting(false); return@launch }
            val out = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), file.nameWithoutExtension, kind)
            val result = runCatching {
                withContext(Dispatchers.Default) {
                    val title = file.nameWithoutExtension
                    val x = com.example.docscanner.util.TextExporters
                    val text = when (kind) {
                        "html" -> x.html(title, pages)
                        "json" -> x.json(title, pages)
                        "xml" -> x.xml(title, pages)
                        else -> x.markdown(title, pages)
                    }
                    out.writeText(text, Charsets.UTF_8)
                }
            }
            setImporting(false)
            if (result.isFailure) {
                runCatching { out.delete() }
                Toast.makeText(this@MainActivity, R.string.textexport_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            refreshHistory()
            Toast.makeText(this@MainActivity, getString(R.string.textexport_done, out.name) + if (scanned[0]) "\n" + getString(R.string.text_from_ocr_note) else "", Toast.LENGTH_LONG).show()
        }
    }

    /** Any history file as Base64 text (`name.b64`, 76-character lines; PDF list L15). Streams, so a big PDF never sits in memory. */
    private fun exportBase64(file: File) {
        if (!hasRoomFor(file.length() * 4 / 3 + 1)) return
        setImporting(true)
        lifecycleScope.launch {
            val out = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), file.nameWithoutExtension, "b64")
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    file.inputStream().buffered().use { input -> out.outputStream().buffered().use { output -> com.example.docscanner.util.TextExporters.base64(input, output) } }
                }
            }
            setImporting(false)
            if (result.isFailure) {
                runCatching { out.delete() }
                Toast.makeText(this@MainActivity, R.string.textexport_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            refreshHistory()
            Toast.makeText(this@MainActivity, getString(R.string.textexport_done, out.name), Toast.LENGTH_LONG).show()
        }
    }

    /**
     * PDF -> Excel: each page is read by OCR WITH the position of every word, [com.example.docscanner.util.TableExtractor] rebuilds the
     * table from the gaps between columns, and every page that has text becomes a sheet ("Trang N"). Whole numbers become numbers; codes,
     * long digit strings and anything with separators stay text (see `XlsxWriter`). A page with no table structure gives one line of text
     * per row, and the result says so.
     */
    private fun exportExcel(file: File) {
        setImporting(true)
        lifecycleScope.launch {
            val out = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), file.nameWithoutExtension, "xlsx")
            var truncated = false
            val sheets = try {
                withContext(Dispatchers.Default) {
                    val result = ArrayList<com.example.docscanner.util.XlsxWriter.Sheet>()
                    val session = com.example.docscanner.util.PdfPageBitmap.open(file)
                    if (session != null) {
                        try {
                            val count = session.pageCount
                            truncated = count > EXPORT_TABLE_MAX_PAGES
                            for (page in 0 until minOf(count, EXPORT_TABLE_MAX_PAGES)) {
                                val bitmap = session.render(page, 2000) ?: continue
                                val lines = try {
                                    com.example.docscanner.util.OcrHelper.recognizeLines(bitmap, com.example.docscanner.util.OcrHelper.OcrScript.LATIN)
                                } finally {
                                    bitmap.recycle()
                                }
                                val words = lines.flatMap { it.words }.map {
                                    com.example.docscanner.util.TableExtractor.Word(it.text, it.box.left.toFloat(), it.box.top.toFloat(), it.box.right.toFloat(), it.box.bottom.toFloat())
                                }
                                val table = com.example.docscanner.util.TableExtractor.extract(words)
                                if (table.rows.isNotEmpty()) result.add(com.example.docscanner.util.XlsxWriter.Sheet(getString(R.string.export_page_name, page + 1), table.rows))
                            }
                        } finally {
                            session.close()
                        }
                    }
                    result
                }
            } catch (e: Exception) {
                null
            }
            if (sheets == null) {
                setImporting(false)
                Toast.makeText(this@MainActivity, R.string.excel_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            if (sheets.isEmpty()) {
                setImporting(false)
                Toast.makeText(this@MainActivity, R.string.excel_no_text, Toast.LENGTH_LONG).show()
                return@launch
            }
            val written = runCatching { withContext(Dispatchers.IO) { com.example.docscanner.util.XlsxWriter.write(sheets, out) } }
            setImporting(false)
            if (written.isFailure) {
                runCatching { out.delete() }
                Toast.makeText(this@MainActivity, R.string.excel_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            refreshHistory()
            val anyTable = sheets.any { s -> s.rows.any { it.size > 1 } }
            val note = StringBuilder(getString(R.string.excel_done, out.name, sheets.size))
            note.append('\n').append(getString(if (anyTable) R.string.excel_table_note else R.string.excel_no_table_note))
            if (truncated) note.append('\n').append(getString(R.string.export_truncated_note, EXPORT_TABLE_MAX_PAGES))
            Toast.makeText(this@MainActivity, note.toString(), Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Invoice fields (date, number, serial, tax codes, amount to pay, VAT) read from the text of the first 3 pages next to their labels
     * ([com.example.docscanner.util.InvoiceFields]); shown for checking, with copy and "save as CSV" (UTF-8 with a byte-order mark so Excel reads the accents).
     */
    private fun extractInvoice(file: File) {
        setImporting(true)
        lifecycleScope.launch {
            val scanned = BooleanArray(1)
            val pages = loadDocumentPages(file, 3, scanned)
            setImporting(false)
            if (pages == null) return@launch
            val fields = com.example.docscanner.util.InvoiceFields.extract(pages.joinToString("\n"))
            if (fields.isEmpty()) {
                androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                    .setTitle(R.string.invoice_title).setMessage(R.string.invoice_none).setPositiveButton(android.R.string.ok, null).show()
                return@launch
            }
            val rows = fields.map { f -> invoiceLabel(f.kind) to invoiceDisplay(f) }
            val body = rows.joinToString("\n") { "${it.first}: ${it.second}" }
            androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                .setTitle(R.string.invoice_title)
                .setMessage(body + "\n\n" + getString(R.string.invoice_check_note) + if (scanned[0]) "\n" + getString(R.string.text_from_ocr_note) else "")
                .setPositiveButton(R.string.invoice_copy) { _, _ ->
                    val clipboard = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("invoice", body))
                    Toast.makeText(this@MainActivity, R.string.invoice_copied, Toast.LENGTH_SHORT).show()
                }
                .setNeutralButton(R.string.invoice_save_csv) { _, _ ->
                    val out = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), file.nameWithoutExtension + "_hoadon", "csv")
                    val csv = StringBuilder("\uFEFF").append("Truong,Gia tri\r\n")
                    rows.forEach { (label, value) -> csv.append(csvCell(label)).append(',').append(csvCell(value)).append("\r\n") }
                    runCatching { out.writeText(csv.toString(), Charsets.UTF_8) }
                        .onSuccess { shareFile(out) }
                        .onFailure { Toast.makeText(this@MainActivity, R.string.textexport_failed, Toast.LENGTH_LONG).show() }
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
    }

    private fun docCategoryName(c: com.example.docscanner.util.DocInsight.Category): String = getString(
        when (c) {
            com.example.docscanner.util.DocInsight.Category.INVOICE -> R.string.insight_cat_invoice
            com.example.docscanner.util.DocInsight.Category.RECEIPT -> R.string.insight_cat_receipt
            com.example.docscanner.util.DocInsight.Category.CONTRACT -> R.string.insight_cat_contract
            com.example.docscanner.util.DocInsight.Category.ID_DOCUMENT -> R.string.insight_cat_id
            com.example.docscanner.util.DocInsight.Category.BANK_STATEMENT -> R.string.insight_cat_bank
            com.example.docscanner.util.DocInsight.Category.CERTIFICATE -> R.string.insight_cat_certificate
            com.example.docscanner.util.DocInsight.Category.RESUME -> R.string.insight_cat_resume
            com.example.docscanner.util.DocInsight.Category.OFFICIAL_LETTER -> R.string.insight_cat_letter
            com.example.docscanner.util.DocInsight.Category.FORM -> R.string.insight_cat_form
        }
    )

    /**
     * "Analyse document" ([com.example.docscanner.util.DocInsight], phiên 20): the kind of document, up to 5 tag suggestions (TF-IDF against the user's OTHER documents, taken from the
     * OCR transcripts [com.example.docscanner.util.ContentIndex] already holds) and a 3-sentence TextRank summary, all computed on the device from the first 10 pages. A suggestion, shown as one:
     * the tags are added only if the user taps "Add tags".
     */
    private fun showDocInsight(file: File) {
        setImporting(true)
        lifecycleScope.launch {
            val scanned = BooleanArray(1)
            val pages = loadDocumentPages(file, 10, scanned)
            if (pages == null) { setImporting(false); return@launch }
            val text = pages.joinToString("\n\n")
            val result = withContext(Dispatchers.Default) {
                com.example.docscanner.util.ContentIndex.warm(historyAll)
                val others = historyAll.filter { it != file }.mapNotNull { com.example.docscanner.util.ContentIndex.cached(it) }.take(200)
                Triple(
                    com.example.docscanner.util.DocInsight.classify(text),
                    com.example.docscanner.util.DocInsight.keywords(text, others, 5),
                    com.example.docscanner.util.DocInsight.summary(text, 3)
                )
            }
            setImporting(false)
            val kind = result.first
            val tags = result.second
            val summary = result.third
            val cat = kind.category
            val runnerUp = kind.runnerUp
            val body = StringBuilder()
            body.append(if (cat != null) getString(R.string.insight_kind, docCategoryName(cat)) else getString(R.string.insight_kind_unknown))
            if (runnerUp != null) body.append('\n').append(getString(R.string.insight_kind_or, docCategoryName(runnerUp)))
            body.append("\n\n").append(getString(R.string.insight_summary)).append(":\n")
            body.append(if (summary.isEmpty()) getString(R.string.insight_no_summary) else summary.joinToString("\n") { "\u2022 $it" })
            if (tags.isNotEmpty()) body.append("\n\n").append(getString(R.string.insight_tags, tags.joinToString(", ")))
            body.append("\n\n").append(getString(R.string.insight_note))
            if (scanned[0]) body.append('\n').append(getString(R.string.text_from_ocr_note))
            val builder = androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                .setTitle(R.string.insight_title)
                .setMessage(body.toString())
                .setNegativeButton(android.R.string.ok, null)
            if (tags.isNotEmpty()) builder.setPositiveButton(R.string.insight_add_tags) { _, _ -> askInsightTags(file, tags) }
            if (summary.isNotEmpty()) builder.setNeutralButton(R.string.insight_copy_summary) { _, _ ->
                val clipboard = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                clipboard.setPrimaryClip(android.content.ClipData.newPlainText("summary", summary.joinToString("\n")))
                Toast.makeText(this@MainActivity, R.string.invoice_copied, Toast.LENGTH_SHORT).show()
            }
            builder.show()
        }
    }

    /** The suggested tags, all ticked: the ones left ticked are ADDED to the tags the document already has. */
    private fun askInsightTags(file: File, tags: List<String>) {
        val names = tags.toTypedArray()
        val checked = BooleanArray(names.size) { true }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.insight_tags_title)
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton(R.string.dialog_ok) { _, _ ->
                val chosen = names.filterIndexed { i, _ -> checked[i] }
                if (chosen.isNotEmpty()) {
                    val current = com.example.docscanner.util.TagStore.all(this)[file.name] ?: emptySet()
                    com.example.docscanner.util.TagStore.setTags(this, file, (current + chosen).toList())
                    renderHistory()
                }
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun invoiceLabel(kind: com.example.docscanner.util.InvoiceFields.Kind): String = getString(
        when (kind) {
            com.example.docscanner.util.InvoiceFields.Kind.DATE -> R.string.invoice_field_date
            com.example.docscanner.util.InvoiceFields.Kind.INVOICE_NO -> R.string.invoice_field_no
            com.example.docscanner.util.InvoiceFields.Kind.SERIAL -> R.string.invoice_field_serial
            com.example.docscanner.util.InvoiceFields.Kind.TAX_ID -> R.string.invoice_field_tax
            com.example.docscanner.util.InvoiceFields.Kind.TOTAL -> R.string.invoice_field_total
            com.example.docscanner.util.InvoiceFields.Kind.VAT_RATE -> R.string.invoice_field_vat_rate
            com.example.docscanner.util.InvoiceFields.Kind.VAT_AMOUNT -> R.string.invoice_field_vat_amount
        }
    )

    /** Amounts are shown with Vietnamese separators (12.345.678), everything else as extracted. */
    private fun invoiceDisplay(f: com.example.docscanner.util.InvoiceFields.Field): String = when (f.kind) {
        com.example.docscanner.util.InvoiceFields.Kind.TOTAL, com.example.docscanner.util.InvoiceFields.Kind.VAT_AMOUNT -> try {
            val format = java.text.NumberFormat.getInstance(java.util.Locale("vi", "VN"))
            format.maximumFractionDigits = 2
            format.format(java.math.BigDecimal(f.value))
        } catch (e: Exception) {
            f.value
        }
        else -> f.value
    }

    private fun csvCell(value: String): String = "\"" + value.replace("\"", "\"\"") + "\""

    /**
     * Business card: OCR of the first page -> [com.example.docscanner.util.ContactCard.parse] -> the fields are shown, then either the system
     * "add contact" form is opened with them filled in (no permission needed: the Contacts app does the saving) or a vCard file is shared.
     */
    private fun cardToContact(file: File) {
        setImporting(true)
        lifecycleScope.launch {
            val text = withContext(Dispatchers.Default) {
                val session = com.example.docscanner.util.PdfPageBitmap.open(file) ?: return@withContext ""
                try {
                    val bitmap = session.render(0, 1600) ?: return@withContext ""
                    try { com.example.docscanner.util.OcrHelper.recognize(bitmap) } finally { bitmap.recycle() }
                } finally {
                    session.close()
                }
            }
            setImporting(false)
            val card = com.example.docscanner.util.ContactCard.parse(text)
            val rows = listOf(
                R.string.card_field_name to card.name, R.string.card_field_title to card.title, R.string.card_field_company to card.company,
                R.string.card_field_phone to card.phones.joinToString(", "), R.string.card_field_email to card.emails.joinToString(", "),
                R.string.card_field_web to card.websites.joinToString(", "), R.string.card_field_address to card.address
            ).filter { it.second.isNotEmpty() }
            if (text.isBlank() || rows.isEmpty()) {
                Toast.makeText(this@MainActivity, R.string.card_none, Toast.LENGTH_LONG).show()
                return@launch
            }
            androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                .setTitle(R.string.card_title)
                .setMessage(rows.joinToString("\n") { "${getString(it.first)}: ${it.second}" } + "\n\n" + getString(R.string.card_check_note))
                .setPositiveButton(R.string.card_add_contact) { _, _ -> openAddContact(card) }
                .setNeutralButton(R.string.card_save_vcard) { _, _ ->
                    val out = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), file.nameWithoutExtension, "vcf")
                    runCatching { out.writeBytes(com.example.docscanner.util.ContactCard.toVCard(card).toByteArray(Charsets.UTF_8)) }
                        .onSuccess { shareFile(out) }
                        .onFailure { Toast.makeText(this@MainActivity, R.string.textexport_failed, Toast.LENGTH_LONG).show() }
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
        }
    }

    private fun openAddContact(card: com.example.docscanner.util.ContactCard.Contact) {
        val intent = Intent(android.provider.ContactsContract.Intents.Insert.ACTION).apply {
            type = android.provider.ContactsContract.RawContacts.CONTENT_TYPE
            putExtra(android.provider.ContactsContract.Intents.Insert.NAME, card.name)
            putExtra(android.provider.ContactsContract.Intents.Insert.COMPANY, card.company)
            putExtra(android.provider.ContactsContract.Intents.Insert.JOB_TITLE, card.title)
            card.phones.getOrNull(0)?.let { putExtra(android.provider.ContactsContract.Intents.Insert.PHONE, it) }
            card.phones.getOrNull(1)?.let { putExtra(android.provider.ContactsContract.Intents.Insert.SECONDARY_PHONE, it) }
            card.phones.getOrNull(2)?.let { putExtra(android.provider.ContactsContract.Intents.Insert.TERTIARY_PHONE, it) }
            card.emails.getOrNull(0)?.let { putExtra(android.provider.ContactsContract.Intents.Insert.EMAIL, it) }
            card.emails.getOrNull(1)?.let { putExtra(android.provider.ContactsContract.Intents.Insert.SECONDARY_EMAIL, it) }
            card.emails.getOrNull(2)?.let { putExtra(android.provider.ContactsContract.Intents.Insert.TERTIARY_EMAIL, it) }
            if (card.address.isNotEmpty()) putExtra(android.provider.ContactsContract.Intents.Insert.POSTAL, card.address)
            if (card.websites.isNotEmpty()) putExtra(android.provider.ContactsContract.Intents.Insert.NOTES, card.websites.joinToString("\n"))
        }
        try {
            startActivity(intent)
        } catch (e: android.content.ActivityNotFoundException) {
            Toast.makeText(this, R.string.card_no_contacts_app, Toast.LENGTH_LONG).show()
        }
    }

    /** PDF -> PowerPoint: one slide per page, the page picture fitted on it (no editable text - see `PptxWriter`). */
    private fun exportPowerPoint(file: File) {
        setImporting(true)
        lifecycleScope.launch {
            val out = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), file.nameWithoutExtension, "pptx")
            var truncated = false
            val count = try {
                withContext(Dispatchers.Default) {
                    val session = com.example.docscanner.util.PdfPageBitmap.open(file) ?: return@withContext 0
                    try {
                        truncated = session.pageCount > EXPORT_SLIDES_MAX_PAGES
                        val slides = ArrayList<com.example.docscanner.util.PptxWriter.Slide>()
                        for (page in 0 until minOf(session.pageCount, EXPORT_SLIDES_MAX_PAGES)) {
                            val bitmap = session.render(page, 1600) ?: continue
                            val bytes = java.io.ByteArrayOutputStream().also { bitmap.compress(Bitmap.CompressFormat.JPEG, 85, it) }.toByteArray()
                            slides.add(com.example.docscanner.util.PptxWriter.Slide(bytes, bitmap.width, bitmap.height, getString(R.string.export_page_name, page + 1)))
                            bitmap.recycle()
                        }
                        if (slides.isNotEmpty()) com.example.docscanner.util.PptxWriter.write(slides, out)
                        slides.size
                    } finally {
                        session.close()
                    }
                }
            } catch (e: Exception) {
                0
            }
            setImporting(false)
            if (count == 0) {
                runCatching { out.delete() }
                Toast.makeText(this@MainActivity, R.string.pptx_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            refreshHistory()
            Toast.makeText(
                this@MainActivity,
                getString(R.string.pptx_done, out.name, count) + if (truncated) "\n" + getString(R.string.export_truncated_note, EXPORT_SLIDES_MAX_PAGES) else "",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun exportWord(file: File) {
        setImporting(true)
        lifecycleScope.launch {
            val scanned = BooleanArray(1)
            val pages = loadDocumentPages(file, 30, scanned)
            if (pages == null) { setImporting(false); return@launch }
            val out = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), file.nameWithoutExtension, "docx")
            val result = runCatching {
                withContext(Dispatchers.Default) {
                    val paragraphs = ArrayList<String>()
                    for ((i, page) in pages.withIndex()) {
                        if (i > 0) paragraphs.add(com.example.docscanner.util.DocxWriter.PAGE_BREAK)
                        paragraphs.addAll(com.example.docscanner.util.DocxWriter.paragraphsFromText(page))
                    }
                    com.example.docscanner.util.DocxWriter.write(paragraphs, out)
                }
            }
            setImporting(false)
            if (result.isFailure) {
                runCatching { out.delete() }
                Toast.makeText(this@MainActivity, R.string.word_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            refreshHistory()
            Toast.makeText(this@MainActivity, getString(R.string.word_done, out.name) + if (scanned[0]) "\n" + getString(R.string.text_from_ocr_note) else "", Toast.LENGTH_LONG).show()
        }
    }

    // ---- UI language (util.AppLanguages): follows the device by default, English when the device language is not one of ours; the person can pick one ----

    private fun showLanguageDialog() {
        val tags = resources.getStringArray(R.array.app_language_tags)
        val names = resources.getStringArray(R.array.app_language_names)
        val labels = arrayOf(getString(R.string.language_system_default)) + names
        val checked = com.example.docscanner.util.AppLanguages.checkedIndex(tags.toList(), com.example.docscanner.util.AppLanguages.currentTag())
        AlertDialog.Builder(this)
            .setTitle(R.string.language_title)
            .setSingleChoiceItems(labels, checked) { dialog, which ->
                dialog.dismiss()
                if (which != checked) com.example.docscanner.util.AppLanguages.apply(if (which == 0) null else tags[which - 1])   // recreates the open screens
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    // ---- private mode (util.PrivateMode): documents and projects go to a separate folder, no bin, wiped when turned off ----

    private fun showPrivateModeDialog() {
        val on = com.example.docscanner.util.PrivateMode.isOn(this)
        val count = if (on) com.example.docscanner.util.PrivateMode.count(this) else 0
        AlertDialog.Builder(this)
            .setTitle(R.string.private_title)
            .setMessage(if (on) getString(R.string.private_is_on, count) else getString(R.string.private_is_off))
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(if (on) R.string.private_turn_off else R.string.private_turn_on) { _, _ ->
                if (on) turnPrivateModeOff() else {
                    com.example.docscanner.util.PrivateMode.turnOn(this)
                    applyPrivateModeIndicator()
                    refreshHistory()
                }
            }
            .show()
    }

    private fun turnPrivateModeOff() {
        setImporting(true)
        lifecycleScope.launch {
            val gone = withContext(Dispatchers.IO) { com.example.docscanner.util.PrivateMode.turnOff(this@MainActivity) }
            // the stars / tags of private documents must not outlive them
            val names = withContext(Dispatchers.IO) { PdfExporter.exportDir(this@MainActivity).listFiles()?.map { it.name }?.toSet() ?: emptySet() }
            com.example.docscanner.util.FavoriteStore.prune(this@MainActivity, names)
            com.example.docscanner.util.TagStore.prune(this@MainActivity, names)
            setImporting(false)
            applyPrivateModeIndicator()
            refreshHistory()
            Toast.makeText(this@MainActivity, getString(R.string.private_turned_off, gone), Toast.LENGTH_LONG).show()
        }
    }

    /** The activity title (shown in the recent-apps list and toolbar) tells the person they are in private mode - it is never silent. */
    private fun applyPrivateModeIndicator() {
        title = if (com.example.docscanner.util.PrivateMode.isOn(this)) getString(R.string.app_name) + getString(R.string.private_title_suffix) else getString(R.string.app_name)
        binding.btnHistoryPrivate.text = getString(if (com.example.docscanner.util.PrivateMode.isOn(this)) R.string.private_button_on else R.string.private_button)
    }

    // ---- watch folder (util.WatchFolder): pick a folder once; on every start, NEW images / PDFs in it are offered for import ----

    private fun watchPrefs() = getSharedPreferences("watch_folder", MODE_PRIVATE)

    private fun listWatchEntries(tree: Uri): List<com.example.docscanner.util.WatchFolder.Entry> {
        val parentId = android.provider.DocumentsContract.getTreeDocumentId(tree)
        val children = android.provider.DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        val out = ArrayList<com.example.docscanner.util.WatchFolder.Entry>()
        val cols = arrayOf(
            android.provider.DocumentsContract.Document.COLUMN_DOCUMENT_ID, android.provider.DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            android.provider.DocumentsContract.Document.COLUMN_MIME_TYPE, android.provider.DocumentsContract.Document.COLUMN_LAST_MODIFIED, android.provider.DocumentsContract.Document.COLUMN_SIZE
        )
        contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val mime = c.getString(2) ?: ""
                if (mime == android.provider.DocumentsContract.Document.MIME_TYPE_DIR) continue
                out.add(com.example.docscanner.util.WatchFolder.Entry(c.getString(0), c.getString(1) ?: "", mime, if (c.isNull(3)) 0L else c.getLong(3), if (c.isNull(4)) 0L else c.getLong(4)))
            }
        }
        return out
    }

    private fun showWatchFolderDialog() {
        val current = watchPrefs().getString("uri", null)
        val b = AlertDialog.Builder(this).setTitle(R.string.watch_title).setNegativeButton(R.string.dialog_cancel, null)
        if (current == null) {
            b.setMessage(R.string.watch_help_off).setPositiveButton(R.string.watch_choose) { _, _ -> watchFolderPicker.launch(null) }
        } else {
            val name = Uri.parse(current).lastPathSegment?.substringAfterLast(':') ?: current
            b.setMessage(getString(R.string.watch_help_on, name))
                .setPositiveButton(R.string.watch_change) { _, _ -> watchFolderPicker.launch(null) }
                .setNeutralButton(R.string.watch_stop) { _, _ -> stopWatchFolder(Uri.parse(current)) }
        }
        b.show()
    }

    private fun stopWatchFolder(uri: Uri) {
        runCatching { contentResolver.releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        watchPrefs().edit().clear().apply()
        Toast.makeText(this, R.string.watch_stopped, Toast.LENGTH_SHORT).show()
    }

    private fun setWatchFolder(uri: Uri) {
        runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        setImporting(true)
        lifecycleScope.launch {
            val entries = runCatching { withContext(Dispatchers.IO) { listWatchEntries(uri) } }.getOrNull()
            setImporting(false)
            if (entries == null) {
                Toast.makeText(this@MainActivity, R.string.watch_lost, Toast.LENGTH_LONG).show()
                return@launch
            }
            // what is ALREADY in the folder is marked seen: only files that arrive from now on are offered
            val seen = com.example.docscanner.util.WatchFolder.remember(emptyList(), entries.map { it.id })
            watchPrefs().edit().putString("uri", uri.toString()).putString("seen", com.example.docscanner.util.WatchFolder.encode(seen)).apply()
            Toast.makeText(this@MainActivity, getString(R.string.watch_set, entries.size), Toast.LENGTH_LONG).show()
        }
    }

    private fun checkWatchFolder() {
        val uriStr = watchPrefs().getString("uri", null) ?: return
        if (watchDialogShown) return
        val tree = Uri.parse(uriStr)
        lifecycleScope.launch {
            val entries = runCatching { withContext(Dispatchers.IO) { listWatchEntries(tree) } }.getOrNull()
            if (entries == null) {   // folder deleted or permission revoked: stop quietly instead of failing on every start
                watchPrefs().edit().clear().apply()
                Toast.makeText(this@MainActivity, R.string.watch_lost, Toast.LENGTH_LONG).show()
                return@launch
            }
            val seen = com.example.docscanner.util.WatchFolder.decode(watchPrefs().getString("seen", null))
            val fresh = com.example.docscanner.util.WatchFolder.pick(entries, seen.toSet(), System.currentTimeMillis())
            if (fresh.isEmpty() || isFinishing) return@launch
            val images = fresh.count { com.example.docscanner.util.WatchFolder.kindOf(it) == com.example.docscanner.util.WatchFolder.Kind.IMAGE }
            watchDialogShown = true
            AlertDialog.Builder(this@MainActivity)
                .setTitle(R.string.watch_new_title)
                .setMessage(getString(R.string.watch_new_message, fresh.size, images, fresh.size - images))
                .setPositiveButton(R.string.watch_import) { _, _ -> watchDialogShown = false; importWatched(tree, fresh) }
                .setNeutralButton(R.string.watch_skip) { _, _ -> watchDialogShown = false; markWatchSeen(fresh.map { it.id }) }
                .setNegativeButton(R.string.watch_later) { _, _ -> watchDialogShown = false }
                .setOnCancelListener { watchDialogShown = false }
                .show()
        }
    }

    private fun markWatchSeen(ids: Collection<String>) {
        val seen = com.example.docscanner.util.WatchFolder.decode(watchPrefs().getString("seen", null))
        watchPrefs().edit().putString("seen", com.example.docscanner.util.WatchFolder.encode(com.example.docscanner.util.WatchFolder.remember(seen, ids))).apply()
    }

    /** Images go to the same crop queue as gallery photos; PDFs are copied into the document list. Only files that were really imported are marked seen (a failed one is offered again). */
    private fun importWatched(tree: Uri, items: List<com.example.docscanner.util.WatchFolder.Entry>) {
        if (!hasRoomFor(items.sumOf { it.size })) return
        setImporting(true)
        lifecycleScope.launch {
            val imagePaths = ArrayList<String>(); var pdfs = 0; val done = ArrayList<String>()
            withContext(Dispatchers.IO) {
                var index = 0
                for (e in items) {
                    val uri = android.provider.DocumentsContract.buildDocumentUriUsingTree(tree, e.id)
                    try {
                        when (com.example.docscanner.util.WatchFolder.kindOf(e)) {
                            com.example.docscanner.util.WatchFolder.Kind.IMAGE -> {
                                val file = FileUtils.newImportedFile(this@MainActivity, index++)
                                contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(file).use { input.copyTo(it) } } ?: throw java.io.IOException("khong mo duoc")
                                imagePaths.add(file.absolutePath)
                            }
                            com.example.docscanner.util.WatchFolder.Kind.PDF -> {
                                val base = com.example.docscanner.util.SmartNamer.sanitize(e.name.substringBeforeLast('.')).ifEmpty { "pdf" }
                                val file = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), base, "pdf")
                                contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(file).use { input.copyTo(it) } } ?: throw java.io.IOException("khong mo duoc")
                                pdfs++
                            }
                            null -> continue
                        }
                        done.add(e.id)
                    } catch (_: Exception) { /* leave it unseen: offered again next time */ }
                }
            }
            setImporting(false)
            markWatchSeen(done)
            refreshHistory()
            if (imagePaths.isNotEmpty()) startCropQueue(imagePaths)
            else Toast.makeText(this@MainActivity, getString(R.string.watch_imported, pdfs, done.size - pdfs), Toast.LENGTH_LONG).show()
        }
    }

    // ---- storage clean-up: size report + duplicate finder (util.StorageTools); duplicates go to the bin, not straight to oblivion ----

    private fun showCleanupDialog() {
        setImporting(true)
        lifecycleScope.launch {
            val dir = PdfExporter.exportDir(this@MainActivity)
            val rep = withContext(Dispatchers.IO) {
                val files = com.example.docscanner.util.StorageTools.visibleFiles(dir)
                com.example.docscanner.util.StorageTools.report(files, 5)
            }
            setImporting(false)
            if (rep.fileCount == 0) {
                Toast.makeText(this@MainActivity, R.string.cleanup_empty, Toast.LENGTH_LONG).show()
                return@launch
            }
            fun size(b: Long) = android.text.format.Formatter.formatShortFileSize(this@MainActivity, b)
            val sb = StringBuilder(getString(R.string.cleanup_summary, rep.fileCount, size(rep.totalBytes)))
            for ((cat, v) in rep.byCategory.entries.sortedByDescending { it.value.second }) {
                sb.append("\n").append(getString(R.string.cleanup_category_line, getString(categoryLabel(cat)), v.first, size(v.second)))
            }
            sb.append("\n\n").append(getString(R.string.cleanup_biggest))
            for (f in rep.biggest) sb.append("\n").append(getString(R.string.cleanup_biggest_line, f.name, size(f.length())))
            AlertDialog.Builder(this@MainActivity)
                .setTitle(R.string.cleanup_title)
                .setMessage(sb.toString())
                .setNegativeButton(R.string.cleanup_close, null)
                .setNeutralButton(R.string.watch_button) { _, _ -> showWatchFolderDialog() }
                .setPositiveButton(R.string.cleanup_find_duplicates) { _, _ -> findDuplicatesDialog() }
                .show()
        }
    }

    private fun categoryLabel(cat: String): Int = when (cat) {
        "pdf" -> R.string.cleanup_cat_pdf
        "epub" -> R.string.cleanup_cat_epub
        "text" -> R.string.cleanup_cat_text
        "office" -> R.string.cleanup_cat_office
        "image" -> R.string.cleanup_cat_image
        else -> R.string.cleanup_cat_other
    }

    private fun findDuplicatesDialog() {
        setImporting(true)
        lifecycleScope.launch {
            val dir = PdfExporter.exportDir(this@MainActivity)
            val groups = withContext(Dispatchers.IO) {
                com.example.docscanner.util.StorageTools.findDuplicates(com.example.docscanner.util.StorageTools.visibleFiles(dir))
            }
            setImporting(false)
            if (groups.isEmpty()) {
                Toast.makeText(this@MainActivity, R.string.cleanup_no_duplicates, Toast.LENGTH_LONG).show()
                return@launch
            }
            // the OLDEST file of each group is kept; the newer copies are the candidates and start ticked (they only go to the bin, 30 days)
            val candidates = ArrayList<File>()
            val labels = ArrayList<String>()
            for (g in groups) for (copy in g.drop(1)) {
                candidates.add(copy)
                labels.add(getString(R.string.cleanup_duplicate_item, copy.name, android.text.format.Formatter.formatShortFileSize(this@MainActivity, copy.length()), g[0].name))
            }
            val checked = BooleanArray(candidates.size) { true }
            AlertDialog.Builder(this@MainActivity)
                .setTitle(getString(R.string.cleanup_duplicates_title, groups.size))
                .setMultiChoiceItems(labels.toTypedArray(), checked) { _, which, isChecked -> checked[which] = isChecked }
                .setNegativeButton(R.string.dialog_cancel, null)
                .setPositiveButton(R.string.cleanup_move_to_trash) { _, _ ->
                    val picked = candidates.filterIndexed { i, _ -> checked[i] }
                    if (picked.isEmpty()) Toast.makeText(this@MainActivity, R.string.selection_none, Toast.LENGTH_SHORT).show() else moveToTrash(picked)
                }
                .show()
        }
    }

    // ---- PDF inner structure: attachments, layers (OCG), links (util.PdfStructureTools) - every change is written to a COPY ----

    private fun <T> pdfStructureTask(file: File, work: () -> T, failRes: Int = R.string.pdf_structure_failed, done: (T) -> Unit) {
        setImporting(true)
        lifecycleScope.launch {
            val result = runCatching { withContext(Dispatchers.IO) { work() } }
            setImporting(false)
            result.fold(
                onSuccess = { done(it) },
                onFailure = {
                    val msg = if (it is IllegalStateException) it.message else null
                    val res = when (msg) {
                        "encrypted" -> R.string.pdf_structure_encrypted
                        "no attachments" -> R.string.portfolio_needs_attachments
                        else -> failRes
                    }
                    Toast.makeText(this@MainActivity, res, Toast.LENGTH_LONG).show()
                }
            )
        }
    }

    private fun structureCopy(file: File, suffixRes: Int): File =
        com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this), file.nameWithoutExtension + getString(suffixRes), "pdf")

    private fun savedToast(out: File) {
        refreshHistory()
        Toast.makeText(this, getString(R.string.epub_tools_done, out.name), Toast.LENGTH_LONG).show()
    }

    private fun showAttachmentsDialog(file: File) {
        pdfStructureTask(file, { com.example.docscanner.util.PdfStructureTools.listAttachments(file) }) { list ->
            val builder = AlertDialog.Builder(this).setTitle(R.string.attachments_title)
                .setNeutralButton(R.string.attachments_add) { _, _ -> pendingAttachmentPdf = file; attachmentPicker.launch(arrayOf("*/*")) }
            if (list.isEmpty()) {
                builder.setMessage(R.string.attachments_none).setPositiveButton(R.string.dialog_cancel, null).show()
                return@pdfStructureTask
            }
            val labels = list.map { getString(R.string.attachments_item, it.name, android.text.format.Formatter.formatShortFileSize(this, it.size)) }.toTypedArray()
            val checked = BooleanArray(list.size)
            builder.setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
                .setPositiveButton(R.string.attachments_extract) { _, _ ->
                    val names = list.filterIndexed { i, _ -> checked[i] }.map { it.name }
                    if (names.isEmpty()) Toast.makeText(this, R.string.selection_none, Toast.LENGTH_SHORT).show() else extractAttachments(file, names)
                }
                .setNegativeButton(R.string.attachments_remove) { _, _ ->
                    val names = list.filterIndexed { i, _ -> checked[i] }.map { it.name }.toSet()
                    if (names.isEmpty()) Toast.makeText(this, R.string.selection_none, Toast.LENGTH_SHORT).show() else removeAttachmentsFrom(file, names)
                }
                .show()
        }
    }

    private fun extractAttachments(file: File, names: List<String>) {
        pdfStructureTask(file, {
            val dir = PdfExporter.exportDir(this)
            names.mapNotNull { name ->
                val data = com.example.docscanner.util.PdfStructureTools.extractAttachment(file, name) ?: return@mapNotNull null
                val dot = name.lastIndexOf('.')
                val base = com.example.docscanner.util.SmartNamer.sanitize(if (dot > 0) name.substring(0, dot) else name).ifEmpty { "attachment" }
                val ext = if (dot > 0) com.example.docscanner.util.SmartNamer.sanitize(name.substring(dot + 1)).ifEmpty { "bin" } else "bin"
                com.example.docscanner.util.SmartNamer.uniqueFile(dir, base, ext).also { it.writeBytes(data) }
            }
        }) { made ->
            refreshHistory()
            Toast.makeText(this, getString(R.string.attachments_extracted, made.size), Toast.LENGTH_LONG).show()
        }
    }

    private fun removeAttachmentsFrom(file: File, names: Set<String>) {
        if (!hasRoomFor(file.length())) return
        val out = structureCopy(file, R.string.suffix_no_attachments)
        pdfStructureTask(file, { com.example.docscanner.util.PdfStructureTools.removeAttachments(file, out, names) }) { savedToast(out) }
    }

    private fun addAttachmentTo(file: File, uri: Uri) {
        if (!hasRoomFor(file.length())) return
        val out = structureCopy(file, R.string.suffix_with_attachment)
        pdfStructureTask(file, {
            var name = "attachment"
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst() && !c.isNull(0)) name = c.getString(0) }
            val data = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw java.io.IOException("khong doc duoc tep")
            if (data.size > 50L * 1024 * 1024) throw java.io.IOException("tep qua lon")
            com.example.docscanner.util.PdfStructureTools.addAttachment(file, out, com.example.docscanner.util.SmartNamer.sanitize(name).ifEmpty { "attachment" }, data, contentResolver.getType(uri), "")
        }) { savedToast(out) }
    }

    private fun showLayersDialog(file: File) {
        pdfStructureTask(file, { com.example.docscanner.util.PdfStructureTools.listLayers(file) }) { layers ->
            if (layers.isEmpty()) {
                Toast.makeText(this, R.string.layers_none, Toast.LENGTH_LONG).show()
                return@pdfStructureTask
            }
            val checked = BooleanArray(layers.size) { layers[it].enabled }
            AlertDialog.Builder(this).setTitle(R.string.layers_title).setMessage(R.string.layers_help)
                .setMultiChoiceItems(layers.map { it.name.ifBlank { getString(R.string.layers_unnamed) } }.toTypedArray(), checked) { _, which, isChecked -> checked[which] = isChecked }
                .setNegativeButton(R.string.dialog_cancel, null)
                .setPositiveButton(R.string.layers_save) { _, _ ->
                    if (!hasRoomFor(file.length())) return@setPositiveButton
                    val out = structureCopy(file, R.string.suffix_layers)
                    pdfStructureTask(file, { com.example.docscanner.util.PdfStructureTools.setLayers(file, out, checked.toList()) }) { savedToast(out) }
                }
                .show()
        }
    }

    private fun showLinksDialog(file: File) {
        pdfStructureTask(file, { com.example.docscanner.util.PdfStructureTools.listLinks(file) }) { links ->
            if (links.isEmpty()) {
                Toast.makeText(this, R.string.links_none, Toast.LENGTH_LONG).show()
                return@pdfStructureTask
            }
            val web = links.filter { it.kind == com.example.docscanner.util.PdfStructureTools.LinkKind.WEB }
            val pages = links.count { it.kind == com.example.docscanner.util.PdfStructureTools.LinkKind.PAGE }
            val sb = StringBuilder(getString(R.string.links_summary, links.size, web.size, pages, links.size - web.size - pages))
            for (l in web.take(8)) sb.append("\n").append(getString(R.string.links_web_line, l.page, l.target))
            if (web.size > 8) sb.append("\n").append(getString(R.string.links_more, web.size - 8))
            AlertDialog.Builder(this).setTitle(R.string.links_title).setMessage(sb.toString())
                .setNeutralButton(R.string.cleanup_close, null)
                .setNegativeButton(R.string.links_remove_all) { _, _ -> removeLinksFrom(file, false) }
                .setPositiveButton(R.string.links_remove_web) { _, _ -> removeLinksFrom(file, true) }
                .show()
        }
    }

    private fun removeLinksFrom(file: File, onlyWeb: Boolean) {
        if (!hasRoomFor(file.length())) return
        val out = structureCopy(file, R.string.suffix_no_links)
        pdfStructureTask(file, { com.example.docscanner.util.PdfStructureTools.removeLinks(file, out, onlyWeb) }) { savedToast(out) }
    }

    /** Runs [action] only if the user accepted the signed-PDF warning for [file] (an unsigned PDF never gets a dialog). */
    private fun afterSignedCheck(file: File, action: () -> Unit) {
        lifecycleScope.launch {
            if (com.example.docscanner.util.SignedPdfGuard.confirm(this@MainActivity, file)) action()
        }
    }

    /** "Fast Web View" (util.PdfLinearizer): a COPY whose first page can be shown while the rest is still downloading. Useful only for files served from a web server. */
    private fun linearizePdf(file: File) {
        if (com.example.docscanner.util.PdfLinearizer.isLinearized(file)) {
            Toast.makeText(this, R.string.linearize_already, Toast.LENGTH_LONG).show()
            return
        }
        if (file.length() > com.example.docscanner.util.PdfLinearizer.MAX_BYTES) {
            Toast.makeText(this, getString(R.string.linearize_too_large, android.text.format.Formatter.formatShortFileSize(this, com.example.docscanner.util.PdfLinearizer.MAX_BYTES)), Toast.LENGTH_LONG).show()
            return
        }
        if (!hasRoomFor(file.length())) return
        afterSignedCheck(file) {
            val out = structureCopy(file, R.string.suffix_linearized)
            pdfStructureTask(file, { com.example.docscanner.util.PdfLinearizer.linearize(file, out) }, R.string.linearize_failed) { pages ->
                refreshHistory()
                Toast.makeText(this, getString(R.string.linearize_done, out.name, pages), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun repairPdf(file: File) {
        if (!hasRoomFor(file.length())) return
        afterSignedCheck(file) {
            val out = structureCopy(file, R.string.suffix_repaired)
            pdfStructureTask(file, { com.example.docscanner.util.PdfRepair.repair(file, out) }, R.string.repair_failed) { r ->
                refreshHistory()
                val note = if (r.diagnosis == com.example.docscanner.util.PdfRepair.Diagnosis.OK) R.string.repair_was_fine else if (r.diagnosis.severe) R.string.repair_was_damaged else R.string.repair_was_nonstandard
                Toast.makeText(this, getString(R.string.repair_done, out.name, r.pages, getString(note)), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun autoLinkPdf(file: File) {
        if (!hasRoomFor(file.length())) return
        afterSignedCheck(file) {
            val out = structureCopy(file, R.string.suffix_autolinks)
            pdfStructureTask(file, { com.example.docscanner.util.PdfAutoLinks.addLinks(file, out) }) { r ->
                if (r.added == 0) {
                    runCatching { out.delete() }
                    Toast.makeText(this, if (r.skippedPages > 0) getString(R.string.autolink_none_skipped, r.skippedPages) else getString(R.string.autolink_none), Toast.LENGTH_LONG).show()
                } else {
                    refreshHistory()
                    Toast.makeText(this, getString(R.string.autolink_done, out.name, r.added, r.skippedPages), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun showPortfolioDialog(file: File) {
        pdfStructureTask(file, { com.example.docscanner.util.PdfStructureTools.isPortfolio(file) }) { isPortfolio ->
            AlertDialog.Builder(this)
                .setTitle(R.string.portfolio_title)
                .setMessage(if (isPortfolio) R.string.portfolio_is_on else R.string.portfolio_is_off)
                .setNegativeButton(R.string.dialog_cancel, null)
                .setPositiveButton(if (isPortfolio) R.string.portfolio_turn_off else R.string.portfolio_turn_on) { _, _ ->
                    if (!hasRoomFor(file.length())) return@setPositiveButton
                    val out = structureCopy(file, R.string.suffix_portfolio)
                    pdfStructureTask(file, { com.example.docscanner.util.PdfStructureTools.setPortfolio(file, out, !isPortfolio) }) { savedToast(out) }
                }
                .show()
        }
    }

    // ---- EPUB tools: edit info / cover / split / merge at ZIP level (util.EpubTools, images and CSS kept), HTML + Markdown via EpubReader ----

    private fun isoNowUtc(): String =
        java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", java.util.Locale.US).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }.format(java.util.Date())

    private fun epubField(box: android.widget.LinearLayout, hintRes: Int, value: String, multiLine: Boolean = false): android.widget.EditText {
        val input = android.widget.EditText(this)
        input.setHint(hintRes)
        input.setText(value)
        if (multiLine) {
            input.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            input.minLines = 3
        } else {
            input.inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        box.addView(input)
        return input
    }

    private fun showEpubMetaDialog(file: File) {
        val meta = runCatching { com.example.docscanner.util.EpubTools.readMeta(file) }.getOrNull()
        if (meta == null) {
            Toast.makeText(this, R.string.epub_tools_unreadable, Toast.LENGTH_LONG).show()
            return
        }
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = android.widget.LinearLayout(this)
        box.orientation = android.widget.LinearLayout.VERTICAL
        box.setPadding(pad, pad / 2, pad, 0)
        val title = epubField(box, R.string.epub_meta_title, meta.title)
        val authors = epubField(box, R.string.epub_meta_authors, meta.authors.joinToString("; "))
        val lang = epubField(box, R.string.epub_meta_language, meta.language)
        val publisher = epubField(box, R.string.epub_meta_publisher, meta.publisher)
        val description = epubField(box, R.string.epub_meta_description, meta.description, multiLine = true)
        val scroll = android.widget.ScrollView(this)
        scroll.addView(box)
        AlertDialog.Builder(this)
            .setTitle(R.string.epub_meta_dialog_title)
            .setMessage(R.string.epub_meta_help)
            .setView(scroll)
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.epub_meta_save) { _, _ ->
                val edited = com.example.docscanner.util.EpubTools.Meta(
                    title.text.toString(),
                    authors.text.toString().split(';', '\n').map { it.trim() }.filter { it.isNotEmpty() },
                    lang.text.toString(), publisher.text.toString(), description.text.toString(), ""
                )
                saveEpubMeta(file, edited)
            }
            .show()
    }

    private fun saveEpubMeta(file: File, meta: com.example.docscanner.util.EpubTools.Meta) {
        if (!hasRoomFor(file.length())) return
        setImporting(true)
        lifecycleScope.launch {
            val out = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), file.nameWithoutExtension + getString(R.string.epub_edited_suffix), "epub")
            val result = runCatching { withContext(Dispatchers.IO) { com.example.docscanner.util.EpubTools.writeMeta(file, out, meta, isoNowUtc()) } }
            setImporting(false)
            if (result.isFailure) {
                runCatching { out.delete() }
                Toast.makeText(this@MainActivity, R.string.epub_tools_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            refreshHistory()
            Toast.makeText(this@MainActivity, getString(R.string.epub_tools_done, out.name), Toast.LENGTH_LONG).show()
        }
    }

    /** JPEG/PNG go in untouched; anything else the system can decode (HEIC, WebP, ...) is re-encoded to JPEG, longest side capped at 2000 px. */
    private fun applyEpubCover(file: File, uri: Uri) {
        if (!hasRoomFor(file.length())) return
        setImporting(true)
        lifecycleScope.launch {
            val out = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), file.nameWithoutExtension + getString(R.string.epub_edited_suffix), "epub")
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val type = contentResolver.getType(uri) ?: ""
                    val raw = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: throw java.io.IOException("khong doc duoc anh")
                    val (bytes, ext) = if (type == "image/jpeg") raw to "jpg" else if (type == "image/png") raw to "png" else {
                        val bmp = android.graphics.BitmapFactory.decodeByteArray(raw, 0, raw.size) ?: throw java.io.IOException("khong giai ma duoc anh")
                        val scale = 2000f / maxOf(bmp.width, bmp.height)
                        val small = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt().coerceAtLeast(1), (bmp.height * scale).toInt().coerceAtLeast(1), true) else bmp
                        val buf = java.io.ByteArrayOutputStream()
                        small.compress(Bitmap.CompressFormat.JPEG, 90, buf)
                        buf.toByteArray() to "jpg"
                    }
                    com.example.docscanner.util.EpubTools.setCover(file, out, bytes, ext, isoNowUtc())
                }
            }
            setImporting(false)
            if (result.isFailure) {
                runCatching { out.delete() }
                Toast.makeText(this@MainActivity, R.string.epub_tools_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            refreshHistory()
            Toast.makeText(this@MainActivity, getString(R.string.epub_tools_done, out.name), Toast.LENGTH_LONG).show()
        }
    }

    private fun showEpubSplitDialog(file: File) {
        val n = runCatching { com.example.docscanner.util.EpubTools.spineSize(file) }.getOrDefault(0)
        if (n < 2) {
            Toast.makeText(this, R.string.epub_split_too_short, Toast.LENGTH_LONG).show()
            return
        }
        val input = android.widget.EditText(this)
        input.inputType = android.text.InputType.TYPE_CLASS_TEXT
        input.setText("1-" + (n / 2))
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = android.widget.FrameLayout(this)
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle(R.string.epub_split_title)
            .setMessage(getString(R.string.epub_split_help, n))
            .setView(box)
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.epub_split_run) { _, _ ->
                val parts = com.example.docscanner.util.EpubTools.parseParts(input.text.toString(), n)
                if (parts == null) Toast.makeText(this, getString(R.string.epub_split_invalid, n), Toast.LENGTH_LONG).show()
                else splitEpub(file, parts)
            }
            .show()
    }

    private fun splitEpub(file: File, parts: List<List<Int>>) {
        if (!hasRoomFor(file.length())) return
        setImporting(true)
        lifecycleScope.launch {
            val dir = PdfExporter.exportDir(this@MainActivity)
            val made = ArrayList<File>()
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val meta = com.example.docscanner.util.EpubTools.readMeta(file)
                    val title = meta.title.ifBlank { file.nameWithoutExtension }
                    for ((k, part) in parts.withIndex()) {
                        val out = com.example.docscanner.util.SmartNamer.uniqueFile(dir, file.nameWithoutExtension + " (" + (k + 1) + ")", "epub")
                        made.add(out)
                        com.example.docscanner.util.EpubTools.build(
                            listOf(com.example.docscanner.util.EpubTools.Source(file, part, title)),
                            getString(R.string.epub_part_title, title, k + 1), meta.language, meta.authors, true, out, isoNowUtc(), java.util.UUID.randomUUID().toString(),
                            { getString(R.string.epub_part_default, it) }
                        )
                    }
                }
            }
            setImporting(false)
            if (result.isFailure) {
                made.forEach { runCatching { it.delete() } }
                Toast.makeText(this@MainActivity, R.string.epub_tools_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            refreshHistory()
            Toast.makeText(this@MainActivity, getString(R.string.epub_split_done, made.size), Toast.LENGTH_LONG).show()
        }
    }

    /** Selection-mode action: merges the selected EPUBs (list order) into one; images, CSS and each book's own table of contents are kept. */
    private fun mergeSelectedEpubs() {
        val files = historyAdapter.selectedFiles().filter { it.extension.equals("epub", ignoreCase = true) }
        if (files.size < 2) {
            Toast.makeText(this, R.string.epub_merge_need_two, Toast.LENGTH_LONG).show()
            return
        }
        val firstTitle = runCatching { com.example.docscanner.util.EpubTools.readMeta(files[0]).title }.getOrDefault("").ifBlank { files[0].nameWithoutExtension }
        val input = android.widget.EditText(this)
        input.inputType = android.text.InputType.TYPE_CLASS_TEXT
        input.setText(getString(R.string.epub_merge_default_title, firstTitle))
        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = android.widget.FrameLayout(this)
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(input)
        AlertDialog.Builder(this)
            .setTitle(getString(R.string.epub_merge_title, files.size))
            .setMessage(R.string.epub_merge_help)
            .setView(box)
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.epub_merge_run) { _, _ -> mergeEpubs(files, input.text.toString().trim().ifEmpty { firstTitle }) }
            .show()
    }

    private fun mergeEpubs(files: List<File>, title: String) {
        if (!hasRoomFor(files.sumOf { it.length() })) return
        setImporting(true)
        lifecycleScope.launch {
            val out = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), com.example.docscanner.util.SmartNamer.sanitize(title).ifEmpty { "epub" }, "epub")
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val sources = ArrayList<com.example.docscanner.util.EpubTools.Source>()
                    val authors = LinkedHashSet<String>()
                    var lang = ""
                    for (f in files) {
                        val m = com.example.docscanner.util.EpubTools.readMeta(f)
                        sources.add(com.example.docscanner.util.EpubTools.Source(f, null, m.title.ifBlank { f.nameWithoutExtension }))
                        authors.addAll(m.authors)
                        if (lang.isEmpty()) lang = m.language
                    }
                    com.example.docscanner.util.EpubTools.build(sources, title, lang, authors.toList(), false, out, isoNowUtc(), java.util.UUID.randomUUID().toString()) { getString(R.string.epub_part_default, it) }
                }
            }
            setImporting(false)
            if (result.isFailure) {
                runCatching { out.delete() }
                Toast.makeText(this@MainActivity, R.string.epub_tools_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            refreshHistory()
            Toast.makeText(this@MainActivity, getString(R.string.epub_tools_done, out.name), Toast.LENGTH_LONG).show()
        }
    }

    /** EPUB -> one HTML page or one Markdown file (chapters as headings), text only - the same chapters [EpubReader] gives the converter. */
    private fun exportEpubText(file: File, html: Boolean) {
        setImporting(true)
        lifecycleScope.launch {
            val out = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), file.nameWithoutExtension, if (html) "html" else "md")
            val result = runCatching {
                withContext(Dispatchers.Default) {
                    val chapters = com.example.docscanner.util.EpubReader.read(file)
                    if (chapters.isEmpty()) throw java.io.IOException("khong co chuong nao")
                    val title = runCatching { com.example.docscanner.util.EpubTools.readMeta(file).title }.getOrDefault("").ifBlank { file.nameWithoutExtension }
                    val text = if (html) com.example.docscanner.util.TextExporters.htmlFromChapters(title, chapters) else com.example.docscanner.util.TextExporters.markdownFromChapters(title, chapters)
                    out.writeText(text, Charsets.UTF_8)
                }
            }
            setImporting(false)
            if (result.isFailure) {
                runCatching { out.delete() }
                Toast.makeText(this@MainActivity, R.string.epub_tools_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            refreshHistory()
            Toast.makeText(this@MainActivity, getString(R.string.epub_tools_done, out.name), Toast.LENGTH_LONG).show()
        }
    }

    /** Splits a PDF into one file per chapter at its bookmarks (see util.PdfBookmarks); the person picks the bookmark level. */
    private fun splitAtBookmarks(file: File) {
        setImporting(true)
        lifecycleScope.launch {
            val read = runCatching { withContext(Dispatchers.IO) { com.example.docscanner.util.PdfBookmarks.readFile(file) } }
            setImporting(false)
            val (entries, pageCount) = read.getOrNull() ?: run {
                Toast.makeText(this@MainActivity, if (read.exceptionOrNull()?.message == "encrypted") R.string.sign_encrypted else R.string.split_bm_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            val deepest = com.example.docscanner.util.PdfBookmarks.maxLevel(entries, pageCount)
            if (deepest == 0) {
                androidx.appcompat.app.AlertDialog.Builder(this@MainActivity).setMessage(R.string.split_bm_none).setPositiveButton(R.string.dialog_ok, null).show()
                return@launch
            }
            val preface = getString(R.string.split_bm_preface)
            val levels = (1..deepest).filter { com.example.docscanner.util.PdfBookmarks.sections(entries, pageCount, it, true, preface).size >= 2 }
            if (levels.isEmpty()) {
                androidx.appcompat.app.AlertDialog.Builder(this@MainActivity).setMessage(R.string.split_bm_one_part).setPositiveButton(R.string.dialog_ok, null).show()
                return@launch
            }
            val labels = levels.map { l ->
                getString(R.string.split_bm_level, l, com.example.docscanner.util.PdfBookmarks.sections(entries, pageCount, l, true, preface).size)
            }.toTypedArray()
            androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                .setTitle(R.string.split_bm_title)
                .setItems(labels) { _, which -> runSplit(file, levels[which], preface) }
                .setNegativeButton(R.string.dialog_cancel, null)
                .show()
        }
    }

    private fun runSplit(file: File, level: Int, preface: String) {
        setImporting(true)
        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.Default) {
                    com.example.docscanner.util.PdfBookmarks.splitFile(file, PdfExporter.exportDir(this@MainActivity), file.nameWithoutExtension, level, true, preface)
                }
            }
            setImporting(false)
            val files = result.getOrNull()
            if (files == null || files.isEmpty()) {
                Toast.makeText(this@MainActivity, R.string.split_bm_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            refreshHistory()
            Toast.makeText(this@MainActivity, getString(R.string.split_bm_done, files.size), Toast.LENGTH_LONG).show()
        }
    }

    /** PDF -> PDF/A-2b (see util.PdfAConverter). A file that cannot be converted without changing what it shows is refused with the reasons listed. */
    private fun exportPdfA(file: File) {
        setImporting(true)
        lifecycleScope.launch {
            if (!com.example.docscanner.util.SignedPdfGuard.confirm(this@MainActivity, file)) {
                setImporting(false)
                return@launch
            }
            val out = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), file.nameWithoutExtension + " (PDF-A)", "pdf")
            val result = runCatching {
                withContext(Dispatchers.Default) { com.example.docscanner.util.PdfAConverter.convert(file, out, file.nameWithoutExtension) }
            }
            setImporting(false)
            val failure = result.exceptionOrNull()
            if (failure != null) {
                runCatching { out.delete() }
                val message = when {
                    failure is com.example.docscanner.util.PdfAConverter.BlockedException ->
                        getString(R.string.pdfa_blocked, failure.blockers.sorted().joinToString { blockerLabel(it) })
                    failure.message == "encrypted" -> getString(R.string.sign_encrypted)
                    else -> getString(R.string.pdfa_failed)
                }
                androidx.appcompat.app.AlertDialog.Builder(this@MainActivity).setMessage(message).setPositiveButton(R.string.dialog_ok, null).show()
                return@launch
            }
            refreshHistory()
            Toast.makeText(this@MainActivity, getString(R.string.pdfa_done, out.name), Toast.LENGTH_LONG).show()
        }
    }

    private fun blockerLabel(code: String): String = getString(
        when (code) {
            "encrypted" -> R.string.pdfa_b_encrypted
            "version" -> R.string.pdfa_b_version
            "font_not_embedded" -> R.string.pdfa_b_font
            "lzw" -> R.string.pdfa_b_lzw
            "cmyk" -> R.string.pdfa_b_cmyk
            "embedded_file" -> R.string.pdfa_b_attachment
            else -> R.string.pdfa_b_annotation
        }
    )

    private fun showRenameDialog(file: File, prefill: String) {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val input = android.widget.EditText(this).apply {
            setText(prefill)
            setSelection(text.length)
            setSingleLine()
        }
        val frame = android.widget.FrameLayout(this).apply {
            setPadding(pad, pad / 2, pad, 0)
            addView(input)
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.history_rename_title)
            .setView(frame)
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.dialog_ok) { _, _ ->
                val renamed = com.example.docscanner.util.SmartNamer.rename(file, input.text.toString())
                if (renamed == null) {
                    Toast.makeText(this, R.string.history_rename_failed, Toast.LENGTH_SHORT).show()
                } else {
                    if (renamed.name != file.name) {
                        com.example.docscanner.util.FavoriteStore.rename(this, file.name, renamed.name)
                        com.example.docscanner.util.TagStore.rename(this, file.name, renamed.name)
                    }
                    refreshHistory()
                }
            }
            .show()
    }

    /** Reads page 1 with OCR, proposes a title as the new name, and lets the user edit it before renaming. */
    private fun suggestNameFromContent(file: File) {
        setImporting(true)
        lifecycleScope.launch {
            val suggestion: String? = withContext(Dispatchers.Default) {
                val bitmap = com.example.docscanner.util.PdfPageBitmap.renderFirstPage(file)
                if (bitmap == null) {
                    null
                } else {
                    val text = try {
                        com.example.docscanner.util.OcrHelper.recognize(bitmap)
                    } finally {
                        bitmap.recycle()
                    }
                    com.example.docscanner.util.SmartNamer.fromText(text) ?: ""
                }
            }
            setImporting(false)
            when {
                suggestion == null -> {
                    Toast.makeText(this@MainActivity, R.string.history_suggest_unreadable, Toast.LENGTH_LONG).show()
                }
                suggestion.isEmpty() -> {
                    Toast.makeText(this@MainActivity, R.string.history_suggest_none, Toast.LENGTH_LONG).show()
                    showRenameDialog(file, file.nameWithoutExtension)
                }
                else -> showRenameDialog(file, suggestion)
            }
        }
    }

    // ---- document list: search, sort, favourites (see util.HistoryFilter) ----

    private var historyAll: List<File> = emptyList()
    private var historyFavorites: Set<String> = emptySet()
    private var historyQuery: String = ""
    private var historyTags: Map<String, Set<String>> = emptyMap()
    private var historyTagFilter: String? = null
    private var historySort = com.example.docscanner.util.HistoryFilter.Sort.NEWEST

    private fun setupHistorySearchAndSort() {
        val prefs = getSharedPreferences("history_view", Context.MODE_PRIVATE)
        historySort = runCatching {
            com.example.docscanner.util.HistoryFilter.Sort.valueOf(prefs.getString("sort", null) ?: "NEWEST")
        }.getOrDefault(com.example.docscanner.util.HistoryFilter.Sort.NEWEST)
        updateSortButtonText()
        binding.btnHistoryTag.setOnClickListener { showTagFilterDialog() }
        binding.btnHistoryVoice.setOnClickListener {
            val intent = Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, java.util.Locale.getDefault().toLanguageTag())
                putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, getString(R.string.history_voice_prompt))
            }
            try {
                voiceSearchLauncher.launch(intent)
            } catch (e: android.content.ActivityNotFoundException) {
                Toast.makeText(this, R.string.history_voice_unavailable, Toast.LENGTH_LONG).show()
            }
        }
        binding.etHistorySearch.doAfterTextChanged {
            historyQuery = it?.toString().orEmpty()
            renderHistory()
        }
        binding.btnHistorySort.setOnClickListener {
            val sorts = com.example.docscanner.util.HistoryFilter.Sort.values()
            val labels = arrayOf(
                getString(R.string.history_sort_newest),
                getString(R.string.history_sort_name),
                getString(R.string.history_sort_largest)
            )
            androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(R.string.history_sort_title)
                .setSingleChoiceItems(labels, sorts.indexOf(historySort)) { dialog, which ->
                    historySort = sorts[which]
                    prefs.edit().putString("sort", historySort.name).apply()
                    updateSortButtonText()
                    renderHistory()
                    dialog.dismiss()
                }
                .setNegativeButton(R.string.dialog_cancel, null)
                .show()
        }
    }

    private fun updateSortButtonText() {
        binding.btnHistorySort.setText(
            when (historySort) {
                com.example.docscanner.util.HistoryFilter.Sort.NEWEST -> R.string.history_sort_newest
                com.example.docscanner.util.HistoryFilter.Sort.NAME -> R.string.history_sort_name
                com.example.docscanner.util.HistoryFilter.Sort.LARGEST -> R.string.history_sort_largest
            }
        )
    }

    /** Re-reads the export folder, then shows it through the current search and sort. */
    private fun refreshHistory() {
        val dir = PdfExporter.exportDir(this)
        com.example.docscanner.util.TrashStore.purgeExpired(com.example.docscanner.util.TrashStore.dir(this), System.currentTimeMillis())
        updateTrashButton()
        val allFiles = dir.listFiles { f -> f.isFile } ?: emptyArray()
        val pdfBaseNames = allFiles
            .filter { it.extension.equals("pdf", ignoreCase = true) }
            .map { it.nameWithoutExtension }
            .toSet()
        // A .txt is shown on its own only if it's a standalone ebook export, not the OCR
        // companion file that rides along with a same-named .pdf (that one opens from the PDF row).
        historyAll = allFiles.filter { f ->
            when (f.extension.lowercase()) {
                // fb2 / xlsx / pptx / html / md: the other exports. (fb2 was missing here until phiên 16: such a file was written but never listed.)
                "pdf", "epub", "docx", "fb2", "xlsx", "pptx", "html", "md", "json", "xml", "b64" -> true
                "txt" -> f.nameWithoutExtension !in pdfBaseNames
                else -> false
            }
        }
        com.example.docscanner.util.FavoriteStore.prune(this, allFiles.map { it.name }.toSet())
        com.example.docscanner.util.TagStore.prune(this, allFiles.map { it.name }.toSet())
        renderHistory()
        maybeSendWebhooks(historyAll)
    }

    private var contentWarmJob: kotlinx.coroutines.Job? = null

    /**
     * Searching by content needs the OCR transcripts read once (see `ContentIndex`). Do it off the main thread; when it finished and
     * something was new, search again so the content matches appear. A second call while one is running does nothing.
     */
    private fun warmContentIndex() {
        if (contentWarmJob?.isActive == true) return
        val files = historyAll
        contentWarmJob = lifecycleScope.launch {
            val changed = withContext(Dispatchers.IO) { com.example.docscanner.util.ContentIndex.warm(files) }
            if (changed && historyQuery.isNotBlank()) renderHistory()
        }
    }

    /** Applies search + sort + favourites to the files read by [refreshHistory]; cheap, no disk access except the stars. */
    private fun renderHistory() {
        historyFavorites = com.example.docscanner.util.FavoriteStore.all(this)
        historyTags = com.example.docscanner.util.TagStore.all(this)
        val activeFilter = historyTagFilter
        if (activeFilter != null && historyTags.values.none { tags -> tags.any { com.example.docscanner.util.TagTree.matches(it, activeFilter) } }) {
            historyTagFilter = null   // the last document carrying this tag lost it: show everything again
        }
        updateTagButtonText()
        if (historyQuery.isNotBlank()) warmContentIndex()
        val shown = com.example.docscanner.util.HistoryFilter.arrangeFiles(
            historyAll, historyQuery, historySort, historyFavorites, historyTags, historyTagFilter,
            content = { com.example.docscanner.util.ContentIndex.cached(it) }
        )
        historyAdapter.submitList(shown)
        val nothingAtAll = historyAll.isEmpty()
        val noMatch = !nothingAtAll && shown.isEmpty()
        binding.tvEmptyHistory.setText(if (noMatch) R.string.history_no_match else R.string.empty_history)
        binding.tvEmptyHistory.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        binding.rvHistory.visibility = if (shown.isEmpty()) View.GONE else View.VISIBLE
        binding.etHistorySearch.visibility = if (nothingAtAll) View.GONE else View.VISIBLE
        binding.btnHistorySort.visibility = if (nothingAtAll) View.GONE else View.VISIBLE
        binding.btnHistoryTag.visibility = if (nothingAtAll) View.GONE else View.VISIBLE
    }

    private fun showScanSourcePicker() {
        val options = arrayOf(
            getString(R.string.source_camera),
            getString(R.string.source_gallery),
            getString(R.string.source_pdf),
            getString(R.string.source_archive)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.source_picker_title)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        ScanSessionManager.clear()
                        startActivity(Intent(this, CaptureActivity::class.java))
                    }
                    1 -> galleryPicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                    2 -> scanPdfPicker.launch(arrayOf("application/pdf"))
                    3 -> scanArchivePicker.launch(arrayOf("application/zip", "application/vnd.comicbook+zip", "application/x-cbz", "application/octet-stream"))
                }
            }
            .show()
    }

    private fun importGalleryImages(uris: List<Uri>) {
        setImporting(true)
        lifecycleScope.launch {
            val paths = withContext(Dispatchers.IO) {
                uris.mapIndexedNotNull { index, uri -> copyUriToFile(uri, index) }
            }
            setImporting(false)
            startCropQueue(paths)
        }
    }

    /** Renders every page of the chosen PDF at a known DPI (220) and sends them through the same
     *  crop/filter queue as gallery imports - but, unlike gallery imports, this source DOES have a
     *  real DPI, so it's passed through to [startCropQueue] to keep the PDF this session eventually
     *  exports to at the correct physical page size (see [PdfExporter]'s `ASSUMED_DPI` doc comment,
     *  and TECHNICAL_DOCS.md section 6/7 - this was the one remaining unfixed `ASSUMED_DPI` spot). */
    private fun importPdfForScanning(uri: Uri) {
        setImporting(true)
        lifecycleScope.launch {
            val paths = withContext(Dispatchers.IO) {
                PdfImportHelper.renderAllPagesToFiles(this@MainActivity, uri, dpi = 220)
            }
            setImporting(false)
            startCropQueue(paths, sourceDpi = 220f)
        }
    }

    /** CBZ / ZIP of pictures -> the same crop queue as gallery photos (util.ArchiveImages: natural order, zip-slip and zip-bomb safe). */
    private fun importArchiveForScanning(uri: Uri) {
        val size = runCatching {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)?.use { c -> if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else 0L }
        }.getOrNull() ?: 0L
        if (!hasRoomFor(size)) return
        setImporting(true)
        lifecycleScope.launch {
            val paths = withContext(Dispatchers.IO) {
                val tmp = File(FileUtils.tempDir(this@MainActivity), "archive_" + System.currentTimeMillis() + ".zip")
                try {
                    contentResolver.openInputStream(uri)?.use { input -> FileOutputStream(tmp).use { input.copyTo(it) } }
                    com.example.docscanner.util.ArchiveImages.extract(tmp, FileUtils.importedDir(this@MainActivity), "arc_" + System.currentTimeMillis() + "_").map { it.absolutePath }
                } catch (e: Exception) {
                    emptyList()
                } finally {
                    tmp.delete()
                }
            }
            setImporting(false)
            if (paths.isEmpty()) Toast.makeText(this@MainActivity, R.string.archive_no_images, Toast.LENGTH_LONG).show() else startCropQueue(paths)
        }
    }

    /** False (with a message) when the export folder cannot hold [inputBytes] twice plus a safety margin - checked BEFORE a long operation, not after it fails half way. */
    private fun hasRoomFor(inputBytes: Long): Boolean {
        val free = PdfExporter.exportDir(this).usableSpace
        if (com.example.docscanner.util.StorageTools.enoughSpace(free, inputBytes)) return true
        Toast.makeText(this, getString(R.string.low_space, android.text.format.Formatter.formatShortFileSize(this, com.example.docscanner.util.StorageTools.requiredSpace(inputBytes)), android.text.format.Formatter.formatShortFileSize(this, free)), Toast.LENGTH_LONG).show()
        return false
    }

    /** [sourceDpi]: the known render DPI for every page in [paths], or `null` for a source with no
     *  "true" DPI (gallery photos - same convention as a camera capture). Carried through
     *  [PendingCropQueue] and the first image's Intent extra so `CropActivity` can stamp it onto
     *  every [ScanPage] it saves from this batch, including split-page halves. */
    private fun startCropQueue(paths: List<String>, sourceDpi: Float? = null) {
        if (paths.isEmpty()) {
            Toast.makeText(this, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
            return
        }
        ScanSessionManager.clear()
        PendingCropQueue.setAll(paths.drop(1), sourceDpi)
        val intent = Intent(this, CropActivity::class.java).apply {
            putExtra(CropActivity.EXTRA_IMAGE_PATH, paths.first())
            putExtra(CropActivity.EXTRA_QUEUE_MODE, true)
            if (sourceDpi != null) putExtra(CropActivity.EXTRA_SOURCE_DPI, sourceDpi)
        }
        startActivity(intent)
    }

    /** Bulk tool: renders every page straight into a session (no interactive crop - a digital
     *  PDF page is already flat) so the user can jump right to the bulk e-ink filter. Passes the
     *  actual render DPI (250, matching the call below) as each page's `sourceDpi` so the PDF this
     *  session eventually exports to keeps the correct physical page size - see
     *  `PdfExporter.ASSUMED_DPI`'s doc comment for why that matters. */
    private fun importPdfForEink(uri: Uri) {
        setImporting(true)
        lifecycleScope.launch {
            val paths = withContext(Dispatchers.IO) {
                PdfImportHelper.renderAllPagesToFiles(this@MainActivity, uri, dpi = 250)
            }
            setImporting(false)
            if (paths.isEmpty()) {
                Toast.makeText(this@MainActivity, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
                return@launch
            }
            ScanSessionManager.clear()
            paths.forEach { ScanSessionManager.addPage(ScanPage(ScanSessionManager.newPageId(), it, sourceDpi = 250f)) }
            startActivity(Intent(this@MainActivity, PageListActivity::class.java))
        }
    }

    /** [forUri] = a PDF that is already chosen (handed over by another app); null = ask for the file after the method. */
    private fun showCompressMethodPicker(forUri: Uri? = null) {
        val options = listOf(
            CompressOptionsDialog.Option(
                title = getString(R.string.compress_method_safe),
                summary = getString(R.string.compress_option_safe_summary),
                pros = getString(R.string.compress_option_safe_pros),
                cons = getString(R.string.compress_option_safe_cons)
            ),
            CompressOptionsDialog.Option(
                title = getString(R.string.compress_method_g4),
                summary = getString(R.string.compress_option_g4_summary),
                pros = getString(R.string.compress_option_g4_pros),
                cons = getString(R.string.compress_option_g4_cons)
            ),
            CompressOptionsDialog.Option(
                title = getString(R.string.compress_method_direct_edit),
                summary = getString(R.string.compress_option_direct_edit_summary),
                pros = getString(R.string.compress_option_direct_edit_pros),
                cons = getString(R.string.compress_option_direct_edit_cons)
            )
        )
        CompressOptionsDialog.show(this, R.string.compress_method_title, options) { which ->
            pendingCompressionMethod = when (which) {
                1 -> CompressChoice.G4
                2 -> CompressChoice.DIRECT_EDIT
                else -> CompressChoice.SAFE
            }
            if (forUri != null) compressExistingPdf(forUri) else compressPdfPicker.launch(arrayOf("application/pdf"))
        }
    }

    /**
     * Standalone "Nén PDF" tool: the input can be ANY PDF the user picks, not necessarily one
     * this app scanned - unlike the Project flow's compress stage (`ProjectCompressActivity`),
     * which only ever compresses this app's own freshly-scanned images and is left untouched (see
     * TECHNICAL_DOCS.md). Offers 3 methods now (`showCompressMethodPicker`): the original 2
     * (`PdfCompressor` - rasterize every page, rebuild the PDF from scratch; fine for an
     * already-scanned PDF, HARMFUL for one with real vector text - see [fileLikelyHasRealText])
     * plus a newer 3rd ("Sửa trực tiếp") that edits the existing PDF's own embedded JPEG images in
     * place via PdfBox-Android (`PdfObjectRecompressor`), never touching real text/vector content at all -
     * see that class's own doc comment for the full picture, including its narrow, deliberate
     * scope and TECHNICAL_DOCS.md (phiên 11) for why the engine is PdfBox-Android (Apache 2.0)
     * rather than iText (AGPL / paid licence). [fileLikelyHasRealText]'s warning is skipped for that 3rd method - it exists to
     * protect against the other 2 rasterizing real text away, which the direct-edit method never
     * does in the first place.
     * After compressing (any of the 3 methods), if the result isn't actually smaller than the
     * original, the output is discarded and the user is told plainly instead of handing back a
     * "compressed" file that's worse than what they started with - a hard guarantee, not a
     * heuristic, and the same rule for all 3.
     */
    private fun compressExistingPdf(uri: Uri) {
        if (pendingCompressionMethod == CompressChoice.DIRECT_EDIT) {
            // This method never rasterizes real text away in the first place - the warning below
            // exists specifically to protect against the other 2 methods doing that, so it does
            // not apply here.
            runCompression(uri)
            return
        }
        lifecycleScope.launch {
            val looksLikeRealText = withContext(Dispatchers.IO) { fileLikelyHasRealText(uri) }
            if (looksLikeRealText) {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(R.string.compress_text_warning_title)
                    .setMessage(R.string.compress_text_warning_message)
                    .setPositiveButton(R.string.compress_text_warning_continue) { _, _ -> runCompression(uri) }
                    .setNegativeButton(R.string.dialog_cancel, null)
                    .show()
            } else {
                runCompression(uri)
            }
        }
    }

    /** Best-effort, NOT real PDF parsing: just checks whether the raw file bytes contain the
     *  literal `/Font` dictionary key PDF producers write for any embedded font resource. A
     *  genuine scan (every page a photographed image, no fonts anywhere) will never contain this
     *  string; a text document almost always will, UNLESS its objects happen to be packed inside
     *  compressed object streams (common in some modern PDF producers) - in that case this misses
     *  it and simply skips the warning, same as if the check had never run. Skips the check
     *  entirely for very large files (>50MB) to avoid loading something huge into memory just for
     *  a heuristic. */
    private fun fileLikelyHasRealText(uri: Uri): Boolean {
        return try {
            val size = PdfImportHelper.fileSize(this, uri)
            if (size <= 0 || size > 50_000_000L) return false
            contentResolver.openInputStream(uri)?.use { input ->
                String(input.readBytes(), Charsets.ISO_8859_1).contains("/Font")
            } ?: false
        } catch (e: Exception) {
            false
        }
    }

    private fun runCompression(uri: Uri) {
        val method = pendingCompressionMethod
        if (method == CompressChoice.DIRECT_EDIT) {
            runDirectEditCompression(uri)
            return
        }
        val textMethod = if (method == CompressChoice.G4) {
            PdfCompressor.TextCompressionMethod.CCITT_G4
        } else {
            PdfCompressor.TextCompressionMethod.SAFE_DEFLATE
        }
        setImporting(true)
        lifecycleScope.launch {
            val originalSize = withContext(Dispatchers.IO) { PdfImportHelper.fileSize(this@MainActivity, uri) }
            val paths = withContext(Dispatchers.IO) {
                PdfImportHelper.renderAllPagesToFiles(this@MainActivity, uri, dpi = 250)
            }
            if (paths.isEmpty()) {
                setImporting(false)
                Toast.makeText(this@MainActivity, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
                return@launch
            }
            val outFile = File(PdfExporter.exportDir(this@MainActivity), "${FileUtils.defaultCompressedName()}.pdf")
            val result = withContext(Dispatchers.Default) {
                // paths here always came from rendering the picked PDF at 250dpi (just above) -
                // pass that real DPI through so the compressed page keeps the correct physical
                // size instead of coming out oversized (see PdfCompressor.ASSUMED_DPI's doc comment).
                PdfCompressor.compress(paths, outFile, originalSize, textMethod, assumedDpi = 250f) { done, total ->
                    runOnUiThread {
                        importingDialog?.setMessage(getString(R.string.compress_progress, done, total))
                    }
                }
            }
            paths.forEach { runCatching { File(it).delete() } }
            setImporting(false)
            if (result.compressedSize >= result.originalSize) {
                // Never hand back a "compressed" file that's actually not smaller - see the class
                // doc comment on compressExistingPdf(). Original file is untouched either way
                // (this tool only ever reads it, via SAF); only the failed output gets deleted.
                runCatching { outFile.delete() }
                Toast.makeText(this@MainActivity, getString(R.string.compress_no_benefit), Toast.LENGTH_LONG).show()
                return@launch
            }
            val ratioStr = String.format(Locale.getDefault(), "%.1f", result.ratio)
            Toast.makeText(
                this@MainActivity,
                getString(
                    R.string.compress_success,
                    FileUtils.humanFileSize(result.originalSize),
                    FileUtils.humanFileSize(result.compressedSize),
                    ratioStr
                ),
                Toast.LENGTH_LONG
            ).show()
            refreshHistory()
        }
    }

    /** "Sửa trực tiếp" - see [PdfObjectRecompressor]'s own doc comment for the full picture. This
     *  never renders anything (no [PdfImportHelper] call at all) - the DPI-mismatch concern that
     *  matters for the other 2 methods (see [PdfCompressor.ASSUMED_DPI]) simply does not apply
     *  here, since the page objects themselves - MediaBox included - are never touched. */
    private fun runDirectEditCompression(uri: Uri) {
        setImporting(true)
        lifecycleScope.launch {
            val srcFile = withContext(Dispatchers.IO) { copyUriToTempPdfFile(uri) }
            if (srcFile == null) {
                setImporting(false)
                Toast.makeText(this@MainActivity, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
                return@launch
            }
            if (!com.example.docscanner.util.SignedPdfGuard.confirm(this@MainActivity, srcFile)) {
                setImporting(false)
                runCatching { srcFile.delete() }
                return@launch
            }
            val originalSize = srcFile.length()
            val outFile = File(PdfExporter.exportDir(this@MainActivity), "${FileUtils.defaultCompressedName()}.pdf")
            val result = runCatching {
                withContext(Dispatchers.Default) {
                    PdfObjectRecompressor.recompress(srcFile, outFile) { done, total ->
                        runOnUiThread {
                            importingDialog?.setMessage(getString(R.string.compress_progress, done, total))
                        }
                    }
                }
            }
            runCatching { srcFile.delete() }
            setImporting(false)
            val recompressResult = result.getOrNull()
            if (recompressResult == null) {
                // The PDF itself couldn't even be opened/parsed by PdfBox - leave the user with a
                // plain, honest failure message rather than a half-written or misleading output.
                runCatching { outFile.delete() }
                Toast.makeText(this@MainActivity, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
                return@launch
            }
            val compressedSize = outFile.length()
            if (compressedSize >= originalSize || compressedSize <= 0) {
                runCatching { outFile.delete() }
                Toast.makeText(this@MainActivity, getString(R.string.compress_no_benefit), Toast.LENGTH_LONG).show()
                return@launch
            }
            val ratioStr = String.format(Locale.getDefault(), "%.1f", originalSize.toDouble() / compressedSize)
            Toast.makeText(
                this@MainActivity,
                getString(
                    R.string.compress_direct_edit_success,
                    FileUtils.humanFileSize(originalSize),
                    FileUtils.humanFileSize(compressedSize),
                    ratioStr,
                    recompressResult.imagesRecompressed,
                    recompressResult.imagesRecompressed + recompressResult.imagesSkipped
                ) + if (recompressResult.structureOptimized) getString(R.string.compress_structure_note) else "",
                Toast.LENGTH_LONG
            ).show()
            refreshHistory()
        }
    }

    /** What to do with the picked PDF: set a password, remove one, or stamp a text watermark. */
    private fun showSecurityMenu(uri: Uri) {
        val labels = arrayOf(
            getString(R.string.security_set_password),
            getString(R.string.security_remove_password),
            getString(R.string.security_watermark),
            getString(R.string.security_edit_info),
            getString(R.string.security_strip_info),
            getString(R.string.security_digital_sign)
        )
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.tool_security_title)
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> askText(R.string.security_set_password, R.string.security_password_hint, secret = true) { runSecurity(uri, SecurityAction.PROTECT, it) }
                    1 -> askText(R.string.security_remove_password, R.string.security_password_hint, secret = true) { runSecurity(uri, SecurityAction.UNPROTECT, it) }
                    2 -> askText(R.string.security_watermark, R.string.security_watermark_hint, secret = false) { runSecurity(uri, SecurityAction.WATERMARK, it) }
                    3 -> runMetadata(uri, strip = false)
                    4 -> runMetadata(uri, strip = true)
                    else -> startDigitalSign(uri)
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ---- digital signature (see util.PdfDigitalSigner: key in the Android Keystore, self-signed certificate) ----

    /** First use: ask for the signer's name and create the key + certificate; then confirm and sign. */
    private fun startDigitalSign(uri: Uri) {
        val signer = com.example.docscanner.util.PdfDigitalSigner
        if (signer.hasKey()) {
            confirmDigitalSign(uri)
            return
        }
        // no key yet: make a self-signed certificate, or bring the person's own certificate file (PDF list 3.x, 4.49.8)
        val choices = arrayOf(getString(R.string.digsign_choice_create), getString(R.string.digsign_choice_import))
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.digsign_choice_title)
            .setItems(choices) { _, which ->
                if (which == 1) {
                    pendingSignUri = uri
                    certificatePicker.launch(arrayOf("application/x-pkcs12", "application/pkcs12", "application/octet-stream", "*/*"))
                } else {
                    askText(R.string.digsign_name_title, R.string.digsign_name_hint, secret = false) { name ->
                        val created = runCatching { signer.createKey(name) }.isSuccess
                        if (created) {
                            confirmDigitalSign(uri)
                        } else {
                            Toast.makeText(this, R.string.digsign_key_failed, Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    /**
     * A .p12 / .pfx was picked: read it (at most 5 MB), ask for its password (an EMPTY password is allowed, so not [askText]), check it and move
     * the key into the Android Keystore ([com.example.docscanner.util.PdfDigitalSigner.importPkcs12]); then carry on to the confirm-and-sign step.
     */
    private fun importCertificateFile(file: Uri, pdf: Uri) {
        val bytes = runCatching {
            contentResolver.openInputStream(file)?.use { input -> input.readBytes().takeIf { it.size <= 5 * 1024 * 1024 } }
        }.getOrNull()
        if (bytes == null || bytes.isEmpty()) {
            pendingSignUri = null
            Toast.makeText(this, R.string.digsign_import_bad_file, Toast.LENGTH_LONG).show()
            return
        }
        val input = android.widget.EditText(this).apply {
            setHint(R.string.digsign_import_password_hint)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = android.widget.FrameLayout(this).apply { setPadding(pad, pad / 2, pad, 0); addView(input) }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.digsign_import_password_title)
            .setView(holder)
            .setPositiveButton(R.string.digsign_import_run) { _, _ ->
                val password = input.text.toString().toCharArray()
                setImporting(true)
                lifecycleScope.launch {
                    val failure = withContext(Dispatchers.Default) {
                        runCatching { com.example.docscanner.util.PdfDigitalSigner.importPkcs12(bytes, password) }.exceptionOrNull()
                    }
                    setImporting(false)
                    pendingSignUri = null
                    if (failure == null) {
                        confirmDigitalSign(pdf)
                    } else {
                        val message = when ((failure as? com.example.docscanner.util.Pkcs12Import.ImportException)?.reason) {
                            com.example.docscanner.util.Pkcs12Import.Reason.BAD_FILE_OR_PASSWORD -> R.string.digsign_import_bad_file
                            com.example.docscanner.util.Pkcs12Import.Reason.NO_KEY -> R.string.digsign_import_no_key
                            com.example.docscanner.util.Pkcs12Import.Reason.EXPIRED -> R.string.digsign_import_expired
                            com.example.docscanner.util.Pkcs12Import.Reason.NOT_YET_VALID -> R.string.digsign_import_not_yet
                            com.example.docscanner.util.Pkcs12Import.Reason.UNSUPPORTED_KEY -> R.string.digsign_import_unsupported
                            com.example.docscanner.util.Pkcs12Import.Reason.WEAK_KEY -> R.string.digsign_import_weak
                            com.example.docscanner.util.Pkcs12Import.Reason.KEY_MISMATCH -> R.string.digsign_import_mismatch
                            null -> R.string.digsign_import_failed
                        }
                        Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
                    }
                }
            }
            .setNegativeButton(R.string.dialog_cancel) { _, _ -> pendingSignUri = null }
            .setOnCancelListener { pendingSignUri = null }
            .show()
    }

    private fun confirmDigitalSign(uri: Uri) {
        val signer = com.example.docscanner.util.PdfDigitalSigner
        val info = signer.info()
        if (info == null) {
            Toast.makeText(this, R.string.digsign_key_failed, Toast.LENGTH_LONG).show()
            return
        }
        val until = java.text.DateFormat.getDateInstance().format(java.util.Date(info.notAfter))
        // optional RFC 3161 time stamp server (phiên 20, 4.48.6): EMPTY = no time stamp and no network call; what is typed is remembered
        val prefs = getSharedPreferences("digital_sign", MODE_PRIVATE)
        val tsaField = android.widget.EditText(this).apply {
            setHint(R.string.digsign_tsa_hint)
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setText(prefs.getString("tsa_url", "") ?: "")
        }
        // optional visible stamp on the last page (4.49.10); remembered, off by default because it sits on top of whatever is in that corner
        val visibleBox = android.widget.CheckBox(this).apply { setText(R.string.digsign_visible_option); isChecked = prefs.getBoolean("visible_stamp", false) }
        // optional long-term validation (4.51): stores OCSP / CRL answers in the PDF; needs the network, so off by default and remembered
        val ltvBox = android.widget.CheckBox(this).apply { setText(R.string.digsign_ltv_option); isChecked = prefs.getBoolean("ltv", false) }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(android.widget.TextView(this@MainActivity).apply { text = getString(R.string.digsign_confirm_message, info.subject, until, info.sha256) })
            addView(android.widget.TextView(this@MainActivity).apply { setText(R.string.digsign_tsa_label); setPadding(0, pad / 2, 0, 0) })
            addView(tsaField)
            addView(android.widget.TextView(this@MainActivity).apply { setText(R.string.digsign_tsa_note); textSize = 12f })
            addView(visibleBox)
            addView(ltvBox)
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.digsign_confirm_title)
            .setView(box)
            .setPositiveButton(R.string.digsign_btn_sign) { _, _ ->
                val tsa = tsaField.text.toString().trim()
                if (tsa.isNotEmpty() && !(tsa.startsWith("http://") || tsa.startsWith("https://"))) {
                    Toast.makeText(this, R.string.digsign_tsa_bad_url, Toast.LENGTH_LONG).show()
                } else {
                    prefs.edit().putString("tsa_url", tsa).putBoolean("visible_stamp", visibleBox.isChecked).putBoolean("ltv", ltvBox.isChecked).apply()
                    runDigitalSign(uri, tsa, visibleBox.isChecked, ltvBox.isChecked)
                }
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .setNeutralButton(R.string.digsign_btn_delete) { _, _ ->
                androidx.appcompat.app.AlertDialog.Builder(this)
                    .setMessage(R.string.digsign_delete_confirm)
                    .setNegativeButton(R.string.dialog_cancel, null)
                    .setPositiveButton(R.string.dialog_ok) { _, _ ->
                        signer.deleteKey()
                        Toast.makeText(this, R.string.digsign_deleted, Toast.LENGTH_SHORT).show()
                    }
                    .show()
            }
            .show()
    }

    private fun runDigitalSign(uri: Uri, tsaUrl: String = "", visibleStamp: Boolean = false, storeRevocation: Boolean = false) {
        setImporting(true)
        lifecycleScope.launch {
            val src = withContext(Dispatchers.IO) { copyUriToTempPdfFile(uri) }
            if (src == null) {
                setImporting(false)
                Toast.makeText(this@MainActivity, R.string.digsign_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            if (!com.example.docscanner.util.SignedPdfGuard.confirm(this@MainActivity, src, com.example.docscanner.util.PdfSignatureProbe.ToolKind.APPENDS_SIGNATURE)) {
                setImporting(false)
                runCatching { src.delete() }
                return@launch
            }
            val outFile = File(PdfExporter.exportDir(this@MainActivity), "${FileUtils.defaultSecurityName("digisigned")}.pdf")
            val signerName = com.example.docscanner.util.PdfDigitalSigner.info()?.subject?.let { com.example.docscanner.util.PdfDigitalSigner.commonName(it) }
            val stampLines = if (visibleStamp) listOf(
                getString(R.string.digsign_stamp_by, signerName ?: ""),
                java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT).format(java.util.Date())
            ) else null
            val result = runCatching {
                withContext(Dispatchers.IO) {   // IO, not Default: a time stamp is a network call
                    com.example.docscanner.util.PdfDigitalSigner.sign(src, outFile, signerName, null, tsaUrl, stampLines)
                }
            }
            runCatching { src.delete() }
            // long-term validation (4.51): a failure here never undoes the signature, it is only reported
            var ltvMessage: String? = null
            if (storeRevocation && result.isSuccess) {
                val ltv = runCatching { withContext(Dispatchers.IO) { com.example.docscanner.util.PdfLtv.addValidationInfo(outFile) } }.getOrNull()
                ltvMessage = if (ltv == null) getString(R.string.digsign_ltv_failed)
                else if (ltv.written) getString(R.string.digsign_ltv_done, ltv.covered, ltv.needed)
                else getString(R.string.digsign_ltv_none)
            }
            setImporting(false)
            if (result.isFailure) {
                runCatching { outFile.delete() }
                val failure = result.exceptionOrNull()
                val encrypted = failure?.message == "encrypted"
                if (tsaUrl.isNotEmpty() && failure is java.io.IOException && !encrypted) {
                    Toast.makeText(this@MainActivity, getString(R.string.digsign_tsa_failed, failure.message ?: ""), Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this@MainActivity, if (encrypted) R.string.sign_encrypted else R.string.digsign_failed, Toast.LENGTH_LONG).show()
                }
                return@launch
            }
            refreshHistory()
            if (visibleStamp && result.getOrNull() == false) Toast.makeText(this@MainActivity, R.string.digsign_stamp_skipped, Toast.LENGTH_LONG).show()
            androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                .setMessage(getString(R.string.digsign_done, outFile.name) + (ltvMessage?.let { "\n\n" + it } ?: ""))
                .setPositiveButton(R.string.dialog_ok, null)
                .setNeutralButton(R.string.digsign_share_cert) { _, _ -> shareSigningCertificate() }
                .show()
        }
    }

    /** The public certificate (never the key) as a .cer file, so the recipient can choose to trust this signer. */
    private fun shareSigningCertificate() {
        val der = com.example.docscanner.util.PdfDigitalSigner.certificateDer() ?: return
        val file = File(PdfExporter.exportDir(this), "docscanner_signing_certificate.cer")
        runCatching {
            file.writeBytes(der)
            FileUtils.shareFile(this, file, getString(R.string.digsign_share_cert))
        }
    }

    // ---- PDF properties (title/author/subject/keywords) - see util.PdfMetadataTools ----

    private fun runMetadata(uri: Uri, strip: Boolean) {
        setImporting(true)
        lifecycleScope.launch {
            val src = withContext(Dispatchers.IO) { copyUriToTempPdfFile(uri) }
            if (src == null) {
                setImporting(false)
                Toast.makeText(this@MainActivity, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
                return@launch
            }
            if (!com.example.docscanner.util.SignedPdfGuard.confirm(this@MainActivity, src)) {
                setImporting(false)
                runCatching { src.delete() }
                return@launch
            }
            if (strip) {
                applyMetadata(src, null)
                return@launch
            }
            val info = runCatching {
                withContext(Dispatchers.IO) { com.example.docscanner.util.PdfMetadataTools.read(src) }
            }
            setImporting(false)
            val current = info.getOrNull()
            if (current == null) {
                runCatching { src.delete() }
                val encrypted = info.exceptionOrNull()?.message == "encrypted"
                Toast.makeText(this@MainActivity, if (encrypted) R.string.sign_encrypted else R.string.metadata_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            showMetadataDialog(src, current)
        }
    }

    private fun showMetadataDialog(src: File, current: com.example.docscanner.util.PdfMetadataTools.Info) {
        val pad = (20 * resources.displayMetrics.density).toInt()
        fun field(hint: Int, value: String) = android.widget.EditText(this).apply {
            setHint(hint)
            setText(value)
            setSingleLine()
        }
        val title = field(R.string.metadata_title, current.title)
        val author = field(R.string.metadata_author, current.author)
        val subject = field(R.string.metadata_subject, current.subject)
        val keywords = field(R.string.metadata_keywords, current.keywords)
        val column = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            listOf(title, author, subject, keywords).forEach { addView(it) }
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.security_edit_info)
            .setView(android.widget.ScrollView(this).apply { addView(column) })
            .setNegativeButton(R.string.dialog_cancel) { _, _ -> runCatching { src.delete() } }
            .setOnCancelListener { runCatching { src.delete() } }
            .setPositiveButton(R.string.dialog_ok) { _, _ ->
                applyMetadata(
                    src,
                    com.example.docscanner.util.PdfMetadataTools.Info(
                        title.text.toString(), author.text.toString(), subject.text.toString(), keywords.text.toString()
                    )
                )
            }
            .show()
    }

    /** [info] null = remove all document labels. Deletes [src] when done either way. */
    private fun applyMetadata(src: File, info: com.example.docscanner.util.PdfMetadataTools.Info?) {
        setImporting(true)
        val prefix = if (info == null) "clean" else "info"
        val outFile = File(PdfExporter.exportDir(this), "${FileUtils.defaultSecurityName(prefix)}.pdf")
        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.Default) {
                    if (info == null) com.example.docscanner.util.PdfMetadataTools.strip(src, outFile)
                    else com.example.docscanner.util.PdfMetadataTools.write(src, outFile, info)
                }
            }
            runCatching { src.delete() }
            setImporting(false)
            if (result.isFailure) {
                runCatching { outFile.delete() }
                val encrypted = result.exceptionOrNull()?.message == "encrypted"
                Toast.makeText(this@MainActivity, if (encrypted) R.string.sign_encrypted else R.string.metadata_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            Toast.makeText(this@MainActivity, getString(R.string.metadata_done, outFile.name), Toast.LENGTH_LONG).show()
            refreshHistory()
        }
    }

    private fun askText(title: Int, hint: Int, secret: Boolean, onOk: (String) -> Unit) {
        val input = android.widget.EditText(this).apply {
            setHint(hint)
            inputType = if (secret) {
                android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            } else android.text.InputType.TYPE_CLASS_TEXT
            setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = android.widget.FrameLayout(this).apply { setPadding(pad, pad / 2, pad, 0); addView(input) }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(title)
            .setView(holder)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val text = input.text.toString()
                if (text.isBlank()) Toast.makeText(this, R.string.security_empty_input, Toast.LENGTH_SHORT).show() else onOk(text)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private enum class SecurityAction(val prefix: String) { PROTECT("protected"), UNPROTECT("unlocked"), WATERMARK("watermark") }

    private fun runSecurity(uri: Uri, action: SecurityAction, text: String) {
        setImporting(true)
        lifecycleScope.launch {
            val srcFile = withContext(Dispatchers.IO) { copyUriToTempPdfFile(uri) }
            if (srcFile == null) {
                setImporting(false)
                Toast.makeText(this@MainActivity, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
                return@launch
            }
            if (!com.example.docscanner.util.SignedPdfGuard.confirm(this@MainActivity, srcFile)) {
                setImporting(false)
                runCatching { srcFile.delete() }
                return@launch
            }
            val outFile = File(PdfExporter.exportDir(this@MainActivity), "${FileUtils.defaultSecurityName(action.prefix)}.pdf")
            val result = runCatching {
                withContext(Dispatchers.Default) {
                    when (action) {
                        SecurityAction.PROTECT -> PdfSecurityTools.protect(srcFile, outFile, text)
                        SecurityAction.UNPROTECT -> PdfSecurityTools.unprotect(srcFile, outFile, text)
                        SecurityAction.WATERMARK -> PdfSecurityTools.watermark(srcFile, outFile, text)
                    }
                }
            }
            runCatching { srcFile.delete() }
            setImporting(false)
            val pages = result.getOrNull()
            if (pages == null) {
                runCatching { outFile.delete() }
                val wrong = result.exceptionOrNull() is PdfSecurityTools.WrongPassword
                Toast.makeText(
                    this@MainActivity,
                    getString(if (wrong) R.string.security_wrong_password else R.string.security_failed),
                    Toast.LENGTH_LONG
                ).show()
                return@launch
            }
            Toast.makeText(
                this@MainActivity,
                getString(
                    when (action) {
                        SecurityAction.PROTECT -> R.string.security_done_protect
                        SecurityAction.UNPROTECT -> R.string.security_done_unprotect
                        SecurityAction.WATERMARK -> R.string.security_done_watermark
                    },
                    pages
                ),
                Toast.LENGTH_LONG
            ).show()
            refreshHistory()
        }
    }

    /**
     * "PDF tìm kiếm được" - OCR every page that has no real text and lays an invisible text layer over
     * it (see [SearchablePdfBuilder]'s doc comment). The source PDF is only read; the result goes to the
     * export folder like every other tool's output, and a result that ended up with no text layer at all
     * is deleted instead of being handed back as if it were something new.
     */
    private fun makeSearchablePdf(uri: Uri) {
        setImporting(true)
        lifecycleScope.launch {
            val srcFile = withContext(Dispatchers.IO) { copyUriToTempPdfFile(uri) }
            if (srcFile == null) {
                setImporting(false)
                Toast.makeText(this@MainActivity, getString(R.string.export_failed, ""), Toast.LENGTH_SHORT).show()
                return@launch
            }
            if (!com.example.docscanner.util.SignedPdfGuard.confirm(this@MainActivity, srcFile)) {
                setImporting(false)
                runCatching { srcFile.delete() }
                return@launch
            }
            val outFile = File(PdfExporter.exportDir(this@MainActivity), "${FileUtils.defaultSearchableName()}.pdf")
            val result = runCatching {
                withContext(Dispatchers.Default) {
                    SearchablePdfBuilder.build(srcFile, outFile, searchableScript) { done, total ->
                        runOnUiThread {
                            importingDialog?.setMessage(getString(R.string.searchable_progress, done, total))
                        }
                    }
                }
            }
            runCatching { srcFile.delete() }
            setImporting(false)
            val r = result.getOrNull()
            if (r == null) {
                runCatching { outFile.delete() }
                Toast.makeText(this@MainActivity, getString(R.string.searchable_failed), Toast.LENGTH_LONG).show()
                return@launch
            }
            if (r.pagesOcr == 0) {
                // Nothing was added: do not leave a copy of the input lying around as a "new" file.
                runCatching { outFile.delete() }
                val msg = if (r.pagesSkippedHadText > 0 && r.pagesWithoutText == 0) R.string.searchable_all_have_text
                else R.string.searchable_nothing
                Toast.makeText(this@MainActivity, getString(msg), Toast.LENGTH_LONG).show()
                return@launch
            }
            val sb = StringBuilder(getString(R.string.searchable_success, r.pagesOcr, r.words))
            if (r.pagesSkippedHadText > 0) sb.append(getString(R.string.searchable_skipped_suffix, r.pagesSkippedHadText))
            if (r.structureOptimized) sb.append(getString(R.string.compress_structure_note))
            val check = r.extractionCheckPercent
            if (check != null) {
                sb.append(
                    if (check >= 70) getString(R.string.searchable_check_ok, check)
                    else getString(R.string.searchable_check_low, check)
                )
            }
            Toast.makeText(this@MainActivity, sb.toString(), Toast.LENGTH_LONG).show()
            refreshHistory()
        }
    }

    /** PdfBox's PDDocument.load(File) needs a real file path to read from (unlike the rest of this app, which mostly reads
     *  SAF [Uri]s straight via [android.content.ContentResolver]) - copies the picked PDF into the
     *  app's own temp dir first. Deleted right after [runDirectEditCompression] finishes with it. */
    private fun copyUriToTempPdfFile(uri: Uri): File? {
        return try {
            val file = File(FileUtils.tempDir(this), "COMPRESS_SRC_${System.currentTimeMillis()}.pdf")
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            } ?: return null
            file
        } catch (e: Exception) {
            null
        }
    }

    private fun copyUriToFile(uri: Uri, index: Int): String? {
        return try {
            val file = FileUtils.newImportedFile(this, index)
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(file).use { output -> input.copyTo(output) }
            }
            file.absolutePath
        } catch (e: Exception) {
            null
        }
    }

    private fun setImporting(show: Boolean) {
        if (show) {
            // exactly ONE acquire per progress dialog, released when it goes away (see KeepAlive, TECHNICAL_DOCS.md 4.38)
            if (importingDialog == null) com.example.docscanner.util.KeepAlive.acquire(this) else importingDialog?.dismiss()
            importingDialog = ProgressDialog.show(this, null, getString(R.string.importing_progress), true, false)
            // a long job must not be cut short by the screen timing out and the system suspending the app (see TECHNICAL_DOCS.md 4.37)
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            askNotificationPermissionOnce()
        } else {
            if (importingDialog != null) com.example.docscanner.util.KeepAlive.release()
            importingDialog?.dismiss()
            importingDialog = null
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* the service runs either way; the permission only lets the person SEE its notification */ }

    /** Android 13+: asks once (ever) so the "processing" notification of [com.example.docscanner.util.KeepAlive] is visible. Never blocks and never asks again. */
    private fun askNotificationPermissionOnce() {
        if (android.os.Build.VERSION.SDK_INT < 33) return
        if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) return
        val prefs = getSharedPreferences("keepalive", MODE_PRIVATE)
        if (prefs.getBoolean("asked_notifications", false)) return
        prefs.edit().putBoolean("asked_notifications", true).apply()
        notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
    }

    override fun onDestroy() {
        // the Activity can die while a progress dialog is up: release the foreground service it asked for, or it would run for ever
        if (importingDialog != null) {
            importingDialog?.dismiss()
            importingDialog = null
            com.example.docscanner.util.KeepAlive.release()
        }
        super.onDestroy()
    }

    /**
     * The "Khoá ứng dụng" switch. Turning it ON needs a screen lock or a biometric on the device (otherwise nothing
     * could ever answer the prompt) and a successful authentication first, so the user knows it works before it can
     * lock them out; turning it OFF needs an authentication too, so someone who merely picks up an unlocked phone
     * cannot remove the protection. [lockSwitchBusy] stops the programmatic revert from re-triggering the listener.
     */
    private var lockSwitchBusy = false

    private fun setupAppLockSwitch() {
        binding.switchAppLock.isChecked = com.example.docscanner.util.AppLock.isEnabled(this)
        updateLockDelayRow()
        binding.tvLockDelay.setOnClickListener { showLockDelayDialog() }
        binding.switchAppLock.setOnCheckedChangeListener { button, checked ->
            if (lockSwitchBusy) return@setOnCheckedChangeListener
            fun revert(to: Boolean) {
                lockSwitchBusy = true
                button.isChecked = to
                lockSwitchBusy = false
            }
            if (checked) {
                if (!com.example.docscanner.util.AppLock.isSupported(this)) {
                    Toast.makeText(this, R.string.lock_not_supported, Toast.LENGTH_LONG).show()
                    revert(false)
                    return@setOnCheckedChangeListener
                }
                com.example.docscanner.util.AppLock.authenticate(this, getString(R.string.lock_enable_prompt)) { ok ->
                    if (ok) {
                        com.example.docscanner.util.AppLock.setEnabled(this, true)
                        com.example.docscanner.util.AppLock.markUnlocked()
                        window.setFlags(
                            android.view.WindowManager.LayoutParams.FLAG_SECURE,
                            android.view.WindowManager.LayoutParams.FLAG_SECURE
                        )
                        updateLockDelayRow()
                    } else {
                        revert(false)
                    }
                }
            } else {
                com.example.docscanner.util.AppLock.authenticate(this, getString(R.string.lock_disable_prompt)) { ok ->
                    if (ok) {
                        com.example.docscanner.util.AppLock.setEnabled(this, false)
                        window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
                        updateLockDelayRow()
                    } else {
                        revert(true)
                    }
                }
            }
        }
    }

    /**
     * Search inside one EPUB (PDF list C7; util.EpubSearch): ignores case and accents; the hits - chapter, then the text around each match
     * with the match between « and » - open in the plain text screen, where they can be copied.
     */
    private fun searchInEpub(file: File) {
        askText(R.string.epub_search_title, R.string.epub_search_hint, false) { typed ->
            val query = typed.trim()
            if (query.isEmpty()) return@askText
            setImporting(true)
            lifecycleScope.launch {
                val found = withContext(Dispatchers.Default) {
                    runCatching {
                        val chapters = com.example.docscanner.util.EpubReader.read(file)
                        val total = IntArray(1)
                        val hits = com.example.docscanner.util.EpubSearch.search(chapters, query, totalHits = total)
                        Triple(chapters, hits, total[0])
                    }.getOrNull()
                }
                setImporting(false)
                if (found == null) { Toast.makeText(this@MainActivity, R.string.textexport_failed, Toast.LENGTH_LONG).show(); return@launch }
                val (chapters, hits, total) = found
                if (hits.isEmpty()) { Toast.makeText(this@MainActivity, getString(R.string.epub_search_none, query), Toast.LENGTH_LONG).show(); return@launch }
                val text = com.example.docscanner.util.EpubSearch.render(
                    hits, chapters, getString(R.string.epub_search_header, query, total),
                    if (total > hits.size) getString(R.string.epub_search_more, hits.size) else null
                ) { number, title -> if (title.isEmpty()) getString(R.string.epub_search_chapter_n, number) else getString(R.string.epub_search_chapter, number, title) }
                val out = File(FileUtils.tempDir(this@MainActivity), "epub_search_" + System.currentTimeMillis() + ".txt")
                val written = runCatching { out.writeText(text, Charsets.UTF_8) }.isSuccess
                if (!written) { Toast.makeText(this@MainActivity, R.string.textexport_failed, Toast.LENGTH_LONG).show(); return@launch }
                startActivity(Intent(this@MainActivity, TextResultActivity::class.java).putExtra(TextResultActivity.EXTRA_TEXT_FILE_PATH, out.absolutePath))
            }
        }
    }

    // ---- "Translate a photo": system camera -> on-device OCR -> on-device translation (PDF list N10, as a single photo rather than a live overlay) ----

    private fun startSnapTranslate() {
        val dir = File(cacheDir, "translate_snap").apply { mkdirs() }
        dir.listFiles()?.forEach { runCatching { it.delete() } }                       // one photo at a time; nothing is kept
        val photo = File(dir, "snap_" + System.currentTimeMillis() + ".jpg")
        snapFile = photo
        snapLauncher.launch(FileProvider.getUriForFile(this, "$packageName.fileprovider", photo))
    }

    /** Reads the photo with ML Kit: Latin first; when that finds almost no letters, the CJK and Devanagari readers too, keeping whichever found most. */
    private fun readSnap(photo: File) {
        setImporting(true)
        lifecycleScope.launch {
            val text = withContext(Dispatchers.Default) {
                val bitmap = android.graphics.BitmapFactory.decodeFile(photo.absolutePath) ?: return@withContext ""
                try {
                    val ocr = com.example.docscanner.util.OcrHelper
                    fun letters(t: String) = t.count { it.isLetter() }
                    var best = runCatching { ocr.recognize(bitmap, com.example.docscanner.util.OcrHelper.OcrScript.LATIN) }.getOrDefault("")
                    if (letters(best) < 8) {
                        for (script in listOf(
                            com.example.docscanner.util.OcrHelper.OcrScript.CHINESE, com.example.docscanner.util.OcrHelper.OcrScript.JAPANESE,
                            com.example.docscanner.util.OcrHelper.OcrScript.KOREAN, com.example.docscanner.util.OcrHelper.OcrScript.DEVANAGARI
                        )) {
                            val t = runCatching { ocr.recognize(bitmap, script) }.getOrDefault("")
                            if (letters(t) > letters(best)) best = t
                        }
                    }
                    best.trim()
                } finally { bitmap.recycle() }
            }
            runCatching { photo.delete() }
            setImporting(false)
            if (text.isBlank()) { Toast.makeText(this@MainActivity, R.string.snap_no_text, Toast.LENGTH_LONG).show(); return@launch }
            val targets = com.example.docscanner.util.TextTranslator.targets
            androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                .setTitle(R.string.translate_pick_target)
                .setItems(targets.map { it.second }.toTypedArray()) { _, which ->
                    androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                        .setMessage(R.string.translate_model_note)
                        .setNegativeButton(R.string.dialog_cancel, null)
                        .setPositiveButton(R.string.translate_continue) { _, _ -> translateSnap(text, targets[which]) }
                        .show()
                }
                .setNegativeButton(R.string.dialog_cancel, null)
                .show()
        }
    }

    private fun translateSnap(text: String, target: Pair<String, String>) {
        val progress = androidx.appcompat.app.AlertDialog.Builder(this).setTitle(R.string.tool_snap_title).setMessage(getString(R.string.translate_working, 0, 0)).setCancelable(false).create()
        progress.show()
        lifecycleScope.launch {
            val source = runCatching { com.example.docscanner.util.TextTranslator.identify(text) }.getOrNull()
            if (source == null || source == target.first) {
                progress.dismiss()
                Toast.makeText(this@MainActivity, if (source == null) R.string.translate_unknown_language else R.string.translate_same_language, Toast.LENGTH_LONG).show()
                return@launch
            }
            val translated = runCatching {
                com.example.docscanner.util.TextTranslator.translate(text, source, target.first) { i, n -> progress.setMessage(getString(R.string.translate_working, i, n)) }
            }.getOrNull()
            progress.dismiss()
            if (translated.isNullOrBlank()) { Toast.makeText(this@MainActivity, R.string.translate_failed, Toast.LENGTH_LONG).show(); return@launch }
            androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                .setTitle(target.second)
                .setMessage(translated.take(4000) + (if (translated.length > 4000) "…" else ""))
                .setPositiveButton(R.string.btn_copy_text) { _, _ ->
                    (getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                        .setPrimaryClip(android.content.ClipData.newPlainText("translation", translated))
                    Toast.makeText(this@MainActivity, R.string.text_copied, Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton(R.string.dialog_ok, null)
                .show()
        }
    }

    // ---- in-app text size (PDF list I4; util.FontScale, applied by BaseActivity) ----

    private fun textSizeLabels(): Array<String> = arrayOf(
        getString(R.string.text_size_1), getString(R.string.text_size_2), getString(R.string.text_size_3), getString(R.string.text_size_4)
    )

    private fun updateTextSizeRow() {
        binding.tvTextSize.text = getString(R.string.text_size_link, textSizeLabels()[com.example.docscanner.util.FontScale.index(this)])
    }

    /** A RadioGroup under the explanation (an AlertDialog with a message does not show list items); choosing reloads this screen with the new size. */
    private fun showTextSizeDialog() {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        box.addView(android.widget.TextView(this).apply { setText(R.string.text_size_help); textSize = 13f; setPadding(0, 0, 0, pad / 2) })
        val group = android.widget.RadioGroup(this)
        val base = 8000
        val current = com.example.docscanner.util.FontScale.index(this)
        textSizeLabels().forEachIndexed { i, label -> group.addView(android.widget.RadioButton(this).apply { id = base + i; text = label; isChecked = i == current }) }
        box.addView(group)
        // PDF I6: the "Easy-to-read font" (Lexend) switch lives in the same dialog; applied by BaseActivity on the next screen creation, so this one is recreated.
        val readable = android.widget.CheckBox(this).apply {
            setText(R.string.readable_font_option)
            isChecked = com.example.docscanner.util.ReadableFont.isOn(this@MainActivity)
            setPadding(0, pad / 2, 0, 0)
        }
        box.addView(readable)
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this).setTitle(R.string.text_size_title).setView(box).setNegativeButton(R.string.dialog_cancel, null).create()
        readable.setOnCheckedChangeListener { _, checked ->
            com.example.docscanner.util.ReadableFont.setOn(this, checked)
            dialog.dismiss()
            recreate()
        }
        group.setOnCheckedChangeListener { _, checkedId ->
            val chosen = checkedId - base
            dialog.dismiss()
            if (chosen != current) {
                com.example.docscanner.util.FontScale.setIndex(this, chosen)
                recreate()
            }
        }
        dialog.show()
    }

    // ---- webhook: tell a web address when a new document appears (PDF list F7; util.DocumentWebhook) ----

    private var webhookJob: kotlinx.coroutines.Job? = null

    /** The row shows only when the build has the INTERNET permission (same switch as the link import). */
    private fun updateWebhookRow() {
        val available = WifiScanActivity.isAvailable(this)
        binding.tvWebhook.visibility = if (available) android.view.View.VISIBLE else android.view.View.GONE
        val state = if (com.example.docscanner.util.DocumentWebhook.isOn(this)) R.string.webhook_state_on else R.string.webhook_state_off
        binding.tvWebhook.text = getString(R.string.webhook_link, getString(state))
    }

    private fun showWebhookDialog() {
        val hook = com.example.docscanner.util.DocumentWebhook
        val pad = (20 * resources.displayMetrics.density).toInt()
        val address = android.widget.EditText(this).apply {
            setHint(R.string.link_url_hint)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine(); setText(hook.url(this@MainActivity))
        }
        val secret = android.widget.EditText(this).apply {
            setHint(R.string.webhook_secret_hint)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine(); setText(hook.secret(this@MainActivity))
        }
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(android.widget.TextView(this@MainActivity).apply { setText(R.string.webhook_help); textSize = 13f; setPadding(0, 0, 0, pad / 2) })
            addView(address); addView(secret)
        }
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.webhook_title)
            .setView(box)
            .setPositiveButton(R.string.webhook_save, null)           // set below: a bad address keeps the dialog open
            .setNeutralButton(R.string.webhook_test, null)
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
        dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val text = address.text.toString().trim()
            if (text.isNotEmpty() && com.example.docscanner.util.LinkImport.parse(text) == null) {
                Toast.makeText(this, R.string.link_bad_url, Toast.LENGTH_LONG).show()
            } else {
                hook.save(this, text, secret.text.toString(), historyAll.map { it.name })      // empty address = webhook off
                updateWebhookRow()
                dialog.dismiss()
            }
        }
        dialog.getButton(android.content.DialogInterface.BUTTON_NEUTRAL).setOnClickListener {
            val url = com.example.docscanner.util.LinkImport.parse(address.text.toString())
            if (url == null) { Toast.makeText(this, R.string.link_bad_url, Toast.LENGTH_LONG).show(); return@setOnClickListener }
            val key = secret.text.toString()
            lifecycleScope.launch {
                val ok = withContext(Dispatchers.IO) { hook.post(url, hook.testPayload(System.currentTimeMillis()), key) }
                Toast.makeText(this@MainActivity, if (ok) R.string.webhook_test_ok else R.string.webhook_test_fail, Toast.LENGTH_LONG).show()
            }
        }
    }

    /** New, recent documents not yet announced go out one message each; what was delivered is remembered, what failed is tried again on the next refresh. */
    private fun maybeSendWebhooks(files: List<File>) {
        val hook = com.example.docscanner.util.DocumentWebhook
        if (!hook.isOn(this) || webhookJob?.isActive == true) return
        val url = com.example.docscanner.util.LinkImport.parse(hook.url(this)) ?: return
        val secret = hook.secret(this)
        val seen = hook.seen(this)
        val now = System.currentTimeMillis()
        val stale = files.filter { it.name !in seen && now - it.lastModified() > hook.RECENT_MS }.map { it.name }
        if (stale.isNotEmpty()) hook.markSeen(this, stale)                         // too old to announce: never retried
        val due = hook.pending(seen, files.map { it.name to it.lastModified() }, now)
        if (due.isEmpty()) return
        val byName = files.associateBy { it.name }
        webhookJob = lifecycleScope.launch {
            val delivered = withContext(Dispatchers.IO) {
                due.filter { name ->
                    val f = byName[name]
                    f != null && hook.post(url, hook.payload(f.name, f.length(), f.lastModified()), secret)
                }
            }
            if (delivered.isNotEmpty()) hook.markSeen(this@MainActivity, delivered)
        }
    }

    // ---- import from a web link / the clipboard (PDF list L7, L6; util.LinkImport) ----

    private fun showLinkImportMenu() {
        val entries = ArrayList<Pair<Int, () -> Unit>>()
        // downloading needs the INTERNET permission, which a build may leave out (same switch as the Wi-Fi scanner card)
        if (WifiScanActivity.isAvailable(this)) entries.add(R.string.link_from_url to { askLinkUrl(clipboardLinkOrEmpty()) })
        entries.add(R.string.link_from_clip to { importFromClipboard() })
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.link_menu_title)
            .setItems(entries.map { getString(it.first) }.toTypedArray()) { _, which -> entries[which].second() }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun clipboardText(): String? {
        val clip = (getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).primaryClip ?: return null
        if (clip.itemCount == 0) return null
        return clip.getItemAt(0).coerceToText(this)?.toString()?.trim()?.takeIf { it.isNotEmpty() }
    }

    /** A copied web link is offered in the box already, so the usual case is one tap on "Download". */
    private fun clipboardLinkOrEmpty(): String = clipboardText()?.takeIf { !it.contains('\n') && com.example.docscanner.util.LinkImport.parse(it) != null } ?: ""

    private fun askLinkUrl(prefill: String) {
        val input = android.widget.EditText(this).apply {
            setHint(R.string.link_url_hint)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setSingleLine()
            setText(prefill)
            setSelectAllOnFocus(true)
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = android.widget.FrameLayout(this).apply { setPadding(pad, pad / 2, pad, 0); addView(input) }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.link_url_title)
            .setView(holder)
            .setPositiveButton(R.string.link_download) { _, _ -> importFromLink(input.text.toString()) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    /** Downloads one PDF or picture: a PDF is saved into the document list, a picture goes to the crop queue like a gallery import. */
    private fun importFromLink(text: String) {
        val url = com.example.docscanner.util.LinkImport.parse(text)
        if (url == null) { Toast.makeText(this, R.string.link_bad_url, Toast.LENGTH_LONG).show(); return }
        setImporting(true)
        lifecycleScope.launch {
            val temp = File(FileUtils.tempDir(this@MainActivity), "link_" + System.currentTimeMillis() + ".part")
            val result = runCatching {
                com.example.docscanner.util.KeepAlive.during(applicationContext) {
                    withContext(Dispatchers.IO) { com.example.docscanner.util.LinkImport.download(url, temp) }
                }
            }
            val got = result.getOrNull()
            if (got == null) {
                setImporting(false)
                runCatching { temp.delete() }
                val reason = (result.exceptionOrNull() as? com.example.docscanner.util.LinkImport.LinkException)?.reason
                val message = when (reason) {
                    com.example.docscanner.util.LinkImport.Reason.TOO_BIG -> getString(R.string.link_too_big, (com.example.docscanner.util.LinkImport.MAX_BYTES / (1024 * 1024)).toInt())
                    com.example.docscanner.util.LinkImport.Reason.UNSUPPORTED -> getString(R.string.link_not_supported)
                    com.example.docscanner.util.LinkImport.Reason.BAD_URL -> getString(R.string.link_bad_url)
                    else -> getString(R.string.link_failed)
                }
                Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
                return@launch
            }
            if (got.extension == "pdf") {
                val out = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), got.suggestedName.removeSuffix(".pdf"), "pdf")
                val moved = withContext(Dispatchers.IO) { temp.renameTo(out) || runCatching { temp.copyTo(out, overwrite = true); temp.delete(); true }.getOrDefault(false) }
                setImporting(false)
                if (!moved) { runCatching { out.delete() }; Toast.makeText(this@MainActivity, R.string.link_failed, Toast.LENGTH_LONG).show(); return@launch }
                refreshHistory()
                Toast.makeText(this@MainActivity, getString(R.string.textexport_done, out.name), Toast.LENGTH_LONG).show()
            } else {
                setImporting(false)
                importGalleryImages(listOf(Uri.fromFile(temp)))      // the temp file is swept by cleanOldCacheFiles
            }
        }
    }

    /** A copied picture goes to the crop queue, a copied PDF into the list; copied text can be downloaded (if it is a link), saved as .txt or made into a PDF. */
    private fun importFromClipboard() {
        val clip = (getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager).primaryClip
        val item = if (clip != null && clip.itemCount > 0) clip.getItemAt(0) else null
        val uri = item?.uri
        if (uri != null) {
            val type = runCatching { contentResolver.getType(uri) }.getOrNull().orEmpty()
            if (type.startsWith("image/")) { importGalleryImages(listOf(uri)); return }
            if (type == "application/pdf") { savePdfFromUri(uri); return }
        }
        val text = clipboardText()
        if (text == null) { Toast.makeText(this, R.string.link_clip_empty, Toast.LENGTH_LONG).show(); return }
        val entries = ArrayList<Pair<Int, () -> Unit>>()
        if (WifiScanActivity.isAvailable(this) && !text.contains('\n') && com.example.docscanner.util.LinkImport.parse(text) != null) {
            entries.add(R.string.link_clip_download to { importFromLink(text) })
        }
        entries.add(R.string.link_clip_txt to { saveClipboardText(text, asPdf = false) })
        entries.add(R.string.link_clip_pdf to { saveClipboardText(text, asPdf = true) })
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.link_clip_title)
            .setItems(entries.map { getString(it.first) }.toTypedArray()) { _, which -> entries[which].second() }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun savePdfFromUri(uri: Uri) {
        setImporting(true)
        lifecycleScope.launch {
            val out = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), "clipboard_" + FileUtils.defaultDocName().removePrefix("scan_"), "pdf")
            val ok = withContext(Dispatchers.IO) {
                runCatching { contentResolver.openInputStream(uri)!!.use { input -> out.outputStream().use { input.copyTo(it) } }; true }.getOrDefault(false)
            }
            setImporting(false)
            if (!ok) { runCatching { out.delete() }; Toast.makeText(this@MainActivity, R.string.link_failed, Toast.LENGTH_LONG).show(); return@launch }
            refreshHistory()
            Toast.makeText(this@MainActivity, getString(R.string.textexport_done, out.name), Toast.LENGTH_LONG).show()
        }
    }

    private fun saveClipboardText(text: String, asPdf: Boolean) {
        setImporting(true)
        lifecycleScope.launch {
            val stamp = "clipboard_" + FileUtils.defaultDocName().removePrefix("scan_")
            val out = com.example.docscanner.util.SmartNamer.uniqueFile(PdfExporter.exportDir(this@MainActivity), stamp, if (asPdf) "pdf" else "txt")
            val ok = withContext(Dispatchers.Default) {
                runCatching {
                    if (asPdf) {
                        val paragraphs = com.example.docscanner.util.DocxWriter.paragraphsFromText(text)
                        val title = paragraphs.firstOrNull()?.take(60)?.trim().orEmpty().ifEmpty { getString(R.string.ebook_default_title) }
                        com.example.docscanner.util.TextPdfBuilder.build(out, listOf(com.example.docscanner.util.EbookBuilder.Chapter(title, paragraphs)))
                    } else out.writeText(text, Charsets.UTF_8)
                    true
                }.getOrDefault(false)
            }
            setImporting(false)
            if (!ok) { runCatching { out.delete() }; Toast.makeText(this@MainActivity, R.string.textexport_failed, Toast.LENGTH_LONG).show(); return@launch }
            refreshHistory()
            Toast.makeText(this@MainActivity, getString(R.string.textexport_done, out.name), Toast.LENGTH_LONG).show()
        }
    }

    private fun lockDelayLabels(): Array<String> = arrayOf(
        getString(R.string.lock_delay_5s), getString(R.string.lock_delay_1m), getString(R.string.lock_delay_5m),
        getString(R.string.lock_delay_15m), getString(R.string.lock_delay_30m)
    )

    /** The "Lock again after: ..." row shows only while the lock is on, with the current choice. */
    private fun updateLockDelayRow() {
        val on = com.example.docscanner.util.AppLock.isEnabled(this)
        binding.tvLockDelay.visibility = if (on) android.view.View.VISIBLE else android.view.View.GONE
        binding.tvLockDelay.text = getString(R.string.lock_delay_link, lockDelayLabels()[com.example.docscanner.util.AppLock.graceIndex(this)])
    }

    /**
     * Changing the delay does not ask for authentication: it only decides how soon the app asks AGAIN. Built with a RadioGroup under the
     * explanation (an AlertDialog that has a message does not show its list items, so setMessage + setSingleChoiceItems cannot be combined).
     */
    private fun showLockDelayDialog() {
        val density = resources.displayMetrics.density
        val pad = (20 * density).toInt()
        val box = android.widget.LinearLayout(this).apply { orientation = android.widget.LinearLayout.VERTICAL; setPadding(pad, pad / 2, pad, 0) }
        box.addView(android.widget.TextView(this).apply { setText(R.string.lock_delay_help); textSize = 13f; setPadding(0, 0, 0, pad / 2) })
        val group = android.widget.RadioGroup(this)
        val base = 7000                       // view ids of the radio buttons: base + index of the choice
        val current = com.example.docscanner.util.AppLock.graceIndex(this)
        lockDelayLabels().forEachIndexed { i, label ->
            group.addView(android.widget.RadioButton(this).apply { id = base + i; text = label; isChecked = i == current })
        }
        box.addView(group)
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.lock_delay_title)
            .setView(box)
            .setNegativeButton(R.string.dialog_cancel, null)
            .create()
        group.setOnCheckedChangeListener { _, checkedId ->
            com.example.docscanner.util.AppLock.setGraceIndex(this, checkedId - base)
            updateLockDelayRow()
            dialog.dismiss()
        }
        dialog.show()
    }

    // ---- compare two PDFs by looking at them (see util.PdfComparer) ----

    private fun runCompare(oldUri: Uri, newUri: Uri) {
        val progress = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.tool_compare_title)
            .setMessage(getString(R.string.compare_progress, 1, 1))
            .setCancelable(false)
            .create()
        progress.show()
        lifecycleScope.launch {
            // two different temp-name schemes on purpose: both files must exist at the same time
            val oldFile = withContext(Dispatchers.IO) { copyUriToTempPdfFile(oldUri) }
            val newFile = withContext(Dispatchers.IO) { FileUtils.copyUriToTempFile(this@MainActivity, newUri, ".pdf") }
            val report = File(PdfExporter.exportDir(this@MainActivity), "${FileUtils.defaultSecurityName("compare")}.pdf")
            val result = if (oldFile == null || newFile == null) {
                Result.failure(java.io.IOException("copy"))
            } else {
                runCatching {
                    withContext(Dispatchers.Default) {
                        com.example.docscanner.util.PdfComparer.compare(oldFile, newFile, report) { page, total ->
                            runOnUiThread { progress.setMessage(getString(R.string.compare_progress, page, total)) }
                        }
                    }
                }
            }
            runCatching { oldFile?.delete() }
            runCatching { newFile?.delete() }
            progress.dismiss()
            val r = result.getOrNull()
            if (r == null) {
                runCatching { report.delete() }
                Toast.makeText(this@MainActivity, R.string.compare_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            refreshHistory()
            val sb = StringBuilder()
            sb.append(getString(R.string.compare_result_matched, r.matched, r.pagesOld, r.pagesNew)).append("\n\n")
            if (r.identical) {
                sb.append(getString(R.string.compare_result_same))
            } else {
                if (r.changed.isNotEmpty()) sb.append(getString(R.string.compare_result_diff, r.changed.size, r.changed.take(30).joinToString(", "))).append("\n")
                if (r.added.isNotEmpty()) sb.append(getString(R.string.compare_result_added, r.added.take(30).joinToString(", "))).append("\n")
                if (r.removed.isNotEmpty()) sb.append(getString(R.string.compare_result_removed, r.removed.take(30).joinToString(", "))).append("\n")
            }
            if (r.reportWritten) sb.append("\n").append(getString(R.string.compare_report_saved, report.name))
            androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                .setMessage(sb.toString())
                .setPositiveButton(R.string.dialog_ok, null)
                .show()
        }
    }

    // ---- ID card / passport on one A4 page (see util.IdCardComposer) ----

    private fun showIdCardPresetMenu() {
        val presets = com.example.docscanner.util.IdCardComposer.Preset.values()   // ID1, ID3 - same order as the labels
        val labels = arrayOf(getString(R.string.idcard_preset_id1), getString(R.string.idcard_preset_id3))
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.tool_idcard_title)
            .setItems(labels) { _, which ->
                pendingIdPreset = presets[which]
                Toast.makeText(this, R.string.idcard_pick_front, Toast.LENGTH_SHORT).show()
                idFrontPicker.launch(arrayOf("image/*"))
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun askIdCardBack() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.idcard_ask_back_title)
            .setPositiveButton(R.string.idcard_back_btn) { _, _ -> idBackPicker.launch(arrayOf("image/*")) }
            .setNegativeButton(R.string.idcard_front_only) { _, _ -> pendingIdFront?.let { runIdCard(listOf(it)) } }
            .show()
    }

    /**
     * [flips] says which cards the user asked to turn 180 degrees; [previous] is the file of an earlier try that this one
     * replaces. When the text could not tell which way up a card is, the user is asked (see [askIdCardOrientation]).
     */
    private fun runIdCard(uris: List<Uri>, flips: BooleanArray = BooleanArray(uris.size), previous: File? = null) {
        val preset = pendingIdPreset
        setImporting(true)
        val outFile = File(PdfExporter.exportDir(this), "${FileUtils.defaultSecurityName("idcard")}.pdf")
        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.Default) {
                    val cards = ArrayList<android.graphics.Bitmap>()
                    val known = ArrayList<Boolean>()
                    try {
                        for ((i, uri) in uris.withIndex()) {
                            val tmp = FileUtils.copyUriToTempFile(this@MainActivity, uri, ".jpg") ?: throw java.io.IOException("copy")
                            val decoded = try {
                                FileUtils.decodeBitmapWithExifOrientation(tmp.absolutePath)
                            } finally {
                                runCatching { tmp.delete() }
                            } ?: throw java.io.IOException("decode")
                            val small = ImageProcessor.downscaleTo(decoded, 2400)
                            val prepared = com.example.docscanner.util.IdCardComposer.prepare(small, preset, flips[i])
                            if (small !== decoded) decoded.recycle()
                            if (prepared.bitmap !== small) small.recycle()
                            cards.add(prepared.bitmap)
                            known.add(prepared.orientationKnown || flips[i])   // a card the user turned by hand is settled
                        }
                        com.example.docscanner.util.IdCardComposer.compose(cards, preset, outFile)
                    } finally {
                        cards.forEach { runCatching { it.recycle() } }
                    }
                    known.toList()
                }
            }
            setImporting(false)
            val known = result.getOrNull()
            if (known == null) {
                runCatching { outFile.delete() }
                Toast.makeText(this@MainActivity, R.string.idcard_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            previous?.let { runCatching { it.delete() } }
            refreshHistory()
            val unsure = known.indices.filter { !known[it] }
            if (unsure.isEmpty()) {
                Toast.makeText(this@MainActivity, getString(R.string.idcard_done, outFile.name), Toast.LENGTH_LONG).show()
            } else {
                askIdCardOrientation(uris, flips, unsure, outFile)
            }
        }
    }

    /** The text of some card was too sparse to tell which way is up: show the result and offer a half turn per such card. */
    private fun askIdCardOrientation(uris: List<Uri>, flips: BooleanArray, unsure: List<Int>, outFile: File) {
        fun label(index: Int): String = when {
            uris.size == 1 -> getString(R.string.idcard_flip_one)
            index == 0 -> getString(R.string.idcard_flip_front)
            else -> getString(R.string.idcard_flip_back)
        }
        fun flipped(index: Int): BooleanArray = flips.copyOf().also { it[index] = !it[index] }
        val builder = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.idcard_check_title)
            .setMessage(getString(R.string.idcard_unsure_message, outFile.name))
            .setNegativeButton(R.string.idcard_keep, null)
            .setPositiveButton(label(unsure[0])) { _, _ -> runIdCard(uris, flipped(unsure[0]), outFile) }
        if (unsure.size > 1) {
            builder.setNeutralButton(label(unsure[1])) { _, _ -> runIdCard(uris, flipped(unsure[1]), outFile) }
        }
        builder.show()
    }

    // ---- batch: one operation on many PDFs (see util.BatchProcessor) ----

    private fun queryDisplayName(uri: Uri): String? = runCatching {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()

    private fun showBatchMenu(uris: List<Uri>) {
        val ops = com.example.docscanner.util.BatchProcessor.Op.values()   // same order as the labels
        val labels = arrayOf(
            getString(R.string.batch_op_number),
            getString(R.string.batch_op_watermark),
            getString(R.string.batch_op_password),
            getString(R.string.batch_op_strip),
            getString(R.string.batch_op_twoup),
            getString(R.string.batch_op_compress)
        )
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.tool_batch_title) + " (" + uris.size + ")")
            .setItems(labels) { _, which ->
                val op = ops[which]
                when (op) {
                    com.example.docscanner.util.BatchProcessor.Op.WATERMARK ->
                        askText(R.string.security_watermark, R.string.security_watermark_hint, secret = false) { runBatch(uris, op, it) }
                    com.example.docscanner.util.BatchProcessor.Op.PASSWORD ->
                        askText(R.string.security_set_password, R.string.security_password_hint, secret = true) { runBatch(uris, op, it) }
                    else -> runBatch(uris, op, "")
                }
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun runBatch(uris: List<Uri>, op: com.example.docscanner.util.BatchProcessor.Op, argument: String) {
        // PDF 2.15 / 2.16: a nearly empty battery or a hot phone is said BEFORE a long job (nothing is shown when all is well; util.DeviceLoad).
        com.example.docscanner.util.DeviceLoad.guard(this) { runBatchNow(uris, op, argument) }
    }

    /**
     * Same copy as [copyUriToTempPdfFile] but the failure is THROWN, so [com.example.docscanner.util.TaskFailures.retrying] can tell a busy / locked file
     * (try again in a moment) from a broken one or a full disk. null still means "the provider gave no stream".
     */
    private fun copyUriToTempPdfFileOrThrow(uri: Uri): File? {
        val file = File(FileUtils.tempDir(this), "COMPRESS_SRC_${System.nanoTime()}.pdf")
        try {
            val input = contentResolver.openInputStream(uri) ?: return null
            input.use { source -> FileOutputStream(file).use { output -> source.copyTo(output) } }
        } catch (e: Exception) {
            runCatching { file.delete() }
            throw e
        }
        return file
    }

    /**
     * One operation on many PDFs, one file at a time ([com.example.docscanner.util.BatchQueue]): the Stop button lets the file in progress finish and does not
     * start the rest; a busy / locked file is tried again (PDF 2.9); a full disk stops the whole run instead of failing every following file (PDF 2.10);
     * the run is kept alive while the app is in the background ([com.example.docscanner.util.KeepAlive], PDF F4).
     */
    private fun runBatchNow(uris: List<Uri>, op: com.example.docscanner.util.BatchProcessor.Op, argument: String) {
        val queue = com.example.docscanner.util.BatchQueue(uris.size)
        val progress = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.tool_batch_title)
            .setMessage(getString(R.string.batch_progress, 1, uris.size))
            .setCancelable(false)
            .setNegativeButton(R.string.batch_stop, null)
            .create()
        progress.show()
        // A dialog button closes its dialog by default; Stop must not (the file in progress is still being processed), so it gets its own listener after show().
        progress.getButton(android.content.DialogInterface.BUTTON_NEGATIVE).setOnClickListener { button ->
            queue.stop()
            button.isEnabled = false
            progress.setMessage(getString(R.string.batch_stopping))
        }
        lifecycleScope.launch {
            var ok = 0
            var skippedSigned = 0
            var diskFull = false
            val failed = mutableListOf<String>()
            val dir = PdfExporter.exportDir(this@MainActivity)
            com.example.docscanner.util.KeepAlive.during(applicationContext) {
                while (true) {
                    val i = queue.next()
                    if (i < 0) break
                    val uri = uris[i]
                    progress.setMessage(getString(R.string.batch_progress, i + 1, uris.size))
                    val name = withContext(Dispatchers.IO) { queryDisplayName(uri) } ?: "document.pdf"
                    val copy = withContext(Dispatchers.IO) {
                        runCatching { com.example.docscanner.util.TaskFailures.retrying { copyUriToTempPdfFileOrThrow(uri) } }
                    }
                    val src = copy.getOrNull()
                    if (src == null) {
                        failed.add(name)
                        queue.failed(i)
                        val copyError = copy.exceptionOrNull()
                        if (copyError != null && com.example.docscanner.util.TaskFailures.classify(copyError) == com.example.docscanner.util.TaskFailure.DISK_FULL) {
                            diskFull = true
                            queue.stop()
                        }
                        continue
                    }
                    // PDF da ky so (PDF "Thieu gi de ban app" 2.6): moi phep hang loat ghi file MOI nen chu ky cua file moi se mat.
                    // Hoi tung file ky; nguoi dung tu choi = bo qua file do (khong tinh la loi) va dem rieng de bao cuoi.
                    if (!com.example.docscanner.util.SignedPdfGuard.confirm(this@MainActivity, src)) {
                        runCatching { src.delete() }
                        skippedSigned++
                        queue.skipped(i)
                        continue
                    }
                    val outFile = com.example.docscanner.util.SmartNamer.uniqueFile(
                        dir, com.example.docscanner.util.SmartNamer.derivedBase(name, op.suffix), "pdf"
                    )
                    val result = runCatching {
                        withContext(Dispatchers.Default) {
                            com.example.docscanner.util.TaskFailures.retrying { com.example.docscanner.util.BatchProcessor.apply(op, argument, src, outFile) }
                        }
                    }
                    runCatching { src.delete() }
                    val error = result.exceptionOrNull()
                    if (error == null) {
                        ok++
                        queue.done(i)
                    } else {
                        runCatching { outFile.delete() }
                        failed.add(name)
                        queue.failed(i)
                        if (com.example.docscanner.util.TaskFailures.classify(error) == com.example.docscanner.util.TaskFailure.DISK_FULL) {
                            diskFull = true
                            queue.stop()
                        }
                    }
                }
            }
            progress.dismiss()
            refreshHistory()
            val notStarted = queue.count(com.example.docscanner.util.BatchQueue.State.STOPPED)
            val message = getString(R.string.batch_summary, ok, failed.size) +
                (if (skippedSigned == 0) "" else "\n" + getString(R.string.batch_skipped_signed, skippedSigned)) +
                (if (notStarted == 0) "" else "\n" + getString(R.string.batch_stopped_count, notStarted)) +
                (if (!diskFull) "" else "\n" + getString(R.string.batch_disk_full)) +
                (if (failed.isEmpty()) "" else "\n\n" + getString(R.string.batch_failed_list, failed.take(10).joinToString("\n")))
            androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                .setMessage(message)
                .setPositiveButton(R.string.dialog_ok, null)
                .show()
        }
    }

    // ---- N-up / booklet (see util.PdfImposer) ----

    private fun showImposeMenu(uri: Uri) {
        val modes = com.example.docscanner.util.PdfImposer.Mode.values()   // TWO_UP, FOUR_UP, BOOKLET - same order as the labels
        val labels = arrayOf(
            getString(R.string.impose_two_up),
            getString(R.string.impose_four_up),
            getString(R.string.impose_booklet),
            getString(R.string.impose_poster)
        )
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.tool_impose_title)
            .setItems(labels) { _, which -> if (which < modes.size) runImpose(uri, modes[which]) else showPosterColsDialog(uri) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    // ---------------------------------------------------------------------------------- QR code (4.47.5)

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    private fun showQrKindDialog() {
        val kinds = arrayOf(getString(R.string.qr_kind_text), getString(R.string.qr_kind_wifi))
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.tool_qr_title)
            .setItems(kinds) { _, which -> if (which == 0) promptQrText() else promptQrWifi() }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun promptQrText() {
        val input = android.widget.EditText(this).apply {
            hint = getString(R.string.qr_text_hint)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.qr_kind_text)
            .setView(input)
            .setPositiveButton(R.string.qr_make) { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) makeQr(text, text)
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun promptQrWifi() {
        val ssid = android.widget.EditText(this).apply { hint = getString(R.string.qr_wifi_ssid_hint); inputType = android.text.InputType.TYPE_CLASS_TEXT }
        val password = android.widget.EditText(this).apply { hint = getString(R.string.qr_wifi_password_hint); inputType = android.text.InputType.TYPE_CLASS_TEXT }
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), dp(8))
            addView(ssid)
            addView(password)
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.qr_kind_wifi)
            .setView(box)
            .setPositiveButton(R.string.qr_make) { _, _ ->
                val name = ssid.text.toString()
                val pass = password.text.toString()
                // the caption names the network but NEVER the password: the sheet may be pinned on a wall
                if (name.isNotBlank()) makeQr(com.example.docscanner.util.QrEncoder.wifiPayload(name, pass, if (pass.isEmpty()) "nopass" else "WPA"), getString(R.string.qr_wifi_caption, name))
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun makeQr(payload: String, caption: String) {
        lifecycleScope.launch {
            val outFile = File(PdfExporter.exportDir(this@MainActivity), "${FileUtils.defaultSecurityName("qr")}.pdf")
            val result = withContext(Dispatchers.Default) {
                val qr = com.example.docscanner.util.QrEncoder.encode(payload, com.example.docscanner.util.QrEncoder.Ecl.MEDIUM)
                    ?: return@withContext -1
                if (com.example.docscanner.util.QrPdfBuilder.build(outFile, qr, caption)) 1 else 0
            }
            when (result) {
                1 -> { refreshHistory(); Toast.makeText(this@MainActivity, getString(R.string.qr_done, outFile.name), Toast.LENGTH_LONG).show() }
                -1 -> Toast.makeText(this@MainActivity, R.string.qr_too_long, Toast.LENGTH_LONG).show()
                else -> { runCatching { outFile.delete() }; Toast.makeText(this@MainActivity, R.string.qr_failed, Toast.LENGTH_LONG).show() }
            }
        }
    }

    /** Poster (4.47.3): the first page enlarged over several A4 sheets; the number of rows follows from the page's proportions. */
    private fun showPosterColsDialog(uri: Uri) {
        val counts = intArrayOf(2, 3, 4, 5)
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.poster_cols_title)
            .setItems(Array(counts.size) { getString(R.string.poster_cols_option, counts[it]) }) { _, which -> runPoster(uri, counts[which]) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun runPoster(uri: Uri, cols: Int) {
        setImporting(true)
        lifecycleScope.launch {
            val src = withContext(Dispatchers.IO) { copyUriToTempPdfFile(uri) }
            if (src == null) {
                setImporting(false)
                Toast.makeText(this@MainActivity, R.string.impose_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            val outFile = File(PdfExporter.exportDir(this@MainActivity), "${FileUtils.defaultSecurityName("poster")}.pdf")
            val result = runCatching {
                withContext(Dispatchers.Default) { com.example.docscanner.util.PdfPoster.poster(src, outFile, 0, cols) }
            }
            runCatching { src.delete() }
            setImporting(false)
            val sheets = result.getOrNull()
            if (sheets == null) {
                runCatching { outFile.delete() }
                val encrypted = result.exceptionOrNull()?.message == "encrypted"
                Toast.makeText(this@MainActivity, if (encrypted) R.string.sign_encrypted else R.string.impose_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            refreshHistory()
            androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                .setMessage(getString(R.string.poster_done, outFile.name, sheets))
                .setPositiveButton(R.string.dialog_ok, null)
                .show()
        }
    }

    private fun runImpose(uri: Uri, mode: com.example.docscanner.util.PdfImposer.Mode) {
        setImporting(true)
        lifecycleScope.launch {
            val src = withContext(Dispatchers.IO) { copyUriToTempPdfFile(uri) }
            if (src == null) {
                setImporting(false)
                Toast.makeText(this@MainActivity, R.string.impose_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            val prefix = when (mode) {
                com.example.docscanner.util.PdfImposer.Mode.TWO_UP -> "nup2"
                com.example.docscanner.util.PdfImposer.Mode.FOUR_UP -> "nup4"
                com.example.docscanner.util.PdfImposer.Mode.BOOKLET -> "booklet"
            }
            val outFile = File(PdfExporter.exportDir(this@MainActivity), "${FileUtils.defaultSecurityName(prefix)}.pdf")
            val result = runCatching {
                withContext(Dispatchers.Default) { com.example.docscanner.util.PdfImposer.impose(src, outFile, mode) }
            }
            runCatching { src.delete() }
            setImporting(false)
            val sheets = result.getOrNull()
            if (sheets == null) {
                runCatching { outFile.delete() }
                val encrypted = result.exceptionOrNull()?.message == "encrypted"
                Toast.makeText(this@MainActivity, if (encrypted) R.string.sign_encrypted else R.string.impose_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            refreshHistory()
            if (mode == com.example.docscanner.util.PdfImposer.Mode.BOOKLET) {
                androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
                    .setMessage(getString(R.string.impose_booklet_hint, outFile.name, sheets))
                    .setPositiveButton(R.string.dialog_ok, null)
                    .show()
            } else {
                Toast.makeText(this@MainActivity, getString(R.string.impose_done, outFile.name, sheets), Toast.LENGTH_LONG).show()
            }
        }
    }

    // ---- backup / restore (see util.BackupManager for what is and is not included, and why) ----

    private fun showBackupDialog() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.backup_dialog_title)
            .setMessage(R.string.backup_dialog_message)
            .setPositiveButton(R.string.backup_action_backup) { _, _ ->
                backupCreator.launch("docscanner_backup_${FileUtils.defaultDocName().removePrefix("scan_")}.zip")
            }
            .setNeutralButton(R.string.backup_action_restore) { _, _ ->
                restorePicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
            }
            .setNegativeButton(R.string.backup_action_schedule) { _, _ -> showAutoBackupDialog() }
            .show()
    }

    /** Scheduled backup (util.AutoBackup, phiên 20): interval, how many to keep, the folder; shows the last result or error. */
    private fun showAutoBackupDialog() {
        val s = com.example.docscanner.util.AutoBackup.settings(this)
        val intervals = listOf(
            com.example.docscanner.util.BackupSchedule.Interval.OFF to R.string.autobackup_off,
            com.example.docscanner.util.BackupSchedule.Interval.DAILY to R.string.autobackup_daily,
            com.example.docscanner.util.BackupSchedule.Interval.WEEKLY to R.string.autobackup_weekly,
            com.example.docscanner.util.BackupSchedule.Interval.MONTHLY to R.string.autobackup_monthly
        )
        val keeps = listOf(3, 5, 10, 30)
        fun spinner(items: List<String>, selected: Int) = android.widget.Spinner(this).apply {
            adapter = android.widget.ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(selected)
        }
        val every = spinner(intervals.map { getString(it.second) }, intervals.indexOfFirst { it.first == s.interval }.coerceAtLeast(0))
        val keep = spinner(keeps.map { getString(R.string.autobackup_keep_n, it) }, keeps.indexOf(s.keep).let { if (it < 0) 1 else it })
        val status = StringBuilder()
        status.append(s.tree?.let { getString(R.string.autobackup_folder, android.net.Uri.decode(it.lastPathSegment ?: it.toString())) } ?: getString(R.string.autobackup_no_folder))
        status.append('\n').append(
            if (s.lastSuccess > 0) getString(R.string.autobackup_last_ok, java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT).format(java.util.Date(s.lastSuccess)))
            else getString(R.string.autobackup_never)
        )
        s.lastError?.let { status.append('\n').append(getString(R.string.autobackup_last_error, it)) }
        status.append("\n\n").append(getString(R.string.autobackup_note))
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(android.widget.TextView(this@MainActivity).apply { text = status.toString() })
            addView(android.widget.TextView(this@MainActivity).apply { setText(R.string.autobackup_every) }); addView(every)
            addView(android.widget.TextView(this@MainActivity).apply { setText(R.string.autobackup_keep) }); addView(keep)
        }
        fun store() = com.example.docscanner.util.AutoBackup.save(this, s.tree, intervals[every.selectedItemPosition].first, keeps[keep.selectedItemPosition])
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.autobackup_title)
            .setView(box)
            .setPositiveButton(R.string.autobackup_save) { _, _ ->
                store()
                if (intervals[every.selectedItemPosition].first != com.example.docscanner.util.BackupSchedule.Interval.OFF && s.tree == null) autoBackupFolderPicker.launch(null)
                else com.example.docscanner.util.AutoBackup.ensureScheduled(this)
            }
            .setNeutralButton(R.string.autobackup_choose_folder) { _, _ -> store(); autoBackupFolderPicker.launch(null) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun onAutoBackupFolder(uri: Uri) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        runCatching { contentResolver.takePersistableUriPermission(uri, flags) }
        val s = com.example.docscanner.util.AutoBackup.settings(this)
        s.tree?.let { old -> if (old != uri) runCatching { contentResolver.releasePersistableUriPermission(old, flags) } }
        com.example.docscanner.util.AutoBackup.save(this, uri, s.interval, s.keep)
        com.example.docscanner.util.AutoBackup.ensureScheduled(this)
        Toast.makeText(this, R.string.autobackup_folder_set, Toast.LENGTH_LONG).show()
    }

    private fun runBackup(uri: Uri) {
        setImporting(true)
        lifecycleScope.launch {
            val count = runCatching {
                withContext(Dispatchers.IO) {
                    val out = contentResolver.openOutputStream(uri) ?: throw java.io.IOException("no stream")
                    com.example.docscanner.util.BackupManager.backup(this@MainActivity, out)
                }
            }
            setImporting(false)
            val n = count.getOrNull()
            when {
                n == null -> {
                    runCatching { android.provider.DocumentsContract.deleteDocument(contentResolver, uri) }   // do not leave a half ZIP behind
                    Toast.makeText(this@MainActivity, R.string.backup_failed, Toast.LENGTH_LONG).show()
                }
                n == 0 -> Toast.makeText(this@MainActivity, R.string.backup_empty, Toast.LENGTH_LONG).show()
                else -> Toast.makeText(this@MainActivity, getString(R.string.backup_done, n), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun runRestore(uri: Uri) {
        setImporting(true)
        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    val input = contentResolver.openInputStream(uri) ?: throw java.io.IOException("no stream")
                    com.example.docscanner.util.BackupManager.restore(this@MainActivity, input)
                }
            }
            setImporting(false)
            val r = result.getOrNull()
            if (r == null) {
                val notBackup = result.exceptionOrNull() is IllegalArgumentException
                Toast.makeText(this@MainActivity, if (notBackup) R.string.restore_not_backup else R.string.restore_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            Toast.makeText(this@MainActivity, getString(R.string.restore_done, r.written, r.skipped, r.rejected), Toast.LENGTH_LONG).show()
            refreshHistory()
        }
    }

    private fun shareFile(file: File) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val mime = FileUtils.mimeTypeFor(file)   // knows docx / xlsx / pptx / html / md / fb2 too; a Word file used to go out as text/plain
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.action_share)))
    }

    private fun confirmDeleteHistoryFile(file: File) {
        val companionTxt = File(file.parentFile, file.nameWithoutExtension + ".txt")
        // A PDF's OCR .txt sidecar goes to the bin with it (the bin hides it and restores it together with the PDF). An ebook's EPUB+TXT pair
        // is shown as TWO rows, so deleting the EPUB row also moves the TXT row: that case is called out explicitly (see TECHNICAL_DOCS.md 6).
        val warnAboutPair = file.extension.equals("epub", ignoreCase = true) &&
            companionTxt.exists() && companionTxt.absolutePath != file.absolutePath
        val message = if (warnAboutPair) {
            getString(R.string.confirm_trash_file_with_txt_pair, file.name, companionTxt.name, com.example.docscanner.util.TrashStore.RETENTION_DAYS)
        } else {
            getString(R.string.confirm_trash_file, file.name, com.example.docscanner.util.TrashStore.RETENTION_DAYS)
        }
        AlertDialog.Builder(this)
            .setMessage(message)
            .setPositiveButton(R.string.dialog_yes) { _, _ ->
                moveToTrash(if (warnAboutPair) listOf(file, companionTxt) else listOf(file))
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    // ---- multi-select, recycle bin, bulk rename (phiên 17, mục 4.31; logic in util.TrashStore / util.BulkRename) ----

    private var selectionMode: androidx.appcompat.view.ActionMode? = null

    private val selectionCallback = object : androidx.appcompat.view.ActionMode.Callback {
        override fun onCreateActionMode(mode: androidx.appcompat.view.ActionMode, menu: android.view.Menu): Boolean {
            mode.menuInflater.inflate(R.menu.menu_history_selection, menu)
            return true
        }
        override fun onPrepareActionMode(mode: androidx.appcompat.view.ActionMode, menu: android.view.Menu): Boolean = false
        override fun onActionItemClicked(mode: androidx.appcompat.view.ActionMode, item: android.view.MenuItem): Boolean {
            when (item.itemId) {
                R.id.action_sel_all -> historyAdapter.selectAll()
                R.id.action_sel_share -> shareSelected()
                R.id.action_sel_zip -> zipSelected()
                R.id.action_sel_tag -> tagSelected()
                R.id.action_sel_rename -> renameSelected()
                R.id.action_sel_merge_epub -> mergeSelectedEpubs()
                R.id.action_sel_trash -> trashSelected()
            }
            return true
        }
        override fun onDestroyActionMode(mode: androidx.appcompat.view.ActionMode) {
            selectionMode = null
            historyAdapter.endSelection()
        }
    }

    private fun startSelection(first: File?) {
        if (selectionMode == null) {
            historyAdapter.beginSelection()
            selectionMode = startSupportActionMode(selectionCallback)
        }
        first?.let { historyAdapter.toggle(it) }
        updateSelectionTitle()
    }

    private fun updateSelectionTitle() {
        selectionMode?.title = getString(R.string.selection_count, historyAdapter.selectedFiles().size)
    }

    private fun selectedOrToast(): List<File>? {
        val files = historyAdapter.selectedFiles()
        if (files.isEmpty()) Toast.makeText(this, R.string.selection_none, Toast.LENGTH_SHORT).show()
        return files.ifEmpty { null }
    }

    private fun shareSelected() {
        val files = selectedOrToast() ?: return
        val uris = ArrayList<android.net.Uri>(files.map { FileProvider.getUriForFile(this, "$packageName.fileprovider", it) })
        val mimes = files.map { FileUtils.mimeTypeFor(it) }.toSet()
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = if (mimes.size == 1) mimes.first() else "*/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.action_share)))
    }

    /**
     * Packs the selected documents into ONE ZIP and hands it to the share sheet (PDF list: E6 archive, L13 export as ZIP, M2 share as
     * ZIP, M4 share with password). Empty password = ordinary ZIP; otherwise AES-256 (util.ZipPack, WinZip AE-2). File names stay visible.
     */
    private fun zipSelected() {
        val files = selectedOrToast() ?: return
        val input = android.widget.EditText(this).apply {
            setHint(R.string.zip_password_hint)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = android.widget.FrameLayout(this).apply { setPadding(pad, pad / 2, pad, 0); addView(input) }
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.zip_title, files.size))
            .setMessage(getString(R.string.zip_help, com.example.docscanner.util.ZipPack.MIN_PASSWORD_CHARS))
            .setView(holder)
            .setPositiveButton(R.string.zip_run, null)          // set below so a too-short password keeps the dialog open
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
        dialog.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val pw = input.text.toString()
            if (pw.isNotEmpty() && !com.example.docscanner.util.ZipPack.passwordAcceptable(pw)) {
                Toast.makeText(this, getString(R.string.zip_password_short, com.example.docscanner.util.ZipPack.MIN_PASSWORD_CHARS), Toast.LENGTH_LONG).show()
            } else {
                dialog.dismiss()
                runZip(files, pw.ifEmpty { null })
            }
        }
    }

    private fun runZip(files: List<File>, password: String?) {
        if (!hasRoomFor(files.sumOf { it.length() })) return
        setImporting(true)
        lifecycleScope.launch {
            val dir = FileUtils.zipShareDir(this@MainActivity)
            val out = File(dir, "docscanner_files_" + FileUtils.defaultDocName().removePrefix("scan_") + ".zip")
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    dir.listFiles()?.forEach { runCatching { it.delete() } }       // one ZIP at a time: never leave an older copy of the documents behind
                    com.example.docscanner.util.ZipPack.write(files, com.example.docscanner.util.ZipPack.entryNames(files.map { it.name }), out, password)
                }
            }
            setImporting(false)
            val error = result.exceptionOrNull()
            if (error != null) {
                runCatching { out.delete() }
                Toast.makeText(this@MainActivity, if (error is com.example.docscanner.util.ZipPack.TooBigException) R.string.zip_too_big else R.string.zip_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            selectionMode?.finish()
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", out))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, getString(R.string.action_share)))
        }
    }

    /** Adds the chosen tags to EVERY selected document (never removes: removing from many at once is too easy to do by mistake). */
    private fun tagSelected() {
        val files = selectedOrToast() ?: return
        val known = com.example.docscanner.util.TagStore.tagCounts(com.example.docscanner.util.TagStore.all(this)).map { it.first }.toTypedArray()
        val checked = BooleanArray(known.size)
        fun apply(chosen: List<String>) {
            if (chosen.isEmpty()) return
            val all = com.example.docscanner.util.TagStore.all(this)
            for (f in files) com.example.docscanner.util.TagStore.setTags(this, f, ((all[f.name] ?: emptySet()) + chosen).toList())
            selectionMode?.finish()
            renderHistory()
        }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.selection_tag_title, files.size))
            .setMultiChoiceItems(known, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton(R.string.dialog_ok) { _, _ -> apply(known.filterIndexed { i, _ -> checked[i] }) }
            .setNeutralButton(R.string.tag_new) { _, _ ->
                val keep = known.filterIndexed { i, _ -> checked[i] }
                askText(R.string.tag_new, R.string.tag_new_hint, secret = false) { name -> apply(keep + name) }
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun renameSelected() {
        val files = selectedOrToast() ?: return
        val pad = (20 * resources.displayMetrics.density).toInt()
        val input = android.widget.EditText(this).apply {
            setText(com.example.docscanner.util.BulkRename.DEFAULT_PATTERN)
            setSelection(text.length)
            setSingleLine()
        }
        val frame = android.widget.FrameLayout(this).apply { setPadding(pad, pad / 2, pad, 0); addView(input) }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.selection_rename_title, files.size))
            .setMessage(R.string.selection_rename_help)
            .setView(frame)
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.dialog_ok) { _, _ -> confirmBulkRename(files, input.text.toString()) }
            .show()
    }

    private fun confirmBulkRename(files: List<File>, pattern: String) {
        val dir = PdfExporter.exportDir(this)
        val fmt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
        val newNames = com.example.docscanner.util.BulkRename.plan(
            files.map { com.example.docscanner.util.BulkRename.Item(it.name, it.lastModified()) },
            pattern, 1, (dir.list() ?: emptyArray()).toSet()
        ) { fmt.format(java.util.Date(it)) }
        val changes = files.indices.filter { newNames[it] != files[it].name }
        if (changes.isEmpty()) {
            Toast.makeText(this, R.string.selection_rename_nochange, Toast.LENGTH_LONG).show()
            return
        }
        val preview = changes.take(3).joinToString("\n") { "${files[it].name}  \u2192  ${newNames[it]}" }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.selection_rename_confirm, changes.size))
            .setMessage(preview + if (changes.size > 3) "\n\u2026" else "")
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.dialog_ok) { _, _ ->
                var failed = 0
                for (i in changes) {
                    val f = files[i]
                    val newBase = newNames[i].removeSuffix(if (f.extension.isEmpty()) "" else "." + f.extension)
                    val renamed = com.example.docscanner.util.SmartNamer.rename(f, newBase)
                    if (renamed == null) failed++ else if (renamed.name != f.name) {
                        com.example.docscanner.util.FavoriteStore.rename(this, f.name, renamed.name)
                        com.example.docscanner.util.TagStore.rename(this, f.name, renamed.name)
                    }
                }
                if (failed > 0) Toast.makeText(this, getString(R.string.selection_rename_partial, failed), Toast.LENGTH_LONG).show()
                selectionMode?.finish()
                refreshHistory()
            }
            .show()
    }

    private fun trashSelected() {
        val files = selectedOrToast() ?: return
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setMessage(getString(R.string.selection_trash_confirm, files.size, com.example.docscanner.util.TrashStore.RETENTION_DAYS))
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.dialog_yes) { _, _ ->
                selectionMode?.finish()
                moveToTrash(files)
            }
            .show()
    }

    /** Moves [files] to the bin; one that cannot be moved stays where it is and is reported. */
    private fun moveToTrash(files: List<File>) {
        if (com.example.docscanner.util.PrivateMode.isOn(this)) {
            // private mode leaves no bin: what is deleted here is gone (overwritten first), with its OCR transcript
            var gone = 0
            for (f in files) {
                if (com.example.docscanner.util.StorageTools.wipe(f)) gone++
                com.example.docscanner.util.ContentIndex.transcriptOf(f)?.takeIf { it != f }?.let { com.example.docscanner.util.StorageTools.wipe(it) }
            }
            Toast.makeText(this, getString(R.string.private_deleted, gone), Toast.LENGTH_SHORT).show()
            refreshHistory()
            return
        }
        val trashDir = com.example.docscanner.util.TrashStore.dir(this)
        val now = System.currentTimeMillis()
        val tagMap = com.example.docscanner.util.TagStore.all(this)
        val stars = com.example.docscanner.util.FavoriteStore.all(this)
        // the star and the tags live outside the file: they travel with it into the bin and come back on restore
        val failed = files.count {
            val meta = com.example.docscanner.util.TrashMeta.encode(it.name in stars, tagMap[it.name] ?: emptySet())
            !com.example.docscanner.util.TrashStore.moveToTrash(trashDir, it, now, meta)
        }
        if (failed > 0) Toast.makeText(this, getString(R.string.trash_failed, failed), Toast.LENGTH_LONG).show()
        else Toast.makeText(this, getString(R.string.trash_moved, files.size), Toast.LENGTH_SHORT).show()
        refreshHistory()
    }

    private fun updateTrashButton() {
        val n = com.example.docscanner.util.TrashStore.entries(com.example.docscanner.util.TrashStore.dir(this)).size
        binding.btnHistoryTrash.text = if (n == 0) getString(R.string.trash_button) else getString(R.string.trash_button_count, n)
    }

    private fun showTrashDialog() {
        val trashDir = com.example.docscanner.util.TrashStore.dir(this)
        val now = System.currentTimeMillis()
        val entries = com.example.docscanner.util.TrashStore.entries(trashDir)
        if (entries.isEmpty()) {
            Toast.makeText(this, R.string.trash_nothing, Toast.LENGTH_LONG).show()
            return
        }
        val labels = entries.map { getString(R.string.trash_item, it.originalName, com.example.docscanner.util.TrashStore.daysLeft(it.deletedAt, now)) }.toTypedArray()
        val checked = BooleanArray(entries.size)
        fun chosen() = entries.filterIndexed { i, _ -> checked[i] }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(getString(R.string.trash_title, com.example.docscanner.util.TrashStore.RETENTION_DAYS))
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton(R.string.trash_restore) { _, _ ->
                val picked = chosen()
                if (picked.isEmpty()) {
                    Toast.makeText(this, R.string.selection_none, Toast.LENGTH_SHORT).show()
                } else {
                    val dir = PdfExporter.exportDir(this)
                    val ok = picked.count { entry ->
                        val meta = com.example.docscanner.util.TrashStore.readMeta(trashDir, entry)?.let { com.example.docscanner.util.TrashMeta.decode(it) }
                        val restored = com.example.docscanner.util.TrashStore.restore(trashDir, dir, entry)
                        if (restored != null && meta != null) {
                            if (meta.favorite && !com.example.docscanner.util.FavoriteStore.isFavorite(this, restored)) com.example.docscanner.util.FavoriteStore.toggle(this, restored)
                            if (meta.tags.isNotEmpty()) com.example.docscanner.util.TagStore.setTags(this, restored, meta.tags)
                        }
                        restored != null
                    }
                    Toast.makeText(this, getString(R.string.trash_restored, ok), Toast.LENGTH_SHORT).show()
                    refreshHistory()
                }
            }
            .setNegativeButton(R.string.trash_delete_forever) { _, _ ->
                val picked = chosen()
                if (picked.isEmpty()) {
                    Toast.makeText(this, R.string.selection_none, Toast.LENGTH_SHORT).show()
                } else {
                    confirmDeleteForever(trashDir, picked)
                }
            }
            .setNeutralButton(R.string.trash_empty_all) { _, _ -> confirmDeleteForever(trashDir, entries) }
            .show()
    }

    private fun confirmDeleteForever(trashDir: File, entries: List<com.example.docscanner.util.TrashStore.Entry>) {
        AlertDialog.Builder(this)
            .setMessage(getString(R.string.trash_forever_confirm, entries.size))
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.dialog_yes) { _, _ ->
                entries.forEach { com.example.docscanner.util.TrashStore.deleteForever(trashDir, it) }
                updateTrashButton()
            }
            .show()
    }

    private val HISTORY_GROUP_NAMES = intArrayOf(
        R.string.history_group_organize, R.string.history_group_read, R.string.history_group_convert, R.string.history_group_tools, R.string.history_group_extract
    )

    /** Group of each tool of the reader's Edit button ([showPdfTools]): 0 edit & annotate, 1 sign & protect, 2 document tools, 3 convert & export, 4 read, 5 extract information. */
    private val READER_TOOL_GROUPS: Map<Int, Int> = mapOf(
        R.string.tool_text_edit_title to 0,
        R.string.incoming_annotate to 0,
        R.string.incoming_markup to 0,
        R.string.incoming_form to 0,
        R.string.incoming_decorate to 0,
        R.string.pages_title to 0,
        R.string.incoming_sign to 1,
        R.string.incoming_redact to 1,
        R.string.incoming_security to 1,
        R.string.incoming_page_manager to 2,
        R.string.incoming_impose to 2,
        R.string.incoming_compress to 2,
        R.string.history_action_split_bookmarks to 2,
        R.string.history_action_repair to 2,
        R.string.history_action_linearize to 2,
        R.string.incoming_scan to 2,
        R.string.history_action_bookmarks to 2,
        R.string.history_action_links to 2,
        R.string.history_action_autolinks to 2,
        R.string.history_action_attachments to 2,
        R.string.history_action_layers to 2,
        R.string.history_action_portfolio to 2,
        R.string.incoming_searchable to 3,
        R.string.history_action_word to 3,
        R.string.history_action_excel to 3,
        R.string.history_action_pptx to 3,
        R.string.history_action_pdfa to 3,
        R.string.history_action_read to 4,
        R.string.history_action_translate to 4,
        R.string.incoming_print to 4,
        R.string.history_action_invoice to 5,
        R.string.history_action_insight to 5,
        R.string.history_action_card to 5
    )

    private val READER_GROUP_NAMES = intArrayOf(
        R.string.tool_group_edit, R.string.tool_group_secure, R.string.history_group_tools, R.string.history_group_convert, R.string.history_group_read, R.string.history_group_extract
    )

    /**
     * Every tool that works on ONE PDF, for the reader's Edit button (session 23, 4.60): the ones of the list shown for a PDF received from another app and the
     * PDF-specific ones of the history menu, in 6 groups. They all take a file (or an address of it), write a NEW copy or open a screen of their own and read the PDF
     * itself rather than a text file kept beside it, so they work on any PDF, not only on history files. The reader brings this screen to the front with
     * [PdfReaderActivity.ACTION_PDF_TOOLS] and keeps itself underneath, so Back returns to the reader. tools/verify/history_menu_groups_check.py keeps this list and
     * [READER_TOOL_GROUPS] in step.
     */
    private fun showPdfTools(file: File, title: String?) {
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val tools = ArrayList<Pair<String, () -> Unit>>()
        tools.add(getString(R.string.tool_text_edit_title) to { openPdfIn(PdfTextEditActivity::class.java, uri) })
        tools.add(getString(R.string.incoming_annotate) to { openPdfIn(PdfAnnotateActivity::class.java, uri) })
        tools.add(getString(R.string.incoming_markup) to { openPdfIn(PdfMarkupActivity::class.java, uri) })
        tools.add(getString(R.string.incoming_form) to { openPdfIn(PdfFormActivity::class.java, uri) })
        tools.add(getString(R.string.incoming_decorate) to { openPdfIn(PdfDecorateActivity::class.java, uri) })
        tools.add(getString(R.string.pages_title) to { startActivity(Intent(this, PdfPagesActivity::class.java).putExtra(PdfPagesActivity.EXTRA_PDF_PATH, file.absolutePath)) })
        tools.add(getString(R.string.incoming_sign) to { openPdfIn(PdfSignActivity::class.java, uri) })
        tools.add(getString(R.string.incoming_redact) to { openPdfIn(PdfRedactActivity::class.java, uri) })
        tools.add(getString(R.string.incoming_security) to { showSecurityMenu(uri) })
        tools.add(getString(R.string.incoming_page_manager) to { openPdfIn(PdfPageEditorActivity::class.java, uri) })
        tools.add(getString(R.string.incoming_impose) to { showImposeMenu(uri) })
        tools.add(getString(R.string.incoming_compress) to { showCompressMethodPicker(uri) })
        tools.add(getString(R.string.history_action_split_bookmarks) to { splitAtBookmarks(file) })
        tools.add(getString(R.string.history_action_repair) to { repairPdf(file) })
        tools.add(getString(R.string.history_action_linearize) to { linearizePdf(file) })
        tools.add(getString(R.string.incoming_scan) to { importPdfForScanning(uri) })
        tools.add(getString(R.string.history_action_bookmarks) to { startActivity(Intent(this, PdfBookmarkActivity::class.java).putExtra(PdfBookmarkActivity.EXTRA_PDF_PATH, file.absolutePath)) })
        tools.add(getString(R.string.history_action_links) to { showLinksDialog(file) })
        tools.add(getString(R.string.history_action_autolinks) to { autoLinkPdf(file) })
        tools.add(getString(R.string.history_action_attachments) to { showAttachmentsDialog(file) })
        tools.add(getString(R.string.history_action_layers) to { showLayersDialog(file) })
        tools.add(getString(R.string.history_action_portfolio) to { showPortfolioDialog(file) })
        tools.add(getString(R.string.incoming_searchable) to { askOcrScript { makeSearchablePdf(uri) } })
        tools.add(getString(R.string.history_action_word) to { exportWord(file) })
        tools.add(getString(R.string.history_action_excel) to { exportExcel(file) })
        tools.add(getString(R.string.history_action_pptx) to { exportPowerPoint(file) })
        tools.add(getString(R.string.history_action_pdfa) to { exportPdfA(file) })
        tools.add(getString(R.string.history_action_read) to { readAloud(file) })
        tools.add(getString(R.string.history_action_translate) to { pickTranslateTarget(file) })
        tools.add(getString(R.string.incoming_print) to { com.example.docscanner.util.PdfPrintAdapter.print(this, file) })
        tools.add(getString(R.string.history_action_invoice) to { extractInvoice(file) })
        tools.add(getString(R.string.history_action_insight) to { showDocInsight(file) })
        tools.add(getString(R.string.history_action_card) to { cardToContact(file) })
        showGroupedActions(title ?: file.name, tools, READER_TOOL_GROUPS, READER_GROUP_NAMES, fallback = 2)
    }

    /** What a tap on a history file does: a PDF opens in the reader, an EPUB in the book reader, a text file in the text screen. */
    private fun openHistoryFile(file: File) {
        when (file.extension.lowercase()) {
            "pdf" -> openPdfReaderFile(file)
            "epub" -> startActivity(Intent(this, EpubReaderActivity::class.java).putExtra(EpubReaderActivity.EXTRA_EPUB_PATH, file.absolutePath))
            else -> openTextResult(file)
        }
    }

    private fun openPdfReaderFile(file: File) {
        startActivity(Intent(this, PdfReaderActivity::class.java).putExtra(PdfReaderActivity.EXTRA_PDF_PATH, file.absolutePath))
    }

    /** Copies the PDF behind [uri] first (the access a file manager or a drop grants is short-lived), then opens the reader on the copy. */
    private fun openPdfReaderUri(uri: Uri) {
        lifecycleScope.launch {
            val copy = withContext(Dispatchers.IO) { PdfReaderActivity.copyToCache(this@MainActivity, uri) }
            if (copy == null) {
                Toast.makeText(this@MainActivity, R.string.reader_copy_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            startActivity(Intent(this@MainActivity, PdfReaderActivity::class.java).apply {
                putExtra(PdfReaderActivity.EXTRA_PDF_PATH, copy.absolutePath)
                putExtra(PdfReaderActivity.EXTRA_TEMP, true)
                putExtra(PdfReaderActivity.EXTRA_TITLE, IncomingFile.displayName(this@MainActivity, uri) ?: copy.name)
            })
        }
    }

    // ---- drag and drop from a file manager (split screen / freeform window) ----

    /** Keeps the read access the system grants for a dropped file for as long as this screen lives. */
    private var dropPermissions: android.view.DragAndDropPermissions? = null

    /**
     * Dropping a PDF (or pictures) from a file manager running beside this app opens it as "Open with" would: one PDF in the reader, several in the batch menu, pictures
     * into a scan session. Plain text dragged onto the search box is left alone (see [acceptsDrop]).
     */
    private fun setupPdfDrop() {
        val target = binding.root
        target.setOnDragListener { _, event ->
            when (event.action) {
                android.view.DragEvent.ACTION_DRAG_STARTED -> acceptsDrop(event.clipDescription)
                android.view.DragEvent.ACTION_DRAG_ENTERED -> { target.alpha = 0.6f; true }
                android.view.DragEvent.ACTION_DRAG_EXITED, android.view.DragEvent.ACTION_DRAG_ENDED -> { target.alpha = 1f; true }
                android.view.DragEvent.ACTION_DROP -> { target.alpha = 1f; handleDrop(event) }
                else -> true
            }
        }
    }

    /**
     * Accepts a drag unless EVERY type it offers is plain text. File managers differ in the type they announce (application/pdf, a wildcard, octet-stream...), so
     * matching only PDF would silently ignore some of them; what is not usable is told to the person after the drop (incoming_unsupported).
     */
    private fun acceptsDrop(description: android.content.ClipDescription?): Boolean =
        description != null && (0 until description.mimeTypeCount).any { val type = description.getMimeType(it); !type.startsWith("text/") || type == "text/uri-list" }

    private fun handleDrop(event: android.view.DragEvent): Boolean {
        val clip = event.clipData ?: return false
        // a sender may carry the address in the item's uri or, as a "text/uri-list", in its text (one content:// address per line)
        val uris = (0 until clip.itemCount).flatMap { index ->
            val item = clip.getItemAt(index)
            val direct = item.uri
            if (direct != null) listOf(direct)
            else item.text?.lines()?.map { it.trim() }?.filter { it.startsWith("content://") }?.map { Uri.parse(it) } ?: emptyList()
        }
        if (uris.isEmpty()) return false
        dropPermissions = requestDragAndDropPermissions(event)
        handleIncomingUris(uris, openInReader = true)
        return true
    }

    // ---- collapsible tool groups on the main screen ----

    /** Each group's title row opens / closes its cards; the choice is remembered, and only the first group starts open. */
    private fun setupCollapsibleGroups() {
        val prefs = getSharedPreferences("main_ui", MODE_PRIVATE)
        val groups = listOf(
            Triple("scan", binding.tvGroupScan, binding.llGroupScan),
            Triple("arrange", binding.tvGroupArrange, binding.llGroupArrange),
            Triple("edit", binding.tvGroupEdit, binding.llGroupEdit),
            Triple("secure", binding.tvGroupSecure, binding.llGroupSecure),
            Triple("convert", binding.tvGroupConvert, binding.llGroupConvert),
            Triple("utility", binding.tvGroupUtility, binding.llGroupUtility)
        )
        for ((name, header, box) in groups) {
            val key = "group_open_$name"
            applyGroupState(header, box, prefs.getBoolean(key, name == "scan"))
            header.setOnClickListener {
                val open = box.visibility != View.VISIBLE
                applyGroupState(header, box, open)
                prefs.edit().putBoolean(key, open).apply()
            }
        }
    }

    private fun applyGroupState(header: android.widget.TextView, box: View, open: Boolean) {
        box.visibility = if (open) View.VISIBLE else View.GONE
        header.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, if (open) R.drawable.ic_expand_less else R.drawable.ic_expand_more, 0)
    }

    private fun openTextResult(file: File) {
        when (file.extension.lowercase()) {
            "pdf" -> {
                val txtFile = File(file.parentFile, file.nameWithoutExtension + ".txt")
                if (!txtFile.exists()) {
                    Toast.makeText(this, R.string.no_text_found, Toast.LENGTH_SHORT).show()
                    return
                }
                startActivity(Intent(this, TextResultActivity::class.java).apply {
                    putExtra(TextResultActivity.EXTRA_TEXT_FILE_PATH, txtFile.absolutePath)
                })
            }
            "txt" -> {
                startActivity(Intent(this, TextResultActivity::class.java).apply {
                    putExtra(TextResultActivity.EXTRA_TEXT_FILE_PATH, file.absolutePath)
                })
            }
            else -> {
                // .epub - nothing to preview in-app; share/open it with a reading app instead.
                shareFile(file)
            }
        }
    }
}

/** PDF -> Excel reads every page by OCR (about a second each), so it stops at this many pages and says so. */
private const val EXPORT_TABLE_MAX_PAGES = 40

/** PDF -> PowerPoint keeps every page as a picture in memory until the file is written. */
private const val EXPORT_SLIDES_MAX_PAGES = 100
