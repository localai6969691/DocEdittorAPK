package com.example.docscanner.util

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Revocation data for PAdES-B-LT (session 23, 4.51): for each certificate of a signature's chain, the OCSP response (preferred) or the CRL that says the
 * certificate had not been revoked, so the signature can still be checked after the issuer's server is gone. This file only COLLECTS the bytes; they are
 * written into the PDF's /DSS by [PdfLtv].
 *
 * Everything except [httpPost] / [httpGet] is plain DER walking on byte arrays (no Android classes) and is mirrored by tools/verify/RevocationCheck.java,
 * which revocation_check.py compares with `openssl` (requests byte for byte, URLs, a live `openssl ocsp` responder, CMS certificate lists).
 *
 * What is NOT done here, on purpose: the responder's signature and the response's validity period are not verified (the PDF reader that later validates
 * the signature does that; this code only refuses a response that is not "successful", is not "good", or answers a different certificate).
 */
internal object Revocation {

    const val CERT_GOOD = 0
    const val CERT_REVOKED = 1
    const val CERT_UNKNOWN = 2
    private const val MAX_BYTES = 5 * 1024 * 1024

    private const val OID_AIA = "1.3.6.1.5.5.7.1.1"
    private const val OID_CDP = "2.5.29.31"
    private const val OID_OCSP = "1.3.6.1.5.5.7.48.1"

    // ---------------------------------------------------------------------------------------
    // DER helpers (all bounds-checked by the callers' try / catch: a damaged certificate gives empty results, never an exception)
    // ---------------------------------------------------------------------------------------

    /** `[start, end)` of the element that begins at [off]: its content spans `[start + headerLength, end)`. */
    private class El(val tag: Int, val start: Int, val contentStart: Int, val end: Int)

    private fun el(d: ByteArray, off: Int): El {
        if (off < 0 || off + 2 > d.size) throw IndexOutOfBoundsException("element outside the data")
        val h = DerWriter.header(d, off)
        val contentStart = off + h[1]
        val end = contentStart.toLong() + h[2].toLong()
        if (h[2] < 0 || end > d.size) throw IndexOutOfBoundsException("element longer than the data")
        return El(h[0], off, contentStart, end.toInt())
    }

    private fun children(d: ByteArray, e: El): List<El> {
        val out = ArrayList<El>()
        var p = e.contentStart
        while (p < e.end) {
            val c = el(d, p)
            if (c.end > e.end) throw IndexOutOfBoundsException("child longer than its parent")
            out.add(c)
            p = c.end
        }
        return out
    }

    private fun slice(d: ByteArray, e: El): ByteArray = d.copyOfRange(e.start, e.end)

    private fun oidString(d: ByteArray, e: El): String {
        val sb = StringBuilder()
        var value = 0L
        var first = true
        for (i in e.contentStart until e.end) {
            val b = d[i].toInt() and 0xFF
            value = (value shl 7) or (b and 0x7F).toLong()
            if (b and 0x80 == 0) {
                if (first) {
                    val a = if (value < 40) 0L else if (value < 80) 1L else 2L
                    sb.append(a).append('.').append(value - a * 40)
                    first = false
                } else sb.append('.').append(value)
                value = 0
            }
        }
        return sb.toString()
    }

    private fun sha1(b: ByteArray): ByteArray = MessageDigest.getInstance("SHA-1").digest(b)

    // ---------------------------------------------------------------------------------------
    // Certificate fields
    // ---------------------------------------------------------------------------------------

    /** The parts of a certificate that the rest needs, each copied with its tag and length ([extensions] = the SEQUENCE OF Extension, or null). */
    class CertFields(
        val serial: ByteArray, val issuer: ByteArray, val subject: ByteArray,
        val publicKeyBits: ByteArray, val extensions: ByteArray?
    )

    /** Null when the bytes are not a certificate this code can read. */
    fun fields(cert: ByteArray): CertFields? = try {
        val outer = el(cert, 0)
        val tbs = el(cert, outer.contentStart)
        var p = tbs.contentStart
        var e = el(cert, p)
        if (e.tag == 0xA0) { p = e.end; e = el(cert, p) }          // [0] version (absent in v1)
        val serial = slice(cert, e); p = e.end
        e = el(cert, p); p = e.end                                  // signature AlgorithmIdentifier
        e = el(cert, p); val issuer = slice(cert, e); p = e.end
        e = el(cert, p); p = e.end                                  // validity
        e = el(cert, p); val subject = slice(cert, e); p = e.end
        e = el(cert, p)                                             // SubjectPublicKeyInfo
        val spki = children(cert, e)
        val bits = spki[1]                                          // BIT STRING; first content byte = unused bits
        val keyBits = cert.copyOfRange(bits.contentStart + 1, bits.end)
        p = e.end
        var extensions: ByteArray? = null
        while (p < tbs.end) {
            val x = el(cert, p)
            if (x.tag == 0xA3) { extensions = slice(cert, el(cert, x.contentStart)); break }
            p = x.end
        }
        CertFields(serial, issuer, subject, keyBits, extensions)
    } catch (ex: RuntimeException) {
        null
    }

    class Urls(val ocsp: List<String>, val crl: List<String>)

    /** http(s) addresses in the AuthorityInfoAccess (OCSP responders) and CRLDistributionPoints extensions; empty for a self-signed or unreadable certificate. */
    fun urlsOf(cert: ByteArray): Urls {
        val ocsp = ArrayList<String>()
        val crl = ArrayList<String>()
        try {
            val ext = fields(cert)?.extensions ?: return Urls(ocsp, crl)
            val root = el(ext, 0)
            for (x in children(ext, root)) {
                val parts = children(ext, x)
                if (parts.size < 2) continue
                val id = oidString(ext, parts[0])
                val octets = parts[parts.size - 1]
                if (octets.tag != 0x04) continue
                val inner = ext.copyOfRange(octets.contentStart, octets.end)
                val top = el(inner, 0)
                if (id == OID_AIA) {
                    for (ad in children(inner, top)) {
                        val adParts = children(inner, ad)
                        if (adParts.size == 2 && oidString(inner, adParts[0]) == OID_OCSP && adParts[1].tag == 0x86) {
                            addUrl(ocsp, String(inner, adParts[1].contentStart, adParts[1].end - adParts[1].contentStart, Charsets.US_ASCII))
                        }
                    }
                } else if (id == OID_CDP) {
                    for (dp in children(inner, top)) {
                        for (field in children(inner, dp)) {
                            if (field.tag != 0xA0) continue                          // distributionPoint
                            for (name in children(inner, field)) {
                                if (name.tag != 0xA0) continue                       // fullName
                                for (gn in children(inner, name)) {
                                    if (gn.tag == 0x86) addUrl(crl, String(inner, gn.contentStart, gn.end - gn.contentStart, Charsets.US_ASCII))
                                }
                            }
                        }
                    }
                }
            }
        } catch (ex: RuntimeException) {
            // damaged extension: whatever was found before stays, the rest is skipped
        }
        return Urls(ocsp, crl)
    }

    private fun addUrl(list: MutableList<String>, url: String) {
        if ((url.startsWith("http://") || url.startsWith("https://")) && !list.contains(url)) list.add(url)
    }

    // ---------------------------------------------------------------------------------------
    // OCSP (RFC 6960)
    // ---------------------------------------------------------------------------------------

    /** CertID ::= SEQUENCE { SHA-1 AlgorithmIdentifier, hash of the issuer's name, hash of the issuer's key, serial number }. SHA-1 only identifies the certificate. */
    fun certId(cert: ByteArray, issuer: ByteArray): ByteArray? {
        val c = fields(cert) ?: return null
        val i = fields(issuer) ?: return null
        return DerWriter.sequence(
            DerWriter.sequence(DerWriter.oid("1.3.14.3.2.26"), DerWriter.nullValue()),
            DerWriter.octetString(sha1(c.issuer)),
            DerWriter.octetString(sha1(i.publicKeyBits)),
            c.serial
        )
    }

    /** OCSPRequest with one Request and no extensions (no nonce: responders can answer from a cache, as RFC 5019 recommends). */
    fun buildOcspRequest(certId: ByteArray): ByteArray =
        DerWriter.sequence(DerWriter.sequence(DerWriter.sequence(DerWriter.sequence(certId))))

    /** [status] = OCSPResponseStatus (0 = successful); [certStatus] = CERT_GOOD / CERT_REVOKED / CERT_UNKNOWN or -1 when there is no answer for [certId]. */
    class OcspAnswer(val status: Int, val certStatus: Int, val answersThisCertificate: Boolean)

    /** Never throws: bytes that are not an OCSP response give status -1. */
    fun parseOcspResponse(d: ByteArray, certId: ByteArray): OcspAnswer {
        try {
            val top = el(d, 0)
            if (top.tag != 0x30) return OcspAnswer(-1, -1, false)
            val parts = children(d, top)
            if (parts.isEmpty() || parts[0].tag != 0x0A || parts[0].end - parts[0].contentStart != 1) return OcspAnswer(-1, -1, false)
            val status = d[parts[0].contentStart].toInt() and 0xFF
            if (status != 0) return OcspAnswer(status, -1, false)
            if (parts.size < 2 || parts[1].tag != 0xA0) return OcspAnswer(-1, -1, false)
            val responseBytes = children(d, el(d, parts[1].contentStart))          // SEQUENCE { OID, OCTET STRING }
            if (responseBytes.size < 2 || responseBytes[1].tag != 0x04) return OcspAnswer(-1, -1, false)
            val basic = d.copyOfRange(responseBytes[1].contentStart, responseBytes[1].end)
            val basicEl = el(basic, 0)
            val tbs = children(basic, el(basic, basicEl.contentStart))            // tbsResponseData
            var idx = 0
            if (tbs[idx].tag == 0xA0) idx++                                        // [0] version
            idx++                                                                  // responderID
            idx++                                                                  // producedAt
            val singles = children(basic, tbs[idx])
            var firstStatus = -1
            for (s in singles) {
                val f = children(basic, s)                                         // certID, certStatus, thisUpdate, ...
                if (f.size < 3) continue
                val st = when (f[1].tag) { 0x80 -> CERT_GOOD; 0xA1 -> CERT_REVOKED; 0x82 -> CERT_UNKNOWN; else -> -1 }
                if (firstStatus == -1) firstStatus = st
                if (slice(basic, f[0]).contentEquals(certId)) return OcspAnswer(0, st, true)
            }
            return OcspAnswer(0, firstStatus, false)
        } catch (ex: RuntimeException) {
            return OcspAnswer(-1, -1, false)
        }
    }

    // ---------------------------------------------------------------------------------------
    // Chain
    // ---------------------------------------------------------------------------------------

    fun isSelfIssued(cert: ByteArray): Boolean {
        val f = fields(cert) ?: return false
        return f.issuer.contentEquals(f.subject)
    }

    /** The certificate in [pool] whose subject is [cert]'s issuer (a self-issued certificate has none). */
    fun issuerOf(cert: ByteArray, pool: List<ByteArray>): ByteArray? {
        val f = fields(cert) ?: return null
        if (f.issuer.contentEquals(f.subject)) return null
        for (c in pool) {
            val g = fields(c) ?: continue
            if (g.subject.contentEquals(f.issuer) && !c.contentEquals(cert)) return c
        }
        return null
    }

    /** The certificates inside a CMS SignedData (ContentInfo), in the order they are stored; empty when there are none or the bytes are not CMS. */
    fun cmsCertificates(cms: ByteArray): List<ByteArray> {
        val out = ArrayList<ByteArray>()
        try {
            val content = children(cms, el(cms, 0))                                // OID, [0]
            if (content.size < 2) return out
            val signedData = el(cms, content[1].contentStart)
            val parts = children(cms, signedData)                                  // version, digestAlgorithms, encapContentInfo, [0] certificates, ...
            for (p in parts) {
                if (p.tag == 0xA0) {
                    for (c in children(cms, p)) if (c.tag == 0x30) out.add(slice(cms, c))
                    break
                }
            }
        } catch (ex: RuntimeException) {
            // fall through with what was read
        }
        return out
    }

    // ---------------------------------------------------------------------------------------
    // Collecting
    // ---------------------------------------------------------------------------------------

    /** [needed] = certificates that need revocation data (all but self-issued roots); [covered] = how many of them got an OCSP response or a CRL. */
    class Bundle(val certs: List<ByteArray>, val ocsps: List<ByteArray>, val crls: List<ByteArray>, val needed: Int, val covered: Int)

    private fun addUnique(list: MutableList<ByteArray>, item: ByteArray) {
        for (x in list) if (x.contentEquals(item)) return
        list.add(item)
    }

    /**
     * For every certificate of [chain] (signer first) except a self-issued root: a "good" OCSP response from its responder, else the CRL from its distribution
     * point. [post] / [get] return the bytes or throw [IOException]; a failure only means that certificate is not covered. The chain's certificates are
     * returned as well (a validator needs them in the /DSS too).
     */
    fun collect(chain: List<ByteArray>, post: (String, ByteArray) -> ByteArray, get: (String) -> ByteArray): Bundle {
        val certs = ArrayList<ByteArray>()
        val ocsps = ArrayList<ByteArray>()
        val crls = ArrayList<ByteArray>()
        var needed = 0
        var covered = 0
        for (cert in chain) {
            addUnique(certs, cert)
            if (isSelfIssued(cert)) continue
            needed++
            val urls = urlsOf(cert)
            var done = false
            val issuer = issuerOf(cert, chain)
            val id = if (issuer != null) certId(cert, issuer) else null
            if (id != null) {
                val request = buildOcspRequest(id)
                for (u in urls.ocsp) {
                    val reply = try { post(u, request) } catch (e: IOException) { continue }
                    val answer = parseOcspResponse(reply, id)
                    if (answer.status == 0 && answer.answersThisCertificate && answer.certStatus == CERT_GOOD) {
                        addUnique(ocsps, reply)
                        done = true
                        break
                    }
                }
            }
            if (!done) {
                for (u in urls.crl) {
                    val reply = try { get(u) } catch (e: IOException) { continue }
                    if (looksLikeCrl(reply)) {
                        addUnique(crls, reply)
                        done = true
                        break
                    }
                }
            }
            if (done) covered++
        }
        return Bundle(certs, ocsps, crls, needed, covered)
    }

    /** A DER SEQUENCE of three parts (tbsCertList, signatureAlgorithm, signature) that fills the data exactly. A PEM CRL is refused. */
    fun looksLikeCrl(d: ByteArray): Boolean = try {
        val top = el(d, 0)
        top.tag == 0x30 && top.end == d.size && children(d, top).size == 3
    } catch (ex: RuntimeException) {
        false
    }

    // ---------------------------------------------------------------------------------------
    // HTTP (the only part that is not mirrored: needs the network)
    // ---------------------------------------------------------------------------------------

    private fun read(c: HttpURLConnection): ByteArray {
        if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode}")
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        c.inputStream.use { input ->
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                out.write(buf, 0, n)
                if (out.size() > MAX_BYTES) throw IOException("the answer is too large")
            }
        }
        return out.toByteArray()
    }

    fun httpPost(url: String, body: ByteArray, timeoutMs: Int = 15_000): ByteArray {
        if (!(url.startsWith("http://") || url.startsWith("https://"))) throw IOException("not an http(s) address")
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.instanceFollowRedirects = false
            c.setRequestProperty("Content-Type", "application/ocsp-request")
            c.setRequestProperty("Accept", "application/ocsp-response")
            c.setFixedLengthStreamingMode(body.size)
            c.outputStream.use { it.write(body) }
            return read(c)
        } finally {
            c.disconnect()
        }
    }

    fun httpGet(url: String, timeoutMs: Int = 15_000): ByteArray {
        if (!(url.startsWith("http://") || url.startsWith("https://"))) throw IOException("not an http(s) address")
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "GET"
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.instanceFollowRedirects = false
            return read(c)
        } finally {
            c.disconnect()
        }
    }
}
