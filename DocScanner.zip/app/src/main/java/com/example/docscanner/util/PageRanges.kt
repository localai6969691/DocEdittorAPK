package com.example.docscanner.util

/**
 * Page-range text as people write it: `1-3, 5, 8-` (1-based, inclusive; `8-` = from page 8 to the last, `-3` = the first three).
 * Pure Kotlin so `tools/verify/page_ranges_check.py` can run a Java copy of it against an independently written reference.
 *
 * Strict on purpose: a range that does not fit the document (`1-99` in a 20-page file) is an ERROR, not silently shortened -
 * "split pages 15-25" quietly producing 15-20 would look like a successful split of the wrong thing.
 */
object PageRanges {

    enum class Problem { EMPTY, SYNTAX, OUT_OF_RANGE, REVERSED }

    /** [groups]: one list of 0-based page indexes per comma-separated part; [problem] != null means the text was rejected at [badToken]. */
    class Parsed(val groups: List<List<Int>>, val problem: Problem?, val badToken: String?) {
        val ok: Boolean get() = problem == null
    }

    private val TOKEN = Regex("""(\d*)\s*(-?)\s*(\d*)""")

    fun parse(spec: String, pageCount: Int): Parsed {
        val tokens = spec.split(',', ';').map { it.trim() }.filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return Parsed(emptyList(), Problem.EMPTY, null)
        val groups = ArrayList<List<Int>>()
        for (token in tokens) {
            val m = TOKEN.matchEntire(token) ?: return Parsed(emptyList(), Problem.SYNTAX, token)
            val a = m.groupValues[1]
            val dash = m.groupValues[2]
            val b = m.groupValues[3]
            // "5 8" (two numbers, no dash), "-" and "" are not ranges
            if ((dash.isEmpty() && (a.isEmpty() || b.isNotEmpty())) || (a.isEmpty() && b.isEmpty())) {
                return Parsed(emptyList(), Problem.SYNTAX, token)
            }
            val from = if (a.isEmpty()) 1L else (a.toLongOrNull() ?: return Parsed(emptyList(), Problem.OUT_OF_RANGE, token))
            val to = when {
                dash.isEmpty() -> from
                b.isEmpty() -> pageCount.toLong()
                else -> b.toLongOrNull() ?: return Parsed(emptyList(), Problem.OUT_OF_RANGE, token)
            }
            if (from < 1 || from > pageCount || to < 1 || to > pageCount) return Parsed(emptyList(), Problem.OUT_OF_RANGE, token)
            if (from > to) return Parsed(emptyList(), Problem.REVERSED, token)
            groups.add((from.toInt() - 1 until to.toInt()).toList())
        }
        return Parsed(groups, null, null)
    }

    /** Consecutive groups of [n] pages (the last one may be shorter); `n < 1` is treated as 1. */
    fun everyN(pageCount: Int, n: Int): List<List<Int>> = (0 until pageCount).toList().chunked(maxOf(1, n))

    /** "1-3" or "5" - for naming the output file of a group (1-based). */
    fun label(group: List<Int>): String =
        if (group.size == 1) "${group[0] + 1}" else "${group.first() + 1}-${group.last() + 1}"
}
