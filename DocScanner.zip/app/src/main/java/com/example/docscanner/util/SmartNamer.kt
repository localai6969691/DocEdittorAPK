package com.example.docscanner.util

import java.io.File

/**
 * Names for documents: a file name suggested from the text of the first page ("Hợp đồng thuê nhà" instead of
 * "scan_20261004_101533"), cleaned so it is a legal file name, and made unique inside a folder.
 *
 * Picking the title: Vietnamese official papers open with a fixed header ("CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM / Độc lập -
 * Tự do - Hạnh phúc") that says nothing about the document, so those lines are skipped; then the first of the first
 * [TITLE_SCAN_LINES] lines that STARTS with a word that usually begins a document title (hợp đồng, biên bản, đơn, giấy,
 * hóa đơn...) wins; failing that, the first line that looks like text (at least half letters - so dates, barcodes and
 * ruled lines are ignored). Matching ignores case and diacritics ([HistoryFilter.normalize]). The pure functions are
 * mirrored in tools/verify/smart_namer_check.py.
 */
object SmartNamer {

    const val MAX_LENGTH = 60
    private const val TITLE_SCAN_LINES = 20

    private val forbidden = charArrayOf('\\', '/', ':', '*', '?', '"', '<', '>', '|', '\n', '\r', '\t')

    /** Lines (normalized) that are the fixed header of Vietnamese official documents, not their title. */
    private val boilerplate = listOf(
        "cong hoa xa hoi chu nghia", "doc lap", "hanh phuc", "socialist republic", "independence", "freedom"
    )

    /** Words (normalized) that usually start a document's title. */
    private val titleStarts = listOf(
        "hop dong", "bien ban", "don xin", "don de nghi", "don ", "giay ", "hoa don", "quyet dinh", "thong bao",
        "bao cao", "to trinh", "cong van", "phieu ", "chung nhan", "giay phep", "de nghi", "cam ket", "uy quyen",
        "thu moi", "so yeu ly lich", "ly lich", "ke hoach", "bang ", "invoice", "contract", "receipt", "agreement",
        "certificate", "report", "minutes", "statement"
    )

    /** Legal file-name text: forbidden characters become spaces, runs of spaces collapse, no leading/trailing dots or spaces. */
    fun sanitize(raw: String): String {
        val replaced = raw.map { if (it in forbidden) ' ' else it }.joinToString("")
        val collapsed = replaced.replace(Regex("\\s+"), " ").trim().trim('.').trim()
        return collapsed.take(MAX_LENGTH).trim().trim('.').trim()
    }

    private fun looksLikeText(line: String): Boolean {
        val letters = line.count { it.isLetter() }
        val nonSpace = line.count { !it.isWhitespace() }
        return letters >= 4 && letters * 2 >= nonSpace
    }

    private fun cleanLine(line: String): String = line.trim().dropWhile { !it.isLetterOrDigit() }.trim()

    /** A suggested file name (no extension) from OCR [text], or null when nothing in it looks like a title. */
    fun fromText(text: String): String? {
        val lines = text.lines().map { cleanLine(it) }.filter { it.isNotEmpty() }
        val candidates = lines.take(TITLE_SCAN_LINES).filter { line ->
            val n = HistoryFilter.normalize(line)
            looksLikeText(line) && boilerplate.none { n.contains(it) }
        }
        val titled = candidates.firstOrNull { line ->
            val n = HistoryFilter.normalize(line) + " "
            titleStarts.any { n.startsWith(it) } && line.count { it.isLetter() } >= 5
        }
        val chosen = titled ?: candidates.firstOrNull() ?: return null
        val name = sanitize(chosen)
        return name.ifEmpty { null }
    }

    /** Base name for a file derived from [originalName] ("Hop dong.pdf", "numbered" -> "Hop dong_numbered"). */
    fun derivedBase(originalName: String, suffix: String): String {
        val stem = sanitize(originalName.substringBeforeLast('.', originalName)).ifEmpty { "document" }
        return sanitize(stem.take(MAX_LENGTH - suffix.length - 1) + "_" + suffix)
    }

    /** `base.ext`, or `base (2).ext`, `base (3).ext`... - the first name for which [exists] is false. */
    fun uniqueName(exists: (String) -> Boolean, base: String, extension: String): String {
        val ext = if (extension.isEmpty()) "" else ".$extension"
        var candidate = base + ext
        var n = 2
        while (exists(candidate)) {
            candidate = "$base ($n)$ext"
            n++
        }
        return candidate
    }

    fun uniqueFile(dir: File, base: String, extension: String): File =
        File(dir, uniqueName({ File(dir, it).exists() }, base, extension))

    /**
     * Renames [file] (and, for a PDF, its OCR `.txt` sidecar) to [newBase]; a name already taken gets " (2)".
     * @return the renamed file, or null if the new name is empty or the rename failed (nothing is changed then).
     */
    fun rename(file: File, newBase: String): File? {
        val clean = sanitize(newBase)
        if (clean.isEmpty()) return null
        val dir = file.parentFile ?: return null
        val ext = file.extension
        if (clean == file.nameWithoutExtension) return file
        val target = uniqueFile(dir, clean, ext)
        if (!file.renameTo(target)) return null
        if (ext.equals("pdf", ignoreCase = true)) {
            val sidecar = File(dir, file.nameWithoutExtension + ".txt")
            val sidecarTarget = File(dir, target.nameWithoutExtension + ".txt")
            if (sidecar.exists() && !sidecarTarget.exists()) sidecar.renameTo(sidecarTarget)
        }
        return target
    }
}
