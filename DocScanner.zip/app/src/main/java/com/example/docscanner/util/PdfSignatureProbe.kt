package com.example.docscanner.util

import java.io.File
import java.io.RandomAccessFile

/**
 * Finds the digital signatures of a PDF by reading the BYTES of the file (no PDF library, no Android class), so it is cheap on a
 * 200 MB scan, works on a file PdfBox could not parse, and can be run unchanged on the JVM next to the real signers (see
 * `tools/verify/signed_pdf_check.py` + `SignatureProbeCheck.java`, which compare it with poppler's `pdfsig`).
 *
 * WHY NOT PDFBox's `signatureDictionaries`: `PdfFormFiller.isSigned` uses it and needs the whole file parsed (slow, memory heavy, throws on a
 * damaged file). Here the question is only "will rewriting this file destroy a signature?", and the answer is in the file's bytes.
 *
 * HOW A SIGNATURE IS RECOGNISED (ISO 32000-1 12.8.1): the signature dictionary holds `/ByteRange [a b c d]` and `/Contents <hex>`. The signed
 * bytes are `[a, a+b)` + `[c, c+d)`, i.e. EVERYTHING except the hex string, so a real signature satisfies a STRUCTURAL property that text which
 * merely contains the word "/ByteRange" (a manual, a PDF about PDFs, a text string) practically never does: `a == 0`, the byte at `a+b` is `<`,
 * the byte at `c-1` is `>`, and `c+d` does not run past the end of the file. Everything else (SubFilter, DocTimeStamp, DocMDP level) is read
 * from the text of the SAME dictionary, which can sit on either side of the long hex string, so two windows are read: the one before the
 * string (back to the previous `endobj`) and the one after it (up to the next `endobj`).
 */
object PdfSignatureProbe {

    data class Signature(
        /** Offset of the `/ByteRange` key in the file. */
        val position: Long,
        val a: Long, val b: Long, val c: Long, val d: Long,
        /** `/SubFilter` name without the slash (`adbe.pkcs7.detached`, `ETSI.CAdES.detached`, `ETSI.RFC3161`...), or null. */
        val subFilter: String?,
        /** A document time stamp (`/Type /DocTimeStamp` or SubFilter `ETSI.RFC3161`): proves WHEN, does not approve the content. */
        val isTimestamp: Boolean,
        /** DocMDP level of a CERTIFYING signature: 1 = no change allowed, 2 = forms + signing, 3 = + annotations; 0 = not certifying. */
        val certifyLevel: Int
    ) {
        /** The first byte after the revision this signature protects. */
        val revisionEnd: Long get() = c + d
    }

    data class Result(val fileLength: Long, val signatures: List<Signature>) {
        /** Signatures that approve / certify content (everything but document time stamps), in file order. */
        val approvals: List<Signature> get() = signatures.filter { !it.isTimestamp }
        val timestamps: List<Signature> get() = signatures.filter { it.isTimestamp }
        /** Any signature or document time stamp: rewriting the file throws away what they vouch for. */
        val hasSignature: Boolean get() = signatures.isNotEmpty()
        /** 0 when no signature certifies; else the STRICTEST (lowest non-zero) DocMDP level. */
        val certifyLevel: Int get() = approvals.map { it.certifyLevel }.filter { it > 0 }.minOrNull() ?: 0
        /** Bytes exist after the last signed revision (an edit or a later, unsigned update): the file has been changed since it was signed. */
        val changedAfterLastSignature: Boolean get() = signatures.isNotEmpty() && signatures.maxOf { it.revisionEnd } < fileLength
    }

    enum class ToolKind {
        /** Reads only (compare, print, OCR text, translate, read aloud): nothing is written to the PDF. */
        READ_ONLY,
        /** Writes a whole new file (PdfBox full save, rasterize, merge, compress...): every byte may differ from the signed one. */
        REWRITES,
        /** Incremental update that fills form fields. */
        APPENDS_FORM,
        /** Incremental update that adds one more signature. */
        APPENDS_SIGNATURE
    }

    enum class Effect { NONE, KEEPS, BREAKS }

    /** What [tool] does to the signatures of [r]. [Effect.BREAKS] is the case the user must be warned about. */
    fun effect(r: Result, tool: ToolKind): Effect {
        if (!r.hasSignature) return Effect.NONE
        return when (tool) {
            ToolKind.READ_ONLY -> Effect.NONE
            ToolKind.REWRITES -> Effect.BREAKS
            ToolKind.APPENDS_FORM, ToolKind.APPENDS_SIGNATURE -> if (r.certifyLevel == 1) Effect.BREAKS else Effect.KEEPS
        }
    }

    private const val KEY = "/ByteRange"
    private const val MAX_SIGNATURES = 64
    private const val WINDOW = 4096
    private const val CHUNK = 1 shl 20

    fun scan(file: File): Result = RandomAccessFile(file, "r").use { scan(it) }

    /** [chunk] is only changed by the check on the JVM, to put the key exactly on a chunk edge. */
    internal fun scan(data: ByteArray, chunk: Int = CHUNK): Result = scanSource(data.size.toLong(), chunk) { off, len ->
        val from = off.coerceIn(0L, data.size.toLong()).toInt()
        val to = (off + len).coerceIn(from.toLong(), data.size.toLong()).toInt()
        data.copyOfRange(from, to)
    }

    private fun scan(raf: RandomAccessFile): Result = scanSource(raf.length(), CHUNK) { off, len ->
        if (off < 0 || off >= raf.length() || len <= 0) ByteArray(0) else {
            val n = minOf(len.toLong(), raf.length() - off).toInt()
            val buf = ByteArray(n)
            raf.seek(off)
            raf.readFully(buf)
            buf
        }
    }

    private fun scanSource(length: Long, chunkSize: Int, read: (Long, Int) -> ByteArray): Result {
        val keyBytes = KEY.toByteArray(Charsets.US_ASCII)
        val found = ArrayList<Signature>()
        var base = 0L
        while (base < length && found.size < MAX_SIGNATURES) {
            val chunk = read(base, chunkSize + keyBytes.size)
            if (chunk.isEmpty()) break
            var i = 0
            // the overlap of key.size bytes means a key cut by the chunk edge is found by the chunk it STARTS in, never twice: only starts < chunkSize count
            while (i < chunk.size && i < chunkSize) {
                if (matchesAt(chunk, i, keyBytes)) {
                    val sig = parseAt(base + i, length, read)
                    if (sig != null) found.add(sig)
                    i += keyBytes.size
                } else i++
            }
            base += chunkSize
        }
        return Result(length, found.sortedBy { it.position })
    }

    private fun matchesAt(buf: ByteArray, at: Int, key: ByteArray): Boolean {
        if (at + key.size > buf.size) return false
        for (k in key.indices) if (buf[at + k] != key[k]) return false
        return true
    }

    private fun isWs(b: Byte): Boolean = b.toInt() == 32 || b.toInt() == 10 || b.toInt() == 13 || b.toInt() == 9 || b.toInt() == 12 || b.toInt() == 0

    /** Reads `[a b c d]` after the key; null when it is not four plain non-negative integers (e.g. an unsigned placeholder `[0 ******** ...]`). */
    private fun parseRange(head: ByteArray, from: Int): LongArray? {
        var p = from
        while (p < head.size && isWs(head[p])) p++
        if (p >= head.size || head[p] != '['.code.toByte()) return null
        p++
        val out = LongArray(4)
        for (n in 0 until 4) {
            while (p < head.size && isWs(head[p])) p++
            val s = p
            var v = 0L
            while (p < head.size && head[p] >= '0'.code.toByte() && head[p] <= '9'.code.toByte()) {
                if (p - s > 15) return null
                v = v * 10 + (head[p] - '0'.code.toByte())
                p++
            }
            if (p == s) return null
            out[n] = v
        }
        while (p < head.size && isWs(head[p])) p++
        if (p >= head.size || head[p] != ']'.code.toByte()) return null
        return out
    }

    private fun parseAt(pos: Long, length: Long, read: (Long, Int) -> ByteArray): Signature? {
        val head = read(pos + KEY.length, 160)
        val r = parseRange(head, 0) ?: return null
        val (a, b, c, d) = r.toList()
        // structural test of a REAL signature (see the class comment)
        if (a != 0L || b <= 0L || c <= a + b || d < 0L || c + d > length) return null
        if (read(a + b, 1).firstOrNull() != '<'.code.toByte()) return null
        if (read(c - 1, 1).firstOrNull() != '>'.code.toByte()) return null

        // text of the dictionary: before the hex string (back to the previous endobj) + after it (up to the next endobj)
        val beforeStart = maxOf(0L, a + b - WINDOW)
        var before = String(read(beforeStart, (a + b - beforeStart).toInt()), Charsets.ISO_8859_1)
        val lastEnd = before.lastIndexOf("endobj")
        if (lastEnd >= 0) before = before.substring(lastEnd + 6)
        var after = String(read(c, WINDOW), Charsets.ISO_8859_1)
        val nextEnd = after.indexOf("endobj")
        if (nextEnd >= 0) after = after.substring(0, nextEnd)
        val meta = "$before $after"

        val sub = SUBFILTER.find(meta)?.groupValues?.get(1)
        val timestamp = DOC_TIMESTAMP.containsMatchIn(meta) || sub.equals("ETSI.RFC3161", ignoreCase = true)
        var level = 0
        if (DOC_MDP.containsMatchIn(meta)) {
            val params = meta.indexOf("/TransformParams").let { if (it >= 0) meta.substring(it) else meta }
            val m = P_LEVEL.find(params)
            level = m?.groupValues?.get(1)?.toInt() ?: 2 // DocMDP without /P means 2 (ISO 32000-1 Table 254)
        }
        return Signature(pos, a, b, c, d, sub, timestamp, level)
    }

    private val SUBFILTER = Regex("/SubFilter\\s*/([A-Za-z0-9._\\-]+)")
    private val DOC_TIMESTAMP = Regex("/Type\\s*/DocTimeStamp")
    private val DOC_MDP = Regex("/TransformMethod\\s*/DocMDP")
    private val P_LEVEL = Regex("/P(?![A-Za-z])\\s*([123])(?![0-9])")
}
