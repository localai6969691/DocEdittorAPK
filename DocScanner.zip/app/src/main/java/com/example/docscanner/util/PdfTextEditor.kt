package com.example.docscanner.util

import com.tom_roush.pdfbox.contentstream.operator.Operator
import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSBase
import com.tom_roush.pdfbox.cos.COSFloat
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSNumber
import com.tom_roush.pdfbox.cos.COSStream
import com.tom_roush.pdfbox.cos.COSString
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdfparser.PDFStreamParser
import com.tom_roush.pdfbox.pdfwriter.ContentStreamWriter
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.common.PDStream
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.font.PDType0Font
import com.tom_roush.pdfbox.pdmodel.font.PDType3Font
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * "Sửa chữ PDF" - find-and-replace a SHORT run of already-existing real text in an external PDF,
 * in place, without rasterizing the page. Deliberately the narrowest possible scope for this
 * (chosen and confirmed with the person before any of it was written - see TECHNICAL_DOCS.md,
 * phiên 8) - NOT real re-flow, NOT "edit like Word".
 *
 * ## Engine: PdfBox-Android (Apache 2.0), NOT iText (phiên 11)
 * This file used to sit on iText 7 (AGPL / paid commercial licence). A paid Google Play app cannot
 * ship AGPL code without either publishing its whole source or buying a yearly commercial licence,
 * so the engine was swapped for PdfBox-Android (Apache 2.0, free for commercial use). The DESIGN
 * below is unchanged; only the primitives differ:
 *  - the page's content stream is parsed into a flat token list with `PDFStreamParser(page)` (the
 *    documented PDFBox 2.x way; it also merges pages whose /Contents is an ARRAY of streams),
 *  - edited tokens are written back with `ContentStreamWriter` + `page.setContents(...)` (the same
 *    pattern PDFBox's own RemoveAllText/replace-text examples use).
 *
 * ## ONE traversal for reading AND writing (design rule kept from phiên 10)
 * Both [extractChunks] and [applyEdit] go through the SAME [scanPage] - one text-showing operator
 * (`Tj`/`'`/`"`/`TJ`) is one [TextChunk], numbered by [TextChunk.index] in strict token order.
 * There is exactly one place deciding "what counts as an operator and in what order", so read and
 * write counters cannot drift apart (the class of bug phiên 9/10 had to fix with iText).
 * Form XObjects are never entered (`Do` is just a token here) - so text inside them is neither
 * found nor editable, identically for read and write.
 *
 * A `TJ` array with several kerned fragments (`[(Hel) -20 (lo)] TJ`) is ONE chunk: the fragments are
 * literally elements of the same array in the same instruction - a structural fact, not a guess.
 * Merging fragments across two DIFFERENT operators would need a position heuristic and is NOT done.
 *
 * ## What this refuses rather than guesses at
 * - **[EditResult.UnsupportedFont]**: Type3 fonts, and Type0/CID fonts that ship without a usable
 *   `/ToUnicode` table (see "Encoding new text" below) - nothing reliable to map Unicode back to codes.
 * - **[EditResult.MissingGlyphs]**: the chunk's font cannot encode some new character. Most embedded
 *   fonts are subsets holding only the characters the document used; there is no honest way to add
 *   a glyph, and silently switching font would not match the document.
 *
 * ## Encoding new text (phiên 11 patch - the part PdfBox alone does not do for embedded subset fonts)
 * PdfBox's `PDFont.encode()` works for simple fonts whose glyph names it can resolve, but for an
 * embedded Type0/CID font (most PDFs from Word, Chrome, LibreOffice, InDesign) it cannot turn Unicode
 * back into character codes - the encode side was written for fonts the caller creates, not for fonts
 * read from a file. iText could edit these because its font layer also read the subset's own cmap.
 * Here the same information is taken from a source that is public in the PDF spec (ISO 32000-1,
 * 9.10.3): the font's `/ToUnicode` CMap lists exactly which codes the subset really contains and what
 * they mean. [ToUnicodeReverse] parses it (bfchar / bfrange) and inverts it: a character is available
 * iff some code in that table maps to it. Simple fonts try `font.encode()` first and only fall back to
 * this table when that fails.
 * - **[EditResult.ScaleOutOfRange]**: same-width replacement is done by horizontal scaling (`Tz`)
 *   to the original run's width; outside 40%-250% that would be illegible, so it is refused.
 *
 * ## Difference from the iText version (deliberate improvements)
 * 1. The scaled run is bracketed by `s Tz` ... `<previous> Tz`, NOT `q ... Q`. ISO 32000 does not
 *    allow `q`/`Q` inside a `BT ... ET` text object; some strict readers reject it. The previous
 *    Tz/Tc/Tw/font state is tracked through `q`/`Q` by [scanPage] so the restore value is exact.
 * 2. The scale accounts for the Tz that was ALREADY active (`s = Tz0 * Wold / Wnew`), and widths
 *    include Tc (char spacing) and Tw (word spacing) - the iText version ignored both.
 *
 * NOT verified on a real device yet (no Android SDK in the authoring environment) - see
 * TECHNICAL_DOCS.md, "Bảng mức tin cậy API PdfBox".
 */
object PdfTextEditor {

    private const val MIN_SCALE_PERCENT = 40f
    private const val MAX_SCALE_PERCENT = 250f

    /**
     * One piece of existing text. [box] = `[llx, lly, urx, ury]` in the page's own user space (where the run sits on the page, 4.69), or null when it cannot be known;
     * the in-reader "edit text" tool turns it into a box on the displayed page with [placedChunks] and finds the piece under a finger with [pick].
     */
    class TextChunk(val index: Int, val text: String, val fontSize: Float, val widthPt: Float, val box: FloatArray? = null) {
        override fun toString(): String = "TextChunk(index=$index, text=$text, fontSize=$fontSize, widthPt=$widthPt)"
    }

    /** A [TextChunk] and its box as fractions 0..1 of the DISPLAYED page (rotation and CropBox applied), `[x0, y0, x1, y1]` from the top-left. */
    class PlacedChunk(val chunk: TextChunk, val box: FloatArray)

    sealed class EditResult {
        object Success : EditResult()
        data class MissingGlyphs(val chars: String) : EditResult()
        data class ScaleOutOfRange(val percent: Float) : EditResult()
        object UnsupportedFont : EditResult()
        object ChunkNotFound : EditResult()
    }

    /** Everything [scanPage] learns about ONE text-showing operator. */
    internal class ScannedOp(
        /** position of the operator token itself inside the token list */
        val opTokenIndex: Int,
        /** position of the first operand belonging to this operator */
        val firstOperandIndex: Int,
        val opName: String,
        val font: PDFont?,
        val fontSize: Float,
        val tc: Float,
        val tw: Float,
        val tz: Float,
        val text: String,
        /** width in text space WITHOUT Tz applied (includes Tc/Tw) */
        val unscaledWidth: Float,
        /** `[llx, lly, urx, ury]` of the run in page user space (text matrix x CTM tracked through `cm`, `BT`, `Tm`, `Td`, `TD`, `T*`, `'`, `"`), or null */
        val box: FloatArray? = null,
        /** where the run's baseline starts in page user space, and the text matrix x CTM it is drawn with (for [PdfParagraphEditor]) */
        val originX: Float = 0f,
        val originY: Float = 0f,
        val matrix: FloatArray = floatArrayOf(1f, 0f, 0f, 1f, 0f, 0f)
    )

    internal class PageScan(val tokens: MutableList<Any>, val ops: List<ScannedOp>)

    private class TextState(
        var fontName: COSName? = null,
        var fontSize: Float = 0f,
        var tc: Float = 0f,
        var tw: Float = 0f,
        var tz: Float = 100f,
        var leading: Float = 0f,
        var rise: Float = 0f,
        var ctm: FloatArray = floatArrayOf(1f, 0f, 0f, 1f, 0f, 0f)
    ) {
        fun copy() = TextState(fontName, fontSize, tc, tw, tz, leading, rise, ctm.copyOf())
    }

    /** `first` then `second` as PDF matrices `[a b c d e f]` (row vectors: x' = a x + c y + e, y' = b x + d y + f). */
    internal fun multiply(first: FloatArray, second: FloatArray): FloatArray = floatArrayOf(
        first[0] * second[0] + first[1] * second[2],
        first[0] * second[1] + first[1] * second[3],
        first[2] * second[0] + first[3] * second[2],
        first[2] * second[1] + first[3] * second[3],
        first[4] * second[0] + first[5] * second[2] + second[4],
        first[4] * second[1] + first[5] * second[3] + second[5]
    )

    private fun translation(tx: Float, ty: Float): FloatArray = floatArrayOf(1f, 0f, 0f, 1f, tx, ty)

    /** Ascent and descent of [font] as fractions of the font size (descent negative); the font descriptor's own values when they are sane, else 0.8 / -0.2. */
    private fun verticalExtent(font: PDFont?): Pair<Float, Float> {
        val d = runCatching { font?.fontDescriptor }.getOrNull()
        val asc = d?.ascent?.div(1000f) ?: 0f
        val desc = d?.descent?.div(1000f) ?: 0f
        val okAsc = asc in 0.3f..1.2f
        val okDesc = desc in -0.6f..0f
        return Pair(if (okAsc) asc else 0.8f, if (okDesc && desc != 0f) desc else -0.2f)
    }

    private fun tokenNumber(tokens: List<Any>, index: Int): Float? =
        (tokens.getOrNull(index) as? COSNumber)?.floatValue()

    /** Decodes [bytes] with [font] into text + unscaled advance width (text space, Tz not applied). */
    internal fun decodeAndMeasure(font: PDFont, bytes: ByteArray, fontSize: Float, tc: Float, tw: Float): Pair<String, Float> {
        val sb = StringBuilder()
        var width = 0f
        val input = ByteArrayInputStream(bytes)
        while (input.available() > 0) {
            val before = input.available()
            val code = font.readCode(input)
            val used = before - input.available()
            if (used <= 0) break // defensive: never loop forever on a malformed string
            sb.append(runCatching { font.toUnicode(code) }.getOrNull() ?: "")
            val glyphWidth = runCatching { font.getWidth(code) }.getOrDefault(0f)
            width += glyphWidth / 1000f * fontSize + tc + (if (used == 1 && code == 32) tw else 0f)
        }
        return Pair(sb.toString(), width)
    }

    /**
     * Parses page [pageNumber] (1-based) into tokens and lists every text-showing operator in token
     * order, tracking the text state (font, size, Tc, Tw, Tz) through `q`/`Q`. Read-only: never
     * touches [document]. This is the single traversal shared by reading and writing.
     */
    internal fun scanPage(document: PDDocument, pageNumber: Int): PageScan {
        val page: PDPage = document.getPage(pageNumber - 1)
        val parser = PDFStreamParser(page)
        parser.parse()
        val tokens: MutableList<Any> = ArrayList(parser.tokens)

        val resources = page.resources
        val fontCache = HashMap<COSName, PDFont?>()
        fun fontFor(name: COSName?): PDFont? {
            if (name == null || resources == null) return null
            return fontCache.getOrPut(name) { runCatching { resources.getFont(name) }.getOrNull() }
        }

        var state = TextState()
        val stack = ArrayList<TextState>()
        val ops = ArrayList<ScannedOp>()
        var lastOperatorIndex = -1
        // where the text is (4.69): the text matrix and the line matrix are NOT part of the saved graphics state, the CTM is (it lives in TextState)
        var tm = floatArrayOf(1f, 0f, 0f, 1f, 0f, 0f)
        var tlm = floatArrayOf(1f, 0f, 0f, 1f, 0f, 0f)
        fun numbersBefore(i: Int, count: Int): FloatArray? {
            if (i < count) return null
            val v = FloatArray(count)
            for (k in 0 until count) v[k] = tokenNumber(tokens, i - count + k) ?: return null
            return v
        }

        for ((i, token) in tokens.withIndex()) {
            if (token !is Operator) continue
            val name = token.name
            val firstOperand = lastOperatorIndex + 1
            when (name) {
                "q" -> stack.add(state.copy())
                "Q" -> if (stack.isNotEmpty()) state = stack.removeAt(stack.size - 1)
                "Tf" -> {
                    state.fontName = tokens.getOrNull(i - 2) as? COSName
                    state.fontSize = tokenNumber(tokens, i - 1) ?: state.fontSize
                }
                "Tc" -> state.tc = tokenNumber(tokens, i - 1) ?: state.tc
                "Tw" -> state.tw = tokenNumber(tokens, i - 1) ?: state.tw
                "Tz" -> state.tz = tokenNumber(tokens, i - 1) ?: state.tz
                "TL" -> state.leading = tokenNumber(tokens, i - 1) ?: state.leading
                "Ts" -> state.rise = tokenNumber(tokens, i - 1) ?: state.rise
                "cm" -> numbersBefore(i, 6)?.let { state.ctm = multiply(it, state.ctm) }
                "BT" -> {
                    tm = floatArrayOf(1f, 0f, 0f, 1f, 0f, 0f)
                    tlm = tm.copyOf()
                }
                "Tm" -> numbersBefore(i, 6)?.let {
                    tm = it
                    tlm = it.copyOf()
                }
                "Td", "TD" -> numbersBefore(i, 2)?.let {
                    if (name == "TD") state.leading = -it[1]
                    tlm = multiply(translation(it[0], it[1]), tlm)
                    tm = tlm.copyOf()
                }
                "T*" -> {
                    tlm = multiply(translation(0f, -state.leading), tlm)
                    tm = tlm.copyOf()
                }
                "Tj", "'", "\"", "TJ" -> {
                    if (name == "\"") {
                        // operands: aw ac string  ->  sets word/char spacing, then shows the string
                        state.tw = tokenNumber(tokens, i - 3) ?: state.tw
                        state.tc = tokenNumber(tokens, i - 2) ?: state.tc
                    }
                    if (name == "'" || name == "\"") {
                        // both start with T* (the next line), then show the string
                        tlm = multiply(translation(0f, -state.leading), tlm)
                        tm = tlm.copyOf()
                    }
                    val font = fontFor(state.fontName)
                    var text = ""
                    var width = 0f
                    if (font != null) {
                        if (name == "TJ") {
                            val array = tokens.getOrNull(i - 1) as? COSArray
                            if (array != null) {
                                val sb = StringBuilder()
                                for (k in 0 until array.size()) {
                                    when (val el: COSBase? = array.get(k)) {
                                        is COSString -> {
                                            val (t, w) = decodeAndMeasure(font, el.bytes, state.fontSize, state.tc, state.tw)
                                            sb.append(t)
                                            width += w
                                        }
                                        is COSNumber -> width -= el.floatValue() / 1000f * state.fontSize
                                        else -> {}
                                    }
                                }
                                text = sb.toString()
                            }
                        } else {
                            val str = tokens.getOrNull(i - 1) as? COSString
                            if (str != null) {
                                val (t, w) = decodeAndMeasure(font, str.bytes, state.fontSize, state.tc, state.tw)
                                text = t
                                width = w
                            }
                        }
                    }
                    // the run's box in user space: its width along the text line, the font's ascent / descent up and down, through the text matrix and the CTM
                    val runWidth = width * state.tz / 100f
                    var box: FloatArray? = null
                    if (font != null && runWidth != 0f && state.fontSize != 0f) {
                        val (ascent, descent) = verticalExtent(font)
                        val low = state.rise + descent * state.fontSize
                        val high = state.rise + ascent * state.fontSize
                        val m = multiply(tm, state.ctm)
                        val xs = floatArrayOf(0f, runWidth, runWidth, 0f)
                        val ys = floatArrayOf(low, low, high, high)
                        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
                        for (k in 0 until 4) {
                            val ux = m[0] * xs[k] + m[2] * ys[k] + m[4]
                            val uy = m[1] * xs[k] + m[3] * ys[k] + m[5]
                            minX = minOf(minX, ux); maxX = maxOf(maxX, ux); minY = minOf(minY, uy); maxY = maxOf(maxY, uy)
                        }
                        box = floatArrayOf(minX, minY, maxX, maxY)
                    }
                    val runMatrix = multiply(tm, state.ctm)
                    ops.add(
                        ScannedOp(
                            opTokenIndex = i, firstOperandIndex = firstOperand, opName = name, font = font,
                            fontSize = state.fontSize, tc = state.tc, tw = state.tw, tz = state.tz,
                            text = text, unscaledWidth = width, box = box,
                            originX = runMatrix[4], originY = runMatrix[5], matrix = runMatrix
                        )
                    )
                    // the next run on the line starts where this one ended
                    tm = multiply(translation(runWidth, 0f), tm)
                }
            }
            lastOperatorIndex = i
        }
        return PageScan(tokens, ops)
    }

    /** Lists every non-blank text-showing operator on page [pageNumber] (1-based), in document
     *  order. [TextChunk.index] is that operator's ordinal among ALL text-showing operators on the
     *  page (blank ones counted, just not returned) - [applyEdit] relies on this exact numbering, so
     *  callers must hand the [TextChunk] back exactly as returned here. */
    fun extractChunks(document: PDDocument, pageNumber: Int): List<TextChunk> {
        val scan = scanPage(document, pageNumber)
        val chunks = ArrayList<TextChunk>()
        scan.ops.forEachIndexed { index, op ->
            if (op.text.isNotBlank()) {
                chunks.add(TextChunk(index, op.text, op.fontSize, op.unscaledWidth * op.tz / 100f, op.box))
            }
        }
        return chunks
    }

    /**
     * The editable pieces of page [pageNumber] (1-based) with where they sit on the page AS DISPLAYED (4.69): [PdfPageGeometry.inverseMatrixValues] takes the user-space box to the upright
     * bottom-left frame, then x / width and 1 - y / height give fractions from the top-left. Pieces whose position is unknown or lies wholly outside the page are left out.
     */
    fun placedChunks(document: PDDocument, pageNumber: Int): List<PlacedChunk> {
        val page = document.getPage(pageNumber - 1)
        val geo = PdfPageGeometry.of(page)
        val inv = geo.inverseMatrixValues()
        val w = geo.displayWidth
        val h = geo.displayHeight
        if (w <= 0f || h <= 0f) return emptyList()
        val out = ArrayList<PlacedChunk>()
        for (chunk in extractChunks(document, pageNumber)) {
            val b = chunk.box ?: continue
            var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
            val us = floatArrayOf(b[0], b[2], b[2], b[0])
            val vs = floatArrayOf(b[1], b[1], b[3], b[3])
            for (k in 0 until 4) {
                val dx = inv[0] * us[k] + inv[2] * vs[k] + inv[4]
                val dy = inv[1] * us[k] + inv[3] * vs[k] + inv[5]
                val fx = dx / w
                val fy = 1f - dy / h
                minX = minOf(minX, fx); maxX = maxOf(maxX, fx); minY = minOf(minY, fy); maxY = maxOf(maxY, fy)
            }
            if (maxX <= 0f || maxY <= 0f || minX >= 1f || minY >= 1f) continue
            out.add(PlacedChunk(chunk, floatArrayOf(minX.coerceIn(0f, 1f), minY.coerceIn(0f, 1f), maxX.coerceIn(0f, 1f), maxY.coerceIn(0f, 1f))))
        }
        return out
    }

    /**
     * The piece of text under a tap at (x, y) (fractions 0..1 from the top-left): among the boxes that contain the point grown by [slop] on every side, the SMALLEST one (a word box inside a
     * bigger line wins), ties go to the nearer centre; null when none is near. A box that has no area counts as its centre point.
     */
    fun pick(chunks: List<PlacedChunk>, x: Float, y: Float, slop: Float = 0.006f): PlacedChunk? {
        var best: PlacedChunk? = null
        var bestArea = Float.MAX_VALUE
        var bestDistance = Float.MAX_VALUE
        for (c in chunks) {
            val b = c.box
            if (x < b[0] - slop || x > b[2] + slop || y < b[1] - slop || y > b[3] + slop) continue
            val area = (b[2] - b[0]) * (b[3] - b[1])
            val dx = x - (b[0] + b[2]) / 2f
            val dy = y - (b[1] + b[3]) / 2f
            val distance = dx * dx + dy * dy
            if (area < bestArea || (area == bestArea && distance < bestDistance)) {
                best = c
                bestArea = area
                bestDistance = distance
            }
        }
        return best
    }

    /** Result of turning new text into the font's own character codes. */
    internal class Encoded(val bytes: ByteArray?, val missing: String, val noMapping: Boolean)

    /** Parsed `/ToUnicode` CMap of [font], inverted: code point -> code. Empty when there is none. */
    private fun reverseMapOf(font: PDFont): Map<Int, ToUnicodeReverse.Entry> {
        val stream = font.cosObject.getDictionaryObject(COSName.getPDFName("ToUnicode")) as? COSStream
            ?: return emptyMap()
        val bytes = runCatching { stream.createInputStream().use { it.readBytes() } }.getOrNull() ?: return emptyMap()
        return ToUnicodeReverse.parse(bytes)
    }

    internal fun encodeText(font: PDFont, text: String): Encoded {
        var reverse: Map<Int, ToUnicodeReverse.Entry>? = null
        fun reverseMap(): Map<Int, ToUnicodeReverse.Entry> = reverse ?: reverseMapOf(font).also { reverse = it }

        val out = ByteArrayOutputStream()
        val missing = StringBuilder()
        text.codePoints().forEach { cp ->
            val ch = String(Character.toChars(cp))
            var bytes: ByteArray? = null
            // Simple fonts: PdfBox's own encoder first (it also checks the glyph exists in the font program).
            if (font !is PDType0Font) bytes = runCatching { font.encode(ch) }.getOrNull()
            if (bytes == null) bytes = reverseMap()[cp]?.toBytes()
            if (bytes == null) {
                if (!missing.contains(ch)) missing.append(ch)
            } else {
                out.write(bytes)
            }
        }
        val noMapping = font is PDType0Font && reverseMap().isEmpty()
        return if (missing.isEmpty() && !noMapping) Encoded(out.toByteArray(), "", false)
        else Encoded(null, missing.toString(), noMapping)
    }

    /** Every character of [newText] that [chunk]'s font cannot render, as one string (empty when all
     *  are supported). A cheap live-feedback check; [applyEdit] always re-checks before writing. */
    fun findMissingGlyphs(document: PDDocument, pageNumber: Int, chunk: TextChunk, newText: String): String {
        val font = scanPage(document, pageNumber).ops.getOrNull(chunk.index)?.font ?: return newText
        return encodeText(font, newText).missing
    }

    /**
     * Replaces [chunk]'s text on page [pageNumber] with [newText]. The new text's width is matched to
     * the ORIGINAL run by horizontal scaling: the operator is bracketed as
     * `<scale> Tz  <operands> <op>  <previous Tz> Tz`, with `scale = Tz0 * Wold / Wnew` and Wold/Wnew
     * measured the same way (same font, size, Tc, Tw), so whatever follows on the same line keeps its
     * position. A multi-fragment `TJ` becomes a one-element array (old kerning numbers were tuned for
     * the OLD characters and mean nothing for new ones).
     *
     * [document] and [pageNumber] must be the same document/page [chunk] came from, unmodified since.
     * Editing 2 chunks of the same page = calling this twice (each a full fresh edit).
     */
    fun applyEdit(document: PDDocument, pageNumber: Int, chunk: TextChunk, newText: String): EditResult {
        val scan = scanPage(document, pageNumber)
        val op = scan.ops.getOrNull(chunk.index) ?: return EditResult.ChunkNotFound
        val font = op.font ?: return EditResult.UnsupportedFont
        // Type3 glyphs are arbitrary drawing procedures - there is no text-to-code mapping to rely on.
        if (font is PDType3Font) return EditResult.UnsupportedFont

        val encoded = encodeText(font, newText)
        if (encoded.noMapping) return EditResult.UnsupportedFont
        if (encoded.missing.isNotEmpty()) return EditResult.MissingGlyphs(encoded.missing)
        val newBytes = encoded.bytes ?: return EditResult.MissingGlyphs(newText)
        val newWidth = decodeAndMeasure(font, newBytes, op.fontSize, op.tc, op.tw).second
        val scalePercent = if (newWidth > 0f && op.unscaledWidth > 0f) op.tz * op.unscaledWidth / newWidth else op.tz
        if (scalePercent < MIN_SCALE_PERCENT || scalePercent > MAX_SCALE_PERCENT) {
            return EditResult.ScaleOutOfRange(scalePercent)
        }

        val tokens = scan.tokens
        // 1) substitute the operand(s)
        val opIdx = op.opTokenIndex
        val replacement = COSString(newBytes)
        if (op.opName == "TJ") {
            val newArray = COSArray()
            newArray.add(replacement)
            if (tokens.getOrNull(opIdx - 1) !is COSArray) return EditResult.ChunkNotFound
            tokens[opIdx - 1] = newArray
        } else {
            if (tokens.getOrNull(opIdx - 1) !is COSString) return EditResult.ChunkNotFound
            tokens[opIdx - 1] = replacement
        }
        // 2) bracket with Tz (restore AFTER first so the earlier insert index stays valid)
        val needsScale = kotlin.math.abs(scalePercent - op.tz) > 0.05f
        if (needsScale) {
            tokens.add(opIdx + 1, Operator.getOperator("Tz"))
            tokens.add(opIdx + 1, COSFloat(op.tz))
            tokens.add(op.firstOperandIndex, Operator.getOperator("Tz"))
            tokens.add(op.firstOperandIndex, COSFloat(scalePercent))
        }

        // 3) write the token list back as the page's (single) content stream
        val newStream = PDStream(document)
        newStream.createOutputStream(COSName.FLATE_DECODE).use { out ->
            ContentStreamWriter(out).writeTokens(tokens)
        }
        document.getPage(pageNumber - 1).setContents(newStream)
        return EditResult.Success
    }

    /** One replacement for [applyAll]: [page] is 1-based, [chunkIndex] is [TextChunk.index], [newText] the new wording. */
    class Replacement(val page: Int, val chunkIndex: Int, val newText: String)

    private fun openForEdit(file: File): PDDocument =
        PDDocument.load(file, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(file.parentFile))

    /**
     * Whether [newText] could replace piece [chunkIndex] of page [page] (1-based) of [file]: the edit is made on a copy in memory and thrown away (4.69), so the in-reader tool can say at once
     * "this font has no such letter" or "too long" instead of at "Save a copy". A damaged or unreadable file answers [EditResult.ChunkNotFound].
     */
    fun trial(file: File, page: Int, chunkIndex: Int, newText: String): EditResult {
        val doc = try { openForEdit(file) } catch (e: Exception) { return EditResult.ChunkNotFound }
        try {
            if (page !in 1..doc.numberOfPages) return EditResult.ChunkNotFound
            val chunk = extractChunks(doc, page).find { it.index == chunkIndex } ?: return EditResult.ChunkNotFound
            return applyEdit(doc, page, chunk, newText)
        } catch (e: Exception) {
            return EditResult.ChunkNotFound
        } finally {
            runCatching { doc.close() }
        }
    }

    /** The pieces of page [page] (1-based) of [file] with their boxes on the displayed page, read from a fresh copy of the file; an unreadable page gives an empty list. */
    fun placedChunks(file: File, page: Int): List<PlacedChunk> {
        val doc = try { openForEdit(file) } catch (e: Exception) { return emptyList() }
        try {
            if (page !in 1..doc.numberOfPages) return emptyList()
            return placedChunks(doc, page)
        } catch (e: Exception) {
            return emptyList()
        } finally {
            runCatching { doc.close() }
        }
    }

    /**
     * Writes every replacement of [edits] into a NEW file [out] (the original is not touched), in the order given: each is a full fresh [applyEdit] on the page as the previous ones left it
     * (the numbering of pieces does not change, see [extractChunks]). Throws `IllegalStateException` naming the first replacement that cannot be made, rather than saving a copy that
     * silently lacks an edit the person made; the output must open as a PDF with the same number of pages ([PdfVerify]).
     */
    fun applyAll(src: File, out: File, edits: List<Replacement>) {
        val doc = openForEdit(src)
        try {
            val pages = doc.numberOfPages
            for (edit in edits) {
                if (edit.page !in 1..pages) throw IllegalStateException("page " + edit.page + " not found")
                val chunk = extractChunks(doc, edit.page).find { it.index == edit.chunkIndex }
                    ?: throw IllegalStateException("text piece " + edit.chunkIndex + " not found on page " + edit.page)
                val result = applyEdit(doc, edit.page, chunk, edit.newText)
                if (result !is EditResult.Success) throw IllegalStateException("text edit refused on page " + edit.page + ": " + result)
            }
            doc.save(out)
            if (!PdfVerify.opensAsPdf(out, pages)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
        } finally {
            runCatching { doc.close() }
        }
    }
}

/**
 * Inverts a font's `/ToUnicode` CMap (ISO 32000-1, 9.10.3 - `beginbfchar` / `beginbfrange` sections)
 * into "Unicode code point -> character code (+ its byte length)". Only single-code-point targets are
 * kept (ligature entries such as "fi" cannot be produced one character at a time). The first code
 * listed for a code point wins. Tolerant by design: anything it cannot read is skipped, and an empty
 * result simply means "this font offers no editable characters".
 */
internal object ToUnicodeReverse {

    class Entry(val code: Int, val byteLength: Int) {
        fun toBytes(): ByteArray = ByteArray(byteLength) { i -> (code ushr (8 * (byteLength - 1 - i))).toByte() }
    }

    private val BF_CHAR = Regex("beginbfchar(.*?)endbfchar", RegexOption.DOT_MATCHES_ALL)
    private val BF_RANGE = Regex("beginbfrange(.*?)endbfrange", RegexOption.DOT_MATCHES_ALL)
    private val CHAR_PAIR = Regex("<([0-9A-Fa-f\\s]+)>\\s*<([0-9A-Fa-f\\s]+)>")
    private val RANGE_ITEM = Regex("<([0-9A-Fa-f\\s]+)>\\s*<([0-9A-Fa-f\\s]+)>\\s*(?:<([0-9A-Fa-f\\s]+)>|\\[(.*?)])", RegexOption.DOT_MATCHES_ALL)
    private val HEX_TOKEN = Regex("<([0-9A-Fa-f\\s]+)>")

    private fun hexOf(token: String): String = token.filter { !it.isWhitespace() }

    /** UTF-16BE hex -> the single code point it spells, or null (empty / several code points / bad hex). */
    private fun singleCodePoint(hex: String): Int? {
        val h = hexOf(hex)
        if (h.isEmpty() || h.length % 4 != 0 && h.length != 2) return null
        val padded = if (h.length == 2) "00$h" else h
        val bytes = ByteArray(padded.length / 2) { i -> padded.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
        val str = String(bytes, Charsets.UTF_16BE)
        return if (str.codePointCount(0, str.length) == 1) str.codePointAt(0) else null
    }

    fun parse(cmap: ByteArray): Map<Int, Entry> {
        val text = String(cmap, Charsets.ISO_8859_1)
        val result = LinkedHashMap<Int, Entry>()
        fun add(cp: Int?, code: Int, byteLength: Int) {
            if (cp != null && cp > 0 && byteLength in 1..4) result.putIfAbsent(cp, Entry(code, byteLength))
        }

        for (section in BF_CHAR.findAll(text)) {
            for (m in CHAR_PAIR.findAll(section.groupValues[1])) {
                val src = hexOf(m.groupValues[1])
                if (src.isEmpty() || src.length % 2 != 0 || src.length > 8) continue
                add(singleCodePoint(m.groupValues[2]), src.toLong(16).toInt(), src.length / 2)
            }
        }
        for (section in BF_RANGE.findAll(text)) {
            for (m in RANGE_ITEM.findAll(section.groupValues[1])) {
                val lo = hexOf(m.groupValues[1])
                val hi = hexOf(m.groupValues[2])
                if (lo.isEmpty() || lo.length != hi.length || lo.length % 2 != 0 || lo.length > 8) continue
                val first = lo.toLong(16)
                val last = hi.toLong(16)
                if (last < first || last - first > 0xFFFF) continue
                val byteLength = lo.length / 2
                val single = m.groupValues[3]
                if (single.isNotEmpty()) {
                    val base = singleCodePoint(single) ?: continue
                    for (i in 0..(last - first).toInt()) add(base + i, (first + i).toInt(), byteLength)
                } else {
                    val targets = HEX_TOKEN.findAll(m.groupValues[4]).toList()
                    for ((i, t) in targets.withIndex()) {
                        if (first + i > last) break
                        add(singleCodePoint(t.groupValues[1]), (first + i).toInt(), byteLength)
                    }
                }
            }
        }
        return result
    }
}
