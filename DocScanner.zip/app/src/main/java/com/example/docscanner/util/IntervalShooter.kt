package com.example.docscanner.util

/**
 * The clock of "burst shooting" (PDF list A5): after the person taps the shutter ONCE, the camera takes a photo every [intervalMs] while they
 * turn the pages of a book, until they tap again or [maxShots] is reached. Pure logic with an injected clock, so it can be tested without a camera
 * (tools/verify/interval_shooter_check.py runs its Java twin IntervalShooterCheck.java through hundreds of simulated sessions).
 *
 * Rules, each one tested:
 *  - the FIRST shot is due immediately after [start];
 *  - the interval is measured from the START of a shot to the start of the next, and a new shot is never due while the previous one is still being
 *    saved ([onShotStarted] .. [onShotFinished]): a slow phone therefore shoots slower, it never queues two shots on top of each other;
 *  - there is no catch-up: if the screen stalled for 10 intervals, ONE shot is due, not ten;
 *  - after [maxShots] started shots the session ends by itself (when the last one has finished), so a forgotten burst cannot fill the storage;
 *  - after [stop] nothing is ever due, but a shot already being saved still finishes normally.
 */
class IntervalShooter(val intervalMs: Long, val maxShots: Int = MAX_SHOTS) {

    var running = false
        private set
    var shots = 0
        private set
    private var busy = false
    private var nextAt = 0L

    fun start(now: Long) {
        running = true
        shots = 0
        busy = false
        nextAt = now
    }

    fun stop() {
        running = false
    }

    /** True when a photo should be taken NOW; the caller then calls [onShotStarted]. */
    fun due(now: Long): Boolean {
        if (!running || busy) return false
        if (shots >= maxShots) return false
        return now >= nextAt
    }

    fun onShotStarted(now: Long) {
        busy = true
        shots++
        nextAt = now + intervalMs
    }

    /** Called when the photo was saved OR failed: a failed shot is not retried, the next one comes at its normal time. */
    fun onShotFinished() {
        busy = false
        if (shots >= maxShots) running = false
    }

    /** Milliseconds until the next shot is due (0 when due or being saved), for the countdown shown on screen. */
    fun msUntilNext(now: Long): Long = if (busy) 0L else maxOf(0L, nextAt - now)

    companion object {
        const val MAX_SHOTS = 300
        /** The choices offered by the button, in seconds (0 = off). */
        val CHOICES_SECONDS = intArrayOf(0, 2, 3, 5)
    }
}
