package com.example.docscanner.adapter

import android.graphics.Bitmap
import android.util.LruCache
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.databinding.ItemReaderPageBinding
import com.example.docscanner.util.PdfTextMarkup
import com.example.docscanner.util.ReaderEdits
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * The pages of the in-app PDF reader ([com.example.docscanner.PdfReaderActivity]): one picture per page, drawn only when its row is on (or near) the screen and thrown
 * away when the row is recycled, so a 500-page PDF holds a handful of bitmaps. [render] draws page `index` at a given pixel width and may return null (a page that
 * fails stays blank); it runs off the main thread and must be safe to call from there. A placeholder of A4 height keeps the scroll bar steady until the page arrives.
 */
class PdfReaderPageAdapter(
    private val pageCount: Int,
    /** Width pages are drawn at; the reader raises it while zoomed in and calls [applyWidth] so the pages come out sharp. */
    var widthPx: Int,
    /** Width of the screen: the placeholder height is taken from it, not from [widthPx], so changing the drawing width does not make the rows jump. */
    private val placeholderWidthPx: Int,
    private val scope: CoroutineScope,
    private val label: (Int) -> String,
    private val render: (Int, Int) -> Bitmap?
) : RecyclerView.Adapter<PdfReaderPageAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemReaderPageBinding) : RecyclerView.ViewHolder(binding.root) {
        var job: Job? = null
    }

    /** The active editing tool of the reader (null = reading) and the marks made so far; changing them is shown with [refreshOverlays] / [refreshOverlay]. */
    var tool: ReaderEdits.Kind? = null
    var edits: ReaderEdits? = null

    /** A frame was dragged on page `page`: box 0..1. */
    var onFrame: ((Int, FloatArray) -> Unit)? = null

    /** A highlight / underline / strike-out drag on page `page`: start x, y and end x, y as fractions of the page. */
    var onTextDrag: ((Int, Float, Float, Float, Float) -> Unit)? = null

    /** The words of a page, or null while they are still being read (the reader then asks for them and refreshes the row): only asked for while a text tool is active. */
    var wordsProvider: ((Int) -> List<PdfTextMarkup.WordBox>?)? = null

    /** The boxes of the existing text pieces of a page that the edit-text tool can change, or null while they are still being read (the reader then asks for them and refreshes the row). */
    var textBoxesProvider: ((Int) -> List<FloatArray>?)? = null

    /** The boxes of the words the person searched for on a page, or null while the page's words are still being read (4.77). */
    var searchBoxesProvider: ((Int) -> List<FloatArray>?)? = null

    /** The eraser touched page `page`: x, y (view pixels), view width, view height (4.72). */
    var onErase: ((Int, Float, Float, Float, Float) -> Unit)? = null

    /** Thickness of the pen / marker stroke being drawn, as a fraction of the page width; 0 = the tool's usual thickness. */
    var toolWidth: Float = 0f

    /** The text tool or the edit-text tool was tapped on page `page`: x, y (view pixels), view width, view height. */
    var onTap: ((Int, Float, Float, Float, Float) -> Unit)? = null

    /** The pen or marker finished a stroke on page `page`: points as fractions of the page. */
    var onStroke: ((Int, FloatArray) -> Unit)? = null

    /** Colour of the active tool (the pen, the marker, the highlight, the underline, the strike-out, the text). */
    var toolColor: Int = ReaderEdits.DEFAULT_COLOR

    /** Pictures already drawn, by page and width: a row that comes back into view (scrolling up, zooming out) shows its picture at once instead of flashing blank (4.66). */
    private val cache = object : LruCache<Long, Bitmap>(((Runtime.getRuntime().maxMemory() / 8).coerceAtMost(64L * 1024 * 1024)).toInt()) {
        override fun sizeOf(key: Long, value: Bitmap): Int = value.allocationByteCount
    }

    private fun key(page: Int, width: Int): Long = (page.toLong() shl 32) or width.toLong()

    /**
     * Draws every row at [newWidth] WITHOUT throwing the rows away: notifyDataSetChanged recycled them all, [onViewRecycled] cleared their pictures and the A4 placeholder gave them
     * a different height, so after every pinch the whole screen blinked white and jumped (4.66, seen on the first phone test). A change with a payload keeps each row and its old
     * picture on screen until the sharper (or lighter) one arrives.
     */
    fun applyWidth(newWidth: Int) {
        if (newWidth == widthPx) return
        widthPx = newWidth
        notifyItemRangeChanged(0, itemCount, PAYLOAD_SHARPEN)
    }

    /** Redraws only the marks and the tool of every row: the page pictures are not drawn again. */
    fun refreshOverlays() = notifyItemRangeChanged(0, itemCount, PAYLOAD_OVERLAY)

    fun refreshOverlay(page: Int) = notifyItemChanged(page, PAYLOAD_OVERLAY)

    private fun bindOverlay(holder: ViewHolder) {
        val view = holder.binding.ivPage
        val page = holder.bindingAdapterPosition
        if (page == RecyclerView.NO_POSITION) return
        view.tool = tool
        view.overlays = edits?.on(page) ?: emptyList()
        view.onFrame = { box -> onFrame?.invoke(holder.bindingAdapterPosition, box) }
        view.onTap = { x, y, w, h -> onTap?.invoke(holder.bindingAdapterPosition, x, y, w, h) }
        view.onStroke = { points -> onStroke?.invoke(holder.bindingAdapterPosition, points) }
        view.onTextDrag = { ax, ay, bx, by -> onTextDrag?.invoke(holder.bindingAdapterPosition, ax, ay, bx, by) }
        view.words = if (ReaderEdits.isTextMark(tool)) wordsProvider?.invoke(page) ?: emptyList() else emptyList()
        view.textBoxes = if (tool == ReaderEdits.Kind.EDITTEXT) textBoxesProvider?.invoke(page) ?: emptyList() else emptyList()
        view.toolColor = toolColor
        view.searchBoxes = searchBoxesProvider?.invoke(page) ?: emptyList()
        view.toolWidth = toolWidth
        view.onErase = { x, y, w, h -> onErase?.invoke(holder.bindingAdapterPosition, x, y, w, h) }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(ItemReaderPageBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty() && payloads.all { it == PAYLOAD_OVERLAY }) {
            bindOverlay(holder)
            return
        }
        if (payloads.isNotEmpty() && payloads.all { it == PAYLOAD_SHARPEN }) {
            bindPage(holder, position)
            return
        }
        super.onBindViewHolder(holder, position, payloads)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        bindOverlay(holder)
        bindPage(holder, position)
    }

    /** Shows the picture of page [position] at [widthPx]: from the cache at once if it is there, else the old picture stays (or the placeholder shows) until it has been drawn. */
    private fun bindPage(holder: ViewHolder, position: Int) {
        holder.job?.cancel()
        val view = holder.binding.ivPage
        view.contentDescription = label(position)
        val width = widthPx
        val cached = cache.get(key(position, width))
        if (cached != null) {
            view.minimumHeight = 0
            view.setImageBitmap(cached)
            return
        }
        if (view.drawable == null) view.minimumHeight = (placeholderWidthPx * 1.41f).toInt()
        holder.job = scope.launch {
            val bitmap = withContext(Dispatchers.Default) { render(position, width) }
            if (bitmap != null && isActive) {
                cache.put(key(position, width), bitmap)
                view.minimumHeight = 0
                view.setImageBitmap(bitmap)
            }
        }
    }

    override fun onViewRecycled(holder: ViewHolder) {
        holder.job?.cancel()
        holder.job = null
        holder.binding.ivPage.setImageDrawable(null)
    }

    override fun getItemCount(): Int = pageCount

    companion object {
        private const val PAYLOAD_OVERLAY = "overlay"
        private const val PAYLOAD_SHARPEN = "sharpen"
    }
}
