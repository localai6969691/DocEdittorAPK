package com.example.docscanner.adapter

import android.graphics.Bitmap
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.databinding.ItemReaderPageBinding
import com.example.docscanner.util.ReaderEdits
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * The pages of the in-app PDF reader ([com.example.docscanner.PdfReaderActivity]): one picture per page, drawn only when its row is on (or near) the screen and thrown
 * away when the row is recycled, so a 500-page PDF holds a handful of bitmaps. [render] draws page `index` at a given pixel width and may return null (a page that
 * fails stays blank); it runs off the main thread and must be safe to call from there. A placeholder of A4 height keeps the scroll bar steady until the page arrives.
 */
class PdfReaderPageAdapter(
    private val pageCount: Int,
    /** Width pages are drawn at; the reader raises it while zoomed in and calls notifyDataSetChanged so the pages come out sharp. */
    var widthPx: Int,
    /** Width of the screen: the placeholder height is taken from it, not from [widthPx], so changing the drawing width does not make the rows jump. */
    private val placeholderWidthPx: Int,
    private val scope: CoroutineScope,
    private val label: (Int) -> String,
    private val render: (Int, Int) -> Bitmap?
) : RecyclerView.Adapter<PdfReaderPageAdapter.ViewHolder>() {

    class ViewHolder(val binding: ItemReaderPageBinding) : RecyclerView.ViewHolder(binding.root) {
        var job: Job? = null
    }

    /** The active editing tool of the reader (null = reading) and the marks made so far; changing them is shown with [refreshOverlays] / [refreshOverlay]. */
    var tool: ReaderEdits.Kind? = null
    var edits: ReaderEdits? = null

    /** A frame was dragged on page `page`: box 0..1. */
    var onFrame: ((Int, FloatArray) -> Unit)? = null

    /** The text tool was tapped on page `page`: x, y (view pixels), view width, view height. */
    var onTap: ((Int, Float, Float, Float, Float) -> Unit)? = null

    /** Redraws only the marks and the tool of every row: the page pictures are not drawn again. */
    fun refreshOverlays() = notifyItemRangeChanged(0, itemCount, PAYLOAD_OVERLAY)

    fun refreshOverlay(page: Int) = notifyItemChanged(page, PAYLOAD_OVERLAY)

    private fun bindOverlay(holder: ViewHolder) {
        val view = holder.binding.ivPage
        val page = holder.bindingAdapterPosition
        if (page == RecyclerView.NO_POSITION) return
        view.tool = tool
        view.overlays = edits?.on(page) ?: emptyList()
        view.onFrame = { box -> onFrame?.invoke(holder.bindingAdapterPosition, box) }
        view.onTap = { x, y, w, h -> onTap?.invoke(holder.bindingAdapterPosition, x, y, w, h) }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
        ViewHolder(ItemReaderPageBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int, payloads: MutableList<Any>) {
        if (payloads.isNotEmpty() && payloads.all { it == PAYLOAD_OVERLAY }) {
            bindOverlay(holder)
            return
        }
        super.onBindViewHolder(holder, position, payloads)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        bindOverlay(holder)
        holder.job?.cancel()
        val view = holder.binding.ivPage
        // a row rebound for the same page (after a zoom) keeps its old picture until the sharper one arrives, instead of flashing blank
        if (view.drawable == null) view.minimumHeight = (placeholderWidthPx * 1.41f).toInt()
        view.contentDescription = label(position)
        val width = widthPx
        holder.job = scope.launch {
            val bitmap = withContext(Dispatchers.Default) { render(position, width) }
            if (bitmap != null && isActive) {
                view.minimumHeight = 0
                view.setImageBitmap(bitmap)
            }
        }
    }

    override fun onViewRecycled(holder: ViewHolder) {
        holder.job?.cancel()
        holder.job = null
        holder.binding.ivPage.setImageDrawable(null)
    }

    override fun getItemCount(): Int = pageCount

    companion object {
        private const val PAYLOAD_OVERLAY = "overlay"
    }
}
