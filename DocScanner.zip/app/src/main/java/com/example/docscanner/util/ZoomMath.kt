package com.example.docscanner.util

import kotlin.math.roundToInt

/**
 * The arithmetic of pinch zoom in the PDF reader ([com.example.docscanner.view.ZoomRecyclerView], session 23, 4.59), kept free of Android classes so that
 * tools/verify/ReaderLogicCheck.java mirrors it and reader_logic_check.py proves its invariants.
 *
 * The picture: the list is drawn scaled by [scale] about the top-left corner and then moved sideways by [offsetX] (<= 0). Vertically the list scrolls by itself.
 * So a content point (cx, cy) shows at screen x = offsetX + scale * cx and at screen y = scale * (cy - scrollY).
 * Zooming about a finger position (fx, fy) must keep the content under the finger where it is:
 *  - horizontally that is a new [offsetX] (clamped so no empty margin shows);
 *  - vertically the list has to scroll by [Zoom.scrollDy], because it cannot be moved by an offset.
 */
object ZoomMath {

    const val MAX_ZOOM = 4f

    /** The state after a zoom step. [scrollDy] = pixels the list must scroll down (negative = up) afterwards. */
    class Zoom(val scale: Float, val offsetX: Float, val scrollDy: Int)

    /** Keeps the scaled page inside the view: no gap on the left (offset <= 0) and none on the right (offset >= width * (1 - scale)). */
    fun clampX(x: Float, width: Float, scale: Float): Float = x.coerceIn(width * (1f - scale), 0f)

    fun zoomTo(scale: Float, offsetX: Float, width: Float, target: Float, fx: Float, fy: Float): Zoom {
        val s = target.coerceIn(1f, MAX_ZOOM)
        if (s == scale) return Zoom(scale, offsetX, 0)
        val ox = clampX(fx - (fx - offsetX) * (s / scale), width, s)
        val dy = (fy / scale - fy / s).roundToInt()
        return Zoom(s, ox, dy)
    }

    /**
     * Scaling about the top-left corner shows only the top 1/scale of what the list thinks is on screen, so the last part of the document could never be reached.
     * The list gets this much extra bottom padding to make it reachable. 0 at scale 1.
     */
    fun extraBottomPadding(height: Float, scale: Float): Int = (height * (1f - 1f / scale)).toInt()

    /** Screen x -> content x (used to give the list its touches in its own, unscaled coordinates). */
    fun contentX(x: Float, offsetX: Float, scale: Float): Float = (x - offsetX) / scale
}
