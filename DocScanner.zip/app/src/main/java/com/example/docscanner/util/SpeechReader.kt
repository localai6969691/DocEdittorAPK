package com.example.docscanner.util

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Reads text aloud with the phone's own text-to-speech engine (no extra library, works offline when the voice is installed).
 * Vietnamese is requested first; when the engine has no Vietnamese voice the default language is used and [onReady] says so, so the
 * screen can tell the user to install one (Settings > text-to-speech). Long text is cut by [TextChunker] because an engine accepts only
 * about [TextToSpeech.getMaxSpeechInputLength] characters per call. Android 11+ needs the TTS_SERVICE intent declared in the manifest's
 * `<queries>`, otherwise the engine cannot even be found - it is declared there.
 *
 * Always call [shutdown] when done (the engine is a bound service).
 */
class SpeechReader(context: Context, private val onReady: (ready: Boolean, vietnamese: Boolean) -> Unit) {

    private var ready = false
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            val engine = tts
            if (status != TextToSpeech.SUCCESS || engine == null) {
                onReady(false, false)
            } else {
                val r = engine.setLanguage(Locale("vi", "VN"))
                val vietnamese = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
                if (!vietnamese) engine.setLanguage(Locale.getDefault())
                ready = true
                onReady(true, vietnamese)
            }
        }
    }

    /** Starts reading [text] from the beginning (anything already being read is dropped). */
    fun speak(text: String) {
        val engine = tts ?: return
        if (!ready) return
        val limit = minOf(TextToSpeech.getMaxSpeechInputLength() - 100, 3500).coerceAtLeast(200)
        val chunks = TextChunker.split(text, limit)
        chunks.forEachIndexed { i, chunk ->
            engine.speak(chunk, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "chunk$i")
        }
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        runCatching { tts?.stop() }
        runCatching { tts?.shutdown() }
        tts = null
        ready = false
    }
}
