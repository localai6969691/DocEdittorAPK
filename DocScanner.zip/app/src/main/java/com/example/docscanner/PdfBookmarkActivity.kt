package com.example.docscanner

import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityPdfBookmarksBinding
import com.example.docscanner.util.PdfBookmarks
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.SmartNamer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * "Sửa mục lục" (phiên 17, mục 4.34): shows the bookmarks of a PDF as an indented list and lets the person rename one, delete one WITH its children, or add a bookmark at a page;
 * "Lưu bản mới" writes a COPY of the PDF with the new outline (the pages and the original file are untouched). The edits are the pure functions of [PdfBookmarks]
 * (delete / rename / insert - checked in tools/verify/bookmarks_check.py); a bookmark whose destination could not be resolved to a page shows "tr. ?" and is dropped on save.
 */
class PdfBookmarkActivity : BaseActivity() {

    companion object { const val EXTRA_PDF_PATH = "extra_pdf_path" }

    private lateinit var binding: ActivityPdfBookmarksBinding
    private lateinit var source: File
    private var entries: List<PdfBookmarks.Entry> = emptyList()
    private var pageCount = 0
    private var changed = false
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfBookmarksBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.bm_title)
        val path = intent.getStringExtra(EXTRA_PDF_PATH)
        if (path == null || !File(path).isFile) { finish(); return }
        source = File(path)
        binding.lvBookmarks.setOnItemClickListener { _, _, position, _ -> if (!busy) askAction(position) }
        binding.btnBookmarkAdd.setOnClickListener { if (!busy) askAdd() }
        binding.btnBookmarkSave.setOnClickListener { if (!busy) save() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (!changed || busy) { isEnabled = false; onBackPressedDispatcher.onBackPressed(); return }
                AlertDialog.Builder(this@PdfBookmarkActivity)
                    .setMessage(R.string.bm_discard)
                    .setNegativeButton(R.string.dialog_cancel, null)
                    .setPositiveButton(R.string.sign_discard_exit) { _, _ -> isEnabled = false; onBackPressedDispatcher.onBackPressed() }
                    .show()
            }
        })
        setBusy(true)
        lifecycleScope.launch {
            val read = runCatching { withContext(Dispatchers.IO) { PdfBookmarks.readFile(source) } }
            setBusy(false)
            val r = read.getOrNull()
            if (r == null) {
                Toast.makeText(this@PdfBookmarkActivity, if (read.exceptionOrNull()?.message == "encrypted") R.string.sign_encrypted else R.string.bm_failed, Toast.LENGTH_LONG).show()
                finish()
                return@launch
            }
            entries = PdfBookmarks.normalizeLevels(r.first)
            pageCount = r.second
            refresh()
        }
    }

    private fun setBusy(value: Boolean) {
        busy = value
        binding.btnBookmarkAdd.isEnabled = !value
        binding.btnBookmarkSave.isEnabled = !value
    }

    private fun refresh() {
        val labels = entries.map { e -> "    ".repeat(e.level - 1) + e.title + "  ·  " + getString(R.string.bm_page, if (e.page >= 0) (e.page + 1).toString() else "?") }
        binding.lvBookmarks.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        binding.lvBookmarks.visibility = if (entries.isEmpty()) View.GONE else View.VISIBLE
        binding.tvBookmarkEmpty.visibility = if (entries.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun askAction(index: Int) {
        val e = entries.getOrNull(index) ?: return
        // Only the moves that would change something are offered (4.47): the first child cannot go up, the last cannot go down, and so on.
        val actions = ArrayList<Pair<String, () -> Unit>>()
        actions.add(getString(R.string.bm_rename) to { askRename(index) })
        if (PdfBookmarks.canMoveUp(entries, index)) actions.add(getString(R.string.bm_move_up) to { applyEdit(PdfBookmarks.moveUp(entries, index)) })
        if (PdfBookmarks.canMoveDown(entries, index)) actions.add(getString(R.string.bm_move_down) to { applyEdit(PdfBookmarks.moveDown(entries, index)) })
        if (PdfBookmarks.canIndent(entries, index)) actions.add(getString(R.string.bm_indent) to { applyEdit(PdfBookmarks.indent(entries, index)) })
        if (PdfBookmarks.canOutdent(entries, index)) actions.add(getString(R.string.bm_outdent) to { applyEdit(PdfBookmarks.outdent(entries, index)) })
        actions.add(getString(R.string.bm_delete) to { confirmDelete(index) })
        AlertDialog.Builder(this)
            .setTitle(e.title)
            .setItems(actions.map { it.first }.toTypedArray()) { _, which -> actions[which].second() }
            .show()
    }

    /** Takes [updated] as the new list (a move or a level change) and redraws; the bookmark list is a COPY until saved, so nothing is written yet. */
    private fun applyEdit(updated: List<PdfBookmarks.Entry>) {
        entries = updated
        changed = true
        refresh()
    }

    private fun askRename(index: Int) {
        val input = EditText(this).apply {
            setText(entries[index].title)
            setSelection(text.length)
            setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val frame = android.widget.FrameLayout(this).apply { setPadding(pad, pad / 2, pad, 0); addView(input) }
        AlertDialog.Builder(this)
            .setTitle(R.string.bm_rename)
            .setView(frame)
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.dialog_ok) { _, _ ->
                entries = PdfBookmarks.rename(entries, index, input.text.toString())
                changed = true
                refresh()
            }
            .show()
    }

    private fun confirmDelete(index: Int) {
        val children = PdfBookmarks.delete(entries, index).let { entries.size - it.size - 1 }
        AlertDialog.Builder(this)
            .setMessage(if (children > 0) getString(R.string.bm_delete_with_children, entries[index].title, children) else getString(R.string.bm_delete_one, entries[index].title))
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.dialog_yes) { _, _ ->
                entries = PdfBookmarks.delete(entries, index)
                changed = true
                refresh()
            }
            .show()
    }

    private fun askAdd() {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val title = EditText(this).apply { setSingleLine(); hint = getString(R.string.bm_new_title_hint) }
        val page = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; hint = getString(R.string.bm_new_page_hint, pageCount) }
        val level = Spinner(this).apply {
            adapter = ArrayAdapter(this@PdfBookmarkActivity, android.R.layout.simple_spinner_dropdown_item, (1..3).map { getString(R.string.bm_level, it) })
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(title); addView(page); addView(TextView(this@PdfBookmarkActivity).apply { setText(R.string.bm_new_level) }); addView(level)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.bm_add)
            .setView(box)
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.dialog_ok) { _, _ ->
                val p = page.text.toString().toIntOrNull()
                val t = title.text.toString().trim()
                if (t.isEmpty() || p == null || p !in 1..pageCount) {
                    Toast.makeText(this, R.string.bm_new_invalid, Toast.LENGTH_LONG).show()
                } else {
                    entries = PdfBookmarks.insert(entries, t, p - 1, level.selectedItemPosition + 1, pageCount)
                    changed = true
                    refresh()
                }
            }
            .show()
    }

    private fun save() {
        setBusy(true)
        val out = SmartNamer.uniqueFile(PdfExporter.exportDir(this), source.nameWithoutExtension + " (" + getString(R.string.bm_suffix) + ")", "pdf")
        lifecycleScope.launch {
            val result = runCatching { withContext(Dispatchers.Default) { PdfBookmarks.saveWithOutline(source, out, entries) } }
            setBusy(false)
            if (result.isFailure) {
                runCatching { out.delete() }
                Toast.makeText(this@PdfBookmarkActivity, R.string.bm_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            changed = false
            Toast.makeText(this@PdfBookmarkActivity, getString(R.string.bm_saved, out.name), Toast.LENGTH_LONG).show()
            finish()
        }
    }
}
