package com.example.docscanner.util

import android.content.Context
import java.io.File

/**
 * Recycle bin for exported documents (phiên 17, mục 4.31): "delete" moves a file into a trash folder for [RETENTION_DAYS] days instead of
 * destroying it; the bin can restore it or empty itself. Item "Trash (recycle bin) / Restore / Empty trash" of the PDF "Thiếu gì để bán app".
 *
 * No index file: the time of deletion is part of the file's NAME in the bin, `<millis>__<original name>`, so there is nothing to get out of
 * step with the folder (an index would be lost or stale after a crash between the move and the write). A PDF's OCR sidecar `.txt` goes into
 * the bin with the SAME timestamp and is hidden from the list (it comes back with its PDF), exactly as the history list hides it.
 * A small `.meta` companion (same timestamp, `<original>.meta`) can travel with the file to carry what lives OUTSIDE it - the favourite star and the tags ([TrashMeta]) - so a
 * restored document gets them back; it is hidden from the list, restored / deleted / purged together with its file, and read with [readMeta] BEFORE [restore].
 * Files in the bin folder whose name does not follow the pattern are never listed, restored or purged - they are not ours.
 *
 * The bin folder lives next to the export folder, not inside it: [BackupManager] walks the export folder and a backup must not carry deleted files.
 * Everything takes the folders as parameters so it runs on a plain temp directory in tools/verify/TrashCheck.java.
 */
object TrashStore {

    const val RETENTION_DAYS = 30
    private const val DAY_MS = 86_400_000L
    private const val SEP = "__"

    class Entry(val file: File, val deletedAt: Long, val originalName: String)

    fun dir(context: Context): File {
        val base = context.getExternalFilesDir(null) ?: context.filesDir
        return File(base, "trash").also { if (!it.exists()) it.mkdirs() }
    }

    // ---------------------------------------------------------------- pure

    fun trashName(deletedAt: Long, original: String): String = "$deletedAt$SEP$original"

    /** `<digits>__<name>` -> (time, name); anything else (no digits, empty name, no separator) -> null. */
    fun parse(trashFileName: String): Pair<Long, String>? {
        val cut = trashFileName.indexOf(SEP)
        if (cut <= 0 || cut + SEP.length >= trashFileName.length) return null
        val digits = trashFileName.substring(0, cut)
        if (digits.length > 18 || !digits.all { it in '0'..'9' }) return null
        return Pair(digits.toLong(), trashFileName.substring(cut + SEP.length))
    }

    /** Expired after exactly [days] days; a timestamp in the FUTURE (clock changed) is never expired, so a wrong clock cannot wipe the bin. */
    fun isExpired(deletedAt: Long, now: Long, days: Int = RETENTION_DAYS): Boolean = now >= deletedAt && now - deletedAt >= days * DAY_MS

    /** Whole days left (rounded up), 0 when expired, never more than [days]. */
    fun daysLeft(deletedAt: Long, now: Long, days: Int = RETENTION_DAYS): Int {
        val left = days * DAY_MS - (now - deletedAt)
        if (left <= 0) return 0
        return minOf(days.toLong(), (left + DAY_MS - 1) / DAY_MS).toInt()
    }

    // ---------------------------------------------------------------- files

    private fun move(src: File, dst: File): Boolean {
        if (src.renameTo(dst)) return true
        return try { src.copyTo(dst, overwrite = false); src.delete(); true } catch (t: Throwable) { runCatching { dst.delete() }; false }
    }

    /** Moves [file] (and a PDF's `.txt` sidecar; and [meta] as a `.meta` companion when given) into [trashDir]. @return false if the file could not be moved (it is left where it was). */
    fun moveToTrash(trashDir: File, file: File, now: Long, meta: String? = null): Boolean {
        if (!file.isFile) return false
        if (!trashDir.exists()) trashDir.mkdirs()
        val target = File(trashDir, trashName(now, file.name))
        if (target.exists()) return false
        if (!move(file, target)) return false
        if (file.extension.equals("pdf", ignoreCase = true)) {
            val sidecar = File(file.parentFile, file.nameWithoutExtension + ".txt")
            if (sidecar.isFile) move(sidecar, File(trashDir, trashName(now, sidecar.name)))
        }
        if (meta != null) runCatching { File(trashDir, trashName(now, file.name + ".meta")).writeText(meta) }
        return true
    }

    private fun metaFile(trashDir: File, e: Entry) = File(trashDir, trashName(e.deletedAt, e.originalName + ".meta"))

    /** The `.meta` text that travelled with [entry], or null. Read it BEFORE [restore] (which deletes it). */
    fun readMeta(trashDir: File, entry: Entry): String? = metaFile(trashDir, entry).takeIf { it.isFile }?.let { runCatching { it.readText() }.getOrNull() }

    private fun isSidecarOfTrashedPdf(all: List<Entry>, e: Entry): Boolean {
        if (!e.originalName.endsWith(".txt", ignoreCase = true)) return false
        val base = e.originalName.substring(0, e.originalName.length - 4)
        return all.any { it.deletedAt == e.deletedAt && it.originalName.equals("$base.pdf", ignoreCase = true) }
    }

    private fun isMetaOfTrashedFile(all: List<Entry>, e: Entry): Boolean {
        if (!e.originalName.endsWith(".meta")) return false
        val base = e.originalName.removeSuffix(".meta")
        return all.any { it.deletedAt == e.deletedAt && it.originalName == base }
    }

    /** Everything in the bin that follows the naming pattern, newest deletion first; companions (a trashed PDF's `.txt`, any `.meta`) left out. */
    fun entries(trashDir: File): List<Entry> {
        val all = (trashDir.listFiles { f -> f.isFile } ?: emptyArray())
            .mapNotNull { f -> parse(f.name)?.let { Entry(f, it.first, it.second) } }
        return all.filterNot { isSidecarOfTrashedPdf(all, it) || isMetaOfTrashedFile(all, it) }
            .sortedWith(compareByDescending<Entry> { it.deletedAt }.thenBy { it.originalName })
    }

    private fun sidecarOf(trashDir: File, e: Entry): File? {
        if (!e.originalName.endsWith(".pdf", ignoreCase = true)) return null
        val name = trashName(e.deletedAt, e.originalName.substring(0, e.originalName.length - 4) + ".txt")
        return File(trashDir, name).takeIf { it.isFile }
    }

    /** Puts [entry] back into [exportDir] under its own name, or `name (2)`... if taken. @return the restored file, or null on failure. */
    fun restore(trashDir: File, exportDir: File, entry: Entry): File? {
        if (!entry.file.isFile) return null
        if (!exportDir.exists()) exportDir.mkdirs()
        val ext = entry.originalName.substringAfterLast('.', "")
        val base = entry.originalName.removeSuffix(if (ext.isEmpty()) "" else ".$ext")
        val sidecar = sidecarOf(trashDir, entry)
        val name = SmartNamer.uniqueName(
            { n -> File(exportDir, n).exists() || (sidecar != null && File(exportDir, n.removeSuffix(".pdf") + ".txt").exists()) },
            base, ext
        )
        val target = File(exportDir, name)
        if (!move(entry.file, target)) return null
        if (sidecar != null) move(sidecar, File(exportDir, target.nameWithoutExtension + ".txt"))
        metaFile(trashDir, entry).delete()
        return target
    }

    fun deleteForever(trashDir: File, entry: Entry): Boolean {
        sidecarOf(trashDir, entry)?.let { StorageTools.wipe(it) }
        StorageTools.wipe(metaFile(trashDir, entry))
        return StorageTools.wipe(entry.file)
    }

    /** Deletes (with [StorageTools.wipe]: overwritten first, best effort) what is older than [RETENTION_DAYS] days. @return the number of files removed (sidecars included). */
    fun purgeExpired(trashDir: File, now: Long): Int {
        var n = 0
        for (f in trashDir.listFiles { x -> x.isFile } ?: emptyArray()) {
            val (at, _) = parse(f.name) ?: continue
            if (isExpired(at, now) && StorageTools.wipe(f)) n++
        }
        return n
    }

    /** Empties the bin (only files that follow the pattern). @return the number of files removed. */
    fun empty(trashDir: File): Int {
        var n = 0
        for (f in trashDir.listFiles { x -> x.isFile } ?: emptyArray()) if (parse(f.name) != null && StorageTools.wipe(f)) n++
        return n
    }
}
