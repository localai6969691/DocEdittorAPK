package com.example.docscanner.util

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.security.keystore.KeyProtection
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.interactive.digitalsignature.PDSignature
import com.tom_roush.pdfbox.pdmodel.interactive.digitalsignature.SignatureInterface
import com.tom_roush.pdfbox.pdmodel.interactive.digitalsignature.SignatureOptions
import java.io.File
import java.io.FileOutputStream
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.Calendar
import java.util.Date
import javax.security.auth.x500.X500Principal

/**
 * A real (cryptographic) digital signature on a PDF: the viewer shows a signature panel, and changing a single byte of
 * the signed part afterwards makes it report the document as modified. This is NOT the picture signature of
 * [PdfStamper] - the two are complementary (stamp a picture first, sign last).
 *
 * The key pair lives in the Android Keystore: generated inside the device's secure storage (hardware-backed where the
 * phone has it) and never exportable, so a copy of the app's data cannot leak it. The keystore also makes the matching
 * SELF-SIGNED certificate when the key is created, which is what [CmsSigner] embeds (or, after [importPkcs12], the person's own certificate and its
 * chain, whose key is moved into the keystore from a .p12 file). A self-signed certificate means:
 * the signature proves "this exact file, unchanged since it was signed by the holder of this key", but no viewer will
 * trust the signer's identity until the recipient installs/accepts the certificate (hence [certificateDer], to share
 * it). A certificate from a public certificate authority cannot be created in the app - that is bought elsewhere.
 *
 * The signature is an INCREMENTAL update appended to the file (PDFBox `saveIncremental`), so the original bytes stay
 * untouched - which is also why a signed file must not go through any tool of this app that rewrites a PDF.
 * The CMS builder is verified against pdfsig and openssl on a JVM (tools/verify/digital_signature_check.py); the
 * Keystore calls and PDFBox's signature plumbing can only be exercised on a device.
 */
object PdfDigitalSigner {

    const val KEY_ALIAS = "docscanner_signing_key"
    private const val PROVIDER = "AndroidKeyStore"
    private const val DAY_MS = 24L * 60 * 60 * 1000

    class CertInfo(val subject: String, val notAfter: Long, val sha256: String)

    private fun keyStore(): KeyStore = KeyStore.getInstance(PROVIDER).apply { load(null) }

    fun hasKey(): Boolean = runCatching { keyStore().containsAlias(KEY_ALIAS) }.getOrDefault(false)

    private fun certificate(): X509Certificate? =
        runCatching { keyStore().getCertificate(KEY_ALIAS) as? X509Certificate }.getOrNull()

    /** DER bytes of the public certificate (what a recipient installs to trust the signer), or null if there is no key. */
    fun certificateDer(): ByteArray? = certificate()?.encoded

    fun info(): CertInfo? {
        val cert = certificate() ?: return null
        val hex = MessageDigest.getInstance("SHA-256").digest(cert.encoded)
            .joinToString(":") { "%02X".format(it.toInt() and 0xFF) }
        return CertInfo(cert.subjectX500Principal.name, cert.notAfter.time, hex)
    }

    /**
     * The CN of a distinguished name in RFC 2253 form, with its escapes removed: `CN=Công ty A\, B,O=Org` -> `Công ty A, B`. An imported certificate has
     * a full name (country, organisation...), and only the CN belongs in the signature's /Name field. Without a CN the whole text is returned.
     */
    fun commonName(subject: String): String {
        val match = Regex("(?:^|,)\\s*CN=((?:\\\\.|[^,])*)", RegexOption.IGNORE_CASE).find(subject) ?: return subject
        return match.groupValues[1].replace(Regex("\\\\(.)"), "$1").trim().ifEmpty { subject }
    }

    private val forbiddenInName = charArrayOf(',', '+', '"', '\\', '<', '>', ';', '=', '#', '\n', '\r')

    /** A name that is safe inside a distinguished name: no separators or escape characters, at most 64 characters. */
    fun cleanName(raw: String): String {
        val cleaned = raw.map { if (it in forbiddenInName) ' ' else it }.joinToString("").trim().replace(Regex("\\s+"), " ")
        return cleaned.take(64).ifEmpty { "DocScanner User" }
    }

    /** Creates the RSA-2048 key and its self-signed certificate (valid 25 years) in the Android Keystore. */
    fun createKey(commonName: String) {
        val now = System.currentTimeMillis()
        val spec = KeyGenParameterSpec.Builder(KEY_ALIAS, KeyProperties.PURPOSE_SIGN)
            .setKeySize(2048)
            .setDigests(KeyProperties.DIGEST_SHA256)
            .setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
            .setCertificateSubject(X500Principal("CN=" + cleanName(commonName)))
            .setCertificateSerialNumber(BigInteger.valueOf(now))
            .setCertificateNotBefore(Date(now - DAY_MS))
            .setCertificateNotAfter(Date(now + 25L * 365 * DAY_MS))
            .build()
        val generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, PROVIDER)
        generator.initialize(spec)
        generator.generateKeyPair()
    }

    /**
     * Replaces the signing key with the one in a PKCS#12 file ([Pkcs12Import] checks it and throws [Pkcs12Import.ImportException] with the reason). The
     * key goes into the Android Keystore as sign-only, so it cannot be read back out of the phone; the whole certificate chain is stored with it and
     * embedded in every signature. [password] is wiped before returning.
     */
    fun importPkcs12(bytes: ByteArray, password: CharArray): CertInfo {
        try {
            val read = Pkcs12Import.read(bytes, password)
            val protection = KeyProtection.Builder(KeyProperties.PURPOSE_SIGN).setDigests(KeyProperties.DIGEST_SHA256).apply {
                if (read.key.algorithm.equals("RSA", ignoreCase = true)) setSignaturePaddings(KeyProperties.SIGNATURE_PADDING_RSA_PKCS1)
            }.build()
            keyStore().setEntry(KEY_ALIAS, KeyStore.PrivateKeyEntry(read.key, read.chain.toTypedArray()), protection)
        } finally {
            password.fill('\u0000')
        }
        return info() ?: throw IllegalStateException("import did not stick")
    }

    fun deleteKey() {
        runCatching { keyStore().deleteEntry(KEY_ALIAS) }
    }

    /** Signs [src] into the NEW file [out]. Throws if there is no key, the PDF is encrypted, or the result does not open. */
    /**
     * [tsaUrl]: an RFC 3161 time stamp server (phiên 20, 4.48.6); null or blank = no time stamp (the signature is then only as old as the phone's clock says). Only the hash of the
     * signature is sent. Throws [java.io.IOException] with a readable message when the server cannot be reached or its answer does not match.
     */
    /**
     * Signs [src] into [out]. [stampLines] (null = no stamp) are the text lines of the VISIBLE stamp on the last page, bottom right ([VisibleSignature]).
     * Returns true when the visible stamp is in the result, false when the signature is invisible - either because none was asked for or because the stamp
     * could not be made: a failure BEFORE the signing callback ran (nothing was signed, no time stamp server was called yet) is retried without the stamp,
     * since a missing stamp is better than a missing signature. A failure after that (the time stamp server, the output check) is NOT retried.
     */
    fun sign(src: File, out: File, signerName: String?, reason: String?, tsaUrl: String? = null, stampLines: List<String>? = null): Boolean {
        if (stampLines != null) {
            var signerCalled = false
            try {
                signOnce(src, out, signerName, reason, tsaUrl, stampLines) { signerCalled = true }
                return true
            } catch (e: Throwable) {
                if (signerCalled || e.message == "encrypted") throw e
                runCatching { out.delete() }
            }
        }
        signOnce(src, out, signerName, reason, tsaUrl, null) { }
        return false
    }

    private fun signOnce(src: File, out: File, signerName: String?, reason: String?, tsaUrl: String?, stampLines: List<String>?, onSignerCalled: () -> Unit) {
        val store = keyStore()
        val key = store.getKey(KEY_ALIAS, null) as? PrivateKey ?: throw IllegalStateException("no key")
        val cert = store.getCertificate(KEY_ALIAS) as? X509Certificate ?: throw IllegalStateException("no key")
        val chain = store.getCertificateChain(KEY_ALIAS)?.filterIsInstance<X509Certificate>().orEmpty()     // longer than one only for an imported certificate
        val doc = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
        try {
            if (doc.isEncrypted) throw IllegalStateException("encrypted")
            val pages = doc.numberOfPages
            val signature = PDSignature()
            signature.setFilter(PDSignature.FILTER_ADOBE_PPKLITE)
            signature.setSubFilter(PDSignature.SUBFILTER_ADBE_PKCS7_DETACHED)
            signerName?.takeIf { it.isNotBlank() }?.let { signature.setName(it) }
            reason?.takeIf { it.isNotBlank() }?.let { signature.setReason(it) }
            signature.setSignDate(Calendar.getInstance())
            val signingTime = System.currentTimeMillis()
            val stamp: ((ByteArray) -> ByteArray)? = tsaUrl?.trim()?.takeIf { it.isNotEmpty() }?.let { u -> { sig: ByteArray -> TimeStamp.obtain(u, sig) } }
            val signer = SignatureInterface { content -> onSignerCalled(); CmsSigner.signContent(content, cert, key, signingTime, stamp, chain) }
            // PDFBox reserves 9 472 bytes for the CMS by default. The CMS holds the whole certificate chain (an imported certificate may bring 3-4 certificates of 1-2 KB each),
            // and a time stamp token carries the TSA's own chain (3-6 KB): make room for what this signature will really carry, or PDFBox refuses it as "too large"
            var needed = chain.sumOf { it.encoded.size } + 3000
            if (stamp != null) needed = maxOf(needed + 9000, 20000)                       // 20 000 was the reserve for a time stamp before certificate chains were embedded: never less
            val options = SignatureOptions().apply { if (needed > 9000) setPreferredSignatureSize(needed.coerceAtMost(60000)) }
            try {
                if (stampLines != null) {
                    val page = doc.getPage(pages - 1)
                    val crop = page.cropBox
                    val box = floatArrayOf(crop.lowerLeftX, crop.lowerLeftY, crop.upperRightX, crop.upperRightY)
                    val rect = VisibleSignature.userRect(box, page.rotation)
                    val (wPt, hPt) = VisibleSignature.visualSize(rect, page.rotation)
                    val bitmap = VisibleSignature.stampBitmap(stampLines, wPt, hPt)
                    try {
                        val template = VisibleSignature.templatePdf(box, page.rotation, rect, bitmap.width, bitmap.height, VisibleSignature.rgbOf(bitmap))
                        options.setVisualSignature(java.io.ByteArrayInputStream(template))
                        options.setPage(pages - 1)
                    } finally {
                        bitmap.recycle()
                    }
                }
                doc.addSignature(signature, signer, options)
                FileOutputStream(out).use { doc.saveIncremental(it) }
            } finally {
                runCatching { options.close() }
            }
            if (!PdfVerify.opensAsPdf(out, pages)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
        } catch (e: Throwable) {
            runCatching { out.delete() }
            throw e
        } finally {
            runCatching { doc.close() }
        }
    }
}
