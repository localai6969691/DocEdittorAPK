package com.example.docscanner.util

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.math.BigInteger
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom

/**
 * RFC 3161 time stamp for a digital signature (phiên 20, mục 4.48.6; PDF "Thiếu gì để bán app" 3.4-3.8, PAdES-B-T). A time stamp is a statement by a TIME STAMPING AUTHORITY (TSA), signed by it, that
 * a given hash existed at a given time; attached to our signature (the `id-aa-signatureTimeStampToken` unsigned attribute, see [CmsSigner]) it proves WHEN the PDF was signed to anybody, even
 * if the phone's clock is wrong or the signing certificate later expires.
 *
 * PRIVACY: what leaves the phone is ONE SHA-256 hash of the signature value (32 bytes) in an HTTP POST to the address the user typed; never the document, never the certificate. It is still
 * a network call, so it happens only when the user typed a TSA address (empty = off) and the app's INTERNET permission (declared for eSCL, see 4.31 I) is what makes it possible.
 *
 * What is checked here: the reply is a well formed `TimeStampResp`, its status is "granted", and the token's own `TSTInfo` repeats OUR hash and OUR nonce (so an answer meant for another
 * request cannot be attached). What is NOT checked: the TSA's signature and certificate chain (that is the PDF reader's job, and it needs a trust list the app does not have). A token the
 * checker cannot parse (BER with indefinite lengths, which some old TSAs use) is REFUSED rather than attached unchecked.
 *
 * The DER building and reading is pure and mirrored in `tools/verify/TimestampCheck.java`; `timestamp_check.py` runs the whole round trip against `openssl ts` acting as a local TSA.
 */
internal object TimeStamp {

    const val OID_TS_TOKEN = "1.2.840.113549.1.9.16.2.14"
    private const val OID_SHA256 = "2.16.840.1.101.3.4.2.1"
    private const val MAX_RESPONSE = 256 * 1024

    /** `TimeStampReq`: version 1, SHA-256 message imprint, [nonce], `certReq` TRUE (the token then carries the TSA certificate, so a reader can check it offline). */
    fun buildRequest(digest: ByteArray, nonce: BigInteger): ByteArray {
        val imprint = DerWriter.sequence(
            DerWriter.sequence(DerWriter.oid(OID_SHA256), DerWriter.nullValue()),
            DerWriter.octetString(digest)
        )
        return DerWriter.sequence(
            DerWriter.integer(BigInteger.ONE),
            imprint,
            DerWriter.integer(nonce),
            DerWriter.tlv(0x01, byteArrayOf(0xFF.toByte()))
        )
    }

    /** [status] 0 granted, 1 granted with modifications, 2 rejection, 3 waiting, 4 revocation warning, 5 revocation notification; [token] = the whole `TimeStampToken` (a CMS ContentInfo) when present. */
    class Response(val status: Int, val token: ByteArray?)

    /** Reads a `TimeStampResp`; [IllegalArgumentException] when [d] is not one. */
    fun parseResponse(d: ByteArray): Response {
        try {
            val outer = DerWriter.header(d, 0)
            require(outer[0] == 0x30 && outer[1] + outer[2] <= d.size)
            val end = outer[1] + outer[2]
            var p = outer[1]
            val info = DerWriter.header(d, p)                    // PKIStatusInfo ::= SEQUENCE { status PKIStatus, ... }
            require(info[0] == 0x30)
            val st = DerWriter.header(d, p + info[1])
            require(st[0] == 0x02 && st[2] in 1..4)
            var status = 0
            for (i in 0 until st[2]) status = (status shl 8) or (d[p + info[1] + st[1] + i].toInt() and 0xFF)
            p += info[1] + info[2]
            var token: ByteArray? = null
            if (p < end) {
                val t = DerWriter.header(d, p)                   // TimeStampToken ::= ContentInfo ::= SEQUENCE
                require(t[0] == 0x30 && p + t[1] + t[2] <= end)
                token = d.copyOfRange(p, p + t[1] + t[2])
            }
            return Response(status, token)
        } catch (e: IndexOutOfBoundsException) {
            throw IllegalArgumentException("not a TimeStampResp")
        }
    }

    /** True when the `TSTInfo` inside [token] has [digest] (SHA-256) as its message imprint and [nonce] as its nonce. False for anything it cannot read. */
    fun tokenMatches(token: ByteArray, digest: ByteArray, nonce: BigInteger): Boolean {
        try {
            val ci = DerWriter.header(token, 0)                              // ContentInfo
            if (ci[0] != 0x30 || ci[1] + ci[2] != token.size) return false   // its length must be the token's: a CUT token (TSTInfo intact, the rest missing) would corrupt the CMS it is put in
            var p = ci[1]
            val oid = DerWriter.header(token, p); p += oid[1] + oid[2]       // contentType = signedData
            val ex = DerWriter.header(token, p)                              // [0] EXPLICIT
            if (ex[0] != 0xA0) return false
            p += ex[1]
            val sd = DerWriter.header(token, p)                              // SignedData
            if (sd[0] != 0x30) return false
            p += sd[1]
            val ver = DerWriter.header(token, p); p += ver[1] + ver[2]
            val algs = DerWriter.header(token, p); p += algs[1] + algs[2]
            val enc = DerWriter.header(token, p)                             // EncapsulatedContentInfo
            if (enc[0] != 0x30) return false
            p += enc[1]
            val ct = DerWriter.header(token, p); p += ct[1] + ct[2]          // id-ct-TSTInfo
            val a0 = DerWriter.header(token, p)                              // [0] EXPLICIT
            if (a0[0] != 0xA0) return false
            p += a0[1]
            val oct = DerWriter.header(token, p)                             // OCTET STRING holding the TSTInfo
            if (oct[0] != 0x04) return false
            p += oct[1]
            val ti = DerWriter.header(token, p)                              // TSTInfo ::= SEQUENCE
            if (ti[0] != 0x30) return false
            val tiEnd = p + ti[1] + ti[2]
            p += ti[1]
            val v = DerWriter.header(token, p); p += v[1] + v[2]             // version
            val pol = DerWriter.header(token, p); p += pol[1] + pol[2]       // policy
            val mi = DerWriter.header(token, p)                              // MessageImprint
            if (mi[0] != 0x30) return false
            val alg = DerWriter.header(token, p + mi[1])                     // hashAlgorithm
            val algOid = DerWriter.header(token, p + mi[1] + alg[1])
            val expectOid = DerWriter.oid(OID_SHA256)
            val gotOid = token.copyOfRange(p + mi[1] + alg[1], p + mi[1] + alg[1] + algOid[1] + algOid[2])
            if (!gotOid.contentEquals(expectOid)) return false
            val hashOff = p + mi[1] + alg[1] + alg[2]
            val hash = DerWriter.header(token, hashOff)
            if (hash[0] != 0x04 || !token.copyOfRange(hashOff + hash[1], hashOff + hash[1] + hash[2]).contentEquals(digest)) return false
            p += mi[1] + mi[2]
            val ser = DerWriter.header(token, p); p += ser[1] + ser[2]       // serialNumber
            val gen = DerWriter.header(token, p); p += gen[1] + gen[2]       // genTime
            while (p < tiEnd) {                                              // accuracy / ordering are skipped; the first top-level INTEGER is the nonce
                val h = DerWriter.header(token, p)
                if (h[0] == 0x02) return BigInteger(token.copyOfRange(p + h[1], p + h[1] + h[2])) == nonce
                p += h[1] + h[2]
            }
            return false
        } catch (e: IndexOutOfBoundsException) {
            return false
        }
    }

    /** POST of the request to [url] (http or https; no redirects; at most 256 KB back). */
    fun post(url: String, request: ByteArray, timeoutMs: Int = 20_000): ByteArray {
        if (!(url.startsWith("http://") || url.startsWith("https://"))) throw IOException("the time stamp address must start with http:// or https://")
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.instanceFollowRedirects = false
            c.setRequestProperty("Content-Type", "application/timestamp-query")
            c.setRequestProperty("Accept", "application/timestamp-reply")
            c.setFixedLengthStreamingMode(request.size)
            c.outputStream.use { it.write(request) }
            if (c.responseCode != 200) throw IOException("the time stamp server answered HTTP ${c.responseCode}")
            val out = ByteArrayOutputStream()
            val buf = ByteArray(8192)
            c.inputStream.use { input ->
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > MAX_RESPONSE) throw IOException("the time stamp reply is too large")
                }
            }
            return out.toByteArray()
        } finally {
            c.disconnect()
        }
    }

    /** The time stamp token for [signatureValue] (the RSA signature bytes of the SignerInfo) from the TSA at [url]; [IOException] with a readable reason otherwise. */
    fun obtain(url: String, signatureValue: ByteArray): ByteArray {
        val digest = MessageDigest.getInstance("SHA-256").digest(signatureValue)
        val nonce = BigInteger(63, SecureRandom()).add(BigInteger.ONE)
        val reply = post(url, buildRequest(digest, nonce))
        val resp = try { parseResponse(reply) } catch (e: IllegalArgumentException) { throw IOException("the time stamp server sent something that is not a time stamp reply") }
        if (resp.status != 0 && resp.status != 1) throw IOException("the time stamp server refused (status ${resp.status})")
        val token = resp.token ?: throw IOException("the time stamp reply has no token")
        if (!tokenMatches(token, digest, nonce)) throw IOException("the time stamp does not match the request (or cannot be read)")
        return token
    }
}
