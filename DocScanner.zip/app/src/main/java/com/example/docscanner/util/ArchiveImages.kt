package com.example.docscanner.util

import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

/**
 * Lay anh tu mot goi CBZ / ZIP (truyen tranh, anh sach nen thanh mot tep) de dua vao hang doi quet (phien 18, PDF "Thieu gi de ban app" muc L / 9.x nhap tu goi).
 * Ban Java chay duoc: `tools/verify/ArchiveImagesCheck.java`; kiem chung: `tools/verify/archive_images_check.py` (hai ban PHAI giu cung thuat toan).
 *
 * An toan: (1) ten tep ra DO APP DAT (`<prefix>NNNN.<duoi>`), khong bao gio dung ten trong goi nen "../x" hay "/abs/x" (zip-slip) khong co cho de lam hai;
 * (2) zip-bomb: dung luong khai bao trong goi khong dang tin, nen DEM byte thuc doc ra - tep vuot [maxEntryBytes] bi bo, tong vuot [maxTotalBytes] thi dung;
 * (3) tran so tep [maxEntries]; (4) tep dang giai nen do bi bo / loi duoc xoa, khong de tep dang do.
 */
object ArchiveImages {
    private val EXT = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")

    const val MAX_ENTRIES = 2000
    const val MAX_ENTRY_BYTES = 64L * 1024 * 1024
    const val MAX_TOTAL_BYTES = 1024L * 1024 * 1024

    /** Ten trong goi co phai la mot anh de lay khong: bo thu muc, `__MACOSX`, tep an (bat dau bang `.`), `Thumbs.db`, tep khong phai anh; chap nhan `\` kieu Windows. */
    fun isImageName(raw: String): Boolean {
        val name = raw.replace('\\', '/')
        if (name.endsWith("/")) return false
        val seg = name.split('/')
        for (s in seg) { if (s.isEmpty()) continue; if (s.startsWith(".") || s == "__MACOSX") return false }
        val last = seg.last()
        if (last.equals("thumbs.db", ignoreCase = true)) return false
        val dot = last.lastIndexOf('.')
        if (dot < 0) return false
        return last.substring(dot + 1).lowercase(Locale.ROOT) in EXT
    }

    private fun isDigit(c: Char) = c in '0'..'9'

    /** So sanh "tu nhien": dai so so sanh theo GIA TRI (p2 < p10), chu khong phan biet hoa thuong, so dung truoc chu; bang nhau het thi so sanh chuoi tho de thu tu on dinh. */
    fun natural(a: String, b: String): Int {
        var i = 0; var j = 0
        while (i < a.length && j < b.length) {
            val da = isDigit(a[i]); val db = isDigit(b[j])
            var ie = i; var je = j
            while (ie < a.length && isDigit(a[ie]) == da) ie++
            while (je < b.length && isDigit(b[je]) == db) je++
            val ta = a.substring(i, ie); val tb = b.substring(j, je)
            if (da != db) return if (da) -1 else 1
            val c = if (da) {
                val na = ta.replaceFirst(Regex("^0+(?=.)"), ""); val nb = tb.replaceFirst(Regex("^0+(?=.)"), "")
                if (na.length != nb.length) na.length.compareTo(nb.length) else na.compareTo(nb)
            } else ta.lowercase(Locale.ROOT).compareTo(tb.lowercase(Locale.ROOT))
            if (c != 0) return c
            i = ie; j = je
        }
        val rest = (a.length - i).compareTo(b.length - j)
        if (rest != 0) return rest
        return a.compareTo(b)
    }

    /**
     * Giai nen cac anh cua [zip] vao [outDir] theo thu tu tu nhien cua ten day du trong goi, dat ten `<prefix>0001.jpg`, `<prefix>0002.png`...
     * @return cac tep da ghi, theo thu tu doc. Goi hong -> [IOException] (tep da ghi truoc do vi vay nen duoc nguoi goi xoa).
     */
    fun extract(
        zip: File, outDir: File, prefix: String,
        maxEntries: Int = MAX_ENTRIES, maxEntryBytes: Long = MAX_ENTRY_BYTES, maxTotalBytes: Long = MAX_TOTAL_BYTES
    ): List<File> {
        val out = ArrayList<File>()
        ZipFile(zip).use { z ->
            val picked = ArrayList<ZipEntry>()
            for (e in z.entries()) if (!e.isDirectory && isImageName(e.name)) picked.add(e)
            picked.sortWith { x, y -> natural(x.name.replace('\\', '/'), y.name.replace('\\', '/')) }
            if (!outDir.exists()) outDir.mkdirs()
            var total = 0L
            var n = 0
            for (e in picked) {
                if (n >= maxEntries) break
                val ext = e.name.substring(e.name.lastIndexOf('.') + 1).lowercase(Locale.ROOT)
                val f = File(outDir, String.format(Locale.ROOT, "%s%04d.%s", prefix, n + 1, ext))
                var bytes = 0L
                var ok = true
                z.getInputStream(e).use { input ->
                    FileOutputStream(f).use { os ->
                        val buf = ByteArray(65536)
                        while (true) {
                            val r = input.read(buf)
                            if (r <= 0) break
                            bytes += r
                            if (bytes > maxEntryBytes || total + bytes > maxTotalBytes) { ok = false; break }
                            os.write(buf, 0, r)
                        }
                    }
                }
                if (!ok) {
                    f.delete()
                    if (total + bytes > maxTotalBytes && bytes <= maxEntryBytes) break   // het tran tong: dung han
                    continue                                                            // tep qua lon: bo tep nay, lay tiep
                }
                total += bytes; n++; out.add(f)
            }
        }
        return out
    }
}
