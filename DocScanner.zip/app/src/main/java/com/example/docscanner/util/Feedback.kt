package com.example.docscanner.util

import android.content.Context
import android.media.MediaActionSound
import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.View

/**
 * The small touches of feedback (phiên 25, TECHNICAL_DOCS.md 4.76; PDF list items 4.4 "shutter sound" and 13.4 "haptics"): a camera click when a page is photographed, a light tick when a tool is
 * picked or a mark is erased in the reader, a firmer buzz when something is refused (a letter the font lacks). One switch on the main screen turns all of it off ([enabled]); the system's
 * own touch-feedback setting still applies on top of it, since [View.performHapticFeedback] obeys that.
 */
object Feedback {

    private const val PREFS = "feedback"
    private const val KEY_ENABLED = "enabled"

    fun enabled(context: Context): Boolean = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, true)

    fun setEnabled(context: Context, on: Boolean) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, on).apply()
    }

    /** A light tick: a control was used. */
    fun tick(view: View) {
        if (!enabled(view.context)) return
        view.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }

    /** Something worked (a photo taken): a firm click, the "confirm" pattern where the device has one. */
    fun confirm(view: View) {
        if (!enabled(view.context)) return
        view.performHapticFeedback(if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.LONG_PRESS)
    }

    /** Something was refused: the "reject" pattern where the device has one. */
    fun error(view: View) {
        if (!enabled(view.context)) return
        view.performHapticFeedback(if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) HapticFeedbackConstants.REJECT else HapticFeedbackConstants.LONG_PRESS)
    }

    private var sound: MediaActionSound? = null

    /** The camera shutter click (the system's own sound, which a phone sold where the click is required plays whatever the volume). */
    fun shutter(context: Context) {
        if (!enabled(context)) return
        try {
            val s = sound ?: MediaActionSound().also {
                it.load(MediaActionSound.SHUTTER_CLICK)
                sound = it
            }
            s.play(MediaActionSound.SHUTTER_CLICK)
        } catch (e: Exception) {
            // a sound that cannot play must never stop the photo
        }
    }
}
