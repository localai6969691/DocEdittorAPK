package com.example.docscanner.util

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

/**
 * Takes the web page out of an MHTML file (`.mht` / `.mhtml`, RFC 2557: what "Save as single file" in Chrome / Edge / Opera and old Internet Explorer writes) so that it goes through the
 * same reflowing import as an ordinary `.html` file (phiên 25, TECHNICAL_DOCS.md 4.74; PDF list item 9.5). An MHTML file is a MIME message: a `multipart/related` body whose first part
 * is the page and whose other parts are its images, style sheets and frames. Only the page's TEXT is imported, so the other parts are skipped, not decoded.
 *
 * [htmlOf] reads the headers (folded lines unfolded, parameters with or without quotes), splits a multipart body on its boundary (nested `multipart/alternative` too), decodes the part's
 * `Content-Transfer-Encoding` (quoted-printable, base64, or as is), then its charset: the one the part declares, else, in the same order as `DocumentImport.decodeText` (kept apart so
 * this file stands alone for the checks): a byte-order mark, a `<meta charset>` in the first 2 KB, strict UTF-8, and when the bytes are not UTF-8 Windows-1252, which never fails. The FIRST `text/html` part is the page (browsers write it first; a later one is a frame). A message with no HTML part gives null.
 * The base64 decoder is written here because `java.util.Base64` needs Android 8 and this app supports Android 7.
 */
object MhtmlImport {

    /** How deep multipart parts may nest (a message nested deeper is not a web page): further parts are ignored. */
    private const val MAX_DEPTH = 6

    private class Headers(val map: Map<String, String>) {
        operator fun get(name: String): String? = map[name.lowercase()]
    }

    /** The decoded text of the first `text/html` part of [bytes], or null when there is none (or this is not a MIME message). */
    fun htmlOf(bytes: ByteArray): String? {
        if (bytes.isEmpty()) return null
        // one byte = one char, so the structure can be cut up as text without damaging the bytes of any part
        val raw = String(bytes, Charsets.ISO_8859_1)
        return htmlFromEntity(raw, 0)
    }

    /** Whether [bytes] looks like an MHTML / MIME message at all (a header line near the top), so a plain page saved under the wrong name is not misread. */
    fun looksLikeMime(bytes: ByteArray): Boolean {
        val head = String(bytes, 0, minOf(bytes.size, 4096), Charsets.ISO_8859_1).lowercase()
        return head.contains("mime-version:") || head.contains("content-type: multipart/") || head.contains("content-type:multipart/")
    }

    private fun splitHeaderBody(entity: String): Pair<String, String> {
        val crlf = entity.indexOf("\r\n\r\n")
        val lf = entity.indexOf("\n\n")
        return when {
            crlf >= 0 && (lf < 0 || crlf <= lf) -> Pair(entity.substring(0, crlf), entity.substring(crlf + 4))
            lf >= 0 -> Pair(entity.substring(0, lf), entity.substring(lf + 2))
            else -> Pair(entity, "")
        }
    }

    private fun parseHeaders(block: String): Headers {
        val map = HashMap<String, String>()
        var name: String? = null
        val value = StringBuilder()
        fun flush() {
            val n = name
            if (n != null && !map.containsKey(n)) map[n] = value.toString().trim()
            name = null
            value.setLength(0)
        }
        for (line in block.split("\n")) {
            val l = line.trimEnd('\r')
            if (l.isEmpty()) continue
            if ((l[0] == ' ' || l[0] == '\t') && name != null) {
                value.append(' ').append(l.trim())   // a folded continuation line
                continue
            }
            val colon = l.indexOf(':')
            if (colon <= 0) continue
            flush()
            name = l.substring(0, colon).trim().lowercase()
            value.append(l.substring(colon + 1).trim())
        }
        flush()
        return Headers(map)
    }

    /** `type/subtype` (lower case) of a Content-Type value and its parameters by lower-case name, quotes removed. */
    private fun parseContentType(value: String?): Pair<String, Map<String, String>> {
        if (value == null) return Pair("text/plain", emptyMap())
        val pieces = splitParams(value)
        val type = pieces[0].trim().lowercase()
        val params = HashMap<String, String>()
        for (p in pieces.drop(1)) {
            val eq = p.indexOf('=')
            if (eq <= 0) continue
            val k = p.substring(0, eq).trim().lowercase()
            var v = p.substring(eq + 1).trim()
            if (v.length >= 2 && v[0] == '"' && v[v.length - 1] == '"') v = v.substring(1, v.length - 1)
            params[k] = v
        }
        return Pair(type, params)
    }

    /** Splits on `;` outside double quotes (a boundary may contain one). */
    private fun splitParams(s: String): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var quoted = false
        for (c in s) {
            if (c == '"') quoted = !quoted
            if (c == ';' && !quoted) {
                out.add(cur.toString())
                cur.setLength(0)
            } else {
                cur.append(c)
            }
        }
        out.add(cur.toString())
        return out
    }

    private fun htmlFromEntity(entity: String, depth: Int): String? {
        if (depth > MAX_DEPTH) return null
        val (headBlock, body) = splitHeaderBody(entity)
        val headers = parseHeaders(headBlock)
        val (type, params) = parseContentType(headers["content-type"])
        if (type.startsWith("multipart/")) {
            val boundary = params["boundary"] ?: return null
            for (part in splitParts(body, boundary)) {
                val found = htmlFromEntity(part, depth + 1)
                if (found != null) return found
            }
            return null
        }
        if (type != "text/html" && type != "application/xhtml+xml") return null
        val decoded = decodeTransfer(body, headers["content-transfer-encoding"]?.trim()?.lowercase())
        return decodeCharset(decoded, params["charset"])
    }

    /** The parts between the `--boundary` lines, each without the line break that belongs to the delimiter. */
    private fun splitParts(body: String, boundary: String): List<String> {
        val delimiter = "--$boundary"
        val parts = ArrayList<String>()
        var pos = body.indexOf(delimiter)
        while (pos >= 0) {
            var start = pos + delimiter.length
            if (body.startsWith("--", start)) break   // the closing delimiter
            // the rest of the delimiter line (transport padding, then the line break)
            val eol = body.indexOf('\n', start)
            if (eol < 0) break
            start = eol + 1
            val next = body.indexOf(delimiter, start)
            var end = if (next < 0) body.length else next
            // the line break before a delimiter belongs to the delimiter, not to the part
            if (end > start && body[end - 1] == '\n') end--
            if (end > start && body[end - 1] == '\r') end--
            if (end >= start) parts.add(body.substring(start, end))
            pos = next
        }
        return parts
    }

    private fun decodeTransfer(body: String, encoding: String?): ByteArray = when (encoding) {
        "quoted-printable" -> decodeQuotedPrintable(body)
        "base64" -> decodeBase64(body)
        else -> body.toByteArray(Charsets.ISO_8859_1)
    }

    private fun hexValue(c: Char): Int = when (c) {
        in '0'..'9' -> c - '0'
        in 'A'..'F' -> c - 'A' + 10
        in 'a'..'f' -> c - 'a' + 10
        else -> -1
    }

    /** Quoted-printable: `=XX` is one byte, `=` at the end of a line joins it with the next (a soft break); a bad escape is kept as it is. */
    fun decodeQuotedPrintable(s: String): ByteArray {
        val out = java.io.ByteArrayOutputStream(s.length)
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c != '=') {
                out.write(c.code and 0xFF)
                i++
                continue
            }
            // soft line break: "=" + optional spaces + line break
            var j = i + 1
            while (j < s.length && (s[j] == ' ' || s[j] == '\t')) j++
            if (j < s.length && s[j] == '\r' && j + 1 < s.length && s[j + 1] == '\n') {
                i = j + 2
                continue
            }
            if (j < s.length && s[j] == '\n') {
                i = j + 1
                continue
            }
            if (i + 2 < s.length && hexValue(s[i + 1]) >= 0 && hexValue(s[i + 2]) >= 0) {
                out.write(hexValue(s[i + 1]) * 16 + hexValue(s[i + 2]))
                i += 3
            } else {
                out.write('='.code)
                i++
            }
        }
        return out.toByteArray()
    }

    /** Base64 by hand: characters outside the alphabet (line breaks, spaces) are skipped, `=` ends the data. */
    fun decodeBase64(s: String): ByteArray {
        val out = java.io.ByteArrayOutputStream(s.length * 3 / 4)
        var acc = 0
        var bits = 0
        for (c in s) {
            val v = when (c) {
                in 'A'..'Z' -> c - 'A'
                in 'a'..'z' -> c - 'a' + 26
                in '0'..'9' -> c - '0' + 52
                '+', '-' -> 62
                '/', '_' -> 63
                '=' -> break
                else -> continue
            }
            acc = (acc shl 6) or v
            bits += 6
            if (bits >= 8) {
                bits -= 8
                out.write((acc shr bits) and 0xFF)
            }
        }
        return out.toByteArray()
    }

    private val META_CHARSET = Regex("charset\\s*=\\s*[\"']?([A-Za-z0-9_:.-]+)", RegexOption.IGNORE_CASE)

    private fun decodeCharset(bytes: ByteArray, charset: String?): String {
        if (charset != null) {
            try {
                return String(bytes, Charset.forName(charset.trim()))
            } catch (e: Exception) {
                // an unknown or unsupported name: look further
            }
        }
        val n = bytes.size
        if (n >= 3 && (bytes[0].toInt() and 0xFF) == 0xEF && (bytes[1].toInt() and 0xFF) == 0xBB && (bytes[2].toInt() and 0xFF) == 0xBF) return String(bytes, 3, n - 3, Charsets.UTF_8)
        val head = String(bytes, 0, minOf(n, 2048), Charsets.ISO_8859_1)
        val named = META_CHARSET.find(head)?.groupValues?.get(1)
        if (named != null) {
            try {
                return String(bytes, Charset.forName(named))
            } catch (e: Exception) {
                // the page names a charset this device does not have: look further
            }
        }
        return try {
            Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString()
        } catch (e: CharacterCodingException) {
            String(bytes, Charset.forName("windows-1252"))
        }
    }
}
