package com.example.docscanner.util

import java.io.InputStream
import java.math.BigInteger
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.cert.X509Certificate

/**
 * Builds the detached CMS (PKCS#7) `SignedData` that goes into a PDF signature's `/Contents` (SubFilter
 * `adbe.pkcs7.detached`): SHA-256 for the digest, RSA PKCS#1 v1.5 for the signature, the signer's certificate embedded,
 * and the three signed attributes a verifier expects (content type, signing time, message digest).
 *
 * The one classic trap: the signature is computed over the signed attributes tagged as a plain SET (0x31), but they are
 * STORED in the SignerInfo under the context tag [0] IMPLICIT (0xA0) - the same bytes with a different first byte.
 * Both forms are produced from the same sorted content below. The result is checked against two independent verifiers
 * (pdfsig and openssl) through the Java twin of [DerWriter]/this file, see tools/verify/digital_signature_check.py.
 *
 * It embeds the signer's certificate and, when the key came from a PKCS#12 file (4.49.8), the rest of that certificate's chain too (without the
 * chain a viewer cannot connect a certificate-authority certificate to its root and shows "unknown signer"). RSA keys sign with SHA-256 and PKCS#1
 * v1.5; EC keys with ECDSA over SHA-256 (the algorithm identifier of ECDSA has NO parameters field, unlike RSA's NULL: RFC 5758). An optional
 * time stamp token (4.48.6) is added; there is no revocation data, so the signature is valid but not long-term-validated.
 */
internal object CmsSigner {

    private const val OID_SIGNED_DATA = "1.2.840.113549.1.7.2"
    private const val OID_DATA = "1.2.840.113549.1.7.1"
    private const val OID_CONTENT_TYPE = "1.2.840.113549.1.9.3"
    private const val OID_MESSAGE_DIGEST = "1.2.840.113549.1.9.4"
    private const val OID_SIGNING_TIME = "1.2.840.113549.1.9.5"
    private const val OID_SHA256 = "2.16.840.1.101.3.4.2.1"
    private const val OID_SHA256_RSA = "1.2.840.113549.1.1.11"
    private const val OID_ECDSA_SHA256 = "1.2.840.10045.4.3.2"

    private fun algorithm(oid: String): ByteArray = DerWriter.sequence(DerWriter.oid(oid), DerWriter.nullValue())

    private fun attribute(oid: String, value: ByteArray): ByteArray =
        DerWriter.sequence(DerWriter.oid(oid), DerWriter.setOf(value))

    /** [signRaw] receives the DER of the signed attributes (tagged SET) and returns the raw RSA-SHA256 signature of them. */
    fun buildDetached(
        contentDigest: ByteArray, certDer: ByteArray, signRaw: (ByteArray) -> ByteArray, signingTimeMillis: Long,
        /** Gets an RFC 3161 token for the signature value (PAdES-B-T); it goes into `unsignedAttrs`, which the signature does not cover, so adding it does not change the signature. */
        timestamper: ((ByteArray) -> ByteArray)? = null,
        /** DER of the OTHER certificates to embed after the signer's own (intermediates, root); empty for a self-signed certificate. */
        chainDer: List<ByteArray> = emptyList(),
        ecdsa: Boolean = false
    ): ByteArray {
        val (serial, issuer) = DerWriter.serialAndIssuer(certDer)
        val attrs = DerWriter.sortedForSet(
            listOf(
                attribute(OID_CONTENT_TYPE, DerWriter.oid(OID_DATA)),
                attribute(OID_SIGNING_TIME, DerWriter.utcTime(signingTimeMillis)),
                attribute(OID_MESSAGE_DIGEST, DerWriter.octetString(contentDigest))
            )
        )
        val attrsContent = DerWriter.concat(*attrs.toTypedArray())
        val toSign = DerWriter.tlv(0x31, attrsContent)               // signed as a plain SET ...
        val signature = signRaw(toSign)
        val parts = mutableListOf(
            DerWriter.integer(BigInteger.ONE),
            DerWriter.sequence(issuer, serial),                       // IssuerAndSerialNumber
            algorithm(OID_SHA256),
            DerWriter.tlv(0xA0, attrsContent),                        // ... but stored as [0] IMPLICIT
            if (ecdsa) DerWriter.sequence(DerWriter.oid(OID_ECDSA_SHA256)) else algorithm(OID_SHA256_RSA),
            DerWriter.octetString(signature)
        )
        if (timestamper != null) parts.add(DerWriter.tlv(0xA1, attribute(TimeStamp.OID_TS_TOKEN, timestamper(signature))))   // unsignedAttrs [1] IMPLICIT
        val signerInfo = DerWriter.sequence(*parts.toTypedArray())
        val signedData = DerWriter.sequence(
            DerWriter.integer(BigInteger.ONE),
            DerWriter.setOf(algorithm(OID_SHA256)),
            DerWriter.sequence(DerWriter.oid(OID_DATA)),              // detached: the content is not inside
            DerWriter.tlv(0xA0, DerWriter.concat(certDer, *chainDer.toTypedArray())),     // certificates [0] IMPLICIT: the signer's first
            DerWriter.setOf(signerInfo)
        )
        return DerWriter.sequence(DerWriter.oid(OID_SIGNED_DATA), DerWriter.tlv(0xA0, signedData))
    }

    /** Digest [content] (the PDF bytes outside the signature placeholder, handed over by PDFBox) and sign it. */
    fun signContent(
        content: InputStream, cert: X509Certificate, key: PrivateKey, signingTimeMillis: Long, timestamper: ((ByteArray) -> ByteArray)? = null,
        chain: List<X509Certificate> = emptyList()
    ): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(16 * 1024)
        while (true) {
            val n = content.read(buffer)
            if (n < 0) break
            md.update(buffer, 0, n)
        }
        val ecdsa = key.algorithm.equals("EC", ignoreCase = true)
        val own = cert.encoded
        val others = chain.map { it.encoded }.filter { !it.contentEquals(own) }          // the chain usually starts with the signer's own certificate
        return buildDetached(md.digest(), own, { data ->
            val s = Signature.getInstance(if (ecdsa) "SHA256withECDSA" else "SHA256withRSA")
            s.initSign(key)
            s.update(data)
            s.sign()
        }, signingTimeMillis, timestamper, others, ecdsa)
    }
}
