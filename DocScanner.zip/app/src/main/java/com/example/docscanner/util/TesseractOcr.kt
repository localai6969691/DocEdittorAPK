package com.example.docscanner.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.example.docscanner.DocScannerApp
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * OCR for the Cyrillic script (Russian, Ukrainian, Bulgarian...), the one script ML Kit cannot read: its official language table has
 * Latin, Chinese, Devanagari, Japanese and Korean models only (developers.google.com/ml-kit/vision/text-recognition/v2/languages).
 *
 * Engine: Tesseract 5 through Tesseract4Android (Apache-2.0, published on JitPack only - see settings.gradle). Data: the
 * `rus.traineddata` of the official `tessdata_fast` repository (Apache-2.0, about 3.7 MB, LSTM only), downloaded ONCE on demand over
 * HTTPS into the app's private folder (`filesDir/tesseract/tessdata`) - never bundled, so people who never read Cyrillic never pay the
 * size. After that everything runs offline on the device, like the other scripts.
 *
 * The data file is not pinned to a SHA-256 yet ([EXPECTED_SHA256] is empty) because it could not be fetched where this code was
 * written; the other safeguards are HTTPS only, a size window, a temporary name that is renamed only when complete, and Tesseract's
 * own parser rejecting a corrupt file at `init` (then the file is deleted and the person is asked again).
 */
object TesseractOcr {

    private const val LANG = "rus"
    private val URLS = listOf(
        "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/rus.traineddata",
        "https://github.com/tesseract-ocr/tessdata_fast/raw/main/rus.traineddata"
    )
    /** Fill in after the first successful CI run (`sha256sum rus.traineddata`); while empty the check is skipped. */
    private const val EXPECTED_SHA256 = ""
    private const val MIN_BYTES = 1_500_000L
    private const val MAX_BYTES = 40_000_000L
    /** Longest side handed to Tesseract: a 300 dpi A4 page is 3508 px; larger photos only cost time and memory. */
    private const val MAX_SIDE = 3600

    private val mutex = Mutex()          // TessBaseAPI is not thread-safe
    private var api: TessBaseAPI? = null

    private fun root(context: Context) = File(context.applicationContext.filesDir, "tesseract")
    private fun dataFile(context: Context) = File(File(root(context), "tessdata"), "$LANG.traineddata")

    fun isReady(context: Context = DocScannerApp.instance): Boolean = dataFile(context).let { it.isFile && it.length() >= MIN_BYTES }

    /** Downloads the Russian data once. Returns true when the file is in place and verified. [onProgress] gets 0..100 (or -1 when the size is unknown). */
    suspend fun download(context: Context, onProgress: (Int) -> Unit = {}): Boolean = withContext(Dispatchers.IO) {
        if (isReady(context)) return@withContext true
        val target = dataFile(context)
        target.parentFile?.mkdirs()
        val part = File(target.parentFile, "$LANG.traineddata.part")
        for (address in URLS) {
            if (!address.startsWith("https://")) continue
            try {
                part.delete()
                val conn = URL(address).openConnection() as HttpURLConnection
                conn.connectTimeout = 15_000
                conn.readTimeout = 30_000
                conn.instanceFollowRedirects = true
                if (conn.responseCode != HttpURLConnection.HTTP_OK) { conn.disconnect(); continue }
                val total = conn.contentLengthLong
                val digest = MessageDigest.getInstance("SHA-256")
                var done = 0L
                var lastPercent = -2
                conn.inputStream.use { input ->
                    part.outputStream().use { output ->
                        val buffer = ByteArray(32 * 1024)
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            output.write(buffer, 0, n)
                            digest.update(buffer, 0, n)
                            done += n
                            if (done > MAX_BYTES) throw java.io.IOException("too large")
                            val percent = if (total > 0) (done * 100 / total).toInt().coerceIn(0, 100) else -1
                            if (percent != lastPercent) { lastPercent = percent; onProgress(percent) }
                        }
                    }
                }
                conn.disconnect()
                val hex = digest.digest().joinToString("") { "%02x".format(it) }
                val sizeOk = done in MIN_BYTES..MAX_BYTES
                val hashOk = EXPECTED_SHA256.isEmpty() || hex.equals(EXPECTED_SHA256, ignoreCase = true)
                if (sizeOk && hashOk && part.renameTo(target)) return@withContext true
            } catch (e: Exception) {
                // try the next address
            }
        }
        part.delete()
        false
    }

    /** Frees the native engine (a few tens of MB); the next recognition recreates it. Called when the app goes to the background. */
    fun release() {
        if (!mutex.tryLock()) return
        try {
            api?.recycle()
            api = null
        } finally {
            mutex.unlock()
        }
    }

    private fun engine(): TessBaseAPI? {
        api?.let { return it }
        val context = DocScannerApp.instance
        if (!isReady(context)) return null
        val tess = TessBaseAPI()
        if (!tess.init(root(context).absolutePath, LANG)) {
            tess.recycle()
            dataFile(context).delete()          // corrupt or unreadable: forget it so the person is offered the download again
            return null
        }
        tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
        api = tess
        return tess
    }

    /** The bitmap Tesseract is given (ARGB_8888, longest side <= [MAX_SIDE]) and the factor that maps its coordinates back to the original. */
    private class Prepared(val bitmap: Bitmap, val scale: Float, val owned: Boolean)

    private fun prepare(source: Bitmap): Prepared {
        val longest = maxOf(source.width, source.height)
        val factor = if (longest > MAX_SIDE) MAX_SIDE.toFloat() / longest else 1f
        if (factor == 1f && source.config == Bitmap.Config.ARGB_8888) return Prepared(source, 1f, false)
        val w = maxOf(1, Math.round(source.width * factor))
        val h = maxOf(1, Math.round(source.height * factor))
        val scaled = Bitmap.createScaledBitmap(source, w, h, true)
        val argb = if (scaled.config == Bitmap.Config.ARGB_8888) scaled else (scaled.copy(Bitmap.Config.ARGB_8888, false) ?: scaled)
        if (argb !== scaled && scaled !== source) scaled.recycle()
        return Prepared(argb, 1f / factor, argb !== source)
    }

    /** Runs [block] on a prepared copy of [source]; null when the data is missing or anything native fails. */
    private suspend fun <T> withEngine(source: Bitmap, block: (TessBaseAPI, Float) -> T): T? = mutex.withLock {
        withContext(Dispatchers.Default) {
            var prepared: Prepared? = null
            try {
                val tess = engine() ?: return@withContext null
                prepared = prepare(source)
                tess.setImage(prepared.bitmap)
                block(tess, prepared.scale)
            } catch (e: Throwable) {
                null
            } finally {
                prepared?.let { if (it.owned) it.bitmap.recycle() }
            }
        }
    }

    suspend fun recognizeText(bitmap: Bitmap): String = withEngine(bitmap) { tess, _ -> tess.getUTF8Text() ?: "" } ?: ""

    suspend fun recognizeBlocks(bitmap: Bitmap): List<String> {
        val hocr = withEngine(bitmap) { tess, _ -> tess.getHOCRText(0) ?: "" } ?: return emptyList()
        return HocrParser.paragraphs(hocr).map { par -> par.joinToString("\n") { line -> line.words.joinToString(" ") { it.text } } }
            .map { it.trim() }.filter { it.isNotBlank() }
    }

    suspend fun recognizeLines(bitmap: Bitmap): List<OcrHelper.OcrLine> {
        val parsed = withEngine(bitmap) { tess, scale -> Pair(HocrParser.lines(tess.getHOCRText(0) ?: ""), scale) } ?: return emptyList()
        val (lines, scale) = parsed
        fun at(v: Int) = Math.round(v * scale)
        return lines.map { line ->
            OcrHelper.OcrLine(line.words.map { w -> OcrHelper.OcrWord(w.text, Rect(at(w.left), at(w.top), at(w.right), at(w.bottom)), null) })
        }
    }
}
