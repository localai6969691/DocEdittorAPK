package com.example.docscanner.util

import android.graphics.Bitmap

/**
 * Turns [PiiDetector] matches into boxes on a page picture: OCR the picture, search the text of each recognised line, and draw a box
 * around the words that carry each match. Boxes are fractions of the picture (left, top, right, bottom), the convention of
 * [PdfRedactor] and `RedactionView`, padded a little so the edges of the digits are covered.
 */
object PiiScanner {

    suspend fun scan(bitmap: Bitmap, kinds: Set<PiiDetector.Kind>): List<FloatArray> {
        val lines = OcrHelper.recognizeLines(bitmap, OcrHelper.OcrScript.LATIN)
        val w = bitmap.width.toFloat()
        val h = bitmap.height.toFloat()
        val out = ArrayList<FloatArray>()
        for (line in lines) {
            val words = line.words.map { it.text }
            val text = words.joinToString(" ")
            for (match in PiiDetector.find(text, kinds)) {
                val range = PiiDetector.wordsCovering(words, match.start, match.end) ?: continue
                val boxes = range.map { line.words[it].box }
                val left = boxes.minOf { it.left }.toFloat()
                val top = boxes.minOf { it.top }.toFloat()
                val right = boxes.maxOf { it.right }.toFloat()
                val bottom = boxes.maxOf { it.bottom }.toFloat()
                val padX = (bottom - top) * 0.25f
                val padY = (bottom - top) * 0.2f
                out.add(
                    floatArrayOf(
                        ((left - padX) / w).coerceIn(0f, 1f),
                        ((top - padY) / h).coerceIn(0f, 1f),
                        ((right + padX) / w).coerceIn(0f, 1f),
                        ((bottom + padY) / h).coerceIn(0f, 1f)
                    )
                )
            }
        }
        return out
    }
}
