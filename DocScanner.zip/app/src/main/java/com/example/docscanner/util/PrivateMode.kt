package com.example.docscanner.util

import android.content.Context
import java.io.File

/**
 * Che do rieng tu - khong ghi lich su (phien 18, PDF "Thieu gi de ban app" muc D). Khi BAT:
 *  - moi tai lieu xuat ra ([documentsDir]) va moi du an quet ([projectsDir]) di vao thu muc RIENG trong bo nho trong cua app, KHONG nam trong danh sach "Tai lieu da xuat"
 *    cua che do thuong va khong vao Thung rac: XOA o che do nay la xoa han (ghi de roi xoa, [StorageTools.wipe]) chu khong cat vao Thung rac;
 *  - khi TAT, toan bo thu muc rieng bi xoa sach ([wipeAll]) va ten tai lieu rieng tu bi go khoi sao / the.
 * Hai diem tap trung duoc doi huong: `PdfExporter.exportDir` va `FileUtils.projectsRootDir` - nen khong phai sua tung noi xuat.
 * Trang thai BAT duoc luu ben (khong mat tai lieu khi he thong thu hoi tien trinh); giao dien luon cho thay dang o che do rieng tu.
 *
 * GIOI HAN (noi thang): che do nay khong tro thanh "an danh" voi he dieu hanh - tep nam trong bo nho rieng cua app (moi app khac khong doc duoc, nhung nguoi dung
 * root / sao luu ADB thi co), anh chup tam o thu muc cache van theo chu ky don dep thong thuong (24 gio) chu khong xoa ngay, va "ghi de truoc khi xoa" chi la no luc
 * tot nhat tren bo nho flash (xem StorageTools, TECHNICAL_DOCS.md 4.36). Thu muc dich khac ma nguoi dung chon de luu hoac chia se thi nam ngoai tam kiem soat cua app.
 */
object PrivateMode {
    private const val PREFS = "private_mode"
    private const val KEY = "enabled"

    @Volatile private var cached: Boolean? = null

    fun isOn(context: Context): Boolean {
        cached?.let { return it }
        val v = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY, false)
        cached = v
        return v
    }

    private fun root(context: Context): File = File(context.filesDir, "private")

    /** Thu muc tai lieu xuat khi dang o che do rieng tu (chua tao, chi tra duong dan; [documentsDir] tao khi can). */
    fun documentsDir(context: Context): File = File(root(context), "documents").also { if (!it.exists()) it.mkdirs() }

    fun projectsDir(context: Context): File = File(root(context), "projects").also { if (!it.exists()) it.mkdirs() }

    /** Bat che do. Khong xoa gi. */
    fun turnOn(context: Context) {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, true).apply()
        cached = true
    }

    /** So tai lieu rieng tu hien co (de noi ro truoc khi tat). */
    fun count(context: Context): Int = countFiles(root(context))

    private fun countFiles(f: File): Int = if (f.isFile) 1 else (f.listFiles()?.sumOf { countFiles(it) } ?: 0)

    /** Tat che do va xoa sach moi thu cua che do rieng tu. @return so tep da xoa. */
    fun turnOff(context: Context): Int {
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, false).apply()
        cached = false
        return StorageTools.wipeTree(root(context))
    }
}
