package com.example.docscanner.util

import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.File
import java.io.FileOutputStream

/**
 * One A4 page with a QR code drawn as VECTOR squares (sharp at any print size; phiên 19, mục 4.47.5) and a caption under it. The code is [QrEncoder]'s; the quiet zone of
 * 4 modules that readers need is included. The caption is for people ("Wi-Fi: Home"): it must never contain a secret such as a Wi-Fi password.
 */
object QrPdfBuilder {
    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val CODE_SIDE = 420f
    private const val QUIET = 4

    fun build(outFile: File, qr: QrEncoder.Qr, caption: String): Boolean {
        val module = CODE_SIDE / (qr.size + 2 * QUIET)
        val left = (PAGE_W - CODE_SIDE) / 2f
        val top = 110f
        val document = PdfDocument()
        try {
            val page = document.startPage(PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, 1).create())
            val canvas = page.canvas
            val ink = Paint().apply { style = Paint.Style.FILL; color = Color.BLACK; isAntiAlias = false }
            for (y in 0 until qr.size) for (x in 0 until qr.size) {
                if (!qr.get(x, y)) continue
                val x0 = left + (x + QUIET) * module
                val y0 = top + (y + QUIET) * module
                canvas.drawRect(x0, y0, x0 + module, y0 + module, ink)   // squares touch: no hairline gaps between neighbours
            }
            val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 13f; color = Color.BLACK; textAlign = Paint.Align.CENTER }
            var y = top + CODE_SIDE + 36f
            for (line in TextPdfBuilder.wrapText(caption, text, 480f).take(8)) {
                canvas.drawText(line, PAGE_W / 2f, y, text)
                y += 18f
            }
            document.finishPage(page)
            FileOutputStream(outFile).use { document.writeTo(it) }
            return true
        } finally {
            document.close()
        }
    }
}
