package com.example.docscanner.util

import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSDictionary
import com.tom_roush.pdfbox.cos.COSFloat
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.File
import java.util.Locale
import kotlin.math.hypot
import kotlin.math.max

/**
 * REAL text-markup annotations (phiên 17, mục 4.31): highlight, underline and strike-out written as standard PDF annotations
 * (`/Subtype /Highlight` etc.), not burnt into the page - any reader can list, move or delete them, and the page text is untouched.
 * Item "Highlight/Underline/Strikethrough thật" (B11/N-list) of the PDF "Thiếu gì để bán app".
 *
 * Geometry. A mark is a box on the page AS DISPLAYED, in fractions (left, top, right, bottom) - the convention of [PdfRedactor] and
 * `RedactionView`. [quadPoints] turns it into the 4 corners in the page's own user space through [PdfPageGeometry] (so a rotated page
 * or an offset CropBox is handled once, in one place), in the order every real reader writes and expects: top-left, top-right,
 * bottom-left, bottom-right of the DISPLAYED box ("Z" order - the literal reading of the spec, counter-clockwise, is what Acrobat
 * itself does NOT produce). The annotation `/Rect` is the bounding box of the four corners.
 *
 * Appearance. Many readers (older Drive preview, some e-ink apps) draw nothing for an annotation without an appearance stream, so one is
 * always written ([appearance]), in page coordinates with an identity matrix and `/BBox` = `/Rect`: highlight = a filled quad with
 * blend mode Multiply and opacity 0.6 (text stays black and readable even in a reader that ignores the blend mode), underline /
 * strike-out = a line along the bottom edge / through the middle, thickness 7 % of the box height (at least 0.7 pt). Lines are computed
 * from the four corners, so they follow the displayed orientation on rotated pages.
 *
 * Words. The boxes come from OCR words of the rendered page ([WordBox]); [findPhrase] finds a typed phrase ignoring case and diacritics
 * (so "hop dong" finds "Hợp đồng"), [wordsInRect] picks the words under a dragged rectangle, and [lineBoxes] merges the chosen words of
 * each line into ONE box per line (a highlighter, not one box per word). All of that is pure and mirrored in
 * tools/verify/TextMarkupCheck.java; the geometry and appearance are checked on rotated / cropped pages with poppler by
 * tools/verify/text_markup_check.py.
 */
object PdfTextMarkup {

    enum class Style(val subtype: String) { HIGHLIGHT("Highlight"), UNDERLINE("Underline"), STRIKEOUT("StrikeOut") }

    /** Highlight opacity: with Multiply the text stays dark; without it (reader ignores BM) 0.6 still shows the text through. */
    const val HIGHLIGHT_OPACITY = 0.6f

    /** Line thickness as a fraction of the box height, and its floor in points. */
    const val LINE_FRACTION = 0.07f
    const val LINE_MIN = 0.7f

    /** Vertical padding added around merged line boxes, as a fraction of the line height (OCR boxes hug the glyphs). */
    const val LINE_PAD = 0.08f

    /** One mark to write: a box on the displayed page (fractions), its kind and colour (3 floats 0..1). */
    class Mark(val box: FloatArray, val style: Style, val rgb: FloatArray)

    /** One OCR word: text and its box on the displayed page (fractions), [line] = index of the OCR line it belongs to. */
    class WordBox(val text: String, val box: FloatArray, val line: Int)

    // ---------------------------------------------------------------- geometry (pure)

    /** 8 numbers x1 y1 .. x4 y4 (TL, TR, BL, BR of the displayed box) in user space. [box] = fractions l, t, r, b. */
    fun quadPoints(geo: PdfPageGeometry, box: FloatArray): FloatArray {
        val l = minOf(box[0], box[2]).coerceIn(0f, 1f) * geo.displayWidth
        val r = maxOf(box[0], box[2]).coerceIn(0f, 1f) * geo.displayWidth
        val t = minOf(box[1], box[3]).coerceIn(0f, 1f) * geo.displayHeight
        val b = maxOf(box[1], box[3]).coerceIn(0f, 1f) * geo.displayHeight
        val tl = geo.toUser(l, t); val tr = geo.toUser(r, t); val bl = geo.toUser(l, b); val br = geo.toUser(r, b)
        return floatArrayOf(tl.first, tl.second, tr.first, tr.second, bl.first, bl.second, br.first, br.second)
    }

    /** `[llx, lly, urx, ury]` bounding box of a quad. */
    fun bounds(q: FloatArray): FloatArray {
        val xs = floatArrayOf(q[0], q[2], q[4], q[6]); val ys = floatArrayOf(q[1], q[3], q[5], q[7])
        return floatArrayOf(xs.min(), ys.min(), xs.max(), ys.max())
    }

    private fun f3(v: Float): String = String.format(Locale.US, "%.3f", v)

    /** Content stream of the appearance, in page user space. [rgb] = 3 floats 0..1. */
    fun appearance(style: Style, rgb: FloatArray, q: FloatArray): String {
        val c = "${f3(rgb[0])} ${f3(rgb[1])} ${f3(rgb[2])}"
        if (style == Style.HIGHLIGHT) {
            return "/GS gs\n$c rg\n${f3(q[0])} ${f3(q[1])} m ${f3(q[2])} ${f3(q[3])} l ${f3(q[6])} ${f3(q[7])} l ${f3(q[4])} ${f3(q[5])} l h f\n"
        }
        val height = hypot(q[0] - q[4], q[1] - q[5])
        val w = max(LINE_MIN, LINE_FRACTION * height)
        // unit vector from the bottom edge towards the top edge (displayed "up", whatever the rotation)
        val ux = if (height > 0f) (q[0] - q[4]) / height else 0f
        val uy = if (height > 0f) (q[1] - q[5]) / height else 1f
        val (x1, y1, x2, y2) = if (style == Style.UNDERLINE) {
            val s = w
            floatArrayOf(q[4] + ux * s, q[5] + uy * s, q[6] + ux * s, q[7] + uy * s)
        } else {
            floatArrayOf((q[0] + q[4]) / 2f, (q[1] + q[5]) / 2f, (q[2] + q[6]) / 2f, (q[3] + q[7]) / 2f)
        }
        return "$c RG\n${f3(w)} w\n${f3(x1)} ${f3(y1)} m ${f3(x2)} ${f3(y2)} l S\n"
    }

    // ---------------------------------------------------------------- words (pure)

    /** Lower-case, no diacritics, only letters and digits ("nhà," -> "nha"). */
    fun fold(s: String): String = HistoryFilter.normalize(s).filter { it.isLetterOrDigit() }

    /**
     * Index ranges (into [words]) of every occurrence of [query], scanning in reading order without overlaps. Words with no letter or digit
     * (a lone dash, a bullet) are skipped, so they cannot break a phrase. One query word matches inside a word ("hop" in "hợp"); in a
     * longer phrase the first word must END with its query word, middle words must EQUAL theirs and the last word must START with its
     * query word - the last word is a PREFIX match because the user may still be typing ("thue nha" finds "thuê nhà" and "thuê nhàn"), but the words must be adjacent ("thuê ở nhà" is not a hit).
     */
    fun findPhrase(words: List<WordBox>, query: String): List<IntRange> {
        val q = HistoryFilter.normalize(query).split(Regex("\\s+")).map { w -> w.filter { it.isLetterOrDigit() } }.filter { it.isNotEmpty() }
        if (q.isEmpty()) return emptyList()
        val idx = ArrayList<Int>(); val folded = ArrayList<String>()
        for (i in words.indices) { val f = fold(words[i].text); if (f.isNotEmpty()) { idx.add(i); folded.add(f) } }
        val out = ArrayList<IntRange>()
        var i = 0
        while (i + q.size <= folded.size) {
            var ok = true
            for (k in q.indices) {
                val w = folded[i + k]
                val hit = when {
                    q.size == 1 -> w.contains(q[0])
                    k == 0 -> w.endsWith(q[0])
                    k == q.size - 1 -> w.startsWith(q[k])
                    else -> w == q[k]
                }
                if (!hit) { ok = false; break }
            }
            if (ok) { out.add(idx[i]..idx[i + q.size - 1]); i += q.size } else i++
        }
        return out
    }

    /** Indices of the words whose box CENTRE lies inside [rect] (fractions l, t, r, b). */
    fun wordsInRect(words: List<WordBox>, rect: FloatArray): List<Int> {
        val l = minOf(rect[0], rect[2]); val r = maxOf(rect[0], rect[2]); val t = minOf(rect[1], rect[3]); val b = maxOf(rect[1], rect[3])
        val out = ArrayList<Int>()
        for (i in words.indices) {
            val bx = words[i].box
            val cx = (bx[0] + bx[2]) / 2f; val cy = (bx[1] + bx[3]) / 2f
            if (cx in l..r && cy in t..b) out.add(i)
        }
        return out
    }

    /** One box per OCR line for the chosen word indices: union of that line's chosen words, padded vertically by [LINE_PAD]. Sorted by line. */
    fun lineBoxes(words: List<WordBox>, chosen: Collection<Int>): List<FloatArray> {
        val byLine = java.util.TreeMap<Int, FloatArray>()
        for (i in chosen.toSortedSet()) {
            if (i !in words.indices) continue
            val w = words[i]
            val cur = byLine[w.line]
            if (cur == null) byLine[w.line] = w.box.copyOf()
            else { cur[0] = minOf(cur[0], w.box[0]); cur[1] = minOf(cur[1], w.box[1]); cur[2] = maxOf(cur[2], w.box[2]); cur[3] = maxOf(cur[3], w.box[3]) }
        }
        return byLine.values.map { b ->
            val pad = (b[3] - b[1]) * LINE_PAD
            floatArrayOf(b[0].coerceIn(0f, 1f), (b[1] - pad).coerceIn(0f, 1f), b[2].coerceIn(0f, 1f), (b[3] + pad).coerceIn(0f, 1f))
        }
    }

    // ---------------------------------------------------------------- writing

    private fun numbers(vararg v: Float): COSArray = COSArray().also { a -> v.forEach { a.add(COSFloat(it)) } }

    /**
     * @param marksByPage 0-based page -> marks (boxes are fractions of the displayed page; each mark has its own kind and colour).
     * @return the number of annotations written. Throws `IllegalStateException("encrypted")` for a protected file.
     */
    fun annotate(src: File, out: File, marksByPage: Map<Int, List<Mark>>, author: String = "DocScanner"): Int {
        val doc = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
        try {
            if (doc.isEncrypted) throw IllegalStateException("encrypted")
            val pages = doc.numberOfPages
            var written = 0
            for ((pageIndex, boxes) in marksByPage.toSortedMap()) {
                if (pageIndex !in 0 until pages || boxes.isEmpty()) continue
                val page = doc.getPage(pageIndex)
                val geo = PdfPageGeometry.of(page)
                val annots = (page.cosObject.getDictionaryObject("Annots") as? COSArray)
                    ?: COSArray().also { page.cosObject.setItem("Annots", it) }
                for (mark in boxes) {
                    val style = mark.style
                    val rgb = mark.rgb
                    val q = quadPoints(geo, mark.box)
                    val b = bounds(q)
                    val ap = doc.document.createCOSStream()
                    ap.setItem("Type", COSName.getPDFName("XObject"))
                    ap.setItem("Subtype", COSName.getPDFName("Form"))
                    ap.setItem("BBox", numbers(b[0], b[1], b[2], b[3]))
                    if (style == Style.HIGHLIGHT) {
                        val gs = COSDictionary().apply {
                            setItem("Type", COSName.getPDFName("ExtGState"))
                            setItem("BM", COSName.getPDFName("Multiply"))
                            setItem("ca", COSFloat(HIGHLIGHT_OPACITY))
                        }
                        val states = COSDictionary().apply { setItem("GS", gs) }
                        ap.setItem("Resources", COSDictionary().apply { setItem("ExtGState", states) })
                    } else {
                        ap.setItem("Resources", COSDictionary())
                    }
                    ap.createOutputStream(COSName.FLATE_DECODE).use { it.write(appearance(style, rgb, q).toByteArray(Charsets.US_ASCII)) }
                    val annot = COSDictionary().apply {
                        setItem("Type", COSName.getPDFName("Annot"))
                        setItem("Subtype", COSName.getPDFName(style.subtype))
                        setItem("Rect", numbers(b[0], b[1], b[2], b[3]))
                        setItem("QuadPoints", numbers(q[0], q[1], q[2], q[3], q[4], q[5], q[6], q[7]))
                        setItem("C", numbers(rgb[0], rgb[1], rgb[2]))
                        if (style == Style.HIGHLIGHT) setItem("CA", COSFloat(HIGHLIGHT_OPACITY))
                        setInt("F", 4)   // Print
                        setString("T", author)
                        setItem("AP", COSDictionary().apply { setItem("N", ap) })
                    }
                    annots.add(annot)
                    written++
                }
            }
            if (written == 0) throw IllegalArgumentException("no mark")
            PdfStructureOptimizer.save(doc, out)
            if (!PdfVerify.opensAsPdf(out, pages)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
            return written
        } finally {
            runCatching { doc.close() }
        }
    }
}
