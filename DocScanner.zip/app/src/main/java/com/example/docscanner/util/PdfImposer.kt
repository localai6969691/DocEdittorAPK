package com.example.docscanner.util

import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.LayerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.util.Matrix
import java.io.File

/**
 * "Imposition": several pages of a PDF on one sheet of paper - 2 or 4 per A4 to save paper, or in BOOKLET order so
 * that printing double-sided and folding the stack in half gives a small book. The pages are NOT rasterized: each
 * source page becomes a form XObject (vector text stays vector) drawn on the sheet by a transformation.
 *
 * The transformation for one page is `[fit scale + cell offset] x [inverse of PdfPageGeometry's display matrix]`:
 * the inverse takes the page's own coordinates to the page AS DISPLAYED (so a page with /Rotate 90 or an offset
 * CropBox lands upright), and the fit scales it into its cell keeping the proportions, centred. LayerUtility copies
 * the page's resources into the new document, but its own handling of /Rotate is not relied on: the form's /Matrix is
 * removed and the /BBox is set back to the CropBox, so the geometry is exactly the one checked with poppler on 8
 * rotation x CropBox combinations (tools/verify/imposition_check.py, which also holds Python copies of [cells], [fit]
 * and [bookletSlots] - change one, change the other).
 *
 * Booklet order: pages are padded with blanks to a multiple of 4; sheet k (from 0) carries, front left/right then
 * back left/right, `p-1-2k, 2k` and `2k+1, p-2-2k` (p = padded count). Print double-sided, flip on the SHORT edge.
 * Writes a NEW file; the input is only read.
 */
object PdfImposer {

    enum class Mode { TWO_UP, FOUR_UP, BOOKLET }

    private const val A4_WIDTH = 595.276f
    private const val A4_HEIGHT = 841.89f
    private const val MARGIN = 18f
    private const val GAP = 12f

    /** (width, height) of the output sheet: 2-up and booklet use A4 landscape, 4-up uses A4 portrait. */
    fun sheetSize(mode: Mode): Pair<Float, Float> =
        if (mode == Mode.FOUR_UP) Pair(A4_WIDTH, A4_HEIGHT) else Pair(A4_HEIGHT, A4_WIDTH)

    private fun gridColumns(mode: Mode): Int = 2
    private fun gridRows(mode: Mode): Int = if (mode == Mode.FOUR_UP) 2 else 1

    /** Cells in reading order (top row first, left to right) as `[x, y, width, height]`, origin bottom-left of the sheet. */
    fun cells(mode: Mode): List<FloatArray> {
        val (w, h) = sheetSize(mode)
        val cols = gridColumns(mode)
        val rows = gridRows(mode)
        val cw = (w - 2 * MARGIN - (cols - 1) * GAP) / cols
        val ch = (h - 2 * MARGIN - (rows - 1) * GAP) / rows
        val out = ArrayList<FloatArray>()
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                out.add(floatArrayOf(MARGIN + c * (cw + GAP), h - MARGIN - (r + 1) * ch - r * GAP, cw, ch))
            }
        }
        return out
    }

    /** `[scale, offsetX, offsetY]` that fits a page of displayed size [dw] x [dh] inside [cell], proportions kept, centred. */
    fun fit(dw: Float, dh: Float, cell: FloatArray): FloatArray {
        val s = minOf(cell[2] / dw, cell[3] / dh)
        return floatArrayOf(s, cell[0] + (cell[2] - dw * s) / 2f, cell[1] + (cell[3] - dh * s) / 2f)
    }

    /** Source page (0-based) for each slot in print order, `null` = blank. */
    fun bookletSlots(pageCount: Int): List<Int?> {
        val p = ((maxOf(pageCount, 1) + 3) / 4) * 4
        val slots = ArrayList<Int?>()
        for (k in 0 until p / 4) {
            for (i in intArrayOf(p - 1 - 2 * k, 2 * k, 2 * k + 1, p - 2 - 2 * k)) {
                slots.add(if (i < pageCount) i else null)
            }
        }
        return slots
    }

    /** @return number of sheets written. */
    fun impose(src: File, out: File, mode: Mode): Int {
        val srcDoc = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
        var dst: PDDocument? = null
        try {
            if (srcDoc.isEncrypted) throw IllegalStateException("encrypted")
            val pageCount = srcDoc.numberOfPages
            if (pageCount == 0) throw IllegalArgumentException("empty document")
            val cells = cells(mode)
            val perSheet = cells.size
            val slots: List<Int?> = if (mode == Mode.BOOKLET) bookletSlots(pageCount) else (0 until pageCount).toList()
            val sheets = (slots.size + perSheet - 1) / perSheet
            val (sheetW, sheetH) = sheetSize(mode)

            val doc = PDDocument()
            dst = doc
            val layer = LayerUtility(doc)
            for (s in 0 until sheets) {
                val sheetPage = PDPage(PDRectangle(sheetW, sheetH))
                doc.addPage(sheetPage)
                PDPageContentStream(doc, sheetPage).use { cs ->
                    for (i in 0 until perSheet) {
                        val index = slots.getOrNull(s * perSheet + i) ?: continue
                        val page = srcDoc.getPage(index)
                        val geo = PdfPageGeometry.of(page)
                        val f = fit(geo.displayWidth, geo.displayHeight, cells[i])
                        val form = layer.importPageAsForm(srcDoc, index)
                        form.getCOSObject().removeItem(COSName.MATRIX)   // our own, verified geometry replaces LayerUtility's
                        form.setBBox(page.cropBox)
                        val inv = geo.inverseMatrixValues()
                        val k = f[0]
                        cs.saveGraphicsState()
                        cs.transform(Matrix(k * inv[0], k * inv[1], k * inv[2], k * inv[3], k * inv[4] + f[1], k * inv[5] + f[2]))
                        cs.drawForm(form)
                        cs.restoreGraphicsState()
                        if (mode != Mode.BOOKLET) {
                            // a hairline around each page: white pages on white paper have no visible edge otherwise
                            cs.setStrokingColor(0.75f, 0.75f, 0.75f)
                            cs.setLineWidth(0.5f)
                            cs.addRect(f[1], f[2], geo.displayWidth * k, geo.displayHeight * k)
                            cs.stroke()
                        }
                    }
                }
            }
            PdfStructureOptimizer.save(doc, out)
            if (!PdfVerify.opensAsPdf(out, sheets)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
            return sheets
        } finally {
            runCatching { dst?.close() }
            runCatching { srcDoc.close() }
        }
    }
}
