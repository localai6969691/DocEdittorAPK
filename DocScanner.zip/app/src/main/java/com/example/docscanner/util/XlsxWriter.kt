package com.example.docscanner.util

import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Writes a minimal valid Excel workbook (.xlsx) with no library: a ZIP of [Content_Types].xml, the package and workbook
 * relationships, `xl/workbook.xml`, one `xl/worksheets/sheetN.xml` per sheet and a small `xl/styles.xml`. Text is stored as inline strings
 * (no shared-string table to keep in step), whole numbers as numbers. Checked with openpyxl and LibreOffice by `tools/verify/export_check.py`.
 *
 * Numbers: only plain integers (optional minus, no leading zero, at most 15 digits) become numeric cells. "1.234" in Vietnamese is
 * one thousand two hundred thirty-four but Excel would read 1.234, so anything with separators stays TEXT; and an ID such as
 * 0912345678 or a 12-digit CCCD must keep its leading zero / exact digits, which a number cannot.
 */
object XlsxWriter {

    class Sheet(val name: String, val rows: List<List<String>>)

    /** The whole-number value of [text], or null when it must stay text. */
    fun asNumber(text: String): Long? {
        val t = text.trim()
        if (!Regex("-?(0|[1-9][0-9]{0,14})").matches(t)) return null
        if (t == "-0") return null
        return t.toLong()
    }

    /** 0 -> A, 25 -> Z, 26 -> AA ... */
    fun columnName(index: Int): String {
        var n = index
        val sb = StringBuilder()
        do {
            sb.insert(0, ('A'.code + n % 26).toChar())
            n = n / 26 - 1
        } while (n >= 0)
        return sb.toString()
    }

    /** A legal Excel sheet name (1-31 characters, none of `[ ] : * ? / \`, not starting or ending with an apostrophe) that is not in [taken] (compared ignoring case). */
    fun safeSheetName(name: String, taken: Set<String>): String {
        // blanks and apostrophes are both removed from the two ends, in one pass: "'  Z" must not leave leading blanks behind
        fun edges(t: String) = t.trim { it.isWhitespace() || it == '\'' }
        var base = edges(name.replace(Regex("[\\[\\]:*?/\\\\]"), " ")).ifEmpty { "Sheet" }
        if (base.length > 31) base = edges(base.substring(0, 31)).ifEmpty { "Sheet" }
        val takenLower = taken.map { it.lowercase() }.toSet()
        var candidate = base
        var n = 2
        while (candidate.lowercase() in takenLower) {
            val suffix = " ($n)"
            candidate = base.take(31 - suffix.length).trimEnd() + suffix
            n++
        }
        return candidate
    }

    /** Escapes text for XML and drops the characters XML 1.0 forbids. */
    fun escape(text: String): String = DocxWriter.escape(text)

    fun sheetXml(rows: List<List<String>>): String {
        val width = rows.maxOfOrNull { it.size } ?: 0
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>")
        sb.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">")
        if (width > 0) {
            sb.append("<cols>")
            for (c in 0 until width) {
                val longest = rows.maxOf { r -> if (c < r.size) r[c].length else 0 }
                val w = longest.coerceIn(8, 60) + 2
                sb.append("<col min=\"${c + 1}\" max=\"${c + 1}\" width=\"$w\" customWidth=\"1\"/>")
            }
            sb.append("</cols>")
        }
        sb.append("<sheetData>")
        for ((r, row) in rows.withIndex()) {
            sb.append("<row r=\"${r + 1}\">")
            for ((c, text) in row.withIndex()) {
                if (text.isEmpty()) continue
                val ref = columnName(c) + (r + 1)
                val number = asNumber(text)
                if (number != null) {
                    sb.append("<c r=\"$ref\"><v>$number</v></c>")
                } else {
                    sb.append("<c r=\"$ref\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(escape(text)).append("</t></is></c>")
                }
            }
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")
        return sb.toString()
    }

    private const val XML_HEAD = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
    private const val NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

    fun write(sheets: List<Sheet>, out: File) {
        val list = if (sheets.isEmpty()) listOf(Sheet("Sheet1", emptyList())) else sheets
        val names = ArrayList<String>()
        for (s in list) names.add(safeSheetName(s.name, names.toSet()))
        ZipOutputStream(FileOutputStream(out)).use { zip ->
            fun part(name: String, content: String) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(content.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
            val overrides = list.indices.joinToString("") {
                "<Override PartName=\"/xl/worksheets/sheet${it + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>"
            }
            part("[Content_Types].xml", XML_HEAD + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                overrides + "</Types>")
            part("_rels/.rels", XML_HEAD + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"$NS_REL/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>")
            part("xl/workbook.xml", XML_HEAD + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"$NS_REL\"><sheets>" +
                names.withIndex().joinToString("") { (i, n) -> "<sheet name=\"${escape(n)}\" sheetId=\"${i + 1}\" r:id=\"rId${i + 1}\"/>" } + "</sheets></workbook>")
            part("xl/_rels/workbook.xml.rels", XML_HEAD + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                list.indices.joinToString("") { "<Relationship Id=\"rId${it + 1}\" Type=\"$NS_REL/worksheet\" Target=\"worksheets/sheet${it + 1}.xml\"/>" } +
                "<Relationship Id=\"rId${list.size + 1}\" Type=\"$NS_REL/styles\" Target=\"styles.xml\"/></Relationships>")
            part("xl/styles.xml", XML_HEAD + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                "<fonts count=\"1\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
                "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
                "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/></cellXfs></styleSheet>")
            for ((i, s) in list.withIndex()) part("xl/worksheets/sheet${i + 1}.xml", sheetXml(s.rows))
        }
    }
}
