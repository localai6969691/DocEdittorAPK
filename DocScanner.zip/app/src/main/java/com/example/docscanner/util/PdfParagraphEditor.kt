package com.example.docscanner.util

import com.tom_roush.pdfbox.contentstream.operator.Operator
import com.tom_roush.pdfbox.cos.COSFloat
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSString
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdfwriter.ContentStreamWriter
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.common.PDStream
import java.io.File
import kotlin.math.abs

/**
 * Edit a whole PARAGRAPH of already-existing text in a PDF the way WPS / Acrobat do (phien 27, TECHNICAL_DOCS.md 4.89): the text lives in a text BOX, what is typed wraps inside the
 * box's width, the box does not push other boxes and never flows to another page. [PdfTextEditor] only swaps a short run inside ONE line; this one re-wraps the lines of a block.
 *
 * ## What is a block (found, never guessed at)
 * Built on the same traversal as [PdfTextEditor] ([PdfTextEditor.scanPage]): consecutive text-showing operators that
 * - use the same font object and size, with Tc = 0, Tw = 0 and Tz = 100 (no justification tricks),
 * - are drawn upright and unrotated (text matrix x CTM has no skew / turn),
 * - start at the same left edge (within 0.8 pt) and sit on baselines that go DOWN by the same step (within 8 %), each step between 0.9 and 2.5 font sizes,
 * - each show a non-blank text.
 * At least two lines make a block; a single line stays with [PdfTextEditor]. The block's width is its longest line, i.e. the box the text was set in.
 *
 * ## How it is rewritten
 * The new text is wrapped greedily with the font's own advance widths (words kept whole, an explicit line feed forces a break; a word wider than the box stands alone on its line).
 * Line k of the new text replaces the string of line k of the block; surplus old lines become empty strings; extra lines are added after the block as `0 -step Td (line) Tj`, followed
 * by one `0 n*step Td` that gives the text line matrix back, so whatever follows is still where it was.
 *
 * ## What it refuses rather than guesses at ([Result])
 * a glyph the (subset) font does not hold ([Result.MissingGlyphs] / [Result.UnsupportedFont]: same encoder as [PdfTextEditor]); extra lines that would run into other text on the
 * page ([Result.Overlaps]) or off the bottom of the page ([Result.OffPage]). WPS lets the box overlap; here the person is told instead of getting an unreadable page.
 */
object PdfParagraphEditor {

    /** One block of lines. [firstIndex] = ordinal of its first line among ALL text-showing operators of the page (the numbering of [PdfTextEditor.TextChunk.index]). */
    class Block(val firstIndex: Int, val lineCount: Int, val text: String, val fontSize: Float, val widthPt: Float, val placed: FloatArray?)

    sealed class Result {
        object Success : Result()
        object NotFound : Result()
        object UnsupportedFont : Result()
        object Overlaps : Result()
        object OffPage : Result()
        object TooManyLines : Result()
        data class MissingGlyphs(val chars: String) : Result()
    }

    class Edit(val page: Int, val firstIndex: Int, val newText: String)

    private const val MAX_LINES = 400

    private fun eligible(op: PdfTextEditor.ScannedOp): Boolean {
        val m = op.matrix
        return op.font != null && op.fontSize > 0f && op.tc == 0f && op.tw == 0f && op.tz == 100f && op.text.isNotBlank() && op.box != null &&
            abs(m[1]) < 1e-3f && abs(m[2]) < 1e-3f && m[0] > 0f && m[3] > 0f
    }

    /** A blank run that only continues the previous line (typically one trailing space written by the producer as its own operator) does not end a block. */
    private fun skipTrailingBlanks(ops: List<PdfTextEditor.ScannedOp>, from: Int): Int {
        var k = from
        while (k + 1 < ops.size && ops[k + 1].text.isNotEmpty() && ops[k + 1].text.isBlank() && abs(ops[k + 1].originY - ops[from].originY) <= 0.5f && ops[k + 1].originX >= ops[from].originX) k++
        return k
    }

    /** The blocks, in order: each is the list of operator ordinals of its LINES (trailing blanks of a line are left out, they stay as they are). */
    private fun detect(ops: List<PdfTextEditor.ScannedOp>): List<List<Int>> {
        val out = ArrayList<List<Int>>()
        var i = 0
        while (i < ops.size) {
            if (!eligible(ops[i])) { i++; continue }
            val lines = arrayListOf(i)
            var step = -1f
            var cursor = skipTrailingBlanks(ops, i)
            while (cursor + 1 < ops.size && eligible(ops[cursor + 1])) {
                val a = ops[lines.last()]; val b = ops[cursor + 1]
                val dy = a.originY - b.originY
                val ok = a.font === b.font && abs(a.fontSize - b.fontSize) < 0.01f && abs(a.originX - b.originX) <= 0.8f &&
                    dy >= 0.9f * a.fontSize && dy <= 2.5f * a.fontSize && (step < 0f || abs(dy - step) <= 0.08f * step + 0.3f)
                if (!ok) break
                if (step < 0f) step = dy
                lines.add(cursor + 1)
                cursor = skipTrailingBlanks(ops, cursor + 1)
            }
            if (lines.size > 1) out.add(lines)
            i = cursor + 1
        }
        return out
    }

    private fun widthOf(ops: List<PdfTextEditor.ScannedOp>, lines: List<Int>): Float {
        var right = 0f
        val x0 = ops[lines.first()].originX
        for (k in lines) right = maxOf(right, ops[k].box!![2] - x0)
        return right
    }

    /** The blocks of page [pageNumber] (1-based). */
    fun blocks(document: PDDocument, pageNumber: Int): List<Block> {
        val scan = PdfTextEditor.scanPage(document, pageNumber)
        val geo = PdfPageGeometry.of(document.getPage(pageNumber - 1))
        val inv = geo.inverseMatrixValues()
        val w = geo.displayWidth
        val h = geo.displayHeight
        return detect(scan.ops).map { r ->
            var llx = Float.MAX_VALUE; var lly = Float.MAX_VALUE; var urx = -Float.MAX_VALUE; var ury = -Float.MAX_VALUE
            for (k in r) { val b = scan.ops[k].box!!; llx = minOf(llx, b[0]); lly = minOf(lly, b[1]); urx = maxOf(urx, b[2]); ury = maxOf(ury, b[3]) }
            var placed: FloatArray? = null
            if (w > 0f && h > 0f) {
                var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
                val us = floatArrayOf(llx, urx, urx, llx); val vs = floatArrayOf(lly, lly, ury, ury)
                for (k in 0 until 4) {
                    val fx = (inv[0] * us[k] + inv[2] * vs[k] + inv[4]) / w
                    val fy = 1f - (inv[1] * us[k] + inv[3] * vs[k] + inv[5]) / h
                    minX = minOf(minX, fx); maxX = maxOf(maxX, fx); minY = minOf(minY, fy); maxY = maxOf(maxY, fy)
                }
                if (!(maxX <= 0f || maxY <= 0f || minX >= 1f || minY >= 1f)) placed = floatArrayOf(minX.coerceIn(0f, 1f), minY.coerceIn(0f, 1f), maxX.coerceIn(0f, 1f), maxY.coerceIn(0f, 1f))
            }
            Block(r.first(), r.size, r.joinToString(" ") { scan.ops[it].text.trim() }, scan.ops[r.first()].fontSize, widthOf(scan.ops, r), placed)
        }
    }

    /** The block under a tap at (x, y) (fractions of the displayed page from the top-left), the smallest if several. */
    fun pick(blocks: List<Block>, x: Float, y: Float, slop: Float = 0.006f): Block? =
        blocks.filter { b -> b.placed?.let { x >= it[0] - slop && x <= it[2] + slop && y >= it[1] - slop && y <= it[3] + slop } == true }
            .minByOrNull { b -> b.placed!!.let { (it[2] - it[0]) * (it[3] - it[1]) } }

    /** Greedy wrap of [text] into lines no wider than [maxWidth] (text-space units); null when a character cannot be encoded (then [missing] says which). */
    private fun wrap(font: com.tom_roush.pdfbox.pdmodel.font.PDFont, fontSize: Float, text: String, maxWidth: Float, missing: StringBuilder): List<String>? {
        fun measure(s: String): Float? {
            val e = PdfTextEditor.encodeText(font, s)
            val bytes = e.bytes
            if (bytes == null) { if (e.noMapping) missing.append('\u0000') else missing.append(e.missing); return null }
            return PdfTextEditor.decodeAndMeasure(font, bytes, fontSize, 0f, 0f).second
        }
        val space = measure(" ") ?: return null
        val lines = ArrayList<String>()
        for (paragraph in text.split('\n')) {
            var current = StringBuilder()
            var currentWidth = 0f
            for (word in paragraph.split(' ').filter { it.isNotEmpty() }) {
                val ww = measure(word) ?: return null
                if (current.isEmpty()) { current.append(word); currentWidth = ww }
                else if (currentWidth + space + ww <= maxWidth) { current.append(' ').append(word); currentWidth += space + ww }
                else { lines.add(current.toString()); current = StringBuilder(word); currentWidth = ww }
            }
            lines.add(current.toString())
        }
        return lines
    }

    private fun stringToken(font: com.tom_roush.pdfbox.pdmodel.font.PDFont, line: String): COSString? {
        if (line.isEmpty()) return COSString(ByteArray(0))
        val bytes = PdfTextEditor.encodeText(font, line).bytes ?: return null
        return COSString(bytes)
    }

    /** Re-wraps the block starting at operator [firstIndex] of [pageNumber] with [newText]. The block is found again with [detect]: [firstIndex] must be a block's first line. */
    fun reflow(document: PDDocument, pageNumber: Int, firstIndex: Int, newText: String): Result {
        val scan = PdfTextEditor.scanPage(document, pageNumber)
        val range = detect(scan.ops).firstOrNull { it.first() == firstIndex } ?: return Result.NotFound
        val ops = scan.ops
        val first = ops[range.first()]
        val last = ops[range.last()]
        val font = first.font ?: return Result.UnsupportedFont
        val stepUser = (first.originY - last.originY) / (range.size - 1)
        val scaleX = first.matrix[0]
        val scaleY = first.matrix[3]
        val missing = StringBuilder()
        val lines = wrap(font, first.fontSize, newText.replace("\r\n", "\n"), widthOf(ops, range) / scaleX + 0.02f, missing)
        if (lines == null) {
            return if (missing.contains('\u0000')) Result.UnsupportedFont else Result.MissingGlyphs(missing.toString())
        }
        if (lines.size > MAX_LINES) return Result.TooManyLines
        val existing = range.size
        val extra = maxOf(0, lines.size - existing)
        if (extra > 0) {
            val left = first.originX
            val right = first.originX + widthOf(ops, range)
            val top = last.originY - extra * stepUser - 0.25f * first.fontSize * scaleY
            val bottom = last.originY - 0.25f * first.fontSize * scaleY
            val box = document.getPage(pageNumber - 1).cropBox
            if (top < box.lowerLeftY + 4f) return Result.OffPage
            for ((k, op) in ops.withIndex()) {
                if (k in range) continue
                val b = op.box ?: continue
                if (b[0] < right && b[2] > left && b[1] < bottom && b[3] > top) return Result.Overlaps
            }
        }
        // encode every line first: nothing is written if one cannot be
        val tokens = ArrayList<COSString>()
        for (line in lines) tokens.add(stringToken(font, line) ?: return Result.MissingGlyphs(line))
        val list = scan.tokens
        // the extra lines go in first (they sit AFTER the last line's operator, so the earlier token numbers stay valid)
        if (extra > 0) {
            val stepText = stepUser / scaleY
            val insert = ArrayList<Any>()
            for (k in existing until lines.size) {
                insert.add(COSFloat(0f)); insert.add(COSFloat(-stepText)); insert.add(Operator.getOperator("Td"))
                insert.add(tokens[k]); insert.add(Operator.getOperator("Tj"))
            }
            insert.add(COSFloat(0f)); insert.add(COSFloat(extra * stepText)); insert.add(Operator.getOperator("Td"))
            list.addAll(last.opTokenIndex + 1, insert)
        }
        for (k in 0 until existing) {
            val op = ops[range[k]]
            val text = if (k < lines.size) tokens[k] else COSString(ByteArray(0))
            list[op.opTokenIndex - 1] = text
            if (op.opName == "TJ") list[op.opTokenIndex] = Operator.getOperator("Tj")
        }
        val stream = PDStream(document)
        stream.createOutputStream(COSName.FLATE_DECODE).use { ContentStreamWriter(it).writeTokens(list) }
        document.getPage(pageNumber - 1).setContents(stream)
        return Result.Success
    }

    /** Tries [newText] on a throw-away copy of [file] (nothing is written): the same check the saved copy will pass. */
    fun trial(file: File, page: Int, firstIndex: Int, newText: String): Result {
        val doc = try { openForEdit(file) } catch (e: Exception) { return Result.NotFound }
        try {
            if (page !in 1..doc.numberOfPages) return Result.NotFound
            return reflow(doc, page, firstIndex, newText)
        } catch (e: Exception) {
            return Result.NotFound
        } finally {
            runCatching { doc.close() }
        }
    }

    private fun openForEdit(file: File): PDDocument =
        PDDocument.load(file, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(file.parentFile))

    /** The blocks of page [page] of [file]; an unreadable file or page gives an empty list. */
    fun blocks(file: File, page: Int): List<Block> {
        val doc = try { openForEdit(file) } catch (e: Exception) { return emptyList() }
        try {
            if (page !in 1..doc.numberOfPages) return emptyList()
            return blocks(doc, page)
        } catch (e: Exception) {
            return emptyList()
        } finally {
            runCatching { doc.close() }
        }
    }

    /** Names the first edit that cannot be made instead of saving a copy that silently lacks it; same rule as [PdfTextEditor.applyAll]. Later blocks first, so adding lines never shifts a block still to do. */
    fun applyAll(src: File, out: File, edits: List<Edit>) {
        val doc = openForEdit(src)
        try {
            val pages = doc.numberOfPages
            for (e in edits.sortedWith(compareBy({ it.page }, { -it.firstIndex }))) {
                if (e.page !in 1..pages) throw IllegalStateException("page ${e.page} not found")
                val r = reflow(doc, e.page, e.firstIndex, e.newText)
                if (r != Result.Success) throw IllegalStateException("paragraph edit refused on page ${e.page}: $r")
            }
            doc.save(out)
            if (!PdfVerify.opensAsPdf(out, pages)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
        } finally {
            runCatching { doc.close() }
        }
    }
}
