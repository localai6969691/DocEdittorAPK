package com.example.docscanner.util

import com.tom_roush.pdfbox.contentstream.operator.Operator
import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSBase
import com.tom_roush.pdfbox.cos.COSFloat
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSString
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdfwriter.ContentStreamWriter
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.common.PDStream
import com.tom_roush.pdfbox.pdmodel.font.PDFont
import com.tom_roush.pdfbox.pdmodel.font.PDType0Font
import java.io.File
import java.io.InputStream
import kotlin.math.abs

/**
 * Edit a whole PARAGRAPH of already-existing text in a PDF the way WPS / Acrobat do (phien 27, TECHNICAL_DOCS.md 4.89 / 4.90): the text lives in a text BOX, what is typed wraps inside the
 * box's width, the box does not push other boxes and never flows to another page. [PdfTextEditor] only swaps a short run inside ONE line; this one re-wraps the lines of a block.
 *
 * ## What is a block (found, never guessed at)
 * Built on the same traversal as [PdfTextEditor] ([PdfTextEditor.scanPage]): consecutive text-showing operators that
 * - use the same font object and size with Tz = 100, drawn upright and unrotated (text matrix x CTM has no skew / turn), each showing a non-blank text,
 * - sit on baselines that go DOWN by the same step (within 8 %), each step between 0.9 and 2.5 font sizes,
 * - share ONE alignment: the same left edge (left / justified), the same right edge (right) or the same centre (centred), all within 0.8 pt. A pair of lines that fits several alignments
 *   keeps all of them until a later line decides; left wins a tie.
 * At least two lines make a block; a single line stays with [PdfTextEditor]. A block is JUSTIFIED when, with a common left edge, at least one line that is not the last is drawn wider than its
 * own glyphs (word spacing, char spacing or TJ gaps) and all of those lines end at the same right edge. The block's width is its widest line, i.e. the box the text was set in.
 * A trailing blank written by the producer as its own operator does not end a line. Columns are separate blocks as long as the page lists one column after the other.
 *
 * ## How it is rewritten
 * The new text is wrapped greedily with the glyph advance widths of the fonts it is drawn with (words kept whole, an explicit line feed forces a break and ends a paragraph, a word wider than the
 * box stands alone on its line). Line k of the new text replaces the string of line k; surplus old lines become empty strings; extra lines are added after the block as `dx -step Td (line) Tj`, with
 * one closing `Td` that gives the text line matrix back, so whatever follows is still where it was. Centred / right-aligned lines are moved by a `Td` that is undone right after the line; a
 * justified line (every line but the last of each paragraph) is a TJ array with the missing width shared out as a gap after every space - this works for every font encoding, unlike `Tw`.
 *
 * ## Letters the font does not have (4.90)
 * The original font is used whenever its program really draws the glyph ([PdfTextEditor.glyphDrawable]). A word it cannot draw is written in a FALLBACK font (the caller's list, embedded as a subset)
 * in the same size: `/Fallback size Tf (word) Tj /Original size Tf`; the result is then [Result.Substituted] so the person is told. With no fallback, or when no font has the letter, the edit is
 * refused ([Result.MissingGlyphs]). This is the tiered approach of Acrobat / pdf-edit-mcp (exact, then a metric-compatible font for the new glyphs only).
 *
 * ## What it refuses rather than guesses at ([Result])
 * a letter no font has / a font that cannot be used; extra lines that would run into other text on the page ([Result.Overlaps], unless the caller says to keep them anyway) or off the bottom of the page
 * ([Result.OffPage]).
 */
/** Gives a fallback font file (TrueType) each time it is asked, or null when it is not there. */
typealias ParagraphFontSource = () -> InputStream?

object PdfParagraphEditor {

    enum class Align { LEFT, CENTER, RIGHT, JUSTIFY }

    /** One block of lines. [firstIndex] = ordinal of its first line among ALL text-showing operators of the page (the numbering of [PdfTextEditor.TextChunk.index]). */
    class Block(val firstIndex: Int, val lineCount: Int, val text: String, val fontSize: Float, val widthPt: Float, val placed: FloatArray?, val align: Align = Align.LEFT)

    sealed class Result {
        object Success : Result()
        /** done, but these letters are not in the document's font and were drawn in a fallback font */
        data class Substituted(val chars: String) : Result()
        object NotFound : Result()
        object UnsupportedFont : Result()
        object Overlaps : Result()
        object OffPage : Result()
        object TooManyLines : Result()
        data class MissingGlyphs(val chars: String) : Result()
    }

    fun isDone(r: Result): Boolean = r is Result.Success || r is Result.Substituted

    class Edit(val page: Int, val firstIndex: Int, val newText: String, val allowOverlap: Boolean = false)

    private const val MAX_LINES = 400
    private const val EDGE = 0.8f

    private class Found(val lines: List<Int>, val align: Align)

    private fun eligible(op: PdfTextEditor.ScannedOp): Boolean {
        val m = op.matrix
        if (op.font == null || op.fontName == null || op.box == null) return false
        if (op.fontSize <= 0f || op.tz != 100f || op.text.isBlank()) return false
        if (abs(m[1]) >= 1e-3f || abs(m[2]) >= 1e-3f) return false
        return m[0] > 0f && m[3] > 0f
    }

    /** A blank run that only continues the previous line (typically one trailing space written by the producer as its own operator) does not end a block. */
    private fun skipTrailingBlanks(ops: List<PdfTextEditor.ScannedOp>, from: Int): Int {
        var k = from
        while (k + 1 < ops.size && ops[k + 1].text.isNotEmpty() && ops[k + 1].text.isBlank() && abs(ops[k + 1].originY - ops[from].originY) <= 0.5f && ops[k + 1].originX >= ops[from].originX) k++
        return k
    }

    private fun left(op: PdfTextEditor.ScannedOp) = op.box!![0]
    private fun right(op: PdfTextEditor.ScannedOp) = op.box!![2]
    private fun centre(op: PdfTextEditor.ScannedOp) = (op.box!![0] + op.box!![2]) / 2f

    private fun fits(a: PdfTextEditor.ScannedOp, b: PdfTextEditor.ScannedOp): Set<Align> {
        val out = HashSet<Align>()
        if (abs(left(a) - left(b)) <= EDGE) out.add(Align.LEFT)
        if (abs(centre(a) - centre(b)) <= EDGE) out.add(Align.CENTER)
        if (abs(right(a) - right(b)) <= EDGE) out.add(Align.RIGHT)
        return out
    }

    /** The glyphs' own width of the line's text in page units, or null when it cannot be worked out. */
    private fun naturalWidth(op: PdfTextEditor.ScannedOp): Float? {
        val font = op.font ?: return null
        val bytes = PdfTextEditor.encodeText(font, op.text).bytes ?: return null
        return PdfTextEditor.decodeAndMeasure(font, bytes, op.fontSize, 0f, 0f).second * op.matrix[0]
    }

    private fun isJustified(ops: List<PdfTextEditor.ScannedOp>, lines: List<Int>): Boolean {
        if (lines.size < 2) return false
        val body = lines.dropLast(1)
        val edge = body.maxOf { right(ops[it]) }
        if (body.any { abs(right(ops[it]) - edge) > EDGE }) return false
        return body.any { k ->
            val natural = naturalWidth(ops[k]) ?: return@any false
            abs((right(ops[k]) - left(ops[k])) - natural) > 0.3f
        }
    }

    /** The blocks, in order: each is the list of operator ordinals of its LINES (trailing blanks of a line are left out, they stay as they are) and its alignment. */
    private fun detect(ops: List<PdfTextEditor.ScannedOp>): List<Found> {
        val out = ArrayList<Found>()
        var i = 0
        while (i < ops.size) {
            if (!eligible(ops[i])) { i++; continue }
            val lines = arrayListOf(i)
            var step = -1f
            var candidates: Set<Align> = setOf(Align.LEFT, Align.CENTER, Align.RIGHT)
            var cursor = skipTrailingBlanks(ops, i)
            while (cursor + 1 < ops.size && eligible(ops[cursor + 1])) {
                val a = ops[lines.last()]; val b = ops[cursor + 1]
                val dy = a.originY - b.originY
                val shared = candidates.intersect(fits(a, b))
                val ok = a.font === b.font && abs(a.fontSize - b.fontSize) < 0.01f && shared.isNotEmpty() &&
                    dy >= 0.9f * a.fontSize && dy <= 2.5f * a.fontSize && (step < 0f || abs(dy - step) <= 0.08f * step + 0.3f)
                if (!ok) break
                candidates = shared
                if (step < 0f) step = dy
                lines.add(cursor + 1)
                cursor = skipTrailingBlanks(ops, cursor + 1)
            }
            if (lines.size > 1) {
                val align = when {
                    Align.LEFT in candidates -> if (isJustified(ops, lines)) Align.JUSTIFY else Align.LEFT
                    Align.CENTER in candidates -> Align.CENTER
                    else -> Align.RIGHT
                }
                out.add(Found(lines, align))
            }
            i = cursor + 1
        }
        return out
    }

    private fun widthOf(ops: List<PdfTextEditor.ScannedOp>, lines: List<Int>): Float = lines.maxOf { right(ops[it]) - left(ops[it]) }

    /** The blocks of page [pageNumber] (1-based). */
    fun blocks(document: PDDocument, pageNumber: Int): List<Block> {
        val scan = PdfTextEditor.scanPage(document, pageNumber)
        val geo = PdfPageGeometry.of(document.getPage(pageNumber - 1))
        val inv = geo.inverseMatrixValues()
        val w = geo.displayWidth
        val h = geo.displayHeight
        return detect(scan.ops).map { f ->
            val r = f.lines
            var llx = Float.MAX_VALUE; var lly = Float.MAX_VALUE; var urx = -Float.MAX_VALUE; var ury = -Float.MAX_VALUE
            for (k in r) { val b = scan.ops[k].box!!; llx = minOf(llx, b[0]); lly = minOf(lly, b[1]); urx = maxOf(urx, b[2]); ury = maxOf(ury, b[3]) }
            var placed: FloatArray? = null
            if (w > 0f && h > 0f) {
                var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
                val us = floatArrayOf(llx, urx, urx, llx); val vs = floatArrayOf(lly, lly, ury, ury)
                for (k in 0 until 4) {
                    val fx = (inv[0] * us[k] + inv[2] * vs[k] + inv[4]) / w
                    val fy = 1f - (inv[1] * us[k] + inv[3] * vs[k] + inv[5]) / h
                    minX = minOf(minX, fx); maxX = maxOf(maxX, fx); minY = minOf(minY, fy); maxY = maxOf(maxY, fy)
                }
                if (!(maxX <= 0f || maxY <= 0f || minX >= 1f || minY >= 1f)) placed = floatArrayOf(minX.coerceIn(0f, 1f), minY.coerceIn(0f, 1f), maxX.coerceIn(0f, 1f), maxY.coerceIn(0f, 1f))
            }
            Block(r.first(), r.size, r.joinToString(" ") { scan.ops[it].text.trim() }, scan.ops[r.first()].fontSize, widthOf(scan.ops, r), placed, f.align)
        }
    }

    /** The block under a tap at (x, y) (fractions of the displayed page from the top-left), the smallest if several. */
    fun pick(blocks: List<Block>, x: Float, y: Float, slop: Float = 0.006f): Block? =
        blocks.filter { b -> b.placed?.let { x >= it[0] - slop && x <= it[2] + slop && y >= it[1] - slop && y <= it[3] + slop } == true }
            .minByOrNull { b -> b.placed!!.let { (it[2] - it[0]) * (it[3] - it[1]) } }

    // ------------------------------------------------------------------ fonts, measuring, wrapping

    /** The fonts a line may be drawn with: index 0 = the document's own, then the fallbacks, loaded only when a letter needs them. */
    private class Fonts(val document: PDDocument, val original: PDFont, val size: Float, val sources: List<ParagraphFontSource>, val sink: MutableList<PDType0Font>?) {
        private val loaded = arrayOfNulls<PDType0Font>(sources.size)
        private val tried = BooleanArray(sources.size)
        fun count(): Int = 1 + sources.size

        fun fallback(index: Int): PDType0Font? {
            val k = index - 1
            if (!tried[k]) {
                tried[k] = true
                loaded[k] = runCatching { sources[k]()?.use { PDType0Font.load(document, it, true) } }.getOrNull()
                loaded[k]?.let { sink?.add(it) }
            }
            return loaded[k]
        }

        fun encode(index: Int, text: String): ByteArray? {
            if (index == 0) return PdfTextEditor.encodeText(original, text).bytes
            val f = fallback(index) ?: return null
            val bytes = runCatching { f.encode(text) }.getOrNull() ?: return null
            // PDFBox's content-stream writer adds every drawn code point to the subset itself; the tokens here are written directly, so it is done here
            var k = 0
            while (k < text.length) { val cp = text.codePointAt(k); f.addToSubset(cp); k += Character.charCount(cp) }
            return bytes
        }

        /** width in text-space units (font size applied) */
        fun width(index: Int, text: String, bytes: ByteArray): Float =
            if (index == 0) PdfTextEditor.decodeAndMeasure(original, bytes, size, 0f, 0f).second
            else (fallback(index)?.let { runCatching { it.getStringWidth(text) }.getOrDefault(0f) } ?: 0f) / 1000f * size
    }

    private class Run(val font: Int, val text: String, val width: Float)
    private class Word(val runs: List<Run>, val width: Float)

    /** The runs a word is drawn in: the first font that can draw ALL of it, else letter by letter; null when some letter has no font. */
    private fun runsOf(fonts: Fonts, word: String, missing: StringBuilder): List<Run>? {
        for (i in 0 until fonts.count()) {
            val bytes = fonts.encode(i, word) ?: continue
            return listOf(Run(i, word, fonts.width(i, word, bytes)))
        }
        val runs = ArrayList<Run>()
        var k = 0
        while (k < word.length) {
            val cp = word.codePointAt(k); val ch = String(Character.toChars(cp)); k += Character.charCount(cp)
            var done = false
            for (i in 0 until fonts.count()) {
                val bytes = fonts.encode(i, ch) ?: continue
                val last = runs.lastOrNull()
                if (last != null && last.font == i) { runs[runs.size - 1] = Run(i, last.text + ch, last.width + fonts.width(i, ch, bytes)) }
                else runs.add(Run(i, ch, fonts.width(i, ch, bytes)))
                done = true
                break
            }
            if (!done) { if (!missing.contains(ch)) missing.append(ch) }
        }
        return if (missing.isEmpty()) runs else null
    }

    /** One line to draw: its runs in order (adjacent runs of one font merged), its natural width and the number of spaces in it. */
    private class Line(val runs: List<Run>, val width: Float, val spaces: Int, val endsParagraph: Boolean)

    private fun wrap(fonts: Fonts, text: String, maxWidth: Float, missing: StringBuilder): List<Line>? {
        var spaceFont = -1
        var spaceWidth = 0f
        for (i in 0 until fonts.count()) { val b = fonts.encode(i, " "); if (b != null) { spaceFont = i; spaceWidth = fonts.width(i, " ", b); break } }
        if (spaceFont < 0) { missing.append(' '); return null }
        val lines = ArrayList<Line>()
        fun make(words: List<Word>, ends: Boolean): Line {
            val runs = ArrayList<Run>()
            fun add(r: Run) {
                val last = runs.lastOrNull()
                if (last != null && last.font == r.font) runs[runs.size - 1] = Run(r.font, last.text + r.text, last.width + r.width) else runs.add(r)
            }
            for ((i, w) in words.withIndex()) {
                if (i > 0) add(Run(spaceFont, " ", spaceWidth))
                for (r in w.runs) add(r)
            }
            val width = words.sumOf { it.width.toDouble() }.toFloat() + spaceWidth * maxOf(0, words.size - 1)
            return Line(runs, width, maxOf(0, words.size - 1), ends)
        }
        for (paragraph in text.split('\n')) {
            val words = ArrayList<Word>()
            var current = ArrayList<Word>()
            var currentWidth = 0f
            for (raw in paragraph.split(' ').filter { it.isNotEmpty() }) {
                val runs = runsOf(fonts, raw, missing) ?: return null
                val w = Word(runs, runs.sumOf { it.width.toDouble() }.toFloat())
                if (current.isEmpty()) { current.add(w); currentWidth = w.width }
                else if (currentWidth + spaceWidth + w.width <= maxWidth) { current.add(w); currentWidth += spaceWidth + w.width }
                else { lines.add(make(current, false)); current = arrayListOf(w); currentWidth = w.width }
            }
            words.addAll(current)
            lines.add(make(current, true))
        }
        return lines
    }

    // ------------------------------------------------------------------ writing

    private class Writer(val document: PDDocument, val pageNumber: Int, val fonts: Fonts) {
        private val names = HashMap<Int, COSName>()
        val used = StringBuilder()
        fun nameOf(index: Int, original: COSName): COSName {
            if (index == 0) return original
            return names.getOrPut(index) { document.getPage(pageNumber - 1).resources.add(fonts.fallback(index)!!) }
        }
    }

    private fun tokenNumbers(vararg v: Float): List<Any> = v.map { COSFloat(it) }

    /** The tokens that draw [line] (everything between "move to the line" and "back to the next one"); [extraPerSpace] (text units) > 0 justifies it with TJ gaps. */
    private fun showTokens(w: Writer, line: Line?, op: PdfTextEditor.ScannedOp, extraPerSpace: Float): List<Any> {
        val out = ArrayList<Any>()
        if (op.tw != 0f) { out.add(COSFloat(0f)); out.add(Operator.getOperator("Tw")) }
        if (op.tc != 0f) { out.add(COSFloat(0f)); out.add(Operator.getOperator("Tc")) }
        if (line == null || line.runs.isEmpty()) {
            out.add(COSString(ByteArray(0))); out.add(Operator.getOperator("Tj"))
        } else {
            val switched = line.runs.any { it.font != 0 }
            for (r in line.runs) {
                if (switched) { out.add(w.nameOf(r.font, op.fontName!!)); out.add(COSFloat(op.fontSize)); out.add(Operator.getOperator("Tf")) }
                if (extraPerSpace > 0f && r.text.contains(' ')) {
                    val array = COSArray()
                    var from = 0
                    while (from < r.text.length) {
                        val at = r.text.indexOf(' ', from)
                        val end = if (at < 0) r.text.length else at + 1
                        val chunk = r.text.substring(from, end)
                        array.add(COSString(w.fonts.encode(r.font, chunk)!!))
                        if (at >= 0) array.add(COSFloat(-extraPerSpace * 1000f / op.fontSize))
                        from = end
                    }
                    out.add(array); out.add(Operator.getOperator("TJ"))
                } else {
                    out.add(COSString(w.fonts.encode(r.font, r.text)!!)); out.add(Operator.getOperator("Tj"))
                }
                if (r.font != 0 && !w.used.contains(r.text)) w.used.append(r.text)
            }
            if (switched) { out.add(op.fontName!!); out.add(COSFloat(op.fontSize)); out.add(Operator.getOperator("Tf")) }
        }
        if (op.tw != 0f) { out.add(COSFloat(op.tw)); out.add(Operator.getOperator("Tw")) }
        if (op.tc != 0f) { out.add(COSFloat(op.tc)); out.add(Operator.getOperator("Tc")) }
        return out
    }

    /**
     * Re-wraps the block starting at operator [firstIndex] of [pageNumber] with [newText]. The block is found again with [detect]: [firstIndex] must be a block's first line.
     * [fallbacks] are tried in order for letters the document's font cannot draw; [allowOverlap] keeps extra lines even when they run into other text.
     * PDFBox only subsets a font that was used through a page content stream; the tokens here are written directly, so each fallback font loaded is put in [subsetSink] and the caller
     * must call `subset()` on every one of them before it saves ([applyAll] does).
     */
    fun reflow(
        document: PDDocument, pageNumber: Int, firstIndex: Int, newText: String, fallbacks: List<ParagraphFontSource> = emptyList(), allowOverlap: Boolean = false,
        subsetSink: MutableList<PDType0Font>? = null
    ): Result {
        val scan = PdfTextEditor.scanPage(document, pageNumber)
        val found = detect(scan.ops).firstOrNull { it.lines.first() == firstIndex } ?: return Result.NotFound
        val range = found.lines
        val ops = scan.ops
        val first = ops[range.first()]
        val last = ops[range.last()]
        val font = first.font ?: return Result.UnsupportedFont
        val fontName = first.fontName ?: return Result.UnsupportedFont
        val stepUser = (first.originY - last.originY) / (range.size - 1)
        val scaleX = first.matrix[0]
        val scaleY = first.matrix[3]
        val boxWidth = widthOf(ops, range)
        val fonts = Fonts(document, font, first.fontSize, fallbacks, subsetSink)
        val missing = StringBuilder()
        val lines = wrap(fonts, newText.replace("\r\n", "\n"), boxWidth / scaleX + 0.02f, missing)
        if (lines == null) {
            // a font that cannot be used at all is not the same as one letter that has no font
            return if (missing.isEmpty()) Result.UnsupportedFont else Result.MissingGlyphs(missing.toString())
        }
        if (lines.size > MAX_LINES) return Result.TooManyLines
        val existing = range.size
        val extra = maxOf(0, lines.size - existing)
        val align = found.align
        // the frame the lines are set in, in page units
        val frameLeft = ops.let { range.minOf { k -> left(it[k]) } }
        val frameRight = range.maxOf { k -> right(ops[k]) }
        val frameCentre = range.sumOf { k -> centre(ops[k]).toDouble() }.toFloat() / range.size
        fun targetStart(line: Line): Float {
            val w = line.width * scaleX
            return when (align) { Align.CENTER -> frameCentre - w / 2f; Align.RIGHT -> frameRight - w; else -> frameLeft }
        }
        if (extra > 0) {
            val spanLeft = when (align) { Align.CENTER -> frameCentre - boxWidth / 2f; Align.RIGHT -> frameRight - boxWidth; else -> frameLeft }
            val spanRight = spanLeft + boxWidth
            val top = last.originY - extra * stepUser - 0.25f * first.fontSize * scaleY
            val bottom = last.originY - 0.25f * first.fontSize * scaleY
            val box = document.getPage(pageNumber - 1).cropBox
            if (top < box.lowerLeftY + 4f) return Result.OffPage
            if (!allowOverlap) {
                for ((k, op) in ops.withIndex()) {
                    if (k in range) continue
                    val b = op.box ?: continue
                    if (b[0] < spanRight && b[2] > spanLeft && b[1] < bottom && b[3] > top) return Result.Overlaps
                }
            }
        }
        val writer = Writer(document, pageNumber, fonts)
        // every token list is built BEFORE the content is touched: nothing is written if a line cannot be encoded
        fun justifyGap(line: Line): Float {
            if (align != Align.JUSTIFY || line.endsParagraph || line.spaces == 0) return 0f
            val gap = (boxWidth / scaleX - line.width) / line.spaces
            return if (gap > 0f) gap else 0f
        }
        val list = scan.tokens
        // extra lines first: they sit AFTER the last line's operator, so every earlier token number stays valid; the existing lines are then done from the last to the first
        if (extra > 0) {
            val stepText = stepUser / scaleY
            val insert = ArrayList<Any>()
            var shifted = 0f
            for (k in existing until lines.size) {
                val line = lines[k]
                val shift = (targetStart(line) - last.originX) / scaleX
                insert.addAll(tokenNumbers(shift - shifted, -stepText)); insert.add(Operator.getOperator("Td"))
                insert.addAll(showTokens(writer, line, last, justifyGap(line)))
                shifted = shift
            }
            insert.addAll(tokenNumbers(-shifted, extra * stepText)); insert.add(Operator.getOperator("Td"))
            list.addAll(last.opTokenIndex + 1, insert)
        }
        for (k in existing - 1 downTo 0) {
            val op = ops[range[k]]
            val line = if (k < lines.size) lines[k] else null
            val shift = if (line == null || align == Align.LEFT || align == Align.JUSTIFY) 0f else (targetStart(line) - op.originX) / scaleX
            val replacement = ArrayList<Any>()
            if (abs(shift) > 0.001f) { replacement.addAll(tokenNumbers(shift, 0f)); replacement.add(Operator.getOperator("Td")) }
            // the next-line operators move first: their own work is kept in front of the new text
            val from: Int
            when (op.opName) {
                "'" -> { from = op.opTokenIndex - 1; replacement.add(Operator.getOperator("T*")) }
                "\"" -> {
                    from = op.opTokenIndex - 3
                    replacement.add(list[from]); replacement.add(Operator.getOperator("Tw")); replacement.add(list[from + 1]); replacement.add(Operator.getOperator("Tc"))
                    replacement.add(Operator.getOperator("T*"))
                }
                else -> from = op.opTokenIndex - 1
            }
            replacement.addAll(showTokens(writer, line, op, if (line == null) 0f else justifyGap(line)))
            if (abs(shift) > 0.001f) { replacement.addAll(tokenNumbers(-shift, 0f)); replacement.add(Operator.getOperator("Td")) }
            for (n in op.opTokenIndex downTo from) list.removeAt(n)
            list.addAll(from, replacement)
        }
        val stream = PDStream(document)
        stream.createOutputStream(COSName.FLATE_DECODE).use { ContentStreamWriter(it).writeTokens(list) }
        document.getPage(pageNumber - 1).setContents(stream)
        return if (writer.used.isEmpty()) Result.Success else Result.Substituted(writer.used.toString())
    }

    private fun openForEdit(file: File): PDDocument =
        PDDocument.load(file, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(file.parentFile))

    /** Tries [newText] on a throw-away copy of [file] (nothing is written): the same check the saved copy will pass. */
    fun trial(file: File, page: Int, firstIndex: Int, newText: String, fallbacks: List<ParagraphFontSource> = emptyList(), allowOverlap: Boolean = false): Result {
        val doc = try { openForEdit(file) } catch (e: Exception) { return Result.NotFound }
        try {
            if (page !in 1..doc.numberOfPages) return Result.NotFound
            return reflow(doc, page, firstIndex, newText, fallbacks, allowOverlap)
        } catch (e: Exception) {
            return Result.NotFound
        } finally {
            runCatching { doc.close() }
        }
    }

    /** The blocks of page [page] of [file]; an unreadable file or page gives an empty list. */
    fun blocks(file: File, page: Int): List<Block> {
        val doc = try { openForEdit(file) } catch (e: Exception) { return emptyList() }
        try {
            if (page !in 1..doc.numberOfPages) return emptyList()
            return blocks(doc, page)
        } catch (e: Exception) {
            return emptyList()
        } finally {
            runCatching { doc.close() }
        }
    }

    /** Names the first edit that cannot be made instead of saving a copy that silently lacks it; same rule as [PdfTextEditor.applyAll]. Later blocks first, so adding lines never shifts a block still to do. */
    fun applyAll(src: File, out: File, edits: List<Edit>, fallbacks: List<ParagraphFontSource> = emptyList()) {
        val doc = openForEdit(src)
        try {
            val pages = doc.numberOfPages
            val sink = ArrayList<PDType0Font>()
            for (e in edits.sortedWith(compareBy({ it.page }, { -it.firstIndex }))) {
                if (e.page !in 1..pages) throw IllegalStateException("page ${e.page} not found")
                val r = reflow(doc, e.page, e.firstIndex, e.newText, fallbacks, e.allowOverlap, sink)
                if (!isDone(r)) throw IllegalStateException("paragraph edit refused on page ${e.page}: $r")
            }
            for (f in sink) f.subset()
            doc.save(out)
            if (!PdfVerify.opensAsPdf(out, pages)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
        } finally {
            runCatching { doc.close() }
        }
    }
}
