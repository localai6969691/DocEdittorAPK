package com.example.docscanner.util

/**
 * Names for "Đổi tên hàng loạt" (phiên 17, mục 4.31): one pattern for many documents.
 *
 * Tokens: `{n}` = running number from [plan]'s `start`, zero-padded to the width of the LAST number (so 1..12 gives 01..12 and the names sort
 * correctly); `{name}` = the current name without extension; `{date}` = the file's modification date as `yyyy-MM-dd`. Anything else, including an
 * unknown `{token}`, stays as typed. The extension is always kept. The result goes through [SmartNamer.sanitize] (illegal characters, length 60).
 *
 * Safety: a new name is never one that ALREADY exists in the folder (the caller passes every current name), nor one given earlier in the same batch;
 * a clash gets " (2)", " (3)"... as [SmartNamer.uniqueName] does. Comparison ignores case, because some storage is not case-sensitive. The only
 * existing name a file may take is its OWN current name (a no-op) or the old name of an EARLIER item of the batch (that file has been renamed away
 * by then: the renames run in this order, and [SmartNamer.rename] still refuses to overwrite if one of them failed). Names of LATER items stay
 * taken, so renaming in order can never overwrite a document. A PDF's `.txt` sidecar is renamed with it by [SmartNamer.rename].
 * Pure, mirrored in tools/verify/TrashCheck.java.
 */
object BulkRename {

    const val DEFAULT_PATTERN = "{name}_{n}"

    class Item(val name: String, val modified: Long)

    fun width(start: Int, count: Int): Int = (start + count - 1).coerceAtLeast(0).toString().length.coerceAtLeast(1)

    fun expand(pattern: String, baseName: String, number: Int, width: Int, date: String): String =
        pattern.replace("{n}", number.toString().padStart(width, '0')).replace("{name}", baseName).replace("{date}", date)

    /** @param taken every file name currently in the folder. @param date formats a modification time as `yyyy-MM-dd`.
     *  @return the new FILE names (with extension), in the order of [items]. */
    fun plan(items: List<Item>, pattern: String, start: Int, taken: Set<String>, date: (Long) -> String): List<String> {
        // existing: how many files currently carry each lower-cased name (two files that differ only in case count twice);
        // assigned: the new names already given in this batch.
        val existing = HashMap<String, Int>()
        for (t in taken) existing[t.lowercase()] = (existing[t.lowercase()] ?: 0) + 1
        val assigned = HashSet<String>()
        val w = width(start, items.size)
        val out = ArrayList<String>(items.size)
        for ((i, item) in items.withIndex()) {
            val dot = item.name.lastIndexOf('.')
            val ext = if (dot > 0) item.name.substring(dot + 1) else ""
            val oldBase = if (dot > 0) item.name.substring(0, dot) else item.name
            val raw = expand(pattern, oldBase, start + i, w, date(item.modified))
            val base = SmartNamer.sanitize(raw).ifEmpty { SmartNamer.sanitize(oldBase).ifEmpty { "document" } }
            // taken = given to an earlier item, or present in the folder - except the file's own exact name (a no-op rename)
            val name = SmartNamer.uniqueName(
                { c -> val l = c.lowercase(); assigned.contains(l) || ((existing[l] ?: 0) > 0 && c != item.name) },
                base, ext
            )
            assigned.add(name.lowercase())
            if (name != item.name) existing[item.name.lowercase()] = (existing[item.name.lowercase()] ?: 1) - 1   // the old name is free once renamed away
            out.add(name)
        }
        return out
    }
}
