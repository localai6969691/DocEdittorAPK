package com.example.docscanner.util

import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * Reads Markdown, HTML, Word (.docx) and CSV / TSV files into plain BLOCKS (headings, paragraphs, list items, code, table rows), so that the "Convert" tool can turn them into
 * PDF / EPUB / FB2 (phiên 19, mục 4.47.2; items 78-84 / L1-L5 / 9.11-9.14 of the PDF "Thiếu gì để bán app": Word / HTML / Markdown / CSV to PDF).
 *
 * Everything here is PURE (strings in, blocks out; no Android, no PdfBox) and is mirrored line by line in tools/verify/DocImportCheck.java.
 * tools/verify/doc_import_check.py compares the mirror with INDEPENDENT readers on generated inputs: Markdown against `pandoc -f commonmark` (its AST), HTML against lxml,
 * .docx against python-docx, CSV against Python's `csv` module.
 *
 * Scope, stated plainly: this is a TEXT conversion. Headings, paragraphs, lists, code blocks and tables come through as text in reading order; fonts, colours, images and page
 * layout of the source do not (the output is a clean reflowed document made by [TextPdfBuilder]). A table in Markdown / HTML / Word becomes one line per row with " | " between cells;
 * a CSV / TSV file is drawn as a real grid by [TablePdfBuilder] (column widths from [TableLayout]).
 */
object DocumentImport {

    enum class Kind { MARKDOWN, HTML, DOCX, CSV, TSV, ODT, PPTX, XLSX, RTF }

    /**
     * One piece of the document. [kind]: "H" heading ([level] 1..6), "P" paragraph, "LI" list item ([level] = nesting depth from 1, [marker] = "•" or "3."), "CODE" code block
     * (lines joined by \n), "ROW" table row (cells joined by " | ").
     */
    class Block(val kind: String, val level: Int, val text: String, val marker: String = "")

    /** The kind of file named [fileName] (by extension, case-insensitive), or null when it is not one of the supported ones. */
    fun detectKind(fileName: String): Kind? = when (fileName.substringAfterLast('.', "").lowercase()) {
        "md", "markdown", "mdown", "mkd" -> Kind.MARKDOWN
        "html", "htm", "xhtml" -> Kind.HTML
        "docx" -> Kind.DOCX
        "csv" -> Kind.CSV
        "tsv", "tab" -> Kind.TSV
        "odt" -> Kind.ODT
        "pptx" -> Kind.PPTX
        "xlsx" -> Kind.XLSX
        "rtf" -> Kind.RTF
        else -> null
    }

    // ------------------------------------------------------------------------------------------------- text encoding

    private val CHARSET_META = Regex("charset\\s*=\\s*[\"']?([A-Za-z0-9_:.-]+)", RegexOption.IGNORE_CASE)

    /**
     * Text of a file whose encoding is unknown, in this order: a byte-order mark (UTF-8, UTF-16 LE / BE) decides; then, for HTML ([sniffHtmlCharset]), a `charset=` declared in
     * the first 2 KB (`<meta charset="windows-1252">`); then strict UTF-8; and when the bytes are NOT valid UTF-8 (old Excel CSV exports, legacy pages) Windows-1252, which never fails.
     */
    fun decodeText(bytes: ByteArray, sniffHtmlCharset: Boolean = false): String {
        val n = bytes.size
        fun b(i: Int) = bytes[i].toInt() and 0xFF
        if (n >= 3 && b(0) == 0xEF && b(1) == 0xBB && b(2) == 0xBF) return String(bytes, 3, n - 3, Charsets.UTF_8)
        if (n >= 2 && b(0) == 0xFF && b(1) == 0xFE) return String(bytes, 2, n - 2, Charsets.UTF_16LE)
        if (n >= 2 && b(0) == 0xFE && b(1) == 0xFF) return String(bytes, 2, n - 2, Charsets.UTF_16BE)
        if (sniffHtmlCharset) {
            val head = String(bytes, 0, minOf(n, 2048), Charsets.ISO_8859_1)
            val name = CHARSET_META.find(head)?.groupValues?.get(1)
            if (name != null) {
                try { return String(bytes, java.nio.charset.Charset.forName(name)) } catch (e: Exception) { /* unknown or unsupported name: fall through */ }
            }
        }
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                .decode(java.nio.ByteBuffer.wrap(bytes)).toString()
        } catch (e: java.nio.charset.CharacterCodingException) {
            String(bytes, java.nio.charset.Charset.forName("windows-1252"))
        }
    }

    // ------------------------------------------------------------------------------------------------- shared helpers

    /** The 252 named character references of HTML 4.01 (Latin-1 letters, symbols, Greek, punctuation), as "name:code point,..." - generated from Python's html.entities.name2codepoint, with lang / rang set to the HTML5 angle brackets U+27E8 / U+27E9 that browsers use. */
    private const val HTML4_ENTITIES = "AElig:198,Aacute:193,Acirc:194,Agrave:192,Alpha:913,Aring:197,Atilde:195,Auml:196,Beta:914,Ccedil:199,Chi:935,Dagger:8225,Delta:916,ETH:208,Eacute:201,Ecirc:202,Egrave:200,Epsilon:917,Eta:919,Euml:203,Gamma:915,Iacute:205,Icirc:206,Igrave:204,Iota:921,Iuml:207,Kappa:922,Lambda:923,Mu:924,Ntilde:209,Nu:925,OElig:338,Oacute:211,Ocirc:212,Ograve:210,Omega:937,Omicron:927,Oslash:216,Otilde:213,Ouml:214,Phi:934,Pi:928,Prime:8243,Psi:936,Rho:929,Scaron:352,Sigma:931,THORN:222,Tau:932,Theta:920,Uacute:218,Ucirc:219,Ugrave:217,Upsilon:933,Uuml:220,Xi:926,Yacute:221,Yuml:376,Zeta:918,aacute:225,acirc:226,acute:180,aelig:230,agrave:224,alefsym:8501,alpha:945,amp:38,and:8743,ang:8736,aring:229,asymp:8776,atilde:227,auml:228,bdquo:8222,beta:946,brvbar:166,bull:8226,cap:8745,ccedil:231,cedil:184,cent:162,chi:967,circ:710,clubs:9827,cong:8773,copy:169,crarr:8629,cup:8746,curren:164,dArr:8659,dagger:8224,darr:8595,deg:176,delta:948,diams:9830,divide:247,eacute:233,ecirc:234,egrave:232,empty:8709,emsp:8195,ensp:8194,epsilon:949,equiv:8801,eta:951,eth:240,euml:235,euro:8364,exist:8707,fnof:402,forall:8704,frac12:189,frac14:188,frac34:190,frasl:8260,gamma:947,ge:8805,gt:62,hArr:8660,harr:8596,hearts:9829,hellip:8230,iacute:237,icirc:238,iexcl:161,igrave:236,image:8465,infin:8734,int:8747,iota:953,iquest:191,isin:8712,iuml:239,kappa:954,lArr:8656,lambda:955,lang:10216,laquo:171,larr:8592,lceil:8968,ldquo:8220,le:8804,lfloor:8970,lowast:8727,loz:9674,lrm:8206,lsaquo:8249,lsquo:8216,lt:60,macr:175,mdash:8212,micro:181,middot:183,minus:8722,mu:956,nabla:8711,nbsp:160,ndash:8211,ne:8800,ni:8715,not:172,notin:8713,nsub:8836,ntilde:241,nu:957,oacute:243,ocirc:244,oelig:339,ograve:242,oline:8254,omega:969,omicron:959,oplus:8853,or:8744,ordf:170,ordm:186,oslash:248,otilde:245,otimes:8855,ouml:246,para:182,part:8706,permil:8240,perp:8869,phi:966,pi:960,piv:982,plusmn:177,pound:163,prime:8242,prod:8719,prop:8733,psi:968,quot:34,rArr:8658,radic:8730,rang:10217,raquo:187,rarr:8594,rceil:8969,rdquo:8221,real:8476,reg:174,rfloor:8971,rho:961,rlm:8207,rsaquo:8250,rsquo:8217,sbquo:8218,scaron:353,sdot:8901,sect:167,shy:173,sigma:963,sigmaf:962,sim:8764,spades:9824,sub:8834,sube:8838,sum:8721,sup:8835,sup1:185,sup2:178,sup3:179,supe:8839,szlig:223,tau:964,there4:8756,theta:952,thetasym:977,thinsp:8201,thorn:254,tilde:732,times:215,trade:8482,uArr:8657,uacute:250,uarr:8593,ucirc:251,ugrave:249,uml:168,upsih:978,upsilon:965,uuml:252,weierp:8472,xi:958,yacute:253,yen:165,yuml:255,zeta:950,zwj:8205,zwnj:8204"
    private val NAMED: Map<String, String> by lazy {
        val m = HashMap<String, String>()
        for (pair in HTML4_ENTITIES.split(',')) { val i = pair.indexOf(':'); m[pair.substring(0, i)] = String(Character.toChars(pair.substring(i + 1).toInt())) }
        m["apos"] = "'"
        m
    }
    private val ENTITY = Regex("&(#[0-9]{1,7}|#[xX][0-9A-Fa-f]{1,6}|[A-Za-z][A-Za-z0-9]{1,7});")

    /** Characters 0x80-0x9F in a numeric reference are Windows-1252 (what browsers do: &#150; is an en dash); the five undefined ones stay as they are. */
    private fun cp1252(cp: Int): String {
        val s = String(byteArrayOf(cp.toByte()), java.nio.charset.Charset.forName("windows-1252"))
        return if (s == "\uFFFD") String(Character.toChars(cp)) else s
    }

    /** HTML / XML character references (`&amp;`, `&#233;`, `&#xE9;` and the few named ones above); anything else is left as typed. */
    fun decodeEntities(s: String): String {
        if (s.indexOf('&') < 0) return s
        return ENTITY.replace(s) { m ->
            val body = m.groupValues[1]
            if (body[0] == '#') {
                val cp = try { if (body[1] == 'x' || body[1] == 'X') body.substring(2).toInt(16) else body.substring(1).toInt() } catch (e: NumberFormatException) { -1 }
                if (cp in 0x80..0x9F) cp1252(cp)
                else if (cp in 1..0x10FFFF && cp !in 0xD800..0xDFFF) String(Character.toChars(cp)) else m.value
            } else NAMED[body] ?: m.value
        }
    }

    private val WS = Regex("[ \\t\\u00A0\\r\\n]+")
    private fun collapse(s: String) = WS.replace(s, " ").trim()

    // ------------------------------------------------------------------------------------------------- Markdown

    private val FENCE = Regex("^ {0,3}(`{3,}|~{3,})[ \\t]*([^`]*)$")
    private val ATX = Regex("^ {0,3}(#{1,6})(?:[ \\t]+(.*?))?(?:[ \\t]+#+)?[ \\t]*$")
    private val SETEXT = Regex("^ {0,3}(=+|-+)[ \\t]*$")
    private val HRULE = Regex("^ {0,3}([-*_])(?:[ \\t]*\\1){2,}[ \\t]*$")
    private val LIST_ITEM = Regex("^( *)([-+*]|[0-9]{1,9}[.)])([ \\t]+)(.*)$")
    private val TABLE_SEP = Regex("^ *\\|? *:?-+:? *(?:\\| *:?-+:? *)*\\|? *$")
    private val QUOTE = Regex("^ {0,3}>[ >]*")
    private val IMAGE = Regex("!\\[([^\\]]*)\\]\\([^)]*\\)")
    private val LINK = Regex("\\[([^\\]]*)\\]\\([^)]*\\)")
    private val REFLINK = Regex("\\[([^\\]]+)\\]\\[[^\\]]*\\]")
    private val AUTOLINK = Regex("<((?:https?://|mailto:)[^>\\s]+)>")
    private val CODESPAN = Regex("(`+)([^`]|[^`].*?[^`])\\1(?!`)")
    private val STRONG_STAR = Regex("\\*\\*(?=\\S)(.+?)(?<=\\S)\\*\\*")
    private val STRONG_US = Regex("(?<![A-Za-z0-9_])__(?=\\S)(.+?)(?<=\\S)__(?![A-Za-z0-9_])")
    private val EM_STAR = Regex("\\*(?=[^\\s*])([^*]+?)(?<=[^\\s*])\\*")
    private val EM_US = Regex("(?<![A-Za-z0-9_])_(?=[^\\s_])([^_]+?)(?<=[^\\s_])_(?![A-Za-z0-9_])")
    private val STRIKE = Regex("~~(?=\\S)(.+?)(?<=\\S)~~")
    private val HTML_TAG = Regex("</?[A-Za-z][^>]*>")
    private val ESCAPED = Regex("\\\\([!-/:-@\\[-`{-~])")
    private val FRONT_MATTER_KEY = Regex("^[A-Za-z0-9_-]+:")
    private val HARD_BREAK = Regex("(?: {2,}|\\\\)\\n")

    /** Inline Markdown to plain text: code spans untouched, links / images reduced to their text, emphasis marks, inline HTML tags and backslash escapes removed, entities decoded. */
    fun mdInline(raw: String): String {
        val code = ArrayList<String>()
        var s = CODESPAN.replace(raw) { m ->
            code.add(m.groupValues[2].trim())
            "\u0000" + (code.size - 1) + "\u0000"
        }
        // a backslash escape (\*, \_, \[ ...) is turned into a private-use character FIRST, so that the emphasis / link rules below cannot see it; it is turned back at the end
        s = ESCAPED.replace(s) { (0xE000 + it.groupValues[1][0].code).toChar().toString() }
        s = IMAGE.replace(s) { it.groupValues[1] }
        s = LINK.replace(s) { it.groupValues[1] }
        s = REFLINK.replace(s) { it.groupValues[1] }
        s = AUTOLINK.replace(s) { it.groupValues[1] }
        s = STRONG_STAR.replace(s) { it.groupValues[1] }
        s = STRONG_US.replace(s) { it.groupValues[1] }
        s = EM_STAR.replace(s) { it.groupValues[1] }
        s = EM_US.replace(s) { it.groupValues[1] }
        s = STRIKE.replace(s) { it.groupValues[1] }
        s = HTML_TAG.replace(s, "")
        s = decodeEntities(s)
        s = buildString { for (c in s) append(if (c.code in 0xE021..0xE07E) (c.code - 0xE000).toChar() else c) }
        for ((i, c) in code.withIndex()) s = s.replace("\u0000$i\u0000", c)
        return s
    }

    private fun mdText(lines: List<String>): String {
        val joined = lines.joinToString("\n")
        val withBreaks = HARD_BREAK.replace(joined + "\n", "\u0001").removeSuffix("\n")
        return mdInline(withBreaks).replace(WS, " ").replace("\u0001", "\n").lines().joinToString("\n") { it.trim() }.trim()
    }

    private fun isTableRow(line: String) = line.indexOf('|') >= 0
    private fun splitRow(line: String): List<String> {
        var t = line.trim()
        if (t.startsWith("|")) t = t.substring(1)
        if (t.endsWith("|") && !t.endsWith("\\|")) t = t.substring(0, t.length - 1)
        val cells = ArrayList<String>()
        val sb = StringBuilder()
        var i = 0
        while (i < t.length) {
            val c = t[i]
            if (c == '\\' && i + 1 < t.length && t[i + 1] == '|') { sb.append('|'); i += 2; continue }
            if (c == '|') { cells.add(sb.toString()); sb.setLength(0) } else sb.append(c)
            i++
        }
        cells.add(sb.toString())
        return cells.map { collapse(mdInline(it)) }
    }

    fun blocksFromMarkdown(source: String): List<Block> {
        var text = source.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n')
        if (text.startsWith("---\n") && FRONT_MATTER_KEY.containsMatchIn(text.substring(4).substringBefore('\n'))) {   // YAML front matter (Jekyll, Hugo, Obsidian): "---", key: value lines, "---"
            val end = text.indexOf("\n---\n", 3)
            if (end > 0) text = text.substring(end + 5)
        }
        val lines = text.split("\n")
        val out = ArrayList<Block>()
        val para = ArrayList<String>()
        var itemText: StringBuilder? = null
        var itemLevel = 0
        var itemMarker = ""
        val offsets = ArrayList<Int>()          // content offsets of the open list items (a stack): nesting depth = how many are still open
        fun flushItem() { itemText?.let { out.add(Block("LI", itemLevel, mdText(listOf(it.toString())), itemMarker)) }; itemText = null }
        fun flushPara() {
            if (para.isNotEmpty()) { val t = mdText(para); if (t.isNotEmpty()) out.add(Block("P", 0, t)); para.clear() }
        }
        fun flushAll() { flushItem(); flushPara() }
        var afterBlank = false
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            if (line.isBlank()) { flushAll(); afterBlank = true; i++; continue }   // a blank line ends the item, not the list: items separated by blank lines stay at their depth
            val wasBlank = afterBlank
            afterBlank = false
            val fence = FENCE.find(line)
            if (fence != null) {
                flushAll(); offsets.clear()
                val mark = fence.groupValues[1]
                val body = ArrayList<String>()
                i++
                while (i < lines.size) {
                    val t = lines[i].trim()
                    if (t.length >= mark.length && t.all { it == mark[0] }) break
                    body.add(lines[i]); i++
                }
                i++
                val code = body.joinToString("\n").trimEnd()
                if (code.isNotEmpty()) out.add(Block("CODE", 0, code))
                continue
            }
            val atx = ATX.find(line)
            if (atx != null) {
                flushAll(); offsets.clear()
                out.add(Block("H", atx.groupValues[1].length, collapse(mdInline(atx.groupValues[2]))))
                i++; continue
            }
            val setext = SETEXT.find(line)
            if (setext != null && para.isNotEmpty() && itemText == null) {
                val t = mdText(para); para.clear()
                if (t.isNotEmpty()) out.add(Block("H", if (setext.groupValues[1][0] == '=') 1 else 2, collapse(t)))
                i++; continue
            }
            if (HRULE.containsMatchIn(line)) { flushAll(); offsets.clear(); i++; continue }
            if (isTableRow(line) && i + 1 < lines.size && TABLE_SEP.matches(lines[i + 1]) && lines[i + 1].indexOf('-') >= 0 && lines[i + 1].indexOf('|') >= 0) {
                flushAll(); offsets.clear()
                out.add(Block("ROW", 0, splitRow(line).joinToString(" | ")))
                i += 2
                while (i < lines.size && lines[i].isNotBlank() && isTableRow(lines[i])) { out.add(Block("ROW", 0, splitRow(lines[i]).joinToString(" | "))); i++ }
                continue
            }
            val li = LIST_ITEM.find(line)
            if (li != null && !(para.isNotEmpty() && itemText == null && li.groupValues[2][0].isDigit() && !li.groupValues[2].startsWith("1"))) {
                flushItem(); flushPara()
                val indent = li.groupValues[1].length
                val marker = li.groupValues[2]
                val contentOffset = indent + marker.length + li.groupValues[3].length.coerceAtMost(4)
                while (offsets.isNotEmpty() && indent < offsets.last()) offsets.removeAt(offsets.size - 1)
                offsets.add(contentOffset)
                itemLevel = offsets.size
                itemMarker = if (marker[0].isDigit()) marker else "\u2022"
                itemText = StringBuilder(li.groupValues[4])
                i++; continue
            }
            if (QUOTE.containsMatchIn(line)) {
                flushItem(); offsets.clear()
                para.add(QUOTE.replaceFirst(line, "").trimStart())   // only the START is trimmed: two spaces at the END of a line are a hard break
                i++; continue
            }
            if (itemText != null && !wasBlank) { itemText!!.append('\n').append(line.trimStart()); i++; continue }   // lazy continuation of the item
            if (wasBlank) offsets.clear()                                                                     // a paragraph after a blank line ends the list
            flushItem()
            para.add(line.trimStart())
            i++
        }
        flushAll()
        return out
    }

    // ------------------------------------------------------------------------------------------------- HTML

    private val COMMENT = Regex("<!--.*?-->", RegexOption.DOT_MATCHES_ALL)
    private val SKIPPED = Regex("<(script|style|head|noscript|template)\\b[^>]*>.*?</\\1\\s*>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
    private val TITLE = Regex("<title[^>]*>(.*?)</title\\s*>", setOf(RegexOption.DOT_MATCHES_ALL, RegexOption.IGNORE_CASE))
    private val TAG = Regex("<(/?)([A-Za-z][A-Za-z0-9]*)\\b[^>]*?(/?)>")
    private val HEADING = Regex("h([1-6])")
    private val FLOW = setOf("p", "div", "section", "article", "header", "footer", "blockquote", "figure", "figcaption", "main", "nav", "aside", "address", "dd", "dt", "dl", "form", "fieldset", "hr", "body", "html", "caption")

    /** The text of `<title>`, or "" when the page has none. */
    fun htmlTitle(html: String): String = TITLE.find(COMMENT.replace(html, ""))?.let { collapse(decodeEntities(it.groupValues[1].replace(Regex("<[^>]*>"), ""))) } ?: ""

    fun blocksFromHtml(source: String): List<Block> {
        val html = SKIPPED.replace(COMMENT.replace(source, ""), "")
        val out = ArrayList<Block>()
        val buf = StringBuilder()           // text of the block being collected; \u0001 marks a <br> (outside <pre>)
        var ctx = "P"                       // what the collected text becomes: P, H, LI or CODE
        var ctxLevel = 0
        val lists = ArrayList<IntArray>()   // per open list: [ordered 0/1, counter]
        var liMarker = ""
        var inPre = false
        var row: ArrayList<String>? = null
        var inCell = false
        fun flush() {
            if (inCell) { buf.append(' '); return }   // a paragraph break inside a table cell is just a space
            val t = if (ctx == "CODE") buf.toString().trim('\n')
            else collapse(buf.toString().replace("\u0001", " \u0001 ")).replace(" \u0001 ", "\n").replace("\u0001", "\n").trim()
            if (t.isNotEmpty()) out.add(Block(ctx, ctxLevel, t, if (ctx == "LI") liMarker else ""))
            buf.setLength(0)
            if (!inPre) { ctx = "P"; ctxLevel = 0 }
        }
        var pos = 0
        for (m in TAG.findAll(html)) {
            if (m.range.first > pos) buf.append(decodeEntities(html.substring(pos, m.range.first)))
            pos = m.range.last + 1
            val closing = m.groupValues[1] == "/"
            val name = m.groupValues[2].lowercase()
            val heading = HEADING.matchEntire(name)
            when {
                heading != null -> {
                    flush()
                    if (!closing) { ctx = "H"; ctxLevel = heading.groupValues[1].toInt() }
                }
                name == "br" -> buf.append(if (inPre) "\n" else "\u0001")
                name == "pre" -> {
                    flush()
                    if (!closing) { ctx = "CODE"; inPre = true } else { ctx = "CODE"; flush(); inPre = false; ctx = "P" }
                }
                name == "ul" || name == "ol" -> {
                    flush()
                    if (!closing) lists.add(intArrayOf(if (name == "ol") 1 else 0, 0)) else if (lists.isNotEmpty()) lists.removeAt(lists.size - 1)
                }
                name == "li" -> {
                    flush()
                    if (!closing) {
                        val l = lists.lastOrNull()
                        if (l != null) l[1]++
                        ctx = "LI"; ctxLevel = lists.size.coerceAtLeast(1)
                        liMarker = if (l != null && l[0] == 1) "${l[1]}." else "\u2022"
                    }
                }
                name == "tr" -> {
                    if (!closing) { flush(); row = ArrayList() }
                    else {
                        val r = row
                        if (r != null && r.any { it.isNotEmpty() }) out.add(Block("ROW", 0, r.joinToString(" | ")))
                        row = null; buf.setLength(0); inCell = false
                    }
                }
                name == "td" || name == "th" -> {
                    if (!closing) { flush(); buf.setLength(0); inCell = true }
                    else {
                        row?.add(collapse(buf.toString().replace("\u0001", " ")))
                        buf.setLength(0); inCell = false
                    }
                }
                name == "table" -> { flush(); row = null; inCell = false }
                name in FLOW -> flush()
                else -> { /* inline tag (a, b, i, em, strong, span, code, ...): the text goes on */ }
            }
        }
        if (pos < html.length) buf.append(decodeEntities(html.substring(pos)))
        flush()
        return out
    }

    // ------------------------------------------------------------------------------------------------- DOCX

    private const val MAX_DOCX_XML = 64 * 1024 * 1024

    private val DOCX_ITEM = Regex("<w:tbl>.*?</w:tbl>|<w:p[ >].*?</w:p>", RegexOption.DOT_MATCHES_ALL)
    private val DOCX_ROW = Regex("<w:tr[ >].*?</w:tr>", RegexOption.DOT_MATCHES_ALL)
    private val DOCX_CELL = Regex("<w:tc>.*?</w:tc>|<w:tc [^>]*>.*?</w:tc>", RegexOption.DOT_MATCHES_ALL)
    private val DOCX_PARA = Regex("<w:p[ >].*?</w:p>", RegexOption.DOT_MATCHES_ALL)
    private val DOCX_RUN = Regex("<w:t(?: [^>]*)?>(.*?)</w:t>|<w:tab/>|<w:br(?: [^>]*)?/>|<w:cr/>|<w:noBreakHyphen/>", RegexOption.DOT_MATCHES_ALL)
    private val DOCX_STYLE = Regex("<w:pStyle w:val=\"([^\"]+)\"")
    private val DOCX_ILVL = Regex("<w:ilvl w:val=\"([0-9]+)\"")
    private val DOCX_HEADING = Regex("(?i)^heading([1-9])$")
    private val DOCX_STYLE_DEPTH = Regex("([1-9])$")

    private fun docxParaText(p: String): String {
        val sb = StringBuilder()
        for (m in DOCX_RUN.findAll(p)) {
            val v = m.value
            when {
                v.startsWith("<w:tab") -> sb.append(' ')
                v.startsWith("<w:br") || v.startsWith("<w:cr") -> sb.append('\n')
                v.startsWith("<w:noBreakHyphen") -> sb.append('-')
                else -> sb.append(decodeEntities(m.groupValues[1]))
            }
        }
        return sb.toString()
    }

    /** Blocks from the text of `word/document.xml`: Title / Heading1-9 styles become headings, numbered or bulleted paragraphs become list items, tables become rows. */
    fun blocksFromDocxXml(xml: String): List<Block> {
        val out = ArrayList<Block>()
        for (item in DOCX_ITEM.findAll(xml)) {
            val v = item.value
            if (v.startsWith("<w:tbl>")) {
                for (r in DOCX_ROW.findAll(v)) {
                    val cells = ArrayList<String>()
                    for (c in DOCX_CELL.findAll(r.value)) cells.add(collapse(DOCX_PARA.findAll(c.value).joinToString(" ") { docxParaText(it.value) }))
                    if (cells.any { it.isNotEmpty() }) out.add(Block("ROW", 0, cells.joinToString(" | ")))
                }
                continue
            }
            val text = docxParaText(v).lines().joinToString("\n") { collapse(it) }.trim()
            if (text.isEmpty()) continue
            val style = DOCX_STYLE.find(v)?.groupValues?.get(1) ?: ""
            val heading = DOCX_HEADING.find(style)
            when {
                style.equals("Title", ignoreCase = true) -> out.add(Block("H", 1, collapse(text)))
                heading != null -> out.add(Block("H", heading.groupValues[1].toInt(), collapse(text)))
                v.contains("<w:numPr>") || style.startsWith("ListBullet", true) || style.startsWith("ListNumber", true) || style.equals("ListParagraph", true) -> {
                    // nesting depth: the numbering level when the paragraph carries one, else the digit at the end of the style id ("ListBullet2" = depth 2), else 1
                    val lvl = DOCX_ILVL.find(v)?.groupValues?.get(1)?.toInt()?.plus(1) ?: DOCX_STYLE_DEPTH.find(style)?.groupValues?.get(1)?.toInt() ?: 1
                    out.add(Block("LI", lvl, text, if (style.startsWith("ListNumber", true)) "#" else "\u2022"))
                }
                else -> out.add(Block("P", 0, text))
            }
        }
        return out
    }

    /** Reads `word/document.xml` out of a .docx (a ZIP). Returns an empty list when the entry is missing or larger than 64 MB. */
    fun blocksFromDocx(input: InputStream): List<Block> {
        ZipInputStream(input).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: return emptyList()
                if (e.name != "word/document.xml") continue
                val bytes = java.io.ByteArrayOutputStream()
                val buf = ByteArray(16 * 1024)
                var total = 0
                while (true) {
                    val n = zip.read(buf)
                    if (n < 0) break
                    total += n
                    if (total > MAX_DOCX_XML) return emptyList()
                    bytes.write(buf, 0, n)
                }
                return blocksFromDocxXml(bytes.toString("UTF-8"))
            }
        }
    }

    // ------------------------------------------------------------------------------------------------- CSV / TSV

    /** RFC 4180: quoted fields, `""` for a quote, line breaks inside quotes; rows end at \n, \r\n or \r; a UTF-8 byte-order mark is dropped; empty lines add no row. */
    fun parseCsv(source: String, delimiter: Char): List<List<String>> {
        val text = source.removePrefix("\uFEFF")
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val field = StringBuilder()
        var quoted = false
        var fieldStarted = false
        var i = 0
        fun endField() { row.add(field.toString()); field.setLength(0); fieldStarted = false }
        fun endRow() {
            val blankLine = row.isEmpty() && field.isEmpty() && !fieldStarted   // an empty line is not a row (Python's csv gives [] for it too); a quoted "" alone on a line still is
            endField()
            if (!blankLine) rows.add(row)
            row = ArrayList()
        }
        while (i < text.length) {
            val c = text[i]
            if (quoted) {
                if (c == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') { field.append('"'); i++ } else quoted = false
                } else field.append(c)
            } else when {
                c == '"' && !fieldStarted -> { quoted = true; fieldStarted = true }
                c == delimiter -> endField()
                c == '\n' -> endRow()
                c == '\r' -> { endRow(); if (i + 1 < text.length && text[i + 1] == '\n') i++ }
                else -> { field.append(c); fieldStarted = true }
            }
            i++
        }
        if (fieldStarted || field.isNotEmpty() || row.isNotEmpty()) endRow()
        return rows
    }

    /** `,` `;` TAB or `|`, whichever splits the first 30 rows into the most rows with the SAME number (> 1) of columns; ties go to the earlier candidate; `,` when none splits. */
    fun detectDelimiter(text: String): Char {
        val head = text.removePrefix("\uFEFF").split('\n').take(30).joinToString("\n")
        var best = ','
        var bestScore = 0
        for (d in charArrayOf(',', ';', '\t', '|')) {
            val rows = parseCsv(head, d).filter { it.size > 1 || (it.size == 1 && it[0].isNotEmpty()) }
            if (rows.isEmpty()) continue
            val counts = rows.groupingBy { it.size }.eachCount()
            val modal = counts.entries.maxWithOrNull(compareBy({ it.value }, { it.key }))!!
            val score = if (modal.key > 1) modal.value * 1000 + modal.key else 0
            if (score > bestScore) { bestScore = score; best = d }
        }
        return best
    }

    // ------------------------------------------------------------------------------------------------- blocks -> chapters

    /**
     * Chapters for [TextPdfBuilder] / [EbookBuilder]: every level 1 or 2 heading starts a chapter (its text is the chapter title); text before the first heading goes into a chapter
     * called [fallbackTitle]; deeper headings stay as paragraphs; list items get their marker ("•" or "3.") and two spaces of indent per nesting level; code and table rows keep their text.
     */
    fun chapters(blocks: List<Block>, fallbackTitle: String): List<EbookBuilder.Chapter> {
        val out = ArrayList<EbookBuilder.Chapter>()
        var title: String? = null
        var paras = ArrayList<String>()
        var counter = 0
        fun close() { if (title != null || paras.isNotEmpty()) out.add(EbookBuilder.Chapter(title ?: fallbackTitle, paras)); paras = ArrayList() }
        for (b in blocks) {
            when {
                b.kind == "H" && b.level <= 2 -> { close(); title = b.text; counter = 0 }
                b.kind == "LI" -> paras.add("  ".repeat((b.level - 1).coerceAtLeast(0)) + (if (b.marker == "#") "${++counter}." else b.marker) + " " + b.text)
                else -> paras.add(b.text)
            }
        }
        close()
        return out
    }

    /** A title for the whole document: the first level-1 heading, else the first heading, else [fallback]. */
    fun documentTitle(blocks: List<Block>, fallback: String): String =
        (blocks.firstOrNull { it.kind == "H" && it.level == 1 } ?: blocks.firstOrNull { it.kind == "H" })?.text?.ifEmpty { null } ?: fallback
}
