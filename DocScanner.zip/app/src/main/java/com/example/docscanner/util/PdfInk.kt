package com.example.docscanner.util

import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSDictionary
import com.tom_roush.pdfbox.cos.COSFloat
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.File
import java.util.Locale
import kotlin.math.hypot

/**
 * Freehand drawing as REAL PDF ink annotations (session 23, 4.62): a pen or a marker stroke becomes an `/Ink` annotation (ISO 32000 12.5.6.13: "a freehand scribble composed
 * of one or more disjoint paths", stored in `/InkList`) with its own appearance stream, so the page keeps its text and any viewer shows (and can edit) the stroke. This is
 * what the other PDF readers do; the older "Annotate" screen instead flattens every page to a picture.
 *
 * Strokes are given as points in fractions (0..1) of the DISPLAYED page from the top-left, converted to page user space with [PdfPageGeometry] (rotation and CropBox
 * included) exactly as [PdfTextMarkup] does for highlights. The appearance is written explicitly because a viewer may not draw an ink annotation that has none.
 * [simplify], [bounds] and [appearance] are plain Kotlin mirrored by tools/verify/InkCheck.java; tools/verify/ink_check.py renders the result with poppler in 24 page setups.
 */
object PdfInk {

    /** [points] = x0, y0, x1, y1, ... (0..1, top-left origin); [color] = ARGB int (alpha ignored); [width] = fraction of the displayed page WIDTH; [marker] = translucent highlighter. */
    class Stroke(val points: FloatArray, val color: Int, val width: Float, val marker: Boolean)

    const val PEN_WIDTH = 0.004f
    const val MARKER_WIDTH = 0.022f
    const val MARKER_OPACITY = 0.4f

    /** Points closer than this (fraction of the page) to the previous kept point are dropped: a finger drag delivers far more points than a smooth line needs. */
    const val MIN_STEP = 0.003f

    /** A stroke keeps at most about this many points (the step is raised until it fits). */
    const val MAX_POINTS = 1500

    private fun f3(v: Float): String = String.format(Locale.US, "%.3f", v)

    /** Keeps the first and the last point and every point at least [minStep] away from the last kept one. Always a subsequence of [points], never fewer than 2 points when given 2. */
    fun simplify(points: FloatArray, minStep: Float = MIN_STEP): FloatArray {
        val n = points.size / 2
        if (n <= 2) return points.copyOf(n * 2)
        val out = ArrayList<Float>()
        out.add(points[0]); out.add(points[1])
        var lx = points[0]
        var ly = points[1]
        for (i in 1 until n - 1) {
            val x = points[2 * i]
            val y = points[2 * i + 1]
            if (hypot(x - lx, y - ly) >= minStep) {
                out.add(x); out.add(y)
                lx = x; ly = y
            }
        }
        out.add(points[2 * (n - 1)]); out.add(points[2 * (n - 1) + 1])
        return out.toFloatArray()
    }

    /** [simplify] with the step raised (doubled up to 6 times) until the stroke has at most [MAX_POINTS] points. */
    fun simplifyCapped(points: FloatArray): FloatArray {
        var step = MIN_STEP
        var result = simplify(points, step)
        var tries = 0
        while (result.size / 2 > MAX_POINTS && tries < 6) {
            step *= 2f
            result = simplify(points, step)
            tries++
        }
        return result
    }

    /** `[llx, lly, urx, ury]` of user-space [user] points (x, y pairs) grown by [pad] on every side. */
    fun bounds(user: FloatArray, pad: Float): FloatArray {
        var minX = user[0]; var maxX = user[0]; var minY = user[1]; var maxY = user[1]
        var i = 2
        while (i + 1 < user.size) {
            minX = minOf(minX, user[i]); maxX = maxOf(maxX, user[i])
            minY = minOf(minY, user[i + 1]); maxY = maxOf(maxY, user[i + 1])
            i += 2
        }
        return floatArrayOf(minX - pad, minY - pad, maxX + pad, maxY + pad)
    }

    /**
     * Content stream of the appearance, in page user space: round caps and joins, [width] points thick, the marker through an `/GS` state (multiply, see [annotate]).
     * A single point is drawn as a zero-length line, which the round cap turns into a dot. [rgb] = 3 floats 0..1.
     */
    fun appearance(user: FloatArray, rgb: FloatArray, width: Float, marker: Boolean): String {
        val sb = StringBuilder()
        if (marker) sb.append("/GS gs\n")
        sb.append("${f3(rgb[0])} ${f3(rgb[1])} ${f3(rgb[2])} RG\n${f3(width)} w 1 J 1 j\n")
        sb.append("${f3(user[0])} ${f3(user[1])} m")
        if (user.size <= 2) sb.append(" ${f3(user[0])} ${f3(user[1])} l")
        var i = 2
        while (i + 1 < user.size) {
            sb.append(" ${f3(user[i])} ${f3(user[i + 1])} l")
            i += 2
        }
        sb.append(" S\n")
        return sb.toString()
    }

    private fun numbers(vararg v: Float): COSArray = COSArray().also { a -> v.forEach { a.add(COSFloat(it)) } }

    private fun rgbOf(color: Int): FloatArray =
        floatArrayOf(((color shr 16) and 0xFF) / 255f, ((color shr 8) and 0xFF) / 255f, (color and 0xFF) / 255f)

    /**
     * @param strokesByPage 0-based page -> strokes. @return the number of annotations written (one per stroke; strokes with no point are skipped).
     * Throws `IllegalStateException("encrypted")` for a protected file.
     */
    fun annotate(src: File, out: File, strokesByPage: Map<Int, List<Stroke>>, author: String = "DocScanner"): Int {
        val doc = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
        try {
            if (doc.isEncrypted) throw IllegalStateException("encrypted")
            val pages = doc.numberOfPages
            var written = 0
            for ((pageIndex, strokes) in strokesByPage.toSortedMap()) {
                if (pageIndex !in 0 until pages || strokes.isEmpty()) continue
                val page = doc.getPage(pageIndex)
                val geo = PdfPageGeometry.of(page)
                val annots = (page.cosObject.getDictionaryObject("Annots") as? COSArray)
                    ?: COSArray().also { page.cosObject.setItem("Annots", it) }
                for (stroke in strokes) {
                    val n = stroke.points.size / 2
                    if (n == 0) continue
                    val user = FloatArray(n * 2)
                    for (i in 0 until n) {
                        val p = geo.toUser(stroke.points[2 * i].coerceIn(0f, 1f) * geo.displayWidth, stroke.points[2 * i + 1].coerceIn(0f, 1f) * geo.displayHeight)
                        user[2 * i] = p.first
                        user[2 * i + 1] = p.second
                    }
                    val width = stroke.width * geo.displayWidth
                    val b = bounds(user, width / 2f + 1f)
                    val rgb = rgbOf(stroke.color)
                    val ap = doc.document.createCOSStream()
                    ap.setItem("Type", COSName.getPDFName("XObject"))
                    ap.setItem("Subtype", COSName.getPDFName("Form"))
                    ap.setItem("BBox", numbers(b[0], b[1], b[2], b[3]))
                    if (stroke.marker) {
                        val gs = COSDictionary().apply {
                            setItem("Type", COSName.getPDFName("ExtGState"))
                            setItem("BM", COSName.getPDFName("Multiply"))
                            setItem("CA", COSFloat(MARKER_OPACITY))
                            setItem("ca", COSFloat(MARKER_OPACITY))
                        }
                        val states = COSDictionary().apply { setItem("GS", gs) }
                        ap.setItem("Resources", COSDictionary().apply { setItem("ExtGState", states) })
                    } else {
                        ap.setItem("Resources", COSDictionary())
                    }
                    ap.createOutputStream(COSName.FLATE_DECODE).use { it.write(appearance(user, rgb, width, stroke.marker).toByteArray(Charsets.US_ASCII)) }
                    val path = COSArray().also { a -> user.forEach { a.add(COSFloat(it)) } }
                    val annot = COSDictionary().apply {
                        setItem("Type", COSName.getPDFName("Annot"))
                        setItem("Subtype", COSName.getPDFName("Ink"))
                        setItem("Rect", numbers(b[0], b[1], b[2], b[3]))
                        setItem("InkList", COSArray().also { it.add(path) })
                        setItem("C", numbers(rgb[0], rgb[1], rgb[2]))
                        setItem("BS", COSDictionary().apply { setItem("W", COSFloat(width)) })
                        if (stroke.marker) setItem("CA", COSFloat(MARKER_OPACITY))
                        setInt("F", 4)   // Print
                        setString("T", author)
                        setItem("AP", COSDictionary().apply { setItem("N", ap) })
                    }
                    annots.add(annot)
                    written++
                }
            }
            if (written == 0) throw IllegalArgumentException("no stroke")
            PdfStructureOptimizer.save(doc, out)
            if (!PdfVerify.opensAsPdf(out, pages)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
            return written
        } finally {
            runCatching { doc.close() }
        }
    }
}
