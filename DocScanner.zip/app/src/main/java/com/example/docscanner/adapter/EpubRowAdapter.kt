package com.example.docscanner.adapter

import android.graphics.Color
import android.graphics.Typeface
import android.text.Spannable
import android.text.SpannableString
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.ActionMode
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.R
import com.example.docscanner.databinding.ItemEpubRowBinding
import com.example.docscanner.util.EpubNotes

/**
 * The rows of the in-app EPUB reader ([com.example.docscanner.EpubReaderActivity], PDF list C5 / C6): a heading row per chapter, then one row per paragraph.
 * A paragraph row is selectable text; selecting words offers "Highlight" / "Remove highlight" in the selection menu. Highlights are drawn as spans
 * (yellow background, black text so they read in the light AND the dark theme); a bookmarked paragraph gets a soft amber background.
 * The text of a row is never changed (no icons / prefixes), so selection offsets are exactly the offsets [EpubNotes] stores.
 */
class EpubRowAdapter(
    private val onSelection: (row: Row, start: Int, end: Int, erase: Boolean) -> Unit
) : RecyclerView.Adapter<EpubRowAdapter.ViewHolder>() {

    /** [paragraph] = -1 for a chapter heading. */
    class Row(val chapter: Int, val paragraph: Int, val text: String) {
        val heading: Boolean get() = paragraph < 0
    }

    private var rows: List<Row> = emptyList()
    private var marks: HashMap<Long, List<EpubNotes.Mark>> = HashMap()
    private var bookmarkKeys: HashSet<Long> = HashSet()
    private var textSp: Float = 17f

    class ViewHolder(val binding: ItemEpubRowBinding) : RecyclerView.ViewHolder(binding.root)

    fun submit(newRows: List<Row>) {
        rows = newRows
        notifyDataSetChanged()
    }

    /** Replaces the notes the rows are drawn with. The caller then calls [notifyItemChanged] for the row(s) that changed. */
    fun setNotes(highlights: List<EpubNotes.Mark>, bookmarks: List<EpubNotes.Place>) {
        marks = EpubNotes.index(highlights)
        val keys = HashSet<Long>()
        for (b in bookmarks) keys.add(EpubNotes.key(b.chapter, b.paragraph))
        bookmarkKeys = keys
    }

    fun setTextSize(sp: Float) {
        textSp = sp
        notifyDataSetChanged()
    }

    fun rowAt(position: Int): Row? = rows.getOrNull(position)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemEpubRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val row = rows[position]
        val tv = holder.binding.tvRow
        if (row.heading) {
            if (tv.isTextSelectable) tv.setTextIsSelectable(false)
            tv.customSelectionActionModeCallback = null
            tv.setTypeface(null, Typeface.BOLD)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp * 1.2f)
            tv.setBackgroundColor(Color.TRANSPARENT)
            tv.text = row.text
            return
        }
        if (!tv.isTextSelectable) tv.setTextIsSelectable(true)
        tv.setTypeface(null, Typeface.NORMAL)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp)
        val key = EpubNotes.key(row.chapter, row.paragraph)
        tv.setBackgroundColor(if (bookmarkKeys.contains(key)) BOOKMARK_TINT else Color.TRANSPARENT)

        val spannable = SpannableString(row.text)
        val list = marks[key]
        if (list != null) {
            for (m in list) {
                val end = minOf(m.end, row.text.length)
                if (m.start >= end) continue
                spannable.setSpan(BackgroundColorSpan(HIGHLIGHT_BACKGROUND), m.start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                spannable.setSpan(ForegroundColorSpan(HIGHLIGHT_TEXT), m.start, end, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
        tv.text = spannable

        tv.customSelectionActionModeCallback = object : ActionMode.Callback {
            override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
                menu.add(0, ID_HIGHLIGHT, 0, R.string.epub_reader_highlight)
                menu.add(0, ID_UNHIGHLIGHT, 1, R.string.epub_reader_unhighlight)
                return true
            }

            override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean = false

            override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
                if (item.itemId != ID_HIGHLIGHT && item.itemId != ID_UNHIGHLIGHT) return false
                val a = tv.selectionStart
                val b = tv.selectionEnd
                mode.finish()
                if (a >= 0 && b >= 0 && a != b) onSelection(row, minOf(a, b), maxOf(a, b), item.itemId == ID_UNHIGHLIGHT)
                return true
            }

            override fun onDestroyActionMode(mode: ActionMode) {}
        }
    }

    override fun getItemCount(): Int = rows.size

    companion object {
        private const val ID_HIGHLIGHT = 0x7e01
        private const val ID_UNHIGHLIGHT = 0x7e02
        private val HIGHLIGHT_BACKGROUND = Color.parseColor("#FFEB3B")
        private val HIGHLIGHT_TEXT = Color.parseColor("#000000")
        private val BOOKMARK_TINT = Color.parseColor("#33FFC107")
    }
}
