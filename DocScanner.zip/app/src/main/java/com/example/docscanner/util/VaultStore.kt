package com.example.docscanner.util

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.io.OutputStream
import java.io.RandomAccessFile
import java.security.KeyStore
import java.util.UUID
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

/**
 * The encrypted folder "Két an toàn" on the device (phiên 17, mục 4.31): files are encrypted with [VaultCrypto] and stored as `<random>.dsv` in `filesDir/vault`
 * (the file name is INSIDE the encrypted data, so the folder shows nothing but sizes). The master key is an AES-256-GCM key created in the Android Keystore - hardware-backed
 * where the phone has it - and it never leaves it: the app only asks the Keystore to wrap and unwrap the per-file keys.
 *
 * Consequences worth knowing (also shown to the person): the vault is NOT in backups (`allowBackup=false`, and a Keystore key cannot be restored on another phone) - a lost phone
 * or a factory reset means the vault is gone; and when the phone's screen lock is removed or reset, Android may delete Keystore keys (this key does not require user
 * authentication per use, so ordinary lock changes do not affect it, but a factory reset does). Opening a file decrypts it into the cache folder; [clearTemp] wipes that on leaving the screen
 * and at app start.
 * "Add" is safe against loss: the file is encrypted to a `.part` file, DECRYPTED AGAIN to count its bytes and compare the name, and only then renamed in and the original wiped.
 * "Wipe" overwrites with zeros before deleting; on flash storage with wear levelling that is best effort, not a guarantee (the encryption is what protects the content).
 * Android-only glue (Keystore, files); the cryptography itself is [VaultCrypto], checked against an independent implementation in tools/verify/vault_check.py.
 */
object VaultStore {

    private const val ALIAS = "docscanner_vault_master_v1"
    private const val EXT = "dsv"

    class Item(val file: File, val name: String?, val size: Long)

    fun dir(context: Context): File = File(context.filesDir, "vault").also { if (!it.exists()) it.mkdirs() }

    fun tempDir(context: Context): File = File(context.cacheDir, "vault_tmp").also { if (!it.exists()) it.mkdirs() }

    fun masterKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    /** Overwrites [file] with zeros (best effort) and deletes it. */
    fun wipe(file: File) {
        try {
            if (file.isFile && file.length() > 0) {
                RandomAccessFile(file, "rws").use { raf ->
                    val zeros = ByteArray(64 * 1024)
                    var left = raf.length()
                    raf.seek(0)
                    while (left > 0) {
                        val n = minOf(left, zeros.size.toLong()).toInt()
                        raf.write(zeros, 0, n)
                        left -= n
                    }
                    raf.fd.sync()
                }
            }
        } catch (t: Throwable) {
            // wiping is best effort
        }
        file.delete()
    }

    private class CountingSink : OutputStream() {
        var count = 0L
        override fun write(b: Int) { count++ }
        override fun write(b: ByteArray, off: Int, len: Int) { count += len }
    }

    /** Encrypts [source] into the vault; on success the original is wiped. @return the vault file, or null if anything failed (the original is then untouched). */
    fun add(context: Context, source: File): File? {
        val key = masterKey()
        val out = File(dir(context), UUID.randomUUID().toString() + "." + EXT)
        val part = File(out.parentFile, out.name + ".part")
        try {
            source.inputStream().buffered().use { input -> part.outputStream().buffered().use { VaultCrypto.encrypt(key, source.name, input, it) } }
            val sink = CountingSink()
            val storedName = part.inputStream().buffered().use { VaultCrypto.decrypt(key, it, sink) }
            if (storedName != source.name || sink.count != source.length()) throw IllegalStateException("verification failed")
            if (!part.renameTo(out)) throw IllegalStateException("rename failed")
        } catch (t: Throwable) {
            part.delete()
            out.delete()
            return null
        }
        wipe(source)
        return out
    }

    /** Every vault file with its name (read from the first encrypted chunk only); a file that cannot be read has a null name. Sorted by name. */
    fun list(context: Context): List<Item> {
        val key = masterKey()
        val items = (dir(context).listFiles { f -> f.isFile && f.extension == EXT } ?: emptyArray()).map { f ->
            val name = try { f.inputStream().buffered().use { VaultCrypto.peekName(key, it) } } catch (t: Throwable) { null }
            Item(f, name, f.length())
        }
        return items.sortedWith(compareBy({ it.name == null }, { it.name?.lowercase() ?: it.file.name }))
    }

    private fun decryptTo(item: Item, target: File): Boolean {
        val key = masterKey()
        return try {
            item.file.inputStream().buffered().use { input -> target.outputStream().buffered().use { output -> VaultCrypto.decrypt(key, input, output) } }
            true
        } catch (t: Throwable) {
            wipe(target)
            false
        }
    }

    /** Decrypts into the cache folder for viewing. @return the temporary plain file, or null. */
    fun openTemp(context: Context, item: Item): File? {
        val name = item.name ?: return null
        val target = SmartNamer.uniqueFile(tempDir(context), name.substringBeforeLast('.', name), name.substringAfterLast('.', ""))
        return if (decryptTo(item, target)) target else null
    }

    /** Decrypts into [exportDir] under its own name (a taken name gets " (2)"), then removes it from the vault. @return the file, or null (nothing removed). */
    fun takeOut(item: Item, exportDir: File): File? {
        val name = item.name ?: return null
        val target = SmartNamer.uniqueFile(exportDir, name.substringBeforeLast('.', name), name.substringAfterLast('.', ""))
        if (!decryptTo(item, target)) return null
        wipe(item.file)
        return target
    }

    fun clearTemp(context: Context) {
        tempDir(context).listFiles()?.forEach { wipe(it) }
    }
}
