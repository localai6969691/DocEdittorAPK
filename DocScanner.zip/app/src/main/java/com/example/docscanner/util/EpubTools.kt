package com.example.docscanner.util

import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.StringReader
import java.nio.charset.StandardCharsets
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.transform.OutputKeys
import javax.xml.transform.TransformerFactory
import javax.xml.transform.dom.DOMSource
import javax.xml.transform.stream.StreamResult
import org.w3c.dom.Document
import org.w3c.dom.Element
import org.xml.sax.InputSource

/**
 * Sua thong tin, doi anh bia, ghep va tach EPUB o MUC GOI ZIP (khong doc lai qua van ban nhu [EpubReader]), nen anh, CSS, phong chu va
 * cau truc duoc giu nguyen. Chi dung `java.util.zip` + DOM cua JDK/Android. Ban Java chay duoc: `tools/verify/EpubToolsCheck.java`,
 * kiem chung bang `tools/verify/epub_tools_check.py` (zipfile, lxml, pandoc); hai ban PHAI giu cung thuat toan.
 *
 * Quy tac: tep dau ra luon co `mimetype` dau tien va KHONG nen (OCF); ghi ra `.part` roi doi ten; tep nguon khong bao gio bi sua.
 */
object EpubTools {
    private const val DC = "http://purl.org/dc/elements/1.1/"
    private const val OPF = "http://www.idpf.org/2007/opf"
    private const val OPS = "http://www.idpf.org/2007/ops"
    private const val MIME = "application/epub+zip"

    data class Meta(val title: String, val authors: List<String>, val language: String, val publisher: String, val description: String, val identifier: String)

    // ---------------------------------------------------------------- duong dan
    internal fun norm(p: String): String {
        val out = ArrayList<String>()
        for (s in p.split('/')) {
            if (s.isEmpty() || s == ".") continue
            if (s == "..") { if (out.isNotEmpty()) out.removeAt(out.size - 1); continue }
            out.add(s)
        }
        return out.joinToString("/")
    }

    private fun hexVal(c: Int): Int = when (c) {
        in '0'.code..'9'.code -> c - '0'.code
        in 'a'.code..'f'.code -> c - 'a'.code + 10
        in 'A'.code..'F'.code -> c - 'A'.code + 10
        else -> -1
    }

    internal fun percentDecode(s: String): String {
        if (s.indexOf('%') < 0) return s
        val raw = s.toByteArray(StandardCharsets.UTF_8)
        val b = ByteArrayOutputStream()
        var i = 0
        while (i < raw.size) {
            val c = raw[i].toInt() and 0xFF
            if (c == '%'.code && i + 2 < raw.size && hexVal(raw[i + 1].toInt()) >= 0 && hexVal(raw[i + 2].toInt()) >= 0) {
                b.write(hexVal(raw[i + 1].toInt()) * 16 + hexVal(raw[i + 2].toInt())); i += 3
            } else { b.write(c); i++ }
        }
        return String(b.toByteArray(), StandardCharsets.UTF_8)
    }

    private val SCHEME = Regex("^[A-Za-z][A-Za-z0-9+.\\-]*:.*")

    /** Duong dan trong goi (da giai ma %) cua tham chieu [ref] viet trong tep [base]; null neu la lien ket ngoai hoac rong. */
    internal fun resolve(base: String, ref: String): String? {
        var r = ref.trim()
        val h = r.indexOf('#'); if (h >= 0) r = r.substring(0, h)
        val q = r.indexOf('?'); if (q >= 0) r = r.substring(0, q)
        if (r.isEmpty()) return null
        if (SCHEME.matches(r) || r.startsWith("//")) return null
        r = percentDecode(r)
        if (r.startsWith("/")) return norm(r.substring(1))
        val dir = if (base.contains('/')) base.substring(0, base.lastIndexOf('/') + 1) else ""
        return norm(dir + r)
    }

    /** Ma hoa % cho nhung ky tu co the lam hong IRI trong thuoc tinh href. */
    internal fun enc(path: String): String {
        val sb = StringBuilder()
        for (c in path) {
            if (c == ' ' || c == '%' || c == '#' || c == '?' || c == '"' || c == '<' || c == '>') sb.append(String.format("%%%02X", c.code)) else sb.append(c)
        }
        return sb.toString()
    }

    internal fun relFrom(fromFile: String, target: String): String {
        val from = (if (fromFile.contains('/')) fromFile.substring(0, fromFile.lastIndexOf('/')) else "").split('/').filter { it.isNotEmpty() }
        val to = target.split('/').filter { it.isNotEmpty() }
        var i = 0
        while (i < from.size && i < to.size - 1 && from[i] == to[i]) i++
        val sb = StringBuilder()
        for (k in i until from.size) sb.append("../")
        for (k in i until to.size) { sb.append(to[k]); if (k < to.size - 1) sb.append('/') }
        return sb.toString()
    }

    // ---------------------------------------------------------------- XML
    private fun parse(data: ByteArray): Document {
        val f = DocumentBuilderFactory.newInstance()
        f.isNamespaceAware = true
        try { f.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false) } catch (_: Exception) { }
        val b = f.newDocumentBuilder()
        b.setEntityResolver { _, _ -> InputSource(StringReader("")) }
        return b.parse(ByteArrayInputStream(data))
    }

    private fun serialize(d: Document): ByteArray {
        val t = TransformerFactory.newInstance().newTransformer()
        t.setOutputProperty(OutputKeys.ENCODING, "UTF-8")
        t.setOutputProperty(OutputKeys.METHOD, "xml")
        val o = ByteArrayOutputStream()
        t.transform(DOMSource(d), StreamResult(o))
        return o.toByteArray()
    }

    internal fun esc(s: String): String {
        val sb = StringBuilder()
        for (c in s) {
            when {
                c == '&' -> sb.append("&amp;")
                c == '<' -> sb.append("&lt;")
                c == '>' -> sb.append("&gt;")
                c == '"' -> sb.append("&quot;")
                c.code < 0x20 && c != '\t' && c != '\n' && c != '\r' -> Unit   // ky tu cam cua XML 1.0
                else -> sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun hasToken(s: String, t: String): Boolean = s.trim().split(Regex("\\s+")).any { it == t }

    private fun children(e: Element, ns: String?, local: String): List<Element> {
        val r = ArrayList<Element>()
        var n = e.firstChild
        while (n != null) {
            if (n is Element && local == n.localName && (ns == null || ns == n.namespaceURI)) r.add(n)
            n = n.nextSibling
        }
        return r
    }

    // ---------------------------------------------------------------- goi
    private class Item(val id: String, val href: String, val path: String, val type: String, val props: String, val fallback: String)
    private class Ref(val idref: String, val linear: String)
    private class Pkg(val zip: ZipFile, val opfPath: String, val opfDir: String, val version: String, val doc: Document) {
        val items = ArrayList<Item>()
        val byId = HashMap<String, Item>()
        val byPath = HashMap<String, Item>()
        val spine = ArrayList<Ref>()
        var nav: Item? = null
        var ncx: Item? = null

        fun coverId(): String? {
            for (i in items) if (hasToken(i.props, "cover-image")) return i.id
            val ms = doc.getElementsByTagNameNS("*", "meta")
            for (k in 0 until ms.length) {
                val m = ms.item(k) as Element
                if (m.getAttribute("name") == "cover" && byId.containsKey(m.getAttribute("content"))) return m.getAttribute("content")
            }
            return null
        }
    }

    private fun readEntry(z: ZipFile, name: String): ByteArray? {
        val e = z.getEntry(name) ?: return null
        return z.getInputStream(e).use { it.readBytes() }
    }

    private fun load(z: ZipFile): Pkg {
        val c = readEntry(z, "META-INF/container.xml") ?: throw IOException("khong co container.xml")
        val rf = parse(c).getElementsByTagNameNS("*", "rootfile")
        if (rf.length == 0) throw IOException("khong co rootfile")
        val opfPath = norm(percentDecode((rf.item(0) as Element).getAttribute("full-path")))
        val opfDir = if (opfPath.contains('/')) opfPath.substring(0, opfPath.lastIndexOf('/')) else ""
        val o = readEntry(z, opfPath) ?: throw IOException("khong co tep OPF")
        val doc = parse(o)
        val p = Pkg(z, opfPath, opfDir, doc.documentElement.getAttribute("version"), doc)
        val its = doc.getElementsByTagNameNS("*", "item")
        for (k in 0 until its.length) {
            val e = its.item(k) as Element
            val id = e.getAttribute("id")
            val path = resolve(opfPath, e.getAttribute("href"))
            if (id.isEmpty() || path == null) continue
            val item = Item(id, e.getAttribute("href"), path, e.getAttribute("media-type"), e.getAttribute("properties"), e.getAttribute("fallback"))
            p.items.add(item); p.byId[id] = item; p.byPath[path] = item
            if (hasToken(item.props, "nav")) p.nav = item
            if (item.type == "application/x-dtbncx+xml") p.ncx = item
        }
        val refs = doc.getElementsByTagNameNS("*", "itemref")
        for (k in 0 until refs.length) {
            val e = refs.item(k) as Element
            val r = Ref(e.getAttribute("idref"), e.getAttribute("linear"))
            if (p.byId.containsKey(r.idref)) p.spine.add(r)
        }
        return p
    }

    private fun isDoc(i: Item): Boolean = i.type == "application/xhtml+xml" || i.type == "text/html"

    /** So muc trong spine (thu tu doc) - de nguoi dung chon khoang khi tach. */
    fun spineSize(epub: File): Int = ZipFile(epub).use { load(it).spine.size }

    // ---------------------------------------------------------------- thong tin
    fun readMeta(epub: File): Meta = ZipFile(epub).use { z ->
        val p = load(z)
        val ml = p.doc.getElementsByTagNameNS("*", "metadata")
        if (ml.length == 0) return@use Meta("", emptyList(), "", "", "", "")
        val m = ml.item(0) as Element
        val uid = p.doc.documentElement.getAttribute("unique-identifier")
        val title = children(m, DC, "title").firstOrNull()?.textContent?.trim() ?: ""
        val authors = children(m, DC, "creator").map { it.textContent.trim() }.filter { it.isNotEmpty() }
        val lang = children(m, DC, "language").firstOrNull()?.textContent?.trim() ?: ""
        val pub = children(m, DC, "publisher").firstOrNull()?.textContent?.trim() ?: ""
        val desc = children(m, DC, "description").firstOrNull()?.textContent?.trim() ?: ""
        var ident = ""
        for (e in children(m, DC, "identifier")) if (ident.isEmpty() || e.getAttribute("id") == uid) ident = e.textContent.trim()
        Meta(title, authors, lang, pub, desc, ident)
    }

    private fun putStored(out: ZipOutputStream, name: String, data: ByteArray) {
        val e = ZipEntry(name)
        e.method = ZipEntry.STORED; e.size = data.size.toLong(); e.compressedSize = data.size.toLong()
        val c = CRC32(); c.update(data); e.crc = c.value
        out.putNextEntry(e); out.write(data); out.closeEntry()
    }

    private fun put(out: ZipOutputStream, name: String, b: ByteArray) { out.putNextEntry(ZipEntry(name)); out.write(b); out.closeEntry() }

    private fun finish(tmp: File, dst: File) {
        if (dst.exists() && !dst.delete()) { tmp.delete(); throw IOException("khong ghi de duoc dich") }
        if (!tmp.renameTo(dst)) { tmp.delete(); throw IOException("khong doi ten duoc") }
    }

    /** Chep [src] sang [dst]: mimetype dau tien, khong nen; [replace] doi noi dung tep, [skip] bo tep, [extra] them tep moi o cuoi. */
    private fun rewrite(src: File, dst: File, replace: Map<String, ByteArray>, skip: Set<String>, extra: Map<String, ByteArray>) {
        val tmp = File(dst.path + ".part")
        try {
            ZipFile(src).use { z ->
                ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { out ->
                    putStored(out, "mimetype", MIME.toByteArray(StandardCharsets.US_ASCII))
                    for (e in z.entries()) {
                        val n = e.name
                        if (n == "mimetype" || e.isDirectory || n in skip) continue
                        val data = replace[n] ?: readEntry(z, n) ?: continue
                        put(out, n, data)
                    }
                    for ((n, b) in extra) put(out, n, b)
                }
            }
        } catch (e: Exception) { tmp.delete(); throw e }
        finish(tmp, dst)
    }

    private fun dc(d: Document, local: String, text: String): Element {
        val e = d.createElementNS(DC, "dc:$local"); e.textContent = text; return e
    }

    /** Ghi thong tin moi vao [dst]. Ten / ngon ngu de trong thi giu gia tri cu; tac gia, nha xuat ban, mo ta de trong thi bi xoa. */
    fun writeMeta(src: File, dst: File, meta: Meta, nowIso: String) {
        val opfPath: String
        val opfBytes: ByteArray
        ZipFile(src).use { z ->
            val p = load(z); opfPath = p.opfPath
            val d = p.doc
            val ml = d.getElementsByTagNameNS("*", "metadata")
            if (ml.length == 0) throw IOException("OPF khong co metadata")
            val m = ml.item(0) as Element
            val oldTitle = children(m, DC, "title").firstOrNull()?.textContent?.trim() ?: ""
            val oldLang = children(m, DC, "language").firstOrNull()?.textContent?.trim() ?: ""
            val title = if (meta.title.trim().isEmpty()) oldTitle else meta.title.trim()
            val lang = if (meta.language.trim().isEmpty()) oldLang else meta.language.trim()
            val managed = ArrayList<Element>()
            for (n in listOf("title", "creator", "language", "publisher", "description")) managed.addAll(children(m, DC, n))
            val anchor = managed.firstOrNull()
            val fresh = ArrayList<Element>()
            fresh.add(dc(d, "title", title))
            for (a in meta.authors) if (a.trim().isNotEmpty()) fresh.add(dc(d, "creator", a.trim()))
            if (lang.isNotEmpty()) fresh.add(dc(d, "language", lang))
            if (meta.publisher.trim().isNotEmpty()) fresh.add(dc(d, "publisher", meta.publisher.trim()))
            if (meta.description.trim().isNotEmpty()) fresh.add(dc(d, "description", meta.description.trim()))
            for (f in fresh) { if (anchor != null) m.insertBefore(f, anchor) else m.appendChild(f) }
            for (old in managed) m.removeChild(old)
            touchModified(d, m, p.version, nowIso)
            opfBytes = serialize(d)
        }
        rewrite(src, dst, mapOf(opfPath to opfBytes), emptySet(), emptyMap())
    }

    private fun touchModified(d: Document, meta: Element, version: String, nowIso: String) {
        var found = false
        for (e in children(meta, OPF, "meta")) if (e.getAttribute("property") == "dcterms:modified") { e.textContent = nowIso; found = true }
        if (!found && version.startsWith("3")) {
            val e = d.createElementNS(OPF, "meta"); e.setAttribute("property", "dcterms:modified"); e.textContent = nowIso; meta.appendChild(e)
        }
    }

    // ---------------------------------------------------------------- bia
    fun imageMediaType(ext: String): String? = when (ext.lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"; "png" -> "image/png"; "gif" -> "image/gif"; "webp" -> "image/webp"; else -> null
    }

    /**
     * Thay anh bia. Sach DA co anh bia -> GHI DE noi dung tai CHINH duong dan cu (trang bia XHTML tro toi tep do van dung) va doi media-type theo anh moi;
     * chua co -> them muc moi + `<meta name="cover">` (+ `properties="cover-image"` voi EPUB3).
     */
    fun setCover(src: File, dst: File, image: ByteArray, ext: String, nowIso: String) {
        val mt = imageMediaType(ext) ?: throw IOException("dinh dang anh khong ho tro: $ext")
        val rep = HashMap<String, ByteArray>()
        val extra = LinkedHashMap<String, ByteArray>()
        ZipFile(src).use { z ->
            val p = load(z); val d = p.doc; val cid = p.coverId()
            val ml = d.getElementsByTagNameNS("*", "metadata"); val mf = d.getElementsByTagNameNS("*", "manifest")
            if (ml.length == 0 || mf.length == 0) throw IOException("OPF thieu metadata/manifest")
            val meta = ml.item(0) as Element; val man = mf.item(0) as Element
            if (cid != null) {
                rep[p.byId.getValue(cid).path] = image
                for (e in children(man, OPF, "item")) if (cid == e.getAttribute("id")) e.setAttribute("media-type", mt)
            } else {
                val name = "images/docscanner-cover." + ext.lowercase().replace("jpeg", "jpg")
                var path = norm((if (p.opfDir.isEmpty()) "" else p.opfDir + "/") + name)
                while (z.getEntry(path) != null) path = path.replace("docscanner-cover", "docscanner-cover-1")
                var id = "docscanner-cover"
                while (p.byId.containsKey(id)) id += "-1"
                val e = d.createElementNS(OPF, "item")
                e.setAttribute("id", id); e.setAttribute("href", enc(relFrom(p.opfPath, path))); e.setAttribute("media-type", mt)
                if (p.version.startsWith("3")) e.setAttribute("properties", "cover-image")
                man.appendChild(e)
                val m2 = d.createElementNS(OPF, "meta"); m2.setAttribute("name", "cover"); m2.setAttribute("content", id); meta.appendChild(m2)
                extra[path] = image
            }
            if (p.version.startsWith("3")) touchModified(d, meta, p.version, nowIso)
            rep[p.opfPath] = serialize(d)
        }
        rewrite(src, dst, rep, emptySet(), extra)
    }

    // ---------------------------------------------------------------- muc luc goc
    private class Toc(val title: String, val path: String, val frag: String)

    private fun tocOf(p: Pkg): List<Toc> {
        val out = ArrayList<Toc>()
        p.nav?.let { nav ->
            readEntry(p.zip, nav.path)?.let { b ->
                val d = parse(b); val navs = d.getElementsByTagNameNS("*", "nav")
                var toc: Element? = null
                for (i in 0 until navs.length) { val e = navs.item(i) as Element; if (hasToken(e.getAttributeNS(OPS, "type"), "toc")) { toc = e; break } }
                if (toc == null && navs.length > 0) toc = navs.item(0) as Element
                if (toc != null) {
                    val a = toc.getElementsByTagNameNS("*", "a")
                    for (i in 0 until a.length) { val el = a.item(i) as Element; addToc(out, nav.path, el.getAttribute("href"), el.textContent) }
                }
            }
        }
        if (out.isEmpty()) p.ncx?.let { ncx ->
            readEntry(p.zip, ncx.path)?.let { b ->
                val d = parse(b); val pts = d.getElementsByTagNameNS("*", "navPoint")
                for (i in 0 until pts.length) {
                    val np = pts.item(i) as Element
                    val t = np.getElementsByTagNameNS("*", "text"); val c = np.getElementsByTagNameNS("*", "content")
                    if (t.length > 0 && c.length > 0) addToc(out, ncx.path, (c.item(0) as Element).getAttribute("src"), t.item(0).textContent)
                }
            }
        }
        return out
    }

    private fun addToc(out: MutableList<Toc>, base: String, href: String, title: String) {
        val path = resolve(base, href); val t = title.replace(Regex("\\s+"), " ").trim()
        if (path == null || t.isEmpty()) return
        val h = href.indexOf('#')
        out.add(Toc(t, path, if (h >= 0) href.substring(h + 1) else ""))
    }

    // ---------------------------------------------------------------- tham chieu (cat tia ban)
    private val ATTR = java.util.regex.Pattern.compile("(?:\\bsrc|\\bhref|\\bposter|\\bdata|xlink:href)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')", java.util.regex.Pattern.CASE_INSENSITIVE)
    private val CSSURL = java.util.regex.Pattern.compile("url\\(\\s*(?:\"([^\"]*)\"|'([^']*)'|([^)\\s]*))\\s*\\)", java.util.regex.Pattern.CASE_INSENSITIVE)
    private val CSSIMPORT = java.util.regex.Pattern.compile("@import\\s+(?:\"([^\"]*)\"|'([^']*)')", java.util.regex.Pattern.CASE_INSENSITIVE)

    private fun refsOf(path: String, text: String): Set<String> {
        val out = LinkedHashSet<String>()
        for (pt in listOf(ATTR, CSSURL, CSSIMPORT)) {
            val m = pt.matcher(text)
            while (m.find()) {
                var v: String? = null
                for (g in 1..m.groupCount()) if (m.group(g) != null) { v = m.group(g); break }
                if (v == null) continue
                resolve(path, v)?.let { out.add(it) }
            }
        }
        return out
    }

    // ---------------------------------------------------------------- ghep / tach
    /** Mot nguon cho [build]: [spine] la cac so thu tu (tu 1) trong spine can giu, null = tat ca. */
    class Source(val file: File, val spine: List<Int>?, val title: String)

    /**
     * Dung mot EPUB moi tu [books] (EPUB 3 kem toc.ncx). Moi sach nam trong thu muc rieng `OEBPS/b<k>/` voi CAY THU MUC GOC cua no, nen moi tham chieu
     * tuong doi trong XHTML / CSS van dung. [prune]: chi giu tai nguyen ma cac trang giu lai (va CSS cua chung) nhac toi + anh bia; lien ket sang
     * trang KHONG giu lai se hong - ghi trong TECHNICAL_DOCS.md 4.35.
     */
    fun build(books: List<Source>, title: String, language: String, authors: List<String>, prune: Boolean, dst: File, nowIso: String, uuid: String, partLabel: (Int) -> String = { "Part $it" }) {
        val files = LinkedHashMap<String, ByteArray>()
        val manifest = StringBuilder(); val spine = StringBuilder(); val navLis = StringBuilder(); val ncxPts = StringBuilder()
        var order = 0
        var firstCoverId: String? = null
        val wrap = books.size > 1
        val open = ArrayList<ZipFile>()
        try {
            for ((bi, s) in books.withIndex()) {
                val z = ZipFile(s.file); open.add(z)
                val p = load(z); val pre = "b" + (bi + 1)
                val keptRefs = ArrayList<Ref>()
                if (s.spine == null) keptRefs.addAll(p.spine) else for (idx in s.spine) if (idx >= 1 && idx <= p.spine.size) keptRefs.add(p.spine[idx - 1])
                if (keptRefs.isEmpty()) throw IOException("khong co muc nao trong " + s.file.name)
                val docPaths = LinkedHashSet<String>(); for (r in keptRefs) docPaths.add(p.byId.getValue(r.idref).path)
                val keep = LinkedHashSet<String>()
                val coverId = p.coverId()
                if (prune) {
                    val queue = kotlin.collections.ArrayDeque<String>(docPaths)
                    val seen = HashSet<String>(docPaths)
                    while (queue.isNotEmpty()) {
                        val cur = queue.removeFirst(); val b = readEntry(z, cur) ?: continue
                        val ci = p.byPath[cur]
                        if (ci != null && !isDoc(ci) && ci.type != "text/css") continue
                        for (r in refsOf(cur, String(b, StandardCharsets.UTF_8))) {
                            val target = p.byPath[r] ?: continue
                            if (target === p.nav || target === p.ncx || isDoc(target)) continue
                            if (seen.add(r)) { keep.add(r); queue.addLast(r) }
                        }
                    }
                    if (coverId != null && bi == 0) keep.add(p.byId.getValue(coverId).path)
                } else {
                    for (itm in p.items) if (itm !== p.nav && itm !== p.ncx && itm.path !in docPaths) keep.add(itm.path)
                }
                val include = LinkedHashSet<String>(docPaths); include.addAll(keep)
                for (itm in p.items) {
                    if (itm.path !in include || itm === p.nav || itm === p.ncx) continue
                    manifest.append("<item id=\"").append(esc(pre + "-" + itm.id)).append("\" href=\"").append(esc(enc(pre + "/" + itm.path))).append("\" media-type=\"").append(esc(itm.type)).append('"')
                    var props = itm.props.trim().split(Regex("\\s+")).filter { x -> x.isNotEmpty() && x != "nav" && x != "cover-image" }.joinToString(" ")
                    if (bi == 0 && itm.id == coverId) props = (props + " cover-image").trim()
                    if (props.isNotEmpty()) manifest.append(" properties=\"").append(esc(props)).append('"')
                    if (itm.fallback.isNotEmpty() && include.contains(p.byId[itm.fallback]?.path ?: "")) manifest.append(" fallback=\"").append(esc(pre + "-" + itm.fallback)).append('"')
                    manifest.append("/>\n")
                    if (bi == 0 && itm.id == coverId) firstCoverId = pre + "-" + itm.id
                }
                for (r in keptRefs) {
                    spine.append("<itemref idref=\"").append(esc(pre + "-" + r.idref)).append('"')
                    if (r.linear.isNotEmpty()) spine.append(" linear=\"").append(esc(r.linear)).append('"')
                    spine.append("/>\n")
                }
                for (path in include) { val b = readEntry(z, path); if (b != null) files["OEBPS/$pre/$path"] = b }
                var toc = tocOf(p).filter { it.path in docPaths }
                if (toc.isEmpty()) toc = docPaths.mapIndexed { k, dp -> Toc(partLabel(k + 1), dp, "") }
                val indent = if (wrap) "  " else ""
                if (wrap) {
                    val firstHref = esc(enc(pre + "/" + docPaths.first()))
                    navLis.append("<li><a href=\"").append(firstHref).append("\">").append(esc(s.title)).append("</a>\n<ol>\n")
                    order++
                    ncxPts.append("<navPoint id=\"np-").append(order).append("\" playOrder=\"").append(order).append("\"><navLabel><text>").append(esc(s.title)).append("</text></navLabel><content src=\"").append(firstHref).append("\"/>\n")
                }
                for (t in toc) {
                    val href = enc(pre + "/" + t.path) + (if (t.frag.isEmpty()) "" else "#" + t.frag)
                    navLis.append(indent).append("<li><a href=\"").append(esc(href)).append("\">").append(esc(t.title)).append("</a></li>\n")
                    order++
                    ncxPts.append(indent).append("<navPoint id=\"np-").append(order).append("\" playOrder=\"").append(order).append("\"><navLabel><text>").append(esc(t.title)).append("</text></navLabel><content src=\"").append(esc(href)).append("\"/></navPoint>\n")
                }
                if (wrap) { navLis.append("</ol></li>\n"); ncxPts.append("</navPoint>\n") }
            }
            val opf = StringBuilder()
            opf.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<package xmlns=\"").append(OPF).append("\" version=\"3.0\" unique-identifier=\"bookid\">\n<metadata xmlns:dc=\"").append(DC).append("\">\n")
            opf.append("<dc:identifier id=\"bookid\">urn:uuid:").append(esc(uuid)).append("</dc:identifier>\n<dc:title>").append(esc(title)).append("</dc:title>\n")
            for (a in authors) opf.append("<dc:creator>").append(esc(a)).append("</dc:creator>\n")
            opf.append("<dc:language>").append(esc(if (language.isEmpty()) "vi" else language)).append("</dc:language>\n<meta property=\"dcterms:modified\">").append(esc(nowIso)).append("</meta>\n")
            if (firstCoverId != null) opf.append("<meta name=\"cover\" content=\"").append(esc(firstCoverId!!)).append("\"/>\n")
            opf.append("</metadata>\n<manifest>\n<item id=\"nav\" href=\"nav.xhtml\" media-type=\"application/xhtml+xml\" properties=\"nav\"/>\n<item id=\"ncx\" href=\"toc.ncx\" media-type=\"application/x-dtbncx+xml\"/>\n")
            opf.append(manifest).append("</manifest>\n<spine toc=\"ncx\">\n").append(spine).append("</spine>\n</package>\n")
            val nav = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:epub=\"$OPS\"><head><title>${esc(title)}</title></head><body>\n<nav epub:type=\"toc\"><h1>${esc(title)}</h1>\n<ol>\n$navLis</ol></nav>\n</body></html>\n"
            val ncx = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ncx xmlns=\"http://www.daisy.org/z3986/2005/ncx/\" version=\"2005-1\"><head><meta name=\"dtb:uid\" content=\"urn:uuid:${esc(uuid)}\"/></head><docTitle><text>${esc(title)}</text></docTitle><navMap>\n$ncxPts</navMap></ncx>\n"
            val container = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<container version=\"1.0\" xmlns=\"urn:oasis:names:tc:opendocument:xmlns:container\"><rootfiles><rootfile full-path=\"OEBPS/content.opf\" media-type=\"application/oebps-package+xml\"/></rootfiles></container>\n"
            val tmp = File(dst.path + ".part")
            try {
                ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { out ->
                    putStored(out, "mimetype", MIME.toByteArray(StandardCharsets.US_ASCII))
                    put(out, "META-INF/container.xml", container.toByteArray(StandardCharsets.UTF_8))
                    put(out, "OEBPS/content.opf", opf.toString().toByteArray(StandardCharsets.UTF_8))
                    put(out, "OEBPS/nav.xhtml", nav.toByteArray(StandardCharsets.UTF_8))
                    put(out, "OEBPS/toc.ncx", ncx.toByteArray(StandardCharsets.UTF_8))
                    for ((n, b) in files) put(out, n, b)
                }
            } catch (e: Exception) { tmp.delete(); throw e }
            finish(tmp, dst)
        } finally {
            for (z in open) try { z.close() } catch (_: IOException) { }
        }
    }

    /**
     * Cac khoang cua [spec] ("1-3, 5, 8-"; "-4" = tu dau; "8-" = den het) tren [n] muc, moi khoang la mot phan. Nghiem ngat: phan rong, so khong hop le,
     * ngoai [1, n] hoac nguoc deu la LOI (null), khong cat lang le.
     */
    fun parseParts(spec: String, n: Int): List<List<Int>>? {
        val parts = ArrayList<List<Int>>()
        for (piece in spec.split(',')) {
            val t = piece.trim()
            if (t.isEmpty()) return null
            val a: Int; val b: Int
            val dash = t.indexOf('-')
            try {
                if (dash < 0) { a = t.toInt(); b = a }
                else {
                    val lo = t.substring(0, dash).trim(); val hi = t.substring(dash + 1).trim()
                    a = if (lo.isEmpty()) 1 else lo.toInt()
                    b = if (hi.isEmpty()) n else hi.toInt()
                }
            } catch (_: NumberFormatException) { return null }
            if (a < 1 || b > n || a > b) return null
            parts.add((a..b).toList())
        }
        return parts
    }
}
