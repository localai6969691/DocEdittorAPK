package com.example.docscanner.util

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import androidx.appcompat.app.AlertDialog
import com.example.docscanner.R

/**
 * Warns BEFORE a long, CPU-heavy job when the phone is nearly out of battery or too hot (PDF "Thieu gi de ban app" 2.15 low battery, 2.16 thermal status;
 * TECHNICAL_DOCS.md 4.63). The person always decides: the dialog has "Continue anyway". When nothing is wrong [guard] runs the job at once, without any
 * dialog, so a phone in good shape sees no change at all.
 *
 * The decision itself ([advise], [percentOf], [isCharging], [needsAsk]) is pure; `tools/verify/BatchQueueCheck.java` is a Java copy checked against an
 * independent Python model by `batch_queue_check.py`. Reading the real battery and thermal state ([advice]) is Android and is NOT tested here.
 */
object DeviceLoad {

    /** What to tell the person; the order is the order of severity inside each family (battery 1-2, heat 3-4). */
    enum class Advice { NONE, BATTERY_LOW, BATTERY_CRITICAL, HOT, VERY_HOT }

    const val BATTERY_LOW_PERCENT = 15
    const val BATTERY_CRITICAL_PERCENT = 5

    /** PowerManager.THERMAL_STATUS_SEVERE (3) and THERMAL_STATUS_CRITICAL (4); MODERATE (2) is normal for a busy phone and is NOT warned about. */
    const val THERMAL_HOT = 3
    const val THERMAL_VERY_HOT = 4

    /** After "Continue anyway" the same warning is not repeated for this long (a batch of jobs would otherwise ask every time). */
    const val SNOOZE_MS = 10 * 60 * 1000L

    @Volatile private var snoozedUntil = 0L
    @Volatile private var snoozedAdvice = Advice.NONE

    /** [percent] < 0 means unknown, [thermalStatus] < 0 means unknown (Android 9 and older give no thermal status). Heat is judged first: a hot phone on the charger is still hot. */
    fun advise(percent: Int, charging: Boolean, thermalStatus: Int): Advice {
        if (thermalStatus >= THERMAL_VERY_HOT) return Advice.VERY_HOT
        if (thermalStatus >= THERMAL_HOT) return Advice.HOT
        if (!charging && percent >= 0 && percent <= BATTERY_CRITICAL_PERCENT) return Advice.BATTERY_CRITICAL
        if (!charging && percent >= 0 && percent <= BATTERY_LOW_PERCENT) return Advice.BATTERY_LOW
        return Advice.NONE
    }

    /** Battery level 0..100 from the sticky battery broadcast (EXTRA_LEVEL / EXTRA_SCALE); -1 when the numbers are missing or nonsense. */
    fun percentOf(level: Int, scale: Int): Int {
        if (level < 0 || scale <= 0) return -1
        return (level.toLong() * 100L / scale.toLong()).toInt().coerceIn(0, 100)
    }

    /** EXTRA_PLUGGED != 0 means a charger or dock is connected; BATTERY_STATUS_CHARGING (2) and BATTERY_STATUS_FULL (5) also mean "on power". */
    fun isCharging(plugged: Int, status: Int): Boolean = plugged != 0 || status == 2 || status == 5

    /** Ask unless the person already chose to continue with the SAME warning less than [SNOOZE_MS] ago; a different or worse warning asks again. */
    fun needsAsk(advice: Advice, now: Long, snoozedUntil: Long, snoozedAdvice: Advice): Boolean =
        advice != Advice.NONE && !(now < snoozedUntil && advice == snoozedAdvice)

    /** Reads the real battery and heat; any failure counts as "unknown" (no warning) because a warning must never block the app. */
    fun advice(context: Context): Advice {
        return try {
            val battery = context.applicationContext.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val percent = if (battery == null) -1 else percentOf(
                battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1),
                battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            )
            val charging = battery != null && isCharging(
                battery.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0),
                battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            )
            var thermal = -1
            if (Build.VERSION.SDK_INT >= 29) {
                val power = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
                if (power != null) thermal = power.currentThermalStatus
            }
            advise(percent, charging, thermal)
        } catch (e: Exception) {
            Advice.NONE
        }
    }

    /**
     * Runs [proceed] now when all is well; otherwise shows the warning first and runs it only on "Continue anyway". [onCancel] runs when the person
     * backs out (Cancel button, back key, tap outside) - screens that exist only to run the job pass `{ finish() }` so they do not stay open empty.
     */
    fun guard(activity: Activity, onCancel: () -> Unit = {}, proceed: () -> Unit) {
        val advice = advice(activity)
        if (!needsAsk(advice, System.currentTimeMillis(), snoozedUntil, snoozedAdvice)) {
            proceed()
            return
        }
        AlertDialog.Builder(activity)
            .setTitle(R.string.load_warn_title)
            .setMessage(messageFor(advice))
            .setPositiveButton(R.string.load_warn_continue) { _, _ ->
                snoozedUntil = System.currentTimeMillis() + SNOOZE_MS
                snoozedAdvice = advice
                proceed()
            }
            .setNegativeButton(R.string.dialog_cancel) { _, _ -> onCancel() }
            .setOnCancelListener { onCancel() }
            .show()
    }

    private fun messageFor(advice: Advice): Int = when (advice) {
        Advice.BATTERY_LOW -> R.string.load_warn_battery_low
        Advice.BATTERY_CRITICAL -> R.string.load_warn_battery_critical
        Advice.HOT -> R.string.load_warn_hot
        else -> R.string.load_warn_very_hot
    }
}
