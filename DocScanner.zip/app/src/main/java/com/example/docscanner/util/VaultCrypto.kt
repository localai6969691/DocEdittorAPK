package com.example.docscanner.util

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.io.PushbackInputStream
import java.security.SecureRandom
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * File encryption of the vault "Két an toàn" (phiên 17, mục 4.31). Plain javax.crypto (AES-256-GCM), no extra library, runs on any JVM - which is what lets it be
 * checked against an independent implementation (`cryptography` in Python) in tools/verify/vault_check.py.
 *
 * Why this shape (researched, not invented): androidx.security-crypto's EncryptedFile is deprecated, and Tink's streaming AEAD is the recommended replacement; its
 * construction is the STREAM design of Hoang, Reyhanitabar, Rogaway, Vizár ("Online Authenticated-Encryption and its Nonce-Reuse Misuse-Resistance"), reproduced here with
 * the platform's AES-GCM so no dependency is added:
 *
 *   file    = header | chunk_0 | chunk_1 | ... | chunk_n
 *   header  = "DSV1" | version(1) | chunkLog2(1) | wrapLen(2, BE) | wrapped | noncePrefix(7)
 *   wrapped = ivLen(1) | iv(12) | AES-GCM(masterKey, iv, aad = "DSV1" + version + chunkLog2)( fileKey(32) )
 *   chunk_i = AES-GCM(fileKey, nonce_i, aad = header)( plaintext_i )        plaintext_i = 64 KiB, the last one 1..64 KiB
 *   nonce_i = noncePrefix(7) | i (4, BE) | last(1)                       last = 1 only for the final chunk
 *   plaintext = nameLen(2, BE) | name (UTF-8, 1..1024 bytes) | file bytes
 *
 * What each part buys: a fresh random file key per file means the 96-bit nonces never repeat under one key; the counter makes chunks impossible to reorder or repeat;
 * the "last" flag makes truncation (dropping the final chunks) fail authentication; the header is authenticated as AAD of every chunk, so no field can be changed; the
 * master key (in the Android Keystore, never exported - see [VaultStore]) only wraps the 32-byte file key. The file name travels INSIDE the encrypted data (first chunk),
 * so the vault folder reveals nothing but sizes; [peekName] reads only that chunk.
 * Decryption hands plaintext to the caller chunk by chunk, each already authenticated; on any failure it throws [TamperedException] and the caller must discard the output.
 * Mirrored in tools/verify/VaultCryptoCheck.java.
 */
object VaultCrypto {

    private val MAGIC = byteArrayOf('D'.code.toByte(), 'S'.code.toByte(), 'V'.code.toByte(), '1'.code.toByte())
    const val VERSION = 1
    const val CHUNK_LOG2 = 16
    const val CHUNK = 1 shl CHUNK_LOG2
    const val TAG_BYTES = 16
    const val MAX_NAME_BYTES = 1024
    private const val KEY_BYTES = 32
    private const val PREFIX_BYTES = 7
    private const val IV_BYTES = 12

    class TamperedException(message: String) : Exception(message)

    private val PARAMS_AAD = MAGIC + byteArrayOf(VERSION.toByte(), CHUNK_LOG2.toByte())

    private fun nonce(prefix: ByteArray, index: Long, last: Boolean): ByteArray {
        val n = ByteArray(12)
        System.arraycopy(prefix, 0, n, 0, PREFIX_BYTES)
        n[7] = (index ushr 24).toByte(); n[8] = (index ushr 16).toByte(); n[9] = (index ushr 8).toByte(); n[10] = index.toByte()
        n[11] = if (last) 1 else 0
        return n
    }

    private fun gcm(mode: Int, key: ByteArray, nonce: ByteArray, aad: ByteArray): Cipher =
        Cipher.getInstance("AES/GCM/NoPadding").also {
            it.init(mode, SecretKeySpec(key, "AES"), GCMParameterSpec(TAG_BYTES * 8, nonce))
            it.updateAAD(aad)
        }

    /** Reads up to [buf].size bytes, stopping only at the end of the stream. */
    private fun readUpTo(input: InputStream, buf: ByteArray): Int {
        var n = 0
        while (n < buf.size) {
            val r = input.read(buf, n, buf.size - n)
            if (r < 0) break
            n += r
        }
        return n
    }

    fun encrypt(master: SecretKey, name: String, input: InputStream, output: OutputStream, random: SecureRandom = SecureRandom()) {
        val nameBytes = name.toByteArray(Charsets.UTF_8)
        require(nameBytes.size in 1..MAX_NAME_BYTES) { "name must be 1..$MAX_NAME_BYTES bytes in UTF-8" }
        val fileKey = ByteArray(KEY_BYTES).also { random.nextBytes(it) }
        val prefix = ByteArray(PREFIX_BYTES).also { random.nextBytes(it) }

        val wrapCipher = Cipher.getInstance("AES/GCM/NoPadding")
        wrapCipher.init(Cipher.ENCRYPT_MODE, master)          // the provider picks the IV (the Android Keystore insists on it)
        wrapCipher.updateAAD(PARAMS_AAD)
        val wrappedKey = wrapCipher.doFinal(fileKey)
        val iv = wrapCipher.iv
        check(iv.size == IV_BYTES) { "unexpected IV length ${iv.size}" }
        val wrapped = byteArrayOf(iv.size.toByte()) + iv + wrappedKey
        val header = ByteArrayOutputStream().apply {
            write(MAGIC); write(VERSION); write(CHUNK_LOG2)
            write(wrapped.size ushr 8); write(wrapped.size and 0xFF)
            write(wrapped); write(prefix)
        }.toByteArray()
        output.write(header)

        val head = byteArrayOf((nameBytes.size ushr 8).toByte(), nameBytes.size.toByte()) + nameBytes
        val source = PushbackInputStream(java.io.SequenceInputStream(ByteArrayInputStream(head), input), 1)
        val buf = ByteArray(CHUNK)
        var index = 0L
        while (true) {
            val n = readUpTo(source, buf)
            val next = source.read()
            val last = next < 0
            if (!last) source.unread(next)
            val cipher = gcm(Cipher.ENCRYPT_MODE, fileKey, nonce(prefix, index, last), header)
            output.write(cipher.doFinal(buf, 0, n))
            if (last) break
            index++
        }
        output.flush()
    }

    /** @return the stored file name; the plaintext goes to [output] (pass null to only read the name: only the FIRST chunk is decrypted). */
    fun decrypt(master: SecretKey, input: InputStream, output: OutputStream?): String {
        val fixed = ByteArray(8)
        if (readUpTo(input, fixed) != 8) throw TamperedException("short header")
        for (i in 0 until 4) if (fixed[i] != MAGIC[i]) throw TamperedException("not a vault file")
        if (fixed[4].toInt() != VERSION || fixed[5].toInt() != CHUNK_LOG2) throw TamperedException("unsupported version")
        val wrapLen = ((fixed[6].toInt() and 0xFF) shl 8) or (fixed[7].toInt() and 0xFF)
        if (wrapLen != 1 + IV_BYTES + KEY_BYTES + TAG_BYTES) throw TamperedException("bad key block")
        val wrapped = ByteArray(wrapLen)
        val prefix = ByteArray(PREFIX_BYTES)
        if (readUpTo(input, wrapped) != wrapLen || readUpTo(input, prefix) != PREFIX_BYTES) throw TamperedException("short header")
        if (wrapped[0].toInt() != IV_BYTES) throw TamperedException("bad IV length")
        val header = fixed + wrapped + prefix
        val fileKey = try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, master, GCMParameterSpec(TAG_BYTES * 8, wrapped.copyOfRange(1, 1 + IV_BYTES)))
            c.updateAAD(PARAMS_AAD)
            c.doFinal(wrapped, 1 + IV_BYTES, wrapLen - 1 - IV_BYTES)
        } catch (e: AEADBadTagException) {
            throw TamperedException("wrong key or damaged key block")
        }

        val source = PushbackInputStream(input, 1)
        val buf = ByteArray(CHUNK + TAG_BYTES)
        var index = 0L
        var name = ""
        while (true) {
            val n = readUpTo(source, buf)
            if (n < TAG_BYTES + 1) throw TamperedException("truncated at chunk $index")
            val last: Boolean
            if (n < buf.size) last = true
            else { val next = source.read(); last = next < 0; if (!last) source.unread(next) }
            val plain = try {
                gcm(Cipher.DECRYPT_MODE, fileKey, nonce(prefix, index, last), header).doFinal(buf, 0, n)
            } catch (e: AEADBadTagException) {
                throw TamperedException("chunk $index failed authentication")
            }
            var from = 0
            if (index == 0L) {
                if (plain.size < 3) throw TamperedException("no name")
                val len = ((plain[0].toInt() and 0xFF) shl 8) or (plain[1].toInt() and 0xFF)
                if (len < 1 || len > MAX_NAME_BYTES || 2 + len > plain.size) throw TamperedException("bad name")
                name = String(plain, 2, len, Charsets.UTF_8)
                from = 2 + len
                if (output == null) return name
            }
            output?.write(plain, from, plain.size - from)
            if (last) break
            index++
        }
        output?.flush()
        return name
    }

    fun peekName(master: SecretKey, input: InputStream): String = decrypt(master, input, null)
}
