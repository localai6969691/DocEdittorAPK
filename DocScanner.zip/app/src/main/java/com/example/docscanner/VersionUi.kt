package com.example.docscanner

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.util.FileVersions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * The version history screens, shared by the reader (menu "Version history") and the main screen (select a file, "Version history"): a list of the versions kept of a library file, newest first,
 * and what can be done with one: look at it, put it back, keep it forever (pin) or stop, delete it (phiên 25, TECHNICAL_DOCS.md 4.78 and 4.80). The logic is [FileVersions]; this is only dialogs.
 */
object VersionUi {

    fun label(context: Context, v: FileVersions.Version): String =
        java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT).format(java.util.Date(v.time)) +
            " \u00B7 " + android.text.format.Formatter.formatShortFileSize(context, v.size)

    /** Lists the versions of [target]; [onChanged] runs after the library file itself was changed (a version was put back), so the caller can reload it. */
    fun show(activity: AppCompatActivity, target: File, limit: Int, onChanged: () -> Unit) {
        val versions = FileVersions.list(activity.filesDir, target.name)
        if (versions.isEmpty()) {
            AlertDialog.Builder(activity).setTitle(R.string.versions_title).setMessage(R.string.versions_empty).setPositiveButton(R.string.dialog_ok, null).show()
            return
        }
        val labels = versions.map { v -> label(activity, v) + (if (v.pinned) " \u00B7 " + activity.getString(R.string.versions_pinned) else "") }
        AlertDialog.Builder(activity)
            .setTitle(R.string.versions_title)
            .setItems(labels.toTypedArray()) { _, which -> actions(activity, target, versions[which], limit, onChanged) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun actions(activity: AppCompatActivity, target: File, v: FileVersions.Version, limit: Int, onChanged: () -> Unit) {
        val items = arrayOf(
            activity.getString(R.string.versions_action_view), activity.getString(R.string.versions_action_restore),
            activity.getString(if (v.pinned) R.string.versions_action_unpin else R.string.versions_action_pin), activity.getString(R.string.versions_action_delete)
        )
        AlertDialog.Builder(activity)
            .setTitle(label(activity, v))
            .setItems(items) { _, which ->
                when (which) {
                    0 -> view(activity, target, v)
                    1 -> restore(activity, target, v, limit, onChanged)
                    2 -> {
                        FileVersions.setPinned(activity.filesDir, target.name, v.id, !v.pinned)
                        show(activity, target, limit, onChanged)
                    }
                    else -> {
                        FileVersions.delete(activity.filesDir, target.name, v.id)
                        Toast.makeText(activity, R.string.versions_deleted, Toast.LENGTH_SHORT).show()
                        show(activity, target, limit, onChanged)
                    }
                }
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    /** Opens a version in the reader: its content is rebuilt into a temporary file (a version is a list of pieces, not a PDF) that the reader deletes when it closes. */
    private fun view(activity: AppCompatActivity, target: File, v: FileVersions.Version) {
        activity.lifecycleScope.launch {
            val dir = File(activity.cacheDir, "version_view")
            val out = File(dir, "v${v.id}_" + target.name)
            val ok = withContext(Dispatchers.IO) {
                dir.mkdirs()
                FileVersions.export(activity.filesDir, v, out)
            }
            if (!ok) {
                Toast.makeText(activity, R.string.versions_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            activity.startActivity(Intent(activity, PdfReaderActivity::class.java).apply {
                putExtra(PdfReaderActivity.EXTRA_PDF_PATH, out.absolutePath)
                putExtra(PdfReaderActivity.EXTRA_TITLE, label(activity, v))
                putExtra(PdfReaderActivity.EXTRA_TEMP, true)
            })
        }
    }

    /** Puts a version back as the library file; the content that was current becomes a version itself, so nothing is lost by restoring. */
    private fun restore(activity: AppCompatActivity, target: File, v: FileVersions.Version, limit: Int, onChanged: () -> Unit) {
        activity.lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { FileVersions.restore(activity.filesDir, target.name, v.id, target, System.currentTimeMillis(), limit) }
            if (!ok) {
                Toast.makeText(activity, R.string.versions_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            Toast.makeText(activity, R.string.versions_restore_done, Toast.LENGTH_LONG).show()
            onChanged()
        }
    }
}
