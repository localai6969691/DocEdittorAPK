package com.example.docscanner

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.docscanner.adapter.EpubRowAdapter
import com.example.docscanner.databinding.ActivityEpubReaderBinding
import com.example.docscanner.util.EbookBuilder
import com.example.docscanner.util.EpubNotes
import com.example.docscanner.util.EpubReader
import com.example.docscanner.util.EpubSearch
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Reads one EPUB inside the app (PDF list C5) with highlights, bookmarks and a remembered place (C6), plus search with "jump to the result" (C7).
 * The text comes from [EpubReader] (plain paragraphs: no pictures or publisher styling - see its header); the notes live in [EpubNotes], in a private
 * file per book, and are set aside (not deleted) when the book's text changed since they were written.
 */
class EpubReaderActivity : BaseActivity() {

    private lateinit var binding: ActivityEpubReaderBinding
    private lateinit var adapter: EpubRowAdapter
    private lateinit var layoutManager: LinearLayoutManager

    private var epub: File? = null
    private var chapters: List<EbookBuilder.Chapter> = emptyList()
    private var paragraphs: List<List<String>> = emptyList()
    private var titles: List<String> = emptyList()
    private var rows: List<EpubRowAdapter.Row> = emptyList()
    private var rowOf: HashMap<Long, Int> = HashMap()
    private var headingRow: IntArray = IntArray(0)
    private var fingerprint = ""
    private var notesFile: File? = null
    private var notes: EpubNotes.Notes = EpubNotes.EMPTY
    private var ready = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEpubReaderBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val file = intent.getStringExtra(EXTRA_EPUB_PATH)?.let { File(it) }
        if (file == null || !file.isFile) {
            Toast.makeText(this, R.string.epub_reader_open_failed, Toast.LENGTH_LONG).show()
            finish()
            return
        }
        epub = file
        title = file.nameWithoutExtension

        adapter = EpubRowAdapter { row, start, end, erase -> onSelection(row, start, end, erase) }
        adapter.setTextSize(prefs().getFloat(KEY_SIZE, DEFAULT_SP))
        layoutManager = LinearLayoutManager(this)
        binding.rvBook.layoutManager = layoutManager
        binding.rvBook.adapter = adapter
        binding.progress.visibility = View.VISIBLE

        lifecycleScope.launch {
            val loaded = withContext(Dispatchers.IO) {
                val list = runCatching { EpubReader.read(file) }.getOrDefault(emptyList())
                val paras = list.map { it.paragraphs }
                val fp = EpubNotes.fingerprint(paras)
                val nf = EpubNotes.fileFor(File(filesDir, NOTES_DIR), file)
                Loaded(list, paras, fp, nf, EpubNotes.load(nf, fp, paras))
            }
            binding.progress.visibility = View.GONE
            if (loaded.chapters.isEmpty() || loaded.chapters.all { it.paragraphs.isEmpty() }) {
                Toast.makeText(this@EpubReaderActivity, R.string.epub_reader_open_failed, Toast.LENGTH_LONG).show()
                finish()
                return@launch
            }
            chapters = loaded.chapters
            paragraphs = loaded.paragraphs
            fingerprint = loaded.fingerprint
            notesFile = loaded.notesFile
            notes = loaded.notes
            if (notes.stale) Toast.makeText(this@EpubReaderActivity, R.string.epub_reader_stale, Toast.LENGTH_LONG).show()
            titles = chapters.mapIndexed { i, c -> if (c.title.isBlank()) getString(R.string.epub_search_chapter_n, i + 1) else c.title.trim() }
            buildRows()
            adapter.setNotes(notes.highlights, notes.bookmarks)
            adapter.submit(rows)
            ready = true
            val last = notes.last
            if (last != null) {
                val pos = rowOf[EpubNotes.key(last.chapter, last.paragraph)]
                if (pos != null) binding.rvBook.post { layoutManager.scrollToPositionWithOffset(pos, 0) }
            }
        }
    }

    private class Loaded(
        val chapters: List<EbookBuilder.Chapter>, val paragraphs: List<List<String>>, val fingerprint: String,
        val notesFile: File, val notes: EpubNotes.Notes
    )

    private fun prefs() = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun buildRows() {
        val list = ArrayList<EpubRowAdapter.Row>()
        val index = HashMap<Long, Int>()
        val headings = IntArray(chapters.size)
        for ((ci, chapter) in chapters.withIndex()) {
            headings[ci] = list.size
            list.add(EpubRowAdapter.Row(ci, -1, titles[ci]))
            for ((pi, text) in chapter.paragraphs.withIndex()) {
                index[EpubNotes.key(ci, pi)] = list.size
                list.add(EpubRowAdapter.Row(ci, pi, text))
            }
        }
        rows = list
        rowOf = index
        headingRow = headings
    }

    private fun saveNotes() {
        val f = notesFile ?: return
        if (!EpubNotes.save(f, fingerprint, notes)) Toast.makeText(this, R.string.epub_reader_save_failed, Toast.LENGTH_LONG).show()
    }

    private fun replaceNotes(highlights: List<EpubNotes.Mark>, bookmarks: List<EpubNotes.Place>, last: EpubNotes.Place?) {
        notes = EpubNotes.Notes(highlights, bookmarks, last)
        adapter.setNotes(notes.highlights, notes.bookmarks)
        saveNotes()
    }

    private fun onSelection(row: EpubRowAdapter.Row, start: Int, end: Int, erase: Boolean) {
        val updated = if (erase) EpubNotes.eraseHighlight(notes.highlights, row.chapter, row.paragraph, row.text, start, end)
        else EpubNotes.addHighlight(notes.highlights, row.chapter, row.paragraph, row.text, start, end)
        replaceNotes(updated, notes.bookmarks, notes.last)
        rowOf[EpubNotes.key(row.chapter, row.paragraph)]?.let { adapter.notifyItemChanged(it) }
    }

    /** The first paragraph row on or after the top visible row (a heading is skipped), or the last paragraph row before it; -1 for an empty book. */
    private fun currentParagraphRow(): Int {
        if (rows.isEmpty()) return -1
        val top = layoutManager.findFirstVisibleItemPosition().coerceAtLeast(0)
        for (i in top until rows.size) if (!rows[i].heading) return i
        for (i in top - 1 downTo 0) if (!rows[i].heading) return i
        return -1
    }

    private fun jumpToRow(position: Int) {
        layoutManager.scrollToPositionWithOffset(position.coerceIn(0, (rows.size - 1).coerceAtLeast(0)), 0)
    }

    private fun jumpToParagraph(chapter: Int, paragraph: Int) {
        rowOf[EpubNotes.key(chapter, paragraph)]?.let { jumpToRow(it) }
    }

    override fun onPause() {
        super.onPause()
        if (!ready) return
        val pos = currentParagraphRow()
        val row = if (pos >= 0) rows[pos] else null
        if (row != null) {
            val old = notes.last
            if (old == null || old.chapter != row.chapter || old.paragraph != row.paragraph) {
                replaceNotes(notes.highlights, notes.bookmarks, EpubNotes.Place(row.chapter, row.paragraph))
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_epub_reader, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        if (!ready) return super.onOptionsItemSelected(item)
        when (item.itemId) {
            R.id.action_epub_contents -> showContents()
            R.id.action_epub_search -> askSearch()
            R.id.action_epub_bookmark -> toggleBookmarkHere()
            R.id.action_epub_bookmarks -> showBookmarks()
            R.id.action_epub_highlights -> showHighlights()
            R.id.action_epub_bigger -> changeSize(2f)
            R.id.action_epub_smaller -> changeSize(-2f)
            R.id.action_epub_copy_notes -> copyNotes()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private fun changeSize(delta: Float) {
        val next = (prefs().getFloat(KEY_SIZE, DEFAULT_SP) + delta).coerceIn(MIN_SP, MAX_SP)
        prefs().edit().putFloat(KEY_SIZE, next).apply()
        adapter.setTextSize(next)
    }

    private fun showContents() {
        AlertDialog.Builder(this)
            .setTitle(R.string.epub_reader_contents)
            .setItems(titles.toTypedArray()) { _, which -> jumpToRow(headingRow[which]) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun toggleBookmarkHere() {
        val pos = currentParagraphRow()
        val row = if (pos >= 0) rows[pos] else return
        val had = EpubNotes.hasBookmark(notes.bookmarks, row.chapter, row.paragraph)
        replaceNotes(notes.highlights, EpubNotes.toggleBookmark(notes.bookmarks, row.chapter, row.paragraph), notes.last)
        adapter.notifyItemChanged(pos)
        Toast.makeText(this, if (had) R.string.epub_reader_bookmark_removed else R.string.epub_reader_bookmark_added, Toast.LENGTH_SHORT).show()
    }

    private fun chapterLabel(chapter: Int): String = getString(R.string.epub_search_chapter_n, chapter + 1)

    private fun paragraphText(chapter: Int, paragraph: Int): String = paragraphs.getOrNull(chapter)?.getOrNull(paragraph) ?: ""

    private fun showBookmarks() {
        val list = notes.bookmarks
        if (list.isEmpty()) {
            Toast.makeText(this, R.string.epub_reader_bookmarks_none, Toast.LENGTH_LONG).show()
            return
        }
        val labels = list.map { chapterLabel(it.chapter) + ": " + EpubNotes.snippet(paragraphText(it.chapter, it.paragraph), 80) }
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.epub_reader_bookmarks_title)
            .setItems(labels.toTypedArray()) { _, which -> jumpToParagraph(list[which].chapter, list[which].paragraph) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .create()
        dialog.setOnShowListener {
            dialog.listView.setOnItemLongClickListener { _, _, position, _ ->
                val b = list[position]
                replaceNotes(notes.highlights, EpubNotes.toggleBookmark(notes.bookmarks, b.chapter, b.paragraph), notes.last)
                rowOf[EpubNotes.key(b.chapter, b.paragraph)]?.let { adapter.notifyItemChanged(it) }
                dialog.dismiss()
                showBookmarks()
                true
            }
        }
        dialog.show()
    }

    private fun showHighlights() {
        val list = notes.highlights
        if (list.isEmpty()) {
            Toast.makeText(this, R.string.epub_reader_highlights_none, Toast.LENGTH_LONG).show()
            return
        }
        val labels = list.map {
            val p = paragraphText(it.chapter, it.paragraph)
            val end = minOf(it.end, p.length)
            chapterLabel(it.chapter) + ": " + EpubNotes.snippet(if (it.start < end) p.substring(it.start, end) else "", 80)
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.epub_reader_highlights_title)
            .setItems(labels.toTypedArray()) { _, which -> jumpToParagraph(list[which].chapter, list[which].paragraph) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .create()
        dialog.setOnShowListener {
            dialog.listView.setOnItemLongClickListener { _, _, position, _ ->
                val m = list[position]
                replaceNotes(EpubNotes.removeHighlight(notes.highlights, m), notes.bookmarks, notes.last)
                rowOf[EpubNotes.key(m.chapter, m.paragraph)]?.let { adapter.notifyItemChanged(it) }
                dialog.dismiss()
                showHighlights()
                true
            }
        }
        dialog.show()
    }

    private fun askSearch() {
        val input = EditText(this).apply {
            setHint(R.string.epub_search_hint)
            setSingleLine()
        }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = FrameLayout(this).apply { setPadding(pad, pad / 2, pad, 0); addView(input) }
        AlertDialog.Builder(this)
            .setTitle(R.string.epub_search_title)
            .setView(holder)
            .setPositiveButton(android.R.string.ok) { _, _ -> runSearch(input.text.toString()) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun runSearch(query: String) {
        if (query.isBlank()) return
        lifecycleScope.launch {
            val total = IntArray(1)
            val hits = withContext(Dispatchers.Default) { EpubSearch.search(chapters, query, MAX_SHOWN_HITS, total) }
            if (hits.isEmpty()) {
                Toast.makeText(this@EpubReaderActivity, getString(R.string.epub_search_none, query), Toast.LENGTH_LONG).show()
                return@launch
            }
            val labels = hits.map { chapterLabel(it.chapter) + " · " + it.before + it.match + it.after }
            AlertDialog.Builder(this@EpubReaderActivity)
                .setTitle(getString(R.string.epub_search_header, query, total[0]))
                .setItems(labels.toTypedArray()) { _, which -> jumpToParagraph(hits[which].chapter, hits[which].paragraph) }
                .setNegativeButton(R.string.dialog_cancel, null)
                .show()
        }
    }

    private fun copyNotes() {
        if (notes.highlights.isEmpty() && notes.bookmarks.isEmpty()) {
            Toast.makeText(this, R.string.epub_reader_notes_empty, Toast.LENGTH_SHORT).show()
            return
        }
        val name = epub?.nameWithoutExtension ?: ""
        val text = EpubNotes.render(
            paragraphs, titles, notes, getString(R.string.epub_reader_notes_header, name),
            getString(R.string.epub_reader_notes_bookmarks), getString(R.string.epub_reader_notes_highlights)
        ) { number, chapterTitle -> if (chapterTitle.isEmpty()) getString(R.string.epub_search_chapter_n, number) else getString(R.string.epub_search_chapter, number, chapterTitle) }
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("epub_notes", text))
        Toast.makeText(this, R.string.epub_reader_notes_copied, Toast.LENGTH_SHORT).show()
    }

    companion object {
        const val EXTRA_EPUB_PATH = "extra_epub_path"
        private const val PREFS = "epub_reader"
        private const val KEY_SIZE = "size_sp"
        private const val NOTES_DIR = "epub_notes"
        private const val DEFAULT_SP = 17f
        private const val MIN_SP = 12f
        private const val MAX_SP = 32f
        private const val MAX_SHOWN_HITS = 100
    }
}
