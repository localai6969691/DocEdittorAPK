package com.example.docscanner

import android.content.Intent
import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityCropBinding
import com.example.docscanner.model.PendingCropQueue
import com.example.docscanner.model.ScanPage
import com.example.docscanner.model.ScanSessionManager
import com.example.docscanner.util.DocumentEnhancer
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.ImageProcessor
import com.example.docscanner.util.ManualAdjust
import com.example.docscanner.util.PageOrientation
import com.example.docscanner.util.TextLineDewarp
import com.example.docscanner.util.ScanQuality
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileOutputStream

/**
 * Three-stage screen: (0, optional) split a 2-page spread photo into 2 single pages, (1) drag the
 * 4 corners to match the document, (2) pick a filter and save.
 *
 * Runs in one of two navigation modes:
 *  - Single mode (queueMode = false): launched by CaptureActivity for one just-taken photo.
 *    Saving/retaking finishes this activity with a result and CaptureActivity resumes.
 *  - Queue mode (queueMode = true): launched directly for a batch of images (gallery picks or
 *    pages rendered from an imported PDF, see [PendingCropQueue]). After each save/skip it loads
 *    the next queued image itself, and moves on to [PageListActivity] once the queue is empty.
 *
 * A split (stage 0) always switches this instance to queue mode from that point on, even if it
 * started in single mode: splitting produces 2 pages instead of 1, so there's more than one image
 * left to get through, and the simplest, safest thing is to always finish into [PageListActivity]
 * once every resulting page has been saved (see TECHNICAL_DOCS.md for the reasoning).
 */
class CropActivity : BaseActivity() {

    private lateinit var binding: ActivityCropBinding
    private var sourceBitmap: Bitmap? = null
    private var warpedBitmap: Bitmap? = null

    /** [warpedBitmap] after the optional page fixes ("Tự xoay & thẳng chữ", "Duỗi dòng cong"), computed in
     *  the background whenever either box changes and dropped whenever a new page is warped. */
    private var straightenedBitmap: Bitmap? = null
    private var ignoreDeskewToggle = false
    private var fixJob: kotlinx.coroutines.Job? = null
    private var queueMode = false
    private var selectedFilter = ImageProcessor.ScanFilter.ORIGINAL

    /** "Chỉnh tay" sliders (phiên 17): applied after [selectedFilter]; kept from page to page of a batch so a whole book gets the same look. */
    private var manual = ManualAdjust.Params()

    /** Known render DPI for every page in this batch (queue mode only - `null` for a camera
     *  single-mode capture, which has no "true" DPI). Read once from the launching Intent and
     *  reused for every page saved out of this activity instance, split-page halves included,
     *  since one CropActivity instance only ever processes pages from a single source/batch -
     *  see [PendingCropQueue]'s doc comment and TECHNICAL_DOCS.md section 6/7 ("ASSUMED_DPI"). */
    private var sourceDpi: Float? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCropBinding.inflate(layoutInflater)
        setContentView(binding.root)

        queueMode = intent.getBooleanExtra(EXTRA_QUEUE_MODE, false)
        sourceDpi = if (intent.hasExtra(EXTRA_SOURCE_DPI)) intent.getFloatExtra(EXTRA_SOURCE_DPI, 0f) else null
        val path = intent.getStringExtra(EXTRA_IMAGE_PATH)
        if (path == null) {
            finish()
            return
        }
        loadImage(path)

        binding.btnRetake.setOnClickListener { handleSkip() }
        binding.btnConfirmCrop.setOnClickListener { confirmCrop() }
        binding.btnBackToCrop.setOnClickListener { showCropStage() }
        binding.btnSavePage.setOnClickListener { savePage() }
        binding.btnSplitPages.setOnClickListener { showSplitStage() }
        binding.btnManualAdjust.setOnClickListener { showManualAdjustDialog() }
        binding.btnCancelSplit.setOnClickListener { showCropStage() }
        binding.btnConfirmSplit.setOnClickListener { confirmSplit() }

        binding.chipGroup.setOnCheckedChangeListener { _, checkedId ->
            selectedFilter = when (checkedId) {
                binding.chipEnhance.id -> ImageProcessor.ScanFilter.ENHANCE
                binding.chipGray.id -> ImageProcessor.ScanFilter.GRAY
                binding.chipBw.id -> ImageProcessor.ScanFilter.BW
                binding.chipBwPro.id -> ImageProcessor.ScanFilter.BW_SAUVOLA
                binding.chipClean.id -> ImageProcessor.ScanFilter.CLEAN
                else -> ImageProcessor.ScanFilter.ORIGINAL
            }
            updateFilterPreview()
        }

        val fixToggled = android.widget.CompoundButton.OnCheckedChangeListener { _, _ ->
            if (!ignoreDeskewToggle) recomputePageFixes()
        }
        binding.cbDeskew.setOnCheckedChangeListener(fixToggled)
        binding.cbDewarp.setOnCheckedChangeListener(fixToggled)
    }

    private fun loadImage(path: String) {
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.Default) { FileUtils.decodeBitmapWithExifOrientation(path) }
            if (bmp == null) {
                binding.progressBar.visibility = View.GONE
                handleSkip()
                return@launch
            }
            proceedWithBitmap(bmp)
        }
    }

    /** Shared by the initial file load and by the split flow (which hands over the left-half
     *  bitmap directly, with no file to decode). Detects corners and shows stage 1. */
    private suspend fun proceedWithBitmap(bmp: Bitmap) {
        sourceBitmap = bmp
        val detected = withContext(Dispatchers.Default) {
            ImageProcessor.detectDocumentCorners(bmp)
        } ?: ImageProcessor.defaultCorners(bmp.width, bmp.height)
        binding.cropOverlayView.setImage(bmp, detected)
        binding.progressBar.visibility = View.GONE
        showCropStage()
    }

    /** Used both when the user explicitly retakes/cancels and as a fallback if a file fails to load. */
    private fun handleSkip() {
        if (queueMode) {
            val next = PendingCropQueue.pollNext()
            if (next != null) loadImage(next) else goToPageListAndFinish()
        } else {
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    private fun showSplitStage() {
        val bmp = sourceBitmap ?: return
        binding.cropOverlayView.visibility = View.GONE
        binding.bottomBar1.visibility = View.GONE
        binding.btnSplitPages.visibility = View.GONE
        binding.splitLineOverlayView.visibility = View.VISIBLE
        binding.bottomBarSplit.visibility = View.VISIBLE
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val gutterX = withContext(Dispatchers.Default) { ImageProcessor.detectGutterX(bmp) }
            binding.splitLineOverlayView.setImage(bmp, gutterX)
            binding.progressBar.visibility = View.GONE
        }
    }

    private fun confirmSplit() {
        val source = sourceBitmap ?: return
        val splitX = binding.splitLineOverlayView.getSplitX().toInt().coerceIn(1, source.width - 1)
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val leftBitmap = withContext(Dispatchers.Default) {
                val left = Bitmap.createBitmap(source, 0, 0, splitX, source.height)
                val right = Bitmap.createBitmap(source, splitX, 0, source.width - splitX, source.height)
                val rightFile = FileUtils.newSplitPageFile(this@CropActivity)
                FileOutputStream(rightFile).use { out -> right.compress(Bitmap.CompressFormat.JPEG, 95, out) }
                right.recycle()
                PendingCropQueue.pushFront(rightFile.absolutePath)
                left
            }
            queueMode = true // splitting means there's now more than 1 page left - always finish to the page list
            proceedWithBitmap(leftBitmap)
        }
    }

    private fun confirmCrop() {
        val bmp = sourceBitmap ?: return
        val quad = binding.cropOverlayView.getResultQuad()
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val warped = withContext(Dispatchers.Default) { ImageProcessor.warpDocument(bmp, quad) }
            warpedBitmap = warped
            fixJob?.cancel()
            straightenedBitmap = null
            ignoreDeskewToggle = true
            binding.cbDeskew.isChecked = false
            binding.cbDewarp.isChecked = false
            ignoreDeskewToggle = false
            val suggestColor = withContext(Dispatchers.Default) { ImageProcessor.isColorPage(warped) }
            val quality = withContext(Dispatchers.Default) { ScanQuality.analyze(warped) }
            binding.progressBar.visibility = View.GONE
            showFilterStage(suggestColor)
            showQualityHint(quality)
        }
    }

    private fun showCropStage() {
        binding.cropOverlayView.visibility = View.VISIBLE
        binding.bottomBar1.visibility = View.VISIBLE
        binding.btnSplitPages.visibility = View.VISIBLE
        binding.splitLineOverlayView.visibility = View.GONE
        binding.bottomBarSplit.visibility = View.GONE
        binding.ivResult.visibility = View.GONE
        binding.filterScroll.visibility = View.GONE
        binding.cbDeskew.visibility = View.GONE
        binding.cbDewarp.visibility = View.GONE
        binding.btnManualAdjust.visibility = View.GONE
        binding.bottomBar2.visibility = View.GONE
    }

    private fun showFilterStage(suggestColor: Boolean = false) {
        binding.cropOverlayView.visibility = View.GONE
        binding.bottomBar1.visibility = View.GONE
        binding.btnSplitPages.visibility = View.GONE
        binding.splitLineOverlayView.visibility = View.GONE
        binding.bottomBarSplit.visibility = View.GONE
        binding.ivResult.visibility = View.VISIBLE
        binding.filterScroll.visibility = View.VISIBLE
        binding.cbDeskew.visibility = View.VISIBLE
        binding.cbDewarp.visibility = View.VISIBLE
        binding.btnManualAdjust.visibility = View.VISIBLE
        binding.bottomBar2.visibility = View.VISIBLE
        if (suggestColor) {
            binding.chipEnhance.isChecked = true
            selectedFilter = ImageProcessor.ScanFilter.ENHANCE
        } else {
            binding.chipBw.isChecked = true
            selectedFilter = ImageProcessor.ScanFilter.BW
        }
        updateFilterPreview()
    }

    /** The page the filters are applied to: the warped page, or its fixed copy while a fix box is ticked. */
    private fun baseBitmap(): Bitmap? =
        if (binding.cbDeskew.isChecked || binding.cbDewarp.isChecked) (straightenedBitmap ?: warpedBitmap) else warpedBitmap

    /** Turns [src] counter-clockwise by 90, 180 or 270 degrees (lossless: pixels are only moved). */
    private fun rotateCcw(src: Bitmap, degrees: Int): Bitmap {
        if (degrees == 0) return src
        val m = android.graphics.Matrix().apply { postRotate(-degrees.toFloat()) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    /**
     * Runs the ticked page fixes on a background thread, in this order: orientation (0/90/180/270,
     * [PageOrientation]) -> small skew ([DocumentEnhancer]) -> curled lines ([TextLineDewarp]). Every step
     * declines on its own when it is not sure, and the toast says plainly what was and was not done.
     */
    private fun recomputePageFixes() {
        val warped = warpedBitmap ?: return
        fixJob?.cancel()
        if (!binding.cbDeskew.isChecked && !binding.cbDewarp.isChecked) {
            straightenedBitmap = null
            updateFilterPreview()
            return
        }
        val wantRotate = binding.cbDeskew.isChecked
        val wantDewarp = binding.cbDewarp.isChecked
        binding.progressBar.visibility = View.VISIBLE
        fixJob = lifecycleScope.launch {
            class Outcome(val bitmap: Bitmap, val rotated: Int, val skew: Double, val dewarped: Boolean)
            val outcome = withContext(Dispatchers.Default) {
                var b = warped
                var rotated = 0
                var skew = 0.0
                var dewarped = false
                if (wantRotate) {
                    PageOrientation.detectCcwDegrees(b)?.let { deg ->
                        if (deg != 0) { b = rotateCcw(b, deg); rotated = deg }
                    }
                    val a = DocumentEnhancer.estimateSkewDegrees(b)
                    if (a != 0.0) { b = DocumentEnhancer.straighten(b, a); skew = a }
                }
                if (wantDewarp) {
                    TextLineDewarp.dewarp(b)?.let { b = it; dewarped = true }
                }
                Outcome(b, rotated, skew, dewarped)
            }
            binding.progressBar.visibility = View.GONE
            val changed = outcome.rotated != 0 || outcome.skew != 0.0 || outcome.dewarped
            straightenedBitmap = if (changed) outcome.bitmap else null
            val parts = ArrayList<String>()
            if (outcome.rotated != 0) parts.add(getString(R.string.fix_rotated, outcome.rotated))
            if (outcome.skew != 0.0) parts.add(getString(R.string.deskew_done, String.format(java.util.Locale.getDefault(), "%.1f", kotlin.math.abs(outcome.skew))))
            if (outcome.dewarped) parts.add(getString(R.string.dewarp_done))
            Toast.makeText(
                this@CropActivity,
                if (parts.isEmpty()) getString(R.string.fix_nothing_done) else parts.joinToString(" · "),
                Toast.LENGTH_SHORT
            ).show()
            updateFilterPreview()
        }
    }

    /** Dismissible hint only - never blocks saving (thresholds are untested, see [ScanQuality]). */
    private fun showQualityHint(q: ScanQuality.Report) {
        if (!q.hasProblem) return
        val reasons = ArrayList<String>()
        if (q.isBlurry) reasons.add(getString(R.string.quality_blurry))
        if (q.isTooDark) reasons.add(getString(R.string.quality_dark))
        if (q.isLowContrast) reasons.add(getString(R.string.quality_low_contrast))
        Toast.makeText(
            this,
            getString(R.string.quality_hint, reasons.joinToString(", ")),
            Toast.LENGTH_LONG
        ).show()
    }

    private fun updateFilterPreview() {
        val warped = baseBitmap() ?: return
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val filtered = withContext(Dispatchers.Default) {
                ManualAdjust.apply(ImageProcessor.applyFilter(warped, selectedFilter), manual)
            }
            binding.ivResult.setImageBitmap(filtered)
            binding.progressBar.visibility = View.GONE
        }
    }


    /** Five sliders (brightness, contrast, saturation, sharpen, despeckle). The preview is recomputed when a finger LIFTS, not on every tick:
     *  despeckle labels the whole page, which is too slow to run 30 times a second. */
    private fun showManualAdjustDialog() {
        val density = resources.displayMetrics.density
        val pad = (16 * density).toInt()
        val box = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(pad, pad, pad, 0)
        }
        var draft = manual
        fun addRow(label: Int, min: Int, max: Int, value: Int, onChange: (Int) -> Unit) {
            val title = android.widget.TextView(this).apply { setText(label) }
            val bar = android.widget.SeekBar(this).apply {
                this.max = max - min
                progress = value - min
                setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: android.widget.SeekBar?, progress: Int, fromUser: Boolean) {
                        if (fromUser) onChange(progress + min)
                    }
                    override fun onStartTrackingTouch(seekBar: android.widget.SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: android.widget.SeekBar?) {
                        manual = draft
                        updateFilterPreview()
                    }
                })
            }
            box.addView(title)
            box.addView(bar)
        }
        addRow(R.string.adj_brightness, -100, 100, draft.brightness) { draft = draft.copy(brightness = it) }
        addRow(R.string.adj_contrast, -100, 100, draft.contrast) { draft = draft.copy(contrast = it) }
        addRow(R.string.adj_saturation, -100, 100, draft.saturation) { draft = draft.copy(saturation = it) }
        addRow(R.string.adj_sharpen, 0, 100, draft.sharpen) { draft = draft.copy(sharpen = it) }
        addRow(R.string.adj_despeckle, 0, 3, draft.despeckle) { draft = draft.copy(despeckle = it) }
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.manual_adjust)
            .setView(android.widget.ScrollView(this).apply { addView(box) })
            .setPositiveButton(R.string.adj_done, null)
            .setNeutralButton(R.string.adj_reset) { _, _ ->
                manual = ManualAdjust.Params()
                updateFilterPreview()
            }
            .show()
    }

    private fun savePage() {
        val warped = baseBitmap() ?: return
        binding.progressBar.visibility = View.VISIBLE
        lifecycleScope.launch {
            val outFile = withContext(Dispatchers.Default) {
                val finalBitmap = ManualAdjust.apply(ImageProcessor.applyFilter(warped, selectedFilter), manual)
                val file = FileUtils.newSessionPageFile(this@CropActivity)
                FileOutputStream(file).use { out ->
                    finalBitmap.compress(Bitmap.CompressFormat.JPEG, 92, out)
                }
                file
            }
            ScanSessionManager.addPage(ScanPage(ScanSessionManager.newPageId(), outFile.absolutePath, sourceDpi = sourceDpi))
            binding.progressBar.visibility = View.GONE

            if (queueMode) {
                val next = PendingCropQueue.pollNext()
                if (next != null) loadImage(next) else goToPageListAndFinish()
            } else {
                setResult(RESULT_OK)
                finish()
            }
        }
    }

    private fun goToPageListAndFinish() {
        startActivity(Intent(this, PageListActivity::class.java))
        finish()
    }

    companion object {
        const val EXTRA_IMAGE_PATH = "extra_image_path"
        const val EXTRA_QUEUE_MODE = "extra_queue_mode"
        /** Optional Float extra - only set by [MainActivity.startCropQueue] when the batch has a
         *  known real DPI (currently: PDF-import-for-scanning, 220). Absent entirely for gallery
         *  imports and camera captures, which fall back to `null` (the camera-capture convention -
         *  see [sourceDpi]'s doc comment). */
        const val EXTRA_SOURCE_DPI = "extra_source_dpi"
    }
}
