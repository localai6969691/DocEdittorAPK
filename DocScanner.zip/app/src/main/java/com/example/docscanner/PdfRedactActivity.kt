package com.example.docscanner

import android.app.AlertDialog
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityPdfRedactBinding
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfPageBitmap
import com.example.docscanner.util.PdfRedactor
import com.example.docscanner.util.PiiDetector
import com.example.docscanner.util.PiiScanner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.example.docscanner.util.SignedPdfGuard

/**
 * "Che thông tin vĩnh viễn": pick a PDF, draw black boxes over what must disappear (an ID number, an address, a signature),
 * and save a NEW PDF in which those pages are pictures with the boxes burnt in - the covered text is not in the file any more
 * ([PdfRedactor] explains why a plain black rectangle would not be enough). The original is never changed. Boxes are kept per page
 * while the screen is open; leaving after drawing asks first.
 */
class PdfRedactActivity : BaseActivity() {

    private companion object {
        /** Longest edge of the picture the automatic search reads - larger than the 1400 px of the preview, because OCR of small digits needs the detail. */
        const val AUTO_SEARCH_MAX_EDGE = 2000
    }

    private lateinit var binding: ActivityPdfRedactBinding
    private var srcFile: File? = null
    private var session: PdfPageBitmap.Session? = null
    private var pageCount = 0
    private var pageIndex = 0
    private var busy = false
    private val boxes = HashMap<Int, MutableList<FloatArray>>()

    /** The boxes the automatic search added (by identity), so "Bỏ hộp tự động" can remove exactly those and leave the hand-drawn ones. */
    private val autoBoxes: MutableSet<FloatArray> = java.util.Collections.newSetFromMap(java.util.IdentityHashMap())

    private val onPdfChosen = ActivityResultCallback<Uri?> { uri ->
        if (uri == null) {
            finish()
            return@ActivityResultCallback
        }
        setBusy(true)
        lifecycleScope.launch {
            val copy = withContext(Dispatchers.IO) { FileUtils.copyUriToTempFile(this@PdfRedactActivity, uri, ".pdf") }
            if (copy != null && !SignedPdfGuard.confirm(this@PdfRedactActivity, copy)) {
                runCatching { copy.delete() }
                finish()
                return@launch
            }
            val opened = copy?.let { f -> withContext(Dispatchers.IO) { PdfPageBitmap.open(f) } }
            if (copy == null || opened == null) {
                copy?.let { runCatching { it.delete() } }
                Toast.makeText(this@PdfRedactActivity, R.string.redact_open_failed, Toast.LENGTH_LONG).show()
                finish()
                return@launch
            }
            srcFile = copy
            session = opened
            pageCount = opened.pageCount
            showPage(0)
        }
    }

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument(), onPdfChosen)

    /** First pick of this screen: a PDF that another app handed over ("Open with" / "Share", see `IncomingFile`) is used directly, otherwise the system picker opens. */
    private fun pickPdfOrUseIncoming() {
        val incoming = intent?.data
        if (incoming != null) onPdfChosen.onActivityResult(incoming) else pdfPicker.launch(arrayOf("application/pdf"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfRedactBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.redact_title)
        binding.btnRedactPrev.setOnClickListener { if (!busy && pageIndex > 0) showPage(pageIndex - 1) }
        binding.btnRedactNext.setOnClickListener { if (!busy && pageIndex < pageCount - 1) showPage(pageIndex + 1) }
        binding.redactionView.onBoxAdded = { f ->
            boxes.getOrPut(pageIndex) { ArrayList() }.add(f)
            binding.redactionView.setBoxes(boxes[pageIndex].orEmpty())
        }
        binding.btnRedactUndo.setOnClickListener {
            boxes[pageIndex]?.let { if (it.isNotEmpty()) it.removeAt(it.size - 1) }
            binding.redactionView.setBoxes(boxes[pageIndex].orEmpty())
        }
        binding.btnRedactSave.setOnClickListener { confirmAndSave() }
        binding.btnRedactAuto.setOnClickListener { if (!busy && session != null) askAutoKinds() }
        binding.btnRedactAutoClear.setOnClickListener { if (!busy) clearAutoBoxes() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val drawn = boxes.values.sumOf { it.size }
                if (drawn == 0 || busy) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                } else {
                    AlertDialog.Builder(this@PdfRedactActivity)
                        .setMessage(getString(R.string.redact_discard, drawn))
                        .setNegativeButton(R.string.dialog_cancel, null)
                        .setPositiveButton(R.string.sign_discard_exit) { _, _ ->
                            isEnabled = false
                            onBackPressedDispatcher.onBackPressed()
                        }
                        .show()
                }
            }
        })
        pickPdfOrUseIncoming()
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { session?.close() }
        session = null
        if (isFinishing) srcFile?.let { runCatching { it.delete() } }
    }

    private fun setBusy(value: Boolean) {
        busy = value
        binding.redactProgress.visibility = if (value) View.VISIBLE else View.GONE
        binding.btnRedactSave.isEnabled = !value
        binding.btnRedactUndo.isEnabled = !value
        binding.btnRedactAuto.isEnabled = !value
        binding.btnRedactAutoClear.isEnabled = !value
    }

    private fun showPage(index: Int) {
        val s = session ?: return
        pageIndex = index
        binding.tvRedactPage.text = getString(R.string.annotate_page_indicator, index + 1, pageCount)
        binding.btnRedactPrev.isEnabled = index > 0
        binding.btnRedactNext.isEnabled = index < pageCount - 1
        setBusy(true)
        lifecycleScope.launch {
            val bmp: Bitmap? = withContext(Dispatchers.Default) { s.render(index, 1400) }
            if (index == pageIndex) {
                binding.redactionView.setPage(bmp)
                binding.redactionView.setBoxes(boxes[index].orEmpty())
            }
            setBusy(false)
        }
    }

    private fun askAutoKinds() {
        val kinds = PiiDetector.Kind.values()
        val labels = kinds.map {
            getString(
                when (it) {
                    PiiDetector.Kind.CITIZEN_ID -> R.string.redact_kind_citizen
                    PiiDetector.Kind.PHONE -> R.string.redact_kind_phone
                    PiiDetector.Kind.EMAIL -> R.string.redact_kind_email
                    PiiDetector.Kind.CARD -> R.string.redact_kind_card
                    PiiDetector.Kind.TAX_ID -> R.string.redact_kind_tax
                    PiiDetector.Kind.ACCOUNT -> R.string.redact_kind_account
                }
            )
        }.toTypedArray()
        val checked = BooleanArray(kinds.size) { true }
        AlertDialog.Builder(this)
            .setTitle(R.string.redact_auto_title)
            .setMultiChoiceItems(labels, checked) { _, index, isChecked -> checked[index] = isChecked }
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.redact_auto_scan) { _, _ ->
                val wanted = kinds.filterIndexed { i, _ -> checked[i] }.toSet()
                if (wanted.isNotEmpty()) runAutoSearch(wanted)
            }
            .show()
    }

    /** OCRs every page (one at a time, so memory stays flat) and adds a box over each personal item found; nothing is saved until the user presses "Che & lưu". */
    private fun runAutoSearch(kinds: Set<PiiDetector.Kind>) {
        val s = session ?: return
        setBusy(true)
        lifecycleScope.launch {
            var added = 0
            val pagesWithBoxes = HashSet<Int>()
            for (page in 0 until pageCount) {
                binding.tvRedactPage.text = getString(R.string.redact_auto_progress, page + 1, pageCount)
                val bitmap: Bitmap? = withContext(Dispatchers.Default) { s.render(page, AUTO_SEARCH_MAX_EDGE) }
                if (bitmap == null) continue
                val found = try {
                    PiiScanner.scan(bitmap, kinds)
                } finally {
                    bitmap.recycle()
                }
                if (found.isNotEmpty()) {
                    val list = boxes.getOrPut(page) { ArrayList() }
                    found.forEach { list.add(it); autoBoxes.add(it) }
                    added += found.size
                    pagesWithBoxes.add(page)
                }
            }
            setBusy(false)
            showPage(pageIndex)
            Toast.makeText(
                this@PdfRedactActivity,
                if (added == 0) getString(R.string.redact_auto_none) else getString(R.string.redact_auto_result, added, pagesWithBoxes.size),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun clearAutoBoxes() {
        var removed = 0
        boxes.values.forEach { list -> removed += list.count { it in autoBoxes }; list.removeAll { it in autoBoxes } }
        autoBoxes.clear()
        binding.redactionView.setBoxes(boxes[pageIndex].orEmpty())
        Toast.makeText(this, getString(R.string.redact_auto_cleared, removed), Toast.LENGTH_SHORT).show()
    }

    private fun confirmAndSave() {
        val src = srcFile ?: return
        val drawn = boxes.filterValues { it.isNotEmpty() }
        if (drawn.isEmpty()) {
            Toast.makeText(this, R.string.redact_nothing, Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.redact_confirm_title)
            .setMessage(getString(R.string.redact_confirm_message, drawn.size, drawn.values.sumOf { it.size }))
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.redact_save) { _, _ -> save(src, drawn.mapValues { e -> e.value.toList() }) }
            .show()
    }

    private fun save(src: File, rects: Map<Int, List<FloatArray>>) {
        setBusy(true)
        val out = File(PdfExporter.exportDir(this), "${FileUtils.defaultSecurityName("redacted")}.pdf")
        lifecycleScope.launch {
            val result = runCatching { withContext(Dispatchers.Default) { PdfRedactor.redact(src, out, rects) } }
            setBusy(false)
            if (result.isFailure) {
                runCatching { out.delete() }
                val encrypted = result.exceptionOrNull()?.message == "encrypted"
                Toast.makeText(this@PdfRedactActivity, if (encrypted) R.string.sign_encrypted else R.string.redact_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            boxes.clear()
            Toast.makeText(this@PdfRedactActivity, getString(R.string.redact_done, out.name, result.getOrNull() ?: 0), Toast.LENGTH_LONG).show()
            finish()
        }
    }
}
