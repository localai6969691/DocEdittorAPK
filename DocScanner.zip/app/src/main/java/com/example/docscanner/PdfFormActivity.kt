package com.example.docscanner

import android.app.AlertDialog
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityPdfFormBinding
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfFormFiller
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import com.example.docscanner.util.SignedPdfGuard
import com.example.docscanner.util.PdfSignatureProbe

/**
 * "Điền biểu mẫu PDF": pick a PDF that has fillable fields, edit them in a plain list (one row per field: a text box, a
 * check box, or a drop-down), and save a new PDF. A PDF without fields (a scan) gets an explanation of the alternative
 * instead of an empty screen. The work is done by [PdfFormFiller].
 */
class PdfFormActivity : BaseActivity() {

    private lateinit var binding: ActivityPdfFormBinding
    private var srcFile: File? = null
    private var busy = false
    private var srcSigned = false

    /** Field name -> a way to read the user's current input (as the string [PdfFormFiller.fill] expects). */
    private val readers = LinkedHashMap<String, () -> String>()

    private val onPdfChosen = ActivityResultCallback<Uri?> { uri ->
        if (uri == null) {
            finish()
            return@ActivityResultCallback
        }
        setBusy(true)
        lifecycleScope.launch {
            val copy = withContext(Dispatchers.IO) { FileUtils.copyUriToTempFile(this@PdfFormActivity, uri, ".pdf") }
            if (copy == null) {
                Toast.makeText(this@PdfFormActivity, R.string.sign_open_failed, Toast.LENGTH_LONG).show()
                finish()
                return@launch
            }
            if (!SignedPdfGuard.confirm(this@PdfFormActivity, copy, PdfSignatureProbe.ToolKind.APPENDS_FORM)) {
                runCatching { copy.delete() }
                finish()
                return@launch
            }
            srcFile = copy
            srcSigned = runCatching { withContext(Dispatchers.Default) { PdfFormFiller.isSigned(copy) } }.getOrDefault(false)
            val fields = runCatching { withContext(Dispatchers.Default) { PdfFormFiller.readFields(copy) } }
            setBusy(false)
            val list = fields.getOrNull()
            when {
                list == null -> {
                    val encrypted = fields.exceptionOrNull()?.message == "encrypted"
                    Toast.makeText(this@PdfFormActivity, if (encrypted) R.string.sign_encrypted else R.string.form_failed, Toast.LENGTH_LONG).show()
                    finish()
                }
                list.isEmpty() -> {
                    AlertDialog.Builder(this@PdfFormActivity)
                        .setMessage(R.string.form_no_fields)
                        .setCancelable(false)
                        .setPositiveButton(R.string.dialog_ok) { _, _ -> finish() }
                        .show()
                }
                else -> buildForm(list)
            }
        }
    }

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument(), onPdfChosen)

    /** First pick of this screen: a PDF that another app handed over ("Open with" / "Share", see `IncomingFile`) is used directly, otherwise the system picker opens. */
    private fun pickPdfOrUseIncoming() {
        val incoming = intent?.data
        if (incoming != null) onPdfChosen.onActivityResult(incoming) else pdfPicker.launch(arrayOf("application/pdf"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfFormBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.form_title)
        binding.btnFormSave.setOnClickListener { save() }
        pickPdfOrUseIncoming()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isFinishing) srcFile?.let { runCatching { it.delete() } }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun buildForm(fields: List<PdfFormFiller.Field>) {
        val container = binding.fieldsContainer
        container.removeAllViews()
        readers.clear()
        for (f in fields) {
            when (f.kind) {
                PdfFormFiller.Kind.TEXT -> {
                    container.addView(label(f.name))
                    val input = EditText(this).apply { setText(f.value) }
                    container.addView(input, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                    readers[f.name] = { input.text.toString() }
                }
                PdfFormFiller.Kind.CHECKBOX -> {
                    val box = CheckBox(this).apply {
                        text = f.name
                        isChecked = f.value == "true"
                        setPadding(0, dp(8), 0, dp(8))
                    }
                    container.addView(box)
                    readers[f.name] = { box.isChecked.toString() }
                }
                PdfFormFiller.Kind.CHOICE -> {
                    container.addView(label(f.name))
                    val spinner = Spinner(this)
                    val items = if (f.options.contains(f.value) || f.value.isEmpty()) f.options else listOf(f.value) + f.options
                    spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
                    val current = items.indexOf(f.value)
                    if (current >= 0) spinner.setSelection(current)
                    container.addView(spinner)
                    readers[f.name] = { (spinner.selectedItem as? String) ?: f.value }
                }
            }
        }
    }

    private fun label(text: String): TextView = TextView(this).apply {
        this.text = text
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(14), 0, 0)
        setTextColor(getColor(R.color.text_primary))
    }

    private fun setBusy(value: Boolean) {
        busy = value
        binding.formProgress.visibility = if (value) View.VISIBLE else View.GONE
        binding.btnFormSave.isEnabled = !value
    }

    private fun save() {
        val src = srcFile ?: return
        if (busy) return
        val values = readers.mapValues { it.value() }
        setBusy(true)
        val out = File(PdfExporter.exportDir(this), "${FileUtils.defaultSecurityName("form")}.pdf")
        lifecycleScope.launch {
            val result = runCatching { withContext(Dispatchers.Default) { PdfFormFiller.fill(src, out, values) } }
            setBusy(false)
            val changed = result.getOrNull()
            if (changed == null) {
                runCatching { out.delete() }
                Toast.makeText(this@PdfFormActivity, R.string.form_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            val message = getString(R.string.form_done, out.name, changed) +
                if (srcSigned) "\n" + getString(R.string.form_done_signed) else ""
            Toast.makeText(this@PdfFormActivity, message, Toast.LENGTH_LONG).show()
            finish()
        }
    }
}
