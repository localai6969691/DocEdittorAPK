package com.example.docscanner.util

import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.TreeMap
import java.util.zip.Deflater

/**
 * Tuyen tinh hoa PDF ("Fast Web View", ISO 32000-1 Annex F) - phien 18, B12, TECHNICAL_DOCS.md 4.42. LOI THUAN TUY: khong biet gi ve cach doc PDF; nhan do thi doi tuong
 * ([Graph]) va than tung doi tuong da tuan tu hoa ([Body]; tham chieu la dau hieu `\u0001<so>\u0002`, duoc thay bang `<so moi> 0 R`). Lop noi voi PdfBox: [PdfLinearizer].
 *
 * Chuyen the tu goi Go `linearize` cua du an byblos (github.com/dobbo-ca/byblos, Apache-2.0), vi chinh qpdf lam bo kiem cua no. Ban Java chay duoc
 * `tools/verify/LinearizerCheck.java` giu CUNG thuat toan; kiem chung boi `tools/verify/linearize_check.py` bang `qpdf --check-linearization`. Hai ban PHAI khop nhau.
 *
 * Bo cuc (F.3.1): phan 1 tieu de, 2 tu dien tuyen tinh hoa, 3 xref + trailer trang dau, 4 catalog va doi tuong cap tai lieu, 5 luong goi y, 6 doan trang dau,
 * 7 cac trang con lai, 8 doi tuong chung cua cac trang sau, 9 con lai (cay trang, Info...), 11 xref chinh + trailer. Chi xref co dien, khong luong doi tuong,
 * nen moi o chua biet deu nam trong ngan co do rong biet truoc (20 byte moi muc xref, 201 byte tu dien, 21 byte /Prev) va viec va khong doi do dai.
 */
object Linearizer {

    class Graph {
        /** Doi tuong -> cac doi tuong no tham chieu (theo so hieu GOC). Tap khoa = tap doi tuong se duoc ghi. */
        val refs = TreeMap<Int, List<Int>>()
        var pages: List<Int> = emptyList()
        var pageTree: List<Int> = emptyList()
        var openDoc: List<Int> = emptyList()
        var other: List<Int> = emptyList()
        var catalog = 0
        var info = 0
        var outlines = 0
        var useOutlines = false
    }

    class Plan {
        val renumber = HashMap<Int, Int>()
        var part4: List<Int> = emptyList()
        var part6: List<Int> = emptyList()
        var part7: List<List<Int>> = emptyList()
        var part8: List<Int> = emptyList()
        var part9: List<Int> = emptyList()
        var outlines: List<Int> = emptyList()
        val pageShared = ArrayList<List<Int>>()
        var linDict = 0
        var hint = 0
        var catalog = 0
        var info = 0
        var size = 0
        var nPages = 0
    }

    /** Than mot doi tuong: [dict] (ASCII, chua dau hieu tham chieu) va, neu la luong, du lieu tho [stream] (khong dung vao). */
    class Body(val dict: String, val stream: ByteArray?)

    // ------------------------------------------------------------------ phan vung (layout.go)

    private fun closure(g: Graph, start: Int, barrier: Set<Int>): Set<Int> {
        val seen = HashSet<Int>()
        if (!g.refs.containsKey(start)) return seen
        val st = ArrayDeque<Int>(); st.addLast(start)
        while (st.isNotEmpty()) {
            val n = st.removeLast()
            if (n in seen || !g.refs.containsKey(n)) continue
            if (n != start && n in barrier) continue
            seen.add(n)
            for (r in g.refs.getValue(n)) st.addLast(r)
        }
        return seen
    }

    private fun closureOf(g: Graph, seeds: List<Int>, barrier: Set<Int>): Set<Int> {
        val out = HashSet<Int>()
        for (s in seeds) { if (s in barrier) continue; out.addAll(closure(g, s, barrier)) }
        return out
    }

    private fun lead(first: Int, ns: List<Int>): List<Int> {
        val r = ns.sorted().toMutableList()
        val i = r.indexOf(first)
        if (i > 0) { r.removeAt(i); r.add(0, first) }
        return r
    }

    private fun leadAll(firsts: List<Int>, ns: List<Int>): List<Int> {
        val r = ns.sorted().toMutableList(); val head = ArrayList<Int>()
        for (f in firsts) { val i = r.indexOf(f); if (i >= 0) { head.add(f); r.removeAt(i) } }
        head.addAll(r); return head
    }

    fun planLayout(g: Graph): Plan {
        check(g.pages.isNotEmpty()) { "khong co trang" }
        check(g.catalog != 0) { "khong co catalog" }
        val barrier = HashSet<Int>(g.pages); barrier.addAll(g.pageTree)
        val firstPage = closure(g, g.pages[0], barrier)
        val otherPages = ArrayList<Set<Int>>(); otherPages.add(emptySet())
        val pageCount = HashMap<Int, Int>()
        for (i in 1 until g.pages.size) {
            val c = closure(g, g.pages[i], barrier); otherPages.add(c)
            for (n in c) pageCount[n] = (pageCount[n] ?: 0) + 1
        }
        val openDoc = closureOf(g, g.openDoc, barrier)
        val others = closureOf(g, g.other, barrier)
        val outlinesSet = if (g.outlines != 0) closure(g, g.outlines, barrier) else emptySet()
        val p = Plan(); p.nPages = g.pages.size
        val part4 = ArrayList<Int>(); val part6 = ArrayList<Int>(); val part8 = ArrayList<Int>(); val part9 = ArrayList<Int>()
        val part7 = ArrayList<MutableList<Int>>(); for (i in 0 until g.pages.size - 1) part7.add(ArrayList())
        var outlineGroup = ArrayList<Int>()
        for (n in g.refs.keys) {
            val pc = pageCount[n] ?: 0
            when {
                n == g.catalog -> part4.add(n)
                n in outlinesSet -> outlineGroup.add(n)
                n in openDoc -> part4.add(n)
                n in firstPage -> part6.add(n)
                pc == 1 && n !in others -> { for (i in 1 until g.pages.size) if (n in otherPages[i]) { part7[i - 1].add(n); break } }
                pc > 1 -> part8.add(n)
                else -> part9.add(n)
            }
        }
        var p4: List<Int> = lead(g.catalog, part4)
        var p6: List<Int> = lead(g.pages[0], part6)
        val p7 = ArrayList<List<Int>>(); for (i in part7.indices) p7.add(lead(g.pages[i + 1], part7[i]))
        val p8 = part8.sorted()
        var p9: List<Int> = leadAll(g.pageTree, part9)
        val og = lead(g.outlines, outlineGroup)
        if (g.useOutlines) p6 = p6 + og else p9 = p9 + og
        var next = 1
        for (grp in p7) for (n in grp) p.renumber[n] = next++
        for (n in p8) p.renumber[n] = next++
        for (n in p9) p.renumber[n] = next++
        p.linDict = next++
        for (n in p4) p.renumber[n] = next++
        p.hint = next++
        for (n in p6) p.renumber[n] = next++
        p.size = next
        check(p.renumber.size == g.refs.size) { "phan vung " + p.renumber.size + "/" + g.refs.size }
        val sharedIdx = HashMap<Int, Int>()
        for ((i, n) in p6.withIndex()) sharedIdx[n] = i
        for ((i, n) in p8.withIndex()) sharedIdx[n] = p6.size + i
        p.pageShared.add(emptyList())
        for (i in 1 until g.pages.size) {
            val ids = ArrayList<Int>(); for (n in otherPages[i]) sharedIdx[n]?.let { ids.add(it) }
            ids.sort(); p.pageShared.add(ids)
        }
        p.catalog = p.renumber.getValue(g.catalog)
        if (g.info != 0) p.info = p.renumber.getValue(g.info)
        p.part4 = p4.map { p.renumber.getValue(it) }
        p.part6 = p6.map { p.renumber.getValue(it) }
        p.part7 = p7.map { grp -> grp.map { p.renumber.getValue(it) } }
        p.part8 = p8.map { p.renumber.getValue(it) }
        p.part9 = p9.map { p.renumber.getValue(it) }
        p.outlines = og.map { p.renumber.getValue(it) }
        return p
    }

    // ------------------------------------------------------------------ luong goi y (hints.go)

    private class BitWriter {
        val out = ByteArrayOutputStream(); var acc = 0L; var nAcc = 0
        fun bits(v: Int, n: Int) {
            if (n <= 0) return
            for (i in n - 1 downTo 0) { acc = (acc shl 1) or ((v shr i) and 1).toLong(); nAcc++; if (nAcc == 8) { out.write(acc.toInt()); acc = 0; nAcc = 0 } }
        }
        fun flush() { if (nAcc == 0) return; out.write((acc shl (8 - nAcc)).toInt()); acc = 0; nAcc = 0 }
        fun u32(v: Int) { flush(); out.write(v ushr 24); out.write(v ushr 16); out.write(v ushr 8); out.write(v) }
        fun u16(v: Int) { flush(); out.write(v ushr 8); out.write(v) }
        fun size() = out.size()
    }

    private fun nbits(v: Int): Int { var n = 0; var x = v; while (x > 0) { n++; x = x shr 1 }; return n }

    private class Hints(
        val pageN: IntArray, val pageLen: IntArray, val pageShared: List<List<Int>>, val firstPageOffset: Int,
        val sharedLen: IntArray, val nSharedFirstPage: Int, val firstSharedObj: Int, val firstSharedOffset: Int,
        val hasOutline: Boolean, val oFirst: Int, val oOffset: Int, val oN: Int, val oLen: Int
    )

    /** @return payload, S, O (O = 0 khi khong co bang dan y muc luc). Cac bang la CAC COT dong goi bit MSB truoc, xa xuong ranh gioi byte sau moi cot. */
    private fun encodeHints(h: Hints): Triple<ByteArray, Int, Int> {
        val w = BitWriter(); val np = h.pageN.size
        var minO = Int.MAX_VALUE; var maxO = 0; var minL = Int.MAX_VALUE; var maxL = 0; var maxS = 0
        for (i in 0 until np) { minO = minOf(minO, h.pageN[i]); maxO = maxOf(maxO, h.pageN[i]); minL = minOf(minL, h.pageLen[i]); maxL = maxOf(maxL, h.pageLen[i]); maxS = maxOf(maxS, h.pageShared[i].size) }
        val nbO = nbits(maxO - minO); val nbL = nbits(maxL - minL); val nbS = nbits(maxS); val nbI = nbits(h.sharedLen.size)
        w.u32(minO); w.u32(h.firstPageOffset); w.u16(nbO); w.u32(minL); w.u16(nbL); w.u32(0); w.u16(0); w.u32(minL); w.u16(nbL); w.u16(nbS); w.u16(nbI); w.u16(0); w.u16(4)
        for (i in 0 until np) w.bits(h.pageN[i] - minO, nbO); w.flush()
        for (i in 0 until np) w.bits(h.pageLen[i] - minL, nbL); w.flush()
        for (i in 0 until np) w.bits(h.pageShared[i].size, nbS); w.flush()
        for (i in 0 until np) for (id in h.pageShared[i]) w.bits(id, nbI); w.flush()
        w.flush(); w.flush()
        for (i in 0 until np) w.bits(h.pageLen[i] - minL, nbL); w.flush()
        val s = w.size()
        var minG = 0; var maxG = 0
        for ((i, v) in h.sharedLen.withIndex()) { if (i == 0 || v < minG) minG = v; if (v > maxG) maxG = v }
        val nbG = nbits(maxG - minG)
        w.u32(h.firstSharedObj); w.u32(h.firstSharedOffset); w.u32(h.nSharedFirstPage); w.u32(h.sharedLen.size); w.u16(0); w.u32(minG); w.u16(nbG)
        for (v in h.sharedLen) w.bits(v - minG, nbG); w.flush()
        for (i in h.sharedLen.indices) w.bits(0, 1); w.flush()
        w.flush()
        var o = 0
        if (h.hasOutline) { o = w.size(); w.u32(h.oFirst); w.u32(h.oOffset); w.u32(h.oN); w.u32(h.oLen) }
        w.flush()
        return Triple(w.out.toByteArray(), s, o)
    }

    // ------------------------------------------------------------------ ghep tep (write.go)

    private const val LIN_SLOT = 201
    private const val PREV_SLOT = 21

    private class Buf {
        var a = ByteArray(1 shl 16); var n = 0
        fun add(b: ByteArray) { ensure(b.size); System.arraycopy(b, 0, a, n, b.size); n += b.size }
        fun add(s: String) { add(s.toByteArray(StandardCharsets.ISO_8859_1)) }
        fun rep(c: Char, k: Int) { ensure(k); java.util.Arrays.fill(a, n, n + k, c.code.toByte()); n += k }
        private fun ensure(k: Int) { if (n + k > a.size) a = a.copyOf(maxOf(a.size + (a.size shr 1), n + k)) }   // x1,5: tiet kiem bo nho hon x2
    }

    private fun render(body: Body, renumber: Map<Int, Int>): ByteArray {
        val sb = StringBuilder(); var i = 0; val d = body.dict
        while (i < d.length) {
            val c = d[i]
            if (c == '\u0001') { val j = d.indexOf('\u0002', i); sb.append(renumber.getValue(d.substring(i + 1, j).toInt())).append(" 0 R"); i = j + 1 } else { sb.append(c); i++ }
        }
        val b = Buf(); b.add(sb.toString())
        if (body.stream != null) { b.add("\nstream\n"); b.add(body.stream); b.add("\nendstream") }
        return b.a.copyOf(b.n)
    }

    private fun hex(b: ByteArray): String { val sb = StringBuilder(); for (x in b) sb.append(String.format(Locale.ROOT, "%02x", x.toInt() and 0xFF)); return sb.toString() }

    private fun put(a: ByteArray, pos: Int, off: Int) { val b = String.format(Locale.ROOT, "%010d", off).toByteArray(StandardCharsets.ISO_8859_1); System.arraycopy(b, 0, a, pos, b.size) }

    /**
     * Lap ke hoach, dung tung than doi tuong qua [bodyOf] (nhan so hieu GOC, doc LAZY de moi luc chi giu mot luong lon trong bo nho) va ghi tep tuyen tinh hoa vao [out].
     * Bo nho dinh ~ do dai tep (mot bo dem duy nhat duoc va tai cho roi ghi thanh ba doan), khong dung ban sao thu hai.
     */
    fun linearize(g: Graph, bodyOf: (Int) -> Body, version: String, id0: ByteArray?, id1: ByteArray?, out: OutputStream) {
        val p = planLayout(g)
        val origOf = HashMap<Int, Int>(); for ((o, n) in p.renumber) origOf[n] = o
        val buf = Buf(); val starts = HashMap<Int, Int>(); val ends = HashMap<Int, Int>()
        fun emit(n: Int) {
            val body = render(bodyOf(origOf.getValue(n)), p.renumber)
            starts[n] = buf.n; buf.add("$n 0 obj\n"); buf.add(body); buf.add("\nendobj\n"); ends[n] = buf.n
        }
        buf.add("%PDF-" + version.ifEmpty { "1.4" } + "\n"); buf.add(byteArrayOf('%'.code.toByte(), 0xE2.toByte(), 0xE3.toByte(), 0xCF.toByte(), 0xD3.toByte(), '\n'.code.toByte()))
        val linOff = buf.n; buf.rep(' ', LIN_SLOT); starts[p.linDict] = linOff
        val first = ArrayList<Int>(); first.add(p.linDict); first.addAll(p.part4); first.add(p.hint); first.addAll(p.part6)
        for (i in first.indices) check(first[i] == p.linDict + i) { "nhom dau khong lien tuc" }
        val xref3 = buf.n; buf.add("xref\n" + first[0] + " " + first.size + "\n")
        val frontEntry = IntArray(first.size); for (i in first.indices) { frontEntry[i] = buf.n; buf.add("0000000000 00000 n \n") }
        val idl = if (id0 == null) "" else "[<" + hex(id0) + "><" + hex(id1 ?: id0) + ">]"
        buf.add("trailer\n<< /Size " + p.size + " /Root " + p.catalog + " 0 R" + (if (p.info != 0) " /Info " + p.info + " 0 R" else "") + " /Prev ")
        val prevPos = buf.n; buf.rep(' ', PREV_SLOT)
        if (idl.isNotEmpty()) buf.add(" /ID $idl")
        buf.add(" >>\nstartxref\n0\n%%EOF\n")
        for (n in p.part4) emit(n)
        val hintOff = buf.n
        for (n in p.part6) emit(n)
        val endFirst = buf.n
        for (grp in p.part7) for (n in grp) emit(n)
        for (n in p.part8) emit(n)
        for (n in p.part9) emit(n)
        val secondGroup = p.linDict - 1; val xrefMain = buf.n
        buf.add("xref\n0 " + (secondGroup + 1)); val spaceBeforeZero = buf.n; buf.add("\n"); buf.add("0000000000 65535 f \n")
        val mainEntry = IntArray(secondGroup); for (i in 0 until secondGroup) { mainEntry[i] = buf.n; buf.add("0000000000 00000 n \n") }
        buf.add("trailer\n<< /Size " + (secondGroup + 1) + (if (idl.isEmpty()) "" else " /ID $idl") + " >>\nstartxref\n" + xref3 + "\n"); buf.add("%%EOF\n")
        val preLen = buf.n
        val np = 1 + p.part7.size
        val pageN = IntArray(np); val pageLen = IntArray(np); val pageShared = ArrayList<List<Int>>()
        pageN[0] = p.part6.size; pageLen[0] = endFirst - hintOff; pageShared.add(emptyList())
        for ((i, grp) in p.part7.withIndex()) {
            check(grp.isNotEmpty()) { "trang " + (i + 2) + " khong co doi tuong" }
            pageN[i + 1] = grp.size; pageLen[i + 1] = ends.getValue(grp.last()) - starts.getValue(grp.first()); pageShared.add(p.pageShared[i + 1])
        }
        val sharedLen = ArrayList<Int>(); for (n in p.part6) sharedLen.add(ends.getValue(n) - starts.getValue(n)); for (n in p.part8) sharedLen.add(ends.getValue(n) - starts.getValue(n))
        var firstSharedObj = 0; var firstSharedOffset = 0
        if (p.part8.isNotEmpty()) { firstSharedObj = p.part8[0]; firstSharedOffset = starts.getValue(p.part8[0]) }
        var hasOutline = false; var oFirst = 0; var oOffset = 0; var oN = 0; var oLen = 0
        if (p.outlines.isNotEmpty()) {
            var end = 0; for (n in p.outlines) end = maxOf(end, ends.getValue(n))
            hasOutline = true; oFirst = p.outlines[0]; oOffset = starts.getValue(p.outlines[0]); oN = p.outlines.size; oLen = end - oOffset
        }
        val (payload, s, o) = encodeHints(Hints(pageN, pageLen, pageShared, hintOff, sharedLen.toIntArray(), p.part6.size, firstSharedObj, firstSharedOffset, hasOutline, oFirst, oOffset, oN, oLen))
        val df = Deflater(); df.setInput(payload); df.finish()
        val z = ByteArrayOutputStream(); val tmp = ByteArray(8192); while (!df.finished()) z.write(tmp, 0, df.deflate(tmp)); df.end()
        val hb = Buf(); hb.add(p.hint.toString() + " 0 obj\n<< /Filter /FlateDecode /S " + s + (if (o != 0) " /O $o" else "") + " /Length " + z.size() + " >>\nstream\n")
        hb.add(z.toByteArray()); hb.add("\nendstream\nendobj\n")
        val hintLen = hb.n
        fun shift(off: Int) = if (off >= hintOff) off + hintLen else off
        val lin = p.linDict.toString() + " 0 obj\n<< /Linearized 1 /L " + (preLen + hintLen) + " /H [ " + hintOff + " " + hintLen + " ] /O " + p.part6[0] + " /E " + shift(endFirst) + " /N " + p.nPages + " /T " + shift(spaceBeforeZero) + " >>\nendobj\n"
        check(lin.length <= LIN_SLOT - 1) { "tu dien tuyen tinh hoa qua dai" }
        val lb = lin.toByteArray(StandardCharsets.ISO_8859_1); System.arraycopy(lb, 0, buf.a, linOff, lb.size); buf.a[linOff + LIN_SLOT - 1] = '\n'.code.toByte()
        for (i in first.indices) { val n = first[i]; put(buf.a, frontEntry[i], if (n == p.hint) hintOff else shift(starts.getValue(n))) }
        val prev = shift(xrefMain).toString().toByteArray(StandardCharsets.ISO_8859_1); check(prev.size <= PREV_SLOT) { "/Prev qua dai" }; System.arraycopy(prev, 0, buf.a, prevPos, prev.size)
        for (i in 0 until secondGroup) put(buf.a, mainEntry[i], shift(starts.getValue(i + 1)))
        out.write(buf.a, 0, hintOff); out.write(hb.a, 0, hintLen); out.write(buf.a, hintOff, preLen - hintOff)
        out.flush()
    }
}
