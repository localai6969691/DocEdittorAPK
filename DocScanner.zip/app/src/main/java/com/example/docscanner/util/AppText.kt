package com.example.docscanner.util

import android.content.Context
import android.content.res.Configuration
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatDelegate
import com.example.docscanner.DocScannerApp
import com.example.docscanner.R

/**
 * Chuoi theo NGON NGU DANG CHON cho cac lop tien ich khong co Context (EbookBuilder, EpubReader, PdfExporter, PdfComparer...): noi dung ma chung GHI VAO tep xuat
 * ("(khong co van ban)", "Chuong N", chu thich bao cao...) phai theo ngon ngu giao dien, khong duoc cung mot thu tieng. Phien 18, TECHNICAL_DOCS.md 4.46.
 * Android 13+ ap ngon ngu rieng cua app len ca Context cua ung dung; tu Android 12 tro xuong chi co Activity theo ngon ngu da chon (AppCompatDelegate), nen [localized] tu ap
 * ngon ngu do len Context ung dung khi can.
 */
object AppText {
    fun localized(base: Context): Context {
        val locales = AppCompatDelegate.getApplicationLocales()
        if (locales.isEmpty) return base
        val first = locales[0] ?: return base
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(first)
        return base.createConfigurationContext(cfg)
    }

    fun get(@StringRes id: Int, vararg args: Any): String {
        val ctx = localized(DocScannerApp.instance)
        return if (args.isEmpty()) ctx.getString(id) else ctx.getString(id, *args)
    }

    /**
     * Dong thay the "khong nhan dien duoc van ban" trong tep .txt: bang chuoi cua ngon ngu hien tai, HOAC bang ban Viet / Anh cu (tep ghi bang ngon ngu truoc do),
     * de chi muc tim kiem khong lap dong do thanh noi dung. Dau "--- Trang N ---" la DINH DANG tep (khong phai nhan giao dien) nen giu nguyen de doc duoc tep cu.
     */
    fun isOcrPlaceholder(line: String): Boolean =
        line == get(R.string.ocr_no_text_placeholder) || line.startsWith("(không nhận diện được") || line.startsWith("(no text recognized")
}
