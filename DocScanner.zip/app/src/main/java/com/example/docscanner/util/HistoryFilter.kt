package com.example.docscanner.util

import java.io.File
import java.text.Normalizer
import java.util.Locale

/**
 * Search, sort and "favourites first" for the list of exported documents on the main screen.
 *
 * Search ignores case AND diacritics, because Vietnamese is usually typed without them on a phone: "hop dong" must
 * find "Hợp đồng thuê nhà.pdf". [normalize] lower-cases, splits accented letters into base letter + combining mark
 * (NFD), drops the marks, and maps "đ" to "d" (NFD does not split it). Several words in the query must ALL appear
 * (in any order). A blank query matches everything.
 *
 * Content: [arrange] also takes the text of each document ([ContentIndex], already normalized). A query word counts as found when it
 * occurs in the name, the tags OR the content - so "hop dong thue" can find a scan whose NAME is "scan_001.pdf" and whose OCR text says
 * "hợp đồng thuê nhà". Every word must still be found somewhere (AND).
 *
 * Tags ([TagStore]): the search also matches the text of a document's tags, and an optional [arrange] `tagFilter` keeps only documents
 * carrying that tag (compared ignoring case and diacritics).
 *
 * Favourites are pinned above the rest; inside each group the chosen [Sort] applies, and equal items keep their
 * previous order (the sort is stable). All of it is pure, so it is mirrored in tools/verify/history_filter_check.py.
 */
object HistoryFilter {

    enum class Sort { NEWEST, NAME, LARGEST }

    private val combiningMarks = Regex("\\p{Mn}+")

    fun normalize(text: String): String =
        combiningMarks.replace(Normalizer.normalize(text.lowercase(Locale.ROOT), Normalizer.Form.NFD), "")
            .replace('đ', 'd')

    /** True if every whitespace-separated word of [query] occurs in [name] (both normalized). */
    fun matches(name: String, query: String): Boolean {
        val words = normalize(query).split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty()) return true
        val hay = normalize(name)
        return words.all { hay.contains(it) }
    }

    fun <T> arrange(
        items: List<T>,
        name: (T) -> String,
        modified: (T) -> Long,
        size: (T) -> Long,
        favorite: (T) -> Boolean,
        query: String,
        sort: Sort,
        tags: (T) -> Set<String> = { emptySet() },
        tagFilter: String? = null,
        content: (T) -> String? = { null }
    ): List<T> {
        val words = normalize(query).split(Regex("\\s+")).filter { it.isNotEmpty() }
        val kept = items.filter { item ->
            val itemTags = tags(item)
            (tagFilter == null || itemTags.any { TagTree.matches(it, tagFilter) }) &&         // a folder filter includes its sub-folders (TagTree)
                (words.isEmpty() || run {
                    val nameAndTags = normalize(name(item) + " " + itemTags.joinToString(" "))
                    val body = content(item)      // already normalized: not normalized again (that would cost far more than the search)
                    words.all { nameAndTags.contains(it) || (body != null && body.contains(it)) }
                })
        }
        val sorted = when (sort) {
            Sort.NEWEST -> kept.sortedByDescending(modified)
            Sort.NAME -> kept.sortedWith(compareBy({ normalize(name(it)) }, { name(it) }))
            Sort.LARGEST -> kept.sortedByDescending(size)
        }
        val (fav, rest) = sorted.partition(favorite)
        return fav + rest
    }

    fun arrangeFiles(
        files: List<File>, query: String, sort: Sort, favorites: Set<String>,
        tagsByName: Map<String, Set<String>> = emptyMap(), tagFilter: String? = null,
        content: (File) -> String? = { null }
    ): List<File> =
        arrange(files, { it.name }, { it.lastModified() }, { it.length() }, { it.name in favorites }, query, sort,
            { tagsByName[it.name] ?: emptySet() }, tagFilter, content)
}
