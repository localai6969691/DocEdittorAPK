package com.example.docscanner

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.example.docscanner.util.AppShortcuts

/**
 * Home-screen widget "Quick scan" (PDF list K1): three buttons - Scan, Sign PDF, Searchable PDF - that open [MainActivity] with the SAME
 * action strings the launcher shortcuts use ([AppShortcuts]), so `MainActivity.handleShortcutIntent` opens the tool and nothing new is needed
 * there. The app lock still comes first (the activity locks itself on start). Nothing is shown that could leak a document: the widget has no
 * data, only buttons, and updatePeriodMillis is 0 because there is nothing to refresh.
 *
 * Intents are built from the running app's own context (like [AppShortcuts]) because the applicationId comes from the APP_ID repository
 * variable and is not known when the XML is written. NEW_TASK | CLEAR_TOP | SINGLE_TOP: a MainActivity that is already open receives
 * the action through onNewIntent instead of a second copy being stacked on top.
 */
class ScanWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) appWidgetManager.updateAppWidget(id, build(context))
    }

    companion object {
        /** (view id, request code, action): the request codes differ so that the three PendingIntents never replace each other. */
        val BUTTONS: List<Triple<Int, Int, String>> = listOf(
            Triple(R.id.widgetScan, 101, AppShortcuts.ACTION_SCAN),
            Triple(R.id.widgetSign, 102, AppShortcuts.ACTION_SIGN),
            Triple(R.id.widgetSearchable, 103, AppShortcuts.ACTION_SEARCHABLE)
        )

        fun build(context: Context): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.widget_scan)
            for ((viewId, requestCode, action) in BUTTONS) {
                val intent = Intent(context, MainActivity::class.java).setAction(action)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                views.setOnClickPendingIntent(
                    viewId,
                    PendingIntent.getActivity(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                )
            }
            return views
        }
    }
}
