package com.example.docscanner.util

/**
 * Voice commands for the whole main screen (phien 27, TECHNICAL_DOCS.md 4.87; PDF list item I2). The system speech recogniser (no microphone permission) hears a sentence such as
 * "open compress PDF" / "mo nen pdf" / "abrir comprimir pdf"; [toQuery] drops the leading command word(s) and a trailing "please", and [pick] chooses the ONE tool whose name fits, using
 * the same accent-blind matching as "Find a tool" ([CommandPalette]). It only acts when the answer is clear: the best score must be a real name match (>= 60: the whole name, its start,
 * the start of a word or inside it) AND strictly better than the second best; otherwise null, and the caller puts the words in the search box so the person chooses. Pure, no Android:
 * tools/verify/voice_command_real_run_check.py runs it for real.
 */
object VoiceCommand {

    /** Leading words that only say "do it" (folded: lower case, no accents). Longest first, so "go to" wins over "go". */
    private val LEADING = listOf(
        "open the", "go to the", "go to", "start the", "use the", "run the", "open", "start", "launch", "use", "run", "show",
        "mo cong cu", "mo ra", "vao", "mo", "chay", "dung", "bat dau", "cho toi", "hay",
        "ouvre", "ouvrir", "lance", "lancer", "utilise", "ouvrez",
        "offne", "oeffne", "starte", "starten", "benutze", "zeige",
        "abre", "abrir", "inicia", "iniciar", "usa", "usar", "ejecuta", "abra", "inicie", "use o",
        "buka", "jalankan", "gunakan", "mulai",
        "otkroi", "otkryt", "zapusti", "zapustit"
    )
    private val TRAILING = listOf("please", "now", "for me", "di", "nhe", "giup toi", "voi", "por favor", "s'il vous plait", "bitte", "pozhaluista")

    /** What is left of [heard] once the command words around the tool name are dropped; the accents are KEPT here (the caller matches with [CommandPalette], which ignores them). */
    fun toQuery(heard: String): String {
        var s = heard.trim().replace(Regex("\\s+"), " ")
        var changed = true
        while (changed && s.isNotEmpty()) {
            changed = false
            val folded = CommandPalette.fold(s)
            for (w in LEADING) {
                if (folded == w) { return "" }
                if (folded.startsWith("$w ")) {
                    s = dropWords(s, w.count { it == ' ' } + 1)
                    changed = true
                    break
                }
            }
        }
        changed = true
        while (changed && s.isNotEmpty()) {
            changed = false
            val folded = CommandPalette.fold(s)
            for (w in TRAILING) {
                if (folded.endsWith(" $w")) {
                    s = dropLastWords(s, w.count { it == ' ' } + 1)
                    changed = true
                    break
                }
            }
        }
        return s.trim()
    }

    private fun dropWords(s: String, n: Int): String = s.split(' ').drop(n).joinToString(" ")
    private fun dropLastWords(s: String, n: Int): String = s.split(' ').dropLast(n).joinToString(" ")

    /** The index in [names] of the tool [heard] asks for, or null when it is unclear (nothing fits well, or two tools fit equally well). */
    fun pick(heard: String, names: List<String>): Int? {
        val q = toQuery(heard)
        if (q.isEmpty()) return null
        val scored = names.mapIndexed { i, n -> Pair(i, CommandPalette.score(q, n)) }.filter { it.second >= MIN_SCORE }.sortedWith(compareBy({ -it.second }, { it.first }))
        if (scored.isEmpty()) return null
        if (scored.size > 1 && scored[0].second == scored[1].second) return null
        return scored[0].first
    }

    const val MIN_SCORE = 60
}
