package com.example.docscanner

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityConvertDocumentBinding
import com.example.docscanner.model.ScanSessionManager
import com.example.docscanner.util.DocumentImport
import com.example.docscanner.util.EbookBuilder
import com.example.docscanner.util.Ccitt4Decoder
import com.example.docscanner.util.Ccitt4Encoder
import com.example.docscanner.util.EpubReader
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.ImageProcessor
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfPageBitmap
import com.example.docscanner.util.TablePdfBuilder
import com.example.docscanner.util.TextPdfBuilder
import com.example.docscanner.util.TiffWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import com.example.docscanner.util.OfficeImport
import com.example.docscanner.util.RtfImport

/**
 * General "convert between formats" entry point. PDF-sourced conversions are delegated to the
 * screens that already do them well (OCR + chapter editing for PDF->EPUB/TXT, page export for
 * PDF->Images) rather than duplicating that logic here - this activity only implements the
 * genuinely new conversions: EPUB<->TXT<->PDF, EPUB/TXT->FB2 and Images->PDF; since phiên 19 also Markdown / HTML / Word (.docx) -> PDF / EPUB / FB2 and CSV / TSV -> PDF
 * (a table drawn as a grid), read by [DocumentImport].
 */
class ConvertDocumentActivity : BaseActivity() {

    private lateinit var binding: ActivityConvertDocumentBinding

    private val epubPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) convertEpub(uri, pendingTarget) else finish()
    }
    private val txtPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) convertTxt(uri, pendingTarget) else finish()
    }
    private val tiffPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) convertPdfToTiff(uri, pendingTiffColor) else finish()
    }
    private val markupPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) convertMarkup(uri, pendingTarget) else finish()
    }
    private val tablePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) convertTable(uri) else finish()
    }
    private val imagesPicker = registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(50)) { uris ->
        if (uris.isNotEmpty()) convertImagesToPdf(uris) else finish()
    }

    /** What an EPUB / TXT source is converted into: a PDF, an FB2 file, or "the other ebook format" (TXT from EPUB, EPUB from TXT). */
    private enum class Target { PDF, OTHER_EBOOK, FB2 }

    private var pendingTarget = Target.PDF
    private var pendingTiffColor = false

    private companion object {
        /** A source file larger than this is refused (a text-like file of this size is already thousands of pages). */
        const val MAX_SOURCE_BYTES = 40 * 1024 * 1024

        /** The sources [convertMarkup] reads as blocks. */
        val MARKUP_KINDS = setOf(
            DocumentImport.Kind.MARKDOWN, DocumentImport.Kind.HTML, DocumentImport.Kind.DOCX,
            DocumentImport.Kind.ODT, DocumentImport.Kind.PPTX, DocumentImport.Kind.RTF
        )

        /** TIFF page widths in pixels: A4 at 300 dpi for the black & white (CCITT) kind, A4 at 200 dpi for colour (the file is raw pixels + Deflate, so it grows with the area). */
        const val TIFF_BW_WIDTH = 2480
        const val TIFF_COLOR_WIDTH = 1654
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityConvertDocumentBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        if (savedInstanceState == null) {
            showSourceDialog()
        }
    }

    private fun showSourceDialog() {
        val options = arrayOf(
            getString(R.string.convert_source_pdf),
            getString(R.string.convert_source_epub),
            getString(R.string.convert_source_txt),
            getString(R.string.convert_source_images),
            getString(R.string.convert_source_markup),
            getString(R.string.convert_source_table)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.convert_source_title)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> showPdfTargetDialog()
                    1 -> showEpubTargetDialog()
                    2 -> showTxtTargetDialog()
                    3 -> imagesPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    4 -> showMarkupTargetDialog()
                    5 -> tablePicker.launch(arrayOf("*/*"))   // the type is checked by name afterwards: providers report .md / .csv with many different MIME types
                }
            }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun showPdfTargetDialog() {
        val options = arrayOf(
            getString(R.string.convert_target_ebook_group),
            getString(R.string.convert_target_images),
            getString(R.string.convert_target_tiff_bw),
            getString(R.string.convert_target_tiff_color)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.convert_target_title)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        ScanSessionManager.clear()
                        startActivity(Intent(this, EbookExportActivity::class.java))
                        finish()
                    }
                    1 -> {
                        startActivity(Intent(this, PdfPageEditorActivity::class.java))
                        finish()
                    }
                    else -> {
                        pendingTiffColor = which == 3
                        tiffPicker.launch(arrayOf("application/pdf"))   // this activity stays open: the picker returns here
                    }
                }
            }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun showEpubTargetDialog() {
        val options = arrayOf(
            getString(R.string.convert_target_pdf),
            getString(R.string.convert_target_txt),
            getString(R.string.convert_target_fb2)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.convert_target_title)
            .setItems(options) { _, which ->
                pendingTarget = when (which) {
                    0 -> Target.PDF
                    1 -> Target.OTHER_EBOOK
                    else -> Target.FB2
                }
                epubPicker.launch(arrayOf("application/epub+zip"))
            }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun showTxtTargetDialog() {
        val options = arrayOf(
            getString(R.string.convert_target_pdf),
            getString(R.string.convert_target_epub),
            getString(R.string.convert_target_fb2)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.convert_target_title)
            .setItems(options) { _, which ->
                pendingTarget = when (which) {
                    0 -> Target.PDF
                    1 -> Target.OTHER_EBOOK
                    else -> Target.FB2
                }
                txtPicker.launch(arrayOf("text/plain"))
            }
            .setOnCancelListener { finish() }
            .show()
    }

    /**
     * PDF -> multi-page TIFF (4.47.4). Every page is rendered with [PdfRenderer][PdfPageBitmap] and written as soon as it is ready ([TiffWriter.Writer] appends to the file), so a long
     * document never sits in memory whole. Black & white: 2480 px wide (A4 at 300 dpi), the BW filter, then CCITT Group 4 - checked by decoding it back ([Ccitt4Decoder.verify]), and
     * stored as 8-bit gray + Deflate for that page if the check ever fails. Colour: 1654 px wide (A4 at 200 dpi), RGB + Deflate with the horizontal predictor.
     */
    private fun convertPdfToTiff(uri: Uri, color: Boolean) {
        setBusy(true)
        lifecycleScope.launch {
            val outFile = com.example.docscanner.util.KeepAlive.during(applicationContext) { withContext(Dispatchers.Default) {
                val temp = FileUtils.copyUriToTempFile(this@ConvertDocumentActivity, uri, ".pdf") ?: return@withContext null
                try {
                    val session = PdfPageBitmap.open(temp) ?: return@withContext null   // password-protected or unreadable
                    val out = File(PdfExporter.exportDir(this@ConvertDocumentActivity), "${FileUtils.defaultConvertedName()}.tif")
                    val width = if (color) TIFF_COLOR_WIDTH else TIFF_BW_WIDTH
                    var pages = 0
                    try {
                        TiffWriter.Writer(out).use { writer ->
                            session.use { s ->
                                for (i in 0 until s.pageCount) {
                                    val bitmap = s.render(i, width) ?: continue
                                    val dpi = TiffWriter.dpiFor(bitmap.width, s.pageWidthPoints(i))
                                    writer.add(tiffPage(bitmap, color, dpi))
                                    bitmap.recycle()
                                    pages++
                                }
                            }
                        }
                    } catch (e: Exception) {
                        pages = 0
                    }
                    if (pages == 0) { runCatching { out.delete() }; null } else out
                } finally {
                    temp.delete()
                }
            } }
            setBusy(false)
            finishWithResult(outFile)
        }
    }

    private fun tiffPage(bitmap: android.graphics.Bitmap, color: Boolean, dpi: Int): TiffWriter.Page {
        val w = bitmap.width
        val h = bitmap.height
        if (color) return TiffWriter.Page(w, h, TiffWriter.Kind.RGB_DEFLATE, rgbBytes(bitmap), dpi)
        val bw = ImageProcessor.applyFilter(bitmap, ImageProcessor.ScanFilter.BW)
        val g4 = Ccitt4Encoder.encode(bw)
        val page = if (Ccitt4Decoder.verify(g4, bw)) TiffWriter.Page(w, h, TiffWriter.Kind.BILEVEL_G4, g4, dpi)
        else TiffWriter.Page(w, h, TiffWriter.Kind.GRAY_DEFLATE, grayBytes(bw), dpi)   // the self-check failed (not expected): a larger but correct page instead of a corrupt one
        if (bw !== bitmap) bw.recycle()
        return page
    }

    private fun rgbBytes(bitmap: android.graphics.Bitmap): ByteArray {
        val w = bitmap.width
        val h = bitmap.height
        val out = ByteArray(w * h * 3)
        val row = IntArray(w)
        var o = 0
        for (y in 0 until h) {
            bitmap.getPixels(row, 0, w, 0, y, w, 1)
            for (x in 0 until w) {
                val p = row[x]
                out[o++] = ((p shr 16) and 0xFF).toByte()
                out[o++] = ((p shr 8) and 0xFF).toByte()
                out[o++] = (p and 0xFF).toByte()
            }
        }
        return out
    }

    private fun grayBytes(bitmap: android.graphics.Bitmap): ByteArray {
        val w = bitmap.width
        val h = bitmap.height
        val out = ByteArray(w * h)
        val row = IntArray(w)
        var o = 0
        for (y in 0 until h) {
            bitmap.getPixels(row, 0, w, 0, y, w, 1)
            for (x in 0 until w) {
                val p = row[x]
                out[o++] = ((((p shr 16) and 0xFF) + ((p shr 8) and 0xFF) + (p and 0xFF)) / 3).toByte()
            }
        }
        return out
    }

    private fun showMarkupTargetDialog() {
        val options = arrayOf(
            getString(R.string.convert_target_pdf),
            getString(R.string.convert_target_epub),
            getString(R.string.convert_target_fb2)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.convert_target_title)
            .setItems(options) { _, which ->
                pendingTarget = when (which) {
                    0 -> Target.PDF
                    1 -> Target.OTHER_EBOOK
                    else -> Target.FB2
                }
                markupPicker.launch(arrayOf("*/*"))
            }
            .setOnCancelListener { finish() }
            .show()
    }

    private fun displayName(uri: Uri): String {
        var name = ""
        try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) name = c.getString(0)
            }
        } catch (e: Exception) { /* no name: the type is then unknown */ }
        return name.ifBlank { uri.lastPathSegment ?: "" }
    }

    /** Reads at most [MAX_SOURCE_BYTES] of the file (a 100 MB "markdown" file would only exhaust memory); null when it cannot be read or is larger. */
    private fun readSource(uri: Uri): ByteArray? = try {
        contentResolver.openInputStream(uri)?.use { input ->
            val out = java.io.ByteArrayOutputStream()
            val buf = ByteArray(32 * 1024)
            var total = 0
            while (true) {
                val n = input.read(buf)
                if (n < 0) break
                total += n
                if (total > MAX_SOURCE_BYTES) return@use null
                out.write(buf, 0, n)
            }
            out.toByteArray()
        }
    } catch (e: Exception) {
        null
    }

    /**
     * Markdown / HTML / Word (.docx) / OpenDocument text (.odt) / PowerPoint (.pptx) / RTF -> PDF, EPUB or FB2: [DocumentImport], [OfficeImport] and [RtfImport] read the blocks (a slide is a level 2
     * heading, so a deck becomes one chapter per slide), chapters start at every level 1 or 2 heading, and the ebook builders do the rest.
     */
    private fun convertMarkup(uri: Uri, target: Target) {
        val name = displayName(uri)
        val kind = DocumentImport.detectKind(name)
        if (kind !in MARKUP_KINDS) {
            Toast.makeText(this, R.string.convert_markup_unsupported, Toast.LENGTH_LONG).show()
            finish()
            return
        }
        setBusy(true)
        lifecycleScope.launch {
            val outFile = com.example.docscanner.util.KeepAlive.during(applicationContext) { withContext(Dispatchers.Default) {
                val bytes = readSource(uri) ?: return@withContext null
                val blocks = try {
                    when (kind) {
                        DocumentImport.Kind.MARKDOWN -> DocumentImport.blocksFromMarkdown(DocumentImport.decodeText(bytes))
                        DocumentImport.Kind.HTML -> DocumentImport.blocksFromHtml(DocumentImport.decodeText(bytes, sniffHtmlCharset = true))
                        DocumentImport.Kind.ODT -> OfficeImport.blocksFromOdt(java.io.ByteArrayInputStream(bytes))
                        DocumentImport.Kind.PPTX -> OfficeImport.blocksFromPptx(java.io.ByteArrayInputStream(bytes)) { n -> getString(R.string.convert_slide_n, n) }
                        DocumentImport.Kind.RTF -> RtfImport.blocksFromRtf(RtfImport.decode(bytes))
                        else -> DocumentImport.blocksFromDocx(java.io.ByteArrayInputStream(bytes))
                    }
                } catch (e: Exception) {
                    emptyList()
                }
                if (blocks.isEmpty()) return@withContext null
                val fallback = name.substringBeforeLast('.', name).ifBlank { getString(R.string.ebook_default_title) }
                val title = DocumentImport.documentTitle(blocks, fallback)
                val chapters = DocumentImport.chapters(blocks, title)
                val baseName = FileUtils.defaultConvertedName()
                val dir = PdfExporter.exportDir(this@ConvertDocumentActivity)
                when (target) {
                    Target.PDF -> File(dir, "$baseName.pdf").also { TextPdfBuilder.build(it, chapters) }
                    Target.FB2 -> File(dir, "$baseName.fb2").also { EbookBuilder.buildFb2(it, title, chapters) }
                    Target.OTHER_EBOOK -> File(dir, "$baseName.epub").also { EbookBuilder.buildEpub(it, title, chapters) }
                }
            } }
            setBusy(false)
            finishWithResult(outFile)
        }
    }

    /**
     * CSV / TSV / Excel (.xlsx) -> PDF with a real grid ([TablePdfBuilder]). CSV: the delimiter is `TAB` for .tsv and otherwise detected from the first rows. XLSX: every visible sheet
     * ([OfficeImport.sheetsFromXlsx]), one after another, each starting on a new page under its name.
     */
    private fun convertTable(uri: Uri) {
        val name = displayName(uri)
        setBusy(true)
        lifecycleScope.launch {
            val outFile = com.example.docscanner.util.KeepAlive.during(applicationContext) { withContext(Dispatchers.Default) {
                val bytes = readSource(uri) ?: return@withContext null
                if (DocumentImport.detectKind(name) == DocumentImport.Kind.XLSX) {
                    val sheets = try { OfficeImport.sheetsFromXlsx(java.io.ByteArrayInputStream(bytes)) } catch (e: Exception) { emptyList() }
                    val xlsxFile = File(PdfExporter.exportDir(this@ConvertDocumentActivity), "${FileUtils.defaultConvertedName()}.pdf")
                    return@withContext if (TablePdfBuilder.buildSheets(xlsxFile, sheets)) xlsxFile else null
                }
                val text = DocumentImport.decodeText(bytes)
                val delimiter = if (DocumentImport.detectKind(name) == DocumentImport.Kind.TSV) '\t' else DocumentImport.detectDelimiter(text)
                val rows = DocumentImport.parseCsv(text, delimiter)
                val file = File(PdfExporter.exportDir(this@ConvertDocumentActivity), "${FileUtils.defaultConvertedName()}.pdf")
                if (TablePdfBuilder.build(file, rows)) file else null
            } }
            setBusy(false)
            finishWithResult(outFile)
        }
    }

    private fun convertEpub(uri: Uri, target: Target) {
        setBusy(true)
        lifecycleScope.launch {
            val outFile = com.example.docscanner.util.KeepAlive.during(applicationContext) { withContext(Dispatchers.Default) {
                val temp = FileUtils.copyUriToTempFile(this@ConvertDocumentActivity, uri, ".epub")
                    ?: return@withContext null
                val chapters = EpubReader.read(temp)
                temp.delete()
                if (chapters.isEmpty()) return@withContext null
                val baseName = FileUtils.defaultConvertedName()
                val dir = PdfExporter.exportDir(this@ConvertDocumentActivity)
                when (target) {
                    Target.PDF -> File(dir, "$baseName.pdf").also { TextPdfBuilder.build(it, chapters) }
                    Target.FB2 -> File(dir, "$baseName.fb2").also {
                        EbookBuilder.buildFb2(it, getString(R.string.ebook_default_title), chapters)
                    }
                    Target.OTHER_EBOOK -> File(dir, "$baseName.txt").also {
                        EbookBuilder.buildTxt(it, getString(R.string.ebook_default_title), chapters)
                    }
                }
            } }
            setBusy(false)
            finishWithResult(outFile)
        }
    }

    private fun convertTxt(uri: Uri, target: Target) {
        setBusy(true)
        lifecycleScope.launch {
            val outFile = com.example.docscanner.util.KeepAlive.during(applicationContext) { withContext(Dispatchers.Default) {
                val text = try {
                    contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.readText()
                } catch (e: Exception) {
                    null
                } ?: return@withContext null
                val paragraphs = text.split("\n").map { it.trim() }.filter { it.isNotBlank() }
                if (paragraphs.isEmpty()) return@withContext null
                val chapters = listOf(EbookBuilder.Chapter(getString(R.string.ebook_default_title), paragraphs))
                val baseName = FileUtils.defaultConvertedName()
                val dir = PdfExporter.exportDir(this@ConvertDocumentActivity)
                when (target) {
                    Target.PDF -> File(dir, "$baseName.pdf").also { TextPdfBuilder.build(it, chapters) }
                    Target.FB2 -> File(dir, "$baseName.fb2").also {
                        EbookBuilder.buildFb2(it, getString(R.string.ebook_default_title), chapters)
                    }
                    Target.OTHER_EBOOK -> File(dir, "$baseName.epub").also {
                        EbookBuilder.buildEpub(it, getString(R.string.ebook_default_title), chapters)
                    }
                }
            } }
            setBusy(false)
            finishWithResult(outFile)
        }
    }

    private fun convertImagesToPdf(uris: List<Uri>) {
        setBusy(true)
        lifecycleScope.launch {
            val outFile = com.example.docscanner.util.KeepAlive.during(applicationContext) { withContext(Dispatchers.Default) {
                val paths = uris.mapIndexedNotNull { index, uri ->
                    try {
                        val file = FileUtils.newImportedFile(this@ConvertDocumentActivity, index)
                        contentResolver.openInputStream(uri)?.use { input ->
                            FileOutputStream(file).use { output -> input.copyTo(output) }
                        }
                        file.absolutePath
                    } catch (e: Exception) {
                        null
                    }
                }
                if (paths.isEmpty()) return@withContext null
                val baseName = FileUtils.defaultConvertedName()
                PdfExporter.exportImagePaths(this@ConvertDocumentActivity, paths, List(paths.size) { 0 }, baseName)
            } }
            setBusy(false)
            finishWithResult(outFile)
        }
    }

    private fun finishWithResult(outFile: File?) {
        if (outFile == null) {
            Toast.makeText(this, R.string.convert_no_text_found, Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, getString(R.string.convert_success, outFile.name), Toast.LENGTH_LONG).show()
        }
        finish()
    }

    private fun setBusy(busy: Boolean) {
        binding.progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        binding.tvStatus.visibility = if (busy) View.VISIBLE else View.GONE
        if (busy) binding.tvStatus.text = getString(R.string.convert_progress)
    }
}
