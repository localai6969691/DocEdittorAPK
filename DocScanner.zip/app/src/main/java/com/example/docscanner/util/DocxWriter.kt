package com.example.docscanner.util

import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Writes a minimal but valid Word document (.docx) from plain text - no library: a .docx is a ZIP of a few XML parts
 * ([Content_Types].xml, the package relationships, word/document.xml, word/styles.xml, the document relationships). The
 * output opens in Word and LibreOffice and python-docx (tools/verify/docx_check.py, through the Java twin DocxCheck.java that
 * runs on a JVM). Page: A4, Vietnamese official-document margins (left 3 cm, others 2 cm), Times New Roman 13 pt. Text is Unicode,
 * so Vietnamese diacritics need nothing special.
 *
 * What it does NOT do: it carries text only (no pictures, tables, columns or fonts of the source); OCR text has no real paragraph
 * information, so [paragraphsFromText] guesses it (see there).
 */
object DocxWriter {

    /**
     * A paragraph that is exactly this string becomes a page break (used between OCR'd pages). A private-use character on purpose: the
     * first version used the form feed, which `trim()` counts as whitespace and silently removed - found by tools/verify/docx_check.py.
     */
    const val PAGE_BREAK = "\uE000"

    private const val NS_W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    private const val NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"

    /**
     * Paragraphs from text whose lines are visual lines (OCR output): a blank line always starts a new paragraph; inside a block
     * a line break is kept as a paragraph break when the line ends a sentence (`. ! ? : ; …`), is the last line, or is clearly shorter than the
     * longest line of the block (under 70% - a title, a list item, the last line of a paragraph); otherwise the next line is joined
     * with a space so a wrapped sentence flows again. A line holding only [PAGE_BREAK] is a page break. Pure - mirrored in
     * tools/verify/docx_check.py.
     */
    fun paragraphsFromText(text: String): List<String> {
        val out = ArrayList<String>()
        for (block in text.split(Regex("\\n\\s*\\n"))) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.isEmpty()) continue
            val longest = lines.maxOf { it.length }
            val current = StringBuilder()
            for ((i, line) in lines.withIndex()) {
                if (line == PAGE_BREAK) {
                    if (current.isNotEmpty()) { out.add(current.toString()); current.setLength(0) }
                    out.add(PAGE_BREAK)
                    continue
                }
                if (current.isNotEmpty()) current.append(' ')
                current.append(line)
                val endsSentence = line.last() in ".!?:;…"
                val short = line.length < 0.7 * longest
                if (endsSentence || short || i == lines.lastIndex) { out.add(current.toString()); current.setLength(0) }
            }
            if (current.isNotEmpty()) out.add(current.toString())
        }
        return out
    }

    /** Text safe inside an XML element: `& < >` escaped, characters XML 1.0 forbids (most control characters) removed. */
    fun escape(text: String): String {
        val sb = StringBuilder(text.length + 16)
        var i = 0
        while (i < text.length) {
            val cp = text.codePointAt(i)
            i += Character.charCount(cp)
            val legal = cp == 0x9 || cp == 0xA || cp == 0xD || (cp in 0x20..0xD7FF) || (cp in 0xE000..0xFFFD) || (cp in 0x10000..0x10FFFF)
            if (!legal) continue
            when (cp) {
                '&'.code -> sb.append("&amp;")
                '<'.code -> sb.append("&lt;")
                '>'.code -> sb.append("&gt;")
                else -> sb.appendCodePoint(cp)
            }
        }
        return sb.toString()
    }

    fun documentXml(paragraphs: List<String>): String {
        val body = StringBuilder()
        for (p in paragraphs) {
            if (p == PAGE_BREAK) {
                body.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>")
            } else {
                body.append("<w:p><w:r><w:t xml:space=\"preserve\">").append(escape(p)).append("</w:t></w:r></w:p>")
            }
        }
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document xmlns:w=\"$NS_W\" xmlns:r=\"$NS_R\"><w:body>" + body +
            "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>" +
            "<w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1701\" w:header=\"709\" w:footer=\"709\" w:gutter=\"0\"/>" +
            "</w:sectPr></w:body></w:document>"
    }

    private const val CONTENT_TYPES = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
        "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
        "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
        "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>" +
        "<Override PartName=\"/word/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml\"/>" +
        "</Types>"

    private const val PACKAGE_RELS = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>" +
        "</Relationships>"

    private const val DOCUMENT_RELS = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
        "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
        "</Relationships>"

    private const val STYLES = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
        "<w:styles xmlns:w=\"$NS_W\"><w:docDefaults><w:rPrDefault><w:rPr>" +
        "<w:rFonts w:ascii=\"Times New Roman\" w:hAnsi=\"Times New Roman\" w:cs=\"Times New Roman\" w:eastAsia=\"Times New Roman\"/>" +
        "<w:sz w:val=\"26\"/><w:szCs w:val=\"26\"/><w:lang w:val=\"vi-VN\"/></w:rPr></w:rPrDefault>" +
        "<w:pPrDefault><w:pPr><w:spacing w:after=\"120\" w:line=\"300\" w:lineRule=\"auto\"/></w:pPr></w:pPrDefault></w:docDefaults>" +
        "<w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\"><w:name w:val=\"Normal\"/></w:style></w:styles>"

    /** Writes the NEW file [out] holding [paragraphs] (one Word paragraph each; [PAGE_BREAK] = page break). */
    fun write(paragraphs: List<String>, out: File) {
        ZipOutputStream(FileOutputStream(out)).use { zip ->
            fun part(name: String, content: String) {
                zip.putNextEntry(ZipEntry(name))
                zip.write(content.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
            part("[Content_Types].xml", CONTENT_TYPES)
            part("_rels/.rels", PACKAGE_RELS)
            part("word/document.xml", documentXml(if (paragraphs.isEmpty()) listOf("") else paragraphs))
            part("word/_rels/document.xml.rels", DOCUMENT_RELS)
            part("word/styles.xml", STYLES)
        }
    }
}
