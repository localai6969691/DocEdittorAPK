package com.example.docscanner.util

import com.example.docscanner.util.DocumentImport.Block
import java.nio.charset.Charset

/**
 * Reads Rich Text Format (.rtf) into the same plain BLOCKS as [DocumentImport] (phiên 20, mục 4.48.2). PURE and mirrored in tools/verify/OfficeImportCheck.java;
 * tools/verify/office_import_check.py compares the mirror with `pandoc -f rtf`, with LibreOffice's own text export, and with the ground truth of the .docx the RTF was made from.
 *
 * The input is the file's BYTES read as ISO-8859-1 (RTF is 7-bit; non-ASCII travels as `\uN` or `\'hh`), see [decode].
 *
 * What it understands: groups and `\*` ignorable destinations; `\uN` with the `\ucN` fallback count; `\'hh` through the code page of the CURRENT FONT (font table `\fcharsetN` / `\cpgN`,
 * else `\ansicpgN`), so two escapes in a row form one Shift-JIS / GBK / Big5 / Korean character; `\par`, `\line`, `\tab` and the usual symbol words; paragraph styles from the
 * stylesheet (`Heading 1..9` and `Title` become headings; `\outlinelevelN` also does); list items from the `{\listtext ...}` / `{\pntext ...}` text a writer puts in front of the item
 * (numbered when it looks like `1.` / `a)` / `(i)`, depth from `\ilvlN`); tables (`\trowd` ... `\cell` ... `\row`) as rows.
 * NOT imported: pictures and embedded objects (their data is skipped, `\binN` included), headers, footers, footnotes, text boxes (`\shptxt`), field codes (the field RESULT is kept).
 */
object RtfImport {

    /** RTF bytes as the text the parser reads. */
    fun decode(bytes: ByteArray): String = String(bytes, Charsets.ISO_8859_1)

    private val SKIP_DEST = setOf(
        "colortbl", "info", "header", "headerl", "headerr", "headerf", "footer", "footerl", "footerr", "footerf", "pict", "object", "fldinst", "listtable",
        "listoverridetable", "rsidtbl", "generator", "revtbl", "footnote", "bkmkstart", "bkmkend", "datafield", "themedata", "colorschememapping", "latentstyles",
        "xmlnstbl", "mmathPr", "pgptbl", "protusertbl", "template", "ftnsep", "ftnsepc", "aftnsep", "aftnsepc", "private", "filetbl", "pn", "pnseclvl", "falt",
        "shpinst", "userprops", "nonshppict", "author", "operator", "factoidname", "docvar", "listname", "upr", "ud", "fchars", "lchars", "xe", "tc", "txe", "rxe"
    )

    private val HEADING = Regex("(?i)^heading\\s*([1-9])$")
    private val NUMBERED = Regex("^\\(?([0-9]+|[A-Za-z]|[ivxlcdmIVXLCDM]+)[.)]")

    private fun isAlpha(ch: Char): Boolean = ch in 'a'..'z' || ch in 'A'..'Z'
    private fun isDigit(ch: Char): Boolean = ch in '0'..'9'

    private fun charsetForCodePage(cp: Int): Charset {
        val names = when (cp) {
            932 -> listOf("windows-31j", "Shift_JIS")
            936 -> listOf("GBK", "x-mswin-936")
            949 -> listOf("x-windows-949", "windows-949", "EUC-KR")
            950 -> listOf("x-windows-950", "Big5")
            1361 -> listOf("x-Johab")
            874 -> listOf("x-windows-874", "windows-874")
            10000 -> listOf("x-MacRoman", "MacRoman")
            else -> listOf("windows-$cp")
        }
        for (n in names) try { return Charset.forName(n) } catch (e: Exception) { /* next name */ }
        return Charset.forName("windows-1252")
    }

    private class Group(var skip: Boolean, var uc: Int, var font: Int, var dest: String?, var capture: StringBuilder?) {
        fun copy() = Group(skip, uc, font, dest, capture)
    }

    private class Parser(val rtf: String) {
        val out = ArrayList<Block>()
        val stack = ArrayList<Group>()
        var cur = Group(false, 1, -1, null, null)
        val fontCharset = HashMap<Int, Int>()
        val fontCp = HashMap<Int, Int>()
        val styleNames = HashMap<Int, String>()
        var docCp = 1252
        var fontDef = -1
        var styleNum = -1
        val styleBuf = StringBuilder()

        val para = StringBuilder()
        var paraStyle = -1
        var outline = 0
        var ilvl = 0
        var marker: String? = null
        var inRow = false
        var cells = ArrayList<String>()
        val cell = StringBuilder()
        var pendingSkip = 0
        val bytes = java.io.ByteArrayOutputStream()
        var bytesFont = -1

        fun charsetOf(font: Int): Charset {
            val cp = fontCp[font] ?: when (fontCharset[font]) {
                77 -> 10000
                128 -> 932
                129 -> 949
                130 -> 1361
                134 -> 936
                136 -> 950
                161 -> 1253
                162 -> 1254
                163 -> 1258
                177 -> 1255
                178 -> 1256
                186 -> 1257
                204 -> 1251
                222 -> 874
                238 -> 1250
                else -> docCp
            }
            return charsetForCodePage(cp)
        }

        fun emit(s: String) {
            val g = cur
            if (g.dest == "stylesheet") { styleBuf.append(s); return }
            if (g.skip || g.dest == "fonttbl") return
            (g.capture ?: para).append(s)
        }

        fun flushBytes() {
            if (bytes.size() == 0) return
            val s = String(bytes.toByteArray(), charsetOf(bytesFont))
            bytes.reset()
            emit(s)
        }

        fun lineText(s: String): String = s.lines().joinToString("\n") { OfficeImport.collapse(it) }.trim()

        fun endPara() {
            flushBytes()
            val text = lineText(para.toString())
            para.setLength(0)
            val st = paraStyle
            val ol = outline
            val mk = marker
            val lv = ilvl
            paraStyle = -1; outline = 0; marker = null; ilvl = 0
            if (text.isEmpty()) return
            if (inRow) {
                if (cell.isNotEmpty()) cell.append(' ')
                cell.append(text.replace('\n', ' '))
                return
            }
            val styleName = styleNames[st] ?: ""
            val heading = HEADING.find(styleName)?.groupValues?.get(1)?.toInt()
            val level = when {
                ol in 1..9 -> minOf(ol, 6)
                heading != null -> minOf(heading, 6)
                styleName.equals("Title", ignoreCase = true) -> 1
                else -> 0
            }
            when {
                level > 0 -> out.add(Block("H", level, OfficeImport.collapse(text)))
                mk != null -> out.add(Block("LI", lv + 1, text, if (NUMBERED.containsMatchIn(mk.trim())) "#" else "\u2022"))
                else -> out.add(Block("P", 0, text))
            }
        }

        fun startRow() {
            endPara()
            inRow = true
            cells = ArrayList()
            cell.setLength(0)
        }

        fun endCell() {
            if (!inRow) { endPara(); return }
            flushBytes()
            val text = lineText(para.toString())
            para.setLength(0)
            if (text.isNotEmpty()) {
                if (cell.isNotEmpty()) cell.append(' ')
                cell.append(text.replace('\n', ' '))
            }
            cells.add(OfficeImport.collapse(cell.toString()))
            cell.setLength(0)
            paraStyle = -1; outline = 0; marker = null; ilvl = 0
        }

        fun endRow() {
            if (!inRow) return
            if (para.isNotEmpty()) endCell()
            if (cells.any { it.isNotEmpty() }) out.add(Block("ROW", 0, cells.joinToString(" | ")))
            inRow = false
            cells = ArrayList()
        }

        fun literal(ch: Char) {
            if (cur.dest == "stylesheet") {
                if (cur.skip) return
                if (ch == ';') {
                    if (styleNum >= 0) styleNames[styleNum] = styleBuf.toString().trim()
                    styleBuf.setLength(0)
                } else styleBuf.append(ch)
                return
            }
            if (cur.skip || cur.dest == "fonttbl") return
            flushBytes()
            (cur.capture ?: para).append(ch)
        }

        fun endGroup() {
            flushBytes()
            val g = cur
            val cap = g.capture
            if (cap != null && stack.lastOrNull()?.capture !== cap) marker = cap.toString()
            if (stack.isNotEmpty()) cur = stack.removeAt(stack.size - 1)
        }

        /** Handles one control word; returns the index after it (a `\binN` jumps over its data). */
        fun word(name: String, param: Int?, after: Int): Int {
            var next = after
            if (name != "u") pendingSkip = 0
            if (cur.dest == "fonttbl") {
                when (name) {
                    "f" -> fontDef = param ?: -1
                    "fcharset" -> if (param != null) fontCharset[fontDef] = param
                    "cpg" -> if (param != null) fontCp[fontDef] = param
                }
                if (name != "falt" && name !in SKIP_DEST) return next
            }
            if (cur.dest == "stylesheet") {
                when (name) {
                    "s" -> { styleNum = param ?: -1; styleBuf.setLength(0) }
                    "cs", "ds", "ts" -> styleNum = -1
                }
                if (name !in SKIP_DEST) return next
            }
            when (name) {
                "fonttbl" -> { cur.dest = "fonttbl"; return next }
                "stylesheet" -> { cur.dest = "stylesheet"; styleNum = -1; styleBuf.setLength(0); return next }
                "listtext", "pntext" -> { cur.capture = StringBuilder(); return next }
            }
            if (name in SKIP_DEST) { cur.skip = true; return next }
            if (name == "bin" && param != null && param > 0) next = minOf(rtf.length, after + param)
            if (cur.skip) return next
            when (name) {
                "par" -> endPara()
                "line" -> emit("\n")
                "tab" -> emit(" ")
                "cell" -> endCell()
                "row" -> endRow()
                "trowd" -> startRow()
                "pard" -> if (cur.capture == null) { paraStyle = -1; outline = 0; ilvl = 0 }
                "s" -> paraStyle = param ?: -1
                "outlinelevel" -> outline = if (param != null && param in 0..8) param + 1 else 0
                "ilvl" -> ilvl = param ?: 0
                "f" -> { flushBytes(); cur.font = param ?: -1 }
                "ansicpg" -> docCp = param ?: 1252
                "uc" -> cur.uc = param ?: 1
                "u" -> {
                    flushBytes()
                    if (param != null) emit((if (param < 0) param + 65536 else param).toChar().toString())
                    pendingSkip = cur.uc
                }
                "emdash" -> emit("\u2014")
                "endash" -> emit("\u2013")
                "emspace", "enspace", "qmspace" -> emit(" ")
                "bullet" -> emit("\u2022")
                "lquote" -> emit("\u2018")
                "rquote" -> emit("\u2019")
                "ldblquote" -> emit("\u201C")
                "rdblquote" -> emit("\u201D")
            }
            return next
        }

        fun run(): List<Block> {
            val n = rtf.length
            var i = 0
            while (i < n) {
                val c = rtf[i]
                when {
                    c == '{' -> { flushBytes(); stack.add(cur.copy()); i++ }
                    c == '}' -> { endGroup(); i++ }
                    c == '\r' || c == '\n' -> i++
                    c == '\\' -> {
                        if (i + 1 >= n) { i++; continue }
                        val nx = rtf[i + 1]
                        when {
                            nx == '\\' || nx == '{' || nx == '}' -> {
                                if (pendingSkip > 0) pendingSkip-- else literal(nx)
                                i += 2
                            }
                            nx == '\'' -> {
                                val hex = if (i + 4 <= n) rtf.substring(i + 2, i + 4).toIntOrNull(16) else null
                                if (pendingSkip > 0) pendingSkip--
                                else if (hex != null && !cur.skip && cur.dest != "fonttbl" && cur.dest != "stylesheet") {
                                    if (bytes.size() == 0) bytesFont = cur.font
                                    bytes.write(hex)
                                }
                                i += 4
                            }
                            nx == '*' -> {
                                val j = i + 2
                                if (j + 1 < n && rtf[j] == '\\') {
                                    var k = j + 1
                                    while (k < n && isAlpha(rtf[k])) k++
                                    val name = rtf.substring(j + 1, k)
                                    if (name != "listtext" && name != "pntext") cur.skip = true
                                } else cur.skip = true
                                i = j
                            }
                            nx == '~' -> { flushBytes(); if (!cur.skip) literal('\u00A0'); i += 2 }
                            nx == '_' -> { flushBytes(); if (!cur.skip) literal('-'); i += 2 }
                            nx == '-' || nx == '|' || nx == ':' -> i += 2
                            nx == '\r' || nx == '\n' -> { if (!cur.skip) endPara(); i += 2 }
                            isAlpha(nx) -> {
                                var k = i + 1
                                while (k < n && isAlpha(rtf[k])) k++
                                val name = rtf.substring(i + 1, k)
                                var param: Int? = null
                                var p = k
                                if (p < n && (rtf[p] == '-' || isDigit(rtf[p]))) {
                                    p++
                                    while (p < n && isDigit(rtf[p])) p++
                                    param = rtf.substring(k, p).toIntOrNull()
                                }
                                if (p < n && rtf[p] == ' ') p++
                                flushBytes()
                                i = word(name, param, p)
                            }
                            else -> i += 2
                        }
                    }
                    else -> {
                        if (pendingSkip > 0) { pendingSkip--; i++; continue }
                        if (c.code >= 0x80) {
                            if (!cur.skip && cur.dest != "fonttbl" && cur.dest != "stylesheet") { if (bytes.size() == 0) bytesFont = cur.font; bytes.write(c.code and 0xFF) }
                        } else literal(c)
                        i++
                    }
                }
            }
            flushBytes()
            endRow()
            endPara()
            return out
        }
    }

    /** Blocks of an RTF document ([rtf] = [decode] of the file's bytes). */
    fun blocksFromRtf(rtf: String): List<Block> = Parser(rtf).run()
}
