package com.example.docscanner.util

import com.example.docscanner.R
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Lets the search box of "Tài liệu đã xuất" find a document by WHAT IT SAYS, not only by its name and tags. The words come from the
 * plain-text transcript that the OCR options write next to the document: `<name>.txt` beside `<name>.pdf` (a standalone `.txt` is its
 * own content). A PDF that was never OCR'd has no transcript and is found by name and tags as before.
 *
 * The text is kept NORMALIZED (lower case, no accents - [HistoryFilter.normalize]) and cut to [MAX_CHARS], so a search is a plain
 * `contains` over strings that are already prepared. Reading is the slow part, so [warm] is meant for a background thread, and [cached]
 * never touches the disk: the list shows name/tag matches at once and content matches as soon as the index is ready.
 */
object ContentIndex {
    /** Per-document cap: a long book's first ~60 000 characters decide most searches and keep memory small (200 documents ~ 12 MB). */
    const val MAX_CHARS = 60_000

    private class Entry(val modified: Long, val length: Long, val text: String)

    private val cache = ConcurrentHashMap<String, Entry>()

    /** The transcript file that belongs to [file], or null. */
    fun transcriptOf(file: File): File? {
        val ext = file.extension.lowercase()
        if (ext == "txt") return file
        if (ext != "pdf" && ext != "epub" && ext != "docx") return null
        return File(file.parentFile, file.nameWithoutExtension + ".txt").takeIf { it.isFile }
    }

    /** Normalized text of [file] if it has been indexed; null when there is none or it has not been read yet. Never reads the disk. */
    fun cached(file: File): String? = cache[file.absolutePath]?.text?.takeIf { it.isNotEmpty() }

    /**
     * Reads (or re-reads, when the transcript changed) the transcript of every file in [files] and forgets the files that are gone.
     * Returns true when anything was added or changed, so the caller knows to search again. Blocking - call it off the main thread.
     */
    fun warm(files: List<File>): Boolean {
        var changed = false
        val live = HashSet<String>()
        for (file in files) {
            val source = transcriptOf(file) ?: continue
            val key = file.absolutePath
            live.add(key)
            val modified = source.lastModified()
            val length = source.length()
            val known = cache[key]
            if (known != null && known.modified == modified && known.length == length) continue
            val text = try {
                HistoryFilter.normalize(plainText(source))
            } catch (e: Exception) {
                ""
            }
            cache[key] = Entry(modified, length, text)
            changed = true
        }
        cache.keys.retainAll(live)
        return changed
    }

    /** The words of a transcript, without the page markers (`--- Trang N ---`) and the "nothing recognised" placeholder lines, which every document has and no one searches for. */
    fun plainText(source: File): String {
        val sb = StringBuilder()
        source.bufferedReader(Charsets.UTF_8).useLines { lines ->
            for (line in lines) {
                if (sb.length >= MAX_CHARS) break
                if (line.startsWith("--- Trang ") || AppText.isOcrPlaceholder(line)) continue
                sb.append(line).append('\n')
            }
        }
        return if (sb.length > MAX_CHARS) sb.substring(0, MAX_CHARS) else sb.toString()
    }
}
