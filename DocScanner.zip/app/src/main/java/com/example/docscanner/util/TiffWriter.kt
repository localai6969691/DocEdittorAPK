package com.example.docscanner.util

import java.io.File
import java.io.RandomAccessFile
import java.util.zip.Deflater

/**
 * Writes a multi-page TIFF (phiên 19, mục 4.47.4; item 10.10 of the PDF "Thiếu gì để bán app": TIFF is what archives, fax servers and many OCR / legal pipelines expect).
 * Little-endian ("II"), one strip per page, pages written ONE AT A TIME to disk ([RandomAccessFile]) so that a 100-page colour scan never sits in memory at once: after the
 * header, each page appends its strip data and its IFD, and the previous IFD's "next" pointer (or the header's first-IFD pointer) is patched to point at it.
 *
 * Three kinds of page, all chosen for being read by every TIFF reader (libtiff, Windows Photos, Preview, GIMP, ImageMagick):
 *  - [Kind.BILEVEL_G4]: the CCITT Group 4 bytes of [Ccitt4Encoder] as they are (compression 4, PhotometricInterpretation 1 = BlackIsZero, i.e. 0 bits are black and 1 bits
 *    white - the same convention as the PDF path's `/BlackIs1 false`. Found by experiment, not assumed: the encoder's streams were checked byte for byte against libtiff's own
 *    (Pillow `group4`, mode "1") in session 6-7, and libtiff writes those with tag 1; the same bytes read back inverted under tag 0, see tiff_check.py);
 *  - [Kind.GRAY_DEFLATE] / [Kind.RGB_DEFLATE]: RAW 8-bit samples (rows top to bottom; RGB interleaved) that this class compresses with Adobe Deflate (compression 8) after
 *    the horizontal-differencing predictor (tag 317 = 2), which is what makes Deflate worthwhile for photographs.
 * The page's resolution is written as [Page.dpi] in both directions (unit: inch). [dpiFor] turns "width in pixels / width of the page in points" into that number.
 *
 * Mirrored line by line in tools/verify/TiffCheck.java; tools/verify/tiff_check.py reads the files with libtiff (through Pillow and OpenCV) and compares every pixel.
 */
object TiffWriter {

    enum class Kind { BILEVEL_G4, GRAY_DEFLATE, RGB_DEFLATE }

    /** [data]: for BILEVEL_G4 the encoded Group 4 stream; otherwise the raw samples, `width * height` (gray) or `width * height * 3` (RGB) bytes. */
    class Page(val width: Int, val height: Int, val kind: Kind, val data: ByteArray, val dpi: Int)

    /** Pixels per inch of an image [widthPx] wide that shows a page [widthPoints] points (1/72 inch) wide, at least 1. */
    fun dpiFor(widthPx: Int, widthPoints: Float): Int = if (widthPoints <= 0f) 200 else Math.round(widthPx * 72f / widthPoints).coerceAtLeast(1)

    /** Appends pages to a new TIFF file; call [add] once per page, then [close] (which is also what makes the first-IFD pointer valid). */
    class Writer(file: File) : AutoCloseable {
        private val raf = RandomAccessFile(file, "rw")
        private var lastNextPointerAt = 4L      // where the offset of the next IFD goes: first the header's, then each page's
        var pageCount = 0
            private set

        init {
            raf.setLength(0)
            raf.write(byteArrayOf('I'.code.toByte(), 'I'.code.toByte(), 42, 0, 0, 0, 0, 0))   // header: byte order, magic 42, first IFD offset (patched by the first page)
        }

        fun add(page: Page) {
            require(page.width > 0 && page.height > 0) { "empty page" }
            val strip: ByteArray = when (page.kind) {
                Kind.BILEVEL_G4 -> page.data
                Kind.GRAY_DEFLATE -> deflate(predictor(page.data, page.width, page.height, 1))
                Kind.RGB_DEFLATE -> deflate(predictor(page.data, page.width, page.height, 3))
            }
            val samples = if (page.kind == Kind.RGB_DEFLATE) 3 else 1
            if (page.kind != Kind.BILEVEL_G4) require(page.data.size == page.width * page.height * samples) { "raw size does not match the page size" }

            val stripAt = alignedEnd()
            raf.seek(stripAt)
            raf.write(strip)

            // tag, type (3 SHORT, 4 LONG, 5 RATIONAL), count, value (or offset of the value when it does not fit in 4 bytes) - sorted by tag as the specification requires
            val extraBase = alignedEnd()
            val entries = ArrayList<LongArray>()
            fun put(tag: Int, type: Int, count: Int, value: Long) { entries.add(longArrayOf(tag.toLong(), type.toLong(), count.toLong(), value)) }
            val entryCount = if (page.kind == Kind.BILEVEL_G4) 13 else 14   // the predictor tag is only written for the Deflate kinds (libtiff warns about it on a CCITT strip)
            val ifdSize = 2L + entryCount * 12 + 4
            val extraStart = extraBase + ifdSize

            // the values that need more than 4 bytes go after the IFD: BitsPerSample for RGB (3 SHORTs), the two RATIONAL resolutions
            val bits: Int = if (page.kind == Kind.BILEVEL_G4) 1 else 8
            val photometric = when (page.kind) { Kind.BILEVEL_G4 -> 1; Kind.GRAY_DEFLATE -> 1; Kind.RGB_DEFLATE -> 2 }
            val compression = if (page.kind == Kind.BILEVEL_G4) 4 else 8
            val extraBytes = java.io.ByteArrayOutputStream()
            var bitsValue = bits.toLong()
            var bitsCount = 1
            if (samples == 3) {
                bitsCount = 3
                bitsValue = extraStart + extraBytes.size()
                for (i in 0 until 3) { extraBytes.write(bits and 0xFF); extraBytes.write(0) }
            }
            val xResAt = extraStart + extraBytes.size()
            for (i in 0 until 2) {                       // XResolution then YResolution: RATIONAL dpi / 1
                writeLe(extraBytes, page.dpi.toLong(), 4); writeLe(extraBytes, 1, 4)
            }
            val yResAt = xResAt + 8

            put(256, 4, 1, page.width.toLong())
            put(257, 4, 1, page.height.toLong())
            put(258, 3, bitsCount, bitsValue)
            put(259, 3, 1, compression.toLong())
            put(262, 3, 1, photometric.toLong())
            put(273, 4, 1, stripAt)
            put(277, 3, 1, samples.toLong())
            put(278, 4, 1, page.height.toLong())
            put(279, 4, 1, strip.size.toLong())
            put(282, 5, 1, xResAt)
            put(283, 5, 1, yResAt)
            put(284, 3, 1, 1)
            put(296, 3, 1, 2)
            if (page.kind != Kind.BILEVEL_G4) put(317, 3, 1, 2)   // predictor 2 = horizontal differencing

            val ifd = java.io.ByteArrayOutputStream()
            writeLe(ifd, entries.size.toLong(), 2)
            for (e in entries) {
                writeLe(ifd, e[0], 2); writeLe(ifd, e[1], 2); writeLe(ifd, e[2], 4)
                if (e[1] == 3L && e[2] == 1L) { writeLe(ifd, e[3], 2); writeLe(ifd, 0, 2) } else writeLe(ifd, e[3], 4)   // a single SHORT sits in the first two bytes of the value field
            }
            writeLe(ifd, 0, 4)                            // next IFD: none yet
            check(entries.size == entryCount && ifd.size().toLong() == ifdSize) { "IFD size" }

            raf.seek(extraBase)
            raf.write(ifd.toByteArray())
            raf.write(extraBytes.toByteArray())
            // chain: the previous page's "next" pointer (or the header's) now points here
            raf.seek(lastNextPointerAt)
            raf.write(le(extraBase, 4))
            lastNextPointerAt = extraBase + 2 + entries.size * 12L
            pageCount++
        }

        /** The end of the file rounded up to an even offset (TIFF requires IFDs and their values on word boundaries). */
        private fun alignedEnd(): Long {
            var end = raf.length()
            if (end % 2L == 1L) { raf.seek(end); raf.write(0); end++ }
            return end
        }

        override fun close() { runCatching { raf.close() } }
    }

    // ------------------------------------------------------------------ helpers (pure)

    private fun le(v: Long, n: Int): ByteArray = ByteArray(n) { ((v shr (8 * it)) and 0xFF).toByte() }
    private fun writeLe(out: java.io.ByteArrayOutputStream, v: Long, n: Int) { out.write(le(v, n)) }

    /** TIFF predictor 2: every sample minus the sample [samples] bytes to its left in the same row (the first pixel of a row is stored as it is), modulo 256. */
    fun predictor(raw: ByteArray, width: Int, height: Int, samples: Int): ByteArray {
        val out = raw.copyOf()
        val rowBytes = width * samples
        for (y in 0 until height) {
            val base = y * rowBytes
            for (i in rowBytes - 1 downTo samples) out[base + i] = (raw[base + i] - raw[base + i - samples]).toByte()
        }
        return out
    }

    /** zlib stream (RFC 1950) as Adobe Deflate (compression 8) wants it. */
    fun deflate(data: ByteArray): ByteArray {
        val d = Deflater(6)
        d.setInput(data)
        d.finish()
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(64 * 1024)
        while (!d.finished()) out.write(buf, 0, d.deflate(buf))
        d.end()
        return out.toByteArray()
    }
}
