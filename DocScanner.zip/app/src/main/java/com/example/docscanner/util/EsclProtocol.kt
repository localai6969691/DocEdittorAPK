package com.example.docscanner.util

import java.io.ByteArrayInputStream
import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress
import java.net.URI
import javax.xml.parsers.DocumentBuilderFactory

/**
 * eSCL ("AirScan") - the driverless network-scanner protocol almost every scanner / MFP made since ~2013 speaks over Wi-Fi (phiên 17, mục 4.31; item A6 of the
 * PDF "Thiếu gì để bán app"). Pure code, no Android: the XML is read with the JDK's DOM parser, which Android also has, so the same logic runs in
 * tools/verify/EsclCheck.java against a mock scanner (tools/verify/escl_check.py).
 *
 * Protocol (researched; see TECHNICAL_DOCS.md 4.31 I):
 *  - `GET  <base>/ScannerCapabilities` -> XML describing sources (Platen = glass, Adf = feeder), resolutions, formats, maximum scan area;
 *  - `POST <base>/ScanJobs` with a `scan:ScanSettings` document -> `201 Created` + a `Location` header naming the job;
 *  - `GET  <Location>/NextDocument` -> `200` with one page (image or PDF), repeated until `404` (no more pages); `503` = scanner busy or warming up, ask again;
 *  - `DELETE <Location>` ends the job.
 *  The job URL is taken from `Location` AS GIVEN (absolute or relative, resolved against the POST address by [resolveLocation]) and never rebuilt: some devices
 *  return a different path from the textbook one (SANE backends issues #424 / #479).
 * Privacy: the app otherwise never touches the network, so [isPrivateAddress] restricts every connection to the local network (RFC 1918, link-local, loopback,
 * IPv6 unique-local / link-local); a hostname must resolve ONLY to such addresses (checked by the client).
 */
object EsclProtocol {

    const val NS_SCAN = "http://schemas.hp.com/imaging/escl/2011/05/03"
    const val NS_PWG = "http://www.pwg.org/schemas/2010/12/sm"

    enum class Source(val xml: String) { PLATEN("Platen"), FEEDER("Feeder") }
    enum class Color(val xml: String) { RGB("RGB24"), GRAY("Grayscale8"), BW("BlackAndWhite1") }

    /** Scan area in 1/300 inch (the unit eSCL scanners all accept). A4 at 300 dpi = 2480 x 3508. */
    class Settings(val source: Source, val color: Color, val dpi: Int, val format: String, val widthThirds: Int, val heightThirds: Int, val duplex: Boolean = false)

    class Capabilities(
        val make: String,
        val resolutions: List<Int>,
        val platen: Boolean,
        val feeder: Boolean,
        val formats: List<String>,
        val platenWidth: Int,
        val platenHeight: Int,
        val feederWidth: Int,
        val feederHeight: Int,
        /** The feeder scans both sides of a sheet: the device lists an `AdfDuplexInputCaps` block (phiên 20, 4.48.4). */
        val duplex: Boolean = false,
        /** Maximum area of a DUPLEX job: it can be SMALLER than the simplex one (a real Epson: 4200 simplex, 3510 duplex), and a bigger request is refused with 409. */
        val feederDuplexWidth: Int = feederWidth,
        val feederDuplexHeight: Int = feederHeight
    )

    const val A4_WIDTH_THIRDS = 2480
    const val A4_HEIGHT_THIRDS = 3508

    /** The `scan:ScanSettings` document, elements in the order real clients (SANE airscan, Apple, Windows) send them. */
    fun scanSettingsXml(s: Settings): String =
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<scan:ScanSettings xmlns:pwg=\"$NS_PWG\" xmlns:scan=\"$NS_SCAN\">\n" +
            "  <pwg:Version>2.0</pwg:Version>\n" +
            "  <pwg:ScanRegions>\n    <pwg:ScanRegion>\n" +
            "      <pwg:ContentRegionUnits>escl:ThreeHundredthsOfInches</pwg:ContentRegionUnits>\n" +
            "      <pwg:XOffset>0</pwg:XOffset>\n      <pwg:YOffset>0</pwg:YOffset>\n" +
            "      <pwg:Width>${s.widthThirds}</pwg:Width>\n      <pwg:Height>${s.heightThirds}</pwg:Height>\n" +
            "    </pwg:ScanRegion>\n  </pwg:ScanRegions>\n" +
            "  <pwg:InputSource>${s.source.xml}</pwg:InputSource>\n" +
            "  <scan:ColorMode>${s.color.xml}</scan:ColorMode>\n" +
            "  <scan:XResolution>${s.dpi}</scan:XResolution>\n  <scan:YResolution>${s.dpi}</scan:YResolution>\n" +
            (if (s.duplex) "  <scan:Duplex>true</scan:Duplex>\n" else "") +
            "  <pwg:DocumentFormat>${s.format}</pwg:DocumentFormat>\n" +
            "</scan:ScanSettings>\n"

    private fun texts(doc: org.w3c.dom.Document, local: String): List<String> {
        val nodes = doc.getElementsByTagNameNS("*", local)
        return (0 until nodes.length).map { nodes.item(it).textContent.trim() }
    }

    /** Reads `ScannerCapabilities` whatever namespace prefixes the device uses (matching on local names only). Throws if it is not XML. */
    fun parseCapabilities(xml: String): Capabilities {
        val f = DocumentBuilderFactory.newInstance()
        f.isNamespaceAware = true
        val doc = f.newDocumentBuilder().parse(ByteArrayInputStream(xml.toByteArray(Charsets.UTF_8)))
        val make = texts(doc, "MakeAndModel").firstOrNull() ?: texts(doc, "Make").firstOrNull().orEmpty()
        val res = (texts(doc, "XResolution") + texts(doc, "Resolution")).mapNotNull { it.toIntOrNull() }.filter { it in 50..2400 }.distinct().sorted()
        val formats = texts(doc, "DocumentFormat").filter { it.contains('/') }.distinct()
        fun hasChild(parentLocal: String): Boolean = doc.getElementsByTagNameNS("*", parentLocal).length > 0
        // the maximum scan area is read INSIDE the element of each source: a feeder can be longer than the glass, and a device without glass must not borrow its numbers
        fun area(container: String, local: String, fallback: Int): Int {
            val c = doc.getElementsByTagNameNS("*", container)
            if (c.length == 0) return fallback
            val n = (c.item(0) as org.w3c.dom.Element).getElementsByTagNameNS("*", local)
            return if (n.length == 0) fallback else n.item(0).textContent.trim().toIntOrNull() ?: fallback
        }
        // the feeder's simplex limits come from `AdfSimplexInputCaps` (not from "the first MaxWidth inside Adf", which would be the duplex block on a device that lists it first)
        val simplex = if (hasChild("AdfSimplexInputCaps")) "AdfSimplexInputCaps" else "Adf"
        val feederW = area(simplex, "MaxWidth", A4_WIDTH_THIRDS)
        val feederH = area(simplex, "MaxHeight", A4_HEIGHT_THIRDS)
        return Capabilities(
            make, res, hasChild("Platen"), hasChild("Adf"), formats,
            area("Platen", "MaxWidth", A4_WIDTH_THIRDS), area("Platen", "MaxHeight", A4_HEIGHT_THIRDS),
            feederW, feederH,
            hasChild("AdfDuplexInputCaps"), area("AdfDuplexInputCaps", "MaxWidth", feederW), area("AdfDuplexInputCaps", "MaxHeight", feederH)
        )
    }

    /** Settings the device really supports: the supported resolution closest to [dpi], a source it has, a format it lists (JPEG preferred), the area clamped to the maximum OF THAT SOURCE. */
    fun fit(caps: Capabilities, source: Source, color: Color, dpi: Int, duplex: Boolean = false): Settings {
        val src = when {
            source == Source.FEEDER && caps.feeder -> Source.FEEDER
            source == Source.PLATEN && caps.platen -> Source.PLATEN
            caps.platen -> Source.PLATEN
            else -> Source.FEEDER
        }
        val res = if (caps.resolutions.isEmpty()) dpi else caps.resolutions.minByOrNull { Math.abs(it - dpi) }!!
        val fmt = when {
            caps.formats.isEmpty() || caps.formats.contains("image/jpeg") -> "image/jpeg"
            else -> caps.formats.first()
        }
        // two sides only from the feeder, and only if the device says it can; the area then follows the DUPLEX limits
        val dup = duplex && src == Source.FEEDER && caps.duplex
        val maxW = if (src == Source.FEEDER) (if (dup) caps.feederDuplexWidth else caps.feederWidth) else caps.platenWidth
        val maxH = if (src == Source.FEEDER) (if (dup) caps.feederDuplexHeight else caps.feederHeight) else caps.platenHeight
        return Settings(src, color, res, fmt, minOf(A4_WIDTH_THIRDS, maxW), minOf(A4_HEIGHT_THIRDS, maxH), dup)
    }

    /** The job URL from the POST response: `Location` absolute or relative, resolved against the POST address. Null if there is no usable one. */
    fun resolveLocation(postUrl: String, location: String?): String? {
        if (location.isNullOrBlank()) return null
        return try {
            val u = URI(postUrl).resolve(location.trim())
            if (u.scheme == null || u.host == null) null else u.toString().trimEnd('/')
        } catch (e: Exception) { null }
    }

    /** `host`, `host:port` or a pasted `http://host:port/eSCL` -> `http://host:port/<rs>`; null when it is not a plausible host. Default port 80, default root `eSCL`. */
    fun baseUrl(input: String, rs: String = "eSCL"): String? {
        var t = input.trim()
        if (t.isEmpty() || t.any { it.isWhitespace() }) return null
        t = t.removePrefix("http://").removePrefix("HTTP://")
        if (t.contains("://")) return null
        val slash = t.indexOf('/')
        val path = if (slash >= 0) t.substring(slash).trim('/') else ""
        val hostPort = if (slash >= 0) t.substring(0, slash) else t
        val host: String
        var port = 80
        if (hostPort.startsWith("[")) {
            val close = hostPort.indexOf(']')
            if (close < 0) return null
            host = hostPort.substring(0, close + 1)
            val rest = hostPort.substring(close + 1)
            if (rest.isNotEmpty()) { if (!rest.startsWith(":")) return null; port = rest.substring(1).toIntOrNull() ?: return null }
        } else {
            val c = hostPort.lastIndexOf(':')
            if (c >= 0) { host = hostPort.substring(0, c); port = hostPort.substring(c + 1).toIntOrNull() ?: return null } else host = hostPort
        }
        if (host.isEmpty() || port !in 1..65535) return null
        if (!host.startsWith("[") && !host.all { it.isLetterOrDigit() || it == '.' || it == '-' }) return null
        val root = if (path.isEmpty()) rs.trim('/') else path
        return "http://$host:$port/$root"
    }

    /** True for addresses on the local network only: IPv4 10/8, 172.16/12, 192.168/16, 169.254/16, 127/8; IPv6 ::1, fe80::/10, fc00::/7 (and IPv4-mapped forms of the IPv4 ranges). */
    fun isPrivateAddress(a: InetAddress): Boolean {
        if (a is Inet4Address) {
            val b = a.address
            val b0 = b[0].toInt() and 0xFF
            val b1 = b[1].toInt() and 0xFF
            return b0 == 10 || b0 == 127 || (b0 == 172 && b1 in 16..31) || (b0 == 192 && b1 == 168) || (b0 == 169 && b1 == 254)
        }
        if (a is Inet6Address) {
            val b = a.address
            val b0 = b[0].toInt() and 0xFF
            val b1 = b[1].toInt() and 0xFF
            val loopback = b.take(15).all { it.toInt() == 0 } && b[15].toInt() == 1
            return loopback || (b0 == 0xFE && (b1 and 0xC0) == 0x80) || (b0 and 0xFE) == 0xFC
        }
        return false
    }
}
