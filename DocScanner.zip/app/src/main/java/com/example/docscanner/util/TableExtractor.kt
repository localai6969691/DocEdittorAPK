package com.example.docscanner.util

/**
 * Rebuilds a table (rows x columns of text) from the words of ONE page and their boxes, the way OCR returns them. No table lines are
 * needed: columns are found as vertical WHITE GUTTERS - strips that (almost) no row's words cross - which works for ruled and for
 * unruled tables alike.
 *
 * 1. Rows: words whose vertical centres are within 0.6 x (median word height) of the row so far.
 * 2. Cells: inside a row, words closer than 0.8 x median height belong to the same cell ("Nguyễn Văn An" is one cell).
 * 3. Gutters: only rows with 2 or more cells vote; a strip is a gutter when at most 10% of those rows have a word on it (so a title
 *    that runs across the table does not hide the gutters) and it is at least 0.8 x median height wide. The boundary is the START of the
 *    part of the gutter that no row touches (see [boundaryIn]).
 * 4. Each cell goes to the column holding its LEFT edge (a title that crosses gutters therefore lands in the column where it starts).
 *
 * Known limits (documented in TECHNICAL_DOCS 4.30): a cell whose text wraps onto a second line becomes a second row with one filled
 * cell; two columns closer than 0.8 x the text height merge; a rotated page ruins the rows (straighten it first).
 * Pure Kotlin: `tools/verify/ExportCheck.java` is a line-by-line Java copy run by `export_check.py` on generated tables.
 */
object TableExtractor {

    class Word(val text: String, val left: Float, val top: Float, val right: Float, val bottom: Float) {
        val centerY: Float get() = (top + bottom) / 2f
        val height: Float get() = bottom - top
    }

    /** [columns] is 1 when no table structure was found (the rows are then just lines of text). */
    class Table(val rows: List<List<String>>, val columns: Int)

    private class Cell(val left: Float, val right: Float, val text: String)

    fun extract(words: List<Word>): Table {
        val usable = words.filter { it.text.isNotBlank() && it.height > 0f && it.right >= it.left }
        if (usable.isEmpty()) return Table(emptyList(), 0)
        val medianH = median(usable.map { it.height })

        // 1. rows
        val sorted = usable.sortedBy { it.centerY }
        val rowWords = ArrayList<MutableList<Word>>()
        var rowCenter = 0f
        for (w in sorted) {
            if (rowWords.isEmpty() || w.centerY - rowCenter > 0.6f * medianH) {
                rowWords.add(mutableListOf(w))
                rowCenter = w.centerY
            } else {
                val row = rowWords.last()
                row.add(w)
                rowCenter = row.sumOf { it.centerY.toDouble() }.toFloat() / row.size
            }
        }

        // 2. cells
        val cellGap = 0.8f * medianH
        val rows = rowWords.map { ws ->
            val ordered = ws.sortedBy { it.left }
            val cells = ArrayList<Cell>()
            var start = 0
            for (i in 1..ordered.size) {
                if (i == ordered.size || ordered[i].left - ordered[i - 1].right > cellGap) {
                    val part = ordered.subList(start, i)
                    cells.add(Cell(part.first().left, part.maxOf { it.right }, part.joinToString(" ") { it.text }))
                    start = i
                }
            }
            cells
        }

        // 3. gutters from the rows that have several cells
        val tableRows = rows.filter { it.size >= 2 }
        if (tableRows.size < 2) return Table(rows.map { r -> listOf(r.joinToString(" ") { it.text }) }, 1)
        val minX = usable.minOf { it.left }
        val maxX = usable.maxOf { it.right }
        val boundaries = findBoundaries(tableRows, minX, maxX, medianH)
        if (boundaries.isEmpty()) return Table(rows.map { r -> listOf(r.joinToString(" ") { it.text }) }, 1)

        // 4. cells into columns
        fun columnOf(x: Float): Int = boundaries.count { it <= x }
        val columns = boundaries.size + 1
        val grid = rows.map { r ->
            val line = Array(columns) { StringBuilder() }
            for (cell in r) {
                val col = columnOf(cell.left)
                if (line[col].isNotEmpty()) line[col].append(' ')
                line[col].append(cell.text)
            }
            line.map { it.toString() }
        }
        return Table(grid, columns)
    }

    /** x of the boundary of every gutter, left to right: strips that at most 10% of the voting [rows] have a word on, at least 0.8 x [medianH] wide, between used strips. */
    private fun findBoundaries(rows: List<List<Cell>>, minX: Float, maxX: Float, medianH: Float): List<Float> {
        val step = maxOf(1f, medianH / 10f)
        val buckets = ((maxX - minX) / step).toInt() + 2
        val coverage = IntArray(buckets)
        for (r in rows) {
            val seen = BooleanArray(buckets)
            for (cell in r) {
                // the cell's box, not its words: gaps INSIDE a cell are smaller than a gutter
                val a = ((cell.left - minX) / step).toInt().coerceIn(0, buckets - 1)
                val b = ((cell.right - minX) / step).toInt().coerceIn(0, buckets - 1)
                for (k in a..b) seen[k] = true
            }
            for (k in 0 until buckets) if (seen[k]) coverage[k]++
        }
        val tolerance = (0.1f * rows.size).toInt()
        // the table spans the strips that more than the tolerated few rows touch: a title that runs past the right edge of the table
        // must not create an empty column out there
        val firstUsed = coverage.indexOfFirst { it > tolerance }
        val lastUsed = coverage.indexOfLast { it > tolerance }
        if (firstUsed < 0) return emptyList()
        val minGutterBuckets = Math.ceil((0.8f * medianH / step).toDouble()).toInt()
        val boundaries = ArrayList<Float>()
        var runStart = -1
        for (k in firstUsed..lastUsed + 1) {
            val free = k <= lastUsed && coverage[k] <= tolerance
            if (free && runStart < 0) runStart = k
            if (!free && runStart >= 0) {
                if (runStart > firstUsed && k - runStart >= minGutterBuckets) boundaries.add(boundaryIn(coverage, runStart, k, minGutterBuckets, minX, step))
                runStart = -1
            }
        }
        return boundaries
    }

    /**
     * Where the boundary between two columns goes inside the free run [from, to) of strips. A strip counts as "free" when at most a few rows
     * touch it, so the run can reach into the left part of a right-aligned column whose widest cell (a header such as "Thành tiền") sticks out.
     * The longest part that NO row touches is a true separator, and its START is the boundary: a cell that pokes into the gutter from the right
     * starts after that point (it belongs to the right column), one that pokes in from the left - a title, the widest entry of a left-aligned
     * column - starts before it (the left column). The middle of the whole run would put the first kind on the wrong side.
     */
    private fun boundaryIn(coverage: IntArray, from: Int, to: Int, minBuckets: Int, minX: Float, step: Float): Float {
        var bestStart = -1
        var bestLen = 0
        var s = -1
        for (k in from..to) {
            val zero = k < to && coverage[k] == 0
            if (zero && s < 0) s = k
            if (!zero && s >= 0) {
                if (k - s > bestLen) { bestLen = k - s; bestStart = s }
                s = -1
            }
        }
        return if (bestLen >= minBuckets) minX + bestStart * step else minX + (from + to) / 2f * step
    }

    private fun median(values: List<Float>): Float {
        val s = values.sorted()
        return if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2f
    }
}
