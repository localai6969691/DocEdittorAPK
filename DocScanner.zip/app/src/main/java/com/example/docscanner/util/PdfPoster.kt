package com.example.docscanner.util

import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.LayerUtility
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.util.Matrix
import java.io.File

/**
 * "Poster" printing (phiên 19, mục 4.47.3; item B10 / 8.2 of the PDF "Thiếu gì để bán app"): ONE page enlarged over several A4 sheets that are printed, trimmed and glued
 * together into a big sheet - the opposite of [PdfImposer], which puts several pages on one sheet.
 *
 * The page is scaled so that its width covers [cols] sheets side by side; how many sheet ROWS that needs follows from its proportions ([plan]). Neighbouring sheets repeat a
 * [OVERLAP] strip (10 mm) so that the tiles can be overlapped and glued without a gap, every sheet keeps a [MARGIN] (7 mm) the printer can reach, and four corner marks outside
 * the printable area show where to trim. Sheets are portrait for a portrait page and landscape for a landscape page. As in [PdfImposer] nothing is rasterized: the page is
 * imported as a form XObject (vector text stays vector) and placed by a transformation `[tile window + fit scale] x [inverse of PdfPageGeometry's display matrix]`, clipped
 * to the printable area. [plan] is mirrored in tools/verify/PosterCheck.java and verified against poppler renders by tools/verify/poster_check.py.
 */
object PdfPoster {

    private const val A4_WIDTH = 595.276f
    private const val A4_HEIGHT = 841.89f
    const val MARGIN = 20f
    const val OVERLAP = 28.35f
    const val MIN_COLS = 2
    const val MAX_COLS = 6

    /**
     * The layout of one poster. Everything is in points. "Poster space" has its origin at the bottom-left of the whole enlarged area ([cols] printable widths minus the overlaps,
     * [rows] printable heights minus the overlaps); the scaled page sits at ([offsetX], [offsetY]) in it. [windows] has `cols * rows` entries in reading order (top row first,
     * left to right): the lower-left corner `[x, y]` in poster space of the part of the poster that sheet shows, a [printableWidth] x [printableHeight] rectangle.
     */
    class Plan(
        val sheetWidth: Float, val sheetHeight: Float, val cols: Int, val rows: Int, val scale: Float,
        val offsetX: Float, val offsetY: Float, val printableWidth: Float, val printableHeight: Float, val windows: List<FloatArray>
    )

    /** Layout for a page shown at [displayWidth] x [displayHeight] (after /Rotate and CropBox) spread over [cols] sheets across. */
    fun plan(displayWidth: Float, displayHeight: Float, cols: Int): Plan {
        val c = cols.coerceIn(MIN_COLS, MAX_COLS)
        val landscape = displayWidth > displayHeight
        val sheetW = if (landscape) A4_HEIGHT else A4_WIDTH
        val sheetH = if (landscape) A4_WIDTH else A4_HEIGHT
        val pw = sheetW - 2 * MARGIN
        val ph = sheetH - 2 * MARGIN
        val totalW = c * pw - (c - 1) * OVERLAP
        val s = totalW / displayWidth
        val needed = displayHeight * s
        val rows = maxOf(1, Math.ceil(((needed - ph) / (ph - OVERLAP) - 1e-4)).toInt() + 1)
        val totalH = rows * ph - (rows - 1) * OVERLAP
        val windows = ArrayList<FloatArray>()
        for (r in 0 until rows) for (col in 0 until c) windows.add(floatArrayOf(col * (pw - OVERLAP), totalH - r * (ph - OVERLAP) - ph))
        return Plan(sheetW, sheetH, c, rows, s, 0f, (totalH - needed) / 2f, pw, ph, windows)
    }

    /** Writes the poster of page [pageIndex] (0-based) to [out]; returns the number of sheets. The input is only read. Throws "encrypted" for a password-protected PDF. */
    fun poster(src: File, out: File, pageIndex: Int, cols: Int): Int {
        val srcDoc = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
        var dst: PDDocument? = null
        try {
            if (srcDoc.isEncrypted) throw IllegalStateException("encrypted")
            if (pageIndex !in 0 until srcDoc.numberOfPages) throw IllegalArgumentException("no such page")
            val page = srcDoc.getPage(pageIndex)
            val geo = PdfPageGeometry.of(page)
            val plan = plan(geo.displayWidth, geo.displayHeight, cols)
            val inv = geo.inverseMatrixValues()
            val k = plan.scale

            val doc = PDDocument()
            dst = doc
            val layer = LayerUtility(doc)
            val form = layer.importPageAsForm(srcDoc, pageIndex)
            form.getCOSObject().removeItem(COSName.MATRIX)   // our own, verified geometry replaces LayerUtility's (same as PdfImposer)
            form.setBBox(page.cropBox)
            for (window in plan.windows) {
                val sheet = PDPage(PDRectangle(plan.sheetWidth, plan.sheetHeight))
                doc.addPage(sheet)
                PDPageContentStream(doc, sheet).use { cs ->
                    // the printable area, as a clip: nothing of the neighbouring tile's page may reach into the margin
                    cs.saveGraphicsState()
                    cs.addRect(MARGIN, MARGIN, plan.printableWidth, plan.printableHeight)
                    cs.clip()
                    val tx = MARGIN - window[0] + plan.offsetX
                    val ty = MARGIN - window[1] + plan.offsetY
                    cs.transform(Matrix(k * inv[0], k * inv[1], k * inv[2], k * inv[3], k * inv[4] + tx, k * inv[5] + ty))
                    cs.drawForm(form)
                    cs.restoreGraphicsState()
                    // four corner marks in the margin: where to trim
                    cs.setStrokingColor(0.55f, 0.55f, 0.55f)
                    cs.setLineWidth(0.5f)
                    val l = MARGIN
                    val r = MARGIN + plan.printableWidth
                    val b = MARGIN
                    val t = MARGIN + plan.printableHeight
                    for ((cx, dx) in listOf(l to -1f, r to 1f)) for ((cy, dy) in listOf(b to -1f, t to 1f)) {
                        cs.moveTo(cx, cy); cs.lineTo(cx + dx * (MARGIN - 4f), cy)
                        cs.moveTo(cx, cy); cs.lineTo(cx, cy + dy * (MARGIN - 4f))
                    }
                    cs.stroke()
                }
            }
            val sheets = plan.windows.size
            PdfStructureOptimizer.save(doc, out)
            if (!PdfVerify.opensAsPdf(out, sheets)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
            return sheets
        } finally {
            runCatching { dst?.close() }
            runCatching { srcDoc.close() }
        }
    }
}
