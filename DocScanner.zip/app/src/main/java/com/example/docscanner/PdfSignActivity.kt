package com.example.docscanner

import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityPdfSignBinding
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfStamper
import com.example.docscanner.util.SignatureStore
import com.example.docscanner.util.StampRenderer
import com.example.docscanner.view.SignaturePadView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import com.example.docscanner.util.SignedPdfGuard

/**
 * "Ký & đóng dấu PDF" - put a handwritten signature or a stamp on pages of a PDF WITHOUT rasterizing it (the
 * page's text stays text; see [PdfStamper]). Flow: pick a PDF -> pick/draw a signature or a stamp -> drag and pinch
 * it into place on the preview -> choose which pages -> save a new PDF in the export folder.
 *
 * The preview is [PdfRenderer]'s rendering of the page as displayed; [com.example.docscanner.view.StampPlacementView]
 * reports the placement as fractions of the page, and [PdfStamper] maps that onto each chosen page whatever its
 * rotation or CropBox.
 *
 * This is a VISUAL signature only - the hint text in the layout says so. Real digital signatures (a certificate,
 * a "signed by" panel in the viewer) are a separate feature, see TECHNICAL_DOCS.md section 10.
 *
 * Process death: the working copy of the PDF lives in the app's temp dir and its path + the page being viewed are
 * saved in the instance state, so a kill while the user is placing the signature brings the same page back; the
 * chosen signature/stamp itself is cheap to pick again (drawn signatures are already stored by [SignatureStore]).
 */
class PdfSignActivity : BaseActivity() {

    private lateinit var binding: ActivityPdfSignBinding

    private var srcFile: File? = null
    private var pfd: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private val renderLock = Mutex()
    private var pageCount = 0
    private var pageIndex = 0
    private var currentStamp: Bitmap? = null
    private var busy = false
    /** How many times something was added to the working copy [srcFile] since the file was opened. */
    private var edits = 0

    private val onPdfChosen = ActivityResultCallback<Uri?> { uri ->
        if (uri == null) {
            finish()
            return@ActivityResultCallback
        }
        setBusy(true)
        lifecycleScope.launch {
            val copy = withContext(Dispatchers.IO) { FileUtils.copyUriToTempFile(this@PdfSignActivity, uri, ".pdf") }
            if (copy == null) {
                Toast.makeText(this@PdfSignActivity, R.string.sign_open_failed, Toast.LENGTH_LONG).show()
                finish()
                return@launch
            }
            if (!SignedPdfGuard.confirm(this@PdfSignActivity, copy)) {
                runCatching { copy.delete() }
                finish()
                return@launch
            }
            openSource(copy, 0)
        }
    }

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument(), onPdfChosen)

    /** First pick of this screen: a PDF that another app handed over ("Open with" / "Share", see `IncomingFile`) is used directly, otherwise the system picker opens. */
    private fun pickPdfOrUseIncoming() {
        val incoming = intent?.data
        if (incoming != null) onPdfChosen.onActivityResult(incoming) else pdfPicker.launch(arrayOf("application/pdf"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfSignBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.sign_title)

        binding.btnPrevPage.setOnClickListener { goToPage(pageIndex - 1) }
        binding.btnNextPage.setOnClickListener { goToPage(pageIndex + 1) }
        binding.btnSignDraw.setOnClickListener { showSignaturePad() }
        binding.btnSignSaved.setOnClickListener { showSavedSignatures() }
        binding.btnSignStamp.setOnClickListener { showStampChooser() }
        binding.btnSignApply.setOnClickListener { chooseScopeAndApply() }
        binding.btnSignSave.setOnClickListener { saveAndExit() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (edits == 0 || busy) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                } else {
                    AlertDialog.Builder(this@PdfSignActivity)
                        .setTitle(R.string.sign_discard_title)
                        .setMessage(getString(R.string.sign_discard_message, edits))
                        .setNegativeButton(R.string.dialog_cancel, null)
                        .setPositiveButton(R.string.sign_discard_exit) { _, _ ->
                            isEnabled = false
                            onBackPressedDispatcher.onBackPressed()
                        }
                        .show()
                }
            }
        })

        val restored = savedInstanceState?.getString(STATE_SRC)?.let { File(it) }?.takeIf { it.isFile }
        if (restored != null) {
            edits = savedInstanceState.getInt(STATE_EDITS, 0)
            setBusy(true)
            lifecycleScope.launch { openSource(restored, savedInstanceState.getInt(STATE_PAGE, 0)) }
        } else {
            pickPdfOrUseIncoming()
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        srcFile?.let { outState.putString(STATE_SRC, it.absolutePath) }
        outState.putInt(STATE_PAGE, pageIndex)
        outState.putInt(STATE_EDITS, edits)
    }

    override fun onDestroy() {
        super.onDestroy()
        closeRenderer()
        // keep the working copy across a configuration change/process kill; drop it when the user is really leaving
        if (isFinishing) srcFile?.let { runCatching { it.delete() } }
    }

    private fun closeRenderer() {
        runCatching { renderer?.close() }
        runCatching { pfd?.close() }
        renderer = null
        pfd = null
    }

    private suspend fun openSource(file: File, startPage: Int) {
        val opened = withContext(Dispatchers.IO) {
            try {
                val d = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                try {
                    Triple(d, PdfRenderer(d), null as Throwable?)
                } catch (e: Throwable) {
                    runCatching { d.close() }
                    Triple(null, null, e)
                }
            } catch (e: Throwable) {
                Triple(null, null, e)
            }
        }
        val (d, r, error) = opened
        if (d == null || r == null || r.pageCount == 0) {
            runCatching { r?.close() }
            runCatching { d?.close() }
            val encrypted = error is SecurityException
            Toast.makeText(this, if (encrypted) R.string.sign_encrypted else R.string.sign_open_failed, Toast.LENGTH_LONG).show()
            runCatching { file.delete() }
            srcFile = null
            finish()
            return
        }
        closeRenderer()
        srcFile = file
        pfd = d
        renderer = r
        pageCount = r.pageCount
        showPage(startPage.coerceIn(0, pageCount - 1))
    }

    private fun goToPage(index: Int) {
        if (busy || index !in 0 until pageCount) return
        showPage(index)
    }

    private fun showPage(index: Int) {
        pageIndex = index
        binding.tvPageIndicator.text = getString(R.string.annotate_page_indicator, index + 1, pageCount)
        binding.btnPrevPage.isEnabled = index > 0
        binding.btnNextPage.isEnabled = index < pageCount - 1
        setBusy(true)
        lifecycleScope.launch {
            val bmp = renderPage(index)
            if (index == pageIndex) binding.placementView.setPage(bmp)   // ignore a render that was overtaken
            setBusy(false)
        }
    }

    private suspend fun renderPage(index: Int): Bitmap? = renderLock.withLock {
        withContext(Dispatchers.IO) {
            val r = renderer ?: return@withContext null
            try {
                val page = r.openPage(index)
                try {
                    val targetW = (resources.displayMetrics.widthPixels * 1.5f).toInt().coerceIn(600, 1600)
                    var scale = targetW.toFloat() / page.width
                    if (page.height * scale > 3000f) scale = 3000f / page.height
                    val w = (page.width * scale).toInt().coerceAtLeast(1)
                    val h = (page.height * scale).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    Canvas(bmp).drawColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bmp
                } finally {
                    page.close()
                }
            } catch (e: Throwable) {
                null
            }
        }
    }

    private fun setBusy(value: Boolean) {
        busy = value
        binding.signProgress.visibility = if (value) View.VISIBLE else View.GONE
        binding.btnSignApply.isEnabled = !value
        binding.btnSignSave.isEnabled = !value
        binding.btnSignDraw.isEnabled = !value
        binding.btnSignSaved.isEnabled = !value
        binding.btnSignStamp.isEnabled = !value
        if (!value) {
            binding.btnPrevPage.isEnabled = pageIndex > 0
            binding.btnNextPage.isEnabled = pageIndex < pageCount - 1
        }
    }

    private fun useStamp(bitmap: Bitmap) {
        currentStamp = bitmap
        binding.placementView.setStamp(bitmap)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    // ---- picking what to put on the page ----

    private fun showSignaturePad() {
        val pad = SignaturePadView(this)
        val frame = FrameLayout(this).apply {
            setBackgroundColor(Color.WHITE)
            setPadding(dp(16), dp(8), dp(16), 0)
            addView(pad, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(240)))
            // "Undo" removes the last stroke (SignaturePadView.undoStroke existed but had no button, 4.55); the three dialog buttons are already taken
            val undo = android.widget.Button(this).apply {
                setText(R.string.sign_pad_undo)
                minimumHeight = dp(48)
                setOnClickListener { pad.undoStroke() }
            }
            addView(undo, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, android.view.Gravity.TOP or android.view.Gravity.END))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.sign_pad_title)
            .setView(frame)
            .setNeutralButton(R.string.sign_pad_clear, null)
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.sign_pad_use, null)
            .create()
        dialog.show()
        // overridden after show() so an empty pad or "clear" does not close the dialog
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener { pad.clear() }
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val bmp = pad.toBitmap()
            if (bmp == null) {
                Toast.makeText(this, R.string.sign_pad_empty, Toast.LENGTH_SHORT).show()
            } else {
                SignatureStore.save(this, bmp)
                useStamp(bmp)
                dialog.dismiss()
            }
        }
    }

    private fun showSavedSignatures() {
        val files = SignatureStore.list(this)
        if (files.isEmpty()) {
            Toast.makeText(this, R.string.sign_saved_none, Toast.LENGTH_SHORT).show()
            return
        }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val dialog = AlertDialog.Builder(this)
            .setTitle(R.string.sign_saved_title)
            .setView(ScrollView(this).apply { addView(container) })
            .setNegativeButton(R.string.dialog_cancel, null)
            .create()
        for (f in files) {
            val bmp = SignatureStore.load(f) ?: continue
            val item = ImageView(this).apply {
                setImageBitmap(bmp)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setBackgroundColor(Color.WHITE)
                setPadding(dp(8), dp(8), dp(8), dp(8))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(96)).apply { bottomMargin = dp(8) }
                setOnClickListener { useStamp(bmp); dialog.dismiss() }
                setOnLongClickListener {
                    AlertDialog.Builder(this@PdfSignActivity)
                        .setMessage(R.string.sign_saved_delete_confirm)
                        .setNegativeButton(R.string.dialog_cancel, null)
                        .setPositiveButton(R.string.dialog_ok) { _, _ ->
                            SignatureStore.delete(f)
                            container.removeView(this)
                            if (container.childCount == 0) dialog.dismiss()
                        }
                        .show()
                    true
                }
            }
            container.addView(item)
        }
        dialog.show()
    }

    private fun showStampChooser() {
        val presets = listOf(
            getString(R.string.stamp_approved) to StampRenderer.GREEN,
            getString(R.string.stamp_checked) to StampRenderer.BLUE,
            getString(R.string.stamp_copy) to StampRenderer.BLUE,
            getString(R.string.stamp_paid) to StampRenderer.GREEN,
            getString(R.string.stamp_urgent) to StampRenderer.RED
        )
        val labels = presets.map { it.first } + getString(R.string.stamp_date) + getString(R.string.sign_stamp_custom) +
            getString(R.string.sign_stamp_plain)
        AlertDialog.Builder(this)
            .setTitle(R.string.sign_stamp_title)
            .setItems(labels.toTypedArray()) { _, which ->
                when {
                    which < presets.size -> useStamp(StampRenderer.textStamp(presets[which].first, presets[which].second))
                    which == presets.size -> useStamp(StampRenderer.dateStamp())
                    which == presets.size + 1 -> showCustomStampInput(framed = true)
                    else -> showCustomStampInput(framed = false)
                }
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun showCustomStampInput(framed: Boolean) {
        val input = EditText(this).apply {
            setHint(R.string.sign_stamp_custom_hint)
            setSingleLine(false)
            maxLines = 3
        }
        val frame = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(if (framed) R.string.sign_stamp_custom else R.string.sign_stamp_plain)
            .setView(frame)
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.dialog_ok) { _, _ ->
                val text = input.text.toString().trim().take(if (framed) 60 else 200)
                if (text.isNotEmpty()) {
                    useStamp(
                        if (framed) StampRenderer.textStamp(text, StampRenderer.RED)
                        else StampRenderer.plainText(text, SignaturePadView.INK)
                    )
                }
            }
            .show()
    }

    // ---- applying ----

    private fun chooseScopeAndApply() {
        val stamp = currentStamp
        val src = srcFile
        if (stamp == null) {
            Toast.makeText(this, R.string.sign_pick_first, Toast.LENGTH_SHORT).show()
            return
        }
        if (src == null || pageCount == 0) return
        val labels = arrayOf(
            getString(R.string.sign_scope_this),
            getString(R.string.sign_scope_all, pageCount),
            getString(R.string.sign_scope_last)
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.sign_scope_title)
            .setItems(labels) { _, which ->
                val pages = when (which) {
                    0 -> setOf(pageIndex)
                    1 -> (0 until pageCount).toSet()
                    else -> setOf(pageCount - 1)
                }
                runStamp(src, stamp, pages)
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    /** Adds the picture to the WORKING copy (a temp file), reopens it, and lets the user keep adding; saving is a separate step. */
    private fun runStamp(src: File, stamp: Bitmap, pages: Set<Int>) {
        val placement = binding.placementView.placement()
        setBusy(true)
        val work = File(src.parentFile, "sign_work_${System.nanoTime()}.pdf")
        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.Default) { PdfStamper.stamp(src, work, stamp, placement, pages) }
            }
            if (result.getOrNull() == null) {
                setBusy(false)
                runCatching { work.delete() }
                Toast.makeText(this@PdfSignActivity, R.string.sign_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            edits++
            val previous = srcFile
            openSource(work, pageIndex)            // closes the old renderer and shows the result
            if (previous != null && previous != work) runCatching { previous.delete() }
            Toast.makeText(this@PdfSignActivity, getString(R.string.sign_applied, edits), Toast.LENGTH_SHORT).show()
        }
    }

    /** Copies the working file into the export folder as a new document and leaves. */
    private fun saveAndExit() {
        val work = srcFile
        if (work == null || edits == 0) {
            Toast.makeText(this, R.string.sign_nothing_applied, Toast.LENGTH_LONG).show()
            return
        }
        setBusy(true)
        val out = File(PdfExporter.exportDir(this), "${FileUtils.defaultSecurityName("signed")}.pdf")
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching { work.copyTo(out, overwrite = false) }.isSuccess }
            if (!ok) {
                setBusy(false)
                runCatching { out.delete() }
                Toast.makeText(this@PdfSignActivity, R.string.sign_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            edits = 0
            Toast.makeText(this@PdfSignActivity, getString(R.string.sign_saved, out.name), Toast.LENGTH_LONG).show()
            finish()
        }
    }

    companion object {
        private const val STATE_SRC = "sign_src"
        private const val STATE_PAGE = "sign_page"
        private const val STATE_EDITS = "sign_edits"
    }
}
