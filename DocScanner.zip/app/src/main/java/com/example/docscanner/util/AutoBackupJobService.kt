package com.example.docscanner.util

import android.app.job.JobParameters
import android.app.job.JobService

/** Runs the scheduled backup off the main thread (a JobService callback runs ON it). */
class AutoBackupJobService : JobService() {
    @Volatile private var worker: Thread? = null

    override fun onStartJob(params: JobParameters): Boolean {
        val context = applicationContext
        worker = Thread {
            var retry = false
            try {
                val s = AutoBackup.settings(context)
                if (BackupSchedule.isDue(s.lastSuccess, System.currentTimeMillis(), s.interval)) {
                    AutoBackup.runNow(context)
                    AutoBackup.recordSuccess(context)
                }
            } catch (e: Exception) {
                AutoBackup.recordError(context, e.message ?: e.javaClass.simpleName)
                retry = true
            }
            jobFinished(params, retry)
        }.also { it.start() }
        return true   // work continues on the thread
    }

    override fun onStopJob(params: JobParameters): Boolean {
        worker?.interrupt()
        return true   // the system stopped us (charger unplugged...): run again later
    }
}
