package com.example.docscanner.util

import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import kotlin.math.min

/**
 * The text of a document, page by page, for reading aloud, translating and exporting to Word. Three sources, best first:
 *  1. the PDF's own TEXT LAYER (typed PDFs, and the searchable PDFs this app makes) read with PDFBox - exact, no recognition errors;
 *  2. the `.txt` OCR file that the app wrote next to a scanned export;
 *  3. OCR of the page images ([ocrPages]) - slowest, so limited to [maxOcrPages] pages.
 * A page counts as "has text" when it yields at least [MIN_CHARS_PER_PAGE] non-blank characters on average; otherwise the PDF is treated
 * as a scan. Returns null when the file cannot be read at all (a password-protected PDF).
 */
object PdfTextExtractor {

    const val MIN_CHARS_PER_PAGE = 20

    /** Text layer per page, or null if the PDF cannot be opened (encrypted or damaged). Blank pages give "". */
    fun textLayer(file: File): List<String>? {
        return try {
            PDDocument.load(file, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(file.parentFile)).use { doc ->
                if (doc.isEncrypted) return null
                val stripper = PDFTextStripper()
                (1..doc.numberOfPages).map { page ->
                    stripper.startPage = page
                    stripper.endPage = page
                    stripper.getText(doc)
                }
            }
        } catch (e: Throwable) {
            null
        }
    }

    private fun looksLikeText(pages: List<String>): Boolean =
        pages.isNotEmpty() && pages.sumOf { p -> p.count { !it.isWhitespace() } } >= MIN_CHARS_PER_PAGE * pages.size

    /** OCR of the first [maxOcrPages] pages; null when the PDF cannot be rendered. [onProgress] gets (page, total). */
    suspend fun ocrPages(file: File, maxOcrPages: Int, onProgress: (Int, Int) -> Unit): List<String>? {
        val session = PdfPageBitmap.open(file) ?: return null
        try {
            val n = min(session.pageCount, maxOcrPages)
            val out = ArrayList<String>()
            for (i in 0 until n) {
                onProgress(i + 1, n)
                val bmp = session.render(i, 1600) ?: continue
                out.add(try { OcrHelper.recognize(bmp) } finally { bmp.recycle() })
            }
            return out
        } finally {
            session.close()
        }
    }

    /**
     * The pages of [file] (a PDF, or a .txt which is one page): text layer, else the OCR sidecar `.txt`, else OCR. [scanned] is set
     * to true when OCR was needed, so the caller can say that recognition errors are possible. Null if unreadable.
     */
    suspend fun pages(file: File, maxOcrPages: Int, onProgress: (Int, Int) -> Unit, scanned: BooleanArray): List<String>? {
        if (file.extension.equals("txt", ignoreCase = true)) return listOf(file.readText(Charsets.UTF_8))
        val layer = textLayer(file)
        if (layer != null && looksLikeText(layer)) return layer
        val sidecar = File(file.parentFile, file.nameWithoutExtension + ".txt")
        if (sidecar.isFile) {
            val text = sidecar.readText(Charsets.UTF_8)
            if (text.isNotBlank()) { scanned[0] = true; return listOf(text) }
        }
        scanned[0] = true
        return ocrPages(file, maxOcrPages, onProgress)
    }
}
