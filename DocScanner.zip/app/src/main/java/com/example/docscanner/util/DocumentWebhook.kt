package com.example.docscanner.util

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Webhook (PDF list F7, and the hook people use from automation tools such as n8n, Make or Tasker's HTTP request for F6): when a NEW document shows up in the
 * list, the app POSTs a short JSON message to an https address the person chose. OFF until the person enters an address.
 *
 * What is sent: the document's name, type, size and time - NEVER its content, pages or text. The settings dialog says so. With a signing secret every message
 * carries `X-DocScanner-Signature: sha256=<hex>` = HMAC-SHA256 of the exact body bytes (the convention GitHub / Stripe use), so the receiving server can check
 * that the message came from this app and was not changed.
 *
 * When: while the app is open, each time the list is refreshed (not in the background: no new permission, no service). [pending] picks the documents that
 * are new since the last refresh and recent (a server that was down for a week does not get a week of old messages when it comes back), at most [MAX_PER_PASS]
 * at a time; a message that failed is tried again on the next refresh while the document is still recent. The FIRST time an address is saved, every document
 * already in the list counts as "seen", so switching the webhook on does not announce the whole library.
 *
 * Safety: https only and no credentials in the address (the same [LinkImport.parse] rules); redirects are NOT followed (a redirect could send the body
 * somewhere the person never entered); 10 s timeouts; only a 2xx answer counts as delivered. Pure parts are mirrored by tools/verify/WebhookCheck.java.
 */
object DocumentWebhook {

    const val RECENT_MS = 24L * 60 * 60 * 1000
    const val MAX_PER_PASS = 20
    private const val PREFS = "webhook"
    private const val KEY_URL = "url"
    private const val KEY_SECRET = "secret"
    private const val KEY_SEEN = "seen"
    const val SIGNATURE_HEADER = "X-DocScanner-Signature"

    fun url(context: Context): String = prefs(context).getString(KEY_URL, "").orEmpty()
    fun secret(context: Context): String = prefs(context).getString(KEY_SECRET, "").orEmpty()
    fun isOn(context: Context): Boolean = url(context).isNotEmpty()

    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Saves the address (empty = off) and the secret; when it was off before, marks every document in [currentNames] as already seen. */
    fun save(context: Context, address: String, secret: String, currentNames: Collection<String>) {
        val wasOff = !isOn(context)
        val edit = prefs(context).edit().putString(KEY_URL, address.trim()).putString(KEY_SECRET, secret)
        if (address.isNotBlank() && wasOff) edit.putStringSet(KEY_SEEN, currentNames.toHashSet())
        edit.apply()
    }

    fun seen(context: Context): Set<String> = prefs(context).getStringSet(KEY_SEEN, emptySet()) ?: emptySet()

    fun markSeen(context: Context, names: Collection<String>) {
        prefs(context).edit().putStringSet(KEY_SEEN, seen(context) + names).apply()
    }

    /** Names (at most [limit]) of the documents that are not in [seen], were modified within [recentMs] before [now], oldest first. */
    fun pending(seen: Set<String>, files: List<Pair<String, Long>>, now: Long, recentMs: Long = RECENT_MS, limit: Int = MAX_PER_PASS): List<String> =
        files.filter { it.first !in seen && now - it.second in 0..recentMs }.sortedBy { it.second }.take(limit).map { it.first }

    private fun iso(millis: Long): String =
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date(millis))

    /** The JSON body: `{"event":"document_created","app":"DocScanner","name":...,"type":...,"sizeBytes":...,"modified":"2026-11-02T10:00:00Z"}`. */
    fun payload(name: String, sizeBytes: Long, modifiedMillis: Long): String {
        val type = name.substringAfterLast('.', "").lowercase()
        return "{\"event\":\"document_created\",\"app\":\"DocScanner\",\"name\":" + TextExporters.jsonString(name) + ",\"type\":" + TextExporters.jsonString(type) +
            ",\"sizeBytes\":" + sizeBytes + ",\"modified\":\"" + iso(modifiedMillis) + "\"}"
    }

    fun testPayload(nowMillis: Long): String = "{\"event\":\"test\",\"app\":\"DocScanner\",\"modified\":\"" + iso(nowMillis) + "\"}"

    /** `sha256=<lowercase hex>` of HMAC-SHA256([body], [secret]) with the secret as UTF-8. */
    fun signature(body: ByteArray, secret: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return "sha256=" + mac.doFinal(body).joinToString("") { "%02x".format(it) }
    }

    /** POSTs [json]; true only for a 2xx answer. Never follows a redirect. Network errors are false, not exceptions. */
    fun post(address: URL, json: String, secret: String, timeoutMs: Int = 10_000): Boolean {
        val body = json.toByteArray(Charsets.UTF_8)
        val c = address.openConnection() as HttpURLConnection
        return try {
            c.requestMethod = "POST"
            c.instanceFollowRedirects = false
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.doOutput = true
            c.setFixedLengthStreamingMode(body.size)
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("User-Agent", "DocScanner")
            if (secret.isNotEmpty()) c.setRequestProperty(SIGNATURE_HEADER, signature(body, secret))
            c.outputStream.use { it.write(body) }
            val code = c.responseCode
            runCatching { c.inputStream.use { it.readBytes() } }         // drain so the connection can be reused; the answer's content is not used
            code in 200..299
        } catch (e: Exception) {
            false
        } finally {
            c.disconnect()
        }
    }
}
