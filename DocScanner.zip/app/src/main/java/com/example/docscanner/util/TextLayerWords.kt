package com.example.docscanner.util

/**
 * The PURE geometry of "highlight by the real text layer" (phiên 20, mục 4.48.7; PDF "Thiếu gì để bán app" 3.3-3.4): from the glyph rectangles of ONE word, the box of the word on the DISPLAYED page
 * as fractions (0..1, origin top-left), the same [PdfTextMarkup.WordBox] shape the OCR path produces, so `findPhrase`, `wordsInRect`, `lineBoxes` and the `/Highlight` annotation writer work unchanged
 * and the highlight lands on the real glyphs instead of on what OCR thought it saw.
 *
 * Mirrored in `tools/verify/TextLayerCheck.java`; `text_layer_check.py` compares it with poppler's `pdftotext -bbox` on real PDFs (glyphs read by pdfminer, a third reader).
 * The code that reads the glyphs out of a PDF is [PdfTextLayer] (PDFBox `TextPosition`), NOT run here.
 */
object TextLayerWords {

    /**
     * A glyph in page units (points), origin TOP-LEFT of the displayed page, y growing DOWNWARD: [baseline] is the y of the baseline and [size] the FONT SIZE (the em), not a glyph height:
     * libraries disagree on what a glyph "height" is (PDFBox's is a font-metrics guess that is often smaller than the ink), while the font size is the same everywhere.
     */
    class Glyph(val x: Float, val baseline: Float, val width: Float, val size: Float)

    /**
     * How far the box reaches above the baseline and below it, in font sizes. TUNED ON REAL DATA (1 879 words of 14 real PDFs, `text_layer_check.py`): 0.95 above and >= 0.20 below cover
     * 100 % of the ink poppler puts inside the word's own box (accents stacked on capitals, descenders g p y), 0.70-0.85 above and 0.10 below clip 3-9 % of the words. 0.25 below leaves a margin.
     */
    const val ASCENT = 0.95f
    const val DESCENT = 0.25f

    /** Words narrower or lower than this fraction of the page are noise (a stray dot of a hidden text layer) and give null. */
    private const val MIN_SIZE = 0.0005f

    /** Box [left, top, right, bottom] of the word made of [glyphs], clamped to the page; null for no glyph, a page of no size, or a degenerate box. */
    fun wordBox(glyphs: List<Glyph>, pageWidth: Float, pageHeight: Float): FloatArray? {
        if (glyphs.isEmpty() || pageWidth <= 0f || pageHeight <= 0f) return null
        var l = Float.MAX_VALUE
        var t = Float.MAX_VALUE
        var r = -Float.MAX_VALUE
        var b = -Float.MAX_VALUE
        for (g in glyphs) {
            if (g.width.isNaN() || g.size.isNaN() || g.x.isNaN() || g.baseline.isNaN()) continue
            l = minOf(l, g.x, g.x + g.width)
            r = maxOf(r, g.x, g.x + g.width)
            t = minOf(t, g.baseline - ASCENT * g.size)
            b = maxOf(b, g.baseline + DESCENT * g.size)
        }
        if (l == Float.MAX_VALUE) return null
        val box = floatArrayOf(
            (l / pageWidth).coerceIn(0f, 1f), (t / pageHeight).coerceIn(0f, 1f),
            (r / pageWidth).coerceIn(0f, 1f), (b / pageHeight).coerceIn(0f, 1f)
        )
        return if (box[2] - box[0] < MIN_SIZE || box[3] - box[1] < MIN_SIZE) null else box
    }
}
