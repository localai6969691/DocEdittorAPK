package com.example.docscanner.util

import android.content.Context

/**
 * The "Easy-to-read font" setting (PDF "Thieu gi de ban app" I6; TECHNICAL_DOCS.md 4.63): the whole app uses Lexend (SIL Open Font License 1.1, bundled in
 * `res/font`, covers all Vietnamese letters) instead of the system font. OFF by default and then NOTHING changes: [com.example.docscanner.BaseActivity] applies
 * the theme overlay `ThemeOverlay.DocScanner.ReadableFont` only when [isOn]. Kept in the same preferences file as [FontScale] (the two are siblings in the same dialog).
 */
object ReadableFont {
    private const val PREFS = "display"
    private const val KEY_ON = "readable_font"

    fun isOn(context: Context): Boolean = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ON, false)

    fun setOn(context: Context, on: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ON, on).apply()
    }
}
