package com.example.docscanner.util

import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSDictionary
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSString
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDDocumentNameDictionary
import com.tom_roush.pdfbox.pdmodel.PDEmbeddedFilesNameTreeNode
import com.tom_roush.pdfbox.pdmodel.common.PDNameTreeNode
import com.tom_roush.pdfbox.pdmodel.common.filespecification.PDComplexFileSpecification
import com.tom_roush.pdfbox.pdmodel.common.filespecification.PDEmbeddedFile
import com.tom_roush.pdfbox.pdmodel.interactive.action.PDActionGoTo
import com.tom_roush.pdfbox.pdmodel.interactive.action.PDActionURI
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationLink
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDNamedDestination
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDPageDestination
import java.io.ByteArrayInputStream
import java.io.File
import java.util.Calendar

/**
 * Ba cau truc "ben trong" cua PDF ma app chua cham toi (phien 18, PDF "Thieu gi de ban app" B4 lien ket, B5 / B20 tep dinh kem, B19 lop OCG):
 *  - TEP DINH KEM (cay ten `/Names /EmbeddedFiles`): liet ke, trich ra, them, xoa;
 *  - LOP HIEN THI (`/OCProperties`): liet ke, bat / tat tung lop;
 *  - LIEN KET (chu thich `/Link`): liet ke (web / nhay trang / khac), xoa lien ket web hoac moi lien ket.
 * Moi thao tac ghi ra TEP MOI (nhu `PdfMetadataTools`), tep goc chi duoc doc. PDF ma hoa bi tu choi ("encrypted").
 *
 * KHONG chay duoc o moi truong phat trien (khong co PdfBox): `tools/verify/pdf_structure_check.py` dung pikepdf dung LAI dung cau truc ma cac ham nay
 * tao ra roi kiem bang cong cu doc lap (poppler: pdfdetach, ve trang; qpdf --check; pypdf). Cac loi goi API PdfBox chi lo ra o CI / may that - TECHNICAL_DOCS.md 4.39.
 */
object PdfStructureTools {

    class Attachment(val name: String, val size: Long, val description: String)
    class Layer(val name: String, val enabled: Boolean)
    enum class LinkKind { WEB, PAGE, OTHER }
    class LinkInfo(val page: Int, val kind: LinkKind, val target: String)

    private fun load(src: File): PDDocument {
        val doc = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
        if (doc.isEncrypted) {
            runCatching { doc.close() }
            throw IllegalStateException("encrypted")
        }
        return doc
    }

    // ---------------------------------------------------------------- tep dinh kem

    private fun collectEmbedded(node: PDNameTreeNode<PDComplexFileSpecification>, out: MutableMap<String, PDComplexFileSpecification>) {
        node.names?.let { out.putAll(it) }
        node.kids?.forEach { collectEmbedded(it, out) }
    }

    private fun embeddedMap(doc: PDDocument): LinkedHashMap<String, PDComplexFileSpecification> {
        val out = LinkedHashMap<String, PDComplexFileSpecification>()
        val tree = doc.documentCatalog.names?.embeddedFiles ?: return out
        collectEmbedded(tree, out)
        return out
    }

    /**
     * Ghi lai TOAN BO cay (phang, khong con Kids). Rong thi go han muc /EmbeddedFiles. KHONG dung `PDNameTreeNode.setNames`: no sap khoa theo chuoi Java, con dac ta PDF
     * (ISO 32000, muc 7.9.6) bat khoa phai sap theo BYTE THO cua chuoi da ma hoa - voi chuoi Unicode (mo dau bang BOM FE FF) hai thu tu KHAC nhau khi tron ten ASCII va
     * ten tieng Viet, va trinh xem do tim kiem nhi phan co the khong thay mot so ten. Bai kiem `pdf_structure_check.py` bat duoc chinh loi nay (poppler liet ke khac thu tu ghi).
     */
    private fun storeEmbedded(doc: PDDocument, map: Map<String, PDComplexFileSpecification>) {
        val catalog = doc.documentCatalog
        val dict = catalog.names ?: PDDocumentNameDictionary(catalog).also { catalog.names = it }
        if (map.isEmpty()) { dict.embeddedFiles = null; return }
        val entries = map.map { (k, v) -> COSString(k) to v }.sortedWith { x, y -> compareBytes(x.first.bytes, y.first.bytes) }
        val arr = COSArray()
        for ((k, v) in entries) {
            v.cosObject.isDirect = false          // ghi thanh doi tuong gian tiep (tham chieu), nhu cac PDF tao tu Acrobat
            arr.add(k); arr.add(v)
        }
        val tree = COSDictionary()
        tree.setItem(COSName.NAMES, arr)
        dict.cosObject.setItem(COSName.EMBEDDED_FILES, tree)
    }

    /** So sanh byte khong dau (0..255), ngan hon dung truoc khi la tien to. */
    internal fun compareBytes(a: ByteArray, b: ByteArray): Int {
        val n = minOf(a.size, b.size)
        for (i in 0 until n) {
            val d = (a[i].toInt() and 0xFF) - (b[i].toInt() and 0xFF)
            if (d != 0) return d
        }
        return a.size - b.size
    }

    private fun fileOf(spec: PDComplexFileSpecification): PDEmbeddedFile? =
        spec.embeddedFileUnicode ?: spec.embeddedFile ?: spec.embeddedFileDos ?: spec.embeddedFileMac ?: spec.embeddedFileUnix

    fun listAttachments(src: File): List<Attachment> {
        val doc = load(src)
        try {
            return embeddedMap(doc).map { (name, spec) ->
                Attachment(name, fileOf(spec)?.size?.toLong() ?: 0L, spec.fileDescription.orEmpty())
            }
        } finally { runCatching { doc.close() } }
    }

    /** Noi dung tep dinh kem [name] (da giai nen), hoac null neu khong co. */
    fun extractAttachment(src: File, name: String): ByteArray? {
        val doc = load(src)
        try {
            val spec = embeddedMap(doc)[name] ?: return null
            return fileOf(spec)?.toByteArray()
        } finally { runCatching { doc.close() } }
    }

    /** Them [data] duoi ten [name] (trung ten thi them " (2)", " (3)"...). @return ten da dung. */
    fun addAttachment(src: File, out: File, name: String, data: ByteArray, mime: String?, description: String): String {
        val doc = load(src)
        try {
            val map = embeddedMap(doc)
            var final = name
            var k = 2
            while (map.containsKey(final)) { final = withSuffix(name, k); k++ }
            val ef = PDEmbeddedFile(doc, ByteArrayInputStream(data))
            ef.subtype = (mime?.takeIf { it.isNotBlank() } ?: "application/octet-stream")
            ef.size = data.size
            val now = Calendar.getInstance()
            ef.creationDate = now
            ef.modDate = now
            val spec = PDComplexFileSpecification()
            spec.file = final
            spec.fileUnicode = final
            if (description.isNotBlank()) spec.fileDescription = description.trim()
            spec.embeddedFile = ef
            spec.embeddedFileUnicode = ef
            map[final] = spec
            storeEmbedded(doc, map)
            doc.save(out)
            return final
        } finally { runCatching { doc.close() } }
    }

    internal fun withSuffix(name: String, k: Int): String {
        val dot = name.lastIndexOf('.')
        return if (dot <= 0) "$name ($k)" else name.substring(0, dot) + " ($k)" + name.substring(dot)
    }

    /** Xoa cac tep dinh kem co ten trong [names]. @return so tep da xoa. */
    fun removeAttachments(src: File, out: File, names: Set<String>): Int {
        val doc = load(src)
        try {
            val map = embeddedMap(doc)
            var n = 0
            for (nm in names) if (map.remove(nm) != null) n++
            storeEmbedded(doc, map)
            doc.save(out)
            return n
        } finally { runCatching { doc.close() } }
    }

    // ---------------------------------------------------------------- PDF Portfolio (B20)

    private val COLLECTION = COSName.getPDFName("Collection")
    private val VIEW = COSName.getPDFName("View")

    /** PDF dang o che do Portfolio (Catalog co `/Collection`): trinh xem ho tro se hien cac tep dinh kem nhu mot "thu muc" thay vi trang bia. */
    fun isPortfolio(src: File): Boolean {
        val doc = load(src)
        try { return doc.documentCatalog.cosObject.containsKey(COLLECTION) } finally { runCatching { doc.close() } }
    }

    /**
     * Bat / tat che do Portfolio: them / go muc `/Collection << /Type /Collection /View /D >>` (D = hien chi tiet) trong Catalog, tren nen cac TEP DINH KEM da co.
     * Bat ma chua co tep dinh kem -> IllegalStateException("no attachments") (mot Portfolio rong vo nghia). Trinh xem khong ho tro Portfolio van hien cac trang binh thuong.
     * Chua khai bao `/Schema` (cot tuy chinh): Acrobat dung cot mac dinh - xem TECHNICAL_DOCS.md 4.40.
     */
    fun setPortfolio(src: File, out: File, enable: Boolean) {
        val doc = load(src)
        try {
            val root = doc.documentCatalog.cosObject
            if (enable) {
                if (embeddedMap(doc).isEmpty()) throw IllegalStateException("no attachments")
                val c = COSDictionary()
                c.setItem(COSName.TYPE, COLLECTION)
                c.setItem(VIEW, COSName.getPDFName("D"))
                root.setItem(COLLECTION, c)
            } else {
                root.removeItem(COLLECTION)
            }
            doc.save(out)
        } finally { runCatching { doc.close() } }
    }

    // ---------------------------------------------------------------- lop hien thi (OCG)

    fun listLayers(src: File): List<Layer> {
        val doc = load(src)
        try {
            val props = doc.documentCatalog.ocProperties ?: return emptyList()
            return props.optionalContentGroups.map { Layer(it.name.orEmpty(), props.isGroupEnabled(it)) }
        } finally { runCatching { doc.close() } }
    }

    /**
     * Dat trang thai bat / tat cho TUNG lop theo thu tu cua [listLayers] ([enabled] phai co dung so phan tu). Thao tac TRUC TIEP tren hai mang `/D /ON` va `/D /OFF`
     * theo dac ta PDF (thanh vien ro rang trong mot mang luon thang `/BaseState`): lop bat = co trong ON, khong co trong OFF; lop tat = nguoc lai.
     * Khong dung `setGroupEnabled` cua PdfBox vi hanh vi voi `/BaseState` khong kiem chung duoc o day; cach nay dung lai tung buoc duoc bang pikepdf.
     * Phan tu mang la CHINH doi tuong lop (so sanh bang `===`), ghi ra thanh tham chieu gian tiep chu khong phai ban sao nhung.
     */
    fun setLayers(src: File, out: File, enabled: List<Boolean>) {
        val doc = load(src)
        try {
            val props = doc.documentCatalog.ocProperties ?: throw IllegalStateException("no layers")
            val groups = props.optionalContentGroups.toList()
            require(groups.size == enabled.size) { "layer count" }
            val root = props.cosObject
            val d = root.getDictionaryObject(COSName.D) as? COSDictionary ?: COSDictionary().also { root.setItem(COSName.D, it) }
            fun array(name: COSName): COSArray = d.getDictionaryObject(name) as? COSArray ?: COSArray().also { d.setItem(name, it) }
            val on = array(COSName.ON)
            val off = array(COSName.OFF)
            fun contains(a: COSArray, g: COSDictionary): Boolean { for (i in 0 until a.size()) if (a.getObject(i) === g) return true; return false }
            fun remove(a: COSArray, g: COSDictionary) { for (i in a.size() - 1 downTo 0) if (a.getObject(i) === g) a.remove(i) }
            for ((i, grp) in groups.withIndex()) {
                val g = grp.cosObject
                val (add, drop) = if (enabled[i]) on to off else off to on
                remove(drop, g)
                if (!contains(add, g)) add.add(g)
            }
            doc.save(out)
        } finally { runCatching { doc.close() } }
    }

    // ---------------------------------------------------------------- lien ket

    fun listLinks(src: File): List<LinkInfo> {
        val doc = load(src)
        try {
            val out = ArrayList<LinkInfo>()
            for ((pi, page) in doc.pages.withIndex()) {
                for (a in page.annotations) {
                    if (a !is PDAnnotationLink) continue
                    out.add(describe(doc, pi + 1, a))
                }
            }
            return out
        } finally { runCatching { doc.close() } }
    }

    private fun describe(doc: PDDocument, page: Int, link: PDAnnotationLink): LinkInfo {
        val action = link.action
        if (action is PDActionURI) return LinkInfo(page, LinkKind.WEB, action.uri.orEmpty())
        val dest = if (action is PDActionGoTo) action.destination else link.destination
        if (dest is PDPageDestination) {
            val n = dest.retrievePageNumber()
            return if (n >= 0) LinkInfo(page, LinkKind.PAGE, (n + 1).toString()) else LinkInfo(page, LinkKind.OTHER, "")
        }
        if (dest is PDNamedDestination) {
            val pd = doc.documentCatalog.findNamedDestinationPage(dest)
            val n = pd?.retrievePageNumber() ?: -1
            return if (n >= 0) LinkInfo(page, LinkKind.PAGE, (n + 1).toString()) else LinkInfo(page, LinkKind.OTHER, dest.namedDestination.orEmpty())
        }
        return LinkInfo(page, LinkKind.OTHER, "")
    }

    /** Xoa lien ket web (rieng, an toan hon khi gui di: mat cac duong dan theo doi) hoac moi lien ket; chu thich khac giu nguyen. @return so lien ket da xoa. */
    fun removeLinks(src: File, out: File, onlyWeb: Boolean): Int {
        val doc = load(src)
        try {
            var removed = 0
            for (page in doc.pages) {
                val all = page.annotations
                val keep = all.filter { a ->
                    val drop = a is PDAnnotationLink && (!onlyWeb || a.action is PDActionURI)
                    if (drop) removed++
                    !drop
                }
                if (keep.size != all.size) page.annotations = keep
            }
            doc.save(out)
            return removed
        } finally { runCatching { doc.close() } }
    }
}
