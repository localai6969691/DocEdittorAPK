package com.example.docscanner.util

import java.io.ByteArrayOutputStream
import java.math.BigInteger
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Just enough ASN.1 DER to assemble a CMS/PKCS#7 signature (see [CmsSigner]) and to pick the issuer and serial number
 * out of an X.509 certificate WITHOUT any third-party library: Android has no public API for either, and adding
 * BouncyCastle brings provider-name clashes with the platform's own "BC" and a larger app for ~150 lines of work.
 *
 * Every function is a literal twin of the Java in tools/verify/CmsCheck.java, which runs on a real JVM; its output is
 * accepted by `pdfsig` (poppler) and `openssl cms -verify` (tools/verify/digital_signature_check.py). Change one, change
 * the other, and re-run that check.
 */
internal object DerWriter {

    fun concat(vararg parts: ByteArray): ByteArray {
        val o = ByteArrayOutputStream()
        for (p in parts) o.write(p, 0, p.size)
        return o.toByteArray()
    }

    fun lengthBytes(n: Int): ByteArray {
        if (n < 128) return byteArrayOf(n.toByte())
        var count = 0
        var v = n
        while (v > 0) { count++; v = v ushr 8 }
        val out = ByteArray(1 + count)
        out[0] = (0x80 or count).toByte()
        for (i in 0 until count) out[1 + i] = (n ushr (8 * (count - 1 - i))).toByte()
        return out
    }

    fun tlv(tag: Int, content: ByteArray): ByteArray = concat(byteArrayOf(tag.toByte()), lengthBytes(content.size), content)

    fun sequence(vararg parts: ByteArray): ByteArray = tlv(0x30, concat(*parts))

    /** DER SET OF: the components are put in ascending order (see [sortedForSet]). */
    fun setOf(vararg parts: ByteArray): ByteArray = tlv(0x31, concat(*sortedForSet(parts.toList()).toTypedArray()))

    fun nullValue(): ByteArray = byteArrayOf(0x05, 0x00)

    fun octetString(bytes: ByteArray): ByteArray = tlv(0x04, bytes)

    fun integer(value: BigInteger): ByteArray = tlv(0x02, value.toByteArray())

    fun oid(dotted: String): ByteArray {
        val parts = dotted.split(".")
        val o = ByteArrayOutputStream()
        o.write(parts[0].toInt() * 40 + parts[1].toInt())
        for (i in 2 until parts.size) {
            val v = parts[i].toLong()
            var groups = 1
            var t = v ushr 7
            while (t > 0) { groups++; t = t ushr 7 }
            for (g in groups - 1 downTo 0) {
                val b = ((v ushr (7 * g)) and 0x7F).toInt()
                o.write(if (g > 0) (b or 0x80) else b)
            }
        }
        return tlv(0x06, o.toByteArray())
    }

    /** UTCTime `yyMMddHHmmssZ` (valid for 1950-2049, which is what CMS signingTime uses). */
    fun utcTime(millis: Long): ByteArray {
        val f = SimpleDateFormat("yyMMddHHmmss'Z'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return tlv(0x17, f.format(Date(millis)).toByteArray(Charsets.US_ASCII))
    }

    /** X.690 11.6: components of a SET OF are compared as octet strings, the shorter padded with trailing zeros. */
    fun sortedForSet(parts: List<ByteArray>): List<ByteArray> =
        parts.sortedWith(Comparator { a, b ->
            val n = maxOf(a.size, b.size)
            var result = 0
            var i = 0
            while (i < n && result == 0) {
                val x = if (i < a.size) a[i].toInt() and 0xFF else 0
                val y = if (i < b.size) b[i].toInt() and 0xFF else 0
                if (x != y) result = x.compareTo(y)
                i++
            }
            result
        })

    /** `[tag, headerLength, contentLength]` of the element that starts at [off]. */
    fun header(d: ByteArray, off: Int): IntArray {
        val tag = d[off].toInt() and 0xFF
        val first = d[off + 1].toInt() and 0xFF
        if (first < 128) return intArrayOf(tag, 2, first)
        val count = first and 0x7F
        var len = 0
        for (i in 0 until count) len = (len shl 8) or (d[off + 2 + i].toInt() and 0xFF)
        return intArrayOf(tag, 2 + count, len)
    }

    /** The serial-number INTEGER and the issuer Name of a DER certificate, each copied byte-for-byte (tag and length included). */
    fun serialAndIssuer(cert: ByteArray): Pair<ByteArray, ByteArray> {
        val outer = header(cert, 0)                       // Certificate ::= SEQUENCE
        val tbsOff = outer[1]
        val tbs = header(cert, tbsOff)                    // TBSCertificate ::= SEQUENCE
        var p = tbsOff + tbs[1]
        if ((cert[p].toInt() and 0xFF) == 0xA0) {         // [0] version, absent in a v1 certificate
            val v = header(cert, p)
            p += v[1] + v[2]
        }
        val ser = header(cert, p)
        val serial = cert.copyOfRange(p, p + ser[1] + ser[2])
        p += ser[1] + ser[2]
        val alg = header(cert, p)                         // signature AlgorithmIdentifier
        p += alg[1] + alg[2]
        val iss = header(cert, p)
        val issuer = cert.copyOfRange(p, p + iss[1] + iss[2])
        return Pair(serial, issuer)
    }
}
