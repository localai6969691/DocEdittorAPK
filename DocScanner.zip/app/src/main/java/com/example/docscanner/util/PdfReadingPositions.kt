package com.example.docscanner.util

/**
 * Where the person stopped reading each PDF (session 23, 4.59): the last page of the most recent [MAX_ENTRIES] PDFs, stored as one text value, one entry per line,
 * `page<TAB>key`. The key is the display name plus the file length (so a different file with the same name does not inherit the place). Reading never throws: a
 * damaged line is skipped. Plain Kotlin, mirrored by tools/verify/ReaderLogicCheck.java.
 */
object PdfReadingPositions {

    const val MAX_ENTRIES = 100

    private fun clean(s: String): String = s.map { if (it == '\t' || it == '\n' || it == '\r') ' ' else it }.joinToString("")

    fun key(name: String, length: Long): String = clean(name) + "|" + length

    fun decode(text: String): LinkedHashMap<String, Int> {
        val map = LinkedHashMap<String, Int>()
        for (line in text.split('\n')) {
            val tab = line.indexOf('\t')
            if (tab <= 0) continue
            val page = line.substring(0, tab).toIntOrNull() ?: continue
            if (page < 0) continue
            val k = line.substring(tab + 1)
            if (k.isEmpty()) continue
            map.remove(k)
            map[k] = page
        }
        return map
    }

    fun encode(map: Map<String, Int>): String = map.entries.joinToString("") { it.value.toString() + "\t" + it.key + "\n" }

    fun get(text: String, key: String): Int? = decode(text)[clean(key)]

    /** Records [page] (0-based) for [key] as the most recent entry; the oldest entries beyond [MAX_ENTRIES] are dropped. */
    fun put(text: String, key: String, page: Int): String {
        val map = decode(text)
        val k = clean(key)
        map.remove(k)
        map[k] = page.coerceAtLeast(0)
        while (map.size > MAX_ENTRIES) map.remove(map.keys.first())
        return encode(map)
    }
}
