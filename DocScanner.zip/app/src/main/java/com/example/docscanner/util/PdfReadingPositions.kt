package com.example.docscanner.util

/**
 * Where the person stopped reading each PDF (session 23, 4.59; the zoom was added in session 26, 4.82): the last page - and the zoom - of the most recent [MAX_ENTRIES] PDFs,
 * stored as one text value, one entry per line, `page<TAB>key` or `page<TAB>key<TAB>zoom` (the zoom is a whole number of hundredths, 105..400, and is left out at 1x, so
 * every value written before session 26 is still read). The key is the display name plus the file length (so a different file with the same name does not inherit the
 * place). Reading never throws: a damaged line is skipped, a damaged zoom is read as 1x. Plain Kotlin, run for real by tools/verify/reading_positions_real_run_check.py.
 */
object PdfReadingPositions {

    const val MAX_ENTRIES = 100

    /** At or below this the reader is "not zoomed" (the double tap toggles at 1.05) and nothing is stored. */
    const val MIN_SAVED_ZOOM = 1.05f

    /** A remembered place: 0-based [page] and [zoom] (1 = not zoomed). */
    class Place(val page: Int, val zoom: Float = 1f)

    private fun clean(s: String): String = s.map { if (it == '\t' || it == '\n' || it == '\r') ' ' else it }.joinToString("")

    fun key(name: String, length: Long): String = clean(name) + "|" + length

    /** The zoom as it is stored and restored: 1 when not zoomed or not a number, never above [ZoomMath.MAX_ZOOM], two decimals. */
    fun normalizeZoom(zoom: Float): Float {
        if (zoom.isNaN() || zoom <= MIN_SAVED_ZOOM) return 1f
        return Math.round(minOf(zoom, ZoomMath.MAX_ZOOM) * 100f) / 100f
    }

    private fun parse(text: String): LinkedHashMap<String, Place> {
        val map = LinkedHashMap<String, Place>()
        for (line in text.split('\n')) {
            val tab = line.indexOf('\t')
            if (tab <= 0) continue
            val page = line.substring(0, tab).toIntOrNull() ?: continue
            if (page < 0) continue
            val rest = line.substring(tab + 1)
            val tab2 = rest.indexOf('\t')
            val k = if (tab2 < 0) rest else rest.substring(0, tab2)
            if (k.isEmpty()) continue
            val zoom = if (tab2 < 0) 1f else normalizeZoom((rest.substring(tab2 + 1).toIntOrNull() ?: 100) / 100f)
            map.remove(k)
            map[k] = Place(page, zoom)
        }
        return map
    }

    private fun format(map: Map<String, Place>): String = map.entries.joinToString("") {
        val z = normalizeZoom(it.value.zoom)
        it.value.page.toString() + "\t" + it.key + (if (z > 1f) "\t" + Math.round(z * 100f) else "") + "\n"
    }

    fun decode(text: String): LinkedHashMap<String, Int> {
        val map = LinkedHashMap<String, Int>()
        for ((k, v) in parse(text)) map[k] = v.page
        return map
    }

    fun encode(map: Map<String, Int>): String = map.entries.joinToString("") { it.value.toString() + "\t" + it.key + "\n" }

    fun get(text: String, key: String): Int? = parse(text)[clean(key)]?.page

    /** The remembered page and zoom for [key], or null. */
    fun getPlace(text: String, key: String): Place? = parse(text)[clean(key)]

    /** Records [page] (0-based) for [key] as the most recent entry, keeping the zoom already stored for it; the oldest entries beyond [MAX_ENTRIES] are dropped. */
    fun put(text: String, key: String, page: Int): String {
        val map = parse(text)
        val k = clean(key)
        return store(map, k, Place(page.coerceAtLeast(0), map[k]?.zoom ?: 1f))
    }

    /** Records [page] and [zoom] (anything at or below [MIN_SAVED_ZOOM] means "not zoomed": the stored zoom is cleared). */
    fun putPlace(text: String, key: String, page: Int, zoom: Float): String {
        val map = parse(text)
        return store(map, clean(key), Place(page.coerceAtLeast(0), normalizeZoom(zoom)))
    }

    private fun store(map: LinkedHashMap<String, Place>, key: String, place: Place): String {
        map.remove(key)
        map[key] = place
        while (map.size > MAX_ENTRIES) map.remove(map.keys.first())
        return format(map)
    }
}
