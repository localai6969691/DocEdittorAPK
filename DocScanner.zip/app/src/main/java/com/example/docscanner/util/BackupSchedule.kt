package com.example.docscanner.util

import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * The PURE part of the scheduled backup (phiên 20, mục 4.48.5; PDF "Thiếu gì để bán app" mục 6.4): how a backup file is named, which names this module made, and which old ones to delete so that
 * only the newest few remain. Mirrored in `tools/verify/BackupScheduleCheck.java` and checked by `backup_schedule_check.py`. The Android side (JobScheduler, the folder the user picked, the
 * ZIP itself) is in [AutoBackup] and [BackupManager].
 *
 * SAFETY RULE: the folder is the USER's (often a cloud folder with other files in it), so a name is deleted ONLY if it matches `docscanner_auto_yyyyMMdd_HHmmss.zip` with a real date.
 * A manual backup (`docscanner_backup_...`), a photo, or a lookalike with an impossible date is never touched.
 */
object BackupSchedule {

    enum class Interval(val days: Int) { OFF(0), DAILY(1), WEEKLY(7), MONTHLY(30) }

    const val PREFIX = "docscanner_auto_"
    const val SUFFIX = ".zip"
    const val MIN_KEEP = 1
    const val MAX_KEEP = 30
    private const val STAMP = "yyyyMMdd_HHmmss"
    private val NAME = Regex("^docscanner_auto_([0-9]{8}_[0-9]{6})\\.zip$")

    fun periodMillis(interval: Interval): Long = interval.days * 24L * 60L * 60L * 1000L

    /** `docscanner_auto_20261023_143000.zip` for [timeMillis] on the wall clock of [zone] (the user reads these names in their file manager). */
    fun fileName(timeMillis: Long, zone: TimeZone = TimeZone.getDefault()): String {
        val f = SimpleDateFormat(STAMP, Locale.ROOT)
        f.timeZone = zone
        return PREFIX + f.format(Date(timeMillis)) + SUFFIX
    }

    /** True for a name [fileName] could have produced: the pattern AND a real calendar date and time (checked in UTC, where no hour is skipped). */
    fun isOurs(name: String): Boolean {
        val m = NAME.find(name) ?: return false
        val f = SimpleDateFormat(STAMP, Locale.ROOT)
        f.timeZone = TimeZone.getTimeZone("UTC")
        f.isLenient = false
        return try { f.parse(m.groupValues[1]) != null } catch (e: ParseException) { false }
    }

    /**
     * Names to delete so that only the newest [keep] (1..30) backups made by this module are left. Newest = the largest stamp: it has a fixed width and the year comes first, so
     * sorting the NAMES sorts the times (and a change of time zone or summer time cannot reorder them).
     */
    fun toDelete(names: List<String>, keep: Int): List<String> {
        val k = keep.coerceIn(MIN_KEEP, MAX_KEEP)
        return names.filter { isOurs(it) }.distinct().sortedDescending().drop(k)
    }

    /** A little less than a full period counts as due, so a job the system ran a few minutes early is not skipped. */
    private const val GRACE_MILLIS = 6L * 60L * 60L * 1000L

    fun isDue(lastSuccessMillis: Long, nowMillis: Long, interval: Interval): Boolean =
        interval != Interval.OFF && (lastSuccessMillis <= 0L || nowMillis - lastSuccessMillis >= periodMillis(interval) - GRACE_MILLIS)
}
