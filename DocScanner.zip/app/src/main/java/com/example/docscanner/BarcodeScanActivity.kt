package com.example.docscanner

import android.Manifest
import android.app.SearchManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.example.docscanner.databinding.ActivityBarcodeScanBinding
import com.example.docscanner.util.BarcodeContent
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

/**
 * "Quét mã QR / mã vạch" (phiên 17, mục 4.31): live camera scan (ML Kit bundled model, offline) or a picture from the gallery, then the content is
 * UNDERSTOOD ([BarcodeContent]) and the right action is offered: open the link, show / copy the Wi-Fi password, write the e-mail, dial, text, show on a map,
 * add the contact, search the product. Nothing is opened without the person tapping, and a link is shown in FULL first (a QR code can hide a look-alike address).
 *
 * A code must be read TWICE IN A ROW with the same text before it is accepted (one noisy frame can decode to a wrong string); scanning pauses while the result
 * dialog is up and resumes when it is closed. Camera frames are analysed on a single background thread with KEEP_ONLY_LATEST, like [CaptureActivity].
 */
@ExperimentalGetImage
class BarcodeScanActivity : BaseActivity() {

    private lateinit var binding: ActivityBarcodeScanBinding
    private val executor = Executors.newSingleThreadExecutor()
    private val scanner by lazy {
        BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS).build())
    }

    @Volatile private var paused = false
    private var lastRaw: String? = null
    private var agreeCount = 0

    private val requestPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else finish()
    }
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) scanPicture(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBarcodeScanBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.btnBarcodeClose.setOnClickListener { finish() }
        binding.btnBarcodeGallery.setOnClickListener { pickImage.launch("image/*") }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else requestPermission.launch(Manifest.permission.CAMERA)
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { scanner.close() }
        executor.shutdown()
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(binding.barcodePreview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { it.setAnalyzer(executor) { proxy -> analyse(proxy) } }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) {
                Log.e("BarcodeScan", "Camera bind failed", e)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyse(proxy: ImageProxy) {
        val media = proxy.image
        if (media == null || paused) {
            proxy.close()
            return
        }
        val image = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
        scanner.process(image)
            .addOnSuccessListener { list ->
                val code = list.firstOrNull { !it.rawValue.isNullOrEmpty() }
                if (code != null) onFrameCode(code.rawValue!!, code.format)
            }
            .addOnCompleteListener { proxy.close() }
    }

    /** Accepts a code only when two consecutive frames agree. */
    private fun onFrameCode(raw: String, format: Int) {
        if (paused) return
        if (raw == lastRaw) agreeCount++ else { lastRaw = raw; agreeCount = 1 }
        if (agreeCount >= 2) {
            paused = true
            runOnUiThread { if (!isFinishing) showResult(raw, format) }
        }
    }

    private fun scanPicture(uri: Uri) {
        val image = try { InputImage.fromFilePath(this, uri) } catch (e: Exception) {
            Toast.makeText(this, R.string.barcode_image_failed, Toast.LENGTH_LONG).show()
            return
        }
        paused = true
        scanner.process(image)
            .addOnSuccessListener { list ->
                val code = list.firstOrNull { !it.rawValue.isNullOrEmpty() }
                if (code == null) {
                    paused = false
                    Toast.makeText(this, R.string.barcode_none_in_image, Toast.LENGTH_LONG).show()
                } else showResult(code.rawValue!!, code.format)
            }
            .addOnFailureListener {
                paused = false
                Toast.makeText(this, R.string.barcode_image_failed, Toast.LENGTH_LONG).show()
            }
    }

    private fun isProductFormat(format: Int) = format == Barcode.FORMAT_EAN_13 || format == Barcode.FORMAT_EAN_8 ||
        format == Barcode.FORMAT_UPC_A || format == Barcode.FORMAT_UPC_E

    private fun copy(text: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("code", text))
        Toast.makeText(this, R.string.barcode_copied, Toast.LENGTH_SHORT).show()
    }

    private fun launch(intent: Intent) {
        try { startActivity(intent) } catch (e: Exception) { Toast.makeText(this, R.string.barcode_no_app, Toast.LENGTH_LONG).show() }
    }

    private fun showResult(raw: String, format: Int) {
        val parsed = BarcodeContent.parse(raw, isProductFormat(format))
        val f = parsed.fields
        val title: Int
        val text: String
        var actionLabel: Int? = null
        var action: (() -> Unit)? = null
        when (parsed.kind) {
            BarcodeContent.Kind.URL -> {
                title = R.string.barcode_kind_url; text = f["url"] ?: raw
                actionLabel = R.string.barcode_open
                action = { launch(Intent(Intent.ACTION_VIEW, Uri.parse(f["url"] ?: raw))) }
            }
            BarcodeContent.Kind.WIFI -> {
                title = R.string.barcode_kind_wifi
                text = getString(R.string.barcode_wifi_text, f["ssid"], f["security"], f["password"].orEmpty().ifEmpty { "-" })
                actionLabel = R.string.barcode_wifi_settings
                action = { launch(Intent(Settings.ACTION_WIFI_SETTINGS)) }
            }
            BarcodeContent.Kind.EMAIL -> {
                title = R.string.barcode_kind_email
                text = getString(R.string.barcode_email_text, f["address"], f["subject"], f["body"])
                actionLabel = R.string.barcode_write_email
                action = {
                    launch(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
                        putExtra(Intent.EXTRA_EMAIL, arrayOf(f["address"].orEmpty()))
                        putExtra(Intent.EXTRA_SUBJECT, f["subject"].orEmpty())
                        putExtra(Intent.EXTRA_TEXT, f["body"].orEmpty())
                    })
                }
            }
            BarcodeContent.Kind.PHONE -> {
                title = R.string.barcode_kind_phone; text = f["number"].orEmpty()
                actionLabel = R.string.barcode_dial
                action = { launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(f["number"].orEmpty())))) }
            }
            BarcodeContent.Kind.SMS -> {
                title = R.string.barcode_kind_sms
                text = getString(R.string.barcode_sms_text, f["number"], f["body"])
                actionLabel = R.string.barcode_write_sms
                action = {
                    launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(f["number"].orEmpty()))).apply { putExtra("sms_body", f["body"].orEmpty()) })
                }
            }
            BarcodeContent.Kind.GEO -> {
                title = R.string.barcode_kind_geo; text = "${f["lat"]}, ${f["lon"]}"
                actionLabel = R.string.barcode_show_map
                action = { launch(Intent(Intent.ACTION_VIEW, Uri.parse("geo:${f["lat"]},${f["lon"]}?q=${f["lat"]},${f["lon"]}"))) }
            }
            BarcodeContent.Kind.CONTACT -> {
                title = R.string.barcode_kind_contact
                text = getString(R.string.barcode_contact_text, f["name"], f["phone"], f["email"], f["org"])
                actionLabel = R.string.barcode_add_contact
                action = {
                    launch(Intent(ContactsContract.Intents.Insert.ACTION).apply {
                        type = ContactsContract.RawContacts.CONTENT_TYPE
                        putExtra(ContactsContract.Intents.Insert.NAME, f["name"].orEmpty())
                        putExtra(ContactsContract.Intents.Insert.PHONE, f["phone"].orEmpty())
                        putExtra(ContactsContract.Intents.Insert.EMAIL, f["email"].orEmpty())
                        putExtra(ContactsContract.Intents.Insert.COMPANY, f["org"].orEmpty())
                    })
                }
            }
            BarcodeContent.Kind.EVENT -> { title = R.string.barcode_kind_event; text = raw }
            BarcodeContent.Kind.PRODUCT -> {
                title = if (f["isbn"].orEmpty().isNotEmpty()) R.string.barcode_kind_isbn else R.string.barcode_kind_product
                text = f["code"].orEmpty()
                actionLabel = R.string.barcode_search_web
                action = { launch(Intent(Intent.ACTION_WEB_SEARCH).apply { putExtra(SearchManager.QUERY, f["code"].orEmpty()) }) }
            }
            BarcodeContent.Kind.TEXT -> { title = R.string.barcode_kind_text; text = raw }
        }
        val builder = AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(text)
            .setNeutralButton(R.string.barcode_copy) { _, _ -> copy(if (parsed.kind == BarcodeContent.Kind.WIFI) f["password"].orEmpty().ifEmpty { raw } else text) }
            .setNegativeButton(R.string.barcode_scan_again, null)
            .setOnDismissListener { lastRaw = null; agreeCount = 0; paused = false }
        val label = actionLabel
        val run = action
        if (label != null && run != null) builder.setPositiveButton(label) { _, _ -> run() }
        builder.show()
    }
}
