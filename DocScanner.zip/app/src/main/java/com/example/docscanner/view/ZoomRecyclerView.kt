package com.example.docscanner.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Matrix
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.util.ZoomMath

/**
 * A vertical list that can be pinched larger, dragged sideways when larger, and double-tapped between 1x and 2x (the PDF reader's pages, session 23, 4.59 and 4.61).
 * The arithmetic lives in [ZoomMath] (proved by tools/verify/reader_logic_check.py); this class only wires it to touches and drawing:
 *  - the children are drawn scaled about the top-left corner and moved sideways by [offsetX];
 *  - while larger, EVERY touch is converted to the list's own unscaled coordinates BEFORE it is dispatched ([dispatchTouchEvent]), so the list scrolls by the distance the
 *    finger moved on screen AND a page under the finger (the reader's editing tools draw frames on it) receives the point it really shows;
 *  - two fingers moving together drag the page sideways; one finger does so only while [oneFingerPan] is on (the reader turns it off while an editing tool is active,
 *    because then one finger draws);
 *  - extra bottom padding keeps the end of the document reachable ([ZoomMath.extraBottomPadding]);
 *  - [onZoomSettled] fires when a pinch or a double tap ends, so the reader can draw the pages sharper while zoomed.
 */
class ZoomRecyclerView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : RecyclerView(context, attrs) {

    var zoom = 1f
        private set
    private var offsetX = 0f
    private var basePaddingBottom = -1
    private var pinching = false
    private var lastFocusX = 0f

    /** One finger drags the zoomed page sideways and a double tap zooms. Off while an editing tool uses one finger to draw. */
    var oneFingerPan = true

    /** Called with the new zoom when a pinch or double tap has finished. */
    var onZoomSettled: ((Float) -> Unit)? = null

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
            lastFocusX = detector.focusX
            return true
        }

        override fun onScale(detector: ScaleGestureDetector): Boolean {
            zoomTo(zoom * detector.scaleFactor, detector.focusX, detector.focusY)
            // the two fingers moving together drag the page sideways
            if (zoom > 1f) offsetX = ZoomMath.clampX(offsetX + (detector.focusX - lastFocusX), width.toFloat(), zoom)
            lastFocusX = detector.focusX
            invalidate()
            return true
        }

        override fun onScaleEnd(detector: ScaleGestureDetector) {
            onZoomSettled?.invoke(zoom)
        }
    })

    private val gestures = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (!oneFingerPan) return false
            zoomTo(if (zoom > 1.05f) 1f else DOUBLE_TAP_ZOOM, e.x, e.y)
            onZoomSettled?.invoke(zoom)
            return true
        }

        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
            if (oneFingerPan && zoom > 1f && !scaleDetector.isInProgress) {
                offsetX = ZoomMath.clampX(offsetX - distanceX, width.toFloat(), zoom)
                invalidate()
            }
            return false
        }
    })

    private fun zoomTo(target: Float, fx: Float, fy: Float) {
        val next = ZoomMath.zoomTo(zoom, offsetX, width.toFloat(), target, fx, fy)
        if (next.scale == zoom) return
        zoom = next.scale
        offsetX = next.offsetX
        updateBottomPadding()
        scrollBy(0, next.scrollDy)
        invalidate()
    }

    private fun updateBottomPadding() {
        if (basePaddingBottom < 0) basePaddingBottom = paddingBottom
        setPadding(paddingLeft, paddingTop, paddingRight, basePaddingBottom + ZoomMath.extraBottomPadding(height.toFloat(), zoom))
    }

    /** Back to 1x (also called when the view changes size, e.g. on rotation). */
    fun resetZoom() {
        zoom = 1f
        offsetX = 0f
        if (basePaddingBottom >= 0) setPadding(paddingLeft, paddingTop, paddingRight, basePaddingBottom)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (oldw != 0 && (w != oldw || h != oldh)) resetZoom()
    }

    /**
     * The gesture detectors see the touch as it is on screen; everything below them (the list and the page under the finger) gets it converted to unscaled coordinates.
     * A pinch cancels what the children had started (a frame being drawn, a one-finger scroll) and keeps them out of the pinch until every finger is up.
     */
    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(e)
        gestures.onTouchEvent(e)
        if (scaleDetector.isInProgress) {
            if (!pinching) {
                pinching = true
                val cancel = MotionEvent.obtain(e)
                cancel.action = MotionEvent.ACTION_CANCEL
                super.dispatchTouchEvent(cancel)
                cancel.recycle()
            }
            return true
        }
        if (pinching) {
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) pinching = false
            return true
        }
        if (zoom == 1f) return super.dispatchTouchEvent(e)
        val matrix = Matrix()
        matrix.postTranslate(-offsetX, 0f)
        matrix.postScale(1f / zoom, 1f / zoom)
        val converted = MotionEvent.obtain(e)
        converted.transform(matrix)
        val handled = super.dispatchTouchEvent(converted)
        converted.recycle()
        return handled
    }

    override fun dispatchDraw(canvas: Canvas) {
        if (zoom == 1f) {
            super.dispatchDraw(canvas)
            return
        }
        canvas.save()
        canvas.translate(offsetX, 0f)
        canvas.scale(zoom, zoom)
        super.dispatchDraw(canvas)
        canvas.restore()
    }

    companion object {
        private const val DOUBLE_TAP_ZOOM = 2f
    }
}
