package com.example.docscanner.util

/**
 * Pulls the fields people copy by hand out of a Vietnamese invoice (hoá đơn): date, invoice number and serial, tax codes (MST), the amount
 * to pay, VAT rate and VAT amount. The text is the page text of the document (text layer, or OCR of a scan).
 *
 * Every field is found NEXT TO ITS LABEL ("Mã số thuế", "Số hóa đơn", "Tổng cộng thanh toán"...), never by the look of a number alone: a
 * bare 10-digit number could be a tax code, a phone number or an amount. Labels are matched on the accent-free, lower-case text
 * ([PiiDetector.fold], same length, so offsets are valid in the original), so "TỔNG CỘNG", "Tong cong" and "tổng cộng" are the same.
 * A tax code appears twice on most invoices (seller, then buyer): every one is returned, in the order of the page.
 *
 * Helper, not an authority: a misread digit in OCR gives a wrong value, which is why the screen shows the result for the user to check.
 * Pure Kotlin; `tools/verify/ExtractCheck.java` is a line-by-line Java copy run by `extract_check.py` on invoices built from known values.
 */
object InvoiceFields {

    enum class Kind { DATE, INVOICE_NO, SERIAL, TAX_ID, TOTAL, VAT_RATE, VAT_AMOUNT }

    /** [value]: tax code and invoice number as printed (digits, a tax code may keep its "-001"); date as `YYYY-MM-DD`; amounts as plain digits (`1234567` or `1234567.5`); rate as a number. */
    class Field(val kind: Kind, val value: String)

    private val TAX = Regex("""(?:ma so thue|mst|tax code|tax id)[^0-9\n]{0,25}(\d{10}(?:-\d{3})?|\d{13})(?!\d)""")
    private val INVOICE_NO = Regex("""(?:so hoa don|so hd|invoice no\.?|invoice number|so \(no\.?\))[^0-9\n]{0,25}(\d{1,10})(?!\d)""")
    private val SERIAL = Regex("""(?:ky hieu(?: hoa don)?|serial)(?:\s*\([^)\n]{0,20}\))?[^a-z0-9\n]{0,25}([0-9][a-z][0-9]{2}[a-z]{2,4}|[a-z]{2}/[0-9]{2}[a-z])""")
    private val DATE_WORDS = Regex("""ngay\s*(\d{1,2})\s*thang\s*(\d{1,2})\s*nam\s*(\d{4})""")
    private val DATE_SLASH = Regex("""(?<!\d)(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})(?!\d)""")
    private val DATE_ISO = Regex("""(?<!\d)(\d{4})-(\d{2})-(\d{2})(?!\d)""")
    private val VAT_RATE = Regex("""(?:thue suat|vat rate|thue gtgt|vat)[^0-9\n]{0,15}(\d{1,2})\s?%""")
    private val PERCENT = Regex("""\d+(?:[.,]\d+)?\s?%""")
    private val NUMBER = Regex("""\d{1,3}(?:[.,]\d{3})+(?:[.,]\d{1,2})?|\d+(?:[.,]\d{1,2})?""")

    // payment total, strongest label first; "tong cong" alone may be the total BEFORE tax, so it comes last
    private val TOTAL_LABELS = listOf(
        listOf("tong cong tien thanh toan", "tong tien thanh toan", "tong cong thanh toan", "tong thanh toan", "tien thanh toan", "total amount", "grand total", "amount due"),
        listOf("tong cong")
    )
    private val VAT_AMOUNT_LABELS = listOf("tien thue gtgt", "tien thue", "thue gtgt", "vat amount")

    fun extract(text: String): List<Field> {
        val low = PiiDetector.foldLower(text)
        val out = ArrayList<Field>()
        date(low)?.let { out.add(Field(Kind.DATE, it)) }
        INVOICE_NO.find(low)?.let { out.add(Field(Kind.INVOICE_NO, text.substring(it.groups[1]!!.range.first, it.groups[1]!!.range.last + 1))) }
        SERIAL.find(low)?.let { out.add(Field(Kind.SERIAL, text.substring(it.groups[1]!!.range.first, it.groups[1]!!.range.last + 1))) }
        for (m in TAX.findAll(low)) out.add(Field(Kind.TAX_ID, text.substring(m.groups[1]!!.range.first, m.groups[1]!!.range.last + 1)))
        val lines = lineRanges(low)
        for (labels in TOTAL_LABELS) {
            val found = amountAfterLabel(low, lines, labels, minValue = 0.0)
            if (found != null) { out.add(Field(Kind.TOTAL, found)); break }
        }
        VAT_RATE.find(low)?.let { out.add(Field(Kind.VAT_RATE, it.groups[1]!!.value)) }
        amountAfterLabel(low, lines, VAT_AMOUNT_LABELS, minValue = 1000.0)?.let { out.add(Field(Kind.VAT_AMOUNT, it)) }
        return out
    }

    /**
     * `YYYY-MM-DD` of the FIRST valid date in the text, whichever way it is written ("Ngày 05 tháng 10 năm 2026", 05/10/2026, 2026-10-05): the invoice
     * date is near the top, while a due date or a payment date comes later - choosing by format instead of by position let a "Hạn thanh toán: 15/01/2027"
     * beat an ISO invoice date above it. Impossible dates (31/02) are skipped.
     */
    private fun date(low: String): String? {
        val found = ArrayList<Pair<Int, String>>()
        DATE_WORDS.findAll(low).forEach { m -> iso(m.groupValues[3], m.groupValues[2], m.groupValues[1])?.let { found.add(m.range.first to it) } }
        DATE_SLASH.findAll(low).forEach { m -> iso(m.groupValues[3], m.groupValues[2], m.groupValues[1])?.let { found.add(m.range.first to it) } }
        DATE_ISO.findAll(low).forEach { m -> iso(m.groupValues[1], m.groupValues[2], m.groupValues[3])?.let { found.add(m.range.first to it) } }
        return found.minByOrNull { it.first }?.second
    }

    private fun iso(year: String, month: String, day: String): String? {
        val y = year.toInt()
        val m = month.toInt()
        val d = day.toInt()
        if (y < 1990 || y > 2100 || m < 1 || m > 12 || d < 1) return null
        val days = intArrayOf(31, if (y % 4 == 0 && (y % 100 != 0 || y % 400 == 0)) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        if (d > days[m - 1]) return null
        return String.format(java.util.Locale.ROOT, "%04d-%02d-%02d", y, m, d)
    }

    /** [start, end) of each line of [low]. */
    private fun lineRanges(low: String): List<IntRange> {
        val out = ArrayList<IntRange>()
        var start = 0
        for (i in 0..low.length) {
            if (i == low.length || low[i] == '\n') {
                out.add(start until i)
                start = i + 1
            }
        }
        return out
    }

    /**
     * The amount on the first line that carries one of [labels]: the LAST number after the label (the amount column is on the right), at
     * least [minValue]. A label line with no number takes the first number of the next line (a layout that puts the value underneath).
     */
    private fun amountAfterLabel(low: String, lines: List<IntRange>, labels: List<String>, minValue: Double): String? {
        for ((i, range) in lines.withIndex()) {
            val line = low.substring(range.first, range.last + 1)
            val at = labels.map { line.indexOf(it) }.filter { it >= 0 }.minOrNull() ?: continue
            val label = labels.first { line.indexOf(it) == at }
            // a number followed by % is a rate, never the amount ("Tổng cộng (đã gồm VAT 10%):" has the amount on the next line)
            var numbers = NUMBER.findAll(PERCENT.replace(line.substring(at + label.length), " ")).map { it.value }.toList()
            if (numbers.isEmpty() && i + 1 < lines.size) {
                val next = low.substring(lines[i + 1].first, lines[i + 1].last + 1)
                numbers = NUMBER.findAll(next).map { it.value }.take(1).toList()
            }
            for (candidate in numbers.reversed()) {
                val normal = normalizeAmount(candidate) ?: continue
                if (normal.toDouble() >= minValue) return normal
            }
        }
        return null
    }

    /**
     * Plain digits of an amount written with Vietnamese or English separators: `1.234.567` / `1,234,567` -> `1234567`; `1.234.567,50` / `1,234,567.50` ->
     * `1234567.5`; `1.234` -> `1234` (a single separator followed by exactly three digits is a thousands separator); `12,5` -> `12.5`. Null when it is not an amount.
     */
    fun normalizeAmount(token: String): String? {
        val t = token.trim()
        if (!Regex("""\d{1,3}([.,]\d{3})+([.,]\d{1,2})?|\d+([.,]\d{1,2})?""").matches(t)) return null
        val dots = t.count { it == '.' }
        val commas = t.count { it == ',' }
        val intPart: String
        var frac = ""
        if (dots > 0 && commas > 0) {
            val last = maxOf(t.lastIndexOf('.'), t.lastIndexOf(','))
            intPart = t.substring(0, last).filter { it.isDigit() }
            frac = t.substring(last + 1)
        } else if (dots + commas > 1) {
            val sep = if (dots > 0) '.' else ','
            val last = t.lastIndexOf(sep)
            val tail = t.substring(last + 1)
            if (tail.length <= 2) {
                intPart = t.substring(0, last).filter { it.isDigit() }
                frac = tail
            } else {
                intPart = t.filter { it.isDigit() }
            }
        } else if (dots + commas == 1) {
            val last = maxOf(t.lastIndexOf('.'), t.lastIndexOf(','))
            val before = t.substring(0, last)
            val after = t.substring(last + 1)
            if (after.length == 3 && before.length <= 3) {
                intPart = before + after
            } else {
                intPart = before
                frac = after
            }
        } else {
            intPart = t
        }
        val whole = intPart.trimStart('0').ifEmpty { "0" }
        val fraction = frac.trimEnd('0')
        return if (fraction.isEmpty()) whole else "$whole.$fraction"
    }
}
