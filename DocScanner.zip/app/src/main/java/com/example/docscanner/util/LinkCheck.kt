package com.example.docscanner.util

import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.interactive.action.PDActionGoTo
import com.tom_roush.pdfbox.pdmodel.interactive.action.PDActionURI
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationLink
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDNamedDestination
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDPageDestination
import java.io.File
import java.net.HttpURLConnection
import java.net.IDN
import java.net.SocketTimeoutException
import java.net.URI
import java.net.URL

/**
 * "Do the links of this PDF still work?" (PDF "Thieu gi de ban app" 11.9; phiên 24, TECHNICAL_DOCS.md 4.68). Two levels:
 *  1. OFFLINE, instant, private ([scan]): every link annotation of the document with where it points - a web address (is it well formed?), an e-mail or phone number, a page of the document
 *     (does that page still exist? the usual breakage after deleting or merging pages), a named destination (is it still defined?), or nothing at all;
 *  2. ONLINE, only when the person asks and after being told what is sent ([probe]): one HEAD request per distinct web address (GET if the server refuses HEAD). Nothing of the document is
 *     sent, only the address. Addresses on the local network (localhost, 10.x, 192.168.x, *.local, a name without a dot) are NEVER probed: a PDF must not be able to make the phone knock on
 *     the router or a printer, and the app does not ask for the local-network permission ([isPublicHost]).
 * Classification and the address rules are pure and tested; the PdfBox walk and the HTTP probe are run for real by `tools/verify/link_check_check.py` (PdfBox built from source, a local
 * HTTP server answering 200 / 301 / 404 / 405 / 500 / hanging).
 */
object LinkCheck {

    enum class Kind { WEB, MAIL, PHONE, PAGE, NAMED, OTHER }

    enum class Problem { NONE, BAD_ADDRESS, PAGE_MISSING, NAMED_MISSING, NO_TARGET }

    /** [page] is 0-based (the page the link is ON); [target] is what it points to as text (address, "page 3", the destination name). */
    class Link(val page: Int, val kind: Kind, val target: String, val problem: Problem)

    private val MAIL = Regex("^[^@\\s,;<>]+@[^@\\s,;<>]+\\.[^@\\s,;<>]{2,}$")
    private val PHONE = Regex("^\\+?[0-9(][0-9 .()\\-]*$")

    /** What an address is and whether it is well formed. Anything that is not http(s), mailto or tel (a file, an app link, JavaScript) is [Kind.OTHER] and not judged. */
    fun classifyUri(uri: String): Pair<Kind, Problem> {
        val u = uri.trim()
        val lower = u.lowercase()
        return when {
            lower.startsWith("http://") || lower.startsWith("https://") -> Pair(Kind.WEB, if (wellFormedWeb(u)) Problem.NONE else Problem.BAD_ADDRESS)
            lower.startsWith("mailto:") -> Pair(Kind.MAIL, if (MAIL.matches(u.substring(7).substringBefore('?'))) Problem.NONE else Problem.BAD_ADDRESS)
            lower.startsWith("tel:") -> Pair(Kind.PHONE, if (wellFormedPhone(u.substring(4))) Problem.NONE else Problem.BAD_ADDRESS)
            else -> Pair(Kind.OTHER, Problem.NONE)
        }
    }

    /** Digits, spaces, `.`, `-` and brackets, an optional leading `+`, at least five digits ("(028) 3822-1234" and "+84 90 123 4567" are fine, "abc" and "12" are not). */
    private fun wellFormedPhone(number: String): Boolean = PHONE.matches(number) && number.count { it.isDigit() } >= 5

    /**
     * The host part is converted to its ASCII form first (`java.net.IDN`), because `java.net.URI` rejects an internationalised domain name such as `tiếng-việt.vn` as having no host: that is a
     * valid address (found by the first real run, 4.68), not a broken link. Spaces and other illegal characters are still refused by [URI].
     */
    private fun wellFormedWeb(u: String): Boolean {
        return try {
            val parts = Regex("^(?i)(https?://)([^/?#]*)(.*)$").matchEntire(u) ?: return false
            val authority = parts.groupValues[2]
            val at = authority.lastIndexOf('@')
            val userInfo = authority.substring(0, at + 1)
            val hostPort = authority.substring(at + 1)
            val colon = if (hostPort.startsWith("[")) hostPort.indexOf("]:").let { if (it >= 0) it + 1 else -1 } else hostPort.lastIndexOf(':')
            val host = if (colon >= 0) hostPort.substring(0, colon) else hostPort
            val port = if (colon >= 0) hostPort.substring(colon) else ""
            val asciiHost = if (host.startsWith("[")) host else IDN.toASCII(host, IDN.ALLOW_UNASSIGNED)
            val parsed = URI(parts.groupValues[1] + userInfo + asciiHost + port + parts.groupValues[3])      // refuses spaces and illegal characters
            val h = parsed.host
            !h.isNullOrBlank() && !h.startsWith(".") && !h.endsWith(".") && !h.contains("..")
        } catch (e: Exception) {
            false
        }
    }

    /** False for hosts that mean "this device or the local network" - never probed. A host name without a dot, `localhost`, `*.local`, `*.lan`, `*.internal`, and literal private / loopback / link-local IPv4 and IPv6. */
    fun isPublicHost(host: String?): Boolean {
        if (host.isNullOrBlank()) return false
        val h = host.lowercase().trim('[', ']')
        if (h == "localhost" || h.endsWith(".local") || h.endsWith(".lan") || h.endsWith(".internal") || h.endsWith(".localdomain") || h.endsWith(".home.arpa")) return false
        val ipv4 = Regex("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$").matchEntire(h)
        if (ipv4 != null) {
            val p = ipv4.groupValues.drop(1).map { it.toInt() }
            if (p.any { it > 255 }) return false
            return !(p[0] == 10 || p[0] == 127 || p[0] == 0 || (p[0] == 169 && p[1] == 254) || (p[0] == 172 && p[1] in 16..31) || (p[0] == 192 && p[1] == 168) || (p[0] == 100 && p[1] in 64..127) || p[0] >= 224)
        }
        if (h.contains(':')) {      // a literal IPv6 address: loopback, unspecified, unique-local (fc00::/7), link-local (fe80::/10), multicast, IPv4-mapped
            return !(h == "::1" || h == "::" || h.startsWith("fc") || h.startsWith("fd") || h.startsWith("fe8") || h.startsWith("fe9") || h.startsWith("fea") || h.startsWith("feb") || h.startsWith("ff") || h.startsWith("::ffff:"))
        }
        return h.contains('.')
    }

    /** Every link annotation of the document, or null for an encrypted or unreadable file. */
    fun scan(file: File): List<Link>? {
        return try {
            PDDocument.load(file).use { doc ->
                if (doc.isEncrypted) return null
                val pages = doc.numberOfPages
                val out = ArrayList<Link>()
                for (i in 0 until pages) {
                    for (annotation in doc.getPage(i).annotations) {
                        if (annotation !is PDAnnotationLink) continue
                        val action = annotation.action
                        if (action is PDActionURI) {
                            val uri = action.uri ?: ""
                            val (kind, problem) = classifyUri(uri)
                            out.add(Link(i, kind, uri, if (uri.isBlank()) Problem.NO_TARGET else problem))
                            continue
                        }
                        val destination = if (action is PDActionGoTo) action.destination else if (action == null) annotation.destination else null
                        if (destination == null) {
                            out.add(Link(i, Kind.OTHER, "", if (action == null) Problem.NO_TARGET else Problem.NONE))
                        } else if (destination is PDNamedDestination) {
                            val name = destination.namedDestination ?: ""
                            val found = doc.documentCatalog.findNamedDestinationPage(destination)
                            out.add(Link(i, Kind.NAMED, name, if (found != null && found.retrievePageNumber() in 0 until pages) Problem.NONE else Problem.NAMED_MISSING))
                        } else if (destination is PDPageDestination) {
                            val n = destination.retrievePageNumber()
                            out.add(Link(i, Kind.PAGE, "page " + (n + 1), if (n in 0 until pages) Problem.NONE else Problem.PAGE_MISSING))
                        } else {
                            out.add(Link(i, Kind.OTHER, "", Problem.NONE))
                        }
                    }
                }
                out
            }
        } catch (e: Exception) {
            null
        }
    }

    enum class Status { OK, NOT_FOUND, HTTP_ERROR, TIMEOUT, UNREACHABLE, SKIPPED_LOCAL }

    class Probe(val status: Status, val code: Int)

    /** The status of the HTTP response (redirects followed) -> [Status]; 2xx and 3xx are fine, 404 / 410 are gone, other codes are an error of the server. */
    fun statusOfCode(code: Int): Status = when {
        code in 200..399 -> Status.OK
        code == 404 || code == 410 -> Status.NOT_FOUND
        else -> Status.HTTP_ERROR
    }

    /**
     * One HEAD request (GET when the server answers 403 / 405 / 501 to HEAD - many do), redirects followed, [timeoutMs] to connect and to read. [allowLocal] is for tests only: the app never
     * sets it. Never reads the body.
     */
    fun probe(url: String, timeoutMs: Int = 6000, allowLocal: Boolean = false): Probe {
        val host = try { URI(url.trim()).host } catch (e: Exception) { null }
        if (!allowLocal && !isPublicHost(host)) return Probe(Status.SKIPPED_LOCAL, 0)
        return try {
            var code = request(url.trim(), "HEAD", timeoutMs)
            if (code == 403 || code == 405 || code == 501) code = request(url.trim(), "GET", timeoutMs)
            Probe(statusOfCode(code), code)
        } catch (e: SocketTimeoutException) {
            Probe(Status.TIMEOUT, 0)
        } catch (e: Exception) {
            Probe(Status.UNREACHABLE, 0)
        }
    }

    private fun request(url: String, method: String, timeoutMs: Int): Int {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.connectTimeout = timeoutMs
            connection.readTimeout = timeoutMs
            connection.instanceFollowRedirects = true
            connection.requestMethod = method
            connection.setRequestProperty("User-Agent", "DocScanner link check")
            return connection.responseCode
        } finally {
            connection.disconnect()
        }
    }
}
