package com.example.docscanner.util

import java.text.Normalizer

/**
 * Finds personal data that is typical of Vietnamese paperwork in a line of text, so the redaction screen can offer to black it out:
 * citizen ID (CCCD, 12 digits starting with 0 and a province code 001-096; CMND, 9 digits), mobile and landline phone numbers
 * (0x / 84x / +84x, with spaces, dots or dashes), e-mail addresses, bank cards (13-19 digits that pass the Luhn check), and - ONLY next to
 * the words that say what they are - tax codes (MST) and bank account numbers (STK). A bare 9 or 10 digit number is NOT reported:
 * it could be an amount, a page, a reference; wrongly blacking out an amount is as bad as missing a CMND.
 *
 * Pure Kotlin (java.util.regex underneath, the same engine as the JVM copy `tools/verify/PiiCheck.java`), so it is tested against
 * text built from known values AND from decoys (amounts, dates, 16-digit numbers that fail Luhn...). It is a helper, not a guarantee:
 * the screen says so and the user reviews every page before saving.
 */
object PiiDetector {

    enum class Kind { CITIZEN_ID, PHONE, EMAIL, CARD, TAX_ID, ACCOUNT }

    /** [start, end) offsets into the text that was searched. */
    class Match(val start: Int, val end: Int, val kind: Kind)

    private class Candidate(val start: Int, val end: Int, val kind: Kind, val priority: Int)

    private val EMAIL = Regex("""[A-Za-z0-9._%+\-]+@[A-Za-z0-9\-]+(?:\.[A-Za-z0-9\-]+)*\.[A-Za-z]{2,}""")

    // 4-digit groups (12-16 digits) plus an optional short last group (up to 19). Requiring GROUPS of four keeps a page number or a
    // short number in front of a phone number from being swallowed into one "card".
    private val CARD = Regex("""(?<!\d)\d{4}(?:[ \-]?\d{4}){2,3}(?:[ \-]?\d{1,3})?(?!\d)""")

    // 0 + province code 001..096 + 9 digits
    private val CITIZEN = Regex("""(?<!\d)0(?:0[1-9]|[1-8]\d|9[0-6])\d{9}(?!\d)""")

    private val PHONE_MOBILE = Regex("""(?<![\d+])(?:\+84|84|0)[ .\-]?[35789](?:[ .\-]?\d){8}(?!\d)""")
    private val PHONE_LANDLINE = Regex("""(?<![\d+])0[ .\-]?2(?:[ .\-]?\d){9}(?!\d)""")

    // The three below run on the text with accents removed (see [fold]) so "Số CMND", "Mã số thuế", "Số tài khoản" are plain ASCII.
    private val CITIZEN_CONTEXT = Regex("""(?i)(?:cmnd|cmt|cccd|can cuoc|chung minh)[^\d\n]{0,25}(\d{12}|\d{9})(?!\d)""")
    private val TAX_CONTEXT = Regex("""(?i)(?:mst|ma so thue|tax ?id|tax ?code)[^\d\n]{0,20}(\d{10}(?:-\d{3})?|\d{13})(?!\d)""")
    private val ACCOUNT_CONTEXT = Regex("""(?i)(?:stk|so tai khoan|tai khoan|account(?: ?(?:no|number))?)[^\d\n]{0,20}(\d{6,19})(?!\d)""")

    /**
     * Every match of the wanted [kinds] in [text], sorted by position and never overlapping: where two rules claim the same characters
     * the more specific one wins (e-mail, then a number introduced by its label - so a labelled 13-digit account number that happens to pass Luhn stays an ACCOUNT, not a CARD - then a card, then a bare citizen ID, then a phone).
     */
    fun find(text: String, kinds: Set<Kind> = Kind.values().toSet()): List<Match> {
        val folded = fold(text)
        val found = ArrayList<Candidate>()
        if (Kind.EMAIL in kinds) {
            EMAIL.findAll(text).forEach { found.add(Candidate(it.range.first, it.range.last + 1, Kind.EMAIL, 1)) }
        }
        if (Kind.CARD in kinds) {
            CARD.findAll(text).forEach { m ->
                val digits = m.value.filter { it in '0'..'9' }
                if (digits.length in 13..19 && luhn(digits)) found.add(Candidate(m.range.first, m.range.last + 1, Kind.CARD, 3))
            }
        }
        if (Kind.CITIZEN_ID in kinds) {
            CITIZEN_CONTEXT.findAll(folded).forEach { m -> m.groups[1]?.let { found.add(Candidate(it.range.first, it.range.last + 1, Kind.CITIZEN_ID, 2)) } }
            CITIZEN.findAll(text).forEach { found.add(Candidate(it.range.first, it.range.last + 1, Kind.CITIZEN_ID, 4)) }
        }
        if (Kind.TAX_ID in kinds) {
            TAX_CONTEXT.findAll(folded).forEach { m -> m.groups[1]?.let { found.add(Candidate(it.range.first, it.range.last + 1, Kind.TAX_ID, 2)) } }
        }
        if (Kind.ACCOUNT in kinds) {
            ACCOUNT_CONTEXT.findAll(folded).forEach { m -> m.groups[1]?.let { found.add(Candidate(it.range.first, it.range.last + 1, Kind.ACCOUNT, 2)) } }
        }
        if (Kind.PHONE in kinds) {
            PHONE_MOBILE.findAll(text).forEach { found.add(Candidate(it.range.first, it.range.last + 1, Kind.PHONE, 5)) }
            PHONE_LANDLINE.findAll(text).forEach { found.add(Candidate(it.range.first, it.range.last + 1, Kind.PHONE, 5)) }
        }
        val accepted = ArrayList<Candidate>()
        for (c in found.sortedWith(compareBy<Candidate>({ it.priority }, { it.start }, { -(it.end - it.start) }))) {
            if (accepted.none { c.start < it.end && it.start < c.end }) accepted.add(c)
        }
        return accepted.sortedBy { it.start }.map { Match(it.start, it.end, it.kind) }
    }

    /**
     * [text] with every character replaced by its base letter, one for one (the SAME length, so offsets found in it are valid in the
     * original): "Số CMND" -> "So CMND", "đ" -> "d". Marks that are separate characters are left alone.
     */
    fun fold(text: String): String {
        val sb = StringBuilder(text.length)
        for (c in text) {
            sb.append(
                when (c) {
                    'đ' -> 'd'
                    'Đ' -> 'D'
                    else -> Normalizer.normalize(c.toString(), Normalizer.Form.NFD)[0]
                }
            )
        }
        return sb.toString()
    }

    /** [fold] and then lower case, character by character - the SAME length as [text] (`String.lowercase()` can change the length). */
    fun foldLower(text: String): String {
        val f = fold(text)
        return String(CharArray(f.length) { f[it].lowercaseChar() })
    }

    /** Luhn checksum of a string of digits (bank cards). */
    fun luhn(digits: String): Boolean {
        var sum = 0
        var double = false
        for (i in digits.length - 1 downTo 0) {
            var d = digits[i] - '0'
            if (double) {
                d *= 2
                if (d > 9) d -= 9
            }
            sum += d
            double = !double
        }
        return digits.isNotEmpty() && sum % 10 == 0
    }

    /**
     * [words] are the words of one line, joined with a single space to make the text that was searched; returns the indexes of the words
     * that overlap characters [start, end) of that text, or null when none does. A word only partly inside the match counts as inside
     * (it is blacked out whole - better too much than a leftover digit).
     */
    fun wordsCovering(words: List<String>, start: Int, end: Int): IntRange? {
        var pos = 0
        var first = -1
        var last = -1
        for ((i, w) in words.withIndex()) {
            val wordStart = pos
            val wordEnd = pos + w.length
            if (wordEnd > start && wordStart < end) {
                if (first < 0) first = i
                last = i
            }
            pos = wordEnd + 1
        }
        return if (first < 0) null else first..last
    }
}
