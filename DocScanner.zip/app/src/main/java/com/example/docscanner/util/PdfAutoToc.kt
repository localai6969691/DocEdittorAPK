package com.example.docscanner.util

import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * A contents list (PDF bookmarks) made from the document itself, for a PDF that has none (phiên 25, TECHNICAL_DOCS.md 4.70): the reader's Contents item asks "create one?"
 * and this is what answers yes. It reads the PDF's TEXT LAYER with PDFBox, line by line with each line's font size and weight, and takes the lines that stand out as headings:
 *  - a line is a heading when its font is clearly LARGER than the body text ([HEADING_RATIO] x the size most characters are set in), or when it is bold at body size AND numbered
 *    ("1.2 Methods", "Chương 3", "Chapter IV", "Appendix A");
 *  - running headers and footers (the same words, digits aside, on many pages), page numbers, lines of a printed contents page ("Chapter 1 ........ 5") and sentence fragments
 *    (ending in a comma or semicolon) are not headings;
 *  - a heading wrapped over two lines becomes one entry;
 *  - the distinct heading sizes, largest first, become levels 1, 2 and 3 (smaller ones stay at 3);
 *  - too few headings (under [MIN_ENTRIES]) or far too many (more than [MAX_PER_PAGE] a page on average, or [MAX_ENTRIES] in all: a form, slides, a poster) is NOT a contents list, so
 *    nothing is made rather than a list that would mislead.
 * A scan has no text layer ([Status.NO_TEXT]): the caller says so and points at the searchable-PDF tool, as the search in the reader does.
 *
 * [plan] is PURE (lines in, [PdfBookmarks.Entry] list out; pages are 0-based) and is what tools/verify/autotoc_real_run_check.py drives with the real PDFBox on generated books.
 * It does NOT read a printed contents page to take titles or page numbers from it: the titles come from the headings themselves, so every entry points at the page the heading is on.
 */
object PdfAutoToc {

    enum class Status { FOUND, NO_TEXT, NO_HEADINGS, UNREADABLE }

    class Result(val status: Status, val entries: List<PdfBookmarks.Entry> = emptyList())

    /** One line of the text layer: [page] 0-based, [size] the largest font size on it (pt), [bold] when most of its letters are bold, [top] its distance from the top of the page (pt). */
    class Line(val page: Int, val text: String, val size: Float, val bold: Boolean, val top: Float)

    const val HEADING_RATIO = 1.15f
    const val MIN_ENTRIES = 3
    const val MAX_ENTRIES = 400
    const val MAX_PER_PAGE = 8
    const val MAX_LEVEL = 3
    const val MAX_TITLE_CHARS = 90
    const val MIN_CHARS_PER_PAGE = 20

    private const val SIZE_STEP = 0.75f

    private val PAGE_NUMBER = Regex("""^(page|trang|p\.)?\s*\d{1,5}(\s*(/|of|trên)\s*\d{1,5})?$""", RegexOption.IGNORE_CASE)
    private val CONTENTS_LINE = Regex("""^.{2,80}?[\s.]{2,}\d{1,4}$""")
    private val NUMBERED = Regex(
        """^((chương|chuong|chapter|phần|part|bài|mục|section|appendix|phụ lục|lesson|unit|kapitel|chapitre|capítulo|capitulo|章|第)\s*[\divxlcIVXLC]+\b|""" +
            """\d{1,2}(\.\d{1,2}){0,3}[.)]?\s+\p{L}|[IVX]{1,5}[.)]\s+\p{L})""",
        RegexOption.IGNORE_CASE
    )

    // ---------------------------------------------------------------------------------------
    // Planning (pure)
    // ---------------------------------------------------------------------------------------

    /** The outline for a document of [pageCount] pages whose text layer gave [lines] (in reading order); empty when it does not look like it has headings. */
    fun plan(lines: List<Line>, pageCount: Int): List<PdfBookmarks.Entry> {
        val usable = lines.filter { it.text.isNotBlank() && it.size > 0f }
        if (usable.size < 5 || pageCount < 2) return emptyList()
        val body = bodySize(usable)
        if (body <= 0f) return emptyList()

        // the same words on many pages (digits aside) are a running header or footer
        val pagesOf = HashMap<String, HashSet<Int>>()
        for (l in usable) pagesOf.getOrPut(key(l.text)) { HashSet() }.add(l.page)
        val repeatedAt = max(3, (pageCount * 0.3f).toInt())

        val candidates = ArrayList<Line>()
        for (l in usable) {
            if (!looksLikeHeading(l, body)) continue
            if ((pagesOf[key(l.text)]?.size ?: 0) >= repeatedAt) continue
            candidates.add(l)
        }
        val merged = mergeWrapped(candidates)
        if (merged.size < MIN_ENTRIES || merged.size > MAX_ENTRIES || merged.size > pageCount * MAX_PER_PAGE) return emptyList()

        // levels: the distinct sizes, largest first (sizes within SIZE_STEP are one size)
        val sizes = merged.map { it.size }.distinct().sortedDescending()
        val levelOfSize = ArrayList<Pair<Float, Int>>()
        var levelStart = Float.MAX_VALUE
        var level = 0
        for (s in sizes) {
            if (levelStart - s > SIZE_STEP) {
                level++
                levelStart = s
            }
            levelOfSize.add(Pair(s, level))
        }
        var entries = merged.map { l -> PdfBookmarks.Entry(l.text, levelOfSize.first { it.first == l.size }.second, l.page) }

        // a lone biggest line on the first page is the document's title, not a chapter: leave it out and lift the rest
        val top = entries.filter { it.level == 1 }
        if (top.size == 1 && top[0].page == 0 && entries.size - 1 >= MIN_ENTRIES) {
            entries = entries.filter { it !== top[0] }.map { PdfBookmarks.Entry(it.title, max(1, it.level - 1), it.page) }
        }
        // only now are the deep levels capped: the title above counted as a level while the sizes were ranked
        return PdfBookmarks.normalizeLevels(entries.map { PdfBookmarks.Entry(it.title, minOf(it.level, MAX_LEVEL), it.page) })
    }

    /** The font size most characters are set in, to half a point: the size of the body text. */
    internal fun bodySize(lines: List<Line>): Float {
        val weight = HashMap<Int, Int>()
        for (l in lines) {
            val bucket = (l.size * 2f).roundToInt()
            weight[bucket] = (weight[bucket] ?: 0) + l.text.count { !it.isWhitespace() }
        }
        val best = weight.maxByOrNull { it.value } ?: return 0f
        return best.key / 2f
    }

    private fun key(text: String): String = text.lowercase(Locale.ROOT).replace(Regex("""\d+"""), "#").replace(Regex("""\s+"""), " ").trim()

    private fun looksLikeHeading(l: Line, body: Float): Boolean {
        val text = l.text.trim()
        if (text.length < 2 || text.length > MAX_TITLE_CHARS) return false
        if (text.none { it.isLetter() }) return false
        if (PAGE_NUMBER.matches(text) || CONTENTS_LINE.matches(text)) return false
        if (text.last() == ',' || text.last() == ';') return false
        if (l.size >= body * HEADING_RATIO) return true
        return l.bold && l.size >= body * 0.95f && NUMBERED.containsMatchIn(text)
    }

    /** Two lines of the same size and weight, one right below the other on a page, are one heading that wrapped (unless the second starts a new numbered heading). */
    private fun mergeWrapped(lines: List<Line>): List<Line> {
        val out = ArrayList<Line>()
        for (l in lines) {
            val prev = out.lastOrNull()
            val wrapped = prev != null && prev.page == l.page && abs(prev.size - l.size) <= 0.6f && prev.bold == l.bold &&
                l.top > prev.top && l.top - prev.top <= prev.size * 1.8f && prev.text.length + l.text.length < MAX_TITLE_CHARS + 30 &&
                !NUMBERED.containsMatchIn(l.text)
            if (wrapped && prev != null) {
                out[out.size - 1] = Line(prev.page, prev.text + " " + l.text.trim(), prev.size, prev.bold, l.top)
            } else {
                out.add(Line(l.page, l.text.trim(), l.size, l.bold, l.top))
            }
        }
        return out
    }

    // ---------------------------------------------------------------------------------------
    // Reading the text layer
    // ---------------------------------------------------------------------------------------

    private fun isBold(position: TextPosition): Boolean {
        val font = position.font ?: return false
        val name = font.name ?: ""
        if (name.contains("bold", ignoreCase = true) || name.contains("black", ignoreCase = true) || name.contains("heavy", ignoreCase = true) || name.endsWith(",B")) return true
        val d = runCatching { font.fontDescriptor }.getOrNull() ?: return false
        return d.isForceBold || d.fontWeight >= 700f
    }

    /** Every line of the text layer, in reading order, with its font size and weight; text shown sideways on the displayed page is left out (its sizes are not comparable). */
    fun readLines(doc: PDDocument): List<Line> {
        val out = ArrayList<Line>()
        val stripper = object : PDFTextStripper() {
            private val pieces = ArrayList<String>()
            private var size = 0f
            private var top = 0f
            private var page = 0
            private var boldChars = 0
            private var chars = 0

            override fun writeString(text: String, textPositions: List<TextPosition>) {
                if (textPositions.isEmpty()) return
                val pageRotation = ((currentPage.rotation % 360) + 360) % 360
                if (((textPositions[0].dir.toInt() - pageRotation) % 360 + 360) % 360 != 0) return
                if (pieces.isNotEmpty() && page != currentPageNo - 1) flush()
                if (pieces.isEmpty()) {
                    page = currentPageNo - 1
                    top = textPositions[0].yDirAdj
                }
                pieces.add(text)
                for (p in textPositions) {
                    val unicode = p.unicode ?: ""
                    if (unicode.isBlank()) continue
                    chars++
                    if (isBold(p)) boldChars++
                    size = max(size, p.fontSizeInPt)
                }
            }

            private fun flush() {
                val text = pieces.joinToString(" ").replace(Regex("""\s+"""), " ").trim()
                if (text.isNotEmpty() && size > 0f) out.add(Line(page, text, size, chars > 0 && boldChars * 10 >= chars * 6, top))
                pieces.clear()
                size = 0f
                boldChars = 0
                chars = 0
            }

            override fun writeLineSeparator() {
                flush()
                super.writeLineSeparator()
            }

            override fun writeParagraphSeparator() {
                flush()
                super.writeParagraphSeparator()
            }

            override fun writePageEnd() {
                flush()
                super.writePageEnd()
            }

            fun finish() = flush()
        }
        stripper.sortByPosition = true
        stripper.getText(doc)
        stripper.finish()
        return out
    }

    /** Reads [file] and makes its outline; see the class comment for what each [Status] means. An encrypted or damaged file is [Status.UNREADABLE] (the reader opens an unlocked copy). */
    fun detect(file: File): Result {
        return try {
            PDDocument.load(file, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(file.parentFile)).use { doc ->
                if (doc.isEncrypted) {
                    Result(Status.UNREADABLE)
                } else {
                    val pages = doc.numberOfPages
                    val lines = readLines(doc)
                    val chars = lines.sumOf { l -> l.text.count { !it.isWhitespace() } }
                    if (pages == 0 || chars < MIN_CHARS_PER_PAGE * pages) {
                        Result(Status.NO_TEXT)
                    } else {
                        val entries = plan(lines, pages)
                        if (entries.isEmpty()) Result(Status.NO_HEADINGS) else Result(Status.FOUND, entries)
                    }
                }
            }
        } catch (e: Throwable) {
            Result(Status.UNREADABLE)
        }
    }
}
