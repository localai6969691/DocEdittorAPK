package com.example.docscanner

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityWifiScanBinding
import com.example.docscanner.model.PendingCropQueue
import com.example.docscanner.model.ScanSessionManager
import com.example.docscanner.util.EsclClient
import com.example.docscanner.util.EsclDiscovery
import com.example.docscanner.util.EsclProtocol
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * "Quét qua Wi-Fi" (phiên 17, mục 4.31): scans with a network scanner / MFP that speaks eSCL (AirScan) - no driver, no cable. The scanners are found by mDNS ([EsclDiscovery])
 * or the address is typed ([EsclProtocol.baseUrl]); the person picks source (glass / feeder), colour and resolution from what THAT device supports ([EsclProtocol.fit]); the
 * pages come back as JPEG files and go through the same crop / filter queue as a gallery import, with the real DPI, so the exported PDF has the right physical page size.
 * Everything runs on the local network only ([EsclClient] refuses other addresses). This screen exists only when the app declares the INTERNET permission: [isAvailable] is
 * false without it and the home screen hides the card - removing the permission line from the manifest therefore switches the feature off cleanly.
 * Not yet run against a real scanner (see TECHNICAL_DOCS.md 4.31 I and 6).
 */
class WifiScanActivity : BaseActivity() {

    companion object {
        /** True when the manifest declares INTERNET (the permission is normal-level: granted at install, never asked). */
        fun isAvailable(context: Context): Boolean = context.checkSelfPermission(Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED
    }

    private lateinit var binding: ActivityWifiScanBinding
    private var discovery: EsclDiscovery? = null
    private val scanners = ArrayList<EsclDiscovery.Scanner>()
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWifiScanBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.wifi_title)
        binding.lvScanners.setOnItemClickListener { _, _, position, _ -> scanners.getOrNull(position)?.let { if (!busy) choose(it.name, it.base) } }
        binding.btnWifiType.setOnClickListener { if (!busy) askAddress() }
        binding.btnWifiSearch.setOnClickListener { if (!busy) startSearch() }
        if (!isAvailable(this)) {
            binding.tvWifiStatus.text = getString(R.string.wifi_unavailable)
            binding.btnWifiType.isEnabled = false
            binding.btnWifiSearch.isEnabled = false
            binding.wifiProgress.visibility = View.GONE
            return
        }
        startSearch()
    }

    override fun onDestroy() {
        super.onDestroy()
        discovery?.stop()
    }

    private fun setStatus(text: String) { binding.tvWifiStatus.text = text }

    private fun setBusy(value: Boolean) {
        busy = value
        binding.wifiProgress.visibility = if (value) View.VISIBLE else View.GONE
        binding.btnWifiType.isEnabled = !value
        binding.btnWifiSearch.isEnabled = !value
    }

    private fun startSearch() {
        discovery?.stop()
        scanners.clear()
        refreshList()
        setStatus(getString(R.string.wifi_searching))
        binding.wifiProgress.visibility = View.VISIBLE
        discovery = EsclDiscovery(this) { found ->
            scanners.add(found)
            refreshList()
            setStatus(getString(R.string.wifi_found, scanners.size))
        }.also { it.start() }
        binding.lvScanners.postDelayed({
            if (!busy) binding.wifiProgress.visibility = View.GONE
            if (scanners.isEmpty() && !busy) setStatus(getString(R.string.wifi_none_found))
        }, 8000)
    }

    private fun refreshList() {
        binding.lvScanners.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, scanners.map { it.name + "\n" + it.base.removePrefix("http://") })
    }

    private fun askAddress() {
        val input = EditText(this).apply {
            setSingleLine()
            hint = getString(R.string.wifi_address_hint)
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.wifi_type_address)
            .setView(input)
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.dialog_ok) { _, _ ->
                val base = EsclProtocol.baseUrl(input.text.toString())
                if (base == null) Toast.makeText(this, R.string.wifi_bad_address, Toast.LENGTH_LONG).show() else choose(base.removePrefix("http://"), base)
            }
            .show()
    }

    private fun message(e: Throwable): String = when ((e as? EsclClient.EsclException)?.code) {
        "busy" -> getString(R.string.wifi_err_busy)
        "not_local" -> getString(R.string.wifi_err_not_local)
        "unreachable" -> getString(R.string.wifi_err_unreachable)
        "no_pages" -> getString(R.string.wifi_err_no_pages)
        "no_location", "bad_xml", "too_big" -> getString(R.string.wifi_err_protocol)
        null -> getString(R.string.wifi_err_connect)
        else -> getString(R.string.wifi_err_refused)
    }

    /** Asks the scanner what it can do, then lets the person choose source, colour and resolution among those. */
    private fun choose(name: String, base: String) {
        setBusy(true)
        setStatus(getString(R.string.wifi_asking, name))
        lifecycleScope.launch {
            val caps = withContext(Dispatchers.IO) { runCatching { EsclClient(base).capabilities() } }
            setBusy(false)
            val c = caps.getOrNull()
            if (c == null) {
                setStatus(message(caps.exceptionOrNull() ?: Exception()))
                return@launch
            }
            setStatus("")
            showSettings(name, base, c)
        }
    }

    private fun showSettings(name: String, base: String, caps: EsclProtocol.Capabilities) {
        val sources = ArrayList<Pair<String, EsclProtocol.Source>>()
        if (caps.platen) sources.add(getString(R.string.wifi_source_glass) to EsclProtocol.Source.PLATEN)
        if (caps.feeder) sources.add(getString(R.string.wifi_source_feeder) to EsclProtocol.Source.FEEDER)
        if (sources.isEmpty()) sources.add(getString(R.string.wifi_source_glass) to EsclProtocol.Source.PLATEN)
        val colors = listOf(getString(R.string.wifi_color_rgb) to EsclProtocol.Color.RGB, getString(R.string.wifi_color_gray) to EsclProtocol.Color.GRAY, getString(R.string.wifi_color_bw) to EsclProtocol.Color.BW)
        val dpis = (listOf(150, 200, 300, 600).filter { caps.resolutions.isEmpty() || caps.resolutions.contains(it) }).ifEmpty { caps.resolutions.ifEmpty { listOf(300) } }
        fun spinner(items: List<String>, selected: Int = 0) = Spinner(this).apply {
            adapter = ArrayAdapter(this@WifiScanActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(selected)
        }
        val src = spinner(sources.map { it.first })
        val col = spinner(colors.map { it.first })
        val res = spinner(dpis.map { "$it dpi" }, dpis.indexOf(300).coerceAtLeast(0))
        // two sides: only when the device lists AdfDuplexInputCaps (phiên 20, 4.48.4); "rotate the back sides" is for devices whose second pass comes out upside down
        val duplexBox = android.widget.CheckBox(this).apply { setText(R.string.wifi_duplex); visibility = if (caps.duplex) android.view.View.VISIBLE else android.view.View.GONE }
        val rotateBox = android.widget.CheckBox(this).apply { setText(R.string.wifi_rotate_back); visibility = android.view.View.GONE }
        duplexBox.setOnCheckedChangeListener { _, on -> rotateBox.visibility = if (on) android.view.View.VISIBLE else android.view.View.GONE }
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
            addView(TextView(this@WifiScanActivity).apply { text = if (caps.make.isNotEmpty()) caps.make else name })
            addView(TextView(this@WifiScanActivity).apply { setText(R.string.wifi_source) }); addView(src)
            addView(TextView(this@WifiScanActivity).apply { setText(R.string.wifi_color) }); addView(col)
            addView(TextView(this@WifiScanActivity).apply { setText(R.string.wifi_resolution) }); addView(res)
            addView(duplexBox); addView(rotateBox)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.wifi_settings_title)
            .setView(box)
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.wifi_scan_now) { _, _ ->
                val settings = EsclProtocol.fit(caps, sources[src.selectedItemPosition].second, colors[col.selectedItemPosition].second, dpis[res.selectedItemPosition], duplexBox.isChecked)
                runScan(base, settings, rotateBox.isChecked && settings.duplex)
            }
            .show()
    }

    /** Turns a JPEG page by 180 degrees (re-encoded at quality 95); the page as it came if it cannot be decoded or the phone is out of memory. */
    private fun rotate180(jpeg: ByteArray): ByteArray = try {
        val bmp = android.graphics.BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size)
        if (bmp == null) jpeg else {
            val rotated = android.graphics.Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, android.graphics.Matrix().apply { postRotate(180f) }, true)
            if (rotated !== bmp) bmp.recycle()
            val out = java.io.ByteArrayOutputStream()
            rotated.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, out)
            rotated.recycle()
            out.toByteArray()
        }
    } catch (e: OutOfMemoryError) {
        jpeg
    }

    /** [rotateBack]: pages 2, 4, 6 ... (indices 1, 3, 5 ...) of a two-sided scan are turned by 180 degrees. */
    private fun runScan(base: String, settings: EsclProtocol.Settings, rotateBack: Boolean = false) {
        if (settings.format != "image/jpeg") {
            setStatus(getString(R.string.wifi_err_format))
            return
        }
        setBusy(true)
        setStatus(getString(R.string.wifi_scanning))
        val stamp = System.currentTimeMillis()
        lifecycleScope.launch {
            val paths = ArrayList<String>()
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    EsclClient(base).scan(settings) { index, bytes ->
                        val f = File(cacheDir, "wifi_${stamp}_$index.jpg")
                        f.writeBytes(if (rotateBack && index % 2 == 1) rotate180(bytes) else bytes)
                        paths.add(f.absolutePath)
                    }
                }
            }
            setBusy(false)
            val failure = result.exceptionOrNull()
            if (failure != null && paths.isEmpty()) {
                setStatus(message(failure))
                return@launch
            }
            if (failure != null) Toast.makeText(this@WifiScanActivity, message(failure), Toast.LENGTH_LONG).show()
            // same hand-over as MainActivity.startCropQueue: the scanner's resolution is real, so the exported PDF keeps the right physical size
            ScanSessionManager.clear()
            PendingCropQueue.setAll(paths.drop(1), settings.dpi.toFloat())
            startActivity(Intent(this@WifiScanActivity, CropActivity::class.java).apply {
                putExtra(CropActivity.EXTRA_IMAGE_PATH, paths.first())
                putExtra(CropActivity.EXTRA_QUEUE_MODE, true)
                putExtra(CropActivity.EXTRA_SOURCE_DPI, settings.dpi.toFloat())
            })
            finish()
        }
    }
}
