package com.example.docscanner.util

import com.example.docscanner.util.DocumentImport.Block
import java.io.InputStream
import java.util.zip.ZipInputStream

/**
 * Reads OpenDocument text (.odt), PowerPoint (.pptx) and Excel (.xlsx) files into the same plain BLOCKS as [DocumentImport] (phiên 20, mục 4.48.2; "nhập ODT / PPTX /
 * XLSX / RTF" of the PDF "Thiếu gì để bán app"). RTF has its own reader, [RtfImport].
 *
 * PURE (strings and streams in, blocks out; no Android, no PdfBox) and mirrored line by line in tools/verify/OfficeImportCheck.java; tools/verify/office_import_check.py
 * compares the mirror with INDEPENDENT readers on files made by REAL producers (LibreOffice, python-pptx, openpyxl, pandoc): ODT against `pandoc -f odt`, PPTX against
 * python-pptx, XLSX against openpyxl and against LibreOffice's own CSV export ("as shown").
 *
 * Scope, stated plainly (a TEXT import, like [DocumentImport]): headings, paragraphs, list items and table rows in reading order. NOT imported: images, charts, SmartArt,
 * footnotes / endnotes, comments, tracked-change deletions, generated tables of contents (ODT), speaker notes and hidden-sheet content (XLSX), formulas (the stored RESULT is read).
 * XLSX numbers use the cell's number format for the common cases only (decimals, thousands separator, percent, a currency sign); dates always come out as ISO text.
 */
object OfficeImport {

    /** One sheet of a workbook: its name and its non-empty rows (cells as text, columns kept in place). */
    class Sheet(val name: String, val rows: List<List<String>>)

    // ------------------------------------------------------------------------------------------------- ZIP

    private const val MAX_ENTRY = 64 * 1024 * 1024
    private const val MAX_TOTAL = 160L * 1024 * 1024

    /** Text (UTF-8) of the entries of a ZIP package that [wanted] accepts; null when one entry or the total is too large. */
    internal fun zipTexts(input: InputStream, wanted: (String) -> Boolean): Map<String, String>? {
        val out = LinkedHashMap<String, String>()
        var total = 0L
        ZipInputStream(input).use { zip ->
            while (true) {
                val e = zip.nextEntry ?: break
                if (e.isDirectory || !wanted(e.name)) continue
                val bytes = java.io.ByteArrayOutputStream()
                val buf = ByteArray(16 * 1024)
                var size = 0
                while (true) {
                    val n = zip.read(buf)
                    if (n < 0) break
                    size += n
                    total += n
                    if (size > MAX_ENTRY || total > MAX_TOTAL) return null
                    bytes.write(buf, 0, n)
                }
                out[e.name] = bytes.toString("UTF-8")
            }
        }
        return out
    }

    // ------------------------------------------------------------------------------------------------- a small XML scanner

    internal abstract class XmlHandler {
        open fun start(name: String, attrs: Map<String, String>) {}
        open fun end(name: String) {}
        /** Text between tags with the entities ALREADY decoded. */
        open fun text(t: String) {}
    }

    private val XML_ENTITY = Regex("&(#[0-9]{1,7}|#[xX][0-9A-Fa-f]{1,6}|amp|lt|gt|quot|apos);")

    /** The five predefined XML entities and numeric references (XML has no other named ones; HTML's `&eacute;` never occurs in these parts). */
    internal fun xmlDecode(s: String): String {
        if (s.indexOf('&') < 0) return s
        return XML_ENTITY.replace(s) { m ->
            val b = m.groupValues[1]
            when (b) {
                "amp" -> "&"
                "lt" -> "<"
                "gt" -> ">"
                "quot" -> "\""
                "apos" -> "'"
                else -> {
                    val cp = try { if (b[1] == 'x' || b[1] == 'X') b.substring(2).toInt(16) else b.substring(1).toInt() } catch (e: NumberFormatException) { -1 }
                    if (cp in 1..0x10FFFF && cp !in 0xD800..0xDFFF) String(Character.toChars(cp)) else m.value
                }
            }
        }
    }

    private val ATTR = Regex("([A-Za-z_][A-Za-z0-9_:.\\-]*)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')")

    /** Not a validating parser: tags, attributes, text, CDATA; comments, processing instructions and DOCTYPE are skipped. [stripPrefix] turns `x:row` into `row`. */
    internal fun scanXml(s: String, h: XmlHandler, stripPrefix: Boolean = false) {
        var i = 0
        val n = s.length
        while (i < n) {
            val lt = s.indexOf('<', i)
            if (lt < 0) { h.text(xmlDecode(s.substring(i))); break }
            if (lt > i) h.text(xmlDecode(s.substring(i, lt)))
            if (s.startsWith("<!--", lt)) {
                val e = s.indexOf("-->", lt + 4)
                i = if (e < 0) n else e + 3
            } else if (s.startsWith("<![CDATA[", lt)) {
                val e = s.indexOf("]]>", lt + 9)
                val stop = if (e < 0) n else e
                h.text(s.substring(lt + 9, stop))
                i = if (e < 0) n else e + 3
            } else if (s.startsWith("<?", lt) || s.startsWith("<!", lt)) {
                val e = s.indexOf('>', lt)
                i = if (e < 0) n else e + 1
            } else {
                // the end of the tag: the first '>' that is not inside a quoted attribute value
                var j = lt + 1
                var quote = ' '
                while (j < n) {
                    val c = s[j]
                    if (quote != ' ') { if (c == quote) quote = ' ' }
                    else if (c == '"' || c == '\'') quote = c
                    else if (c == '>') break
                    j++
                }
                if (j >= n) break
                var inner = s.substring(lt + 1, j)
                i = j + 1
                if (inner.startsWith("/")) {
                    h.end(localOrFull(inner.substring(1).trim(), stripPrefix))
                    continue
                }
                var selfClosing = false
                if (inner.endsWith("/")) { selfClosing = true; inner = inner.substring(0, inner.length - 1) }
                var k = 0
                while (k < inner.length && !inner[k].isWhitespace()) k++
                val name = localOrFull(inner.substring(0, k), stripPrefix)
                val attrs = LinkedHashMap<String, String>()
                if (k < inner.length) {
                    for (m in ATTR.findAll(inner.substring(k))) {
                        val v = m.groups[2]?.value ?: m.groups[3]?.value ?: ""
                        attrs[m.groupValues[1]] = xmlDecode(v)
                    }
                }
                h.start(name, attrs)
                if (selfClosing) h.end(name)
            }
        }
    }

    private fun localOrFull(name: String, strip: Boolean): String = if (strip) name.substringAfter(':') else name

    private val WS = Regex("[ \\t\\u00A0\\r\\n]+")
    internal fun collapse(s: String): String = WS.replace(s, " ").trim()

    // ------------------------------------------------------------------------------------------------- ODT

    private val ODT_SKIP = setOf(
        "office:automatic-styles", "office:font-face-decls", "office:scripts", "text:tracked-changes", "text:note", "office:annotation",
        "text:table-of-content", "text:alphabetical-index", "text:bibliography", "text:user-index", "text:illustration-index",
        "text:table-index", "text:object-index"
    )

    /** `text:list-style` name -> nesting level -> true when that level is NUMBERED (false = bullet / image). Read from content.xml and styles.xml. */
    private fun odfListKinds(vararg docs: String): Map<String, Map<Int, Boolean>> {
        val kinds = HashMap<String, HashMap<Int, Boolean>>()
        for (doc in docs) {
            if (doc.isEmpty()) continue
            var cur: String? = null
            scanXml(doc, object : XmlHandler() {
                override fun start(name: String, attrs: Map<String, String>) {
                    when (name) {
                        "text:list-style" -> cur = attrs["style:name"]
                        "text:list-level-style-number" -> cur?.let { c -> kinds.getOrPut(c) { HashMap() }[attrs["text:level"]?.toIntOrNull() ?: 1] = true }
                        "text:list-level-style-bullet", "text:list-level-style-image" -> cur?.let { c -> kinds.getOrPut(c) { HashMap() }[attrs["text:level"]?.toIntOrNull() ?: 1] = false }
                    }
                }
                override fun end(name: String) { if (name == "text:list-style") cur = null }
            })
        }
        return kinds
    }

    private class OdtPara(val kind: String, val level: Int, val style: String) { val sb = StringBuilder() }

    /**
     * Blocks from the text of an ODT's `content.xml` ([styles] = `styles.xml`, only used to tell numbered lists from bulleted ones): `text:h` = heading (its outline level),
     * the `Title` paragraph style = heading 1, `text:list` items = list items (depth = nesting, numbered when the list style's level is), tables = rows (cells joined by " | ").
     */
    fun blocksFromOdtXml(content: String, styles: String = ""): List<Block> {
        val listKinds = odfListKinds(content, styles)
        val out = ArrayList<Block>()
        var skip = 0
        val lists = ArrayList<String?>()          // style name of every open text:list (inherited when the nested list has none)
        val itemUsed = ArrayList<BooleanArray>()  // per open list item: has its first paragraph been written?
        val paras = ArrayList<OdtPara>()          // open paragraphs (a text box inside a paragraph holds another one)
        var tableDepth = 0
        var cells = ArrayList<String>()
        var cell = StringBuilder()
        scanXml(content, object : XmlHandler() {
            override fun start(name: String, attrs: Map<String, String>) {
                if (skip > 0) { skip++; return }
                if (name in ODT_SKIP) { skip = 1; return }
                when (name) {
                    "text:list" -> lists.add(attrs["text:style-name"] ?: lists.lastOrNull())
                    "text:list-item", "text:list-header" -> itemUsed.add(booleanArrayOf(false))
                    "text:h" -> paras.add(OdtPara("H", (attrs["text:outline-level"]?.toIntOrNull() ?: 1).coerceIn(1, 6), ""))
                    "text:p" -> paras.add(OdtPara("P", 0, attrs["text:style-name"] ?: ""))
                    "text:s", "text:tab" -> paras.lastOrNull()?.sb?.append(' ')
                    "text:line-break" -> paras.lastOrNull()?.sb?.append('\n')
                    "table:table" -> { tableDepth++; if (tableDepth == 1) cells = ArrayList() }
                    "table:table-row" -> if (tableDepth == 1) cells = ArrayList()
                    "table:table-cell" -> if (tableDepth == 1) cell = StringBuilder()
                }
            }

            override fun end(name: String) {
                if (skip > 0) { skip--; return }
                when (name) {
                    "text:list" -> if (lists.isNotEmpty()) lists.removeAt(lists.size - 1)
                    "text:list-item", "text:list-header" -> if (itemUsed.isNotEmpty()) itemUsed.removeAt(itemUsed.size - 1)
                    "text:h", "text:p" -> {
                        if (paras.isEmpty()) return
                        val p = paras.removeAt(paras.size - 1)
                        val text = p.sb.toString().lines().joinToString("\n") { collapse(it) }.trim()
                        if (text.isEmpty()) return
                        if (tableDepth > 0) {
                            if (cell.isNotEmpty()) cell.append(' ')
                            cell.append(text.replace('\n', ' '))
                            return
                        }
                        val depth = lists.size
                        when {
                            p.kind == "H" -> out.add(Block("H", p.level, collapse(text)))
                            p.style.equals("Title", ignoreCase = true) -> out.add(Block("H", 1, collapse(text)))
                            depth > 0 && itemUsed.isNotEmpty() && !itemUsed.last()[0] -> {
                                itemUsed.last()[0] = true
                                val numbered = listKinds[lists.last() ?: ""]?.get(depth) == true
                                out.add(Block("LI", depth, text, if (numbered) "#" else "\u2022"))
                            }
                            else -> out.add(Block("P", 0, text))
                        }
                    }
                    "table:table-cell" -> if (tableDepth == 1) cells.add(collapse(cell.toString()))
                    "table:table-row" -> if (tableDepth == 1 && cells.any { it.isNotEmpty() }) out.add(Block("ROW", 0, cells.joinToString(" | ")))
                    "table:table" -> if (tableDepth > 0) tableDepth--
                }
            }

            override fun text(t: String) { if (skip == 0) paras.lastOrNull()?.sb?.append(t) }
        })
        return out
    }

    /** Reads `content.xml` (+ `styles.xml`) out of an .odt (a ZIP). Empty list when `content.xml` is missing or a part is larger than 64 MB. */
    fun blocksFromOdt(input: InputStream): List<Block> {
        val t = zipTexts(input) { it == "content.xml" || it == "styles.xml" } ?: return emptyList()
        return blocksFromOdtXml(t["content.xml"] ?: return emptyList(), t["styles.xml"] ?: "")
    }

    // ------------------------------------------------------------------------------------------------- PPTX

    private class PptxPara(var level: Int, var bullet: Int) { val sb = StringBuilder() }   // bullet: 0 none (buNone), 1 bullet, 2 numbered, -1 not stated

    private val PPTX_SKIP_PH = setOf("sldNum", "dt", "ftr", "hdr")

    /**
     * Blocks of ONE slide: the title placeholder becomes a level-2 heading (every slide is a chapter; a slide without a title gets [label]); body placeholders give list items
     * (depth = paragraph level + 1) unless the paragraph says "no bullet"; other text boxes give paragraphs (list items only when they carry a bullet); tables give rows.
     * Slide number / date / footer placeholders are ignored, and so is the `mc:Fallback` copy of a shape that PowerPoint writes next to the real one.
     */
    fun blocksFromPptxSlide(xml: String, label: String): List<Block> {
        var title: String? = null
        val body = ArrayList<Block>()
        var skip = 0
        var spDepth = 0
        var phType: String? = null
        var hasPh = false
        val shapeParas = ArrayList<PptxPara>()
        var para: PptxPara? = null
        var tblDepth = 0
        var cells = ArrayList<String>()
        var cell = StringBuilder()
        var inCell = false
        var inT = false
        scanXml(xml, object : XmlHandler() {
            override fun start(name: String, attrs: Map<String, String>) {
                if (skip > 0) { skip++; return }
                if (name == "mc:Fallback") { skip = 1; return }
                when (name) {
                    "p:sp" -> { spDepth++; if (spDepth == 1) { phType = null; hasPh = false; shapeParas.clear() } }
                    "p:ph" -> if (spDepth == 1) { hasPh = true; phType = attrs["type"] }
                    "a:tbl" -> tblDepth++
                    "a:tr" -> if (tblDepth == 1) cells = ArrayList()
                    "a:tc" -> if (tblDepth == 1) { cell = StringBuilder(); inCell = !(attrs["hMerge"] == "1" || attrs["vMerge"] == "1" || attrs["hMerge"] == "true" || attrs["vMerge"] == "true") }
                    "a:p" -> para = PptxPara(0, -1)
                    "a:pPr" -> para?.level = (attrs["lvl"]?.toIntOrNull() ?: 0).coerceIn(0, 8)
                    "a:buNone" -> para?.bullet = 0
                    "a:buChar" -> para?.bullet = 1
                    "a:buAutoNum" -> para?.bullet = 2
                    "a:br" -> para?.sb?.append('\n')
                    "a:t" -> inT = true
                }
            }

            override fun end(name: String) {
                if (skip > 0) { skip--; return }
                when (name) {
                    "a:t" -> inT = false
                    "a:p" -> {
                        val p = para ?: return
                        para = null
                        val text = p.sb.toString().lines().joinToString("\n") { collapse(it) }.trim()
                        if (tblDepth > 0) {
                            if (inCell && text.isNotEmpty()) { if (cell.isNotEmpty()) cell.append(' '); cell.append(text.replace('\n', ' ')) }
                        } else if (spDepth > 0 && text.isNotEmpty()) shapeParas.add(PptxPara(p.level, p.bullet).also { it.sb.append(text) })
                    }
                    "a:tc" -> if (tblDepth == 1 && inCell) { cells.add(collapse(cell.toString())); inCell = false }
                    "a:tr" -> if (tblDepth == 1 && cells.any { it.isNotEmpty() }) body.add(Block("ROW", 0, cells.joinToString(" | ")))
                    "a:tbl" -> if (tblDepth > 0) tblDepth--
                    "p:sp" -> if (spDepth > 0) {
                        spDepth--
                        if (spDepth == 0) {
                            val t = phType
                            when {
                                hasPh && (t == "title" || t == "ctrTitle") -> {
                                    val joined = collapse(shapeParas.joinToString(" ") { it.sb.toString() })
                                    if (joined.isNotEmpty()) title = if (title == null) joined else "$title $joined"
                                }
                                hasPh && t in PPTX_SKIP_PH -> {}
                                else -> for (p in shapeParas) {
                                    val text = p.sb.toString()
                                    val bodyPh = hasPh && t != "subTitle"
                                    val listItem = if (bodyPh) p.bullet != 0 else p.bullet > 0
                                    if (listItem) body.add(Block("LI", p.level + 1, text, if (p.bullet == 2) "#" else "\u2022"))
                                    else body.add(Block("P", 0, text))
                                }
                            }
                        }
                    }
                }
            }

            override fun text(t: String) { if (inT) para?.sb?.append(t) }
        })
        if (title == null && body.isEmpty()) return emptyList()
        val out = ArrayList<Block>()
        out.add(Block("H", 2, title ?: label))
        out.addAll(body)
        return out
    }

    private val SLD_NUM = Regex("slide([0-9]+)\\.xml$")

    /** Slides in PRESENTATION order (`p:sldIdLst` + the relationships file, NOT the numbers in the file names), each as [blocksFromPptxSlide]; [slideLabel] names a slide without a title. */
    fun blocksFromPptx(input: InputStream, slideLabel: (Int) -> String = { "Slide $it" }): List<Block> {
        val t = zipTexts(input) {
            it == "ppt/presentation.xml" || it == "ppt/_rels/presentation.xml.rels" || (it.startsWith("ppt/slides/slide") && it.endsWith(".xml"))
        } ?: return emptyList()
        val order = ArrayList<String>()
        val pres = t["ppt/presentation.xml"]
        val rels = t["ppt/_rels/presentation.xml.rels"]
        if (pres != null && rels != null) {
            val targets = HashMap<String, String>()
            scanXml(rels, object : XmlHandler() {
                override fun start(name: String, attrs: Map<String, String>) {
                    if (name == "Relationship") {
                        val id = attrs["Id"]
                        val target = attrs["Target"]
                        if (id != null && target != null) targets[id] = if (target.startsWith("/")) target.substring(1) else "ppt/$target"
                    }
                }
            })
            scanXml(pres, object : XmlHandler() {
                override fun start(name: String, attrs: Map<String, String>) {
                    if (name == "p:sldId") attrs["r:id"]?.let { id -> targets[id]?.let { order.add(it) } }
                }
            })
        }
        val slides = order.filter { t.containsKey(it) }.ifEmpty {
            t.keys.filter { SLD_NUM.containsMatchIn(it) }.sortedBy { SLD_NUM.find(it)!!.groupValues[1].toInt() }
        }
        val out = ArrayList<Block>()
        for ((i, name) in slides.withIndex()) out.addAll(blocksFromPptxSlide(t[name] ?: continue, slideLabel(i + 1)))
        return out
    }

    // ------------------------------------------------------------------------------------------------- XLSX

    /** The format code a built-in number-format id stands for, reduced to what [classifyDate] / [formatNumber] understand (dates always come out ISO, times 24-hour). */
    private fun builtinFormat(id: Int): String = when (id) {
        1 -> "0"
        2 -> "0.00"
        3 -> "#,##0"
        4 -> "#,##0.00"
        9 -> "0%"
        10 -> "0.00%"
        14, 15, 16, 17, 27, 28, 29, 30, 31, 36, 50, 51, 54, 57, 58 -> "yyyy-mm-dd"
        18, 20, 32, 34, 52, 55 -> "hh:mm"
        19, 21, 33, 35, 45, 47, 53, 56 -> "hh:mm:ss"
        46 -> "[h]:mm:ss"
        22 -> "yyyy-mm-dd hh:mm"
        else -> "General"
    }

    private class DateFmt(val hasDate: Boolean, val hasTime: Boolean, val seconds: Boolean, val elapsed: Boolean)

    private val FMT_STRIP = Regex("\"[^\"]*\"|\\\\.|_.|\\*.")
    private val FMT_BRACKET = Regex("\\[([^\\]]*)\\]")

    /** Non-null when the format code shows a date and / or a time: a `y` or `d`, an `h` or `s`, or a `m` that is not a minute. Quoted text, escapes and colour / locale brackets do not count. */
    private fun classifyDate(code: String): DateFmt? {
        var elapsed = false
        var c = FMT_STRIP.replace(code, "")
        c = FMT_BRACKET.replace(c) { m ->
            val k = m.groupValues[1].lowercase()
            if (k == "h" || k == "hh" || k == "m" || k == "mm" || k == "s" || k == "ss") { elapsed = true; k.substring(0, 1) } else ""
        }
        val l = c.lowercase()
        val yd = l.indexOf('y') >= 0 || l.indexOf('d') >= 0
        val hs = l.indexOf('h') >= 0 || l.indexOf('s') >= 0
        val hasDate = yd || (l.indexOf('m') >= 0 && !hs && !elapsed)
        val hasTime = hs || elapsed
        if (!hasDate && !hasTime) return null
        return DateFmt(hasDate, hasTime, l.indexOf('s') >= 0, elapsed)
    }

    private fun pad(n: Int, width: Int): String {
        val s = n.toString()
        return if (s.length >= width) s else "0".repeat(width - s.length) + s
    }

    /** Civil date (year, month, day) of a day number counted from 1970-01-01 (proleptic Gregorian). */
    internal fun civil(daysSinceEpoch: Long): IntArray {
        val z = daysSinceEpoch + 719468
        val era = Math.floorDiv(z, 146097L)
        val doe = z - era * 146097
        val yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365
        val y = yoe + era * 400
        val doy = doe - (365 * yoe + yoe / 4 - yoe / 100)
        val mp = (5 * doy + 2) / 153
        val d = doy - (153 * mp + 2) / 5 + 1
        val m = if (mp < 10) mp + 3 else mp - 9
        return intArrayOf((y + (if (m <= 2) 1 else 0)).toInt(), m.toInt(), d.toInt())
    }

    /** The date of an Excel serial day number: 1900 system with its famous non-existent 1900-02-29 (serial 60), or the 1904 system. */
    internal fun excelDate(days: Long, date1904: Boolean): String {
        if (!date1904) {
            if (days == 60L) return "1900-02-29"
            if (days == 0L) return "1900-01-00"
        }
        val epoch = if (date1904) days - 24107 else if (days < 60) days - 25568 else days - 25569
        val c = civil(epoch)
        return pad(c[0], 4) + "-" + pad(c[1], 2) + "-" + pad(c[2], 2)
    }

    private fun serialToText(v: Double, f: DateFmt, date1904: Boolean): String {
        if (f.elapsed && !f.hasDate) {
            val total = Math.round(v * 86400)
            return (total / 3600).toString() + ":" + pad(((total / 60) % 60).toInt(), 2) + ":" + pad((total % 60).toInt(), 2)
        }
        var days = Math.floor(v).toLong()
        var secs = Math.round((v - days) * 86400)
        if (secs >= 86400) { days++; secs -= 86400 }
        val sb = StringBuilder()
        if (f.hasDate) sb.append(excelDate(days, date1904))
        if (f.hasTime) {
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(pad((secs / 3600).toInt(), 2)).append(':').append(pad(((secs / 60) % 60).toInt(), 2))
            if (f.seconds || secs % 60 != 0L) sb.append(':').append(pad((secs % 60).toInt(), 2))
        }
        return sb.toString()
    }

    /** Excel's "General": at most 15 significant digits, no trailing zeros, scientific only for very large / small values. */
    internal fun generalNumber(raw: String): String {
        val bd = raw.trim().toBigDecimalOrNull() ?: return raw
        if (bd.signum() == 0) return "0"
        val r = bd.round(java.math.MathContext(15, java.math.RoundingMode.HALF_UP)).stripTrailingZeros()
        val abs = r.abs()
        return if (abs >= java.math.BigDecimal("1E15") || abs < java.math.BigDecimal("1E-9")) r.toString() else r.toPlainString()
    }

    private fun splitSections(code: String): List<String> {
        val out = ArrayList<String>()
        val cur = StringBuilder()
        var quoted = false
        var i = 0
        while (i < code.length) {
            val c = code[i]
            if (c == '"') quoted = !quoted
            if (c == '\\' && i + 1 < code.length) { cur.append(c).append(code[i + 1]); i += 2; continue }
            if (c == ';' && !quoted) { out.add(cur.toString()); cur.setLength(0) } else cur.append(c)
            i++
        }
        out.add(cur.toString())
        return out
    }

    /**
     * A number through the SIMPLE number formats: `0`, `0.00`, `#,##0.00`, percent, with literal text or a currency sign before / after, and a separate negative section.
     * Null (= use General) for what is not that: scientific, fractions, text, scaling commas, conditions. The caller has already ruled out dates.
     */
    internal fun formatNumber(raw: String, code: String): String? {
        val bd = raw.trim().toBigDecimalOrNull() ?: return null
        val sections = splitSections(code)
        val neg = bd.signum() < 0
        val sec = when {
            neg && sections.size >= 2 -> sections[1]
            bd.signum() == 0 && sections.size >= 3 -> sections[2]
            else -> sections[0]
        }
        val prefix = StringBuilder()
        val suffix = StringBuilder()
        val core = StringBuilder()
        var percent = false
        var stage = 0   // 0 before the digits, 1 inside, 2 after
        fun lit(s: String) { if (stage == 1) stage = 2; (if (stage == 0) prefix else suffix).append(s) }
        var i = 0
        while (i < sec.length) {
            val c = sec[i]
            when {
                c == '"' -> {
                    val e = sec.indexOf('"', i + 1)
                    if (e < 0) return null
                    lit(sec.substring(i + 1, e)); i = e
                }
                c == '\\' && i + 1 < sec.length -> { lit(sec[i + 1].toString()); i++ }
                c == '_' && i + 1 < sec.length -> { lit(" "); i++ }
                c == '*' && i + 1 < sec.length -> i++
                c == '[' -> {
                    val e = sec.indexOf(']', i + 1)
                    if (e < 0) return null
                    val inner = sec.substring(i + 1, e)
                    if (inner.startsWith("$")) lit(inner.substring(1).substringBefore('-'))
                    else if (inner.startsWith("<") || inner.startsWith(">") || inner.startsWith("=")) return null
                    i = e
                }
                c == '0' || c == '#' || c == '?' || c == '.' || c == ',' -> {
                    if (stage == 2) return null
                    stage = 1
                    core.append(c)
                }
                c == '%' -> { percent = true; lit("%") }
                c == ' ' || c == '-' || c == '+' || c == '(' || c == ')' || c == ':' || c == '$' || c == '\u20AC' || c == '\u00A3' || c == '\u00A5' || c == '\u20AB' -> lit(c.toString())
                else -> return null
            }
            i++
        }
        val spec = core.toString()
        if (spec.isEmpty() || spec.endsWith(",") || spec.contains(",.") || spec.count { it == '.' } > 1) return null
        val intSpec = spec.substringBefore('.')
        val fracSpec = if (spec.contains('.')) spec.substringAfter('.') else ""
        if (fracSpec.contains(',')) return null
        val minInt = intSpec.count { it == '0' }
        val grouping = intSpec.contains(',')
        val decimals = fracSpec.length
        val mandatory = fracSpec.count { it == '0' }
        var v = if (neg) bd.abs() else bd
        if (percent) v = v.multiply(java.math.BigDecimal(100))
        val plain = v.setScale(decimals, java.math.RoundingMode.HALF_UP).toPlainString()
        var intPart = plain.substringBefore('.')
        var frac = if (plain.contains('.')) plain.substringAfter('.') else ""
        while (frac.length > mandatory && frac.endsWith("0")) frac = frac.substring(0, frac.length - 1)
        if (intPart == "0" && minInt == 0 && frac.isNotEmpty()) intPart = ""
        while (intPart.length < minInt) intPart = "0$intPart"
        if (grouping && intPart.length > 3) {
            val g = StringBuilder()
            for ((k, ch) in intPart.withIndex()) {
                if (k > 0 && (intPart.length - k) % 3 == 0) g.append(',')
                g.append(ch)
            }
            intPart = g.toString()
        }
        val body = prefix.toString() + intPart + (if (frac.isNotEmpty()) ".$frac" else "") + suffix.toString()
        return if (neg && sections.size < 2) "-$body" else body
    }

    private fun xlsxStyleCodes(styles: String): List<String> {
        val custom = HashMap<Int, String>()
        val ids = ArrayList<Int>()
        var inCellXfs = false
        scanXml(styles, object : XmlHandler() {
            override fun start(name: String, attrs: Map<String, String>) {
                when (name) {
                    "numFmt" -> { val id = attrs["numFmtId"]?.toIntOrNull(); val code = attrs["formatCode"]; if (id != null && code != null) custom[id] = code }
                    "cellXfs" -> inCellXfs = true
                    "xf" -> if (inCellXfs) ids.add(attrs["numFmtId"]?.toIntOrNull() ?: 0)
                }
            }
            override fun end(name: String) { if (name == "cellXfs") inCellXfs = false }
        }, stripPrefix = true)
        return ids.map { custom[it] ?: builtinFormat(it) }
    }

    private fun xlsxSharedStrings(xml: String): List<String> {
        val out = ArrayList<String>()
        val sb = StringBuilder()
        var inSi = false
        var inT = false
        var phonetic = 0
        scanXml(xml, object : XmlHandler() {
            override fun start(name: String, attrs: Map<String, String>) {
                when (name) {
                    "si" -> { inSi = true; sb.setLength(0) }
                    "rPh" -> phonetic++
                    "t" -> inT = true
                }
            }
            override fun end(name: String) {
                when (name) {
                    "t" -> inT = false
                    "rPh" -> phonetic--
                    "si" -> { out.add(sb.toString()); inSi = false }
                }
            }
            override fun text(t: String) { if (inSi && inT && phonetic == 0) sb.append(t) }
        }, stripPrefix = true)
        return out
    }

    /** 0-based column of a cell reference such as "AB12"; -1 when it has no letters. */
    internal fun columnIndex(ref: String): Int {
        var n = 0
        var letters = 0
        for (ch in ref) {
            if (ch in 'A'..'Z') { n = n * 26 + (ch - 'A' + 1); letters++ }
            else if (ch in 'a'..'z') { n = n * 26 + (ch - 'a' + 1); letters++ }
            else break
        }
        return if (letters == 0) -1 else n - 1
    }

    private const val MAX_ROWS = 100000
    private const val MAX_COLS = 1024

    private fun xlsxRows(xml: String, sst: List<String>, codes: List<String>, dates: List<DateFmt?>, date1904: Boolean): List<List<String>> {
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        var col = 0
        var type = ""
        var style = 0
        val v = StringBuilder()
        val inline = StringBuilder()
        var inV = false
        var inIs = false
        var inT = false
        var phonetic = 0
        scanXml(xml, object : XmlHandler() {
            override fun start(name: String, attrs: Map<String, String>) {
                when (name) {
                    "row" -> row = ArrayList()
                    "c" -> {
                        col = attrs["r"]?.let { columnIndex(it) }?.takeIf { it >= 0 } ?: row.size
                        type = attrs["t"] ?: ""
                        style = attrs["s"]?.toIntOrNull() ?: 0
                        v.setLength(0); inline.setLength(0)
                    }
                    "v" -> inV = true
                    "is" -> inIs = true
                    "rPh" -> phonetic++
                    "t" -> if (inIs) inT = true
                }
            }

            override fun end(name: String) {
                when (name) {
                    "v" -> inV = false
                    "is" -> inIs = false
                    "t" -> inT = false
                    "rPh" -> phonetic--
                    "c" -> {
                        if (col >= MAX_COLS) return
                        val raw = v.toString().trim()
                        val text = when (type) {
                            "s" -> raw.toIntOrNull()?.let { sst.getOrNull(it) } ?: ""
                            "str", "e", "d" -> v.toString()
                            "inlineStr" -> inline.toString()
                            "b" -> if (raw.isEmpty()) "" else if (raw == "1") "TRUE" else "FALSE"
                            else -> if (raw.isEmpty()) "" else {
                                val d = dates.getOrNull(style)
                                val dv = raw.toDoubleOrNull()
                                if (d != null && dv != null) serialToText(dv, d, date1904)
                                else {
                                    val code = codes.getOrNull(style) ?: "General"
                                    if (code == "General") generalNumber(raw) else (formatNumber(raw, code) ?: generalNumber(raw))
                                }
                            }
                        }
                        while (row.size < col) row.add("")
                        if (row.size == col) row.add(text) else row[col] = text
                    }
                    "row" -> {
                        var last = row.size
                        while (last > 0 && row[last - 1].isEmpty()) last--
                        if (last > 0 && rows.size < MAX_ROWS) rows.add(ArrayList(row.subList(0, last)))
                    }
                }
            }

            override fun text(t: String) {
                if (inV) v.append(t)
                else if (inIs && inT && phonetic == 0) inline.append(t)
            }
        }, stripPrefix = true)
        return rows
    }

    private fun relId(attrs: Map<String, String>): String? = attrs.entries.firstOrNull { it.key.endsWith(":id") }?.value

    /** The visible sheets of an .xlsx in workbook order, each with its non-empty rows; empty sheets are left out. */
    fun sheetsFromXlsx(input: InputStream): List<Sheet> {
        val t = zipTexts(input) {
            it == "xl/workbook.xml" || it == "xl/_rels/workbook.xml.rels" || it == "xl/sharedStrings.xml" || it == "xl/styles.xml" ||
                (it.startsWith("xl/worksheets/") && it.endsWith(".xml"))
        } ?: return emptyList()
        val workbook = t["xl/workbook.xml"] ?: return emptyList()
        val rels = HashMap<String, String>()
        t["xl/_rels/workbook.xml.rels"]?.let { r ->
            scanXml(r, object : XmlHandler() {
                override fun start(name: String, attrs: Map<String, String>) {
                    if (name == "Relationship") {
                        val id = attrs["Id"]
                        val target = attrs["Target"]
                        if (id != null && target != null) rels[id] = if (target.startsWith("/")) target.substring(1) else "xl/$target"
                    }
                }
            }, stripPrefix = true)
        }
        class Ref(val name: String, val path: String?)
        val refs = ArrayList<Ref>()
        var date1904 = false
        scanXml(workbook, object : XmlHandler() {
            override fun start(name: String, attrs: Map<String, String>) {
                when (name) {
                    "workbookPr" -> date1904 = attrs["date1904"] == "1" || attrs["date1904"] == "true"
                    "sheet" -> if (attrs["state"] != "hidden" && attrs["state"] != "veryHidden") refs.add(Ref(attrs["name"] ?: "", relId(attrs)?.let { rels[it] }))
                }
            }
        }, stripPrefix = true)
        val sst = t["xl/sharedStrings.xml"]?.let { xlsxSharedStrings(it) } ?: emptyList()
        val codes = t["xl/styles.xml"]?.let { xlsxStyleCodes(it) } ?: emptyList()
        val dates = codes.map { classifyDate(it) }
        val out = ArrayList<Sheet>()
        for (r in refs) {
            val xml = r.path?.let { t[it] } ?: continue
            val rows = xlsxRows(xml, sst, codes, dates, date1904)
            if (rows.isNotEmpty()) out.add(Sheet(r.name, rows))
        }
        return out
    }
}
