package com.example.docscanner.util

import java.io.OutputStream
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * A minimal OpenDocument Text (.odt) file: opens in LibreOffice, OpenOffice, Word, Google Docs and Apple Pages (phiên 24, PDF list 10.4; TECHNICAL_DOCS.md 4.65). Text only, like
 * [DocxWriter]: the title as Heading 1, "Trang N" as Heading 2 per page (page break before every page after the first), one paragraph per block from
 * [DocxWriter.paragraphsFromText]; A4, Vietnamese official-document margins, Times New Roman 13 pt.
 *
 * Package rules that readers are strict about, all kept here: `mimetype` is the FIRST entry and is STORED (not compressed), without a trailing newline or extra field; the manifest lists
 * every part; XML is escaped by [DocxWriter.escape] (which also removes characters XML 1.0 forbids). `tools/verify/text_formats_check.py` validates the result with odfpy,
 * pandoc and LibreOffice (which converts it to PDF), none of which share code with this file.
 */
object OdtWriter {

    private const val MIMETYPE = "application/vnd.oasis.opendocument.text"

    private const val NS = "xmlns:office=\"urn:oasis:names:tc:opendocument:xmlns:office:1.0\" " +
        "xmlns:text=\"urn:oasis:names:tc:opendocument:xmlns:text:1.0\" " +
        "xmlns:style=\"urn:oasis:names:tc:opendocument:xmlns:style:1.0\" " +
        "xmlns:fo=\"urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0\" " +
        "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" " +
        "xmlns:meta=\"urn:oasis:names:tc:opendocument:xmlns:meta:1.0\" " +
        "xmlns:manifest=\"urn:oasis:names:tc:opendocument:xmlns:manifest:1.0\""

    fun write(title: String, pages: List<String>, out: OutputStream) {
        val zip = ZipOutputStream(out)
        val mime = MIMETYPE.toByteArray(Charsets.US_ASCII)
        val first = ZipEntry("mimetype")
        first.method = ZipEntry.STORED
        first.size = mime.size.toLong()
        first.compressedSize = mime.size.toLong()
        val crc = CRC32()
        crc.update(mime)
        first.crc = crc.value
        zip.putNextEntry(first)
        zip.write(mime)
        zip.closeEntry()
        put(zip, "META-INF/manifest.xml", manifestXml())
        put(zip, "meta.xml", metaXml(title))
        put(zip, "styles.xml", stylesXml())
        put(zip, "content.xml", contentXml(title, pages))
        zip.finish()
        zip.flush()
    }

    private fun put(zip: ZipOutputStream, name: String, xml: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(xml.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    fun manifestXml(): String =
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<manifest:manifest $NS manifest:version=\"1.2\">\n" +
            "<manifest:file-entry manifest:full-path=\"/\" manifest:version=\"1.2\" manifest:media-type=\"$MIMETYPE\"/>\n" +
            "<manifest:file-entry manifest:full-path=\"content.xml\" manifest:media-type=\"text/xml\"/>\n" +
            "<manifest:file-entry manifest:full-path=\"styles.xml\" manifest:media-type=\"text/xml\"/>\n" +
            "<manifest:file-entry manifest:full-path=\"meta.xml\" manifest:media-type=\"text/xml\"/>\n" +
            "</manifest:manifest>\n"

    fun metaXml(title: String): String =
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<office:document-meta $NS office:version=\"1.2\"><office:meta>" +
            "<dc:title>" + DocxWriter.escape(title.replace('\n', ' ')) + "</dc:title>" +
            "<meta:generator>DocScanner</meta:generator>" +
            "</office:meta></office:document-meta>\n"

    fun stylesXml(): String =
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<office:document-styles $NS office:version=\"1.2\">\n" +
            "<office:styles>\n" +
            "<style:default-style style:family=\"paragraph\"><style:paragraph-properties fo:margin-top=\"0cm\" fo:margin-bottom=\"0.28cm\"/>" +
            "<style:text-properties fo:font-family=\"'Times New Roman'\" fo:font-size=\"13pt\"/></style:default-style>\n" +
            "<style:style style:name=\"Standard\" style:family=\"paragraph\" style:class=\"text\"/>\n" +
            "<style:style style:name=\"Heading_20_1\" style:display-name=\"Heading 1\" style:family=\"paragraph\" style:parent-style-name=\"Standard\" style:class=\"text\">" +
            "<style:paragraph-properties fo:text-align=\"center\" fo:margin-bottom=\"0.4cm\"/><style:text-properties fo:font-size=\"18pt\" fo:font-weight=\"bold\"/></style:style>\n" +
            "<style:style style:name=\"Heading_20_2\" style:display-name=\"Heading 2\" style:family=\"paragraph\" style:parent-style-name=\"Standard\" style:class=\"text\">" +
            "<style:text-properties fo:font-size=\"13pt\" fo:font-weight=\"bold\"/></style:style>\n" +
            "</office:styles>\n" +
            "<office:automatic-styles>\n" +
            "<style:page-layout style:name=\"pm1\"><style:page-layout-properties fo:page-width=\"21cm\" fo:page-height=\"29.7cm\" " +
            "fo:margin-left=\"3cm\" fo:margin-right=\"2cm\" fo:margin-top=\"2cm\" fo:margin-bottom=\"2cm\"/></style:page-layout>\n" +
            "</office:automatic-styles>\n" +
            "<office:master-styles><style:master-page style:name=\"Standard\" style:page-layout-name=\"pm1\"/></office:master-styles>\n" +
            "</office:document-styles>\n"

    fun contentXml(title: String, pages: List<String>): String {
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<office:document-content ").append(NS).append(" office:version=\"1.2\">\n")
        sb.append("<office:automatic-styles>")
        sb.append("<style:style style:name=\"PageBreak\" style:family=\"paragraph\" style:parent-style-name=\"Heading_20_2\">")
        sb.append("<style:paragraph-properties fo:break-before=\"page\"/></style:style>")
        sb.append("</office:automatic-styles>\n")
        sb.append("<office:body><office:text>\n")
        sb.append("<text:h text:style-name=\"Heading_20_1\" text:outline-level=\"1\">").append(DocxWriter.escape(title.replace('\n', ' '))).append("</text:h>\n")
        for ((i, page) in pages.withIndex()) {
            val style = if (i == 0) "Heading_20_2" else "PageBreak"
            sb.append("<text:h text:style-name=\"").append(style).append("\" text:outline-level=\"2\">Trang ").append(i + 1).append("</text:h>\n")
            for (p in DocxWriter.paragraphsFromText(page)) {
                if (p == DocxWriter.PAGE_BREAK) continue
                sb.append("<text:p text:style-name=\"Standard\">").append(spaces(DocxWriter.escape(p))).append("</text:p>\n")
            }
        }
        sb.append("</office:text></office:body></office:document-content>\n")
        return sb.toString()
    }

    /** ODF collapses runs of spaces; a run of two or more is written with `<text:s text:c="n"/>` so the text comes out exactly as it went in. */
    private fun spaces(text: String): String {
        if (!text.contains("  ") && !text.startsWith(' ') && !text.endsWith(' ') && !text.contains('\t')) return text
        val sb = StringBuilder(text.length + 16)
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (ch == ' ') {
                var j = i
                while (j < text.length && text[j] == ' ') j++
                val run = j - i
                if (run == 1 && i > 0 && i < text.length - 1) sb.append(' ') else sb.append("<text:s text:c=\"").append(run).append("\"/>")
                i = j
            } else if (ch == '\t') {
                sb.append("<text:tab/>")
                i++
            } else {
                sb.append(ch)
                i++
            }
        }
        return sb.toString()
    }
}
