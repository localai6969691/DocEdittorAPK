package com.example.docscanner.util

import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSBase
import com.tom_roush.pdfbox.cos.COSDictionary
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSStream
import com.tom_roush.pdfbox.cos.COSString
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDDocumentInformation
import com.tom_roush.pdfbox.pdmodel.font.PDType3Font
import java.io.File
import java.security.SecureRandom
import java.util.Calendar

/**
 * "Chuyển sang PDF/A" (phiên 17, mục 4.31): rewrites a PDF as PDF/A-2b (ISO 19005-2, level B) for archiving and for offices that require it.
 * Item B1 of the PDF "Thiếu gì để bán app".
 *
 * What PDF/A needs, and what this does: (1) an XMP metadata stream declaring `pdfaid:part=2` / `conformance=B` that AGREES with the Info dictionary - [PdfAXmp];
 * (2) an OutputIntent `GTS_PDFA1` with an embedded sRGB ICC profile - [SrgbIcc]; (3) every font embedded; (4) no encryption, no LZW, no JavaScript / launch actions,
 * no embedded files, no CMYK without a CMYK intent, every annotation (except Link / Popup) with an appearance stream and the Print flag on, Hidden / NoView off;
 * (5) a file ID and a header of at most 1.7. Items (1), (2), (5) and the "JavaScript / launch / flags" part of (4) are WRITTEN here; the rest cannot be fixed without
 * changing what the document shows, so [preflight] reports them as BLOCKERS and [convert] refuses (the PDFs made by this app - scanned pages as images, OCR text in an
 * invisible Type3 font, annotations made by [PdfTextMarkup] and [PdfStamper] - have none). Blocker codes: encrypted, version, font_not_embedded, lzw, cmyk, embedded_file, annot_no_ap.
 *
 * It saves with PdfBox's plain `doc.save`, NOT [PdfStructureOptimizer]: that writer recompresses streams and could put a filter on the XMP stream.
 * Only page-level fonts and the object graph are scanned (a font used only inside a form XObject is not seen). Verified: the same steps in
 * tools/verify/pdfa_sample.py (built from the Java mirrors of the ICC and XMP code), checked by tools/verify/pdfa_check.py and, in CI, by veraPDF (job `pdfa`).
 * Honest limit: the Kotlin below has not been compiled or run; veraPDF has not been run on its output - only on the Python assembly of the same recipe.
 */
object PdfAConverter {

    class Findings(val blockers: Set<String>, val fixes: Set<String>)

    class BlockedException(val blockers: Set<String>) : Exception(blockers.sorted().joinToString(","))

    private fun name(s: String) = COSName.getPDFName(s)

    private fun filterNames(stream: COSStream): List<String> {
        val f = stream.getDictionaryObject("Filter") ?: return emptyList()
        return when (f) {
            is COSName -> listOf(f.name)
            is COSArray -> (0 until f.size()).mapNotNull { (f.getObject(it) as? COSName)?.name }
            else -> emptyList()
        }
    }

    private fun annotations(page: COSDictionary): List<COSDictionary> {
        val arr = page.getDictionaryObject("Annots") as? COSArray ?: return emptyList()
        return (0 until arr.size()).mapNotNull { arr.getObject(it) as? COSDictionary }
    }

    private fun isBadAction(action: COSBase?): Boolean {
        val d = action as? COSDictionary ?: return false
        val s = d.getNameAsString("S")
        return s == "JavaScript" || s == "Launch" || s == "Sound" || s == "Movie" || s == "ResetForm" || s == "ImportData"
    }

    fun preflight(doc: PDDocument): Findings {
        val blockers = HashSet<String>()
        val fixes = HashSet<String>()
        if (doc.isEncrypted) blockers.add("encrypted")
        if (doc.version > 1.7f) blockers.add("version")
        for (o in doc.document.objects) {
            val b = o.getObject() as? COSStream ?: continue
            if ("LZWDecode" in filterNames(b)) blockers.add("lzw")
            if (b.getNameAsString("Subtype") == "Image" && (b.getDictionaryObject("ColorSpace") as? COSName)?.name == "DeviceCMYK") blockers.add("cmyk")
        }
        for (i in 0 until doc.numberOfPages) {
            val page = doc.getPage(i)
            val res = page.resources
            if (res != null) {
                for (fontName in res.fontNames) {
                    val font = try { res.getFont(fontName) } catch (t: Throwable) { null }
                    if (font == null) { blockers.add("font_not_embedded"); continue }
                    if (font is PDType3Font) continue
                    if (!font.isEmbedded) blockers.add("font_not_embedded")
                }
            }
            for (a in annotations(page.cosObject)) {
                val sub = a.getNameAsString("Subtype")
                val flags = a.getInt("F", 0)
                if (sub != "Link" && sub != "Popup" && a.getDictionaryObject("AP") == null) blockers.add("annot_no_ap")
                if ((flags and 2) != 0 || (flags and 32) != 0 || (flags and 4) == 0) fixes.add("annot_flags")   // Hidden, NoView on, or Print off
                if (isBadAction(a.getDictionaryObject("A"))) fixes.add("openaction")
            }
        }
        val catalog = doc.documentCatalog.cosObject
        val names = catalog.getDictionaryObject("Names") as? COSDictionary
        if (names != null && names.containsKey("EmbeddedFiles")) blockers.add("embedded_file")
        if (names != null && names.containsKey("JavaScript")) fixes.add("javascript")
        if (isBadAction(catalog.getDictionaryObject("OpenAction")) || catalog.containsKey("AA")) fixes.add("openaction")
        return Findings(blockers, fixes)
    }

    /**
     * @param title used only when the file has no title of its own (the file name is a good one).
     * @return what was found and fixed. Throws [BlockedException] when something blocks conversion, `IllegalStateException("encrypted")`
     * for a protected file, `IllegalStateException("output failed verification")` if the result does not reopen.
     */
    fun convert(src: File, out: File, title: String, author: String = "", now: Calendar = Calendar.getInstance()): Findings {
        val doc = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
        try {
            if (doc.isEncrypted) throw IllegalStateException("encrypted")
            val findings = preflight(doc)
            if (findings.blockers.isNotEmpty()) throw BlockedException(findings.blockers)
            val pages = doc.numberOfPages
            val catalog = doc.documentCatalog.cosObject

            // 1. Info dictionary + XMP built from the SAME values
            val info = doc.documentInformation ?: PDDocumentInformation()
            val created = info.creationDate ?: now
            val docTitle = info.title?.takeIf { it.isNotBlank() } ?: title
            val docAuthor = info.author?.takeIf { it.isNotBlank() } ?: author
            val producer = info.producer?.takeIf { it.isNotBlank() } ?: "DocScanner"
            val tool = info.creator?.takeIf { it.isNotBlank() } ?: "DocScanner"
            info.title = docTitle
            if (docAuthor.isNotEmpty()) info.author = docAuthor
            info.producer = producer
            info.creator = tool
            info.cosObject.setString("CreationDate", PdfAXmp.infoDate(created))
            info.cosObject.setString("ModDate", PdfAXmp.infoDate(now))
            doc.documentInformation = info
            val metadata = doc.document.createCOSStream()
            metadata.setItem("Type", name("Metadata"))
            metadata.setItem("Subtype", name("XML"))
            metadata.createOutputStream().use { it.write(PdfAXmp.packet(docTitle, docAuthor, producer, tool, created, now).toByteArray(Charsets.UTF_8)) }
            catalog.setItem("Metadata", metadata)

            // 2. OutputIntent with the embedded sRGB profile (kept if the file already has a PDF/A one)
            val existing = catalog.getDictionaryObject("OutputIntents") as? COSArray
            val hasPdfaIntent = existing != null && (0 until existing.size()).any { (existing.getObject(it) as? COSDictionary)?.getNameAsString("S") == "GTS_PDFA1" }
            if (!hasPdfaIntent) {
                val profile = doc.document.createCOSStream()
                profile.setInt("N", 3)
                profile.createOutputStream().use { it.write(SrgbIcc.build()) }
                val intent = COSDictionary().apply {
                    setItem("Type", name("OutputIntent"))
                    setItem("S", name("GTS_PDFA1"))
                    setString("OutputConditionIdentifier", "sRGB IEC61966-2.1")
                    setString("Info", "sRGB IEC61966-2.1")
                    setItem("DestOutputProfile", profile)
                }
                catalog.setItem("OutputIntents", COSArray().apply { add(intent) })
            }

            // 3. what the standard forbids and can be removed without changing what the pages show
            catalog.removeItem(name("AA"))
            if (isBadAction(catalog.getDictionaryObject("OpenAction"))) catalog.removeItem(name("OpenAction"))
            (catalog.getDictionaryObject("Names") as? COSDictionary)?.removeItem(name("JavaScript"))
            for (i in 0 until pages) {
                for (a in annotations(doc.getPage(i).cosObject)) {
                    a.setInt("F", (a.getInt("F", 0) or 4) and 2.inv() and 32.inv())
                    if (isBadAction(a.getDictionaryObject("A"))) a.removeItem(name("A"))
                    a.removeItem(name("AA"))
                }
            }

            // 4. file ID (required in PDF/A) if the file has none
            val trailer = doc.document.trailer
            val id = trailer.getDictionaryObject("ID") as? COSArray
            if (id == null || id.size() != 2) {
                val bytes = ByteArray(16).also { SecureRandom().nextBytes(it) }
                trailer.setItem("ID", COSArray().apply { add(COSString(bytes)); add(COSString(bytes)) })
            }

            doc.save(out)
            if (!PdfVerify.opensAsPdf(out, pages)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
            return findings
        } finally {
            runCatching { doc.close() }
        }
    }
}
