package com.example.docscanner.util

/**
 * Business card -> contact. [parse] reads the OCR text of a card line by line: e-mail addresses and phone numbers by the same patterns
 * the redaction tool uses ([PiiDetector]), web addresses, then the company (a line with Công ty / TNHH / Cổ phần / JSC / Corp / Ltd...), the
 * job title (Giám đốc, Trưởng phòng, Manager, Director, Kỹ sư...), the address (a line with Đường / Phường / Quận / TP. / Street / Tầng... AND a
 * digit or a comma, so a name such as "Lê Quân Việt" is not an address; or a line that starts with "Số 12") and, among what is left, the name
 * (2-5 capitalised words without digits). A slogan in Title Case would also look like a name: the first such line wins. [toVCard] writes it as vCard 3.0 (RFC 2426) for any contacts app.
 *
 * Heuristics, not certainty: a card's layout is free, so the screen hands the result to the system "add contact" form where the user
 * corrects it. Pure Kotlin; `tools/verify/ExtractCheck.java` is a Java copy checked by `extract_check.py`, which also reads the vCard back
 * with an independent RFC 2426 parser.
 */
object ContactCard {

    class Contact(
        val name: String, val title: String, val company: String,
        val phones: List<String>, val emails: List<String>, val websites: List<String>, val address: String
    )

    private val COMPANY = listOf("cong ty ", "tnhh", "co phan", "jsc", "corp", "ltd", "company", "inc.", "group", "tap doan", "doanh nghiep")
    private val TITLE = listOf(
        "giam doc", "truong phong", "pho phong", "chuyen vien", "ky su", "chu tich", "luat su", "bac si", "ke toan",
        "manager", "director", "ceo", "cto", "cfo", "coo", "engineer", "developer", "consultant", "specialist", "president", "executive", "supervisor", "assistant"
    )
    private val ADDRESS = listOf("duong ", "pho ", "quan ", "phuong ", "huyen ", "tp.", "thanh pho", "tinh ", "tang ", "toa nha", "street", "road", "ward", "district", "floor", "building")
    private val FAX = Regex("""\bfax\b""")
    private val WEBSITE = Regex("""(?:https?://)?(?:www\.)?[a-z0-9][a-z0-9\-]*(?:\.[a-z0-9\-]+)*\.(?:com|vn|net|org|edu|gov|io|info|biz|asia)(?:/[^\s,;]*)?""")
    private val ADDRESS_NUMBER = Regex("""^so \d""")
    private val LABEL_PREFIX = Regex("""^(?:tel|dt|d/t|di dong|mobile|mob|phone|hotline|email|e-mail|mail|web|website|www|add|address|dia chi|fax)\s*[:.]\s*""")

    fun parse(text: String): Contact {
        val lines = text.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
        val emails = ArrayList<String>()
        val phones = ArrayList<String>()
        val websites = ArrayList<String>()
        val used = BooleanArray(lines.size)
        for ((i, line) in lines.withIndex()) {
            val folded = PiiDetector.foldLower(line)
            val matches = PiiDetector.find(line, setOf(PiiDetector.Kind.EMAIL, PiiDetector.Kind.PHONE))
            val rest = StringBuilder(folded)
            for (m in matches) {
                val value = line.substring(m.start, m.end).trim()
                if (m.kind == PiiDetector.Kind.EMAIL) {
                    if (value !in emails) emails.add(value)
                } else if (value !in phones && !FAX.containsMatchIn(folded.substring(maxOf(0, m.start - 8), m.start))) {
                    // a number right after the word "Fax" is the fax machine, not a phone ("Tel: ... Fax: ..." share a line)
                    phones.add(value)
                }
                for (k in m.start until m.end) rest.setCharAt(k, ' ')
                used[i] = true
            }
            for (m in WEBSITE.findAll(rest.toString())) {
                if (m.value.contains('@')) continue
                // cut from the ORIGINAL line (same offsets): a card prints "www.AbcCorp.vn/Lien-He" and that is what the contact should keep
                val printed = line.substring(m.range.first, m.range.last + 1)
                if (printed !in websites) websites.add(printed)
                used[i] = true
            }
        }
        var company = ""
        var title = ""
        val addressLines = ArrayList<String>()
        for ((i, line) in lines.withIndex()) {
            if (used[i]) continue
            val folded = PiiDetector.foldLower(line)
            when {
                company.isEmpty() && COMPANY.any { folded.contains(it) } -> { company = line; used[i] = true }
                title.isEmpty() && TITLE.any { folded.contains(it) } -> { title = line; used[i] = true }
                (ADDRESS.any { folded.contains(it) } && (line.any { c -> c.isDigit() } || line.contains(','))) || ADDRESS_NUMBER.containsMatchIn(folded) -> {
                    // the label ("Địa chỉ:") is found on the folded copy, cut from the original (same length)
                    val label = LABEL_PREFIX.find(folded)
                    addressLines.add(if (label != null) line.substring(label.range.last + 1) else line)
                    used[i] = true
                }
            }
        }
        var name = ""
        for ((i, line) in lines.withIndex()) {
            if (used[i] || line.any { it.isDigit() }) continue
            val words = line.split(' ').filter { it.isNotEmpty() }
            if (words.size in 2..5 && words.all { it[0].isUpperCase() } && line.count { it.isLetter() } >= 4) { name = line; break }
        }
        return Contact(name, title, company, phones, emails, websites, addressLines.joinToString(", "))
    }

    /** vCard 3.0: `N` (family name = first word, the Vietnamese order), `FN`, `ORG`, `TITLE`, `TEL`, `EMAIL`, `URL`, `ADR`; CRLF line ends, lines folded at 75 bytes. */
    fun toVCard(c: Contact): String {
        val lines = ArrayList<String>()
        lines.add("BEGIN:VCARD")
        lines.add("VERSION:3.0")
        val words = c.name.split(' ').filter { it.isNotEmpty() }
        val family = words.firstOrNull() ?: ""
        val given = if (words.size > 1) words.drop(1).joinToString(" ") else ""
        lines.add("N:${escape(family)};${escape(given)};;;")
        lines.add("FN:${escape(c.name.ifEmpty { c.company.ifEmpty { c.emails.firstOrNull() ?: c.phones.firstOrNull() ?: "" } })}")
        if (c.company.isNotEmpty()) lines.add("ORG:${escape(c.company)}")
        if (c.title.isNotEmpty()) lines.add("TITLE:${escape(c.title)}")
        for (p in c.phones) lines.add("TEL;TYPE=VOICE:${escape(p)}")
        for (e in c.emails) lines.add("EMAIL;TYPE=INTERNET:${escape(e)}")
        for (w in c.websites) lines.add("URL:${escape(w)}")
        if (c.address.isNotEmpty()) lines.add("ADR;TYPE=WORK:;;${escape(c.address)};;;;")
        lines.add("END:VCARD")
        return lines.joinToString("") { fold(it) + "\r\n" }
    }

    /** Escapes a vCard text value: backslash, semicolon, comma and line breaks. */
    fun escape(value: String): String =
        value.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\r\n", "\\n").replace("\n", "\\n").replace("\r", "\\n")

    /** Folds a content line so no physical line is longer than 75 bytes (UTF-8); a continuation line starts with one space. Never splits a character. */
    fun fold(line: String): String {
        val sb = StringBuilder()
        var bytes = 0
        var limit = 75
        var i = 0
        while (i < line.length) {
            val cp = line.codePointAt(i)
            val len = Character.charCount(cp)
            val size = String(Character.toChars(cp)).toByteArray(Charsets.UTF_8).size
            if (bytes + size > limit) {
                sb.append("\r\n ")
                bytes = 1
                limit = 75
            }
            sb.appendCodePoint(cp)
            bytes += size
            i += len
        }
        return sb.toString()
    }
}
