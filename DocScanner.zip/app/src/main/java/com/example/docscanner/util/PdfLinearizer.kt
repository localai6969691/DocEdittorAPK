package com.example.docscanner.util

import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSBase
import com.tom_roush.pdfbox.cos.COSBoolean
import com.tom_roush.pdfbox.cos.COSDictionary
import com.tom_roush.pdfbox.cos.COSFloat
import com.tom_roush.pdfbox.cos.COSInteger
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSNull
import com.tom_roush.pdfbox.cos.COSObject
import com.tom_roush.pdfbox.cos.COSStream
import com.tom_roush.pdfbox.cos.COSString
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.util.Locale

/**
 * Lop noi PdfBox cho [Linearizer] (phien 18, B12): doc PDF -> do thi doi tuong + than tung doi tuong tuan tu hoa -> tep tuyen tinh hoa ("Fast Web View").
 * Cac buoc PHAN CHIEU tung buoc ban Python trong `tools/verify/linearize_check.py` (pikepdf) - ban Python duoc kiem bang `qpdf --check-linearization`; con LOI GOI PdfBox o day
 * KHONG chay duoc o moi truong phat trien (xem TECHNICAL_DOCS.md 4.42).
 *
 * Quy tac: (1) chi giu cac doi tuong DOI TOI DUOC tu Root / Info (rac bo di); (2) day cac thuoc tinh ke thua (Resources, MediaBox, CropBox, Rotate) tu nut Pages xuong tung trang
 * (Annex F buoc moi trang tu mo ta duoc); (3) tham chieu /Parent va /Thumb cua trang khong dung de phan vung; (4) luong giu nguyen byte tho (bo loc, tham so), chi /Length duoc
 * viet lai thanh so truc tiep; (5) khong luong doi tuong (ObjStm) va khong xref stream: moi thu duoc viet ra o dang co dien; (6) PDF ma hoa bi tu choi; tep qua [MAX_BYTES] bi tu choi
 * vi bo dem cua lop loi giu gan het tep trong bo nho.
 */
object PdfLinearizer {

    const val MAX_BYTES = 100L * 1024 * 1024

    private val INHERIT = listOf(COSName.RESOURCES, COSName.MEDIA_BOX, COSName.CROP_BOX, COSName.ROTATE)
    private val OPEN_KEYS = setOf("ViewerPreferences", "PageMode", "Threads", "OpenAction", "AcroForm")

    /** Tep da co `/Linearized` trong 1024 byte dau (nhin theo byte, khong goi PdfBox). */
    fun isLinearized(file: File): Boolean {
        RandomAccessFile(file, "r").use { raf ->
            val head = ByteArray(minOf(raf.length(), 1024L).toInt()); raf.readFully(head)
            return String(head, Charsets.ISO_8859_1).contains("/Linearized")
        }
    }

    private fun num(o: COSObject): Int = o.objectNumber.toInt()

    /** Cac doi tuong GIAN TIEP ma gia tri [x] tro toi: chinh no neu la tham chieu, nguoc lai cac tham chieu nam trong x (khong di sau vao doi tuong gian tiep). */
    private fun targets(x: COSBase?, out: MutableList<COSObject>, skipKeys: Set<COSName> = emptySet()) {
        when (x) {
            is COSObject -> out.add(x)
            is COSArray -> for (i in 0 until x.size()) targets(x.get(i), out)
            is COSDictionary -> for ((k, v) in x.entrySet()) { if (k in skipKeys) continue; targets(v, out) }
            else -> Unit
        }
    }

    private fun escName(name: String, sb: StringBuilder) {
        sb.append('/')
        for (b in name.toByteArray(Charsets.UTF_8)) {
            val c = (b.toInt() and 0xFF).toChar()
            if (b.toInt() and 0xFF in 0x21..0x7E && "#()<>[]{}/%".indexOf(c) < 0) sb.append(c) else sb.append(String.format(Locale.ROOT, "#%02X", b.toInt() and 0xFF))
        }
    }

    private fun ser(x: COSBase?, sb: StringBuilder, skipKeys: Set<COSName> = emptySet()) {
        when (x) {
            null -> sb.append("null")
            is COSObject -> {
                val target = x.getObject()
                if (target == null || target is COSNull) sb.append("null") else sb.append('\u0001').append(num(x)).append('\u0002')
            }
            is COSName -> escName(x.name, sb)
            is COSString -> { sb.append('<'); for (b in x.bytes) sb.append(String.format(Locale.ROOT, "%02x", b.toInt() and 0xFF)); sb.append('>') }
            is COSInteger -> sb.append(x.longValue())
            is COSFloat -> sb.append(java.math.BigDecimal(java.lang.Float.toString(x.floatValue())).toPlainString())
            is COSBoolean -> sb.append(if (x.value) "true" else "false")
            is COSNull -> sb.append("null")
            is COSArray -> { sb.append('['); for (i in 0 until x.size()) { if (i > 0) sb.append(' '); ser(x.get(i), sb) }; sb.append(']') }
            is COSDictionary -> {
                sb.append("<<")
                for ((k, v) in x.entrySet()) { if (k in skipKeys) continue; escName(k.name, sb); sb.append(' '); ser(v, sb) }
                sb.append(">>")
            }
            else -> throw IOException("kieu doi tuong khong ho tro: " + x.javaClass.simpleName)
        }
    }

    private fun bodyOf(base: COSBase?): Linearizer.Body {
        if (base is COSStream) {
            val raw = base.createRawInputStream().use { it.readBytes() }
            val sb = StringBuilder()
            ser(base, sb, setOf(COSName.LENGTH))
            sb.setLength(sb.length - 2)                                  // bo ">>" cuoi roi them /Length truc tiep
            sb.append(" /Length ").append(raw.size).append(">>")
            return Linearizer.Body(sb.toString(), raw)
        }
        val sb = StringBuilder(); ser(base, sb); return Linearizer.Body(sb.toString(), null)
    }

    /** Ghi ban tuyen tinh hoa cua [src] vao [out]. @return so trang. Loi -> ngoai le va khong de lai [out]. */
    fun linearize(src: File, out: File): Int {
        if (src.length() > MAX_BYTES) throw IllegalStateException("too large")
        val tmp = File(out.path + ".part")
        val doc = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
        try {
            if (doc.isEncrypted) throw IllegalStateException("encrypted")
            val trailer = doc.document.trailer
            val rootRef = trailer.getItem(COSName.ROOT) as? COSObject ?: throw IOException("khong co Root")
            val catalog = rootRef.getObject() as? COSDictionary ?: throw IOException("Root khong phai tu dien")
            val infoRef = trailer.getItem(COSName.INFO) as? COSObject
            val g = Linearizer.Graph()
            g.catalog = num(rootRef); g.info = if (infoRef != null) num(infoRef) else 0

            // 1) cay trang: thu tu trang, cac nut Pages, day thuoc tinh ke thua xuong tung trang
            val pages = ArrayList<COSObject>(); val tree = ArrayList<Int>(); val visited = HashSet<Int>()
            fun walk(ref: COSBase?, inherited: Map<COSName, COSBase>) {
                val r = ref as? COSObject ?: return
                if (!visited.add(num(r))) return
                val d = r.getObject() as? COSDictionary ?: return
                val kids = d.getDictionaryObject(COSName.KIDS) as? COSArray
                if (kids == null) {
                    pages.add(r)
                    for (key in INHERIT) if (d.getItem(key) == null) inherited[key]?.let { d.setItem(key, it) }
                } else {
                    tree.add(num(r))
                    val next = HashMap(inherited)
                    for (key in INHERIT) d.getItem(key)?.let { next[key] = it }
                    for (i in 0 until kids.size()) walk(kids.get(i), next)
                }
            }
            walk(catalog.getItem(COSName.PAGES), emptyMap())
            if (pages.isEmpty()) throw IOException("khong co trang nao")
            g.pages = pages.map { num(it) }; g.pageTree = tree
            val pageNums = g.pages.toSet()

            // 2) kham pha moi doi tuong doi toi duoc tu Root / Info (moi canh, ke ca /Parent), roi do thi dung de phan vung (bo /Parent, /Thumb cua trang)
            val seen = LinkedHashMap<Int, COSObject>(); val queue = ArrayDeque<COSObject>(); queue.addLast(rootRef); infoRef?.let { queue.addLast(it) }
            while (queue.isNotEmpty()) {
                val o = queue.removeFirst(); val n = num(o)
                if (n in seen) continue
                seen[n] = o
                val ts = ArrayList<COSObject>(); targets(o.getObject(), ts, setOf(COSName.LENGTH))
                for (t in ts) queue.addLast(t)
            }
            val thumb = COSName.getPDFName("Thumb")
            for ((n, o) in seen) {
                val ts = ArrayList<COSObject>()
                targets(o.getObject(), ts, if (n in pageNums) setOf(COSName.PARENT, thumb) else setOf(COSName.LENGTH))
                g.refs[n] = ts.map { num(it) }.distinct().filter { it in seen }
            }

            // 3) cac khoa cua catalog: dong tai lieu (phan 4), muc luc, con lai
            val openDoc = ArrayList<COSObject>(); val other = ArrayList<COSObject>()
            for ((k, v) in catalog.entrySet()) {
                val key = k.name
                when {
                    key in OPEN_KEYS -> targets(v, openDoc)
                    key == "Outlines" -> if (v is COSObject) g.outlines = num(v)
                    key == "Pages" -> Unit
                    else -> targets(v, other)
                }
            }
            infoRef?.let { other.add(it) }
            g.openDoc = openDoc.map { num(it) }.distinct(); g.other = other.map { num(it) }.distinct()
            g.useOutlines = catalog.getNameAsString("PageMode") == "UseOutlines"

            // 4) ghi
            val ids = trailer.getDictionaryObject(COSName.ID) as? COSArray
            val id0 = (ids?.getObject(0) as? COSString)?.bytes; val id1 = (ids?.getObject(1) as? COSString)?.bytes
            val version = String.format(Locale.ROOT, "%.1f", doc.version)
            BufferedOutputStream(FileOutputStream(tmp)).use { os ->
                Linearizer.linearize(g, { orig -> bodyOf(seen.getValue(orig).getObject()) }, version, id0, id1, os)
            }
            val count = pages.size
            // kiem lai: mo duoc, du so trang, va qpdf-style: co /Linearized
            val again = PDDocument.load(tmp, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(tmp.parentFile))
            try { if (again.numberOfPages != count) throw IOException("so trang sau khi tuyen tinh hoa khong khop") } finally { runCatching { again.close() } }
            if (!isLinearized(tmp)) throw IOException("khong thay /Linearized")
            if (out.exists() && !out.delete()) throw IOException("khong ghi de duoc dich")
            if (!tmp.renameTo(out)) throw IOException("khong doi ten duoc")
            return count
        } catch (e: Exception) {
            tmp.delete()
            throw e
        } finally { runCatching { doc.close() } }
    }
}
