package com.example.docscanner.util

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.max

/**
 * "Chỉnh tay": five sliders applied AFTER the chosen scan filter (phiên 17, mục 4.31) - the "Chỉnh sửa ảnh thủ công"
 * (brightness / contrast / saturation / sharpen) and "Despeckle" items of the PDF "Thiếu gì để bán app" (A3, A7).
 *
 * Order matters and is fixed: despeckle FIRST (it needs the ink still dark against the paper), then brightness+contrast,
 * saturation, and sharpen LAST (sharpening before a contrast boost would amplify the boost). All sliders at 0 = identity
 * (the very same bitmap is returned, nothing is recomputed).
 *
 *  - Brightness b in -100..100 and contrast c in -100..100 become ONE linear map `out = alpha * (v - 128) + 128 + b * 1.28`:
 *    contrast pivots on mid-grey so 128 stays 128 when only contrast moves. alpha = 1 + c/50 for c >= 0 (up to 3x) and
 *    1 + c/100 for c < 0 (down to 0 = flat grey) - [contrastAlpha].
 *  - Saturation s in -100..100 scales the HSV S channel by (1 + s/100) (s = -100 -> grey).
 *  - Sharpen k in 0..100 is an unsharp mask: `out = v + amount * (v - gaussian(v))` with amount = k / 50 and
 *    sigma = max(0.8, longEdge / 1500), so the radius follows the image size (a 3000 px page needs twice the radius).
 *  - Despeckle level 0..3: [Despeckle] (isolated small ink pieces only, so tone marks and full stops survive).
 *
 * Works on RGB (alpha is dropped and put back) because the brightness/contrast map would otherwise also darken the alpha
 * channel when contrast < 1 and leave a see-through page.
 * The arithmetic of the pure parts is checked by tools/verify/manual_adjust_check.py (numpy / OpenCV-Python and, for
 * [Despeckle], a Java mirror).
 */
object ManualAdjust {

    data class Params(
        val brightness: Int = 0,
        val contrast: Int = 0,
        val saturation: Int = 0,
        val sharpen: Int = 0,
        val despeckle: Int = 0
    ) {
        val isIdentity: Boolean get() = this == Params()
    }

    fun contrastAlpha(contrast: Int): Double =
        if (contrast >= 0) 1.0 + contrast.coerceAtMost(100) / 50.0 else 1.0 + contrast.coerceAtLeast(-100) / 100.0

    fun brightnessBeta(brightness: Int, alpha: Double): Double =
        128.0 - 128.0 * alpha + brightness.coerceIn(-100, 100) * 1.28

    fun saturationFactor(saturation: Int): Double = 1.0 + saturation.coerceIn(-100, 100) / 100.0

    fun sharpenAmount(sharpen: Int): Double = sharpen.coerceIn(0, 100) / 50.0

    fun sharpenSigma(longEdge: Int): Double = max(0.8, longEdge / 1500.0)

    /** Returns [bitmap] itself when [p] is the identity or anything fails; otherwise a NEW bitmap (the caller recycles as usual). */
    fun apply(bitmap: Bitmap, p: Params): Bitmap {
        if (p.isIdentity) return bitmap
        val rgba = Mat()
        val rgb = Mat()
        try {
            Utils.bitmapToMat(bitmap, rgba)
            Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
            val longEdge = max(rgb.cols(), rgb.rows())
            if (p.despeckle > 0) despeckleInPlace(rgb, p.despeckle, longEdge)
            if (p.brightness != 0 || p.contrast != 0) {
                val alpha = contrastAlpha(p.contrast)
                rgb.convertTo(rgb, -1, alpha, brightnessBeta(p.brightness, alpha))
            }
            if (p.saturation != 0) saturateInPlace(rgb, saturationFactor(p.saturation))
            if (p.sharpen > 0) {
                val blur = Mat()
                val out = Mat()
                try {
                    Imgproc.GaussianBlur(rgb, blur, Size(0.0, 0.0), sharpenSigma(longEdge))
                    val a = sharpenAmount(p.sharpen)
                    Core.addWeighted(rgb, 1.0 + a, blur, -a, 0.0, out)
                    out.copyTo(rgb)
                } finally { blur.release(); out.release() }
            }
            Imgproc.cvtColor(rgb, rgba, Imgproc.COLOR_RGB2RGBA)
            val result = Bitmap.createBitmap(rgba.cols(), rgba.rows(), Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(rgba, result)
            return result
        } catch (t: Throwable) {
            return bitmap
        } finally {
            rgba.release(); rgb.release()
        }
    }

    private fun saturateInPlace(rgb: Mat, factor: Double) {
        val hsv = Mat()
        val chans = ArrayList<Mat>()
        try {
            Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)
            Core.split(hsv, chans)
            chans[1].convertTo(chans[1], -1, factor, 0.0)
            Core.merge(chans, hsv)
            Imgproc.cvtColor(hsv, rgb, Imgproc.COLOR_HSV2RGB)
        } finally { hsv.release(); chans.forEach { it.release() } }
    }

    /** Ink = clearly darker than the local paper level (grey dilation = local maximum). Specks are painted with that paper level. */
    private fun despeckleInPlace(rgb: Mat, level: Int, longEdge: Int) {
        val w = rgb.cols()
        val h = rgb.rows()
        val gray = Mat()
        val bg = Mat()
        val diff = Mat()
        val inkMat = Mat()
        val speckMat = Mat()
        val paper = Mat()
        var kernel: Mat? = null
        try {
            Imgproc.cvtColor(rgb, gray, Imgproc.COLOR_RGB2GRAY)
            val r = max(3, longEdge / 250)
            kernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size((2 * r + 1).toDouble(), (2 * r + 1).toDouble()))
            Imgproc.dilate(gray, bg, kernel)
            Core.subtract(bg, gray, diff)
            Imgproc.threshold(diff, inkMat, INK_DIFF, 1.0, Imgproc.THRESH_BINARY)
            val ink = ByteArray(w * h)
            inkMat.get(0, 0, ink)
            val labels = Despeckle.label(ink, w, h)
            val maxArea = Despeckle.maxAreaFor(level, longEdge)
            val speck = Despeckle.findSpecks(labels, w, h, maxArea, Despeckle.gapFor(labels, maxArea, longEdge))
            var any = false
            val mask = ByteArray(w * h)
            for (p in 0 until w * h) { val l = labels.labels[p]; if (l != 0 && speck[l]) { mask[p] = 1; any = true } }
            if (!any) return
            speckMat.create(h, w, CvType.CV_8UC1)
            speckMat.put(0, 0, mask)
            // the anti-aliased halo of a speck is lighter than INK_DIFF: widen the mask by one pixel
            Imgproc.dilate(speckMat, speckMat, Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(3.0, 3.0)))
            Imgproc.dilate(rgb, paper, kernel)
            paper.copyTo(rgb, speckMat)
        } finally {
            kernel?.release()
            gray.release(); bg.release(); diff.release(); inkMat.release(); speckMat.release(); paper.release()
        }
    }

    /** Difference (0..255) between the local paper level and a pixel above which the pixel counts as ink. */
    const val INK_DIFF = 40.0
}
