package com.example.docscanner.util

import android.content.Context
import java.io.File

/**
 * Which exported documents the user starred. Kept by FILE NAME (the export folder is fixed, so a name identifies a
 * file), in a plain preferences file. Starred documents are pinned to the top of the list by [HistoryFilter].
 * [prune] drops names whose file no longer exists, so deleting or renaming a document outside the app does not
 * leave a phantom star behind that would re-appear on a new file with the same name.
 */
object FavoriteStore {

    private const val PREFS = "favorites"
    private const val KEY = "names"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** A copy: the set returned by SharedPreferences must never be modified in place. */
    fun all(context: Context): Set<String> = HashSet(prefs(context).getStringSet(KEY, emptySet()) ?: emptySet())

    fun isFavorite(context: Context, file: File): Boolean = file.name in all(context)

    /** @return the new state (true = now a favourite). */
    fun toggle(context: Context, file: File): Boolean {
        val names = all(context).toMutableSet()
        val now = if (file.name in names) { names.remove(file.name); false } else { names.add(file.name); true }
        prefs(context).edit().putStringSet(KEY, names).apply()
        return now
    }

    /** Moves a star from [oldName] to [newName] (a renamed document keeps its star). */
    fun rename(context: Context, oldName: String, newName: String) {
        val names = all(context).toMutableSet()
        if (names.remove(oldName)) {
            names.add(newName)
            prefs(context).edit().putStringSet(KEY, names).apply()
        }
    }

    fun prune(context: Context, existingNames: Set<String>) {
        val names = all(context)
        val kept = names.filter { it in existingNames }.toSet()
        if (kept.size != names.size) prefs(context).edit().putStringSet(KEY, kept).apply()
    }
}
