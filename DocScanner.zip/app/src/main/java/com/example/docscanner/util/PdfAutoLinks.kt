package com.example.docscanner.util

import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.interactive.action.PDActionURI
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationLink
import com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDBorderStyleDictionary
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.File

/**
 * Bien dia chi web va email co trong VAN BAN cua PDF thanh lien ket bam duoc (phien 18, PDF "Thieu gi de ban app" B4 - them lien ket). Huu ich cho PDF da qua OCR
 * (lop chu tang kem): chu "https://..." van chi la chu, khong bam duoc. Ghi ra TEP MOI; tep goc chi duoc doc.
 *
 * Pham vi (noi thang): chi nhan MOT TU lien tuc (khong co khoang trang) la dia chi web (`http(s)://...`, `www....`) hoac email; chi xu ly trang KHONG xoay (/Rotate = 0)
 * va chu nam ngang (huong 0) - cac trang khac duoc DEM va bo qua, khong doan toa do; khong tao lien ket de len mot lien ket da co. Dia chi bi ngat dong (xuong dong giua chung)
 * khong duoc nhan. Cach nhan dien: [classify] (ban Java chay duoc `tools/verify/LinkTokensCheck.java`); hinh hoc vung bam duoc kiem bang poppler trong
 * `tools/verify/pdf_links_portfolio_check.py`. Phan goi PdfBox (PDFTextStripper) KHONG chay duoc o moi truong phat trien - xem TECHNICAL_DOCS.md 4.40.
 */
object PdfAutoLinks {

    class Target(val start: Int, val end: Int, val uri: String)
    class Result(val added: Int, val skippedPages: Int)

    private val URL = Regex("^(https?://|www\\.)[^\\s<>\"]+$", RegexOption.IGNORE_CASE)
    private val EMAIL = Regex("^[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}$")
    private const val LEADING = "([{<'\"“‘"
    private const val TRAILING = ".,;:!?)]}>'\"”’"

    /**
     * [word] la mot tu (khong khoang trang) lay tu van ban. Cat bo dau cau o hai dau roi nhan dien: tra ve vi tri [Target.start, Target.end) cua phan duoc
     * cat trong [word] va dia chi dich (`www.x` -> `https://www.x`; email -> `mailto:`), hoac null neu khong phai dia chi web / email.
     */
    fun classify(word: String): Target? {
        var s = 0
        var e = word.length
        while (s < e && LEADING.indexOf(word[s]) >= 0) s++
        while (e > s && TRAILING.indexOf(word[e - 1]) >= 0) e--
        if (e <= s) return null
        val token = word.substring(s, e)
        if (URL.matches(token)) {
            val uri = if (token.startsWith("www.", ignoreCase = true)) "https://$token" else token
            return Target(s, e, uri)
        }
        if (EMAIL.matches(token)) return Target(s, e, "mailto:$token")
        return null
    }

    private class Found(val pageIndex: Int, val x0: Float, val y0: Float, val x1: Float, val y1: Float, val uri: String)

    /** Quet van ban, them lien ket. @return so lien ket da them + so trang bi bo qua (xoay / chu khong ngang). */
    fun addLinks(src: File, out: File): Result {
        val doc = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
        try {
            if (doc.isEncrypted) throw IllegalStateException("encrypted")
            val found = ArrayList<Found>()
            val skipped = HashSet<Int>()
            val stripper = object : PDFTextStripper() {
                override fun writeString(text: String?, textPositions: MutableList<TextPosition>?) {
                    if (text.isNullOrEmpty() || textPositions == null || textPositions.isEmpty()) return
                    val pageIndex = currentPageNo - 1
                    val page = document.getPage(pageIndex)
                    val t = classify(text) ?: return
                    if (page.rotation % 360 != 0 || textPositions.any { it.dir != 0f }) { skipped.add(pageIndex); return }
                    // moi ky tu mot vi tri; neu khac (ligature) thi chi nhan khi KHONG phai cat bot gi
                    val pos = if (text.length == textPositions.size) textPositions.subList(t.start, t.end)
                              else if (t.start == 0 && t.end == text.length) textPositions else return
                    val box = page.cropBox
                    var x0 = Float.MAX_VALUE; var x1 = -Float.MAX_VALUE; var base = 0f; var fs = 0f
                    for (p in pos) { x0 = minOf(x0, p.xDirAdj); x1 = maxOf(x1, p.xDirAdj + p.widthDirAdj); base = p.yDirAdj; fs = maxOf(fs, p.fontSizeInPt) }
                    // toa do hien thi (goc tren-trai) -> khong gian nguoi dung PDF (goc duoi-trai) tren trang KHONG xoay
                    val left = box.lowerLeftX + x0
                    val right = box.lowerLeftX + x1
                    val baseline = box.upperRightY - base
                    found.add(Found(pageIndex, left, baseline - 0.25f * fs, right, baseline + 0.8f * fs, t.uri))
                }
            }
            stripper.sortByPosition = true
            stripper.getText(doc)
            var added = 0
            for (f in found) {
                val page = doc.getPage(f.pageIndex)
                val existing = page.annotations.filterIsInstance<PDAnnotationLink>()
                if (existing.any { overlaps(it.rectangle, f) }) continue
                val link = PDAnnotationLink()
                link.rectangle = PDRectangle(f.x0, f.y0, f.x1 - f.x0, f.y1 - f.y0)
                val border = PDBorderStyleDictionary(); border.width = 0f
                link.borderStyle = border
                val action = PDActionURI(); action.uri = f.uri
                link.action = action
                page.annotations = page.annotations + link
                added++
            }
            doc.save(out)
            return Result(added, skipped.size)
        } finally { runCatching { doc.close() } }
    }

    /** Hai hinh chu nhat chong len nhau tu 50% dien tich cua hinh moi tro len. */
    internal fun overlaps(r: PDRectangle?, f: Found): Boolean {
        if (r == null) return false
        val ix = minOf(r.upperRightX, f.x1) - maxOf(r.lowerLeftX, f.x0)
        val iy = minOf(r.upperRightY, f.y1) - maxOf(r.lowerLeftY, f.y0)
        if (ix <= 0 || iy <= 0) return false
        return ix * iy >= 0.5f * (f.x1 - f.x0) * (f.y1 - f.y0)
    }
}
