package com.example.docscanner.util

import java.util.Calendar
import java.util.Locale

/**
 * The XMP packet and the matching date strings for a PDF/A-2b file (phiên 17, mục 4.31). PdfBox-Android does not ship `xmpbox`, and a PDF/A packet is a
 * small fixed shape, so it is written here as text. Declares `pdfaid:part=2`, `pdfaid:conformance=B` and mirrors the Info dictionary (title, author, producer,
 * creator tool, creation / modification dates) so the two agree: a PDF/A validator compares them. Values are XML-escaped; control characters that XML 1.0
 * forbids are dropped. The packet is wrapped in `<?xpacket ...?>` with a BOM in `begin`, and written WITHOUT a stream filter by the caller.
 * Dates: the Info dictionary form `D:yyyyMMddHHmmss+HH'mm'` and the XMP form `yyyy-MM-ddTHH:mm:ss+HH:mm` come from the SAME [Calendar], so they cannot disagree.
 * Mirrored in tools/verify/PdfACheck.java; the packet is parsed as XML and its fields compared in tools/verify/pdfa_check.py.
 */
object PdfAXmp {

    const val PDFA_PART = 2
    const val PDFA_CONFORMANCE = "B"

    /** XML-escape and drop characters not allowed in XML 1.0. */
    fun xmlEscape(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            i += Character.charCount(cp)
            val ok = cp == 0x9 || cp == 0xA || cp == 0xD || cp in 0x20..0xD7FF || cp in 0xE000..0xFFFD || cp in 0x10000..0x10FFFF
            if (!ok) continue
            when (cp) {
                '&'.code -> sb.append("&amp;")
                '<'.code -> sb.append("&lt;")
                '>'.code -> sb.append("&gt;")
                '"'.code -> sb.append("&quot;")
                '\''.code -> sb.append("&apos;")
                else -> sb.appendCodePoint(cp)
            }
        }
        return sb.toString()
    }

    private fun offsetMinutes(c: Calendar): Int = (c.get(Calendar.ZONE_OFFSET) + c.get(Calendar.DST_OFFSET)) / 60000

    private fun two(v: Int) = String.format(Locale.US, "%02d", v)

    /** `D:20261014093000+07'00'` (a zero offset is written `Z`, as PDF allows). */
    fun infoDate(c: Calendar): String {
        val off = offsetMinutes(c)
        val zone = if (off == 0) "Z" else (if (off < 0) "-" else "+") + two(Math.abs(off) / 60) + "'" + two(Math.abs(off) % 60) + "'"
        return "D:" + String.format(Locale.US, "%04d", c.get(Calendar.YEAR)) + two(c.get(Calendar.MONTH) + 1) + two(c.get(Calendar.DAY_OF_MONTH)) +
            two(c.get(Calendar.HOUR_OF_DAY)) + two(c.get(Calendar.MINUTE)) + two(c.get(Calendar.SECOND)) + zone
    }

    /** `2026-10-14T09:30:00+07:00` (`Z` for UTC). */
    fun xmpDate(c: Calendar): String {
        val off = offsetMinutes(c)
        val zone = if (off == 0) "Z" else (if (off < 0) "-" else "+") + two(Math.abs(off) / 60) + ":" + two(Math.abs(off) % 60)
        return String.format(Locale.US, "%04d", c.get(Calendar.YEAR)) + "-" + two(c.get(Calendar.MONTH) + 1) + "-" + two(c.get(Calendar.DAY_OF_MONTH)) +
            "T" + two(c.get(Calendar.HOUR_OF_DAY)) + ":" + two(c.get(Calendar.MINUTE)) + ":" + two(c.get(Calendar.SECOND)) + zone
    }

    fun packet(title: String, author: String, producer: String, creatorTool: String, created: Calendar, modified: Calendar): String {
        val sb = StringBuilder()
        sb.append("<?xpacket begin=\"\uFEFF\" id=\"W5M0MpCehiHzreSzNTczkc9d\"?>\n")
        sb.append("<x:xmpmeta xmlns:x=\"adobe:ns:meta/\">\n")
        sb.append(" <rdf:RDF xmlns:rdf=\"http://www.w3.org/1999/02/22-rdf-syntax-ns#\">\n")
        sb.append("  <rdf:Description rdf:about=\"\" xmlns:pdfaid=\"http://www.aiim.org/pdfa/ns/id/\">\n")
        sb.append("   <pdfaid:part>").append(PDFA_PART).append("</pdfaid:part>\n")
        sb.append("   <pdfaid:conformance>").append(PDFA_CONFORMANCE).append("</pdfaid:conformance>\n")
        sb.append("  </rdf:Description>\n")
        sb.append("  <rdf:Description rdf:about=\"\" xmlns:dc=\"http://purl.org/dc/elements/1.1/\">\n")
        sb.append("   <dc:title><rdf:Alt><rdf:li xml:lang=\"x-default\">").append(xmlEscape(title)).append("</rdf:li></rdf:Alt></dc:title>\n")
        if (author.isNotEmpty()) sb.append("   <dc:creator><rdf:Seq><rdf:li>").append(xmlEscape(author)).append("</rdf:li></rdf:Seq></dc:creator>\n")
        sb.append("  </rdf:Description>\n")
        sb.append("  <rdf:Description rdf:about=\"\" xmlns:pdf=\"http://ns.adobe.com/pdf/1.3/\">\n")
        sb.append("   <pdf:Producer>").append(xmlEscape(producer)).append("</pdf:Producer>\n")
        sb.append("  </rdf:Description>\n")
        sb.append("  <rdf:Description rdf:about=\"\" xmlns:xmp=\"http://ns.adobe.com/xap/1.0/\">\n")
        sb.append("   <xmp:CreatorTool>").append(xmlEscape(creatorTool)).append("</xmp:CreatorTool>\n")
        sb.append("   <xmp:CreateDate>").append(xmpDate(created)).append("</xmp:CreateDate>\n")
        sb.append("   <xmp:ModifyDate>").append(xmpDate(modified)).append("</xmp:ModifyDate>\n")
        sb.append("   <xmp:MetadataDate>").append(xmpDate(modified)).append("</xmp:MetadataDate>\n")
        sb.append("  </rdf:Description>\n")
        sb.append(" </rdf:RDF>\n")
        sb.append("</x:xmpmeta>\n")
        sb.append("<?xpacket end=\"w\"?>")
        return sb.toString()
    }
}
