package com.example.docscanner.util

import android.content.Context
import android.content.res.Configuration

/**
 * "Text size" inside the app (PDF list I4 large text), ON TOP of the phone's own font size setting: the person picks Standard / Large / Larger / Largest and every
 * screen's text (all sizes in the layouts are sp) is multiplied by 1.0 / 1.15 / 1.3 / 1.5, never beyond [MAX_SCALE] in total. Standard (the default) changes NOTHING:
 * [wrap] returns the very same context, so a person who never opens this setting runs exactly the code path that existed before.
 */
object FontScale {

    val CHOICES = floatArrayOf(1.0f, 1.15f, 1.3f, 1.5f)
    const val MAX_SCALE = 2.0f
    private const val PREFS = "display"
    private const val KEY_INDEX = "font_scale_index"

    fun index(context: Context): Int = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_INDEX, 0).coerceIn(0, CHOICES.size - 1)

    fun setIndex(context: Context, index: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_INDEX, index.coerceIn(0, CHOICES.size - 1)).apply()
    }

    /** The font scale to run with: the system's own times the person's choice, capped. */
    fun effective(system: Float, choice: Float): Float = minOf(MAX_SCALE, system * choice)

    /** [base] itself for Standard; otherwise a context whose configuration carries the larger font scale. Called from every activity's attachBaseContext ([com.example.docscanner.BaseActivity]). */
    fun wrap(base: Context): Context {
        val choice = CHOICES[index(base)]
        if (choice == 1.0f) return base
        val config = Configuration(base.resources.configuration)
        config.fontScale = effective(config.fontScale, choice)
        return base.createConfigurationContext(config)
    }
}
