package com.example.docscanner.util

import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDAcroForm
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDCheckBox
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDChoice
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDTerminalField
import com.tom_roush.pdfbox.pdmodel.interactive.form.PDTextField
import java.io.File
import java.io.FileOutputStream

/**
 * Fills in the fields of a PDF that HAS fillable fields (an "AcroForm": tax forms, applications, contracts made in a word
 * processor and exported as a form): text boxes, check boxes, and drop-down / list choices. A scanned paper form has no
 * fields - for that, type text onto the page with "Ký & đóng dấu PDF" -> "Văn bản không khung".
 *
 * Vietnamese text is the catch. A text field draws its value with the font named in the field's default appearance (nearly
 * always Helvetica), and PDFBox refuses to build the appearance for characters that font cannot encode (e.g. "ạ", "ế") by
 * throwing. So [fill] first tries the normal route (value + a generated appearance); if that throws, it stores the value
 * directly and sets the form's NeedAppearances flag, which makes the viewer draw the field itself with its own fonts - the
 * value is right in every viewer, and the field shows it in those that honour the flag (Adobe Reader and the common
 * browsers' viewers do). The idea (a value set with NeedAppearances shows up where one without it does not) is checked with
 * poppler in tools/verify/form_check.py; the PDFBox calls themselves can only be exercised on a device.
 *
 * A PDF that is already SIGNED DIGITALLY is filled differently, so that the signature stays intact: the changes are appended
 * as an incremental update (PDFBox `saveIncremental`, which writes only the objects marked with `setNeedToBeUpdated(true)`;
 * the original bytes, which the signature covers, are untouched) instead of rewriting the whole file, and values are stored
 * directly with NeedAppearances set. tools/verify/signed_form_check.py shows with pdfsig that such an appended revision leaves
 * the signature valid while a full rewrite breaks it. Honest limit: the signature then protects the file as it was SIGNED, not
 * the filled copy - viewers report that the document changed after signing (unless the signer allowed form filling).
 * An unsigned PDF is saved in full as before.
 */
object PdfFormFiller {

    enum class Kind { TEXT, CHECKBOX, CHOICE }

    class Field(
        val name: String,
        val kind: Kind,
        /** Current value; for a check box "true"/"false". */
        val value: String,
        /** Options of a choice field; empty otherwise. */
        val options: List<String>
    )

    private fun load(src: File): PDDocument {
        val doc = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
        if (doc.isEncrypted) {
            runCatching { doc.close() }
            throw IllegalStateException("encrypted")
        }
        return doc
    }

    /** The fillable, editable fields of [src] in document order; empty when it has none (a scan, or a plain PDF). */
    fun readFields(src: File): List<Field> {
        val doc = load(src)
        try {
            val form = doc.documentCatalog.acroForm ?: return emptyList()
            val out = ArrayList<Field>()
            for (f in form.fieldTree) {
                if (f !is PDTerminalField || f.isReadOnly) continue
                when (f) {
                    is PDTextField -> out.add(Field(f.fullyQualifiedName, Kind.TEXT, f.value ?: "", emptyList()))
                    is PDCheckBox -> out.add(Field(f.fullyQualifiedName, Kind.CHECKBOX, f.isChecked.toString(), emptyList()))
                    is PDChoice -> out.add(Field(f.fullyQualifiedName, Kind.CHOICE, f.value.firstOrNull() ?: "", f.options))
                    else -> { /* push buttons, signature fields, radio groups: not offered */ }
                }
            }
            return out
        } finally {
            runCatching { doc.close() }
        }
    }

    /** True when [src] carries a digital signature (so [fill] will append instead of rewriting). */
    fun isSigned(src: File): Boolean {
        val doc = load(src)
        try {
            return doc.signatureDictionaries.isNotEmpty()
        } finally {
            runCatching { doc.close() }
        }
    }

    /**
     * PDFBox's incremental save writes only objects reached along a PATH of objects marked `setNeedToBeUpdated(true)` that starts
     * at the document catalog (PDDocument.saveIncremental javadoc: "There must be a path of objects that have
     * COSUpdateInfo.isNeedToBeUpdated() set, starting from the document catalog"). The path to a changed field is: catalog ->
     * AcroForm -> its /Fields array -> [every ancestor field and its /Kids array] -> the field -> its widgets. Marking only the
     * field and the catalog would leave the change out of the file without any error.
     */
    private fun markUpdated(form: PDAcroForm, field: PDTerminalField) {
        field.cosObject.setNeedToBeUpdated(true)
        for (widget in field.widgets) widget.cosObject.setNeedToBeUpdated(true)
        var parent = field.parent
        while (parent != null) {
            parent.cosObject.setNeedToBeUpdated(true)
            (parent.cosObject.getDictionaryObject(COSName.KIDS) as? COSArray)?.setNeedToBeUpdated(true)
            parent = parent.parent
        }
        (form.cosObject.getDictionaryObject(COSName.FIELDS) as? COSArray)?.setNeedToBeUpdated(true)
    }

    /** Sets each field named in [values] and writes the NEW file [out]. @return the number of fields changed. */
    fun fill(src: File, out: File, values: Map<String, String>): Int {
        val doc = load(src)
        try {
            val pages = doc.numberOfPages
            val form = doc.documentCatalog.acroForm ?: throw IllegalStateException("no form")
            val signed = doc.signatureDictionaries.isNotEmpty()
            var changed = 0
            var needViewerAppearance = false
            for (f in form.fieldTree) {
                if (f !is PDTerminalField || f.isReadOnly) continue
                val wanted = values[f.fullyQualifiedName] ?: continue
                when (f) {
                    is PDTextField -> {
                        if (wanted == (f.value ?: "")) continue
                        if (signed) {
                            f.cosObject.setString(COSName.V, wanted)   // no appearance work: the viewer draws it (NeedAppearances below)
                        } else {
                            try {
                                f.setValue(wanted)
                            } catch (e: Exception) {
                                f.cosObject.setString(COSName.V, wanted)   // the field's font cannot draw it: let the viewer do so
                                needViewerAppearance = true
                            }
                        }
                        if (signed) markUpdated(form, f)
                        changed++
                    }
                    is PDCheckBox -> {
                        val want = wanted.equals("true", ignoreCase = true)
                        if (want == f.isChecked) continue
                        if (want) f.check() else f.unCheck()
                        if (signed) markUpdated(form, f)
                        changed++
                    }
                    is PDChoice -> {
                        if (wanted == (f.value.firstOrNull() ?: "")) continue
                        if (signed) {
                            f.cosObject.setString(COSName.V, wanted)
                        } else {
                            try {
                                f.setValue(wanted)
                            } catch (e: Exception) {
                                f.cosObject.setString(COSName.V, wanted)
                                needViewerAppearance = true
                            }
                        }
                        if (signed) markUpdated(form, f)
                        changed++
                    }
                    else -> { }
                }
            }
            if (signed) {
                form.setNeedAppearances(true)
                form.cosObject.setNeedToBeUpdated(true)
                doc.documentCatalog.cosObject.setNeedToBeUpdated(true)
                FileOutputStream(out).use { doc.saveIncremental(it) }
            } else {
                if (needViewerAppearance) form.setNeedAppearances(true)
                PdfStructureOptimizer.save(doc, out)
            }
            if (!PdfVerify.opensAsPdf(out, pages)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
            return changed
        } catch (e: Throwable) {
            runCatching { out.delete() }
            throw e
        } finally {
            runCatching { doc.close() }
        }
    }
}
