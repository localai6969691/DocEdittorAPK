package com.example.docscanner.util

import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.sqrt

/**
 * "Thước thăng bằng" of the camera screen (phiên 17, mục 4.31): how far the phone is from lying PARALLEL to the table. A document photographed with the phone
 * parallel to the page has no keystone distortion, so the crop step has less to fix and text stays sharper edge to edge. Fed by the accelerometer, which at rest
 * measures gravity in the device frame (x right, y up the screen, z out of the screen): the angle between the device's Z axis and the vertical is
 * `acos(|gz| / |g|)` - 0 deg flat (face up or face down), 90 deg held upright. The sign of gz does not matter, so it works from above and below.
 * A single reading jitters a few degrees, so readings are smoothed with an exponential filter ([smooth]) before being shown. Pure, checked by tools/verify/level_check.py
 * against an independent derivation (rotate the gravity vector by random roll and pitch, compare with the angle the rotation matrix implies).
 */
object LevelIndicator {

    /** Within this many degrees of flat the screen shows the "parallel" tick. */
    const val LEVEL_DEGREES = 3f

    /** Weight of the newest reading in [smooth]. */
    const val SMOOTH_ALPHA = 0.2f

    /** Degrees between the Z axis and gravity, 0..90. A zero vector (free fall / no signal) gives 0. */
    fun tiltDegrees(gx: Float, gy: Float, gz: Float): Float {
        val norm = sqrt(gx * gx + gy * gy + gz * gz)
        if (norm < 1e-3f) return 0f
        val c = (abs(gz) / norm).coerceIn(0f, 1f)
        return Math.toDegrees(acos(c.toDouble())).toFloat()
    }

    fun smooth(previous: Float, sample: Float, alpha: Float = SMOOTH_ALPHA): Float = previous + alpha * (sample - previous)

    fun isLevel(tilt: Float): Boolean = tilt <= LEVEL_DEGREES
}
