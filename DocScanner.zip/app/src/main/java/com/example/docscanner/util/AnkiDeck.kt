package com.example.docscanner.util

import java.io.File
import java.security.MessageDigest
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Flash cards for Anki from the text of a document (PDF list "Scan a book -> flash cards", 10.15; session 26). Two outputs: a `.apkg` package (a ZIP holding an SQLite collection in the
 * legacy "schema 11" layout every Anki version still imports, plus an empty media list) and a tab-separated text file for Anki's "Import file" / Quizlet.
 *
 * Where the cards come from: nothing is invented. A card is a pair the text already contains - `term :: meaning` (also tab, `=>`, `→`), `Q: ... A: ...` on one line or on
 * the next lines (also Hỏi / Đáp, Câu hỏi / Trả lời, Question / Answer, Frage / Antwort, Pregunta / Respuesta, Question / Réponse, 问 / 答 ...), and short `term: meaning`,
 * `term - meaning`, `term – meaning` lines (a term of at most 5 words, so an ordinary sentence with a colon is not taken for a card). Duplicate fronts are dropped.
 *
 * The SQLite part is handed over as a list of [Stmt] (SQL + bind arguments) so the app can run it through `SQLiteDatabase.execSQL` and a test can run the very same list through
 * any SQLite; everything here is plain Kotlin and run for real by tools/verify/anki_real_run_check.py against Anki's own importer.
 */
object AnkiDeck {

    class Card(val front: String, val back: String)

    /** One SQL statement with its bind arguments (Long or String). */
    class Stmt(val sql: String, val args: Array<Any> = emptyArray())

    const val MAX_CARDS = 2000
    const val MAX_TERM_WORDS = 5
    const val MAX_TERM_CHARS = 60
    const val TAG = "DocScanner"
    /** The note type is the same for every export, so cards of several documents share it in Anki. */
    const val MODEL_ID = 1700000000001L

    // ------------------------------------------------------------------------------------------------------------------------------ cards from text
    private val QUESTION = Regex("^(?:q|hỏi|câu hỏi|question|frage|pregunta|pergunta|pertanyaan|вопрос|问|問|質問|질문|प्रश्न)\\s*[:.)\\-–]\\s*(.+)$", RegexOption.IGNORE_CASE)
    private val ANSWER = Regex("^(?:a|đáp|đáp án|trả lời|answer|antwort|respuesta|resposta|réponse|jawaban|ответ|答|回答|답|उत्तर)\\s*[:.)\\-–]\\s*(.+)$", RegexOption.IGNORE_CASE)
    private val QA_ONE_LINE = Regex("^(?:q|hỏi|câu hỏi|question|frage|pregunta|pergunta|pertanyaan|вопрос|问|問|質問|질문)\\s*[:.)]\\s*(.+?)\\s+(?:a|đáp|đáp án|trả lời|answer|antwort|respuesta|resposta|réponse|jawaban|ответ|答|回答|답)\\s*[:.)]\\s*(.+)$", RegexOption.IGNORE_CASE)
    private val BULLET = Regex("^(?:[-•*·▪●○]+|\\(?\\d{1,3}[.)])\\s+")
    private val EXPLICIT = listOf("::", "\t", "=>", "→")
    private val SOFT = listOf(": ", " - ", " – ", " — ")

    /** Cards of every page of a document, in order, without repeated fronts. */
    fun cardsFromPages(pages: List<String>): List<Card> = cardsFromText(pages.joinToString("\n"))

    fun cardsFromText(text: String): List<Card> {
        val lines = text.replace("\r\n", "\n").replace('\r', '\n').split('\n').map { it.trim().replace(BULLET, "") }
        val out = LinkedHashMap<String, Card>()
        fun add(front: String, back: String) {
            val f = front.trim().trimEnd(':', '-', '–', '—').trim()
            val b = back.trim()
            if (f.isEmpty() || b.isEmpty() || out.size >= MAX_CARDS) return
            out.putIfAbsent(f.lowercase(), Card(f, b))
        }
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            if (line.isEmpty()) { i++; continue }
            val oneLine = QA_ONE_LINE.find(line)
            if (oneLine != null) { add(oneLine.groupValues[1], oneLine.groupValues[2]); i++; continue }
            val q = QUESTION.find(line)
            if (q != null) {
                // the answer is on one of the next three non-empty lines; lines up to the next question / blank belong to it
                var j = i + 1
                var seen = 0
                while (j < lines.size && seen < 3 && (lines[j].isEmpty() || ANSWER.find(lines[j]) == null)) { if (lines[j].isNotEmpty()) seen++; j++ }
                val a = if (j < lines.size) ANSWER.find(lines[j]) else null
                if (a != null) {
                    val answer = StringBuilder(a.groupValues[1])
                    var k = j + 1
                    while (k < lines.size && lines[k].isNotEmpty() && QUESTION.find(lines[k]) == null && QA_ONE_LINE.find(lines[k]) == null) { answer.append(' ').append(lines[k]); k++ }
                    add(q.groupValues[1], answer.toString())
                    i = k
                    continue
                }
            }
            // an unanswered "Q: ..." or an orphan "A: ..." is not a "term: meaning" pair (it would give a card whose front is just "Q")
            if (q == null && ANSWER.find(line) == null) { val pair = split(line); if (pair != null) add(pair.first, pair.second) }
            i++
        }
        return out.values.toList()
    }

    /** `term :: meaning` style split of one line, or null when the line is not a pair. */
    internal fun split(line: String): Pair<String, String>? {
        for (sep in EXPLICIT) {
            val at = line.indexOf(sep)
            if (at > 0) {
                val f = line.substring(0, at).trim(); val b = line.substring(at + sep.length).trim()
                if (f.isNotEmpty() && b.isNotEmpty() && f.length <= 160) return f to b
            }
        }
        if (line.length > 240) return null
        for (sep in SOFT) {
            val at = line.indexOf(sep)
            if (at <= 0) continue
            val term = line.substring(0, at).trim(); val meaning = line.substring(at + sep.length).trim()
            val words = term.split(Regex("\\s+")).size
            val plausibleTerm = term.length in 1..MAX_TERM_CHARS && words <= MAX_TERM_WORDS && !term.endsWith('.') && !term.endsWith('?') && !term.all { it.isDigit() || it == '.' || it == ',' }
            if (plausibleTerm && meaning.length >= 3 && !term.contains("://") && !term.equals("http", true) && !term.equals("https", true)) return term to meaning
            return null          // the first separator decides: "Note: a - b" is one pair at best, never two
        }
        return null
    }

    // ------------------------------------------------------------------------------------------------------------------------------ text file
    private fun html(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\r\n", "\n").replace('\r', '\n').replace("\n", "<br>")

    /**
     * One field of the text file. Anki's importer drops a line that starts with `#` (a comment / header line) and reads a field that starts with `"` as a quoted CSV field, so a card
     * such as "#1 priority" or "\"quoted\" word" was lost or mangled (found by importing the file into Anki itself, phiên 26): quotes become `&quot;` and a leading `#` becomes `&#35;`.
     */
    private fun tsvField(s: String): String {
        val h = html(s).replace('\t', ' ').replace("\"", "&quot;")
        return if (h.startsWith("#")) "&#35;" + h.substring(1) else h
    }

    /** Anki "Import file" text: tab-separated Front, Back, Tags with the header lines Anki reads (`#separator`, `#html`, `#tags column`). Quizlet takes the same two columns. */
    fun tsv(cards: List<Card>): String {
        val sb = StringBuilder("#separator:tab\n#html:true\n#tags column:3\n")
        for (c in cards) sb.append(tsvField(c.front)).append('\t').append(tsvField(c.back)).append('\t').append(TAG).append('\n')
        return sb.toString()
    }

    // ------------------------------------------------------------------------------------------------------------------------------ .apkg
    private fun sha1(s: String): ByteArray = MessageDigest.getInstance("SHA-1").digest(s.toByteArray(Charsets.UTF_8))

    /** Anki's field checksum: the first 8 hex digits of the SHA-1 of the first field with its HTML removed. */
    fun fieldChecksum(firstField: String): Long = sha1(plainText(firstField)).take(4).fold(0L) { acc, b -> (acc shl 8) or (b.toLong() and 0xFF) }

    /** A field without its HTML, the way Anki's `strip_html` makes it: tags removed, the entities [html] writes decoded ONCE, nothing trimmed (checked against anki.utils.field_checksum). Also the sort field. */
    internal fun plainText(field: String): String = field.replace(Regex("<[^>]*>"), "").replace(Regex("&(amp|lt|gt);")) {
        when (it.groupValues[1]) { "amp" -> "&"; "lt" -> "<"; else -> ">" }
    }

    private const val BASE91 = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!#$%&()*+,-./:;<=>?@[]^_`{|}~"

    /** A stable global id for a note (Anki: base-91 of 64 bits); stable so importing the same export twice updates instead of duplicating. */
    fun guid(front: String, back: String): String {
        var n = sha1(front + "\u001f" + back).take(8).fold(0L) { acc, b -> (acc shl 8) or (b.toLong() and 0xFF) }
        val sb = StringBuilder()
        if (n == 0L) sb.append(BASE91[0])
        var v = java.lang.Long.toUnsignedString(n).let { java.math.BigInteger(it) }
        val base = java.math.BigInteger.valueOf(91)
        while (v.signum() > 0) { val qr = v.divideAndRemainder(base); sb.append(BASE91[qr[1].toInt()]); v = qr[0] }
        return sb.reverse().toString()
    }

    /** A deck id made from the name, in the range Anki uses for ids made by clients (a millisecond-sized number), never 1 (the Default deck). */
    fun deckId(name: String): Long = 1700000000000L + (java.math.BigInteger(1, sha1(name)).mod(java.math.BigInteger.valueOf(100000000L)).toLong() + 10L)

    private fun js(s: String): String {
        val sb = StringBuilder("\"")
        for (ch in s) when {
            ch == '"' -> sb.append("\\\""); ch == '\\' -> sb.append("\\\\"); ch == '\n' -> sb.append("\\n"); ch == '\r' -> sb.append("\\r"); ch == '\t' -> sb.append("\\t")
            ch < ' ' -> sb.append("\\u%04x".format(ch.code)); else -> sb.append(ch)
        }
        return sb.append('"').toString()
    }

    private fun conf(nowSec: Long): String = "{\"nextPos\":1,\"estTimes\":true,\"activeDecks\":[1],\"sortType\":\"noteFld\",\"timeLim\":0,\"sortBackwards\":false,\"addToCur\":true,\"curDeck\":1," +
        "\"newBury\":true,\"newSpread\":0,\"dueCounts\":true,\"curModel\":\"$MODEL_ID\",\"collapseTime\":1200}"

    private fun deckJson(id: Long, name: String, nowSec: Long, conf: Int): String = "{\"id\":$id,\"name\":${js(name)},\"desc\":\"\",\"mod\":$nowSec,\"usn\":-1,\"collapsed\":false,\"browserCollapsed\":false," +
        "\"newToday\":[0,0],\"revToday\":[0,0],\"lrnToday\":[0,0],\"timeToday\":[0,0],\"dyn\":0,\"extendNew\":10,\"extendRev\":50,\"conf\":$conf}"

    private fun models(nowSec: Long, did: Long): String {
        val css = ".card {\\n font-family: arial;\\n font-size: 20px;\\n text-align: center;\\n color: black;\\n background-color: white;\\n}\\n"
        val fld = { n: String, o: Int -> "{\"name\":\"$n\",\"ord\":$o,\"sticky\":false,\"rtl\":false,\"font\":\"Arial\",\"size\":20,\"media\":[]}" }
        return "{\"$MODEL_ID\":{\"id\":$MODEL_ID,\"name\":\"Basic (DocScanner)\",\"type\":0,\"mod\":$nowSec,\"usn\":-1,\"sortf\":0,\"did\":$did," +
            "\"tmpls\":[{\"name\":\"Card 1\",\"ord\":0,\"qfmt\":\"{{Front}}\",\"afmt\":\"{{FrontSide}}\\n\\n<hr id=answer>\\n\\n{{Back}}\",\"bqfmt\":\"\",\"bafmt\":\"\",\"did\":null,\"bfont\":\"\",\"bsize\":0}]," +
            "\"flds\":[${fld("Front", 0)},${fld("Back", 1)}],\"css\":\"$css\",\"latexPre\":\"\\\\documentclass[12pt]{article}\\n\\\\special{papersize=3in,5in}\\n\\\\usepackage[utf8]{inputenc}\\n\\\\usepackage{amssymb,amsmath}\\n\\\\pagestyle{empty}\\n\\\\setlength{\\\\parindent}{0in}\\n\\\\begin{document}\\n\"," +
            "\"latexPost\":\"\\\\end{document}\",\"latexsvg\":false,\"req\":[[0,\"any\",[0]]],\"tags\":[],\"vers\":[]}}"
    }

    private fun dconf(): String = "{\"1\":{\"id\":1,\"name\":\"Default\",\"replayq\":true,\"lapse\":{\"delays\":[10],\"mult\":0,\"minInt\":1,\"leechFails\":8,\"leechAction\":0}," +
        "\"rev\":{\"perDay\":200,\"fuzz\":0.05,\"ivlFct\":1,\"maxIvl\":36500,\"ease4\":1.3,\"bury\":true,\"minSpace\":1,\"hardFactor\":1.2},\"timer\":0,\"maxTaken\":60,\"usn\":0," +
        "\"new\":{\"perDay\":20,\"delays\":[1,10],\"separate\":true,\"ints\":[1,4,7],\"initialFactor\":2500,\"bury\":true,\"order\":1},\"mod\":0,\"autoplay\":true}}"

    private val SCHEMA = listOf(
        "CREATE TABLE col (id integer primary key, crt integer not null, mod integer not null, scm integer not null, ver integer not null, dty integer not null, usn integer not null, ls integer not null, conf text not null, models text not null, decks text not null, dconf text not null, tags text not null)",
        "CREATE TABLE notes (id integer primary key, guid text not null, mid integer not null, mod integer not null, usn integer not null, tags text not null, flds text not null, sfld integer not null, csum integer not null, flags integer not null, data text not null)",
        "CREATE TABLE cards (id integer primary key, nid integer not null, did integer not null, ord integer not null, mod integer not null, usn integer not null, type integer not null, queue integer not null, due integer not null, ivl integer not null, factor integer not null, reps integer not null, lapses integer not null, left integer not null, odue integer not null, odid integer not null, flags integer not null, data text not null)",
        "CREATE TABLE revlog (id integer primary key, cid integer not null, usn integer not null, ease integer not null, ivl integer not null, lastIvl integer not null, factor integer not null, time integer not null, type integer not null)",
        "CREATE TABLE graves (usn integer not null, oid integer not null, type integer not null)",
        "CREATE INDEX ix_notes_usn on notes (usn)", "CREATE INDEX ix_cards_usn on cards (usn)", "CREATE INDEX ix_revlog_usn on revlog (usn)",
        "CREATE INDEX ix_cards_nid on cards (nid)", "CREATE INDEX ix_cards_sched on cards (did, queue, due)", "CREATE INDEX ix_revlog_cid on revlog (cid)", "CREATE INDEX ix_notes_csum on notes (csum)"
    )

    /** Every statement that builds the collection of [cards] in deck [deckName], in order. [nowMs] only seeds the ids and times, so a test can pass a fixed one. */
    fun statements(cards: List<Card>, deckName: String, nowMs: Long): List<Stmt> {
        val nowSec = nowMs / 1000
        val did = deckId(deckName)
        val out = ArrayList<Stmt>()
        for (s in SCHEMA) out.add(Stmt(s))
        out.add(Stmt("INSERT INTO col VALUES (1, ?, ?, ?, 11, 0, 0, 0, ?, ?, ?, ?, '{}')", arrayOf<Any>(nowSec - (nowSec % 86400), nowMs, nowMs, conf(nowSec), models(nowSec, did),
            "{\"1\":${deckJson(1, "Default", nowSec, 1)},\"$did\":${deckJson(did, deckName, nowSec, 1)}}", dconf())))
        for ((i, c) in cards.withIndex()) {
            val front = html(c.front); val back = html(c.back)
            val nid = nowMs + i
            out.add(Stmt("INSERT INTO notes VALUES (?, ?, ?, ?, -1, ?, ?, ?, ?, 0, '')", arrayOf<Any>(nid, guid(c.front, c.back), MODEL_ID, nowSec, " $TAG ", front + "\u001f" + back, plainText(front), fieldChecksum(front))))
            out.add(Stmt("INSERT INTO cards VALUES (?, ?, ?, 0, ?, -1, 0, 0, ?, 0, 0, 0, 0, 0, 0, 0, 0, '')", arrayOf<Any>(nowMs + cards.size + i, nid, did, nowSec, (i + 1).toLong())))
        }
        return out
    }

    /** Zips the finished collection file into the package Anki imports: `collection.anki2` + `media` (an empty JSON object: no pictures or sounds). */
    fun pack(collection: File, out: File) {
        ZipOutputStream(out.outputStream().buffered()).use { z ->
            z.putNextEntry(ZipEntry("collection.anki2")); collection.inputStream().use { it.copyTo(z) }; z.closeEntry()
            z.putNextEntry(ZipEntry("media")); z.write("{}".toByteArray(Charsets.UTF_8)); z.closeEntry()
        }
    }
}
