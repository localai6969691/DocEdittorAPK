package com.example.docscanner.util

/**
 * What the first-run question does to the home screen (phiên 25, TECHNICAL_DOCS.md 4.79; PDF list item 4.1 "ask a few questions and set the app up"): the person says what they will mostly do and
 * the matching groups of tools start OPEN while the others start FOLDED.
 *
 * Nothing is hidden for good. The scanner apps looked at while designing this (Adobe Scan asks what kind of page is being scanned, Genius Scan has a short first-run tour, Microsoft Lens has
 * modes) personalise where the person STARTS and keep every feature reachable; removing features after one question would be wrong the first time the answer changes. So the groups the
 * person does not pick are folded (the title row opens them, as it always did), "Find a tool" lists the tools of folded groups too, and the choice can be made again from the home screen.
 * Pure: tools/verify/command_palette_real_run_check.py runs it for real.
 */
object ToolPreset {

    /** The groups of tools on the home screen, in the order they are shown. */
    val GROUPS: List<String> = listOf("scan", "arrange", "edit", "secure", "convert", "utility")

    const val GOAL_SCAN = "scan"
    const val GOAL_EDIT = "edit"
    const val GOAL_ARRANGE = "arrange"
    const val GOAL_CONVERT = "convert"
    const val GOAL_ALL = "all"

    /** The goals offered, in the order of the choices. */
    val GOALS: List<String> = listOf(GOAL_SCAN, GOAL_EDIT, GOAL_ARRANGE, GOAL_CONVERT, GOAL_ALL)

    /**
     * The groups that start open for [goals]: nothing picked keeps the usual start (only "scan"); "all" opens every group; otherwise scan -> scan, edit -> edit + secure (signing and
     * redacting belong with editing), arrange -> arrange, convert -> convert. The "utility" group (batch, backup, QR) opens only with "all".
     */
    fun groupsToOpen(goals: Set<String>): Set<String> {
        if (goals.isEmpty()) return setOf("scan")
        if (GOAL_ALL in goals) return GROUPS.toSet()
        val out = LinkedHashSet<String>()
        if (GOAL_SCAN in goals) out.add("scan")
        if (GOAL_EDIT in goals) {
            out.add("edit")
            out.add("secure")
        }
        if (GOAL_ARRANGE in goals) out.add("arrange")
        if (GOAL_CONVERT in goals) out.add("convert")
        // goals this version does not know (an old saved answer): the usual start, never a home screen with every group folded
        return if (out.isEmpty()) setOf("scan") else out
    }
}
