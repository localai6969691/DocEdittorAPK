package com.example.docscanner.util

import com.tom_roush.pdfbox.contentstream.operator.Operator
import com.tom_roush.pdfbox.cos.COSFloat
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSNumber
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdfparser.PDFStreamParser
import com.tom_roush.pdfbox.pdfwriter.ContentStreamWriter
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.common.PDStream
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState
import java.io.File
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Edit the pictures that are ALREADY in a PDF page (phien 27, TECHNICAL_DOCS.md 4.88; the part of "edit a PDF like WPS" that [PdfTextEditor] does not cover): list them with where they
 * sit, delete one, move / resize / rotate one, or swap it for another picture. Nothing is rasterised: only the page's content stream is rewritten, the same way [PdfTextEditor] does.
 *
 * ## How a picture is found
 * ONE traversal, [scan]: the page's tokens are parsed with `PDFStreamParser`, the current transformation matrix (CTM) is tracked through `q` / `Q` / `cm`, and every `Do` whose
 * XObject is an image is one [Picture], numbered by [Picture.index] in token order. The unit square is the picture, so its box on the page is the CTM applied to (0,0)-(1,1).
 * Form XObjects are not entered and inline images (`BI`) are not listed: the same rule as [PdfTextEditor] (what is not found is not edited, identically for reading and writing).
 *
 * ## How it is edited
 * - delete: the `Do` and its name are removed (the surrounding `q` / `cm` / `Q` stay balanced);
 * - move / resize / rotate: `q T cm` is put before the `Do` and `Q` after it, where T = CTM x A x CTM^-1 and A is the change in PAGE space (a shift, then a turn and scale around the
 *   picture's centre), so that CTM' = T x CTM = CTM x A. The original matrix is never edited, so a picture drawn several times (same XObject) changes only at the chosen place;
 * - replace: the new picture is added to the page's resources and the `Do` points to it; its aspect ratio is kept and it is centred inside the old frame ("fit").
 */
object PdfImageEditor {

    /** One picture on a page. [box] = `[llx, lly, urx, ury]` in the page's user space; [placed] = the same as fractions 0..1 of the DISPLAYED page from the top-left, or null when wholly off the page. */
    class Picture(val index: Int, val widthPx: Int, val heightPx: Int, val box: FloatArray, val placed: FloatArray?)

    sealed class Op {
        class Delete(val page: Int, val index: Int) : Op()
        /** [dx] / [dy]: shift as fractions of the displayed page (right / down); [scale]: 1 = unchanged, about the picture's centre; [turnDegrees]: clockwise as seen on the page. */
        class Transform(
            val page: Int, val index: Int, val dx: Float = 0f, val dy: Float = 0f, val scale: Float = 1f, val turnDegrees: Float = 0f,
            /** mirror left-right / top-bottom AS DISPLAYED (done first, about the picture's centre); [opacity] 0..1 (null = leave as it is), 1 = opaque. */
            val flipH: Boolean = false, val flipV: Boolean = false, val opacity: Float? = null
        ) : Op()
        /** Hide the outer part of the picture (a clip, the picture itself is kept): the fractions of the picture's DISPLAYED box to cut from each side, each 0..0.95, left + right < 1 and top + bottom < 1. */
        class Crop(val page: Int, val index: Int, val left: Float = 0f, val top: Float = 0f, val right: Float = 0f, val bottom: Float = 0f) : Op()
        /** [make] builds the new picture in the document (the caller uses JPEGFactory / LosslessFactory, which need Android). */
        class Replace(val page: Int, val index: Int, val make: (PDDocument) -> PDImageXObject) : Op()
    }

    private class Found(val doOpIndex: Int, val nameIndex: Int, val name: COSName, val image: PDImageXObject, val ctm: FloatArray)
    private class PageScan(val tokens: MutableList<Any>, val found: List<Found>)

    // 2D affine matrices as [a b c d e f], PDF row-vector convention: multiply(first, second) = first, then second.
    internal fun multiply(f: FloatArray, s: FloatArray): FloatArray = floatArrayOf(
        f[0] * s[0] + f[1] * s[2], f[0] * s[1] + f[1] * s[3],
        f[2] * s[0] + f[3] * s[2], f[2] * s[1] + f[3] * s[3],
        f[4] * s[0] + f[5] * s[2] + s[4], f[4] * s[1] + f[5] * s[3] + s[5]
    )

    internal fun inverse(m: FloatArray): FloatArray? {
        val det = m[0] * m[3] - m[1] * m[2]
        if (abs(det) < 1e-9f) return null
        val a = m[3] / det; val b = -m[1] / det; val c = -m[2] / det; val d = m[0] / det
        return floatArrayOf(a, b, c, d, -(m[4] * a + m[5] * c), -(m[4] * b + m[5] * d))
    }

    private fun number(tokens: List<Any>, i: Int): Float? = (tokens.getOrNull(i) as? COSNumber)?.floatValue()

    private fun scan(document: PDDocument, pageNumber: Int): PageScan {
        val page = document.getPage(pageNumber - 1)
        val parser = PDFStreamParser(page)
        parser.parse()
        val tokens: MutableList<Any> = ArrayList(parser.tokens)
        val resources = page.resources
        var ctm = floatArrayOf(1f, 0f, 0f, 1f, 0f, 0f)
        val stack = ArrayList<FloatArray>()
        val found = ArrayList<Found>()
        for ((i, token) in tokens.withIndex()) {
            if (token !is Operator) continue
            when (token.name) {
                "q" -> stack.add(ctm.copyOf())
                "Q" -> if (stack.isNotEmpty()) ctm = stack.removeAt(stack.size - 1)
                "cm" -> if (i >= 6) {
                    val v = FloatArray(6)
                    var ok = true
                    for (k in 0 until 6) { val n = number(tokens, i - 6 + k); if (n == null) ok = false else v[k] = n }
                    if (ok) ctm = multiply(v, ctm)
                }
                "Do" -> {
                    val name = tokens.getOrNull(i - 1) as? COSName
                    if (name != null && resources != null) {
                        val image = runCatching { resources.getXObject(name) }.getOrNull() as? PDImageXObject
                        if (image != null) found.add(Found(i, i - 1, name, image, ctm.copyOf()))
                    }
                }
            }
        }
        return PageScan(tokens, found)
    }

    private fun boxOf(ctm: FloatArray): FloatArray {
        val xs = floatArrayOf(ctm[4], ctm[0] + ctm[4], ctm[2] + ctm[4], ctm[0] + ctm[2] + ctm[4])
        val ys = floatArrayOf(ctm[5], ctm[1] + ctm[5], ctm[3] + ctm[5], ctm[1] + ctm[3] + ctm[5])
        return floatArrayOf(xs.min(), ys.min(), xs.max(), ys.max())
    }

    /** The pictures of page [pageNumber] (1-based), in token order. */
    fun pictures(document: PDDocument, pageNumber: Int): List<Picture> {
        val page = document.getPage(pageNumber - 1)
        val geo = PdfPageGeometry.of(page)
        val inv = geo.inverseMatrixValues()
        val w = geo.displayWidth
        val h = geo.displayHeight
        val out = ArrayList<Picture>()
        for ((index, f) in scan(document, pageNumber).found.withIndex()) {
            val b = boxOf(f.ctm)
            var placed: FloatArray? = null
            if (w > 0f && h > 0f) {
                var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
                val us = floatArrayOf(b[0], b[2], b[2], b[0])
                val vs = floatArrayOf(b[1], b[1], b[3], b[3])
                for (k in 0 until 4) {
                    val fx = (inv[0] * us[k] + inv[2] * vs[k] + inv[4]) / w
                    val fy = 1f - (inv[1] * us[k] + inv[3] * vs[k] + inv[5]) / h
                    minX = minOf(minX, fx); maxX = maxOf(maxX, fx); minY = minOf(minY, fy); maxY = maxOf(maxY, fy)
                }
                if (!(maxX <= 0f || maxY <= 0f || minX >= 1f || minY >= 1f)) {
                    placed = floatArrayOf(minX.coerceIn(0f, 1f), minY.coerceIn(0f, 1f), maxX.coerceIn(0f, 1f), maxY.coerceIn(0f, 1f))
                }
            }
            out.add(Picture(index, f.image.width, f.image.height, b, placed))
        }
        return out
    }

    /**
     * Where a picture's box (fractions 0..1 of the displayed page, from the top-left) ends up after a drag (4.91): its centre moves by ([dx], [dy]) and its size is multiplied by [scale] about
     * that centre; kept inside the page. Null when the result would be smaller than 1 % of the page. The reader previews exactly this and stages the same numbers for [Op.Transform], so
     * the frame the person sees is where the saved picture lands (tools/verify/image_edit_real_run_check.py compares the two).
     */
    fun gestureBox(box: FloatArray, dx: Float, dy: Float, scale: Float): FloatArray? {
        val cx = (box[0] + box[2]) / 2f + dx
        val cy = (box[1] + box[3]) / 2f + dy
        val halfW = (box[2] - box[0]) / 2f * scale
        val halfH = (box[3] - box[1]) / 2f * scale
        val out = floatArrayOf((cx - halfW).coerceIn(0f, 1f), (cy - halfH).coerceIn(0f, 1f), (cx + halfW).coerceIn(0f, 1f), (cy + halfH).coerceIn(0f, 1f))
        return if (out[2] - out[0] < 0.01f || out[3] - out[1] < 0.01f) null else out
    }

    /** The picture under a tap at (x, y) (fractions 0..1 from the top-left): the SMALLEST box that contains it (a small picture on top of a big one wins). */
    fun pick(pictures: List<Picture>, x: Float, y: Float): Picture? =
        pictures.filter { p -> p.placed?.let { x >= it[0] && x <= it[2] && y >= it[1] && y <= it[3] } == true }
            .minByOrNull { p -> p.placed!!.let { (it[2] - it[0]) * (it[3] - it[1]) } }

    enum class Result { SUCCESS, NOT_FOUND, DEGENERATE }

    private fun writeBack(document: PDDocument, pageNumber: Int, tokens: List<Any>) {
        val stream = PDStream(document)
        stream.createOutputStream(COSName.FLATE_DECODE).use { ContentStreamWriter(it).writeTokens(tokens) }
        document.getPage(pageNumber - 1).setContents(stream)
    }

    private fun cmTokens(m: FloatArray, gsName: COSName? = null): List<Any> = ArrayList<Any>().apply {
        add(Operator.getOperator("q"))
        if (gsName != null) { add(gsName); add(Operator.getOperator("gs")) }
        for (v in m) add(COSFloat(v))
        add(Operator.getOperator("cm"))
    }

    fun delete(document: PDDocument, pageNumber: Int, index: Int): Result {
        val scan = scan(document, pageNumber)
        val f = scan.found.getOrNull(index) ?: return Result.NOT_FOUND
        scan.tokens.removeAt(f.doOpIndex)
        scan.tokens.removeAt(f.nameIndex)
        writeBack(document, pageNumber, scan.tokens)
        return Result.SUCCESS
    }

    fun transform(document: PDDocument, pageNumber: Int, op: Op.Transform): Result {
        val scan = scan(document, pageNumber)
        val f = scan.found.getOrNull(op.index) ?: return Result.NOT_FOUND
        if (op.scale <= 0f) return Result.DEGENERATE
        val opacity = op.opacity
        if (opacity != null && (opacity <= 0f || opacity > 1f)) return Result.DEGENERATE
        val ctmInv = inverse(f.ctm) ?: return Result.DEGENERATE
        val geo = PdfPageGeometry.of(document.getPage(pageNumber - 1))
        val m = geo.displayMatrixValues()
        val minv = inverse(m) ?: return Result.DEGENERATE
        val ddx = op.dx * geo.displayWidth
        val ddy = -op.dy * geo.displayHeight
        val shiftX = m[0] * ddx + m[2] * ddy
        val shiftY = m[1] * ddx + m[3] * ddy
        // the picture's centre on the page; the turn is clockwise AS DISPLAYED, and the display frame is upright, so a clockwise turn is a negative angle in PDF's y-up space
        val cx = f.ctm[4] + 0.5f * f.ctm[0] + 0.5f * f.ctm[2]
        val cy = f.ctm[5] + 0.5f * f.ctm[1] + 0.5f * f.ctm[3]
        val rad = Math.toRadians(-op.turnDegrees.toDouble())
        val c = cos(rad).toFloat(); val s = sin(rad).toFloat()
        val aboutCentre = multiply(multiply(floatArrayOf(1f, 0f, 0f, 1f, -cx, -cy), floatArrayOf(op.scale * c, op.scale * s, -op.scale * s, op.scale * c, 0f, 0f)), floatArrayOf(1f, 0f, 0f, 1f, cx + shiftX, cy + shiftY))
        // a mirror AS DISPLAYED: reflect in the upright display frame (x right, y up) about the picture's centre, then bring it back to page space
        var flip = floatArrayOf(1f, 0f, 0f, 1f, 0f, 0f)
        val cdx = cx * minv[0] + cy * minv[2] + minv[4]
        val cdy = cx * minv[1] + cy * minv[3] + minv[5]
        if (op.flipH) flip = multiply(flip, multiply(multiply(minv, floatArrayOf(-1f, 0f, 0f, 1f, 2f * cdx, 0f)), m))
        if (op.flipV) flip = multiply(flip, multiply(multiply(minv, floatArrayOf(1f, 0f, 0f, -1f, 0f, 2f * cdy)), m))
        val local = multiply(multiply(f.ctm, multiply(flip, aboutCentre)), ctmInv)
        var gsName: COSName? = null
        if (opacity != null) {
            val gs = PDExtendedGraphicsState()
            gs.setNonStrokingAlphaConstant(opacity)
            gs.setStrokingAlphaConstant(opacity)
            gsName = document.getPage(pageNumber - 1).resources.add(gs)
        }
        scan.tokens.add(f.doOpIndex + 1, Operator.getOperator("Q"))
        scan.tokens.addAll(f.nameIndex, cmTokens(local, gsName))
        writeBack(document, pageNumber, scan.tokens)
        return Result.SUCCESS
    }

    fun crop(document: PDDocument, pageNumber: Int, op: Op.Crop): Result {
        val scan = scan(document, pageNumber)
        val f = scan.found.getOrNull(op.index) ?: return Result.NOT_FOUND
        val sides = floatArrayOf(op.left, op.top, op.right, op.bottom)
        if (sides.any { it < 0f || it > 0.95f } || op.left + op.right >= 1f || op.top + op.bottom >= 1f) return Result.DEGENERATE
        val ctmInv = inverse(f.ctm) ?: return Result.DEGENERATE
        val m = PdfPageGeometry.of(document.getPage(pageNumber - 1)).displayMatrixValues()
        val minv = inverse(m) ?: return Result.DEGENERATE
        // the picture's box in the upright display frame (x right, y up)
        var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE
        for ((ux, uy) in listOf(0f to 0f, 1f to 0f, 0f to 1f, 1f to 1f)) {
            val px = ux * f.ctm[0] + uy * f.ctm[2] + f.ctm[4]
            val py = ux * f.ctm[1] + uy * f.ctm[3] + f.ctm[5]
            val dx = px * minv[0] + py * minv[2] + minv[4]
            val dy = px * minv[1] + py * minv[3] + minv[5]
            minX = minOf(minX, dx); maxX = maxOf(maxX, dx); minY = minOf(minY, dy); maxY = maxOf(maxY, dy)
        }
        val w = maxX - minX
        val h = maxY - minY
        val x0 = minX + op.left * w; val x1 = maxX - op.right * w
        val y0 = minY + op.bottom * h; val y1 = maxY - op.top * h
        // the kept rectangle, display -> page -> the picture's own unit square; its bounding box there is the clip (exact for the usual quarter turns)
        var lx0 = Float.MAX_VALUE; var ly0 = Float.MAX_VALUE; var lx1 = -Float.MAX_VALUE; var ly1 = -Float.MAX_VALUE
        for ((dx, dy) in listOf(x0 to y0, x1 to y0, x0 to y1, x1 to y1)) {
            val px = dx * m[0] + dy * m[2] + m[4]
            val py = dx * m[1] + dy * m[3] + m[5]
            val lx = px * ctmInv[0] + py * ctmInv[2] + ctmInv[4]
            val ly = px * ctmInv[1] + py * ctmInv[3] + ctmInv[5]
            lx0 = minOf(lx0, lx); lx1 = maxOf(lx1, lx); ly0 = minOf(ly0, ly); ly1 = maxOf(ly1, ly)
        }
        lx0 = lx0.coerceIn(0f, 1f); lx1 = lx1.coerceIn(0f, 1f); ly0 = ly0.coerceIn(0f, 1f); ly1 = ly1.coerceIn(0f, 1f)
        if (lx1 - lx0 < 1e-4f || ly1 - ly0 < 1e-4f) return Result.DEGENERATE
        scan.tokens.add(f.doOpIndex + 1, Operator.getOperator("Q"))
        scan.tokens.addAll(f.nameIndex, listOf(
            Operator.getOperator("q"), COSFloat(lx0), COSFloat(ly0), COSFloat(lx1 - lx0), COSFloat(ly1 - ly0),
            Operator.getOperator("re"), Operator.getOperator("W"), Operator.getOperator("n")
        ))
        writeBack(document, pageNumber, scan.tokens)
        return Result.SUCCESS
    }

    fun replace(document: PDDocument, pageNumber: Int, index: Int, make: (PDDocument) -> PDImageXObject): Result {
        val scan = scan(document, pageNumber)
        val f = scan.found.getOrNull(index) ?: return Result.NOT_FOUND
        val page = document.getPage(pageNumber - 1)
        val image = make(document)
        if (image.width <= 0 || image.height <= 0) return Result.DEGENERATE
        val wOld = hypot(f.ctm[0], f.ctm[1])
        val hOld = hypot(f.ctm[2], f.ctm[3])
        if (wOld <= 0f || hOld <= 0f) return Result.DEGENERATE
        val aspect = image.width.toFloat() / image.height.toFloat()
        val sx: Float; val sy: Float
        if (aspect > wOld / hOld) { sx = 1f; sy = (wOld / aspect) / hOld } else { sy = 1f; sx = (hOld * aspect) / wOld }
        val name = page.resources.add(image)
        scan.tokens[f.nameIndex] = name
        scan.tokens.add(f.doOpIndex + 1, Operator.getOperator("Q"))
        scan.tokens.addAll(f.nameIndex, cmTokens(floatArrayOf(sx, 0f, 0f, sy, (1f - sx) / 2f, (1f - sy) / 2f)))
        writeBack(document, pageNumber, scan.tokens)
        return Result.SUCCESS
    }

    private fun openForEdit(file: File): PDDocument =
        PDDocument.load(file, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(file.parentFile))

    /** The pictures of page [page] (1-based) of [file], read from a fresh copy; an unreadable page gives an empty list. */
    fun pictures(file: File, page: Int): List<Picture> {
        val doc = try { openForEdit(file) } catch (e: Exception) { return emptyList() }
        try {
            if (page !in 1..doc.numberOfPages) return emptyList()
            return pictures(doc, page)
        } catch (e: Exception) {
            return emptyList()
        } finally {
            runCatching { doc.close() }
        }
    }

    private fun pageOf(op: Op): Int = when (op) { is Op.Delete -> op.page; is Op.Transform -> op.page; is Op.Crop -> op.page; is Op.Replace -> op.page }

    /** The order the ops are really made in: every change that keeps the pictures' numbers first (in the order given), then the deletions, the highest number first on each page (a delete renumbers the later pictures). */
    internal fun ordered(ops: List<Op>): List<Op> =
        ops.filter { it !is Op.Delete } + ops.filterIsInstance<Op.Delete>().sortedWith(compareBy({ it.page }, { -it.index }))

    /**
     * Writes every op of [ops] (in the order of [ordered]) into a NEW file [out] (the original is not touched), in order. Pictures are numbered as in the file given ([ordered] makes that hold even when a delete was asked first). Throws `IllegalStateException` naming the first
     * op that cannot be made instead of saving a copy that silently lacks it; the output must open as a PDF with the same number of pages ([PdfVerify]).
     */
    fun applyAll(src: File, out: File, ops: List<Op>) {
        val doc = openForEdit(src)
        try {
            val pages = doc.numberOfPages
            for (op in ordered(ops)) {
                val page = pageOf(op)
                if (page !in 1..pages) throw IllegalStateException("page $page not found")
                val result = when (op) {
                    is Op.Delete -> delete(doc, page, op.index)
                    is Op.Transform -> transform(doc, page, op)
                    is Op.Crop -> crop(doc, page, op)
                    is Op.Replace -> replace(doc, page, op.index, op.make)
                }
                if (result != Result.SUCCESS) throw IllegalStateException("picture edit refused on page $page: $result")
            }
            doc.save(out)
            if (!PdfVerify.opensAsPdf(out, pages)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
        } finally {
            runCatching { doc.close() }
        }
    }
}
