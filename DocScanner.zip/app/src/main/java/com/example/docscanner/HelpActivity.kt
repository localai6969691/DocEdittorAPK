package com.example.docscanner

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.docscanner.databinding.ActivityHelpBinding
import com.example.docscanner.util.CrashLog

/**
 * In-app help (what the app does and where to find it), plus the three ways to reach the developer without any account:
 * send feedback, send the last crash report (see [CrashLog]) and rate the app on Google Play. Nothing is sent automatically:
 * each button opens the system share sheet, so the user sees the text and chooses the app.
 */
class HelpActivity : BaseActivity() {

    private lateinit var binding: ActivityHelpBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHelpBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.help_title)

        SECTIONS.forEach { (titleRes, bodyRes) ->
            binding.llHelpSections.addView(sectionTitle(getString(titleRes)))
            binding.llHelpSections.addView(sectionBody(getString(bodyRes)))
        }
        binding.btnHelpFeedback.setOnClickListener { sendFeedback() }
        binding.btnHelpCrash.setOnClickListener {
            val report = CrashLog.latest(this, includeAsked = true)
            if (report != null) shareText(getString(R.string.help_crash_subject), CrashLog.reportText(this, report))
        }
        binding.btnHelpRate.setOnClickListener { openStorePage() }
    }

    override fun onResume() {
        super.onResume()
        binding.btnHelpCrash.visibility = if (CrashLog.latest(this, includeAsked = true) != null) View.VISIBLE else View.GONE
    }

    private fun sendFeedback() {
        shareText(getString(R.string.help_feedback_subject), getString(R.string.help_feedback_template) + "\n\n" + CrashLog.deviceLine(this))
    }

    private fun shareText(subject: String, text: String) {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(send, subject))
    }

    private fun openStorePage() {
        val id = packageName
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$id")))
        } catch (e: ActivityNotFoundException) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$id")))
            } catch (e2: ActivityNotFoundException) {
                Toast.makeText(this, R.string.help_store_unavailable, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun sectionTitle(text: String) = TextView(this).apply {
        this.text = text
        textSize = 16f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        setTextColor(getColor(R.color.text_primary))
        setPadding(0, dp(18), 0, dp(4))
    }

    private fun sectionBody(text: String) = TextView(this).apply {
        this.text = text
        textSize = 14f
        setLineSpacing(0f, 1.15f)
        setTextColor(getColor(R.color.text_secondary))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        /** (title, body) of each help section, in reading order. */
        val SECTIONS = listOf(
            R.string.help_quick_title to R.string.help_quick_body,
            R.string.help_project_title to R.string.help_project_body,
            R.string.help_incoming_title to R.string.help_incoming_body,
            R.string.help_tools_title to R.string.help_tools_body,
            R.string.help_ocr_title to R.string.help_ocr_body,
            R.string.help_privacy_title to R.string.help_privacy_body,
            R.string.help_tips_title to R.string.help_tips_body
        )
    }
}
