package com.example.docscanner.util

import java.text.Normalizer
import java.util.Locale

/**
 * The matching behind "Find a tool" on the main screen (phiên 25, TECHNICAL_DOCS.md 4.75; PDF list item 4.9 "command palette"): the person types a few letters and the tools whose name fits
 * come first. The matching is done on the names with their ACCENTS REMOVED and in lower case, so "ky" finds "Ký tài liệu", "dat mat khau" finds "Đặt mật khẩu" and "word" finds "Word".
 *
 * [score] is 0 for no match, else (higher = better): 100 the whole name; 90 the name starts with the query; 80 a word of the name starts with it; 60 the query is inside the name; 40 every word of
 * a several-word query starts some word of the name, in any order; 20 the query's letters appear in order (two letters or more, so typing "pf" finds "PDF"). [rank] keeps the order of the list
 * for equal scores, and gives every name, in order, for an empty query. Pure, no Android: tools/verify/command_palette_real_run_check.py runs it for real.
 */
object CommandPalette {

    /** Lower case, accents and tone marks removed (đ -> d), runs of spaces collapsed to one, ends trimmed. */
    fun fold(s: String): String {
        val decomposed = Normalizer.normalize(s, Normalizer.Form.NFD)
        val sb = StringBuilder(decomposed.length)
        for (c in decomposed) {
            if (Character.getType(c) == Character.NON_SPACING_MARK.toInt()) continue
            when (c) {
                '\u0111', '\u0110' -> sb.append('d')
                else -> sb.append(c)
            }
        }
        return sb.toString().lowercase(Locale.ROOT).replace(Regex("\\s+"), " ").trim()
    }

    fun score(query: String, name: String): Int {
        val q = fold(query)
        if (q.isEmpty()) return 1
        val n = fold(name)
        if (n == q) return 100
        if (n.startsWith(q)) return 90
        val words = n.split(' ')
        if (words.any { it.startsWith(q) }) return 80
        if (n.contains(q)) return 60
        val parts = q.split(' ').filter { it.isNotEmpty() }
        if (parts.size > 1 && parts.all { part -> words.any { it.startsWith(part) } }) return 40
        if (q.length >= 2) {
            var i = 0
            for (c in n) {
                if (i < q.length && c == q[i]) i++
            }
            if (i == q.length) return 20
        }
        return 0
    }

    /** The indices of [names] that match [query], best first; names with the same score stay in their original order. */
    fun rank(query: String, names: List<String>): List<Int> {
        val scored = ArrayList<Pair<Int, Int>>()
        for ((i, name) in names.withIndex()) {
            val s = score(query, name)
            if (s > 0) scored.add(Pair(i, s))
        }
        return scored.sortedWith(compareBy({ -it.second }, { it.first })).map { it.first }
    }
}
