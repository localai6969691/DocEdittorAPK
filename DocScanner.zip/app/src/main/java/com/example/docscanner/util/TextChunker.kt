package com.example.docscanner.util

/**
 * Cuts text into pieces of at most [max] characters for engines that take a limited amount per call - Android's text-to-speech
 * (about 4000 characters per utterance) and on-device translation. Each non-empty LINE is a unit and consecutive lines are packed
 * together while they fit; a line longer than [max] is cut after a sentence end (`. ! ? …` followed by a space), else at a space,
 * else hard at [max]. Nothing is dropped or reordered: the pieces, read in order, contain every non-blank character of the
 * input. Pure - mirrored in tools/verify/text_chunker_check.py.
 */
object TextChunker {

    fun split(text: String, max: Int): List<String> {
        require(max >= 20) { "max too small" }
        val out = ArrayList<String>()
        val current = StringBuilder()
        fun flush() {
            val t = current.toString().trim()
            if (t.isNotEmpty()) out.add(t)
            current.setLength(0)
        }
        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            for (piece in cutLine(line, max)) {
                if (current.isNotEmpty() && current.length + 1 + piece.length > max) flush()
                if (current.isNotEmpty()) current.append('\n')
                current.append(piece)
            }
        }
        flush()
        return out
    }

    private fun cutLine(line: String, max: Int): List<String> {
        if (line.length <= max) return listOf(line)
        val pieces = ArrayList<String>()
        var rest = line
        while (rest.length > max) {
            val window = rest.substring(0, max)
            var cut = -1
            for (i in window.length - 1 downTo 1) {
                val c = window[i - 1]
                if ((c == '.' || c == '!' || c == '?' || c == '…') && window[i] == ' ') { cut = i; break }
            }
            if (cut <= 0) cut = window.lastIndexOf(' ')
            if (cut <= 0) cut = max
            val head = rest.substring(0, cut).trim()
            if (head.isNotEmpty()) pieces.add(head)
            rest = rest.substring(cut).trim()
        }
        if (rest.isNotEmpty()) pieces.add(rest)
        return pieces
    }
}
