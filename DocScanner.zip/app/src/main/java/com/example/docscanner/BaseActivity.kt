package com.example.docscanner

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import com.example.docscanner.util.FontScale

/**
 * Every screen of the app extends this instead of AppCompatActivity directly, for ONE reason: the in-app "Text size" setting ([FontScale]) has to be applied in
 * attachBaseContext of each activity. With the default (Standard) it does nothing at all. tools/verify/base_activity_check.py makes sure no activity is left behind.
 * (Do NOT also override applyOverrideConfiguration to copy the base configuration: AppCompat uses that hook to apply the per-app language.)
 */
abstract class BaseActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(FontScale.wrap(newBase))
    }
}
