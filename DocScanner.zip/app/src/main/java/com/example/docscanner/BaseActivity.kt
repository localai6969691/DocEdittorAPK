package com.example.docscanner

import android.content.Context
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.docscanner.util.FontScale
import com.example.docscanner.util.ReadableFont

/**
 * Every screen of the app extends this instead of AppCompatActivity directly, for ONE reason: the in-app "Text size" setting ([FontScale]) has to be applied in
 * attachBaseContext of each activity. With the default (Standard) it does nothing at all. tools/verify/base_activity_check.py makes sure no activity is left behind.
 * (Do NOT also override applyOverrideConfiguration to copy the base configuration: AppCompat uses that hook to apply the per-app language.)
 * The same place applies the "Easy-to-read font" ([ReadableFont]) as a theme overlay in onCreate, BEFORE super.onCreate so AppCompat inflates with it; the screen's own
 * theme (e.g. the full-screen one) stays as declared in the manifest because the overlay is applied on top of it, not instead of it. Setting off = no overlay.
 */
abstract class BaseActivity : AppCompatActivity() {
    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(FontScale.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        if (ReadableFont.isOn(this)) theme.applyStyle(R.style.ThemeOverlay_DocScanner_ReadableFont, true)
        super.onCreate(savedInstanceState)
    }
}
