package com.example.docscanner

import android.content.Context
import android.content.res.ColorStateList
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.Gravity
import androidx.core.view.ViewCompat
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.GridLayout
import android.widget.FrameLayout
import com.google.android.material.button.MaterialButton
import android.widget.Toast
import android.graphics.BitmapFactory
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.TooltipCompat
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.adapter.PdfReaderPageAdapter
import com.example.docscanner.databinding.ActivityPdfReaderBinding
import com.example.docscanner.util.EbookBuilder
import com.example.docscanner.util.EpubSearch
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfAutoToc
import com.example.docscanner.util.PdfBookmarks
import com.example.docscanner.util.PdfImageEditor
import com.example.docscanner.util.PdfInk
import com.example.docscanner.util.ParagraphFontSource
import com.example.docscanner.util.PdfParagraphEditor
import com.example.docscanner.util.PdfRedactor
import com.example.docscanner.util.PdfStamper
import com.example.docscanner.util.PdfTextEditor
import com.example.docscanner.util.PdfTextLayer
import com.example.docscanner.util.PdfTextMarkup
import com.example.docscanner.util.ReaderEdits
import com.example.docscanner.util.SignedPdfGuard
import com.example.docscanner.util.StampRenderer
import com.example.docscanner.util.PdfPageBitmap
import com.example.docscanner.util.Feedback
import com.example.docscanner.util.FileVersions
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfFormFiller
import com.example.docscanner.util.PdfPrintAdapter
import com.example.docscanner.util.PdfReadingPositions
import com.example.docscanner.util.PdfSecurityTools
import com.example.docscanner.util.PdfTextExtractor
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Reads a PDF inside the app (session 23, 4.58 and 4.59). Opened by tapping a PDF in the history, by "Open with" from a file manager and by dropping a PDF on the main
 * screen. The toolbar offers only Edit; Share, Print, Go to page, Contents and Search sit in the overflow menu. The editing tools appear when the person taps Edit, instead
 * of a wall of functions the moment a PDF is opened.
 *
 * What the reader does: pinch to zoom, drag sideways and double-tap ([com.example.docscanner.view.ZoomRecyclerView]); remembers the page where the person stopped
 * ([PdfReadingPositions]); jumps to a page, to a bookmark of the PDF ([PdfBookmarks]) or to a search hit ([EpubSearch] over the text layer, so a scan without a text layer
 * says so); asks for the password of a protected PDF and works on an unlocked copy.
 *
 * The reader always works from a LOCAL FILE: a history file as it is, anything else as a copy made by [copyToCache] before this screen starts. That way the access a file
 * manager grants for a moment is not needed afterwards, and the editing tools receive an address of our own. Copies (and the unlocked copy of a protected
 * PDF) are deleted when the screen finishes. Pages are drawn by [PdfPageBitmap] (the platform renderer).
 */
class PdfReaderActivity : BaseActivity() {

    private lateinit var binding: ActivityPdfReaderBinding
    private lateinit var layoutManager: LinearLayoutManager
    private var pageAdapter: PdfReaderPageAdapter? = null

    private val lock = Any()
    private var closed = false
    private var session: PdfPageBitmap.Session? = null
    private var pdfFile: File? = null
    private var isTemp = false
    private var pageCount = 0
    private var baseWidthPx = 0
    private var positionKey = ""
    private var pageTexts: List<String>? = null

    // editing toolbar (4.61)
    private val edits = ReaderEdits()
    private var tool: ReaderEdits.Kind? = null
    private var editing = false
    private var pendingText: String? = null
    private val wordCache = HashMap<Int, List<PdfTextMarkup.WordBox>>()
    private val wordRequests = HashSet<Int>()
    /** Set after a contents list was made: the saved copy opens, then its contents are shown (4.70). */
    private var showContentsWhenOpen = false
    private var resumePage: Int? = null
    private var resumeZoom: Float? = null
    // the colour of each tool (4.69): the highlight and the marker start yellow, the others red; the colour button changes the colour of the ACTIVE tool, so the dot always shows what will be drawn
    // the thickness of the pen and of the marker: an index into ReaderEdits.WIDTH_FACTORS (1 = the usual thickness), set in the colour box (4.72)
    private val toolWidthIndex = HashMap<ReaderEdits.Kind, Int>()
    private var redoHintShown = false

    /** What the person last searched for: its words are painted orange on every page that is shown (4.77). */
    private var hitQuery: String? = null
    private val toolColors = HashMap<ReaderEdits.Kind, Int>()
    private fun colorFor(kind: ReaderEdits.Kind?): Int = (if (kind == null) null else toolColors[kind]) ?: ReaderEdits.defaultColor(kind)
    private val currentColor: Int get() = colorFor(tool)

    /** The thickness (fraction of the page width) of a new stroke of [kind]: the usual thickness times the factor chosen for that tool; 0 for a tool that does not draw lines. */
    private fun widthFor(kind: ReaderEdits.Kind?): Float {
        val usual = when (kind) {
            ReaderEdits.Kind.PEN -> PdfInk.PEN_WIDTH
            ReaderEdits.Kind.MARKER -> PdfInk.MARKER_WIDTH
            else -> return 0f
        }
        return usual * ReaderEdits.WIDTH_FACTORS[toolWidthIndex[kind] ?: 1]
    }

    // the pieces of existing text the edit-text tool can change, read once per page in the background (4.69)
    private val chunkCache = HashMap<Int, List<PdfTextEditor.PlacedChunk>>()
    private val chunkRequests = HashSet<Int>()
    // the form fields of a page, tapped with the same tool (4.71)
    private val fieldCache = HashMap<Int, List<PdfFormFiller.PlacedField>>()
    // the pictures already in a page, tapped with the same tool (4.88)
    private val pictureCache = HashMap<Int, List<PdfImageEditor.Picture>>()
    // the paragraphs (blocks of lines) of a page, for "Edit whole paragraph" (4.89)
    private val blockCache = HashMap<Int, List<PdfParagraphEditor.Block>>()
    private var pendingReplace: Pair<Int, PdfImageEditor.Picture>? = null
    // the picture selected with handles (4.91): page, picture, and its box as it is after the drags made so far
    private var selectedPage = -1
    private var selectedPicture: PdfImageEditor.Picture? = null
    private var selectedBox: FloatArray? = null
    private val replacePicturePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri -> onReplacementChosen(uri) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfReaderBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val path = intent.getStringExtra(EXTRA_PDF_PATH)
        val file = if (path != null) File(path) else null
        if (file == null || !file.isFile) {
            finish()
            return
        }
        val name = intent.getStringExtra(EXTRA_TITLE) ?: file.name
        title = name
        isTemp = intent.getBooleanExtra(EXTRA_TEMP, false)
        positionKey = PdfReadingPositions.key(name, file.length())
        useFile(file)
        setupEditBar()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (editing) closeEditing() else finish()
            }
        })
        startOpening()
    }

    /** Makes [file] the PDF being read (the original, or the unlocked copy of a protected one). */
    private fun useFile(file: File) {
        pdfFile = file
        pageTexts = null
        wordCache.clear()
        wordRequests.clear()
        hitQuery = null
        chunkCache.clear()
        chunkRequests.clear()
        fieldCache.clear()
        pictureCache.clear()
        blockCache.clear()
    }

    private fun startOpening() {
        val file = pdfFile ?: return
        binding.progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            val opened = withContext(Dispatchers.IO) { PdfPageBitmap.open(file) }
            binding.progress.visibility = View.GONE
            if (opened == null) {
                handleOpenFailure(file)
                return@launch
            }
            session = opened
            pageCount = opened.pageCount
            showPages()
            if (showContentsWhenOpen) {
                showContentsWhenOpen = false
                showContents()
            }
        }
    }

    private fun showPages() {
        baseWidthPx = minOf(resources.displayMetrics.widthPixels, MAX_PAGE_WIDTH)
        layoutManager = LinearLayoutManager(this)
        binding.rvPages.layoutManager = layoutManager
        val adapter = PdfReaderPageAdapter(
            pageCount, baseWidthPx, resources.displayMetrics.widthPixels, lifecycleScope,
            { index -> getString(R.string.reader_page_of, index + 1, pageCount) },
            { index, width -> renderPage(index, width) }
        )
        adapter.edits = edits
        adapter.tool = tool
        adapter.onFrame = { page, box -> onFrame(page, box) }
        adapter.onTextDrag = { page, ax, ay, bx, by -> onTextDrag(page, ax, ay, bx, by) }
        adapter.wordsProvider = { page -> wordCache[page] ?: run { requestWords(page); null } }
        adapter.searchBoxesProvider = { page ->
            val q = hitQuery
            if (q == null) {
                emptyList()
            } else {
                val words = wordCache[page]
                if (words == null) {
                    requestWords(page)
                    null
                } else {
                    searchBoxesOf(words, q)
                }
            }
        }
        adapter.textBoxesProvider = { page ->
            val chunks = chunkCache[page]
            val fields = fieldCache[page]
            val pictures = pictureCache[page]
            if (chunks == null || fields == null || pictures == null) {
                requestChunks(page)
                null
            } else {
                chunks.map { it.box } + fields.map { it.box } + pictures.mapNotNull { it.placed }
            }
        }
        adapter.onErase = { page, x, y, w, h -> eraseAt(page, x, y, w, h) }
        adapter.onTap = { page, x, y, w, h -> onTextTap(page, x, y, w, h) }
        adapter.selectedPictureProvider = { page -> if (page == selectedPage) selectedBox else null }
        adapter.onPictureGesture = { page, dx, dy, scale -> onPictureGesture(page, dx, dy, scale) }
        adapter.onPictureTap = { page -> selectedPicture?.let { askPictureAction(page, it) } }
        adapter.onStroke = { page, points -> onStroke(page, points) }
        adapter.toolColor = currentColor
        pageAdapter = adapter
        binding.rvPages.adapter = adapter
        // no cross-fade when a row changes (4.66): the default change animation fades the old row out and a copy in, which shows as a blink when the marks or the picture of a page are refreshed
        (binding.rvPages.itemAnimator as? androidx.recyclerview.widget.SimpleItemAnimator)?.supportsChangeAnimations = false
        binding.rvPages.oneFingerPan = tool == null
        // zoomed in, the pages are drawn at a larger width so the text stays sharp; back at 1x they return to the light size
        binding.rvPages.onZoomSettled = { zoomed ->
            val wanted = if (zoomed > 1.4f) maxOf(baseWidthPx, HIGH_PAGE_WIDTH) else baseWidthPx
            // the rows are NOT thrown away and rebound (notifyDataSetChanged made every page flash blank after a pinch, 4.66): each keeps its picture until the sharper one arrives
            adapter.applyWidth(wanted)
        }
        binding.rvPages.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                updatePageIndicator()
            }
        })
        binding.tvPageIndicator.visibility = View.VISIBLE
        updatePageIndicator()
        // after saving a copy the reader continues on the page it was on; otherwise on the page remembered for this PDF
        val stored = PdfReadingPositions.getPlace(prefs().getString(KEY_POSITIONS, "") ?: "", positionKey)
        val saved = resumePage ?: stored?.page
        val savedZoom = resumeZoom ?: stored?.zoom ?: 1f
        resumePage = null
        resumeZoom = null
        // the page AND the zoom the person left it at (4.82); the zoom is applied after the jump because jumping resets it
        binding.rvPages.post {
            if (saved != null && saved in 1 until pageCount) jumpToPage(saved)
            binding.rvPages.restoreZoom(savedZoom)
        }
    }

    private fun prefs() = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** One page at a time (the platform renderer allows only one open page); null when the screen has already been closed. */
    private fun renderPage(index: Int, width: Int) = synchronized(lock) {
        if (closed) null else session?.render(index, width)
    }

    private fun updatePageIndicator() {
        val first = layoutManager.findFirstVisibleItemPosition().coerceAtLeast(0)
        val indicator = binding.tvPageIndicator
        indicator.text = getString(R.string.reader_page_of, first + 1, pageCount)
        // shown while the pages move and for a moment after, then it fades out (4.66: a permanent solid box covered the text of the page)
        indicator.removeCallbacks(hideIndicator)
        indicator.animate().cancel()
        indicator.alpha = 1f
        indicator.postDelayed(hideIndicator, 1200)
    }

    private val hideIndicator = Runnable { binding.tvPageIndicator.animate().alpha(0f).setDuration(300).start() }

    private fun jumpToPage(index: Int) {
        if (pageCount == 0) return
        binding.rvPages.resetZoom()
        layoutManager.scrollToPositionWithOffset(index.coerceIn(0, pageCount - 1), 0)
    }

    override fun onPause() {
        super.onPause()
        if (pageCount > 0 && pageAdapter != null) {
            val first = layoutManager.findFirstVisibleItemPosition().coerceAtLeast(0)
            val p = prefs()
            p.edit().putString(KEY_POSITIONS, PdfReadingPositions.putPlace(p.getString(KEY_POSITIONS, "") ?: "", positionKey, first, binding.rvPages.zoom)).apply()
        }
    }

    // ---------------------------------------------------------------------------------------
    // PDFs the platform renderer cannot show: protected (ask for the password) or damaged
    // ---------------------------------------------------------------------------------------

    private fun handleOpenFailure(file: File) {
        lifecycleScope.launch {
            val protectedPdf = withContext(Dispatchers.IO) { needsPassword(file) }
            if (protectedPdf) askPassword(false) else showCannotShow()
        }
    }

    /** True only when PdfBox says a password is required (a damaged file is not "protected"). */
    private fun needsPassword(file: File): Boolean = try {
        PDDocument.load(file).close()
        false
    } catch (e: InvalidPasswordException) {
        true
    } catch (e: Throwable) {
        false
    }

    private fun askPassword(wrong: Boolean) {
        val input = EditText(this)
        input.setHint(R.string.reader_password_hint)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = FrameLayout(this)
        holder.setPadding(pad, pad / 2, pad, 0)
        holder.addView(input)
        AlertDialog.Builder(this)
            .setTitle(if (wrong) R.string.reader_password_wrong else R.string.reader_password_title)
            .setView(holder)
            .setPositiveButton(android.R.string.ok) { _, _ -> unlock(input.text.toString()) }
            .setNegativeButton(R.string.dialog_cancel) { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    /** Removes the password into a copy in the cache (the original is untouched) and opens that copy. */
    private fun unlock(password: String) {
        val source = pdfFile ?: return
        val dir = File(cacheDir, "pdf_reader")
        dir.mkdirs()
        val unlocked = File(dir, "unlocked_" + System.currentTimeMillis() + ".pdf")
        binding.progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            var wrong = false
            val ok = withContext(Dispatchers.IO) {
                try {
                    PdfSecurityTools.unprotect(source, unlocked, password)
                    true
                } catch (e: PdfSecurityTools.WrongPassword) {
                    wrong = true
                    false
                } catch (e: Throwable) {
                    runCatching { unlocked.delete() }
                    false
                }
            }
            binding.progress.visibility = View.GONE
            when {
                ok -> {
                    if (isTemp) runCatching { source.delete() }
                    isTemp = true
                    useFile(unlocked)
                    startOpening()
                }
                wrong -> askPassword(true)
                else -> showCannotShow()
            }
        }
    }

    private fun showCannotShow() {
        AlertDialog.Builder(this)
            .setMessage(R.string.reader_open_failed)
            .setPositiveButton(R.string.reader_more_tools) { _, _ -> openTools() }
            .setNegativeButton(R.string.dialog_cancel) { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    // ---------------------------------------------------------------------------------------
    // Menu
    // ---------------------------------------------------------------------------------------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_pdf_reader, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        // the version history is for a file of the library: a copy opened from elsewhere has none (4.78)
        menu.findItem(R.id.action_reader_versions)?.isVisible = libraryFile() != null
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val ready = pageCount > 0 && pageAdapter != null
        when (item.itemId) {
            android.R.id.home -> finish()
            R.id.action_reader_edit -> if (editing) closeEditing() else openEditing()
            R.id.action_reader_share -> pdfFile?.let { FileUtils.shareFile(this, it, getString(R.string.action_share)) }
            R.id.action_reader_print -> pdfFile?.let { PdfPrintAdapter.print(this, it) }
            R.id.action_reader_go_to -> if (ready) askPageNumber()
            R.id.action_reader_contents -> if (ready) showContents()
            R.id.action_reader_search -> if (ready) askSearch()
            R.id.action_reader_versions -> showVersions()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private fun askPageNumber() {
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_NUMBER
        input.setHint(getString(R.string.reader_go_to_prompt, pageCount))
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = FrameLayout(this)
        holder.setPadding(pad, pad / 2, pad, 0)
        holder.addView(input)
        AlertDialog.Builder(this)
            .setTitle(R.string.reader_go_to_page)
            .setView(holder)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val number = input.text.toString().trim().toIntOrNull()
                if (number != null && number in 1..pageCount) jumpToPage(number - 1)
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    /** The PDF's own bookmarks, indented by level; each jumps to its page. Entries whose destination cannot be found are left out. */
    private fun showContents() {
        val file = pdfFile ?: return
        lifecycleScope.launch {
            val entries = withContext(Dispatchers.IO) {
                try { PdfBookmarks.normalizeLevels(PdfBookmarks.readFile(file).first.filter { it.page >= 0 }) } catch (e: Throwable) { emptyList() }
            }
            if (entries.isEmpty()) {
                askCreateContents()
                return@launch
            }
            val labels = entries.map { "    ".repeat((it.level - 1).coerceAtLeast(0)) + it.title.trim() }
            AlertDialog.Builder(this@PdfReaderActivity)
                .setTitle(R.string.reader_contents)
                .setItems(labels.toTypedArray()) { _, which -> jumpToPage(entries[which].page) }
                .setNegativeButton(R.string.dialog_cancel, null)
                .show()
        }
    }

    /**
     * The PDF has no contents list (4.70): instead of only saying so, ask whether to make one from the headings in its text. Yes: [createContents] finds them, saves a COPY with the
     * list as bookmarks (the original stays as it is, like every other change made in the reader) and shows that copy's contents.
     */
    private fun askCreateContents() {
        AlertDialog.Builder(this)
            .setTitle(R.string.reader_contents)
            .setMessage(getString(R.string.reader_no_contents) + "\n\n" + getString(R.string.reader_contents_ask))
            .setPositiveButton(R.string.reader_contents_create) { _, _ -> createContents() }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun createContents() {
        val src = pdfFile ?: return
        binding.progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            val found = withContext(Dispatchers.Default) { PdfAutoToc.detect(src) }
            val message: Int? = when (found.status) {
                PdfAutoToc.Status.NO_TEXT -> R.string.reader_search_no_text
                PdfAutoToc.Status.NO_HEADINGS, PdfAutoToc.Status.UNREADABLE -> R.string.reader_contents_none_found
                PdfAutoToc.Status.FOUND -> null
            }
            if (message != null) {
                binding.progress.visibility = View.GONE
                Toast.makeText(this@PdfReaderActivity, message, Toast.LENGTH_LONG).show()
                return@launch
            }
            // writing a copy of a signed PDF breaks the signature: say so first, as "Save a copy" does
            if (!SignedPdfGuard.confirm(this@PdfReaderActivity, src)) {
                binding.progress.visibility = View.GONE
                return@launch
            }
            val out = File(PdfExporter.exportDir(this@PdfReaderActivity), FileUtils.defaultSecurityName("contents") + ".pdf")
            val saved = runCatching { withContext(Dispatchers.Default) { PdfBookmarks.saveWithOutline(src, out, found.entries) } }
            binding.progress.visibility = View.GONE
            if (saved.isFailure) {
                runCatching { out.delete() }
                Toast.makeText(this@PdfReaderActivity, R.string.reader_edit_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            Toast.makeText(this@PdfReaderActivity, getString(R.string.reader_contents_created, found.entries.size, out.name), Toast.LENGTH_LONG).show()
            showContentsWhenOpen = true
            switchTo(out)
        }
    }

    private fun askSearch() {
        val input = EditText(this)
        input.setHint(R.string.epub_search_hint)
        input.setSingleLine()
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = FrameLayout(this)
        holder.setPadding(pad, pad / 2, pad, 0)
        holder.addView(input)
        AlertDialog.Builder(this)
            .setTitle(R.string.reader_search)
            .setView(holder)
            .setPositiveButton(android.R.string.ok) { _, _ -> runSearch(input.text.toString()) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    /**
     * Searches the text layer (extracted once per PDF and kept) with [EpubSearch], which ignores case and accents; every page is one "chapter" whose lines are the
     * "paragraphs". A scanned PDF has no text layer: say so and point to the searchable-PDF tool instead of finding nothing.
     */
    /** One box per line of every occurrence of [query] among the page's [words]: the part of a match on one line is one box, so a phrase that wraps gives two. */
    private fun searchBoxesOf(words: List<PdfTextMarkup.WordBox>, query: String): List<FloatArray> {
        val boxes = ArrayList<FloatArray>()
        for (range in PdfTextMarkup.findPhrase(words, query)) {
            val byLine = LinkedHashMap<Int, FloatArray>()
            for (i in range) {
                val w = words[i]
                val cur = byLine[w.line]
                byLine[w.line] = if (cur == null) {
                    w.box.copyOf()
                } else {
                    floatArrayOf(minOf(cur[0], w.box[0]), minOf(cur[1], w.box[1]), maxOf(cur[2], w.box[2]), maxOf(cur[3], w.box[3]))
                }
            }
            boxes.addAll(byLine.values)
        }
        return boxes
    }

    private fun runSearch(query: String) {
        if (query.isBlank()) return
        val file = pdfFile ?: return
        binding.progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            val texts = pageTexts ?: withContext(Dispatchers.IO) { PdfTextExtractor.textLayer(file) }
            pageTexts = texts
            if (texts == null || texts.all { it.isBlank() }) {
                binding.progress.visibility = View.GONE
                Toast.makeText(this@PdfReaderActivity, R.string.reader_search_no_text, Toast.LENGTH_LONG).show()
                return@launch
            }
            val total = IntArray(1)
            val hits = withContext(Dispatchers.Default) {
                val chapters = texts.map { page -> EbookBuilder.Chapter("", page.lines().map { it.trim() }.filter { it.isNotEmpty() }) }
                EpubSearch.search(chapters, query, MAX_SHOWN_HITS, total)
            }
            binding.progress.visibility = View.GONE
            if (hits.isEmpty()) {
                Toast.makeText(this@PdfReaderActivity, getString(R.string.epub_search_none, query), Toast.LENGTH_LONG).show()
                return@launch
            }
            val labels = hits.map { getString(R.string.reader_hit_page, it.chapter + 1) + " · " + it.before + it.match + it.after }
            AlertDialog.Builder(this@PdfReaderActivity)
                .setTitle(getString(R.string.epub_search_header, query, total[0]))
                .setItems(labels.toTypedArray()) { _, which ->
                    hitQuery = query
                    pageAdapter?.refreshOverlays()
                    jumpToPage(hits[which].chapter)
                }
                .setNegativeButton(R.string.dialog_cancel, null)
                .show()
        }
    }

    // ---------------------------------------------------------------------------------------
    // Editing toolbar (4.61): highlight / underline / strike out, black box, text, drawn on the page itself
    // ---------------------------------------------------------------------------------------

    private fun setupEditBar() {
        binding.btnToolHighlight.setOnClickListener { selectTool(ReaderEdits.Kind.HIGHLIGHT) }
        binding.btnToolUnderline.setOnClickListener { selectTool(ReaderEdits.Kind.UNDERLINE) }
        binding.btnToolStrike.setOnClickListener { selectTool(ReaderEdits.Kind.STRIKE) }
        binding.btnToolBlack.setOnClickListener { selectTool(ReaderEdits.Kind.BLACKBOX) }
        binding.btnToolText.setOnClickListener { selectTool(ReaderEdits.Kind.TEXT) }
        binding.btnToolPen.setOnClickListener { selectTool(ReaderEdits.Kind.PEN) }
        binding.btnToolMarker.setOnClickListener { selectTool(ReaderEdits.Kind.MARKER) }
        binding.btnToolEditText.setOnClickListener { selectTool(ReaderEdits.Kind.EDITTEXT) }
        binding.btnToolEraser.setOnClickListener { selectTool(ReaderEdits.Kind.ERASER) }
        updateColorDot()
        binding.btnEditColor.setOnClickListener { chooseColor() }
        // the tools are icons: press and hold shows the name (and the name of the active tool is shown above the bar, see setTool)
        for ((button, label) in toolLabels()) TooltipCompat.setTooltipText(button, getString(label))
        binding.btnEditUndo.setOnClickListener { undoEdit() }
        // Redo (4.72) has no button of its own, the bar has no room: hold Undo (a hint says so the first time), or use the "Redo" action TalkBack offers on it
        binding.btnEditUndo.setOnLongClickListener {
            redoEdit()
            true
        }
        ViewCompat.addAccessibilityAction(binding.btnEditUndo, getString(R.string.reader_redo)) { _, _ ->
            redoEdit()
            true
        }
        binding.btnEditSave.setOnClickListener { saveEdits() }
        binding.btnEditMore.setOnClickListener { openTools() }
        binding.btnEditClose.setOnClickListener { closeEditing() }
    }

    private fun toolLabels(): List<Pair<MaterialButton, Int>> = listOf(
        binding.btnToolPen to R.string.reader_tool_pen, binding.btnToolMarker to R.string.reader_tool_marker, binding.btnToolHighlight to R.string.reader_tool_highlight,
        binding.btnToolUnderline to R.string.reader_tool_underline, binding.btnToolStrike to R.string.reader_tool_strike, binding.btnToolBlack to R.string.reader_tool_blackbox,
        binding.btnToolText to R.string.reader_tool_text, binding.btnToolEditText to R.string.tool_text_edit_title, binding.btnToolEraser to R.string.reader_tool_eraser, binding.btnEditUndo to R.string.sign_pad_undo, binding.btnEditMore to R.string.reader_more_tools,
        binding.btnEditClose to R.string.reader_edit_close
    )

    /** The dot on the colour button shows the colour that the ACTIVE tool will draw in (4.69: the pen, the marker, the highlight, the underline, the strike-out and the text each keep their own). */
    private fun updateColorDot() {
        binding.btnEditColor.iconTint = ColorStateList.valueOf(currentColor)
    }

    private fun openEditing() {
        if (pageCount == 0) return
        editing = true
        binding.editBar.visibility = View.VISIBLE
        Toast.makeText(this, R.string.reader_edit_hint, Toast.LENGTH_LONG).show()
    }

    /** Closes the toolbar; marks not yet saved are only dropped after the person agrees. */
    private fun closeEditing() {
        if (edits.isEmpty()) {
            endEditing()
            return
        }
        AlertDialog.Builder(this)
            .setMessage(R.string.reader_edit_discard)
            .setPositiveButton(R.string.reader_edit_discard_yes) { _, _ -> endEditing() }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun endEditing() {
        edits.clear()
        editing = false
        binding.editBar.visibility = View.GONE
        setTool(null)
        pageAdapter?.refreshOverlays()
    }

    private fun selectTool(kind: ReaderEdits.Kind) {
        if (tool == kind) {
            setTool(null)
            return
        }
        if (kind == ReaderEdits.Kind.TEXT) {
            askStampText { text ->
                pendingText = text
                setTool(kind)
            }
            return
        }
        Feedback.tick(binding.root)
        if (kind == ReaderEdits.Kind.EDITTEXT) Toast.makeText(this, R.string.reader_edittext_hint, Toast.LENGTH_LONG).show()
        setTool(kind)
    }

    /** While a tool is active one finger draws on the page, so the list no longer pans or zooms with one finger (pinch still zooms; two fingers pan). */
    private fun setTool(kind: ReaderEdits.Kind?) {
        tool = kind
        if (kind != ReaderEdits.Kind.EDITTEXT) clearPictureSelection()
        pageAdapter?.tool = kind
        pageAdapter?.toolColor = currentColor
        pageAdapter?.toolWidth = widthFor(kind)
        updateColorDot()
        binding.rvPages.oneFingerPan = kind == null
        pageAdapter?.refreshOverlays()
        val on = ColorUtils.setAlphaComponent(ContextCompat.getColor(this, R.color.primary), 70)
        val buttons: List<Pair<MaterialButton, ReaderEdits.Kind>> = listOf(
            binding.btnToolHighlight to ReaderEdits.Kind.HIGHLIGHT, binding.btnToolUnderline to ReaderEdits.Kind.UNDERLINE,
            binding.btnToolStrike to ReaderEdits.Kind.STRIKE, binding.btnToolBlack to ReaderEdits.Kind.BLACKBOX, binding.btnToolText to ReaderEdits.Kind.TEXT,
            binding.btnToolPen to ReaderEdits.Kind.PEN, binding.btnToolMarker to ReaderEdits.Kind.MARKER, binding.btnToolEditText to ReaderEdits.Kind.EDITTEXT,
            binding.btnToolEraser to ReaderEdits.Kind.ERASER
        )
        for ((button, k) in buttons) button.setBackgroundColor(if (kind == k) on else Color.TRANSPARENT)
        val name = when (kind) {
            ReaderEdits.Kind.PEN -> R.string.reader_tool_pen
            ReaderEdits.Kind.MARKER -> R.string.reader_tool_marker
            ReaderEdits.Kind.HIGHLIGHT -> R.string.reader_tool_highlight
            ReaderEdits.Kind.UNDERLINE -> R.string.reader_tool_underline
            ReaderEdits.Kind.STRIKE -> R.string.reader_tool_strike
            ReaderEdits.Kind.BLACKBOX -> R.string.reader_tool_blackbox
            ReaderEdits.Kind.TEXT -> R.string.reader_tool_text
            ReaderEdits.Kind.EDITTEXT -> R.string.tool_text_edit_title
            ReaderEdits.Kind.ERASER -> R.string.reader_tool_eraser
            else -> 0
        }
        binding.tvEditHint.text = if (name == 0) "" else getString(name)
        binding.tvEditHint.visibility = if (name == 0) View.GONE else View.VISIBLE
    }

    /**
     * The colour button (4.69): a grid of [ReaderEdits.PALETTE] colours; the one picked is the colour of the ACTIVE tool from then on (with no tool active it is set for every
     * colour tool). Before, the button went round four colours and the highlight and the marker were always yellow whatever was picked: a green marker came out yellow.
     */
    private fun chooseColor() {
        val density = resources.displayMetrics.density
        val size = (44 * density).toInt()
        val gap = (6 * density).toInt()
        val grid = GridLayout(this)
        grid.columnCount = 4
        val pad = (16 * density).toInt()
        grid.setPadding(pad, pad / 2, pad, 0)
        var dialog: AlertDialog? = null
        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.addView(grid)
        val active = tool
        if (active != null && (active == ReaderEdits.Kind.PEN || active == ReaderEdits.Kind.MARKER)) {
            // the thickness of the pen and the marker (4.72): thin, usual, thick
            val label = TextView(this)
            label.setText(R.string.reader_width)
            label.setPadding(pad, pad / 2, pad, 0)
            content.addView(label)
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.setPadding(pad / 2, 0, pad / 2, 0)
            val widthNames = intArrayOf(R.string.reader_width_thin, R.string.reader_width_normal, R.string.reader_width_thick)
            val chosen = toolWidthIndex[active] ?: 1
            for ((i, nameRes) in widthNames.withIndex()) {
                val b = Button(this)
                b.text = (if (i == chosen) "\u2713 " else "") + getString(nameRes)
                b.isAllCaps = false
                b.layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                b.setOnClickListener {
                    toolWidthIndex[active] = i
                    pageAdapter?.toolWidth = widthFor(active)
                    dialog?.dismiss()
                }
                row.addView(b)
            }
            content.addView(row)
        }
        val names = intArrayOf(
            R.string.color_red, R.string.color_orange, R.string.color_yellow, R.string.color_green,
            R.string.color_blue, R.string.color_purple, R.string.color_pink, R.string.color_black
        )
        for ((i, colour) in ReaderEdits.PALETTE.withIndex()) {
            val swatch = View(this)
            val ring = android.graphics.drawable.GradientDrawable()
            ring.shape = android.graphics.drawable.GradientDrawable.OVAL
            ring.setColor(colour)
            val selected = colour == currentColor
            ring.setStroke(((if (selected) 4 else 1) * density).toInt(), if (selected) ContextCompat.getColor(this, R.color.primary) else Color.GRAY)
            swatch.background = ring
            swatch.contentDescription = getString(names[i])
            val lp = GridLayout.LayoutParams()
            lp.width = size
            lp.height = size
            lp.setMargins(gap, gap, gap, gap)
            lp.setGravity(Gravity.CENTER)
            swatch.layoutParams = lp
            swatch.setOnClickListener {
                applyColor(colour)
                dialog?.dismiss()
            }
            grid.addView(swatch)
        }
        dialog = AlertDialog.Builder(this)
            .setTitle(R.string.reader_edit_color)
            .setView(content)
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    /** Makes [colour] the colour of the active tool (of every tool when none is active) and shows it on the dot and on the strokes still to be drawn. */
    private fun applyColor(colour: Int) {
        val active = tool
        if (active != null) {
            toolColors[active] = colour
        } else {
            for (kind in ReaderEdits.Kind.values()) toolColors[kind] = colour
        }
        updateColorDot()
        pageAdapter?.toolColor = currentColor
        pageAdapter?.refreshOverlays()
    }

    private fun askStampText(then: (String) -> Unit) {
        val input = EditText(this)
        input.setHint(R.string.reader_edit_text_prompt)
        input.setSingleLine()
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = FrameLayout(this)
        holder.setPadding(pad, pad / 2, pad, 0)
        holder.addView(input)
        AlertDialog.Builder(this)
            .setTitle(R.string.reader_tool_text)
            .setView(holder)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) then(text)
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun undoEdit() {
        val removed = edits.undo() ?: return
        pageAdapter?.refreshOverlay(removed.page)
        if (edits.canRedo() && !redoHintShown) {
            redoHintShown = true
            Toast.makeText(this, R.string.reader_redo_hint, Toast.LENGTH_SHORT).show()
        }
    }

    /** Puts back what Undo took back (4.72). */
    private fun redoEdit() {
        val back = edits.redo() ?: return
        pageAdapter?.refreshOverlay(back.page)
    }

    /** The eraser touched page [page] at (x, y) view pixels: the latest mark there, with the rest of its group, goes (one step that Undo puts back). */
    private fun eraseAt(page: Int, x: Float, y: Float, width: Float, height: Float) {
        if (page < 0 || width <= 0f || height <= 0f) return
        val target = edits.hit(page, x / width, y / height) ?: return
        if (edits.erase(target) > 0) {
            Feedback.tick(binding.root)
            pageAdapter?.refreshOverlay(page)
        }
    }

    /** The PDF's own text layer (no OCR): exact words to snap a highlight to; empty for a scan, where the frame itself becomes the mark. */
    private suspend fun wordsFor(page: Int): List<PdfTextMarkup.WordBox> {
        wordCache[page]?.let { return it }
        val file = pdfFile ?: return emptyList()
        val layer = withContext(Dispatchers.IO) { PdfTextLayer.words(file, page) }
        val words = if (layer != null && layer.size >= 3) layer else emptyList()
        wordCache[page] = words
        return words
    }

    /** Reads the words of [page] once, in the background, then redraws its row so the drag can be previewed on them. */
    private fun requestWords(page: Int) {
        if (!wordRequests.add(page)) return
        lifecycleScope.launch {
            wordsFor(page)
            pageAdapter?.refreshOverlay(page)
        }
    }

    /** The black box: the dragged rectangle itself (a box hides whatever is under it, text or not). */
    private fun onFrame(page: Int, box: FloatArray) {
        val active = tool ?: return
        if (active != ReaderEdits.Kind.BLACKBOX) return
        edits.add(ReaderEdits.Item(active, page, box))
        pageAdapter?.refreshOverlay(page)
    }

    /**
     * Highlight, underline, strike-out (4.67): a drag from one point to another marks the words between them in reading order, like selecting text (one band per line; all of them are
     * one step of Undo), and a tap marks the word under the finger. Where the drag does not start on text (a scan, a picture, a margin) the dragged rectangle itself becomes the mark.
     */
    private fun onTextDrag(page: Int, ax: Float, ay: Float, bx: Float, by: Float) {
        val active = tool ?: return
        if (!ReaderEdits.isTextMark(active)) return
        lifecycleScope.launch {
            val boxes = PdfTextMarkup.selectionBoxes(wordsFor(page), ax, ay, bx, by)
            val color = colorFor(active)
            if (boxes != null) {
                val group = edits.newGroup()
                for (b in boxes) edits.add(ReaderEdits.Item(active, page, b, color = color, group = group))
            } else {
                val box = ReaderEdits.frame(ax, ay, bx, by, 1f, 1f) ?: return@launch
                edits.add(ReaderEdits.Item(active, page, box, color = color))
            }
            pageAdapter?.refreshOverlay(page)
        }
    }

    /** The pieces of existing text of [page] with their boxes (4.69), read once from the file in the background; empty for a scan (no text objects) or a page that cannot be read. */
    private suspend fun chunksFor(page: Int): List<PdfTextEditor.PlacedChunk> {
        chunkCache[page]?.let { return it }
        val file = pdfFile ?: return emptyList()
        val placed = withContext(Dispatchers.IO) { PdfTextEditor.placedChunks(file, page + 1) }
        chunkCache[page] = placed
        return placed
    }

    /** The form fields whose widget is on [page], with their boxes (4.71); empty for a page without a form or a file that cannot be read. */
    private suspend fun fieldsFor(page: Int): List<PdfFormFiller.PlacedField> {
        fieldCache[page]?.let { return it }
        val file = pdfFile ?: return emptyList()
        val placed = withContext(Dispatchers.IO) { PdfFormFiller.placedFields(file, page + 1) }
        fieldCache[page] = placed
        return placed
    }

    private suspend fun blocksFor(page: Int): List<PdfParagraphEditor.Block> {
        blockCache[page]?.let { return it }
        val file = pdfFile ?: return emptyList()
        val found = withContext(Dispatchers.IO) { PdfParagraphEditor.blocks(file, page + 1) }
        blockCache[page] = found
        return found
    }

    /** The pictures already in [page] with their boxes (4.88), read once from the file in the background; empty for a page without pictures or a file that cannot be read. */
    private suspend fun picturesFor(page: Int): List<PdfImageEditor.Picture> {
        pictureCache[page]?.let { return it }
        val file = pdfFile ?: return emptyList()
        val found = withContext(Dispatchers.IO) { PdfImageEditor.pictures(file, page + 1) }
        pictureCache[page] = found
        return found
    }

    /** Reads the text pieces and the form fields of [page] once, in the background, then redraws its row so they are outlined while the edit-text tool is active. */
    private fun requestChunks(page: Int) {
        if (!chunkRequests.add(page)) return
        lifecycleScope.launch {
            chunksFor(page)
            fieldsFor(page)
            picturesFor(page)
            pageAdapter?.refreshOverlay(page)
        }
    }

    /** The edit-text tool was tapped at (x, y), fractions of the page: the piece of text under the finger opens in a box to be retyped; nothing under the finger does nothing. */
    private fun editTextAt(page: Int, x: Float, y: Float) {
        lifecycleScope.launch {
            val placed = chunksFor(page)
            val fields = fieldsFor(page)
            val pictures = picturesFor(page)
            if (placed.isEmpty() && fields.isEmpty() && pictures.isEmpty()) {
                Toast.makeText(this@PdfReaderActivity, R.string.text_edit_empty_page, Toast.LENGTH_SHORT).show()
                return@launch
            }
            // a form field under the finger wins over the text printed under it
            val field = PdfFormFiller.pickField(fields, x, y)
            if (field != null) {
                clearPictureSelection()
                fillField(page, field)
                return@launch
            }
            val hit = PdfTextEditor.pick(placed, x, y)
            if (hit != null) {
                clearPictureSelection()
                askNewWording(page, hit, PdfParagraphEditor.pick(blocksFor(page), x, y))
                return@launch
            }
            // no text and no field under the finger: a picture of the page (4.88); it is selected with handles to drag (4.91), a tap on it then opens the other actions
            val picture = PdfImageEditor.pick(pictures, x, y)
            if (picture == null) { clearPictureSelection(); return@launch }
            selectPicture(page, picture)
        }
    }

    private fun clearPictureSelection() {
        val old = selectedPage
        selectedPage = -1
        selectedPicture = null
        selectedBox = null
        if (old >= 0) pageAdapter?.refreshOverlay(old)
    }

    private fun selectPicture(page: Int, picture: PdfImageEditor.Picture) {
        val box = picture.placed ?: return
        val old = selectedPage
        selectedPage = page
        selectedPicture = picture
        selectedBox = box.copyOf()
        if (old >= 0 && old != page) pageAdapter?.refreshOverlay(old)
        pageAdapter?.refreshOverlay(page)
    }

    /** The selected picture was dragged (move) or a corner was dragged (scale about the centre): staged like every other edit, shown as the new frame (4.91). */
    private fun onPictureGesture(page: Int, dx: Float, dy: Float, scale: Float) {
        val picture = selectedPicture ?: return
        val box = selectedBox ?: return
        if (page != selectedPage) return
        val moved = PdfImageEditor.gestureBox(box, dx, dy, scale) ?: return
        edits.add(ReaderEdits.Item(ReaderEdits.Kind.PICTURE, page, moved, ReaderEdits.PICTURE_GESTURE, points = floatArrayOf(dx, dy, scale), chunk = picture.index))
        selectedBox = moved
        pageAdapter?.refreshOverlay(page)
    }

    private fun addPictureEdit(page: Int, picture: PdfImageEditor.Picture, action: String, file: String? = null) {
        val box = picture.placed ?: return
        edits.add(ReaderEdits.Item(ReaderEdits.Kind.PICTURE, page, box, action, chunk = picture.index, name = file))
        Toast.makeText(this, R.string.pic_added, Toast.LENGTH_SHORT).show()
        pageAdapter?.refreshOverlay(page)
    }

    /** A picture was tapped (4.88): what to do with it. Nothing is written until the copy is saved, like every other edit of the reader. */
    private fun askPictureAction(page: Int, picture: PdfImageEditor.Picture) {
        val actions = listOf(
            ReaderEdits.PICTURE_DELETE to R.string.pic_delete, ReaderEdits.PICTURE_BIGGER to R.string.pic_bigger, ReaderEdits.PICTURE_SMALLER to R.string.pic_smaller,
            ReaderEdits.PICTURE_LEFT to R.string.pic_move_left, ReaderEdits.PICTURE_RIGHT to R.string.pic_move_right, ReaderEdits.PICTURE_UP to R.string.pic_move_up,
            ReaderEdits.PICTURE_DOWN to R.string.pic_move_down, ReaderEdits.PICTURE_TURN to R.string.pic_turn,
            ReaderEdits.PICTURE_FLIP_H to R.string.pic_flip_h, ReaderEdits.PICTURE_FLIP_V to R.string.pic_flip_v, ReaderEdits.PICTURE_CROP to R.string.pic_crop,
            ReaderEdits.PICTURE_OPACITY_50 to R.string.pic_opacity_50, ReaderEdits.PICTURE_OPACITY_25 to R.string.pic_opacity_25, ReaderEdits.PICTURE_OPACITY_100 to R.string.pic_opacity_100,
            ReaderEdits.PICTURE_REPLACE to R.string.pic_replace
        )
        AlertDialog.Builder(this)
            .setTitle(R.string.pic_dialog_title)
            .setItems(actions.map { getString(it.second) }.toTypedArray()) { _, which ->
                val action = actions[which].first
                if (action == ReaderEdits.PICTURE_REPLACE) {
                    pendingReplace = Pair(page, picture)
                    replacePicturePicker.launch("image/*")
                } else {
                    addPictureEdit(page, picture, action)
                }
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    /** The person chose the new picture: it is read, shrunk to a size a page can use, and kept in a cache file until the copy is saved. */
    private fun onReplacementChosen(uri: Uri?) {
        val target = pendingReplace
        pendingReplace = null
        if (uri == null || target == null) return
        lifecycleScope.launch {
            val saved = withContext(Dispatchers.IO) {
                runCatching {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                    var sample = 1
                    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 1800) sample *= 2
                    val bitmap = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
                        ?: return@runCatching null
                    val dir = File(cacheDir, "pdf_reader")
                    dir.mkdirs()
                    val file = File(dir, "pic_" + System.nanoTime() + ".png")
                    file.outputStream().use { bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                    bitmap.recycle()
                    file
                }.getOrNull()
            }
            if (saved == null) {
                Feedback.error(binding.root)
                Toast.makeText(this@PdfReaderActivity, R.string.pic_unreadable, Toast.LENGTH_LONG).show()
                return@launch
            }
            addPictureEdit(target.first, target.second, ReaderEdits.PICTURE_REPLACE, saved.absolutePath)
        }
    }

    /** The picture edits of [items] as [PdfImageEditor.Op]s: a step of 3 % of the page, 25 % bigger / 20 % smaller (the inverse of bigger), a quarter turn. */
    private fun pictureOps(items: List<ReaderEdits.Item>): List<PdfImageEditor.Op> = items.filter { it.kind == ReaderEdits.Kind.PICTURE }.mapNotNull { item ->
        val page = item.page + 1
        val index = item.chunk
        when (item.text) {
            ReaderEdits.PICTURE_DELETE -> PdfImageEditor.Op.Delete(page, index)
            ReaderEdits.PICTURE_GESTURE -> item.points?.let { p -> if (p.size >= 3) PdfImageEditor.Op.Transform(page, index, dx = p[0], dy = p[1], scale = p[2]) else null }
            ReaderEdits.PICTURE_BIGGER -> PdfImageEditor.Op.Transform(page, index, scale = 1.25f)
            ReaderEdits.PICTURE_SMALLER -> PdfImageEditor.Op.Transform(page, index, scale = 0.8f)
            ReaderEdits.PICTURE_LEFT -> PdfImageEditor.Op.Transform(page, index, dx = -0.03f)
            ReaderEdits.PICTURE_RIGHT -> PdfImageEditor.Op.Transform(page, index, dx = 0.03f)
            ReaderEdits.PICTURE_UP -> PdfImageEditor.Op.Transform(page, index, dy = -0.03f)
            ReaderEdits.PICTURE_DOWN -> PdfImageEditor.Op.Transform(page, index, dy = 0.03f)
            ReaderEdits.PICTURE_TURN -> PdfImageEditor.Op.Transform(page, index, turnDegrees = 90f)
            ReaderEdits.PICTURE_FLIP_H -> PdfImageEditor.Op.Transform(page, index, flipH = true)
            ReaderEdits.PICTURE_FLIP_V -> PdfImageEditor.Op.Transform(page, index, flipV = true)
            ReaderEdits.PICTURE_CROP -> PdfImageEditor.Op.Crop(page, index, 0.1f, 0.1f, 0.1f, 0.1f)
            ReaderEdits.PICTURE_OPACITY_50 -> PdfImageEditor.Op.Transform(page, index, opacity = 0.5f)
            ReaderEdits.PICTURE_OPACITY_25 -> PdfImageEditor.Op.Transform(page, index, opacity = 0.25f)
            ReaderEdits.PICTURE_OPACITY_100 -> PdfImageEditor.Op.Transform(page, index, opacity = 1f)
            ReaderEdits.PICTURE_REPLACE -> {
                val path = item.name ?: return@mapNotNull null
                PdfImageEditor.Op.Replace(page, index) { doc ->
                    val bitmap = BitmapFactory.decodeFile(path) ?: throw IllegalStateException("picture file unreadable")
                    try { LosslessFactory.createFromImage(doc, bitmap) } finally { bitmap.recycle() }
                }
            }
            else -> null
        }
    }

    /** What the person has typed for [field] in this reading, else the value the file has. */
    private fun valueOf(page: Int, field: PdfFormFiller.PlacedField): String =
        edits.items.firstOrNull { it.kind == ReaderEdits.Kind.FORM && it.page == page && it.name == field.field.name }?.text ?: field.field.value

    private fun setFieldValue(page: Int, field: PdfFormFiller.PlacedField, value: String) {
        edits.add(ReaderEdits.Item(ReaderEdits.Kind.FORM, page, field.box, value, name = field.field.name))
        pageAdapter?.refreshOverlay(page)
    }

    /** Fills a form field where it is (4.71): a check box flips, a choice field offers its options, a text field opens a box; the value is written into the copy when it is saved. */
    private fun fillField(page: Int, field: PdfFormFiller.PlacedField) {
        val current = valueOf(page, field)
        when (field.field.kind) {
            PdfFormFiller.Kind.CHECKBOX -> setFieldValue(page, field, (current != "true").toString())
            PdfFormFiller.Kind.CHOICE -> {
                val options = field.field.options
                if (options.isEmpty()) return
                AlertDialog.Builder(this)
                    .setTitle(field.field.name)
                    .setItems(options.toTypedArray()) { _, which -> setFieldValue(page, field, options[which]) }
                    .setNegativeButton(R.string.dialog_cancel, null)
                    .show()
            }
            PdfFormFiller.Kind.TEXT -> {
                val input = EditText(this)
                input.setText(current)
                input.setSelection(input.text.length)
                val pad = (20 * resources.displayMetrics.density).toInt()
                val holder = FrameLayout(this)
                holder.setPadding(pad, pad / 2, pad, 0)
                holder.addView(input)
                AlertDialog.Builder(this)
                    .setTitle(field.field.name)
                    .setView(holder)
                    .setPositiveButton(android.R.string.ok) { _, _ -> setFieldValue(page, field, input.text.toString()) }
                    .setNegativeButton(R.string.dialog_cancel, null)
                    .show()
            }
        }
    }

    private fun askNewWording(page: Int, hit: PdfTextEditor.PlacedChunk, block: PdfParagraphEditor.Block?) {
        val earlier = edits.items.firstOrNull { it.kind == ReaderEdits.Kind.EDITTEXT && it.page == page && it.chunk == hit.chunk.index }
        val input = EditText(this)
        input.setText(earlier?.text ?: hit.chunk.text)
        input.setSelection(input.text.length)
        input.setSingleLine()
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = FrameLayout(this)
        holder.setPadding(pad, pad / 2, pad, 0)
        holder.addView(input)
        val builder = AlertDialog.Builder(this)
            .setTitle(R.string.text_edit_dialog_title)
            .setView(holder)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val wording = input.text.toString()
                if (wording.isNotBlank() && wording != hit.chunk.text) tryNewWording(page, hit, wording)
            }
            .setNegativeButton(R.string.dialog_cancel, null)
        if (block != null) builder.setNeutralButton(R.string.para_edit_button) { _, _ -> askParagraph(page, block) }
        builder.show()
    }

    /** The whole paragraph the tapped line belongs to, in one box (4.89): the text wraps inside the paragraph's own width, like in a text box of WPS / Acrobat. */
    private fun askParagraph(page: Int, block: PdfParagraphEditor.Block) {
        val earlier = edits.items.firstOrNull { it.kind == ReaderEdits.Kind.PARAGRAPH && it.page == page && it.chunk == block.firstIndex }
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        input.minLines = 4
        input.gravity = Gravity.TOP or Gravity.START
        input.setText(earlier?.text ?: block.text)
        input.setSelection(input.text.length)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = FrameLayout(this)
        holder.setPadding(pad, pad / 2, pad, 0)
        holder.addView(input)
        AlertDialog.Builder(this)
            .setTitle(R.string.para_edit_title)
            .setView(holder)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val wording = input.text.toString()
                if (wording.isNotBlank() && wording != block.text) tryParagraph(page, block, wording)
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    /** The fallback fonts for letters the PDF's own font lacks (4.90): DejaVu Sans from the app's assets, opened only when a letter needs it. */
    private fun fallbackFonts(): List<ParagraphFontSource> =
        listOf<ParagraphFontSource>({ try { assets.open("fonts/DejaVuSans.ttf") } catch (e: java.io.IOException) { null } })

    /** The longer text would run over other text: WPS lets that happen, so the person is asked (4.90). */
    private fun askKeepOverlap(page: Int, block: PdfParagraphEditor.Block, wording: String) {
        AlertDialog.Builder(this)
            .setMessage(R.string.para_overlaps)
            .setPositiveButton(R.string.para_keep_anyway) { _, _ -> tryParagraph(page, block, wording, true) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    /** Tries the new paragraph on a throw-away copy first, so a letter the font lacks or a text that would run into other text is reported now and not at "Save a copy". */
    private fun tryParagraph(page: Int, block: PdfParagraphEditor.Block, wording: String, allowOverlap: Boolean = false) {
        val file = pdfFile ?: return
        binding.progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { PdfParagraphEditor.trial(file, page + 1, block.firstIndex, wording, fallbackFonts(), allowOverlap) }
            binding.progress.visibility = View.GONE
            if (result is PdfParagraphEditor.Result.Overlaps) {
                askKeepOverlap(page, block, wording)
                return@launch
            }
            val message: String? = when (result) {
                is PdfParagraphEditor.Result.Success, is PdfParagraphEditor.Result.Substituted -> null
                is PdfParagraphEditor.Result.MissingGlyphs ->
                    getString(R.string.text_edit_missing_glyphs, result.chars.replace(" ", getString(R.string.text_edit_space_label)))
                is PdfParagraphEditor.Result.UnsupportedFont -> getString(R.string.text_edit_unsupported_font)
                is PdfParagraphEditor.Result.NotFound -> getString(R.string.text_edit_chunk_not_found)
                is PdfParagraphEditor.Result.Overlaps -> getString(R.string.para_overlaps)
                is PdfParagraphEditor.Result.OffPage -> getString(R.string.para_off_page)
                is PdfParagraphEditor.Result.TooManyLines -> getString(R.string.para_too_many)
            }
            if (message != null) {
                Feedback.error(binding.root)
                Toast.makeText(this@PdfReaderActivity, message, Toast.LENGTH_LONG).show()
                return@launch
            }
            val box = block.placed ?: return@launch
            edits.add(ReaderEdits.Item(ReaderEdits.Kind.PARAGRAPH, page, box, wording, chunk = block.firstIndex, name = if (allowOverlap) ReaderEdits.PARAGRAPH_OVERLAP else null))
            val note = if (result is PdfParagraphEditor.Result.Substituted) R.string.para_substituted else R.string.text_edit_applied
            Toast.makeText(this@PdfReaderActivity, note, Toast.LENGTH_LONG).show()
            pageAdapter?.refreshOverlay(page)
        }
    }

    /** Tries the new wording on a throw-away copy first (the same check the copy will pass), so a letter the font lacks is reported now and not at "Save a copy". */
    private fun tryNewWording(page: Int, hit: PdfTextEditor.PlacedChunk, wording: String) {
        val file = pdfFile ?: return
        binding.progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { PdfTextEditor.trial(file, page + 1, hit.chunk.index, wording) }
            binding.progress.visibility = View.GONE
            val message: String? = when (result) {
                is PdfTextEditor.EditResult.Success -> null
                is PdfTextEditor.EditResult.MissingGlyphs ->
                    getString(R.string.text_edit_missing_glyphs, result.chars.replace(" ", getString(R.string.text_edit_space_label)))
                is PdfTextEditor.EditResult.ScaleOutOfRange -> getString(R.string.text_edit_scale_out_of_range)
                is PdfTextEditor.EditResult.UnsupportedFont -> getString(R.string.text_edit_unsupported_font)
                is PdfTextEditor.EditResult.ChunkNotFound -> getString(R.string.text_edit_chunk_not_found)
            }
            if (message != null) {
                Feedback.error(binding.root)
                Toast.makeText(this@PdfReaderActivity, message, Toast.LENGTH_LONG).show()
                return@launch
            }
            edits.add(ReaderEdits.Item(ReaderEdits.Kind.EDITTEXT, page, hit.box, wording, chunk = hit.chunk.index))
            Toast.makeText(this@PdfReaderActivity, R.string.text_edit_applied, Toast.LENGTH_SHORT).show()
            pageAdapter?.refreshOverlay(page)
        }
    }

    private fun onTextTap(page: Int, x: Float, y: Float, width: Float, height: Float) {
        if (tool == ReaderEdits.Kind.EDITTEXT) {
            if (width > 0f && height > 0f) editTextAt(page, x / width, y / height)
            return
        }
        val text = pendingText ?: return
        val picture = StampRenderer.plainText(text, currentColor)
        val aspect = picture.width.toFloat() / picture.height.toFloat()
        picture.recycle()
        val box = ReaderEdits.stampBox(x, y, width, height, STAMP_WIDTH_FRACTION, aspect) ?: return
        edits.add(ReaderEdits.Item(ReaderEdits.Kind.TEXT, page, box, text, color = currentColor))
        pageAdapter?.refreshOverlay(page)
    }

    /** A pen or marker stroke: thinned, then kept as an item; it becomes a real ink annotation when the copy is saved. */
    private fun onStroke(page: Int, points: FloatArray) {
        val kind = tool ?: return
        if (kind != ReaderEdits.Kind.PEN && kind != ReaderEdits.Kind.MARKER) return
        val thinned = PdfInk.simplifyCapped(points)
        if (thinned.isEmpty()) return
        edits.add(ReaderEdits.Item(kind, page, ReaderEdits.boundsOf(thinned), points = thinned, color = colorFor(kind), width = widthFor(kind)))
        pageAdapter?.refreshOverlay(page)
    }

    /**
     * Writes the marks into a NEW PDF (the original is not changed): black boxes first (they turn their pages into pictures, so nothing under them survives), then text
     * stamps, then the highlight / underline / strike-out marks as real PDF annotations on top (the text stays selectable). A signed PDF asks first, because the copy cannot
     * keep the signature valid. Afterwards the reader shows the copy, on the same page.
     */
    /** The open file when it is a file of the library (not a copy opened from elsewhere): the only kind that can be saved INTO and has a version history (4.78). */
    private fun libraryFile(): File? {
        val f = pdfFile ?: return null
        if (isTemp) return null
        val dir = PdfExporter.exportDir(this)
        return if (f.parentFile?.canonicalPath == dir.canonicalPath) f else null
    }

    private fun versionLimit(): Int =
        FileVersions.clampLimit(getSharedPreferences("file_versions", MODE_PRIVATE).getInt("limit", FileVersions.DEFAULT_LIMIT))

    /** Save: a file of the library can be saved as a new file (as before) or INTO itself, keeping the old content as a version; anything else is saved as a new file. */
    private fun saveEdits() {
        if (edits.isEmpty()) {
            Toast.makeText(this, R.string.reader_edit_nothing, Toast.LENGTH_SHORT).show()
            return
        }
        if (libraryFile() == null) {
            doSaveEdits(false)
            return
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.save_choice_title)
            .setItems(arrayOf(getString(R.string.save_choice_copy), getString(R.string.save_choice_overwrite, versionLimit()))) { _, which -> doSaveEdits(which == 1) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    /**
     * Writes the edits. [overwrite] false: into a new file next to the others, as always. True (4.78): the result is made in a temporary file first, then [FileVersions.commit] keeps the
     * CURRENT content of the library file as a version and only then replaces the file with the result; if the old content cannot be kept, the file is not touched.
     */
    private fun doSaveEdits(overwrite: Boolean) {
        val src = pdfFile ?: return
        val target = if (overwrite) libraryFile() else null
        if (overwrite && target == null) return
        val snapshot = ArrayList(edits.items)
        binding.progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            if (!SignedPdfGuard.confirm(this@PdfReaderActivity, src)) {
                binding.progress.visibility = View.GONE
                return@launch
            }
            val out = if (target != null) {
                File(cacheDir, "saving_" + System.nanoTime() + ".pdf")
            } else {
                File(PdfExporter.exportDir(this@PdfReaderActivity), FileUtils.defaultSecurityName("edited") + ".pdf")
            }
            val result = runCatching { withContext(Dispatchers.Default) { applyEdits(src, snapshot, out) } }
            if (result.isFailure) {
                binding.progress.visibility = View.GONE
                runCatching { out.delete() }
                Toast.makeText(this@PdfReaderActivity, R.string.reader_edit_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            if (target != null) {
                val kept = withContext(Dispatchers.IO) { FileVersions.commit(filesDir, target.name, out, target, System.currentTimeMillis(), versionLimit()) }
                binding.progress.visibility = View.GONE
                if (!kept) {
                    runCatching { out.delete() }
                    Toast.makeText(this@PdfReaderActivity, R.string.versions_failed, Toast.LENGTH_LONG).show()
                    return@launch
                }
                Toast.makeText(this@PdfReaderActivity, getString(R.string.versions_saved, FileVersions.count(filesDir, target.name)), Toast.LENGTH_LONG).show()
                switchTo(target)
                return@launch
            }
            binding.progress.visibility = View.GONE
            Toast.makeText(this@PdfReaderActivity, getString(R.string.reader_edit_saved, out.name), Toast.LENGTH_LONG).show()
            switchTo(out)
        }
    }

    /** The versions kept of the open library file (4.78); putting one back reloads the file here. */
    private fun showVersions() {
        val target = libraryFile() ?: return
        VersionUi.show(this, target, versionLimit()) { switchTo(target) }
    }

    private fun applyEdits(src: File, items: List<ReaderEdits.Item>, out: File) {
        val temps = ArrayList<File>()
        val dir = File(cacheDir, "pdf_reader")
        dir.mkdirs()
        var current = src
        try {
            // form fields first: filling a field changes the field and its widget, never the page's own content, so the text pieces below keep their numbers
            val filled = items.filter { it.kind == ReaderEdits.Kind.FORM && it.name != null }
            if (filled.isNotEmpty()) {
                val next = File(dir, "form_" + System.nanoTime() + ".pdf")
                temps.add(next)
                PdfFormFiller.fill(current, next, filled.associate { (it.name ?: "") to (it.text ?: "") })
                current = next
            }
            // pictures of the page (4.88): changing or deleting one rewrites only the page's drawing instructions, never the text pieces, so their numbers stay valid
            val pictureOps = pictureOps(items)
            if (pictureOps.isNotEmpty()) {
                val next = File(dir, "edit_" + System.nanoTime() + ".pdf")
                temps.add(next)
                PdfImageEditor.applyAll(current, next, pictureOps)
                current = next
            }
            // the retyped text goes in FIRST: the pieces are numbered in the page's own content, which the black boxes (pictures) and the stamps below would change
            // a paragraph written again wins over single-line retypes inside it (4.89): its lines are all rewritten anyway
            val paragraphs = items.filter { it.kind == ReaderEdits.Kind.PARAGRAPH }
            val retyped = items.filter { line ->
                line.kind == ReaderEdits.Kind.EDITTEXT && paragraphs.none { p ->
                    p.page == line.page && line.box[0] < p.box[2] && line.box[2] > p.box[0] && line.box[1] < p.box[3] && line.box[3] > p.box[1]
                }
            }
            if (retyped.isNotEmpty()) {
                val next = File(dir, "edit_" + System.nanoTime() + ".pdf")
                temps.add(next)
                PdfTextEditor.applyAll(current, next, retyped.map { PdfTextEditor.Replacement(it.page + 1, it.chunk, it.text ?: "") })
                current = next
            }
            if (paragraphs.isNotEmpty()) {
                val next = File(dir, "edit_" + System.nanoTime() + ".pdf")
                temps.add(next)
                PdfParagraphEditor.applyAll(current, next, paragraphs.map { PdfParagraphEditor.Edit(it.page + 1, it.chunk, it.text ?: "", it.name == ReaderEdits.PARAGRAPH_OVERLAP) }, fallbackFonts())
                current = next
            }
            val boxes = items.filter { it.kind == ReaderEdits.Kind.BLACKBOX }.groupBy({ it.page }, { it.box })
            if (boxes.isNotEmpty()) {
                val next = File(dir, "edit_" + System.nanoTime() + ".pdf")
                temps.add(next)
                PdfRedactor.redact(current, next, boxes)
                current = next
            }
            for (item in items.filter { it.kind == ReaderEdits.Kind.TEXT }) {
                val next = File(dir, "edit_" + System.nanoTime() + ".pdf")
                temps.add(next)
                val picture = StampRenderer.plainText(item.text ?: "", item.color)
                try {
                    val b = item.box
                    PdfStamper.stamp(current, next, picture, PdfStamper.Placement((b[0] + b[2]) / 2f, (b[1] + b[3]) / 2f, b[2] - b[0]), setOf(item.page))
                } finally {
                    picture.recycle()
                }
                current = next
            }
            val strokes = items.filter { it.kind == ReaderEdits.Kind.PEN || it.kind == ReaderEdits.Kind.MARKER }
                .groupBy({ it.page }, { PdfInk.Stroke(it.points ?: FloatArray(0), it.color, if (it.width > 0f) it.width else if (it.kind == ReaderEdits.Kind.MARKER) PdfInk.MARKER_WIDTH else PdfInk.PEN_WIDTH, it.kind == ReaderEdits.Kind.MARKER) })
            if (strokes.isNotEmpty()) {
                val next = File(dir, "edit_" + System.nanoTime() + ".pdf")
                temps.add(next)
                PdfInk.annotate(current, next, strokes)
                current = next
            }
            val marks = items.filter { it.kind == ReaderEdits.Kind.HIGHLIGHT || it.kind == ReaderEdits.Kind.UNDERLINE || it.kind == ReaderEdits.Kind.STRIKE }
                .groupBy({ it.page }, { PdfTextMarkup.Mark(it.box, styleOf(it.kind), rgbOf(it.color)) })
            if (marks.isNotEmpty()) PdfTextMarkup.annotate(current, out, marks) else current.copyTo(out, overwrite = true)
        } finally {
            for (t in temps) runCatching { t.delete() }
            for (done in items) { val cached = done.name; if (done.kind == ReaderEdits.Kind.PICTURE && cached != null) runCatching { File(cached).delete() } }
        }
    }

    private fun styleOf(kind: ReaderEdits.Kind): PdfTextMarkup.Style = when (kind) {
        ReaderEdits.Kind.UNDERLINE -> PdfTextMarkup.Style.UNDERLINE
        ReaderEdits.Kind.STRIKE -> PdfTextMarkup.Style.STRIKEOUT
        else -> PdfTextMarkup.Style.HIGHLIGHT
    }

    private fun rgbOf(color: Int): FloatArray =
        floatArrayOf(((color shr 16) and 0xFF) / 255f, ((color shr 8) and 0xFF) / 255f, (color and 0xFF) / 255f)

    /** Shows the saved copy in place of the PDF just read, on the same page. */
    private fun switchTo(out: File) {
        val page = layoutManager.findFirstVisibleItemPosition().coerceAtLeast(0)
        synchronized(lock) {
            session?.close()
            session = null
        }
        if (isTemp) pdfFile?.let { runCatching { it.delete() } }
        isTemp = false
        resumePage = page
        resumeZoom = binding.rvPages.zoom
        title = out.name
        positionKey = PdfReadingPositions.key(out.name, out.length())
        invalidateOptionsMenu()
        pageAdapter = null
        pageCount = 0
        binding.rvPages.adapter = null
        useFile(out)
        endEditing()
        startOpening()
    }

    // ---------------------------------------------------------------------------------------
    // Editing tools
    // ---------------------------------------------------------------------------------------

    /**
     * The Edit button: every tool that works on this PDF (about 30: edit & annotate, sign & protect, pages & structure, convert & export, read, extract), grouped. The
     * tools live in the main screen, which is brought IN FRONT of this reader (REORDER_TO_FRONT, so the reader stays underneath and Back returns to it) and shows
     * their menu for this file. A tool that makes a new file leaves it in the history; this reader remembers the page, so opening it again continues there.
     */
    private fun openTools() {
        val file = pdfFile ?: return
        val name = title.toString()
        startActivity(Intent(this, MainActivity::class.java).apply {
            action = ACTION_PDF_TOOLS
            putExtra(EXTRA_PDF_PATH, file.absolutePath)
            putExtra(EXTRA_TITLE, name)
            addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        synchronized(lock) {
            closed = true
            session?.close()
            session = null
        }
        if (isTemp && isFinishing) pdfFile?.let { runCatching { it.delete() } }
    }

    companion object {
        const val EXTRA_PDF_PATH = "extra_pdf_path"
        /** The file is our own copy: delete it when the screen finishes. */
        const val EXTRA_TEMP = "extra_temp"
        const val EXTRA_TITLE = "extra_title"

        /** Sent to the main screen by the Edit button: show the tools for the PDF in [EXTRA_PDF_PATH]. */
        const val ACTION_PDF_TOOLS = "com.example.docscanner.action.PDF_TOOLS"

        private const val PREFS = "pdf_reader"
        private const val KEY_POSITIONS = "positions"

        /** Pages are drawn at most this wide (pixels) so a tablet does not hold huge bitmaps; while zoomed in, [HIGH_PAGE_WIDTH] (about 18 MB per page). */
        private const val MAX_PAGE_WIDTH = 1500
        private const val HIGH_PAGE_WIDTH = 1800
        private const val MAX_SHOWN_HITS = 100

        /** Text placed with the editing toolbar is this fraction of the page wide. */
        private const val STAMP_WIDTH_FRACTION = 0.35f

        /**
         * Copies the content behind [uri] into the reader's cache folder (served by FileProvider, see file_paths.xml) and returns the copy, or null when it cannot be read.
         * Copies older than a day (left by a process that was killed) are removed first. Call it off the main thread, while the access to [uri] is still valid.
         */
        fun copyToCache(context: Context, uri: Uri): File? {
            val dir = File(context.cacheDir, "pdf_reader")
            dir.mkdirs()
            val cutoff = System.currentTimeMillis() - 24L * 60 * 60 * 1000
            dir.listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
            val copy = File(dir, "pdf_" + System.currentTimeMillis() + ".pdf")
            return try {
                val input = context.contentResolver.openInputStream(uri) ?: return null
                input.use { source -> copy.outputStream().use { sink -> source.copyTo(sink) } }
                copy
            } catch (e: Exception) {
                copy.delete()
                null
            }
        }
    }
}
