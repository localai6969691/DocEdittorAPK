package com.example.docscanner

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import com.google.android.material.button.MaterialButton
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.adapter.PdfReaderPageAdapter
import com.example.docscanner.databinding.ActivityPdfReaderBinding
import com.example.docscanner.util.EbookBuilder
import com.example.docscanner.util.EpubSearch
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PdfBookmarks
import com.example.docscanner.util.PdfInk
import com.example.docscanner.util.PdfRedactor
import com.example.docscanner.util.PdfStamper
import com.example.docscanner.util.PdfTextLayer
import com.example.docscanner.util.PdfTextMarkup
import com.example.docscanner.util.ReaderEdits
import com.example.docscanner.util.SignedPdfGuard
import com.example.docscanner.util.StampRenderer
import com.example.docscanner.util.PdfPageBitmap
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfPrintAdapter
import com.example.docscanner.util.PdfReadingPositions
import com.example.docscanner.util.PdfSecurityTools
import com.example.docscanner.util.PdfTextExtractor
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Reads a PDF inside the app (session 23, 4.58 and 4.59). Opened by tapping a PDF in the history, by "Open with" from a file manager and by dropping a PDF on the main
 * screen. The toolbar offers only Edit; Share, Print, Go to page, Contents and Search sit in the overflow menu. The editing tools appear when the person taps Edit, instead
 * of a wall of functions the moment a PDF is opened.
 *
 * What the reader does: pinch to zoom, drag sideways and double-tap ([com.example.docscanner.view.ZoomRecyclerView]); remembers the page where the person stopped
 * ([PdfReadingPositions]); jumps to a page, to a bookmark of the PDF ([PdfBookmarks]) or to a search hit ([EpubSearch] over the text layer, so a scan without a text layer
 * says so); asks for the password of a protected PDF and works on an unlocked copy.
 *
 * The reader always works from a LOCAL FILE: a history file as it is, anything else as a copy made by [copyToCache] before this screen starts. That way the access a file
 * manager grants for a moment is not needed afterwards, and the editing tools receive an address of our own. Copies (and the unlocked copy of a protected
 * PDF) are deleted when the screen finishes. Pages are drawn by [PdfPageBitmap] (the platform renderer).
 */
class PdfReaderActivity : BaseActivity() {

    private lateinit var binding: ActivityPdfReaderBinding
    private lateinit var layoutManager: LinearLayoutManager
    private var pageAdapter: PdfReaderPageAdapter? = null

    private val lock = Any()
    private var closed = false
    private var session: PdfPageBitmap.Session? = null
    private var pdfFile: File? = null
    private var isTemp = false
    private var pageCount = 0
    private var baseWidthPx = 0
    private var positionKey = ""
    private var pageTexts: List<String>? = null

    // editing toolbar (4.61)
    private val edits = ReaderEdits()
    private var tool: ReaderEdits.Kind? = null
    private var editing = false
    private var pendingText: String? = null
    private val wordCache = HashMap<Int, List<PdfTextMarkup.WordBox>>()
    private var resumePage: Int? = null
    private var colorIndex = 0
    private val currentColor: Int get() = PALETTE[colorIndex]

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfReaderBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val path = intent.getStringExtra(EXTRA_PDF_PATH)
        val file = if (path != null) File(path) else null
        if (file == null || !file.isFile) {
            finish()
            return
        }
        val name = intent.getStringExtra(EXTRA_TITLE) ?: file.name
        title = name
        isTemp = intent.getBooleanExtra(EXTRA_TEMP, false)
        positionKey = PdfReadingPositions.key(name, file.length())
        useFile(file)
        setupEditBar()
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (editing) closeEditing() else finish()
            }
        })
        startOpening()
    }

    /** Makes [file] the PDF being read (the original, or the unlocked copy of a protected one). */
    private fun useFile(file: File) {
        pdfFile = file
        pageTexts = null
        wordCache.clear()
    }

    private fun startOpening() {
        val file = pdfFile ?: return
        binding.progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            val opened = withContext(Dispatchers.IO) { PdfPageBitmap.open(file) }
            binding.progress.visibility = View.GONE
            if (opened == null) {
                handleOpenFailure(file)
                return@launch
            }
            session = opened
            pageCount = opened.pageCount
            showPages()
        }
    }

    private fun showPages() {
        baseWidthPx = minOf(resources.displayMetrics.widthPixels, MAX_PAGE_WIDTH)
        layoutManager = LinearLayoutManager(this)
        binding.rvPages.layoutManager = layoutManager
        val adapter = PdfReaderPageAdapter(
            pageCount, baseWidthPx, resources.displayMetrics.widthPixels, lifecycleScope,
            { index -> getString(R.string.reader_page_of, index + 1, pageCount) },
            { index, width -> renderPage(index, width) }
        )
        adapter.edits = edits
        adapter.tool = tool
        adapter.onFrame = { page, box -> onFrame(page, box) }
        adapter.onTap = { page, x, y, w, h -> onTextTap(page, x, y, w, h) }
        adapter.onStroke = { page, points -> onStroke(page, points) }
        adapter.toolColor = currentColor
        pageAdapter = adapter
        binding.rvPages.adapter = adapter
        binding.rvPages.oneFingerPan = tool == null
        // zoomed in, the pages are drawn at a larger width so the text stays sharp; back at 1x they return to the light size
        binding.rvPages.onZoomSettled = { zoomed ->
            val wanted = if (zoomed > 1.4f) maxOf(baseWidthPx, HIGH_PAGE_WIDTH) else baseWidthPx
            if (adapter.widthPx != wanted) {
                adapter.widthPx = wanted
                adapter.notifyDataSetChanged()
            }
        }
        binding.rvPages.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                updatePageIndicator()
            }
        })
        binding.tvPageIndicator.visibility = View.VISIBLE
        updatePageIndicator()
        // after saving a copy the reader continues on the page it was on; otherwise on the page remembered for this PDF
        val saved = resumePage ?: PdfReadingPositions.get(prefs().getString(KEY_POSITIONS, "") ?: "", positionKey)
        resumePage = null
        if (saved != null && saved in 1 until pageCount) binding.rvPages.post { jumpToPage(saved) }
    }

    private fun prefs() = getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** One page at a time (the platform renderer allows only one open page); null when the screen has already been closed. */
    private fun renderPage(index: Int, width: Int) = synchronized(lock) {
        if (closed) null else session?.render(index, width)
    }

    private fun updatePageIndicator() {
        val first = layoutManager.findFirstVisibleItemPosition().coerceAtLeast(0)
        binding.tvPageIndicator.text = getString(R.string.reader_page_of, first + 1, pageCount)
    }

    private fun jumpToPage(index: Int) {
        if (pageCount == 0) return
        binding.rvPages.resetZoom()
        layoutManager.scrollToPositionWithOffset(index.coerceIn(0, pageCount - 1), 0)
    }

    override fun onPause() {
        super.onPause()
        if (pageCount > 0 && pageAdapter != null) {
            val first = layoutManager.findFirstVisibleItemPosition().coerceAtLeast(0)
            val p = prefs()
            p.edit().putString(KEY_POSITIONS, PdfReadingPositions.put(p.getString(KEY_POSITIONS, "") ?: "", positionKey, first)).apply()
        }
    }

    // ---------------------------------------------------------------------------------------
    // PDFs the platform renderer cannot show: protected (ask for the password) or damaged
    // ---------------------------------------------------------------------------------------

    private fun handleOpenFailure(file: File) {
        lifecycleScope.launch {
            val protectedPdf = withContext(Dispatchers.IO) { needsPassword(file) }
            if (protectedPdf) askPassword(false) else showCannotShow()
        }
    }

    /** True only when PdfBox says a password is required (a damaged file is not "protected"). */
    private fun needsPassword(file: File): Boolean = try {
        PDDocument.load(file).close()
        false
    } catch (e: InvalidPasswordException) {
        true
    } catch (e: Throwable) {
        false
    }

    private fun askPassword(wrong: Boolean) {
        val input = EditText(this)
        input.setHint(R.string.reader_password_hint)
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = FrameLayout(this)
        holder.setPadding(pad, pad / 2, pad, 0)
        holder.addView(input)
        AlertDialog.Builder(this)
            .setTitle(if (wrong) R.string.reader_password_wrong else R.string.reader_password_title)
            .setView(holder)
            .setPositiveButton(android.R.string.ok) { _, _ -> unlock(input.text.toString()) }
            .setNegativeButton(R.string.dialog_cancel) { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    /** Removes the password into a copy in the cache (the original is untouched) and opens that copy. */
    private fun unlock(password: String) {
        val source = pdfFile ?: return
        val dir = File(cacheDir, "pdf_reader")
        dir.mkdirs()
        val unlocked = File(dir, "unlocked_" + System.currentTimeMillis() + ".pdf")
        binding.progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            var wrong = false
            val ok = withContext(Dispatchers.IO) {
                try {
                    PdfSecurityTools.unprotect(source, unlocked, password)
                    true
                } catch (e: PdfSecurityTools.WrongPassword) {
                    wrong = true
                    false
                } catch (e: Throwable) {
                    runCatching { unlocked.delete() }
                    false
                }
            }
            binding.progress.visibility = View.GONE
            when {
                ok -> {
                    if (isTemp) runCatching { source.delete() }
                    isTemp = true
                    useFile(unlocked)
                    startOpening()
                }
                wrong -> askPassword(true)
                else -> showCannotShow()
            }
        }
    }

    private fun showCannotShow() {
        AlertDialog.Builder(this)
            .setMessage(R.string.reader_open_failed)
            .setPositiveButton(R.string.reader_more_tools) { _, _ -> openTools() }
            .setNegativeButton(R.string.dialog_cancel) { _, _ -> finish() }
            .setOnCancelListener { finish() }
            .show()
    }

    // ---------------------------------------------------------------------------------------
    // Menu
    // ---------------------------------------------------------------------------------------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_pdf_reader, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val ready = pageCount > 0 && pageAdapter != null
        when (item.itemId) {
            android.R.id.home -> finish()
            R.id.action_reader_edit -> if (editing) closeEditing() else openEditing()
            R.id.action_reader_share -> pdfFile?.let { FileUtils.shareFile(this, it, getString(R.string.action_share)) }
            R.id.action_reader_print -> pdfFile?.let { PdfPrintAdapter.print(this, it) }
            R.id.action_reader_go_to -> if (ready) askPageNumber()
            R.id.action_reader_contents -> if (ready) showContents()
            R.id.action_reader_search -> if (ready) askSearch()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    private fun askPageNumber() {
        val input = EditText(this)
        input.inputType = InputType.TYPE_CLASS_NUMBER
        input.setHint(getString(R.string.reader_go_to_prompt, pageCount))
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = FrameLayout(this)
        holder.setPadding(pad, pad / 2, pad, 0)
        holder.addView(input)
        AlertDialog.Builder(this)
            .setTitle(R.string.reader_go_to_page)
            .setView(holder)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val number = input.text.toString().trim().toIntOrNull()
                if (number != null && number in 1..pageCount) jumpToPage(number - 1)
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    /** The PDF's own bookmarks, indented by level; each jumps to its page. Entries whose destination cannot be found are left out. */
    private fun showContents() {
        val file = pdfFile ?: return
        lifecycleScope.launch {
            val entries = withContext(Dispatchers.IO) {
                try { PdfBookmarks.normalizeLevels(PdfBookmarks.readFile(file).first.filter { it.page >= 0 }) } catch (e: Throwable) { emptyList() }
            }
            if (entries.isEmpty()) {
                Toast.makeText(this@PdfReaderActivity, R.string.reader_no_contents, Toast.LENGTH_LONG).show()
                return@launch
            }
            val labels = entries.map { "    ".repeat((it.level - 1).coerceAtLeast(0)) + it.title.trim() }
            AlertDialog.Builder(this@PdfReaderActivity)
                .setTitle(R.string.reader_contents)
                .setItems(labels.toTypedArray()) { _, which -> jumpToPage(entries[which].page) }
                .setNegativeButton(R.string.dialog_cancel, null)
                .show()
        }
    }

    private fun askSearch() {
        val input = EditText(this)
        input.setHint(R.string.epub_search_hint)
        input.setSingleLine()
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = FrameLayout(this)
        holder.setPadding(pad, pad / 2, pad, 0)
        holder.addView(input)
        AlertDialog.Builder(this)
            .setTitle(R.string.reader_search)
            .setView(holder)
            .setPositiveButton(android.R.string.ok) { _, _ -> runSearch(input.text.toString()) }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    /**
     * Searches the text layer (extracted once per PDF and kept) with [EpubSearch], which ignores case and accents; every page is one "chapter" whose lines are the
     * "paragraphs". A scanned PDF has no text layer: say so and point to the searchable-PDF tool instead of finding nothing.
     */
    private fun runSearch(query: String) {
        if (query.isBlank()) return
        val file = pdfFile ?: return
        binding.progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            val texts = pageTexts ?: withContext(Dispatchers.IO) { PdfTextExtractor.textLayer(file) }
            pageTexts = texts
            if (texts == null || texts.all { it.isBlank() }) {
                binding.progress.visibility = View.GONE
                Toast.makeText(this@PdfReaderActivity, R.string.reader_search_no_text, Toast.LENGTH_LONG).show()
                return@launch
            }
            val total = IntArray(1)
            val hits = withContext(Dispatchers.Default) {
                val chapters = texts.map { page -> EbookBuilder.Chapter("", page.lines().map { it.trim() }.filter { it.isNotEmpty() }) }
                EpubSearch.search(chapters, query, MAX_SHOWN_HITS, total)
            }
            binding.progress.visibility = View.GONE
            if (hits.isEmpty()) {
                Toast.makeText(this@PdfReaderActivity, getString(R.string.epub_search_none, query), Toast.LENGTH_LONG).show()
                return@launch
            }
            val labels = hits.map { getString(R.string.reader_hit_page, it.chapter + 1) + " · " + it.before + it.match + it.after }
            AlertDialog.Builder(this@PdfReaderActivity)
                .setTitle(getString(R.string.epub_search_header, query, total[0]))
                .setItems(labels.toTypedArray()) { _, which -> jumpToPage(hits[which].chapter) }
                .setNegativeButton(R.string.dialog_cancel, null)
                .show()
        }
    }

    // ---------------------------------------------------------------------------------------
    // Editing toolbar (4.61): highlight / underline / strike out, black box, text, drawn on the page itself
    // ---------------------------------------------------------------------------------------

    private fun setupEditBar() {
        binding.btnToolHighlight.setOnClickListener { selectTool(ReaderEdits.Kind.HIGHLIGHT) }
        binding.btnToolUnderline.setOnClickListener { selectTool(ReaderEdits.Kind.UNDERLINE) }
        binding.btnToolStrike.setOnClickListener { selectTool(ReaderEdits.Kind.STRIKE) }
        binding.btnToolBlack.setOnClickListener { selectTool(ReaderEdits.Kind.BLACKBOX) }
        binding.btnToolText.setOnClickListener { selectTool(ReaderEdits.Kind.TEXT) }
        binding.btnToolPen.setOnClickListener { selectTool(ReaderEdits.Kind.PEN) }
        binding.btnToolMarker.setOnClickListener { selectTool(ReaderEdits.Kind.MARKER) }
        binding.btnEditColor.setTextColor(currentColor)
        binding.btnEditColor.setOnClickListener { cycleColor() }
        binding.btnEditUndo.setOnClickListener { undoEdit() }
        binding.btnEditSave.setOnClickListener { saveEdits() }
        binding.btnEditMore.setOnClickListener { openTools() }
        binding.btnEditClose.setOnClickListener { closeEditing() }
    }

    private fun openEditing() {
        if (pageCount == 0) return
        editing = true
        binding.editBar.visibility = View.VISIBLE
        Toast.makeText(this, R.string.reader_edit_hint, Toast.LENGTH_LONG).show()
    }

    /** Closes the toolbar; marks not yet saved are only dropped after the person agrees. */
    private fun closeEditing() {
        if (edits.isEmpty()) {
            endEditing()
            return
        }
        AlertDialog.Builder(this)
            .setMessage(R.string.reader_edit_discard)
            .setPositiveButton(R.string.reader_edit_discard_yes) { _, _ -> endEditing() }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun endEditing() {
        edits.clear()
        editing = false
        binding.editBar.visibility = View.GONE
        setTool(null)
        pageAdapter?.refreshOverlays()
    }

    private fun selectTool(kind: ReaderEdits.Kind) {
        if (tool == kind) {
            setTool(null)
            return
        }
        if (kind == ReaderEdits.Kind.TEXT) {
            askStampText { text ->
                pendingText = text
                setTool(kind)
            }
            return
        }
        setTool(kind)
    }

    /** While a tool is active one finger draws on the page, so the list no longer pans or zooms with one finger (pinch still zooms; two fingers pan). */
    private fun setTool(kind: ReaderEdits.Kind?) {
        tool = kind
        pageAdapter?.tool = kind
        binding.rvPages.oneFingerPan = kind == null
        pageAdapter?.refreshOverlays()
        val on = ColorUtils.setAlphaComponent(ContextCompat.getColor(this, R.color.primary), 70)
        val buttons: List<Pair<MaterialButton, ReaderEdits.Kind>> = listOf(
            binding.btnToolHighlight to ReaderEdits.Kind.HIGHLIGHT, binding.btnToolUnderline to ReaderEdits.Kind.UNDERLINE,
            binding.btnToolStrike to ReaderEdits.Kind.STRIKE, binding.btnToolBlack to ReaderEdits.Kind.BLACKBOX, binding.btnToolText to ReaderEdits.Kind.TEXT,
            binding.btnToolPen to ReaderEdits.Kind.PEN, binding.btnToolMarker to ReaderEdits.Kind.MARKER
        )
        for ((button, k) in buttons) button.setBackgroundColor(if (kind == k) on else Color.TRANSPARENT)
    }

    /** The colour of the pen, underline, strike-out and text marks goes round a short palette (red, blue, black, green); a highlight and the marker stay yellow. */
    private fun cycleColor() {
        colorIndex = (colorIndex + 1) % PALETTE.size
        binding.btnEditColor.setTextColor(currentColor)
        pageAdapter?.toolColor = currentColor
        pageAdapter?.refreshOverlays()
    }

    private fun askStampText(then: (String) -> Unit) {
        val input = EditText(this)
        input.setHint(R.string.reader_edit_text_prompt)
        input.setSingleLine()
        val pad = (20 * resources.displayMetrics.density).toInt()
        val holder = FrameLayout(this)
        holder.setPadding(pad, pad / 2, pad, 0)
        holder.addView(input)
        AlertDialog.Builder(this)
            .setTitle(R.string.reader_tool_text)
            .setView(holder)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) then(text)
            }
            .setNegativeButton(R.string.dialog_cancel, null)
            .show()
    }

    private fun undoEdit() {
        val removed = edits.undo() ?: return
        pageAdapter?.refreshOverlay(removed.page)
    }

    /** The PDF's own text layer (no OCR): exact words to snap a highlight to; empty for a scan, where the frame itself becomes the mark. */
    private suspend fun wordsFor(page: Int): List<PdfTextMarkup.WordBox> {
        wordCache[page]?.let { return it }
        val file = pdfFile ?: return emptyList()
        val layer = withContext(Dispatchers.IO) { PdfTextLayer.words(file, page) }
        val words = if (layer != null && layer.size >= 3) layer else emptyList()
        wordCache[page] = words
        return words
    }

    private fun onFrame(page: Int, box: FloatArray) {
        val active = tool ?: return
        if (active == ReaderEdits.Kind.BLACKBOX) {
            edits.add(ReaderEdits.Item(active, page, box))
            pageAdapter?.refreshOverlay(page)
            return
        }
        if (active == ReaderEdits.Kind.TEXT) return
        // highlight / underline / strike out: the words whose centre is inside the frame, one band per line; no words there -> the frame itself
        lifecycleScope.launch {
            val words = wordsFor(page)
            val chosen = PdfTextMarkup.wordsInRect(words, box)
            val boxes = if (chosen.isEmpty()) listOf(box) else PdfTextMarkup.lineBoxes(words, chosen)
            val color = if (active == ReaderEdits.Kind.HIGHLIGHT) ReaderEdits.MARKER_COLOR else currentColor
            for (b in boxes) edits.add(ReaderEdits.Item(active, page, b, color = color))
            pageAdapter?.refreshOverlay(page)
        }
    }

    private fun onTextTap(page: Int, x: Float, y: Float, width: Float, height: Float) {
        val text = pendingText ?: return
        val picture = StampRenderer.plainText(text, currentColor)
        val aspect = picture.width.toFloat() / picture.height.toFloat()
        picture.recycle()
        val box = ReaderEdits.stampBox(x, y, width, height, STAMP_WIDTH_FRACTION, aspect) ?: return
        edits.add(ReaderEdits.Item(ReaderEdits.Kind.TEXT, page, box, text, color = currentColor))
        pageAdapter?.refreshOverlay(page)
    }

    /** A pen or marker stroke: thinned, then kept as an item; it becomes a real ink annotation when the copy is saved. */
    private fun onStroke(page: Int, points: FloatArray) {
        val kind = tool ?: return
        if (kind != ReaderEdits.Kind.PEN && kind != ReaderEdits.Kind.MARKER) return
        val thinned = PdfInk.simplifyCapped(points)
        if (thinned.isEmpty()) return
        val color = if (kind == ReaderEdits.Kind.MARKER) ReaderEdits.MARKER_COLOR else currentColor
        edits.add(ReaderEdits.Item(kind, page, ReaderEdits.boundsOf(thinned), points = thinned, color = color))
        pageAdapter?.refreshOverlay(page)
    }

    /**
     * Writes the marks into a NEW PDF (the original is not changed): black boxes first (they turn their pages into pictures, so nothing under them survives), then text
     * stamps, then the highlight / underline / strike-out marks as real PDF annotations on top (the text stays selectable). A signed PDF asks first, because the copy cannot
     * keep the signature valid. Afterwards the reader shows the copy, on the same page.
     */
    private fun saveEdits() {
        if (edits.isEmpty()) {
            Toast.makeText(this, R.string.reader_edit_nothing, Toast.LENGTH_SHORT).show()
            return
        }
        val src = pdfFile ?: return
        val snapshot = ArrayList(edits.items)
        binding.progress.visibility = View.VISIBLE
        lifecycleScope.launch {
            if (!SignedPdfGuard.confirm(this@PdfReaderActivity, src)) {
                binding.progress.visibility = View.GONE
                return@launch
            }
            val out = File(PdfExporter.exportDir(this@PdfReaderActivity), FileUtils.defaultSecurityName("edited") + ".pdf")
            val result = runCatching { withContext(Dispatchers.Default) { applyEdits(src, snapshot, out) } }
            binding.progress.visibility = View.GONE
            if (result.isFailure) {
                runCatching { out.delete() }
                Toast.makeText(this@PdfReaderActivity, R.string.reader_edit_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            Toast.makeText(this@PdfReaderActivity, getString(R.string.reader_edit_saved, out.name), Toast.LENGTH_LONG).show()
            switchTo(out)
        }
    }

    private fun applyEdits(src: File, items: List<ReaderEdits.Item>, out: File) {
        val temps = ArrayList<File>()
        val dir = File(cacheDir, "pdf_reader")
        dir.mkdirs()
        var current = src
        try {
            val boxes = items.filter { it.kind == ReaderEdits.Kind.BLACKBOX }.groupBy({ it.page }, { it.box })
            if (boxes.isNotEmpty()) {
                val next = File(dir, "edit_" + System.nanoTime() + ".pdf")
                temps.add(next)
                PdfRedactor.redact(current, next, boxes)
                current = next
            }
            for (item in items.filter { it.kind == ReaderEdits.Kind.TEXT }) {
                val next = File(dir, "edit_" + System.nanoTime() + ".pdf")
                temps.add(next)
                val picture = StampRenderer.plainText(item.text ?: "", item.color)
                try {
                    val b = item.box
                    PdfStamper.stamp(current, next, picture, PdfStamper.Placement((b[0] + b[2]) / 2f, (b[1] + b[3]) / 2f, b[2] - b[0]), setOf(item.page))
                } finally {
                    picture.recycle()
                }
                current = next
            }
            val strokes = items.filter { it.kind == ReaderEdits.Kind.PEN || it.kind == ReaderEdits.Kind.MARKER }
                .groupBy({ it.page }, { PdfInk.Stroke(it.points ?: FloatArray(0), it.color, if (it.kind == ReaderEdits.Kind.MARKER) PdfInk.MARKER_WIDTH else PdfInk.PEN_WIDTH, it.kind == ReaderEdits.Kind.MARKER) })
            if (strokes.isNotEmpty()) {
                val next = File(dir, "edit_" + System.nanoTime() + ".pdf")
                temps.add(next)
                PdfInk.annotate(current, next, strokes)
                current = next
            }
            val marks = items.filter { it.kind == ReaderEdits.Kind.HIGHLIGHT || it.kind == ReaderEdits.Kind.UNDERLINE || it.kind == ReaderEdits.Kind.STRIKE }
                .groupBy({ it.page }, { PdfTextMarkup.Mark(it.box, styleOf(it.kind), rgbOf(it.color)) })
            if (marks.isNotEmpty()) PdfTextMarkup.annotate(current, out, marks) else current.copyTo(out, overwrite = true)
        } finally {
            for (t in temps) runCatching { t.delete() }
        }
    }

    private fun styleOf(kind: ReaderEdits.Kind): PdfTextMarkup.Style = when (kind) {
        ReaderEdits.Kind.UNDERLINE -> PdfTextMarkup.Style.UNDERLINE
        ReaderEdits.Kind.STRIKE -> PdfTextMarkup.Style.STRIKEOUT
        else -> PdfTextMarkup.Style.HIGHLIGHT
    }

    private fun rgbOf(color: Int): FloatArray =
        floatArrayOf(((color shr 16) and 0xFF) / 255f, ((color shr 8) and 0xFF) / 255f, (color and 0xFF) / 255f)

    /** Shows the saved copy in place of the PDF just read, on the same page. */
    private fun switchTo(out: File) {
        val page = layoutManager.findFirstVisibleItemPosition().coerceAtLeast(0)
        synchronized(lock) {
            session?.close()
            session = null
        }
        if (isTemp) pdfFile?.let { runCatching { it.delete() } }
        isTemp = false
        resumePage = page
        title = out.name
        positionKey = PdfReadingPositions.key(out.name, out.length())
        pageAdapter = null
        pageCount = 0
        binding.rvPages.adapter = null
        useFile(out)
        endEditing()
        startOpening()
    }

    // ---------------------------------------------------------------------------------------
    // Editing tools
    // ---------------------------------------------------------------------------------------

    /**
     * The Edit button: every tool that works on this PDF (about 30: edit & annotate, sign & protect, pages & structure, convert & export, read, extract), grouped. The
     * tools live in the main screen, which is brought IN FRONT of this reader (REORDER_TO_FRONT, so the reader stays underneath and Back returns to it) and shows
     * their menu for this file. A tool that makes a new file leaves it in the history; this reader remembers the page, so opening it again continues there.
     */
    private fun openTools() {
        val file = pdfFile ?: return
        val name = title.toString()
        startActivity(Intent(this, MainActivity::class.java).apply {
            action = ACTION_PDF_TOOLS
            putExtra(EXTRA_PDF_PATH, file.absolutePath)
            putExtra(EXTRA_TITLE, name)
            addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
        })
    }

    override fun onDestroy() {
        super.onDestroy()
        synchronized(lock) {
            closed = true
            session?.close()
            session = null
        }
        if (isTemp && isFinishing) pdfFile?.let { runCatching { it.delete() } }
    }

    companion object {
        const val EXTRA_PDF_PATH = "extra_pdf_path"
        /** The file is our own copy: delete it when the screen finishes. */
        const val EXTRA_TEMP = "extra_temp"
        const val EXTRA_TITLE = "extra_title"

        /** Sent to the main screen by the Edit button: show the tools for the PDF in [EXTRA_PDF_PATH]. */
        const val ACTION_PDF_TOOLS = "com.example.docscanner.action.PDF_TOOLS"

        private const val PREFS = "pdf_reader"
        private const val KEY_POSITIONS = "positions"

        /** Pages are drawn at most this wide (pixels) so a tablet does not hold huge bitmaps; while zoomed in, [HIGH_PAGE_WIDTH] (about 18 MB per page). */
        private const val MAX_PAGE_WIDTH = 1500
        private const val HIGH_PAGE_WIDTH = 1800
        private const val MAX_SHOWN_HITS = 100

        /** Text placed with the editing toolbar is this fraction of the page wide. */
        private const val STAMP_WIDTH_FRACTION = 0.35f

        /** Colours of the pen, underline, strike-out and text marks: red, blue, black, green. */
        private val PALETTE = intArrayOf(0xFFD91A1A.toInt(), 0xFF1976D2.toInt(), 0xFF000000.toInt(), 0xFF2E7D32.toInt())

        /**
         * Copies the content behind [uri] into the reader's cache folder (served by FileProvider, see file_paths.xml) and returns the copy, or null when it cannot be read.
         * Copies older than a day (left by a process that was killed) are removed first. Call it off the main thread, while the access to [uri] is still valid.
         */
        fun copyToCache(context: Context, uri: Uri): File? {
            val dir = File(context.cacheDir, "pdf_reader")
            dir.mkdirs()
            val cutoff = System.currentTimeMillis() - 24L * 60 * 60 * 1000
            dir.listFiles()?.forEach { if (it.lastModified() < cutoff) it.delete() }
            val copy = File(dir, "pdf_" + System.currentTimeMillis() + ".pdf")
            return try {
                val input = context.contentResolver.openInputStream(uri) ?: return null
                input.use { source -> copy.outputStream().use { sink -> source.copyTo(sink) } }
                copy
            } catch (e: Exception) {
                copy.delete()
                null
            }
        }
    }
}
