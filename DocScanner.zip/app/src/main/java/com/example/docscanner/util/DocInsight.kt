package com.example.docscanner.util

import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * "Trí tuệ tài liệu" from the TEXT of a document (its text layer, or the OCR transcript) - PDF "Thiếu gì để bán app" H1 / H3 / H6, phiên 20 mục 4.48.3:
 *  - [classify]: what KIND of document it is (invoice, contract, ID card, bank statement ...) by weighted phrases;
 *  - [keywords]: tag suggestions by TF-IDF (single words AND two-word phrases, because a Vietnamese word is usually two syllables: "hop dong", not "hop" + "dong"),
 *    the IDF coming from the user's OTHER documents;
 *  - [summary]: the sentences TextRank ranks highest (graph of sentences, TF-IDF cosine similarity, PageRank), in the order they appear.
 *
 * Everything is on the ACCENT-FOLDED, lower-case text ([PiiDetector.foldLower], same length, so offsets found there cut the original), which makes "Hợp đồng", "HOP DONG" and OCR
 * output without marks the same words. PURE (strings in, strings out): `tools/verify/DocInsightCheck.java` is a line-by-line Java copy; `tools/verify/doc_insight_check.py` compares it with
 * scikit-learn (IDF) and networkx (PageRank) and measures [classify] on documents written independently of the phrase table.
 *
 * Helper, not an authority: the dialog that shows the result says so, and a wrong tag is one tap to remove.
 */
object DocInsight {

    enum class Category { INVOICE, RECEIPT, CONTRACT, ID_DOCUMENT, BANK_STATEMENT, CERTIFICATE, RESUME, OFFICIAL_LETTER, FORM }

    /** [category] is null when nothing scores [MIN_SCORE]; [runnerUp] is the second best when it comes close (>= 70 % of the best), else null. */
    class Classification(val category: Category?, val score: Double, val runnerUp: Category?, val runnerUpScore: Double)

    const val MIN_SCORE = 5.0
    private const val MAX_PER_PHRASE = 3
    private const val CLASSIFY_CHARS = 30_000

    /** One phrase per line: `CATEGORY weight phrase` (accent-free, lower case). A phrase counts at most [MAX_PER_PHRASE] times, and only as whole words. */
    internal val TABLE = """
INVOICE 6 hoa don gia tri gia tang
INVOICE 6 vat invoice
INVOICE 4 tax invoice
INVOICE 3 hoa don
INVOICE 3 invoice no
INVOICE 3 invoice number
INVOICE 2 invoice
INVOICE 2 ma so thue
INVOICE 2 thue suat
INVOICE 2 thue gtgt
INVOICE 2.5 nguoi mua hang
INVOICE 2.5 don vi ban hang
INVOICE 3 tong cong tien thanh toan
INVOICE 1.5 tien thue
INVOICE 1.5 thanh tien
INVOICE 1.5 don gia
INVOICE 1.5 don vi tinh
INVOICE 1.5 ky hieu
INVOICE 1.5 unit price
INVOICE 1.5 bill to
INVOICE 1 so luong
INVOICE 1 subtotal
INVOICE 1 vat
RECEIPT 4 bien lai
RECEIPT 4 phieu thu
RECEIPT 3 phieu chi
RECEIPT 4 receipt
RECEIPT 3 cam on quy khach
RECEIPT 3 tien khach dua
RECEIPT 3 tien thua
RECEIPT 2.5 thu ngan
RECEIPT 2.5 cashier
RECEIPT 3 so tien da nhan
RECEIPT 3 payment received
RECEIPT 2.5 nguoi nop tien
RECEIPT 2 ly do nop
RECEIPT 2 da nhan cua
RECEIPT 2 change due
RECEIPT 2 total paid
RECEIPT 1 thank you
RECEIPT 1 tien mat
CONTRACT 5 hai ben cung thoa thuan
CONTRACT 4 cac ben thoa thuan
CONTRACT 4 hop dong
CONTRACT 4 cham dut hop dong
CONTRACT 3 ben a
CONTRACT 3 ben b
CONTRACT 3 party a
CONTRACT 3 party b
CONTRACT 3 agreement
CONTRACT 3 giai quyet tranh chap
CONTRACT 3 ben cho thue
CONTRACT 3 dai dien ben a
CONTRACT 4 witness whereof
CONTRACT 2.5 ben thue
CONTRACT 2.5 the parties
CONTRACT 2 dieu 1
CONTRACT 2 dieu 2
CONTRACT 2 dieu khoan
CONTRACT 2 tien dat coc
CONTRACT 2 contract
CONTRACT 2 landlord
CONTRACT 2 tenant
CONTRACT 1.5 hieu luc
CONTRACT 1.5 hereby
CONTRACT 1 bao mat
ID_DOCUMENT 6 can cuoc cong dan
ID_DOCUMENT 6 chung minh nhan dan
ID_DOCUMENT 6 citizen identity card
ID_DOCUMENT 6 giay phep lai xe
ID_DOCUMENT 5 driving licence
ID_DOCUMENT 5 driver license
ID_DOCUMENT 4 identity card
ID_DOCUMENT 4 so can cuoc
ID_DOCUMENT 4 passport
ID_DOCUMENT 4 ho chieu
ID_DOCUMENT 3 so cmnd
ID_DOCUMENT 2.5 que quan
ID_DOCUMENT 2.5 noi thuong tru
ID_DOCUMENT 2.5 place of residence
ID_DOCUMENT 2.5 date of expiry
ID_DOCUMENT 2 ngay sinh
ID_DOCUMENT 2 date of birth
ID_DOCUMENT 2 gia tri den
ID_DOCUMENT 2 dan toc
ID_DOCUMENT 2 nationality
ID_DOCUMENT 2 quoc tich
ID_DOCUMENT 1.5 gioi tinh
BANK_STATEMENT 6 sao ke tai khoan
BANK_STATEMENT 6 bank statement
BANK_STATEMENT 5 account statement
BANK_STATEMENT 4 sao ke
BANK_STATEMENT 4 so du dau ky
BANK_STATEMENT 4 so du cuoi ky
BANK_STATEMENT 4 opening balance
BANK_STATEMENT 4 closing balance
BANK_STATEMENT 3 noi dung giao dich
BANK_STATEMENT 2.5 ghi no
BANK_STATEMENT 2.5 ghi co
BANK_STATEMENT 2 so tai khoan
BANK_STATEMENT 2 account number
BANK_STATEMENT 2 so tham chieu
BANK_STATEMENT 1.5 so du
BANK_STATEMENT 1.5 giao dich
BANK_STATEMENT 1.5 ngan hang
BANK_STATEMENT 1.5 dien giai
BANK_STATEMENT 1.5 debit
BANK_STATEMENT 1 transaction
BANK_STATEMENT 1 credit
BANK_STATEMENT 1 bank
BANK_STATEMENT 1 chi nhanh
CERTIFICATE 6 giay khai sinh
CERTIFICATE 6 birth certificate
CERTIFICATE 6 giay ket hon
CERTIFICATE 6 marriage certificate
CERTIFICATE 5 giay chung nhan
CERTIFICATE 5 bang tot nghiep
CERTIFICATE 5 this is to certify
CERTIFICATE 4 chung chi
CERTIFICATE 4 certificate
CERTIFICATE 4 certify that
CERTIFICATE 4 hereby certify
CERTIFICATE 4 diploma
CERTIFICATE 4 bang khen
CERTIFICATE 4 giay khen
CERTIFICATE 3 van bang
CERTIFICATE 3 so vao so
CERTIFICATE 2.5 hieu truong
CERTIFICATE 2.5 tot nghiep
CERTIFICATE 2 chung nhan
CERTIFICATE 2 xep loai
CERTIFICATE 1.5 cap ngay
CERTIFICATE 1.5 so hieu
CERTIFICATE 1.5 awarded
CERTIFICATE 1.5 completion
RESUME 6 curriculum vitae
RESUME 5 muc tieu nghe nghiep
RESUME 5 career objective
RESUME 5 kinh nghiem lam viec
RESUME 5 work experience
RESUME 4 professional summary
RESUME 4 employment history
RESUME 3 resume
RESUME 3 hoc van
RESUME 3 nguoi tham chieu
RESUME 2.5 ky nang
RESUME 2.5 so thich
RESUME 2 cv
RESUME 2 skills
RESUME 2 education
RESUME 2 thanh tuu
RESUME 2 linkedin
RESUME 1.5 references
OFFICIAL_LETTER 5 cong van
OFFICIAL_LETTER 4 to trinh
OFFICIAL_LETTER 4 kinh gui
OFFICIAL_LETTER 4 to whom it may concern
OFFICIAL_LETTER 4 memorandum
OFFICIAL_LETTER 3.5 quyet dinh
OFFICIAL_LETTER 3.5 noi nhan
OFFICIAL_LETTER 3 doc lap tu do hanh phuc
OFFICIAL_LETTER 3 so ky hieu
OFFICIAL_LETTER 3 v/v
OFFICIAL_LETTER 3 thu moi
OFFICIAL_LETTER 3 giay moi
OFFICIAL_LETTER 3 uy ban nhan dan
OFFICIAL_LETTER 3 yours faithfully
OFFICIAL_LETTER 3 yours sincerely
OFFICIAL_LETTER 2.5 thong bao
OFFICIAL_LETTER 2.5 can cu
OFFICIAL_LETTER 2.5 ve viec
OFFICIAL_LETTER 2 ubnd
OFFICIAL_LETTER 2 dear sir
OFFICIAL_LETTER 2 dear madam
OFFICIAL_LETTER 2 cong hoa xa hoi chu nghia viet nam
OFFICIAL_LETTER 1.5 sincerely
FORM 5 to khai
FORM 5 application form
FORM 5 registration form
FORM 4 don xin
FORM 4 don de nghi
FORM 4 phieu dang ky
FORM 3.5 nguoi lam don
FORM 3 kinh don
FORM 3 toi xin cam doan
FORM 3 bieu mau
FORM 2.5 xin xac nhan
FORM 2.5 mau so
FORM 2 cam doan
FORM 1.5 ngay thang nam sinh
FORM 1.5 dang ky
FORM 1 ho va ten
FORM 1 full name
FORM 0.5 cong hoa xa hoi chu nghia viet nam
""".trimIndent()

    private val PHRASES: Map<Category, List<Pair<String, Double>>> by lazy { parseTable(TABLE) }

    internal fun parseTable(table: String): Map<Category, List<Pair<String, Double>>> {
        val out = LinkedHashMap<Category, MutableList<Pair<String, Double>>>()
        for (line in table.lines()) {
            val t = line.trim()
            if (t.isEmpty() || t.startsWith("#")) continue
            val p = t.split(' ', limit = 3)
            out.getOrPut(Category.valueOf(p[0])) { ArrayList() }.add(Pair(p[2], p[1].toDouble()))
        }
        return out
    }

    private val SPACES = Regex("\\s+")

    /** Occurrences of [phrase] in [low] as WHOLE words (no letter or digit right before or after), not overlapping. */
    internal fun countPhrase(low: String, phrase: String): Int {
        var n = 0
        var from = 0
        while (true) {
            val i = low.indexOf(phrase, from)
            if (i < 0) break
            val end = i + phrase.length
            val before = if (i == 0) ' ' else low[i - 1]
            val after = if (end >= low.length) ' ' else low[end]
            if (!before.isLetterOrDigit() && !after.isLetterOrDigit()) n++
            from = end
        }
        return n
    }

    /** The kind of document [text] looks like (first 30 000 characters; [table] only differs from [TABLE] in the check). */
    fun classify(text: String, table: Map<Category, List<Pair<String, Double>>> = PHRASES): Classification {
        val low = SPACES.replace(PiiDetector.foldLower(text.take(CLASSIFY_CHARS)), " ")
        val scores = ArrayList<Pair<Category, Double>>()
        for ((cat, list) in table) {
            var s = 0.0
            for ((phrase, w) in list) s += w * minOf(countPhrase(low, phrase), MAX_PER_PHRASE)
            scores.add(Pair(cat, s))
        }
        val sorted = scores.sortedWith(compareBy({ -it.second }, { it.first.ordinal }))
        val best = sorted[0]
        val second = sorted.getOrNull(1)
        if (best.second < MIN_SCORE) return Classification(null, best.second, null, 0.0)
        val close = second != null && second.second >= 0.7 * best.second && second.second >= MIN_SCORE
        return Classification(best.first, best.second, if (close) second!!.first else null, if (close) second!!.second else 0.0)
    }

    // ------------------------------------------------------------------------------------------------- tokens

    /** A word of the folded text: [start, end) are offsets in BOTH the folded and the original text; [breakBefore] = punctuation / a digit / a blank line stands between it and the word before. */
    internal class Tok(val text: String, val start: Int, val end: Int, val breakBefore: Boolean)

    internal fun tokenize(text: String): List<Tok> {
        val low = PiiDetector.foldLower(text)
        val out = ArrayList<Tok>()
        var i = 0
        var brk = true
        var newlines = 0
        while (i < low.length) {
            val c = low[i]
            if (c.isLetter()) {
                var j = i + 1
                while (j < low.length && low[j].isLetter()) j++
                out.add(Tok(low.substring(i, j), i, j, brk))
                brk = false
                newlines = 0
                i = j
            } else {
                if (c == '\n') { newlines++; if (newlines >= 2) brk = true }
                else if (c != ' ' && c != '\t' && c != '\r' && c != '-' && c != '\'' && c != '\u2019') brk = true
                i++
            }
        }
        return out
    }

    private val STOP: Set<String> = (
        "the and for are but not you all any can had her was one our out has have his how its may new now see two way who did get let put say she too use " +
        "that this with from they will would there their what about which when your said each than them then these those been being into over such only also more most some " +
        "were where while after before between because other should could shall under upon very " +
        "va cua la co cho trong mot cac nhung duoc den tu voi nay do khi khong nhu de da se ve tai theo nguoi nam ngay thang " +
        "cung nen hay hoac neu thi ma ra vao len xuong rat con cac moi tung bi boi lai nua con dang sau truoc cung nhieu it hon so chung toi ta ong ba anh chi dieu ten gom xa hoi chu nghia viet hanh phuc doc lap"
        ).split(' ').toSet()

    /** Calls [f] for every candidate term of [toks]: the word itself (4+ letters, not a stop word) and the pair with the next word (2+ letters each, neither a stop word, no break between). */
    private fun eachCandidate(toks: List<Tok>, f: (key: String, words: Int, start: Int, end: Int) -> Unit) {
        for ((i, t) in toks.withIndex()) {
            if (t.text.length >= 4 && t.text !in STOP) f(t.text, 1, t.start, t.end)
            if (i + 1 < toks.size) {
                val u = toks[i + 1]
                if (!u.breakBefore && t.text.length >= 2 && u.text.length >= 2 && t.text !in STOP && u.text !in STOP) f(t.text + " " + u.text, 2, t.start, u.end)
            }
        }
    }

    private class Term(val key: String, val words: Int, val start: Int, val end: Int) { var count = 0 }

    /** Terms and their document frequency over the OTHER documents; shared by [keywords] and the check. */
    internal fun documentFrequency(others: List<String>): Map<String, Int> {
        val df = HashMap<String, Int>()
        for (o in others) {
            val seen = HashSet<String>()
            eachCandidate(tokenize(o)) { key, _, _, _ -> seen.add(key) }
            for (k in seen) df[k] = (df[k] ?: 0) + 1
        }
        return df
    }

    /** sklearn's smooth IDF: ln((1 + n) / (1 + df)) + 1, with the document itself counted among the [n] documents and in [df]. */
    internal fun idf(n: Int, df: Int): Double = ln((1.0 + n) / (1.0 + df)) + 1.0

    /** Weight of a candidate in the document: (1 + ln count) x IDF, and x 1.5 for a two-word phrase. */
    internal fun termScore(count: Int, words: Int, n: Int, df: Int): Double = (1.0 + ln(count.toDouble())) * idf(n, df) * (if (words == 2) 1.5 else 1.0)

    /**
     * Up to [k] tag suggestions for [text], best first: at most 3 two-word phrases (each seen 2+ times) and then single words (2+ times) that are not part of a chosen phrase.
     * [others] = the text of the user's other documents (they give the IDF: a word that every document has is no tag).
     */
    fun keywords(text: String, others: List<String>, k: Int = 5): List<String> {
        val toks = tokenize(text)
        if (toks.size < 8) return emptyList()
        val terms = LinkedHashMap<String, Term>()
        eachCandidate(toks) { key, words, start, end -> terms.getOrPut(key) { Term(key, words, start, end) }.count++ }
        val df = documentFrequency(others)
        val n = others.size + 1
        val ranked = terms.values.filter { it.count >= 2 }
            .map { Pair(it, termScore(it.count, it.words, n, (df[it.key] ?: 0) + 1)) }
            .sortedWith(compareBy({ -it.second }, { it.first.key }))
        val chosen = ArrayList<Term>()
        for ((t, _) in ranked) if (t.words == 2 && chosen.size < minOf(3, k)) chosen.add(t)
        val inPhrases = HashSet<String>()
        for (t in chosen) inPhrases.addAll(t.key.split(' '))
        for ((t, _) in ranked) {
            if (chosen.size >= k) break
            if (t.words == 1 && t.key !in inPhrases) chosen.add(t)
        }
        return chosen.map { SPACES.replace(text.substring(it.start, it.end), " ").lowercase() }
    }

    // ------------------------------------------------------------------------------------------------- summary (TextRank)

    private const val MIN_SENTENCE = 30
    private const val MAX_SENTENCE = 400
    private const val MAX_SENTENCES = 300

    /** The sentences of [text]: a blank line ends a paragraph, single line breaks are joined with a space (OCR wraps lines inside a sentence), `. ! ?` followed by a blank or the end, and `。！？`, end a sentence. */
    fun sentences(text: String): List<String> {
        val paragraphs = ArrayList<String>()
        val cur = StringBuilder()
        for (line in text.lines()) {
            val t = line.trim()
            if (t.isEmpty()) { if (cur.isNotEmpty()) { paragraphs.add(cur.toString()); cur.setLength(0) } }
            else { if (cur.isNotEmpty()) cur.append(' '); cur.append(t) }
        }
        if (cur.isNotEmpty()) paragraphs.add(cur.toString())
        val out = ArrayList<String>()
        for (p in paragraphs) {
            var start = 0
            for (i in p.indices) {
                val c = p[i]
                val cut = when (c) {
                    '.', '!', '?' -> i + 1 >= p.length || p[i + 1].isWhitespace()
                    '\u3002', '\uFF01', '\uFF1F' -> true
                    else -> false
                }
                if (cut) {
                    val s = SPACES.replace(p.substring(start, i + 1), " ").trim()
                    if (s.isNotEmpty()) out.add(s)
                    start = i + 1
                }
            }
            val rest = SPACES.replace(p.substring(start), " ").trim()
            if (rest.isNotEmpty()) out.add(rest)
        }
        return out
    }

    /** TF-IDF vectors (sklearn smooth IDF over the sentences, L2-normalised) of the words of every sentence; null entries have no usable word. */
    internal fun sentenceVectors(sentences: List<String>): List<Map<String, Double>> {
        val counts = sentences.map { s ->
            val m = HashMap<String, Int>()
            for (t in tokenize(s)) if (t.text.length >= 2 && t.text !in STOP) m[t.text] = (m[t.text] ?: 0) + 1
            m
        }
        val df = HashMap<String, Int>()
        for (m in counts) for (w in m.keys) df[w] = (df[w] ?: 0) + 1
        val n = sentences.size
        return counts.map { m ->
            val v = HashMap<String, Double>()
            var norm = 0.0
            for ((w, c) in m) { val x = c * idf(n, df[w] ?: 0); v[w] = x; norm += x * x }
            if (norm > 0.0) { val r = sqrt(norm); for (w in v.keys.toList()) v[w] = v[w]!! / r }
            v
        }
    }

    internal fun cosine(a: Map<String, Double>, b: Map<String, Double>): Double {
        val (small, big) = if (a.size <= b.size) Pair(a, b) else Pair(b, a)
        var s = 0.0
        for ((w, x) in small) { val y = big[w]; if (y != null) s += x * y }
        return s
    }

    /** PageRank (damping [alpha]) of a weighted graph given as a matrix `w[i][j]` = weight of the edge i -> j; a node with no outgoing weight shares its rank with everybody. */
    internal fun pageRank(w: Array<DoubleArray>, alpha: Double = 0.85): DoubleArray {
        val n = w.size
        if (n == 0) return DoubleArray(0)
        val out = DoubleArray(n) { i -> w[i].sum() }
        var r = DoubleArray(n) { 1.0 / n }
        for (iter in 0 until 200) {
            var dangling = 0.0
            for (i in 0 until n) if (out[i] == 0.0) dangling += r[i]
            val next = DoubleArray(n)
            for (j in 0 until n) {
                var s = 0.0
                for (i in 0 until n) if (out[i] > 0.0) s += r[i] * w[i][j] / out[i]
                next[j] = (1.0 - alpha) / n + alpha * (s + dangling / n)
            }
            var diff = 0.0
            for (i in 0 until n) diff += abs(next[i] - r[i])
            r = next
            if (diff < 1e-10) break
        }
        return r
    }

    /** The sentences of [text] that can stand in a summary (30-400 characters, at least 4 real words). */
    internal fun candidateSentences(text: String): List<String> =
        sentences(text).filter { s -> s.length in MIN_SENTENCE..MAX_SENTENCE && tokenize(s).count { it.text.length >= 2 && it.text !in STOP } >= 4 }.take(MAX_SENTENCES)

    /** Scores of the candidate sentences (their PageRank in the TF-IDF cosine graph). */
    internal fun sentenceScores(cands: List<String>): DoubleArray {
        val vec = sentenceVectors(cands)
        val n = cands.size
        val w = Array(n) { DoubleArray(n) }
        for (i in 0 until n) for (j in i + 1 until n) { val c = cosine(vec[i], vec[j]); w[i][j] = c; w[j][i] = c }
        return pageRank(w)
    }

    /** At most [maxSentences] sentences, the highest ranked, in the order they appear in [text]. Fewer candidates than that: all of them. */
    fun summary(text: String, maxSentences: Int = 3): List<String> {
        val cands = candidateSentences(text)
        if (cands.size <= maxSentences) return cands
        val score = sentenceScores(cands)
        val top = cands.indices.sortedWith(compareBy({ -score[it] }, { it })).take(maxSentences).sorted()
        return top.map { cands[it] }
    }
}
