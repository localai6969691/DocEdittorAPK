package com.example.docscanner.util

import java.io.File
import java.util.zip.CRC32

/**
 * Highlights, bookmarks and the reading position of ONE EPUB (PDF list C5 "reader" and C6 "highlight / bookmark"; session 23, 4.50).
 *
 * Everything here is plain Kotlin on strings and numbers (no Android classes), so it is mirrored line by line by tools/verify/EpubNotesCheck.java and
 * compared with an independent per-character-mask model in epub_notes_check.py.
 *
 * Where a note points: (chapter, paragraph) = the same indices that [EpubReader.read] and [EpubSearch] use; a highlight adds [start, end) in UTF-16 units
 * of that paragraph's text. Offsets only mean something for the SAME text, so the file starts with a [fingerprint] of the whole book; when the book was
 * changed (split, merged, re-exported) the old notes are set aside instead of being drawn on the wrong words.
 *
 * Rules (each one is tested):
 *  - a new highlight is trimmed of white space at both ends, never cuts an emoji / surrogate pair in half, and is merged with every highlight of the same
 *    paragraph it overlaps OR touches, so the list never holds two neighbouring pieces;
 *  - erasing cuts the covered part out of any highlight (a highlight that contains the erased range is split in two);
 *  - bookmarks are a set of places: marking the same place again removes it;
 *  - the file is text, one note per line, and reading it never throws: a damaged line is skipped, a note outside the book is dropped.
 */
object EpubNotes {

    const val MAX_NOTES = 5000
    private const val HEADER = "DOCSCANNER-EPUB-NOTES 1"

    class Mark(val chapter: Int, val paragraph: Int, val start: Int, val end: Int)
    class Place(val chapter: Int, val paragraph: Int)

    /** [stale] = a notes file existed but belonged to a different version of the book (it was set aside, this object is empty). */
    class Notes(val highlights: List<Mark>, val bookmarks: List<Place>, val last: Place?, val stale: Boolean = false)

    val EMPTY = Notes(emptyList(), emptyList(), null)

    private fun isSpace(c: Char): Boolean = Character.isWhitespace(c) || Character.isSpaceChar(c)

    private val markOrder = Comparator<Mark> { a, b ->
        if (a.chapter != b.chapter) a.chapter.compareTo(b.chapter)
        else if (a.paragraph != b.paragraph) a.paragraph.compareTo(b.paragraph)
        else a.start.compareTo(b.start)
    }

    private val placeOrder = Comparator<Place> { a, b ->
        if (a.chapter != b.chapter) a.chapter.compareTo(b.chapter) else a.paragraph.compareTo(b.paragraph)
    }

    // ---------------------------------------------------------------------------------------
    // Fingerprint of the book text
    // ---------------------------------------------------------------------------------------

    private fun putInt(crc: CRC32, v: Int) {
        crc.update((v ushr 24) and 0xFF); crc.update((v ushr 16) and 0xFF); crc.update((v ushr 8) and 0xFF); crc.update(v and 0xFF)
    }

    /**
     * CRC-32 over the chapter structure and every paragraph's UTF-8 bytes (each with its length in front, so moving a paragraph or a chapter boundary
     * changes it), then "-" and the paragraph count. [chapters] = the paragraphs of each chapter, in reading order.
     */
    fun fingerprint(chapters: List<List<String>>): String {
        val crc = CRC32()
        var count = 0
        for (chapter in chapters) {
            crc.update(1)
            putInt(crc, chapter.size)
            for (p in chapter) {
                val b = p.toByteArray(Charsets.UTF_8)
                putInt(crc, b.size)
                crc.update(b, 0, b.size)
                count++
            }
        }
        return String.format("%08x", crc.value) + "-" + count
    }

    // ---------------------------------------------------------------------------------------
    // Highlights
    // ---------------------------------------------------------------------------------------

    /** Moves [start] / [end] outward so that neither one falls between the two halves of a surrogate pair. Both are first clamped to the text. */
    private fun snap(text: String, start: Int, end: Int): IntArray {
        var s = start.coerceIn(0, text.length)
        var e = end.coerceIn(0, text.length)
        if (s > 0 && s < text.length && Character.isLowSurrogate(text[s]) && Character.isHighSurrogate(text[s - 1])) s--
        if (e > 0 && e < text.length && Character.isLowSurrogate(text[e]) && Character.isHighSurrogate(text[e - 1])) e++
        return intArrayOf(s, e)
    }

    /**
     * Adds the highlight [start, end) of [text] (the paragraph (chapter, paragraph)). A selection that is only white space adds nothing.
     * Returns a NEW list sorted by chapter, paragraph, start; the cap [MAX_NOTES] keeps a runaway file small (a new piece is refused past it).
     */
    fun addHighlight(list: List<Mark>, chapter: Int, paragraph: Int, text: String, start: Int, end: Int): List<Mark> {
        val se = snap(text, minOf(start, end), maxOf(start, end))
        var s = se[0]
        var e = se[1]
        while (s < e && isSpace(text[s])) s++
        while (e > s && isSpace(text[e - 1])) e--
        if (s >= e) return list
        val out = ArrayList<Mark>(list.size + 1)
        var ns = s
        var ne = e
        var merged = false
        for (m in list) {
            if (m.chapter == chapter && m.paragraph == paragraph && m.start <= ne && m.end >= ns) {
                ns = minOf(ns, m.start); ne = maxOf(ne, m.end); merged = true
            } else out.add(m)
        }
        if (!merged && out.size >= MAX_NOTES) return list
        out.add(Mark(chapter, paragraph, ns, ne))
        out.sortWith(markOrder)
        return out
    }

    /** Removes the part [start, end) of [text] from the highlights of that paragraph (a highlight is cut, split in two, or removed whole). */
    fun eraseHighlight(list: List<Mark>, chapter: Int, paragraph: Int, text: String, start: Int, end: Int): List<Mark> {
        val se = snap(text, minOf(start, end), maxOf(start, end))
        val s = se[0]
        val e = se[1]
        if (s >= e) return list
        val out = ArrayList<Mark>(list.size + 1)
        for (m in list) {
            if (m.chapter != chapter || m.paragraph != paragraph || m.end <= s || m.start >= e) { out.add(m); continue }
            if (m.start < s) out.add(Mark(chapter, paragraph, m.start, s))
            if (m.end > e) out.add(Mark(chapter, paragraph, e, m.end))
        }
        out.sortWith(markOrder)
        return out
    }

    /** Removes the whole highlight [mark] (the "hold to remove" entry of the list). Compared by position, not by object. */
    fun removeHighlight(list: List<Mark>, mark: Mark): List<Mark> =
        list.filterNot { it.chapter == mark.chapter && it.paragraph == mark.paragraph && it.start == mark.start && it.end == mark.end }

    // ---------------------------------------------------------------------------------------
    // Bookmarks
    // ---------------------------------------------------------------------------------------

    fun hasBookmark(list: List<Place>, chapter: Int, paragraph: Int): Boolean = list.any { it.chapter == chapter && it.paragraph == paragraph }

    /** Marks the place, or un-marks it when it is already marked. Returns a new list sorted in reading order. */
    fun toggleBookmark(list: List<Place>, chapter: Int, paragraph: Int): List<Place> {
        if (hasBookmark(list, chapter, paragraph)) return list.filterNot { it.chapter == chapter && it.paragraph == paragraph }
        if (list.size >= MAX_NOTES) return list
        val out = ArrayList(list)
        out.add(Place(chapter, paragraph))
        out.sortWith(placeOrder)
        return out
    }

    /** The highlights of every paragraph in one pass, so drawing a page does not scan the whole list for each paragraph. Key = [key]. */
    fun index(list: List<Mark>): HashMap<Long, List<Mark>> {
        val map = HashMap<Long, ArrayList<Mark>>()
        for (m in list) map.getOrPut(key(m.chapter, m.paragraph)) { ArrayList() }.add(m)
        val out = HashMap<Long, List<Mark>>(map.size * 2)
        for ((k, v) in map) out[k] = v
        return out
    }

    fun key(chapter: Int, paragraph: Int): Long = chapter.toLong() * 1_000_000L + paragraph

    // ---------------------------------------------------------------------------------------
    // Text form (what is stored)
    // ---------------------------------------------------------------------------------------

    fun encode(fingerprint: String, notes: Notes): String {
        val sb = StringBuilder(HEADER).append('\n').append("F ").append(fingerprint).append('\n')
        notes.last?.let { sb.append("L ").append(it.chapter).append(' ').append(it.paragraph).append('\n') }
        for (b in notes.bookmarks) sb.append("B ").append(b.chapter).append(' ').append(b.paragraph).append('\n')
        for (h in notes.highlights) sb.append("H ").append(h.chapter).append(' ').append(h.paragraph).append(' ').append(h.start).append(' ').append(h.end).append('\n')
        return sb.toString()
    }

    private fun ints(parts: List<String>, from: Int, count: Int): IntArray? {
        if (parts.size != from + count) return null
        val r = IntArray(count)
        for (i in 0 until count) {
            val v = parts[from + i].toIntOrNull() ?: return null
            if (v < 0) return null
            r[i] = v
        }
        return r
    }

    /**
     * Reads the stored text for a book whose fingerprint is [fingerprint] and whose paragraphs are [chapters]. Never throws.
     * A missing / foreign header -> EMPTY; a different fingerprint -> EMPTY with stale = true; lines that do not parse are skipped; notes pointing outside
     * the book are dropped and highlight ends are clamped to the paragraph; duplicates and overlaps are merged exactly like [addHighlight] would.
     */
    fun decode(text: String, fingerprint: String, chapters: List<List<String>>): Notes {
        val lines = text.split('\n')
        if (lines.isEmpty() || lines[0].trim() != HEADER) return EMPTY
        var fp: String? = null
        for (l in lines) if (l.startsWith("F ")) { fp = l.substring(2).trim(); break }
        if (fp == null) return EMPTY
        if (fp != fingerprint) return Notes(emptyList(), emptyList(), null, true)
        var highlights: List<Mark> = emptyList()
        var bookmarks: List<Place> = emptyList()
        var last: Place? = null
        for (raw in lines.drop(1)) {
            val line = raw.trim()
            if (line.length < 3) continue
            val parts = line.split(' ')
            if (parts[0] == "L") {
                val v = ints(parts, 1, 2)
                if (v != null && v[0] < chapters.size && v[1] < chapters[v[0]].size) last = Place(v[0], v[1])
            } else if (parts[0] == "B") {
                val v = ints(parts, 1, 2)
                if (v != null && v[0] < chapters.size && v[1] < chapters[v[0]].size && !hasBookmark(bookmarks, v[0], v[1])) {
                    bookmarks = toggleBookmark(bookmarks, v[0], v[1])
                }
            } else if (parts[0] == "H") {
                val v = ints(parts, 1, 4)
                if (v != null && v[0] < chapters.size && v[1] < chapters[v[0]].size) {
                    val p = chapters[v[0]][v[1]]
                    val e = minOf(v[3], p.length)
                    if (v[2] < e) highlights = addHighlight(highlights, v[0], v[1], p, v[2], e)
                }
            }
        }
        return Notes(highlights, bookmarks, last)
    }

    // ---------------------------------------------------------------------------------------
    // Files
    // ---------------------------------------------------------------------------------------

    /** `<dir>/<epub file name with / \ : replaced>.notes` - the folder is private to the app. */
    fun fileFor(dir: File, epub: File): File {
        val safe = epub.name.map { if (it == '/' || it == '\\' || it == ':' || it.code < 32) '_' else it }.joinToString("")
        return File(dir, safe.take(150) + ".notes")
    }

    /** Written to a temporary file first and renamed, so a crash in the middle never leaves a half-written file behind the real one. */
    fun save(file: File, fingerprint: String, notes: Notes): Boolean = try {
        file.parentFile?.mkdirs()
        val tmp = File(file.path + ".tmp")
        tmp.writeText(encode(fingerprint, notes), Charsets.UTF_8)
        if (file.exists() && !file.delete()) { tmp.delete(); false }
        else if (!tmp.renameTo(file)) { tmp.delete(); false }
        else true
    } catch (e: Exception) { false }

    /** Reads [file]; a notes file of another version of the book is renamed to `.stale` (kept, not deleted) and an empty set with stale = true returned. */
    fun load(file: File, fingerprint: String, chapters: List<List<String>>): Notes {
        if (!file.isFile) return EMPTY
        val text = try { file.readText(Charsets.UTF_8) } catch (e: Exception) { return EMPTY }
        val notes = decode(text, fingerprint, chapters)
        if (notes.stale) {
            val aside = File(file.path + ".stale")
            if (aside.exists()) aside.delete()
            file.renameTo(aside)
        }
        return notes
    }

    // ---------------------------------------------------------------------------------------
    // Text for the person
    // ---------------------------------------------------------------------------------------

    /** The first [max] characters, with an ellipsis when cut, never in the middle of a surrogate pair; line breaks and runs of spaces become one space. */
    fun snippet(text: String, max: Int): String {
        val sb = StringBuilder()
        var lastSpace = true
        for (c in text) {
            if (isSpace(c)) { if (!lastSpace) sb.append(' '); lastSpace = true } else { sb.append(c); lastSpace = false }
        }
        var s = sb.toString().trim()
        if (s.length <= max) return s
        var cut = max
        if (cut > 0 && Character.isLowSurrogate(s[cut]) && Character.isHighSurrogate(s[cut - 1])) cut--
        s = s.substring(0, cut).trimEnd()
        return "$s…"
    }

    /**
     * What "Copy notes" puts on the clipboard: [header], then the bookmarks (chapter label + the first words of the paragraph), then the highlights
     * (chapter label + the highlighted words). [paragraphs] = the book's paragraphs; [titles] = chapter titles. A section with nothing in it is left out.
     */
    fun render(
        paragraphs: List<List<String>>, titles: List<String>, notes: Notes, header: String, bookmarksHead: String, highlightsHead: String,
        chapterLabel: (Int, String) -> String
    ): String {
        val sb = StringBuilder(header).append('\n')
        if (notes.bookmarks.isNotEmpty()) {
            sb.append('\n').append(bookmarksHead).append('\n')
            for (b in notes.bookmarks) {
                if (b.chapter >= paragraphs.size || b.paragraph >= paragraphs[b.chapter].size) continue
                sb.append("• ").append(chapterLabel(b.chapter + 1, titles.getOrElse(b.chapter) { "" }.trim())).append(": ")
                    .append(snippet(paragraphs[b.chapter][b.paragraph], 120)).append('\n')
            }
        }
        if (notes.highlights.isNotEmpty()) {
            sb.append('\n').append(highlightsHead).append('\n')
            for (h in notes.highlights) {
                if (h.chapter >= paragraphs.size || h.paragraph >= paragraphs[h.chapter].size) continue
                val p = paragraphs[h.chapter][h.paragraph]
                val e = minOf(h.end, p.length)
                if (h.start >= e) continue
                sb.append("• ").append(chapterLabel(h.chapter + 1, titles.getOrElse(h.chapter) { "" }.trim())).append(": ")
                    .append(snippet(p.substring(h.start, e), 400)).append('\n')
            }
        }
        return sb.toString()
    }
}
