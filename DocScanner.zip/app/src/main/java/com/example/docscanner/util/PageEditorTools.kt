package com.example.docscanner.util

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import androidx.annotation.StringRes
import com.example.docscanner.R
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Page operations of the "Quản lý trang PDF" screen that the first version lacked: duplicate a page, insert a blank page, crop
 * the margins, change the paper size. That screen holds every page as a JPEG rendered at [DPI] (see
 * `PdfPageEditorActivity.loadPdf`) and writes the PDF back from those images, so each operation here is an image operation that
 * produces a NEW file; a page's pending rotation is baked in first so the result always has rotation 0.
 *
 * Nothing here throws: a failure returns false / null and the caller leaves the page as it was.
 */
object PageEditorTools {

    /** Resolution of the page images of the editor (must match `sourceDpi` given to `PdfExporter.exportImagePaths`). */
    const val DPI = 200

    enum class Paper(val widthMm: Float, val heightMm: Float, @StringRes val labelRes: Int) {
        A4(210f, 297f, R.string.paper_a4),
        A5(148f, 210f, R.string.paper_a5),
        A3(297f, 420f, R.string.paper_a3),
        LETTER(215.9f, 279.4f, R.string.paper_letter),
        LEGAL(215.9f, 355.6f, R.string.paper_legal);

        /** Portrait size in pixels at [DPI]. */
        fun portraitPixels(): Pair<Int, Int> =
            Pair((widthMm / 25.4f * DPI).roundToInt(), (heightMm / 25.4f * DPI).roundToInt())
    }

    /** A copy of the page file; the caller copies the rotation onto the new item. */
    fun duplicate(path: String, out: File): Boolean = try {
        File(path).copyTo(out, overwrite = true)
        true
    } catch (e: Exception) {
        false
    }

    /**
     * A white page the same size as the reference page as it will appear (rotation applied), so a blank page inserted in a
     * landscape document is landscape too; A4 portrait when there is no reference.
     */
    fun blankPage(referencePath: String?, referenceRotation: Int, out: File): Boolean = try {
        var (w, h) = Paper.A4.portraitPixels()
        if (referencePath != null) {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(referencePath, bounds)
            if (bounds.outWidth > 0 && bounds.outHeight > 0) {
                val quarter = referenceRotation % 180 != 0
                w = if (quarter) bounds.outHeight else bounds.outWidth
                h = if (quarter) bounds.outWidth else bounds.outHeight
            }
        }
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(Color.WHITE)
        save(bitmap, out)
    } catch (e: Exception) {
        false
    }

    /** Cuts [leftPct], [topPct], [rightPct], [bottomPct] percent of the page's width/height off the respective edge. */
    fun crop(path: String, rotation: Int, leftPct: Float, topPct: Float, rightPct: Float, bottomPct: Float, out: File): Boolean = try {
        val page = decodeRotated(path, rotation)
        if (page == null) {
            false
        } else {
            val rect = cropRect(page.width, page.height, leftPct, topPct, rightPct, bottomPct)
            val cropped = Bitmap.createBitmap(page.bitmap(), rect.left, rect.top, rect.width(), rect.height())
            if (cropped !== page.bitmap()) page.bitmap().recycle()
            save(cropped, out)
        }
    } catch (e: Exception) {
        false
    }

    /**
     * Puts the page on a [paper]-sized white canvas (landscape when the page is), scaled to fit and centred - no part of the page is
     * cut off and the aspect ratio is kept.
     */
    fun fitToPaper(path: String, rotation: Int, paper: Paper, out: File): Boolean = try {
        val page = decodeRotated(path, rotation)
        if (page == null) {
            false
        } else {
            val bmp = page.bitmap()
            val (pw, ph) = paper.portraitPixels()
            val landscape = bmp.width > bmp.height
            val canvasW = if (landscape) ph else pw
            val canvasH = if (landscape) pw else ph
            val target = Bitmap.createBitmap(canvasW, canvasH, Bitmap.Config.ARGB_8888)
            target.eraseColor(Color.WHITE)
            val dest = fitRect(bmp.width, bmp.height, canvasW, canvasH)
            Canvas(target).drawBitmap(bmp, null, dest, Paint(Paint.FILTER_BITMAP_FLAG))
            bmp.recycle()
            save(target, out)
        }
    } catch (e: Exception) {
        false
    }

    // ---- pure geometry (no Android classes except the tiny Rect/RectF holders), checked by tools/verify/page_tools_check.py ----

    /** Pixel rectangle that remains after cutting the percentages off; always at least 1 x 1, and the percentages are clamped to 0..45. */
    fun cropRect(width: Int, height: Int, leftPct: Float, topPct: Float, rightPct: Float, bottomPct: Float): Rect {
        fun pct(v: Float) = min(45f, max(0f, v))
        val left = (width * pct(leftPct) / 100f).toInt()
        val top = (height * pct(topPct) / 100f).toInt()
        val right = (width * pct(rightPct) / 100f).toInt()
        val bottom = (height * pct(bottomPct) / 100f).toInt()
        val w = max(1, width - left - right)
        val h = max(1, height - top - bottom)
        return Rect(left, top, left + w, top + h)
    }

    /** Largest rectangle with the source's aspect ratio that fits inside the canvas, centred. */
    fun fitRect(srcW: Int, srcH: Int, canvasW: Int, canvasH: Int): RectF {
        val scale = min(canvasW.toFloat() / srcW, canvasH.toFloat() / srcH)
        val w = srcW * scale
        val h = srcH * scale
        val x = (canvasW - w) / 2f
        val y = (canvasH - h) / 2f
        return RectF(x, y, x + w, y + h)
    }

    // ---- helpers ----

    private class Decoded(private val bmp: Bitmap) {
        val width: Int get() = bmp.width
        val height: Int get() = bmp.height
        fun bitmap(): Bitmap = bmp
    }

    private fun decodeRotated(path: String, rotation: Int): Decoded? {
        val decoded = BitmapFactory.decodeFile(path) ?: return null
        if (rotation % 360 == 0) return Decoded(decoded)
        val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
        val rotated = Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, matrix, true)
        if (rotated !== decoded) decoded.recycle()
        return Decoded(rotated)
    }

    private fun save(bitmap: Bitmap, out: File): Boolean {
        FileOutputStream(out).use { stream -> bitmap.compress(Bitmap.CompressFormat.JPEG, 92, stream) }
        bitmap.recycle()
        return true
    }
}
