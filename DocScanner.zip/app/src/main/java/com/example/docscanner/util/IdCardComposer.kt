package com.example.docscanner.util

import android.graphics.Bitmap
import android.graphics.Matrix
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageContentStream
import com.tom_roush.pdfbox.pdmodel.common.PDRectangle
import com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
import java.io.File

/**
 * "Ghép thẻ lên A4": photographs of the front (and back) of a card - citizen ID, driving licence, bank or health-insurance
 * card, a passport data page - are cut out, straightened, and placed on ONE A4 page at the card's REAL size, centred,
 * like a photocopy. This is what offices ask for ("photo CCCD hai mặt trên một trang").
 *
 * Per card ([prepare]): find the card's four corners with the document detector, flatten it, turn it upright (the text
 * says which way is up; when it cannot tell, the screen asks the user and offers a half turn), and crop the few pixels that
 * do not fit the card's proportions - then scale to 300 dpi at the real size. When no rectangle is found (a card filling
 * the whole photo, or on a busy background) the centre of the photo is cropped to the card's proportions instead.
 *
 * The page layout ([layout], [cardSize], [cropToAspect]) is pure and mirrored in tools/verify/idcard_check.py, which
 * renders it with poppler.
 */
object IdCardComposer {

    /** Real card sizes in millimetres. [ID1] is ISO/IEC 7810 ID-1 (CCCD, GPLX, bank and BHYT cards); [ID3] is a passport data page. */
    enum class Preset(val widthMm: Float, val heightMm: Float) {
        ID1(85.6f, 53.98f),
        ID3(125f, 88f)
    }

    const val A4_WIDTH = 595.276f
    const val A4_HEIGHT = 841.89f
    private const val MM_TO_PT = 72f / 25.4f
    private const val RENDER_DPI = 300f
    /** Space between the front and the back of the card on the page, in points (about 10 mm). */
    const val GAP_PT = 28f

    /** (width, height) of a landscape card in PDF points. */
    fun cardSize(preset: Preset): Pair<Float, Float> = Pair(preset.widthMm * MM_TO_PT, preset.heightMm * MM_TO_PT)

    /** `[x, y, w, h]` (origin bottom-left) of each of [count] cards: one column, centred horizontally, the block centred vertically. */
    fun layout(count: Int, cardW: Float, cardH: Float, pageW: Float = A4_WIDTH, pageH: Float = A4_HEIGHT): List<FloatArray> {
        val total = count * cardH + (count - 1).coerceAtLeast(0) * GAP_PT
        val top = pageH - (pageH - total) / 2f
        val x = (pageW - cardW) / 2f
        return (0 until count).map { i -> floatArrayOf(x, top - (i + 1) * cardH - i * GAP_PT, cardW, cardH) }
    }

    /** Largest centred rectangle of proportions [aspect] (width / height) inside a [w] x [h] image: `[x, y, width, height]`. */
    fun cropToAspect(w: Int, h: Int, aspect: Float): IntArray {
        val current = w.toFloat() / h
        return if (current > aspect) {
            val nw = (h * aspect).toInt().coerceIn(1, w)
            intArrayOf((w - nw) / 2, 0, nw, h)
        } else {
            val nh = (w / aspect).toInt().coerceIn(1, h)
            intArrayOf(0, (h - nh) / 2, w, nh)
        }
    }

    /** A card ready for the page. [orientationKnown] is false when the text could not tell which way is up. */
    class Prepared(val bitmap: Bitmap, val orientationKnown: Boolean)

    private fun rotated(src: Bitmap, degreesClockwise: Float): Bitmap {
        if (degreesClockwise % 360f == 0f) return src
        val m = Matrix().apply { postRotate(degreesClockwise) }
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    /**
     * Cut out, flatten, turn upright, fit to the card's proportions and scale to 300 dpi at real size.
     *
     * Which way is up: the text decides ([PageOrientation.detectCcwDegrees], the detector the page-scanning flow uses; on 192
     * synthetic card photos in all four turns it was right 126 times, declined 66 times and never wrong - see
     * tools/verify/card_orientation_check.py). When it declines, the card is only made landscape and [Prepared.orientationKnown]
     * is false, so the caller can ask the user and call again with [flip180] - a half turn is the only thing a landscape
     * card can still be wrong by.
     */
    fun prepare(source: Bitmap, preset: Preset, flip180: Boolean = false): Prepared {
        val quad = ImageProcessor.detectDocumentCorners(source)
        val flat = if (quad != null) ImageProcessor.warpDocument(source, quad) else source
        val ccw = PageOrientation.detectCcwDegrees(flat)
        var known = false
        var upright = flat
        if (ccw != null) {
            upright = rotated(flat, -ccw.toFloat())
            known = upright.width >= upright.height     // an upright card is landscape; anything else contradicts the detector
        }
        if (upright.height > upright.width) {
            upright = rotated(upright, 90f)
            known = false
        }
        if (flip180) upright = rotated(upright, 180f)
        val aspect = preset.widthMm / preset.heightMm
        val r = cropToAspect(upright.width, upright.height, aspect)
        val cropped = Bitmap.createBitmap(upright, r[0], r[1], r[2], r[3])
        val targetW = (preset.widthMm / 25.4f * RENDER_DPI).toInt()
        val targetH = (preset.heightMm / 25.4f * RENDER_DPI).toInt()
        val result = Bitmap.createScaledBitmap(cropped, targetW, targetH, true)
        if (cropped !== result && cropped !== upright) cropped.recycle()
        if (upright !== flat && upright !== result && upright !== cropped) upright.recycle()
        if (flat !== source && flat !== result) flat.recycle()
        return Prepared(result, known)
    }

    /** Writes the already-prepared [cards] (1 or 2) onto one A4 page. Writes a NEW file. */
    fun compose(cards: List<Bitmap>, preset: Preset, out: File) {
        require(cards.isNotEmpty()) { "no card" }
        val (cw, ch) = cardSize(preset)
        val cells = layout(cards.size, cw, ch)
        val doc = PDDocument()
        try {
            val page = PDPage(PDRectangle(A4_WIDTH, A4_HEIGHT))
            doc.addPage(page)
            PDPageContentStream(doc, page).use { cs ->
                for ((i, bmp) in cards.withIndex()) {
                    val c = cells[i]
                    cs.drawImage(LosslessFactory.createFromImage(doc, bmp), c[0], c[1], c[2], c[3])
                    // a hairline edge, as a photocopy shows the card's border
                    cs.setStrokingColor(0.6f, 0.6f, 0.6f)
                    cs.setLineWidth(0.5f)
                    cs.addRect(c[0], c[1], c[2], c[3])
                    cs.stroke()
                }
            }
            PdfStructureOptimizer.save(doc, out)
            if (!PdfVerify.opensAsPdf(out, 1)) {
                runCatching { out.delete() }
                throw IllegalStateException("output failed verification")
            }
        } finally {
            runCatching { doc.close() }
        }
    }
}
