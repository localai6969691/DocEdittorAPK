package com.example.docscanner.util

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.multipdf.PDFMergerUtility
import com.tom_roush.pdfbox.multipdf.Splitter
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.destination.PDPageFitDestination
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.outline.PDDocumentOutline
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineItem
import com.tom_roush.pdfbox.pdmodel.interactive.documentnavigation.outline.PDOutlineNode
import java.io.File

/**
 * PDF bookmarks (the outline / "mục lục" of a PDF): read them, SPLIT a PDF at its bookmarks, and MERGE PDFs while keeping text, quality and a combined outline
 * (phiên 17, mục 4.32; items B3 / B14 / B15 of the PDF "Thiếu gì để bán app"). Before this the app's merge rasterized every page - the text layer, the vector quality and any
 * bookmarks were lost and the file grew several times over - and there was no way to split a book by chapter.
 *
 * The planning is PURE ([Entry] lists in, [Section]s / merged [Entry] lists out) and is mirrored in tools/verify/BookmarksCheck.java; tools/verify/bookmarks_check.py checks it
 * end to end against an independent implementation (pikepdf + pdftotext: every part holds exactly its chapter's pages, every merged bookmark lands on the page it names).
 * The PdfBox calls follow the documented API (PDDocumentOutline / PDOutlineItem.findDestinationPage / PDPageFitDestination; multipdf.Splitter; PDFMergerUtility.appendDocument):
 * `Splitter` and `appendDocument` clone pages with their annotations and resources properly, which is why they are used instead of `importPage`. Source documents stay open until
 * the result is saved (the clones may still read their streams).
 *
 * Levels: 1 = top level of the outline. [normalizeLevels] repairs odd outlines (a first entry below level 1, a jump of two levels) the way readers show them.
 * An entry whose destination cannot be resolved to a page (a broken named destination) has page -1 and is ignored everywhere.
 */
object PdfBookmarks {

    class Entry(val title: String, val level: Int, val page: Int)

    /** A chapter: pages [first]..[last] inclusive (0-based). */
    class Section(val title: String, val first: Int, val last: Int)

    class SourceOutline(val name: String, val pageCount: Int, val entries: List<Entry>)

    // ---------------------------------------------------------------- pure planning

    /** Levels < 1 become 1; each level is at most one deeper than the previous entry; the first entry is level 1. */
    fun normalizeLevels(entries: List<Entry>): List<Entry> {
        val out = ArrayList<Entry>(entries.size)
        var prev = 0
        for (e in entries) {
            val level = e.level.coerceAtLeast(1).coerceAtMost(prev + 1)
            out.add(Entry(e.title, level, e.page))
            prev = level
        }
        return out
    }

    /** Deepest level that has at least one usable entry (0 when there is none). */
    fun maxLevel(entries: List<Entry>, pageCount: Int): Int =
        normalizeLevels(entries).filter { it.page in 0 until pageCount }.maxOfOrNull { it.level } ?: 0

    /**
     * Chapters for splitting at bookmarks of exactly [level]: the entries of that level, in order of page; entries that start on the same page count once (the first wins);
     * each chapter runs to the page before the next one starts, the last to the end. Pages before the first chapter form a preface section (titled [prefaceTitle]) when
     * [includePreface] is set; otherwise they are left out. Entries without a valid page are ignored.
     */
    fun sections(entries: List<Entry>, pageCount: Int, level: Int, includePreface: Boolean, prefaceTitle: String): List<Section> {
        val starts = normalizeLevels(entries).filter { it.level == level && it.page in 0 until pageCount }
            .withIndex().sortedWith(compareBy({ it.value.page }, { it.index })).map { it.value }
        val distinct = ArrayList<Entry>()
        for (e in starts) if (distinct.isEmpty() || distinct.last().page != e.page) distinct.add(e)
        val out = ArrayList<Section>()
        if (distinct.isEmpty()) return out
        if (includePreface && distinct.first().page > 0) out.add(Section(prefaceTitle, 0, distinct.first().page - 1))
        for ((i, e) in distinct.withIndex()) out.add(Section(e.title, e.page, if (i + 1 < distinct.size) distinct[i + 1].page - 1 else pageCount - 1))
        return out
    }

    /** The bookmarks that belong INSIDE [section] (pages within it, level >= [level]), re-based for a part that starts at its first page: levels start at 1 again. */
    fun entriesForPart(entries: List<Entry>, section: Section, level: Int): List<Entry> =
        normalizeLevels(entries).filter { it.page in section.first..section.last && it.level >= level }
            .map { Entry(it.title, it.level - level + 1, it.page - section.first) }

    /**
     * The outline of several PDFs merged in the given order: one top-level bookmark per file (named after the file, pointing at its first page) holding that file's own
     * bookmarks one level deeper, all pages shifted by the pages of the files before it. Entries without a valid page are dropped.
     */
    fun mergedOutline(sources: List<SourceOutline>): List<Entry> {
        val out = ArrayList<Entry>()
        var offset = 0
        for (s in sources) {
            if (s.pageCount > 0) {
                out.add(Entry(s.name, 1, offset))
                for (e in normalizeLevels(s.entries).filter { it.page in 0 until s.pageCount }) out.add(Entry(e.title, e.level + 1, e.page + offset))
            }
            offset += s.pageCount
        }
        return out
    }

    // ---------------------------------------------------------------- editing (pure; indices refer to the list AFTER [normalizeLevels], which is what the editor shows)

    /** Removes the entry at [index] together with all its descendants (the entries right after it that are deeper). */
    fun delete(entries: List<Entry>, index: Int): List<Entry> {
        val norm = normalizeLevels(entries)
        if (index !in norm.indices) return norm
        var end = index + 1
        while (end < norm.size && norm[end].level > norm[index].level) end++
        return normalizeLevels(norm.subList(0, index) + norm.subList(end, norm.size))
    }

    /** Gives the entry at [index] a new title (trimmed; a blank title leaves the list unchanged). */
    fun rename(entries: List<Entry>, index: Int, title: String): List<Entry> {
        val norm = normalizeLevels(entries)
        val t = title.trim()
        if (index !in norm.indices || t.isEmpty()) return norm
        return norm.mapIndexed { i, e -> if (i == index) Entry(t, e.level, e.page) else e }
    }

    /**
     * Adds a bookmark ([title], 0-based [page], wanted [level]) at its natural place: right after the last existing entry that starts on [page] or earlier (before everything if there
     * is none), so the list stays in page order; the level is then repaired by [normalizeLevels] (it can never be deeper than the entry before it allows). A blank title or a page
     * outside the document ([pageCount]) leaves the list unchanged.
     */
    fun insert(entries: List<Entry>, title: String, page: Int, level: Int, pageCount: Int): List<Entry> {
        val norm = normalizeLevels(entries)
        val t = title.trim()
        if (t.isEmpty() || page !in 0 until pageCount) return norm
        var at = 0
        for ((i, e) in norm.withIndex()) if (e.page <= page) at = i + 1
        return normalizeLevels(norm.subList(0, at) + Entry(t, level.coerceAtLeast(1), page) + norm.subList(at, norm.size))
    }

    // ---------------------------------------------------------------- moving and re-levelling (phiên 19, mục 4.47; the "move / change level" item that 4.34 left open)

    /** One past the last entry of the BLOCK that starts at [index]: the entry and all its descendants (the entries right after it that are deeper). [norm] must be normalized. */
    private fun blockEnd(norm: List<Entry>, index: Int): Int {
        var end = index + 1
        while (end < norm.size && norm[end].level > norm[index].level) end++
        return end
    }

    /** Start of the PREVIOUS SIBLING of the entry at [index] (same parent), or -1 when it is the first child of its parent. [norm] must be normalized. */
    private fun previousSibling(norm: List<Entry>, index: Int): Int {
        val level = norm[index].level
        var j = index - 1
        while (j >= 0 && norm[j].level > level) j--
        return if (j >= 0 && norm[j].level == level) j else -1
    }

    /** Start of the NEXT SIBLING of the entry at [index] (same parent), or -1 when it is the last child of its parent. [norm] must be normalized. */
    private fun nextSibling(norm: List<Entry>, index: Int): Int {
        val end = blockEnd(norm, index)
        return if (end < norm.size && norm[end].level == norm[index].level) end else -1
    }

    /** True when [moveUp] would do something (the entry has a previous sibling). Compare with this, not with `!=` on the lists: [Entry] is not a data class. */
    fun canMoveUp(entries: List<Entry>, index: Int): Boolean {
        val norm = normalizeLevels(entries)
        return index in norm.indices && previousSibling(norm, index) >= 0
    }

    /** True when [moveDown] would do something (the entry has a next sibling). */
    fun canMoveDown(entries: List<Entry>, index: Int): Boolean {
        val norm = normalizeLevels(entries)
        return index in norm.indices && nextSibling(norm, index) >= 0
    }

    /** Swaps the block at [index] with the block of its PREVIOUS SIBLING (same parent). Unchanged when there is no previous sibling (first child, or [index] out of range). */
    fun moveUp(entries: List<Entry>, index: Int): List<Entry> {
        val norm = normalizeLevels(entries)
        if (index !in norm.indices) return norm
        val j = previousSibling(norm, index)
        if (j < 0) return norm
        val end = blockEnd(norm, index)
        return normalizeLevels(norm.subList(0, j) + norm.subList(index, end) + norm.subList(j, index) + norm.subList(end, norm.size))
    }

    /** Swaps the block at [index] with the block of its NEXT SIBLING (same parent). Unchanged when there is no next sibling. */
    fun moveDown(entries: List<Entry>, index: Int): List<Entry> {
        val norm = normalizeLevels(entries)
        if (index !in norm.indices) return norm
        val end = nextSibling(norm, index)
        if (end < 0) return norm
        val nextEnd = blockEnd(norm, end)
        return normalizeLevels(norm.subList(0, index) + norm.subList(end, nextEnd) + norm.subList(index, end) + norm.subList(nextEnd, norm.size))
    }

    /** True when [indent] would do something: the entry before [index] is at the same level or deeper, so it can become that entry's last child. */
    fun canIndent(entries: List<Entry>, index: Int): Boolean {
        val norm = normalizeLevels(entries)
        return index in 1 until norm.size && norm[index - 1].level >= norm[index].level
    }

    /** True when [outdent] would do something (the entry is not at the top level). */
    fun canOutdent(entries: List<Entry>, index: Int): Boolean {
        val norm = normalizeLevels(entries)
        return index in norm.indices && norm[index].level > 1
    }

    private fun shiftBlock(entries: List<Entry>, index: Int, delta: Int): List<Entry> {
        val norm = normalizeLevels(entries)
        val end = blockEnd(norm, index)
        return normalizeLevels(norm.mapIndexed { i, e -> if (i in index until end) Entry(e.title, e.level + delta, e.page) else e })
    }

    /** Makes the block at [index] (the entry with its children) the LAST CHILD of its previous sibling: one level deeper, same place in the list. Unchanged when [canIndent] is false. */
    fun indent(entries: List<Entry>, index: Int): List<Entry> =
        if (canIndent(entries, index)) shiftBlock(entries, index, 1) else normalizeLevels(entries)

    /**
     * Moves the block at [index] one level up: it becomes a sibling of its former parent, right after it, and the entries that followed it under the same parent become ITS children
     * (the list keeps its order, so what you see in the editor is what you get: only this block changes level). Unchanged for a top-level entry.
     */
    fun outdent(entries: List<Entry>, index: Int): List<Entry> =
        if (canOutdent(entries, index)) shiftBlock(entries, index, -1) else normalizeLevels(entries)

    // ---------------------------------------------------------------- PdfBox

    /** All bookmarks of [doc], depth first, in outline order. */
    fun read(doc: PDDocument): List<Entry> {
        val outline = doc.documentCatalog.documentOutline ?: return emptyList()
        val out = ArrayList<Entry>()
        fun walk(first: PDOutlineItem?, level: Int) {
            var cur = first
            while (cur != null) {
                val page = try { cur.findDestinationPage(doc) } catch (t: Throwable) { null }
                val index = if (page != null) doc.pages.indexOf(page) else -1
                out.add(Entry(cur.title ?: "", level, index))
                walk(cur.firstChild, level + 1)
                cur = cur.nextSibling
            }
        }
        walk(outline.firstChild, 1)
        return out
    }

    /** Replaces the outline of [doc] by [entries] (levels normalized; entries whose page does not exist are skipped). */
    fun write(doc: PDDocument, entries: List<Entry>) {
        val usable = normalizeLevels(entries.filter { it.page in 0 until doc.numberOfPages })
        if (usable.isEmpty()) { doc.documentCatalog.documentOutline = null; return }
        val outline = PDDocumentOutline()
        val stack = ArrayList<PDOutlineNode>()
        stack.add(outline)
        for (e in usable) {
            val item = PDOutlineItem()
            item.title = e.title
            val dest = PDPageFitDestination()
            dest.page = doc.getPage(e.page)
            item.destination = dest
            while (stack.size > e.level) stack.removeAt(stack.size - 1)
            stack.last().addLast(item)
            stack.add(item)
        }
        outline.openNode()
        doc.documentCatalog.documentOutline = outline
    }

    private fun memory(dir: File?) = MemoryUsageSetting.setupMixed(24L * 1024 * 1024).also { if (dir != null) it.setTempDir(dir) }

    /** Reads the bookmarks of [src] (not encrypted PDFs: throws `IllegalStateException("encrypted")`). */
    fun readFile(src: File): Pair<List<Entry>, Int> {
        val doc = PDDocument.load(src, memory(src.parentFile))
        try {
            if (doc.isEncrypted) throw IllegalStateException("encrypted")
            return Pair(read(doc), doc.numberOfPages)
        } finally { runCatching { doc.close() } }
    }

    /** Writes a copy of [src] whose outline is [entries] (the pages are untouched). Throws `IllegalStateException("encrypted")` for a protected file. */
    fun saveWithOutline(src: File, out: File, entries: List<Entry>) {
        val doc = PDDocument.load(src, memory(src.parentFile))
        try {
            if (doc.isEncrypted) throw IllegalStateException("encrypted")
            val pages = doc.numberOfPages
            write(doc, entries)
            PdfStructureOptimizer.save(doc, out)
            if (!PdfVerify.opensAsPdf(out, pages)) { runCatching { out.delete() }; throw IllegalStateException("output failed verification") }
        } finally { runCatching { doc.close() } }
    }

    /**
     * One PDF per chapter at bookmarks of [level], written to [outDir] as `<base> - 01 <title>.pdf` (the number keeps the order; titles go through [SmartNamer.sanitize]).
     * Each part keeps the bookmarks that were inside its chapter. @return the files; an empty list when [level] has no usable bookmark.
     */
    fun splitFile(src: File, outDir: File, base: String, level: Int, includePreface: Boolean, prefaceTitle: String): List<File> {
        val doc = PDDocument.load(src, memory(src.parentFile))
        val parts = ArrayList<PDDocument>()
        try {
            if (doc.isEncrypted) throw IllegalStateException("encrypted")
            val entries = read(doc)
            val plan = sections(entries, doc.numberOfPages, level, includePreface, prefaceTitle)
            val files = ArrayList<File>()
            val width = plan.size.toString().length.coerceAtLeast(2)
            for ((i, s) in plan.withIndex()) {
                val splitter = Splitter()
                splitter.setStartPage(s.first + 1)
                splitter.setEndPage(s.last + 1)
                splitter.setSplitAtPage(s.last - s.first + 1)
                val part = splitter.split(doc).firstOrNull() ?: continue
                parts.add(part)
                write(part, entriesForPart(entries, s, level))
                val name = SmartNamer.sanitize("$base - ${(i + 1).toString().padStart(width, '0')} ${s.title}").ifEmpty { "$base - ${i + 1}" }
                val out = SmartNamer.uniqueFile(outDir, name, "pdf")
                PdfStructureOptimizer.save(part, out)
                if (!PdfVerify.opensAsPdf(out, s.last - s.first + 1)) { runCatching { out.delete() }; throw IllegalStateException("part failed verification") }
                files.add(out)
            }
            return files
        } finally {
            parts.forEach { runCatching { it.close() } }
            runCatching { doc.close() }
        }
    }

    /**
     * Merges [sources] (file, display name) into [out] keeping text, images and annotations as they are, and builds the combined outline ([mergedOutline]).
     * @return the number of pages. Throws `IllegalStateException("encrypted")` if a source is protected.
     */
    fun mergeFiles(sources: List<Pair<File, String>>, out: File, onProgress: (Int, Int) -> Unit = { _, _ -> }): Int {
        val dest = PDDocument(memory(out.parentFile))
        val open = ArrayList<PDDocument>()
        try {
            val merger = PDFMergerUtility()
            val outlines = ArrayList<SourceOutline>()
            for ((i, s) in sources.withIndex()) {
                onProgress(i + 1, sources.size)
                val d = PDDocument.load(s.first, memory(s.first.parentFile))
                open.add(d)
                if (d.isEncrypted) throw IllegalStateException("encrypted")
                outlines.add(SourceOutline(s.second, d.numberOfPages, read(d)))
                merger.appendDocument(dest, d)
            }
            write(dest, mergedOutline(outlines))
            PdfStructureOptimizer.save(dest, out)
            val pages = outlines.sumOf { it.pageCount }
            if (!PdfVerify.opensAsPdf(out, pages)) { runCatching { out.delete() }; throw IllegalStateException("output failed verification") }
            return pages
        } finally {
            open.forEach { runCatching { it.close() } }
            runCatching { dest.close() }
        }
    }

    /** Same as [mergeFiles] for content Uris (each is copied to a temporary file first and the copies are removed afterwards). */
    fun mergeUris(context: Context, uris: List<Uri>, out: File, onProgress: (Int, Int) -> Unit = { _, _ -> }): Int {
        val temps = ArrayList<File>()
        try {
            val sources = uris.map { uri ->
                val f = FileUtils.copyUriToTempFile(context, uri, ".pdf") ?: throw IllegalStateException("cannot read a source")
                temps.add(f)
                Pair(f, PdfImportHelper.displayName(context, uri).substringBeforeLast('.'))
            }
            return mergeFiles(sources, out, onProgress)
        } finally {
            temps.forEach { runCatching { it.delete() } }
        }
    }
}
