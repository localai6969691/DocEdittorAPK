package com.example.docscanner.util

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Labels ("Hợp đồng", "Thuế 2026") the user puts on exported documents, to find them by topic. Stored by FILE NAME, like
 * [FavoriteStore], as one JSON object `{ "<file name>": ["tag", ...] }` in a private preferences file. A document can have many
 * tags; the main screen can filter the list by one tag, and the search box also matches tag text ([HistoryFilter]).
 * Two tags that differ only in case or diacritics ("Hop dong" / "Hợp đồng") are the SAME tag: [canonical] reuses the spelling
 * already in use. Pure helpers ([cleanTag], [canonical]) are mirrored in tools/verify/history_filter_check.py.
 */
object TagStore {

    private const val PREFS = "tags"
    private const val KEY = "map"
    const val MAX_TAG_LENGTH = 60        // was 30; a folder path (Work/Invoices) is longer than a single word
    const val MAX_TAGS_PER_FILE = 12

    /** A tag with whitespace collapsed, forbidden characters (`, ; " \`) turned into spaces, folder separators tidied (`Work / Invoices` -> `Work/Invoices`), cut to [MAX_TAG_LENGTH]; empty if nothing is left. */
    fun cleanTag(raw: String): String {
        val replaced = raw.map { if (it == ',' || it == ';' || it == '"' || it == '\\' || it.isISOControl()) ' ' else it }.joinToString("")
        val spaced = replaced.replace(Regex("\\s+"), " ").trim()
        val path = spaced.split(TagTree.SEPARATOR).map { it.trim() }.filter { it.isNotEmpty() }.joinToString(TagTree.SEPARATOR.toString())     // "Work / / Invoices/" -> "Work/Invoices"
        return path.take(MAX_TAG_LENGTH).trim().trimEnd(TagTree.SEPARATOR).trim()
    }

    /** The spelling already in use for [tag] (same text ignoring case and diacritics), else [tag] itself. */
    fun canonical(tag: String, existing: Collection<String>): String {
        val key = HistoryFilter.normalize(tag)
        return existing.firstOrNull { HistoryFilter.normalize(it) == key } ?: tag
    }

    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** file name -> tags, as stored (a copy). */
    fun all(context: Context): Map<String, Set<String>> {
        val text = prefs(context).getString(KEY, null) ?: return emptyMap()
        return runCatching {
            val obj = JSONObject(text)
            val out = LinkedHashMap<String, Set<String>>()
            for (name in obj.keys()) {
                val arr = obj.getJSONArray(name)
                val tags = LinkedHashSet<String>()
                for (i in 0 until arr.length()) tags.add(arr.getString(i))
                if (tags.isNotEmpty()) out[name] = tags
            }
            out
        }.getOrDefault(emptyMap())
    }

    private fun save(context: Context, map: Map<String, Set<String>>) {
        val obj = JSONObject()
        for ((name, tags) in map) if (tags.isNotEmpty()) obj.put(name, JSONArray(tags.toList()))
        prefs(context).edit().putString(KEY, obj.toString()).apply()
    }

    /** Every tag in use with the number of documents carrying it, most used first, then alphabetical. */
    fun tagCounts(map: Map<String, Set<String>>): List<Pair<String, Int>> =
        map.values.flatten().groupingBy { it }.eachCount().toList()
            .sortedWith(compareBy({ -it.second }, { HistoryFilter.normalize(it.first) }))

    /** Replaces the tags of [file] with [tags] (cleaned, de-duplicated, spelling unified with existing tags, at most [MAX_TAGS_PER_FILE]). */
    fun setTags(context: Context, file: File, tags: Collection<String>) {
        val map = LinkedHashMap(all(context))
        val existing = map.filterKeys { it != file.name }.values.flatten().toSet()
        val result = LinkedHashSet<String>()
        for (raw in tags) {
            val clean = cleanTag(raw)
            if (clean.isEmpty()) continue
            val tag = canonical(clean, existing + result)
            if (result.none { HistoryFilter.normalize(it) == HistoryFilter.normalize(tag) } && result.size < MAX_TAGS_PER_FILE) result.add(tag)
        }
        if (result.isEmpty()) map.remove(file.name) else map[file.name] = result
        save(context, map)
    }

    fun rename(context: Context, oldName: String, newName: String) {
        val map = LinkedHashMap(all(context))
        val tags = map.remove(oldName) ?: return
        map[newName] = tags
        save(context, map)
    }

    /** Drops entries of files that no longer exist. */
    fun prune(context: Context, existingNames: Set<String>) {
        val map = all(context)
        val kept = map.filterKeys { it in existingNames }
        if (kept.size != map.size) save(context, kept)
    }
}
