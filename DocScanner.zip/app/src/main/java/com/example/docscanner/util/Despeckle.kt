package com.example.docscanner.util

import kotlin.math.max

/**
 * "Khử đốm" (despeckle): removes small dark specks (dust, sensor noise, paper grain) from a scanned page WITHOUT eating
 * Vietnamese tone marks, the dots of i/j, full stops or commas. The rule that makes it safe (phiên 17, mục 4.31):
 *
 *   a connected piece of ink is removed only if it is SMALL (area <= [maxAreaFor]) AND no SUBSTANTIAL piece of ink (a letter
 *   body, a line, a frame: area > maxArea) lies within [gapFor] pixels of it.
 *
 * A tone mark, an i-dot or a full stop always sits within a glyph-height of the letters it belongs to, so it is protected;
 * dust in a margin or on blank paper has no letter near it, so it goes. Specks touching text are never touched (they are
 * part of the same connected piece, hence "substantial"). A cloud of tiny specks on blank paper is removed entirely
 * (the neighbours of a speck do not protect it - only substantial ink does).
 *
 * Everything here is pure array code (no OpenCV, no Android) so that it is mirrored line by line in
 * tools/verify/ManualAdjustCheck.java and checked on synthetic Vietnamese pages by tools/verify/manual_adjust_check.py.
 * Connected pieces are found by our own two-pass union-find labelling (8-connectivity): it avoids depending on where
 * OpenCV 5 moved its connected-components functions (see TECHNICAL_DOCS.md 7.2, B15-03: five functions moved there once already).
 */
object Despeckle {

    /** Reference long edge (px) at which the area limits below are expressed; they scale with the square of the real edge. */
    const val REF_EDGE = 1500

    /** Largest speck area (px at [REF_EDGE]) for level 0..3. Level 0 = off. A tone mark at 150 dpi is ~12-25 px, so even level 3 relies on isolation. */
    private val LEVEL_AREA = intArrayOf(0, 6, 16, 36)

    /** Protection radius = this x the median glyph height. */
    const val GAP_FACTOR = 0.8

    class Labels(val labels: IntArray, val count: Int, val areas: IntArray, val heights: IntArray)

    fun maxAreaFor(level: Int, longEdge: Int): Int {
        val l = level.coerceIn(0, 3)
        if (l == 0) return 0
        val s = longEdge.toDouble() / REF_EDGE
        return max(1, Math.round(LEVEL_AREA[l] * s * s).toInt())
    }

    /** 8-connected labelling of [mask] (non-zero = ink). Label 0 = background; labels 1..count. */
    fun label(mask: ByteArray, w: Int, h: Int): Labels {
        val parent = IntArray(w * h / 2 + 2)
        var next = 1
        val lab = IntArray(w * h)
        fun find(a: Int): Int { var x = a; while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x] }; return x }
        fun union(a: Int, b: Int) { val ra = find(a); val rb = find(b); if (ra != rb) { if (ra < rb) parent[rb] = ra else parent[ra] = rb } }
        for (y in 0 until h) {
            for (x in 0 until w) {
                val p = y * w + x
                if (mask[p].toInt() == 0) continue
                var m = 0
                // already-visited neighbours: W, NW, N, NE
                val cand = intArrayOf(
                    if (x > 0) lab[p - 1] else 0,
                    if (x > 0 && y > 0) lab[p - w - 1] else 0,
                    if (y > 0) lab[p - w] else 0,
                    if (x < w - 1 && y > 0) lab[p - w + 1] else 0
                )
                for (c in cand) if (c != 0) { m = if (m == 0) c else m }
                if (m == 0) { parent[next] = next; lab[p] = next; next++ }
                else { lab[p] = m; for (c in cand) if (c != 0) union(m, c) }
            }
        }
        // compress to 1..count
        val remap = IntArray(next)
        var count = 0
        for (i in 1 until next) { if (find(i) == i) { count++; remap[i] = count } }
        for (i in 1 until next) remap[i] = remap[find(i)]
        val areas = IntArray(count + 1)
        val minY = IntArray(count + 1) { Int.MAX_VALUE }
        val maxY = IntArray(count + 1) { -1 }
        for (y in 0 until h) for (x in 0 until w) {
            val p = y * w + x
            val l = lab[p]
            if (l == 0) continue
            val r = remap[l]
            lab[p] = r
            areas[r]++
            if (y < minY[r]) minY[r] = y
            if (y > maxY[r]) maxY[r] = y
        }
        val heights = IntArray(count + 1)
        for (i in 1..count) heights[i] = maxY[i] - minY[i] + 1
        return Labels(lab, count, areas, heights)
    }

    /** Median height of the substantial pieces (letters); a page without any gets a size derived from the image. */
    fun gapFor(l: Labels, maxArea: Int, longEdge: Int): Int {
        val hs = ArrayList<Int>()
        for (i in 1..l.count) if (l.areas[i] > maxArea) hs.add(l.heights[i])
        val glyph: Double = if (hs.isEmpty()) max(8.0, longEdge / 100.0) else { hs.sort(); hs[hs.size / 2].toDouble() }
        return max(2, Math.round(GAP_FACTOR * glyph).toInt())
    }

    /** Per label (index = label): true if that piece is a speck to remove. */
    fun findSpecks(l: Labels, w: Int, h: Int, maxArea: Int, gap: Int): BooleanArray {
        val speck = BooleanArray(l.count + 1)
        if (maxArea <= 0 || l.count == 0) return speck
        // 1. mask of substantial ink
        var tmp = ByteArray(w * h)
        for (p in 0 until w * h) { val lb = l.labels[p]; if (lb != 0 && l.areas[lb] > maxArea) tmp[p] = 1 }
        // 2. dilate by a square of radius gap (two running-count passes)
        val horiz = ByteArray(w * h)
        for (y in 0 until h) {
            var cnt = 0
            for (x in 0 until minOf(gap, w)) cnt += tmp[y * w + x]
            for (x in 0 until w) {
                if (x + gap < w) cnt += tmp[y * w + x + gap]
                if (x - gap - 1 >= 0) cnt -= tmp[y * w + x - gap - 1]
                if (cnt > 0) horiz[y * w + x] = 1
            }
        }
        val near = ByteArray(w * h)
        for (x in 0 until w) {
            var cnt = 0
            for (y in 0 until minOf(gap, h)) cnt += horiz[y * w + x]
            for (y in 0 until h) {
                if (y + gap < h) cnt += horiz[(y + gap) * w + x]
                if (y - gap - 1 >= 0) cnt -= horiz[(y - gap - 1) * w + x]
                if (cnt > 0) near[y * w + x] = 1
            }
        }
        // 3. a small piece is protected if any of its pixels is near substantial ink
        val protectedLabel = BooleanArray(l.count + 1)
        for (p in 0 until w * h) { val lb = l.labels[p]; if (lb != 0 && near[p].toInt() != 0) protectedLabel[lb] = true }
        for (i in 1..l.count) speck[i] = l.areas[i] <= maxArea && !protectedLabel[i]
        return speck
    }
}
