package com.example.docscanner.util

import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * Draws chapters as real, selectable PDF text (not images) using `android.graphics.pdf.PdfDocument`
 * directly - unlike [PdfCompressor], this is a fine use of PdfDocument, since text glyphs are not
 * an image-compression concern (Skia's PDF backend embeds fonts/text natively either way, which
 * matters a lot here: Vietnamese diacritics need real Unicode font handling that only Skia's own
 * text layout can be trusted to get right without embedding a font file by hand).
 *
 * Word-wrapping is done manually, one line at a time, so each line can be checked against the
 * remaining space on the current page and a new page started mid-paragraph if needed. WHERE a
 * line may end comes from the Unicode line-breaking rules (`android.icu.text.BreakIterator`, API 24+),
 * not from spaces, so Chinese / Japanese / Korean text (no spaces between words) wraps correctly and
 * never starts a line with a closing punctuation mark; [TextWrapper] picks the last allowed position
 * that still fits. (The first version split on spaces and let CJK paragraphs run off the page.)
 *
 * After PdfDocument writes the file, [PdfBookmarkInjector] makes a best-effort attempt to add real,
 * clickable PDF bookmarks (one per chapter) by patching the output - see that class for why this
 * is a best-effort step with a safe fallback rather than something guaranteed to work.
 */
object TextPdfBuilder {

    private const val PAGE_WIDTH = 595 // A4 at 72pt/inch
    private const val PAGE_HEIGHT = 842
    private const val MARGIN = 40f
    private const val TITLE_SIZE = 18f
    private const val BODY_SIZE = 12f
    private const val LINE_HEIGHT = 16f
    private const val PARAGRAPH_GAP = 8f
    private const val TITLE_GAP = 20f

    fun build(outFile: File, chapters: List<EbookBuilder.Chapter>) {
        val document = PdfDocument()
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = TITLE_SIZE
            isFakeBoldText = true
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = BODY_SIZE
        }
        val maxWidth = PAGE_WIDTH - 2 * MARGIN

        var pageNumber = 1
        var page = document.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create())
        var canvas = page.canvas
        var y = MARGIN + TITLE_SIZE
        // 0-indexed page number where each chapter's title lands, same order as `chapters`.
        val chapterStartPageIndex = mutableListOf<Int>()

        fun ensureSpace(needed: Float) {
            if (y + needed > PAGE_HEIGHT - MARGIN) {
                document.finishPage(page)
                pageNumber++
                page = document.startPage(PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageNumber).create())
                canvas = page.canvas
                y = MARGIN + TITLE_SIZE
            }
        }

        if (chapters.isEmpty()) {
            document.finishPage(page)
        } else {
            chapters.forEach { chapter ->
                ensureSpace(TITLE_SIZE)
                chapterStartPageIndex.add(pageNumber - 1)
                canvas.drawText(chapter.title, MARGIN, y, titlePaint)
                y += TITLE_GAP

                chapter.paragraphs.forEach { paragraph ->
                    wrapText(paragraph, bodyPaint, maxWidth).forEach { line ->
                        ensureSpace(LINE_HEIGHT)
                        canvas.drawText(line, MARGIN, y, bodyPaint)
                        y += LINE_HEIGHT
                    }
                    y += PARAGRAPH_GAP
                }
            }
            document.finishPage(page)
        }

        val plainBytes = ByteArrayOutputStream().also { document.writeTo(it) }.toByteArray()
        document.close()

        val withBookmarks = if (chapters.isNotEmpty()) {
            PdfBookmarkInjector.tryAddBookmarks(
                plainBytes,
                pageCount = pageNumber,
                chapterTitles = chapters.map { it.title },
                chapterStartPageIndex = chapterStartPageIndex
            )
        } else {
            null
        }

        FileOutputStream(outFile).use { it.write(withBookmarks ?: plainBytes) }
    }

    /** The lines of [text] (blank lines dropped) when wrapped to [maxWidth]; also used by [TablePdfBuilder] for the text inside a cell. */
    internal fun wrapText(text: String, paint: Paint, maxWidth: Float): List<String> {
        if (text.isBlank()) return emptyList()
        val lines = mutableListOf<String>()
        for (piece in text.lines()) {
            if (piece.isBlank()) continue
            lines += TextWrapper.wrap(piece, maxWidth, lineBreakOffsets(piece)) { start, end ->
                paint.measureText(piece, start, end)
            }
        }
        return lines
    }

    /** Positions where [text] may be broken into lines (UAX #14), ascending, the last one = text.length. */
    private fun lineBreakOffsets(text: String): IntArray {
        val iterator = android.icu.text.BreakIterator.getLineInstance()
        iterator.setText(text)
        val offsets = ArrayList<Int>()
        var b = iterator.next()
        while (b != android.icu.text.BreakIterator.DONE) {
            offsets.add(b)
            b = iterator.next()
        }
        return offsets.toIntArray()
    }
}
