package com.example.docscanner.view

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/**
 * Shows one page (fitted and centred) and lets the user draw boxes on it with a finger: press, drag, release. The boxes are kept as
 * FRACTIONS of the page (left, top, right, bottom), so they do not depend on the size the preview is drawn at; [onBoxAdded] gets each
 * new one, and the screen decides what to do with it (keep a list per page, undo). Boxes smaller than [MIN_FRACTION] of the page in
 * either direction are taken for a stray touch and ignored.
 */
class RedactionView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var onBoxAdded: ((FloatArray) -> Unit)? = null

    private var page: Bitmap? = null
    private var boxes: List<FloatArray> = emptyList()
    private var boxColors: IntArray? = null
    private val colorPaint = Paint()

    /** Draw the red frame around every box (the redaction screen does; the highlighter screen turns it off). */
    var showFrame: Boolean = true
    private val pageRect = RectF()
    private var dragStart: Pair<Float, Float>? = null
    private var dragNow: Pair<Float, Float>? = null

    private val bitmapPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint().apply { color = Color.argb(215, 0, 0, 0) }
    private val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.RED
        style = Paint.Style.STROKE
        strokeWidth = 2f * resources.displayMetrics.density
    }
    private val dragPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(230, 25, 118, 210)
        style = Paint.Style.STROKE
        strokeWidth = 2f * resources.displayMetrics.density
    }

    fun setPage(bitmap: Bitmap?) { page = bitmap; invalidate() }

    fun setBoxes(list: List<FloatArray>) { boxes = list; invalidate() }

    /** Optional ARGB fill per box (same order as the list given to [setBoxes]); null = every box gets the black redaction fill. Used by the highlighter screen. */
    fun setBoxColors(colors: IntArray?) { boxColors = colors; invalidate() }

    private fun layoutPage() {
        val p = page
        if (p == null || width == 0 || height == 0) { pageRect.setEmpty(); return }
        val scale = minOf(width.toFloat() / p.width, height.toFloat() / p.height)
        val w = p.width * scale
        val h = p.height * scale
        pageRect.set((width - w) / 2f, (height - h) / 2f, (width + w) / 2f, (height + h) / 2f)
    }

    private fun toPixels(f: FloatArray) = RectF(
        pageRect.left + f[0] * pageRect.width(), pageRect.top + f[1] * pageRect.height(),
        pageRect.left + f[2] * pageRect.width(), pageRect.top + f[3] * pageRect.height()
    )

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val p = page ?: return
        layoutPage()
        if (pageRect.isEmpty) return
        canvas.drawBitmap(p, null, pageRect, bitmapPaint)
        for ((i, b) in boxes.withIndex()) {
            val r = toPixels(b)
            val colors = boxColors
            if (colors != null && i < colors.size) {
                colorPaint.color = colors[i]
                canvas.drawRect(r, colorPaint)
            } else {
                canvas.drawRect(r, fillPaint)
            }
            if (showFrame) canvas.drawRect(r, framePaint)
        }
        val s = dragStart
        val n = dragNow
        if (s != null && n != null) canvas.drawRect(minOf(s.first, n.first), minOf(s.second, n.second), maxOf(s.first, n.first), maxOf(s.second, n.second), dragPaint)
    }

    private fun clampX(x: Float) = x.coerceIn(pageRect.left, pageRect.right)
    private fun clampY(y: Float) = y.coerceIn(pageRect.top, pageRect.bottom)

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (page == null || pageRect.isEmpty) return super.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                dragStart = Pair(clampX(event.x), clampY(event.y))
                dragNow = dragStart
            }
            MotionEvent.ACTION_MOVE -> {
                dragNow = Pair(clampX(event.x), clampY(event.y))
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                val s = dragStart
                val e = Pair(clampX(event.x), clampY(event.y))
                dragStart = null
                dragNow = null
                if (s != null) {
                    val f = floatArrayOf(
                        (minOf(s.first, e.first) - pageRect.left) / pageRect.width(),
                        (minOf(s.second, e.second) - pageRect.top) / pageRect.height(),
                        (maxOf(s.first, e.first) - pageRect.left) / pageRect.width(),
                        (maxOf(s.second, e.second) - pageRect.top) / pageRect.height()
                    )
                    if (f[2] - f[0] >= MIN_FRACTION && f[3] - f[1] >= MIN_FRACTION) onBoxAdded?.invoke(f)
                }
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                dragStart = null
                dragNow = null
                invalidate()
            }
        }
        return true
    }

    companion object {
        const val MIN_FRACTION = 0.01f
    }
}
