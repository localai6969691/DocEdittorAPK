package com.example.docscanner

import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityProjectOcrBinding
import com.example.docscanner.model.Project
import com.example.docscanner.model.ProjectManager
import com.example.docscanner.model.ProjectStage
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.OcrHelper
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.SearchablePdfBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Project stage 7: mandatory OCR over every page, producing a plain-text file - the same
 * "--- Trang N ---" format `PdfExporter.exportSession`'s optional OCR checkbox already writes, so
 * a project's .txt output looks like the standalone tool's. Nothing for the user to configure
 * (OCR has no presets), so this runs automatically on entering the stage; Continue just enables
 * once it's done. If the project already has OCR text (resumed after this stage already
 * finished), it's shown immediately instead of re-running.
 *
 * The same OCR pass also lays an invisible text layer over the project's PDF ([SearchablePdfBuilder.embedInPlace]),
 * so the PDF the user keeps is searchable and copyable. It goes into the COMPRESSED PDF when stage 6 made one (that is
 * the smaller file the project hands out; compressing earlier would have thrown a text layer away because it rebuilds
 * the file from the page images), otherwise into the plain exported PDF. If the layer cannot be added the PDF stays as
 * it was and the OCR runs the old way, page image by page image - the .txt is produced either way.
 */
class ProjectOcrActivity : BaseActivity() {

    private lateinit var binding: ActivityProjectOcrBinding
    private lateinit var project: Project

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProjectOcrBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        val projectId = intent.getStringExtra(ProjectFlow.EXTRA_PROJECT_ID)
        val loaded = projectId?.let { ProjectManager.load(this, it) }
        if (loaded == null) {
            finish()
            return
        }
        project = loaded
        title = project.name
        binding.tvStageIndicator.text = getString(R.string.project_stage_indicator_6)

        binding.btnContinue.setOnClickListener { advance() }

        val existingPath = project.ocrTextPath
        if (existingPath != null && File(existingPath).exists()) {
            showDone(File(existingPath).readText())
        } else {
            runOcr()
        }
    }

    /** Warns first when the battery is nearly empty or the phone is hot (PDF 2.15 / 2.16, util.DeviceLoad); otherwise runs [runOcrNow] at once. */
    private fun runOcr() {
        com.example.docscanner.util.DeviceLoad.guard(this, onCancel = { finish() }) { runOcrNow() }
    }

    private fun runOcrNow() {
        val pages = project.pages
        binding.tvProgress.text = getString(R.string.project_ocr_progress, 0, pages.size)
        lifecycleScope.launch { com.example.docscanner.util.KeepAlive.during(applicationContext) {
            val placeholder = getString(R.string.ocr_no_text_placeholder)
            val layerPdf = (project.compressedPdfPath ?: project.pdfPath)?.let { File(it) }?.takeIf { it.isFile }

            // 1) one pass that gives the text layer AND the transcript
            var texts: List<String>? = null
            var layerNote: String? = null
            if (layerPdf != null) {
                val embedded = withContext(Dispatchers.Default) {
                    SearchablePdfBuilder.embedInPlace(layerPdf) { done, total ->
                        runOnUiThread {
                            binding.tvProgress.text = getString(R.string.project_ocr_progress, done, total)
                            binding.progressBar.progress = if (total > 0) done * 100 / total else 0
                        }
                    }
                }
                if (embedded != null) {
                    texts = (0 until embedded.result.pageCount).map { embedded.pageTexts[it] ?: "" }
                    layerNote = getString(R.string.project_ocr_layer_done, layerPdf.name)
                } else {
                    layerNote = getString(R.string.project_ocr_layer_failed)
                }
            }

            // 2) fallback (and the only path when the project has no PDF file): OCR the page images one by one
            val pageTexts = texts ?: run {
                val collected = mutableListOf<String>()
                pages.forEachIndexed { index, page ->
                    binding.tvProgress.text = getString(R.string.project_ocr_progress, index + 1, pages.size)
                    binding.progressBar.progress = if (pages.isNotEmpty()) (index + 1) * 100 / pages.size else 0
                    val text = withContext(Dispatchers.Default) {
                        val bitmap = BitmapFactory.decodeFile(page.path)
                        val result = if (bitmap != null) OcrHelper.recognize(bitmap) else ""
                        bitmap?.recycle()
                        result
                    }
                    collected.add(text)
                }
                collected
            }

            val outFile = File(PdfExporter.exportDir(this@ProjectOcrActivity), "${FileUtils.defaultDocName()}.txt")
            withContext(Dispatchers.IO) {
                outFile.bufferedWriter().use { w ->
                    pageTexts.forEachIndexed { i, text ->
                        w.write("--- Trang ${i + 1} ---\n")
                        w.write(text.ifBlank { placeholder })
                        w.write("\n\n")
                    }
                }
            }
            project.ocrTextPath = outFile.absolutePath
            ProjectManager.save(this@ProjectOcrActivity, project)
            showDone(outFile.readText(), layerNote)
        }}
    }

    private fun showDone(fullText: String, note: String? = null) {
        binding.progressBar.progress = 100
        val done = getString(R.string.project_ocr_done)
        binding.tvProgress.text = if (note != null) done + "\n" + note else done
        binding.tvOcrPreview.text = fullText.take(4000)
        binding.btnContinue.isEnabled = true
    }

    private fun advance() {
        project.stage = ProjectStage.EBOOK
        ProjectManager.save(this, project)
        ProjectFlow.open(this, project)
        finish()
    }
}
