package com.example.docscanner.util

import java.io.File
import java.io.FileInputStream
import java.io.RandomAccessFile
import java.nio.charset.StandardCharsets
import java.security.SecureRandom
import java.util.Calendar
import java.util.TimeZone
import java.util.zip.CRC32
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * "Pack the selected documents into ONE ZIP", with an optional password (PDF list items E6 Archive, L13 Export as ZIP,
 * M2 Share as ZIP, M4 Share with password).
 *
 * - No password: an ordinary ZIP written by [ZipOutputStream] (opens everywhere, Windows Explorer included).
 * - With a password: WinZip AES encryption, format AE-2, key strength 256 bits (the de-facto standard that 7-Zip, WinRAR,
 *   Keka, The Unarchiver, Info-ZIP's newer builds and libarchive read). The format (all little-endian):
 *     local header: method 99, flag bit 0 (encrypted) + bit 11 (UTF-8 names), CRC field 0 (AE-2 keeps no CRC), extra
 *       field 0x9901 { version 2, vendor "AE", strength 3, real method 0 or 8 };
 *     data: salt (16) | password verifier (2) | AES-CTR ciphertext | first 10 bytes of HMAC-SHA1(ciphertext);
 *     keys: PBKDF2-HMAC-SHA1(password as UTF-8, salt, 1000 iterations) -> 66 bytes = AES key (32) | HMAC key (32) | verifier (2);
 *     CTR: the counter block is 16 bytes LITTLE-endian starting at 1 (not the big-endian counter of RFC 3686 / GCM).
 *
 * PBKDF2 is written out here with [Mac] instead of calling `SecretKeyFactory("PBKDF2WithHmacSHA1")` on purpose: Android's
 * provider can turn a password into bytes by keeping only the low 8 bits of each char (PKCS#5 "8-bit" scheme), so a Vietnamese
 * password with a diacritic would give a different key from the UTF-8 bytes every other ZIP tool uses and the file would not open
 * elsewhere. ASCII passwords hide that difference, which is exactly why it must be tested with non-ASCII ones
 * (tools/verify/zip_pack_check.py does, against hashlib.pbkdf2_hmac).
 *
 * Honest limits (the dialog says the first two): file NAMES are not encrypted (the ZIP format has no way to do that with AES);
 * the 1 000 PBKDF2 iterations are fixed by the format, so a short or common password can be guessed fast - hence
 * [MIN_PASSWORD_CHARS]; no ZIP64, so [MAX_TOTAL_BYTES] and [MAX_ENTRIES] are enforced up front.
 *
 * Everything except [write]'s file access is pure and mirrored by tools/verify/ZipPackCheck.java (same algorithm, runs on a JVM).
 */
object ZipPack {

    const val MIN_PASSWORD_CHARS = 8
    const val MAX_ENTRIES = 65_000
    const val MAX_TOTAL_BYTES = 4_000_000_000L

    private const val AES_KEY_BYTES = 32
    private const val SALT_BYTES = 16
    private const val PBKDF2_ITERATIONS = 1000
    private const val MAC_BYTES = 10
    private const val CHUNK = 64 * 1024

    /** Thrown for "too many / too big"; the caller shows its own translated message. */
    class TooBigException : IllegalArgumentException()

    /** Extensions whose content is already compressed: deflating them again costs time and gains almost nothing. */
    private val STORED_EXTENSIONS = setOf("pdf", "jpg", "jpeg", "png", "webp", "epub", "zip", "docx", "xlsx", "pptx", "cbz", "mp4", "gz", "7z")

    fun shouldStore(name: String): Boolean = name.substringAfterLast('.', "").lowercase() in STORED_EXTENSIONS

    fun passwordAcceptable(password: String): Boolean = password.codePointCount(0, password.length) >= MIN_PASSWORD_CHARS

    /**
     * Names to use inside the ZIP: no folder parts or control characters, never empty, and unique (a second "a.pdf" becomes
     * "a (2).pdf"; uniqueness is case-insensitive because the ZIP is usually unpacked on Windows / macOS).
     */
    fun entryNames(names: List<String>): List<String> {
        val used = HashSet<String>()
        val out = ArrayList<String>(names.size)
        for (raw in names) {
            var base = raw.substringAfterLast('/').substringAfterLast('\\')
                .map { if (it.code < 32 || it == ':' || it == '*' || it == '?' || it == '"' || it == '<' || it == '>' || it == '|') '_' else it }
                .joinToString("").trim { it.code <= 32 }.trim('.')
            if (base.isEmpty()) base = "file"
            var candidate = base
            var n = 2
            while (!used.add(candidate.lowercase())) {
                val dot = base.lastIndexOf('.')
                candidate = if (dot > 0) base.substring(0, dot) + " (" + n + ")" + base.substring(dot) else "$base ($n)"
                n++
            }
            out.add(candidate)
        }
        return out
    }

    /** DOS time and date words of the ZIP format (2-second resolution; dates before 1980 are clamped to 1980-01-01). */
    fun dosDateTime(millis: Long, tz: TimeZone): Pair<Int, Int> {
        val c = Calendar.getInstance(tz)
        c.timeInMillis = millis
        val year = c.get(Calendar.YEAR)
        if (year < 1980) return Pair(0, (1 shl 5) or 1)
        val date = ((year - 1980) shl 9) or ((c.get(Calendar.MONTH) + 1) shl 5) or c.get(Calendar.DAY_OF_MONTH)
        val time = (c.get(Calendar.HOUR_OF_DAY) shl 11) or (c.get(Calendar.MINUTE) shl 5) or (c.get(Calendar.SECOND) / 2)
        return Pair(time, date)
    }

    /** PBKDF2 with HMAC-SHA1 (RFC 8018), byte-exact with hashlib.pbkdf2_hmac('sha1', ...). */
    fun pbkdf2HmacSha1(password: ByteArray, salt: ByteArray, iterations: Int, dkLen: Int): ByteArray {
        val mac = Mac.getInstance("HmacSHA1")
        mac.init(SecretKeySpec(password, "HmacSHA1"))
        val hLen = mac.macLength
        val blocks = (dkLen + hLen - 1) / hLen
        val out = ByteArray(dkLen)
        for (i in 1..blocks) {
            mac.update(salt)
            mac.update(byteArrayOf((i ushr 24).toByte(), (i ushr 16).toByte(), (i ushr 8).toByte(), i.toByte()))
            var u = mac.doFinal()
            val t = u.copyOf()
            for (j in 2..iterations) {
                u = mac.doFinal(u)
                for (k in t.indices) t[k] = (t[k].toInt() xor u[k].toInt()).toByte()
            }
            val start = (i - 1) * hLen
            System.arraycopy(t, 0, out, start, minOf(hLen, dkLen - start))
        }
        return out
    }

    /** AES in counter mode with the WinZip counter (16-byte little-endian block counter, first block = 1). Streaming-safe. */
    private class AesCtrLe(key: ByteArray) {
        private val cipher: Cipher = Cipher.getInstance("AES/ECB/NoPadding").also { it.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES")) }
        private val counter = ByteArray(16).also { it[0] = 1 }
        private var stream = ByteArray(16)
        private var used = 16

        fun process(buf: ByteArray, off: Int, len: Int) {
            for (i in off until off + len) {
                if (used == 16) {
                    stream = cipher.doFinal(counter)     // ECB without padding keeps no state: 16 bytes in, 16 bytes out
                    var k = 0
                    while (k < 16) {                       // increment the little-endian counter
                        counter[k] = (counter[k] + 1).toByte()
                        if (counter[k] != 0.toByte()) break
                        k++
                    }
                    used = 0
                }
                buf[i] = (buf[i].toInt() xor stream[used++].toInt()).toByte()
            }
        }
    }

    private fun le16(v: Int) = byteArrayOf(v.toByte(), (v ushr 8).toByte())
    private fun le32(v: Long) = byteArrayOf(v.toByte(), (v ushr 8).toByte(), (v ushr 16).toByte(), (v ushr 24).toByte())

    private fun aesExtra(realMethod: Int): ByteArray =
        le16(0x9901) + le16(7) + le16(2) + byteArrayOf('A'.code.toByte(), 'E'.code.toByte(), 3) + le16(realMethod)

    private class Done(val name: ByteArray, val method: Int, val time: Int, val date: Int, val compressed: Long, val size: Long, val offset: Long)

    /**
     * Packs [files] (shown as [names], already made by [entryNames]) into [out]. [password] null = ordinary ZIP.
     * @throws TooBigException when the classic (non-ZIP64) limits would be exceeded
     */
    fun write(files: List<File>, names: List<String>, out: File, password: String?, random: SecureRandom = SecureRandom(), tz: TimeZone = TimeZone.getDefault()) {
        require(files.size == names.size)
        if (files.size > MAX_ENTRIES || files.sumOf { it.length() } > MAX_TOTAL_BYTES) throw TooBigException()
        if (password == null) writePlain(files, names, out) else writeAes(files, names, out, password, random, tz)
    }

    private fun writePlain(files: List<File>, names: List<String>, out: File) {
        ZipOutputStream(out.outputStream().buffered()).use { zip ->
            zip.setLevel(Deflater.BEST_SPEED)
            val buf = ByteArray(CHUNK)
            for ((i, f) in files.withIndex()) {
                val entry = ZipEntry(names[i]).apply { time = f.lastModified() }
                if (shouldStore(names[i])) {
                    // STORED needs size and CRC before the data: one cheap pass over the file
                    val crc = CRC32()
                    FileInputStream(f).use { input -> while (true) { val n = input.read(buf); if (n < 0) break; crc.update(buf, 0, n) } }
                    entry.method = ZipEntry.STORED
                    entry.size = f.length(); entry.compressedSize = f.length(); entry.crc = crc.value
                }
                zip.putNextEntry(entry)
                FileInputStream(f).use { input -> while (true) { val n = input.read(buf); if (n < 0) break; zip.write(buf, 0, n) } }
                zip.closeEntry()
            }
        }
    }

    private fun writeAes(files: List<File>, names: List<String>, out: File, password: String, random: SecureRandom, tz: TimeZone) {
        val pw = password.toByteArray(StandardCharsets.UTF_8)
        val done = ArrayList<Done>()
        try {
            RandomAccessFile(out, "rw").use { raf ->
                raf.setLength(0)
                for ((i, f) in files.withIndex()) {
                    val name = names[i].toByteArray(StandardCharsets.UTF_8)
                    val method = if (shouldStore(names[i])) 0 else 8
                    val (time, date) = dosDateTime(f.lastModified(), tz)
                    val offset = raf.filePointer
                    val size = f.length()
                    val extra = aesExtra(method)
                    raf.write(le32(0x04034b50L) + le16(51) + le16(0x0801) + le16(99) + le16(time) + le16(date) + le32(0) + le32(0) + le32(size) +
                        le16(name.size) + le16(extra.size) + name + extra)
                    val dataStart = raf.filePointer

                    val salt = ByteArray(SALT_BYTES).also { random.nextBytes(it) }
                    val dk = pbkdf2HmacSha1(pw, salt, PBKDF2_ITERATIONS, 2 * AES_KEY_BYTES + 2)
                    val ctr = AesCtrLe(dk.copyOfRange(0, AES_KEY_BYTES))
                    val mac = Mac.getInstance("HmacSHA1").also { it.init(SecretKeySpec(dk.copyOfRange(AES_KEY_BYTES, 2 * AES_KEY_BYTES), "HmacSHA1")) }
                    raf.write(salt)
                    raf.write(dk, 2 * AES_KEY_BYTES, 2)

                    fun emit(b: ByteArray, n: Int) {
                        if (n <= 0) return
                        ctr.process(b, 0, n)
                        mac.update(b, 0, n)
                        raf.write(b, 0, n)
                    }
                    val buf = ByteArray(CHUNK)
                    if (method == 0) {
                        FileInputStream(f).use { input -> while (true) { val n = input.read(buf); if (n < 0) break; emit(buf, n) } }
                    } else {
                        val deflater = Deflater(Deflater.BEST_SPEED, true)
                        val packed = ByteArray(CHUNK)
                        try {
                            FileInputStream(f).use { input ->
                                while (true) {
                                    val n = input.read(buf)
                                    if (n < 0) break
                                    deflater.setInput(buf, 0, n)
                                    while (!deflater.needsInput()) emit(packed, deflater.deflate(packed))
                                }
                            }
                            deflater.finish()
                            while (!deflater.finished()) emit(packed, deflater.deflate(packed))
                        } finally { deflater.end() }
                    }
                    raf.write(mac.doFinal(), 0, MAC_BYTES)

                    val end = raf.filePointer
                    val compressed = end - dataStart
                    if (compressed > 0xFFFFFFFFL || end > 0xFFFFFFFFL) throw TooBigException()
                    raf.seek(offset + 18)                       // patch the compressed size now that it is known
                    raf.write(le32(compressed))
                    raf.seek(end)
                    done.add(Done(name, method, time, date, compressed, size, offset))
                }
                val cdStart = raf.filePointer
                for (d in done) {
                    val extra = aesExtra(d.method)
                    raf.write(le32(0x02014b50L) + le16(0x0033) + le16(51) + le16(0x0801) + le16(99) + le16(d.time) + le16(d.date) + le32(0) +
                        le32(d.compressed) + le32(d.size) + le16(d.name.size) + le16(extra.size) + le16(0) + le16(0) + le16(0) + le32(0) +
                        le32(d.offset) + d.name + extra)
                }
                val cdSize = raf.filePointer - cdStart
                raf.write(le32(0x06054b50L) + le16(0) + le16(0) + le16(done.size) + le16(done.size) + le32(cdSize) + le32(cdStart) + le16(0))
            }
        } finally {
            pw.fill(0)
        }
    }
}
