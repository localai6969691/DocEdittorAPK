package com.example.docscanner.util

import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSDictionary
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.cos.COSStream
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/**
 * Long-term validation, PAdES-B-LT (session 23, 4.51): after a PDF is signed, store the certificates and their revocation data (OCSP responses, CRLs; see
 * [Revocation]) in the document's /DSS (Document Security Store, ISO 32000-2 12.8.4.3, ETSI EN 319 142-1 5.4.2), so a reader can still validate the signature
 * when the CA's servers are gone or the certificate has expired.
 *
 * It is an INCREMENTAL update (`saveIncremental`, the same technique as [PdfFormFiller] and [PdfDigitalSigner]): the signed bytes are not touched, so the
 * signature stays valid (checked with pdfsig on a hand-built update of the same structure: tools/verify/ltv_pdf_check.py). A /DSS that already exists (a
 * second signature) is carried over, not lost: the new dictionary lists the old streams too.
 *
 * Not done: no /VRI (optional; readers accept a global /DSS), no document time stamp (that would be PAdES-B-LTA), and the certificates inside a time stamp
 * token are not collected. Only worth doing for a certificate issued by a CA: a self-signed one has nothing to revoke, and [addValidationInfo] then writes nothing.
 */
object PdfLtv {

    /** [needed] = certificates that need revocation data, [covered] = how many got it, [written] = a /DSS update was appended to the file. */
    class Result(val needed: Int, val covered: Int, val written: Boolean)

    private val DSS = COSName.getPDFName("DSS")
    private val KEYS = listOf("Certs", "OCSPs", "CRLs")

    /**
     * Adds the validation data for every signature of [file] (replacing the file only if something was found). Uses the network (OCSP / CRL servers named
     * in the certificates): call it off the main thread. Throws when the PDF has no signature or the result does not open.
     */
    fun addValidationInfo(file: File): Result {
        val doc = PDDocument.load(file, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(file.parentFile))
        val tmp = File(file.path + ".ltv")
        var needed = 0
        var covered = 0
        try {
            val signatures = doc.signatureDictionaries
            if (signatures.isEmpty()) throw IllegalStateException("no signature")
            val pool = ArrayList<ByteArray>()
            for (signature in signatures) {
                val cms = FileInputStream(file).use { signature.getContents(it) }
                for (c in Revocation.cmsCertificates(cms)) if (pool.none { it.contentEquals(c) }) pool.add(c)
            }
            if (pool.isEmpty()) return Result(0, 0, false)
            val bundle = Revocation.collect(pool, { url, body -> Revocation.httpPost(url, body) }, { url -> Revocation.httpGet(url) })
            needed = bundle.needed
            covered = bundle.covered
            if (bundle.ocsps.isEmpty() && bundle.crls.isEmpty()) return Result(needed, covered, false)

            val catalog = doc.documentCatalog.cosObject
            val old = catalog.getDictionaryObject(DSS) as? COSDictionary
            val dss = COSDictionary()
            dss.setItem(COSName.TYPE, COSName.getPDFName("DSS"))
            val fresh = mapOf("Certs" to bundle.certs, "OCSPs" to bundle.ocsps, "CRLs" to bundle.crls)
            for (key in KEYS) {
                val array = COSArray()
                val seen = ArrayList<ByteArray>()
                carryOver(old, key, array, seen)
                for (der in fresh.getValue(key)) {
                    if (seen.any { it.contentEquals(der) }) continue
                    array.add(newStream(doc, der))
                    seen.add(der)
                }
                if (array.size() > 0) {
                    array.setNeedToBeUpdated(true)
                    dss.setItem(COSName.getPDFName(key), array)
                }
            }
            dss.setNeedToBeUpdated(true)
            catalog.setItem(DSS, dss)
            catalog.setNeedToBeUpdated(true)
            FileOutputStream(tmp).use { doc.saveIncremental(it) }
            if (!PdfVerify.opensAsPdf(tmp, doc.numberOfPages)) throw IllegalStateException("output failed verification")
        } catch (e: Throwable) {
            runCatching { tmp.delete() }
            throw e
        } finally {
            runCatching { doc.close() }
        }
        // the document is closed: replace the file only now (it was open for reading until here)
        tmp.copyTo(file, overwrite = true)
        tmp.delete()
        return Result(needed, covered, true)
    }

    private fun newStream(doc: PDDocument, der: ByteArray): COSStream {
        val stream = doc.document.createCOSStream()
        stream.createOutputStream(COSName.FLATE_DECODE).use { it.write(der) }
        stream.setNeedToBeUpdated(true)
        return stream
    }

    /** Keeps the streams of the existing /DSS array [key] (by reference) in [into] and remembers their bytes in [seen] so the same item is not stored twice. */
    private fun carryOver(old: COSDictionary?, key: String, into: COSArray, seen: MutableList<ByteArray>) {
        val array = old?.getDictionaryObject(COSName.getPDFName(key)) as? COSArray ?: return
        for (i in 0 until array.size()) {
            val stream = array.getObject(i) as? COSStream ?: continue
            val bytes = stream.createInputStream().use { it.readBytes() }
            seen.add(bytes)
            into.add(array.get(i))
        }
    }
}
