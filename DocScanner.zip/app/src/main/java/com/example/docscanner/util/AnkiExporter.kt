package com.example.docscanner.util

import android.database.sqlite.SQLiteDatabase
import java.io.File

/**
 * Writes an Anki `.apkg` (session 26). The cards and every SQL statement come from [AnkiDeck] (plain Kotlin, run for real against Anki itself by tools/verify/anki_real_run_check.py);
 * this is only the thin part that hands the statement list to the platform's SQLite and zips the finished collection - the one part no check off the phone can run.
 */
object AnkiExporter {

    /** [cacheDir] holds the temporary collection file, which is deleted again. Throws on any failure and leaves no [out] behind. */
    fun writeApkg(cards: List<AnkiDeck.Card>, deckName: String, out: File, cacheDir: File) {
        val collection = File.createTempFile("anki-", ".anki2", cacheDir)
        try {
            val db = SQLiteDatabase.openOrCreateDatabase(collection, null)
            try {
                db.disableWriteAheadLogging()          // one plain file: a collection kept partly in a -wal file would be zipped incomplete
                db.beginTransaction()
                try {
                    for (st in AnkiDeck.statements(cards, deckName, System.currentTimeMillis())) {
                        if (st.args.isEmpty()) db.execSQL(st.sql) else db.execSQL(st.sql, st.args)
                    }
                    db.setTransactionSuccessful()
                } finally {
                    db.endTransaction()
                }
            } finally {
                db.close()
            }
            AnkiDeck.pack(collection, out)
        } catch (e: Exception) {
            runCatching { out.delete() }
            throw e
        } finally {
            runCatching { collection.delete() }
            runCatching { File(collection.path + "-journal").delete() }
            runCatching { File(collection.path + "-wal").delete() }
            runCatching { File(collection.path + "-shm").delete() }
        }
    }
}
