package com.example.docscanner.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.zip.Deflater

/**
 * The VISIBLE stamp of a digital signature (PDF list "dấu hiển thị cho chữ ký số"): a box on the last page, bottom right, saying who signed and when,
 * so a person who prints the PDF or opens it in a viewer that hides the signature panel still sees that it is signed.
 *
 * How it reaches the document (PDFBox's own mechanism, the one its CreateVisibleSignature example uses): [templatePdf] writes a tiny ONE-PAGE PDF whose
 * only content is a signature field with a widget annotation (rectangle + appearance stream = the stamp image); [PdfDigitalSigner] hands those bytes to
 * `SignatureOptions.setVisualSignature(InputStream)` and `setPage(last page)`. The template is written BY HAND here (no PDFBox calls), so its exact bytes
 * can be tested on a JVM: tools/verify/VisibleSignatureCheck.java is a line-by-line twin, and visible_signature_check.py renders the result with poppler.
 *
 * The hard part is ROTATED pages. An annotation turns with the page, so a stamp that must READ upright on a page with /Rotate 90 has to be pre-rotated:
 * [userRect] converts the place the person SEES (bottom right) into the page's own coordinates, and [formMatrix] counter-rotates the appearance. Both are
 * checked by rendering pages rotated 0 / 90 / 180 / 270, with non-zero crop-box origins, and comparing the pixels with where the stamp must be.
 * If anything about the visible stamp fails at signing time, [PdfDigitalSigner.sign] signs without it (a missing stamp is better than a missing signature).
 */
object VisibleSignature {

    const val WIDTH_PT = 200f
    const val HEIGHT_PT = 58f
    const val MARGIN_PT = 24f

    private fun rot(rotation: Int) = ((rotation % 360) + 360) % 360

    /**
     * [llx, lly, urx, ury] in the page's user space of a stamp of [w] x [h] points at the bottom right of the VISIBLE page. [box] is the page's crop box
     * (llx, lly, urx, ury; its origin need not be 0,0). On a page too small for the stamp plus margins the stamp is scaled down to fit.
     */
    fun userRect(box: FloatArray, rotation: Int, w: Float = WIDTH_PT, h: Float = HEIGHT_PT, margin: Float = MARGIN_PT): FloatArray {
        val r = rot(rotation)
        val bw = box[2] - box[0]; val bh = box[3] - box[1]
        val vw = if (r == 90 || r == 270) bh else bw
        val vh = if (r == 90 || r == 270) bw else bh
        var s = 1f
        val roomW = vw - 2 * margin; val roomH = vh - 2 * margin
        if (roomW > 0 && roomH > 0) s = minOf(1f, roomW / w, roomH / h) else if (vw > 0 && vh > 0) s = minOf(1f, vw / w, vh / h)
        val sw = w * s; val sh = h * s
        val x0 = vw - (if (roomW > 0 && roomH > 0) margin else 0f) - sw
        val y0 = vh - (if (roomW > 0 && roomH > 0) margin else 0f) - sh               // visual coordinates: origin top left, y down
        var llx = Float.MAX_VALUE; var lly = Float.MAX_VALUE; var urx = -Float.MAX_VALUE; var ury = -Float.MAX_VALUE
        for ((vx, vy) in listOf(x0 to y0, x0 + sw to y0, x0 to y0 + sh, x0 + sw to y0 + sh)) {
            val (ux, uy) = when (r) {                                                   // visual -> user space (the displayed page is the user space turned CLOCKWISE by r)
                90 -> vy to vx
                180 -> bw - vx to vy
                270 -> bw - vy to bh - vx
                else -> vx to bh - vy
            }
            llx = minOf(llx, ux); lly = minOf(lly, uy); urx = maxOf(urx, ux); ury = maxOf(ury, uy)
        }
        return floatArrayOf(box[0] + llx, box[1] + lly, box[0] + urx, box[1] + ury)
    }

    /** Size of the stamp as the person sees it (after the shrink [userRect] may apply), recovered from the rectangle. */
    fun visualSize(rect: FloatArray, rotation: Int): Pair<Float, Float> {
        val w = rect[2] - rect[0]; val h = rect[3] - rect[1]
        val r = rot(rotation)
        return if (r == 90 || r == 270) h to w else w to h
    }

    /** The appearance stream's /Matrix: the content turned COUNTER-clockwise by the page rotation, so that after the page turns it reads upright. */
    fun formMatrix(rotation: Int): FloatArray = when (rot(rotation)) {
        90 -> floatArrayOf(0f, 1f, -1f, 0f, 0f, 0f)
        180 -> floatArrayOf(-1f, 0f, 0f, -1f, 0f, 0f)
        270 -> floatArrayOf(0f, -1f, 1f, 0f, 0f, 0f)
        else -> floatArrayOf(1f, 0f, 0f, 1f, 0f, 0f)
    }

    private fun num(v: Float): String {
        val s = String.format(Locale.US, "%.3f", v).trimEnd('0').trimEnd('.')
        return if (s == "-0" || s.isEmpty()) "0" else s
    }

    private fun nums(a: FloatArray) = a.joinToString(" ") { num(it) }

    /**
     * The one-page template PDF (classic xref, six objects): catalog with /AcroForm, pages, page (same crop box and rotation as the target page, so the
     * rectangle means the same thing), the signature widget, the appearance form and the stamp image (8-bit RGB, Flate). Deterministic: same input, same bytes.
     */
    fun templatePdf(box: FloatArray, rotation: Int, rect: FloatArray, imageW: Int, imageH: Int, rgb: ByteArray, fieldName: String = "Signature1"): ByteArray {
        require(rgb.size == imageW * imageH * 3)
        val (w, h) = visualSize(rect, rotation)
        val deflater = Deflater(Deflater.BEST_COMPRESSION)
        val packed = ByteArrayOutputStream()
        try {
            deflater.setInput(rgb); deflater.finish()
            val buf = ByteArray(16 * 1024)
            while (!deflater.finished()) { val n = deflater.deflate(buf); packed.write(buf, 0, n) }
        } finally { deflater.end() }
        val image = packed.toByteArray()
        val content = "q ${num(w)} 0 0 ${num(h)} 0 0 cm /Im0 Do Q".toByteArray(Charsets.US_ASCII)

        val out = ByteArrayOutputStream()
        val offsets = ArrayList<Int>()
        fun text(s: String) = out.write(s.toByteArray(Charsets.ISO_8859_1))
        fun begin(n: Int) { offsets.add(out.size()); text("$n 0 obj\n") }
        text("%PDF-1.4\n%\u00E2\u00E3\u00CF\u00D3\n")
        begin(1); text("<< /Type /Catalog /Pages 2 0 R /AcroForm << /Fields [4 0 R] /SigFlags 3 >> >>\nendobj\n")
        begin(2); text("<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n")
        begin(3); text("<< /Type /Page /Parent 2 0 R /MediaBox [${nums(box)}] /CropBox [${nums(box)}] /Rotate ${rot(rotation)} /Resources << >> /Annots [4 0 R] >>\nendobj\n")
        begin(4); text("<< /Type /Annot /Subtype /Widget /FT /Sig /T (${fieldName}) /Rect [${nums(rect)}] /F 132 /P 3 0 R /AP << /N 5 0 R >> >>\nendobj\n")
        begin(5)
        text("<< /Type /XObject /Subtype /Form /FormType 1 /BBox [0 0 ${num(w)} ${num(h)}] /Matrix [${nums(formMatrix(rotation))}] /Resources << /XObject << /Im0 6 0 R >> >> /Length ${content.size} >>\nstream\n")
        out.write(content); text("\nendstream\nendobj\n")
        begin(6)
        text("<< /Type /XObject /Subtype /Image /Width $imageW /Height $imageH /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length ${image.size} >>\nstream\n")
        out.write(image); text("\nendstream\nendobj\n")
        val xref = out.size()
        text("xref\n0 7\n0000000000 65535 f \n")
        for (o in offsets) text(String.format(Locale.US, "%010d 00000 n \n", o))
        text("trailer\n<< /Size 7 /Root 1 0 R >>\nstartxref\n$xref\n%%EOF\n")
        return out.toByteArray()
    }

    // ---- the only part that needs Android: drawing the stamp ----

    /** The stamp as a bitmap: white, thin dark-blue frame, [lines] of text shrunk to fit (accents and Vietnamese render with the system font). */
    fun stampBitmap(lines: List<String>, widthPt: Float, heightPt: Float, scale: Float = 3f): Bitmap {
        val bw = (widthPt * scale).toInt().coerceAtLeast(8); val bh = (heightPt * scale).toInt().coerceAtLeast(8)
        val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)
        val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0x1F, 0x3A, 0x6E); style = Paint.Style.STROKE; strokeWidth = 1.5f * scale }
        canvas.drawRect(frame.strokeWidth / 2, frame.strokeWidth / 2, bw - frame.strokeWidth / 2, bh - frame.strokeWidth / 2, frame)
        val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(0x1F, 0x3A, 0x6E) }
        val inner = bw - 2 * 6f * scale
        val rowH = (bh - 2 * 5f * scale) / lines.size.coerceAtLeast(1)
        var y = 5f * scale
        for ((i, line) in lines.withIndex()) {
            text.isFakeBoldText = i == 0
            var size = (if (i == 0) 11f else 9f) * scale
            text.textSize = size
            while (text.measureText(line) > inner && size > 4f * scale) { size -= 0.5f * scale; text.textSize = size }
            canvas.drawText(line, 6f * scale, y + rowH * 0.5f + size * 0.35f, text)
            y += rowH
        }
        return bmp
    }

    /** RGB bytes of [bmp] (alpha dropped: the stamp is opaque white). */
    fun rgbOf(bmp: Bitmap): ByteArray {
        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        val out = ByteArray(px.size * 3)
        for (i in px.indices) { out[3 * i] = Color.red(px[i]).toByte(); out[3 * i + 1] = Color.green(px[i]).toByte(); out[3 * i + 2] = Color.blue(px[i]).toByte() }
        return out
    }
}
