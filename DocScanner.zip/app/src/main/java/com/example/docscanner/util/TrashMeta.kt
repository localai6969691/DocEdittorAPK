package com.example.docscanner.util

/**
 * What a document has OUTSIDE the file - the favourite star and its tags - written next to it in the recycle bin ([TrashStore] `.meta`) so a restored document comes back
 * with them (phiên 17, mục 4.33). Plain text, one fact per line: `fav=1` or `fav=0`, then one `tag=<hex of the UTF-8 tag>` per tag (hex, so any character in a tag - a tab, a
 * newline, `=` - survives). [decode] is forgiving: unknown or malformed lines are ignored, a missing `fav` means not a favourite, duplicate tags collapse. Pure; mirrored in
 * tools/verify/TrashCheck.java and checked by round trip in tools/verify/trash_rename_check.py.
 */
object TrashMeta {
    class Meta(val favorite: Boolean, val tags: List<String>)

    private fun hex(s: String): String = s.toByteArray(Charsets.UTF_8).joinToString("") { String.format("%02x", it.toInt() and 0xFF) }

    private fun unhex(h: String): String? {
        if (h.isEmpty() || h.length % 2 != 0) return null
        val b = ByteArray(h.length / 2)
        for (i in b.indices) b[i] = (h.substring(2 * i, 2 * i + 2).toIntOrNull(16) ?: return null).toByte()
        return String(b, Charsets.UTF_8)
    }

    fun encode(favorite: Boolean, tags: Collection<String>): String =
        "fav=" + (if (favorite) "1" else "0") + "\n" + tags.joinToString("") { "tag=" + hex(it) + "\n" }

    fun decode(text: String): Meta {
        var fav = false
        val tags = LinkedHashSet<String>()
        for (line in text.split('\n')) {
            val l = line.trim()
            when {
                l == "fav=1" -> fav = true
                l.startsWith("tag=") -> unhex(l.substring(4))?.takeIf { it.isNotEmpty() }?.let { tags.add(it) }
            }
        }
        return Meta(fav, tags.toList())
    }
}
