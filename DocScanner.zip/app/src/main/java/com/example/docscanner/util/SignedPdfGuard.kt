package com.example.docscanner.util

import android.app.Activity
import android.net.Uri
import androidx.appcompat.app.AlertDialog
import com.example.docscanner.R
import java.io.File
import kotlin.coroutines.resume
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext

/**
 * Asks the user BEFORE a tool rewrites a PDF that carries a digital signature (PDF "Thieu gi de ban app" 2.6).
 *
 * The decision itself is [PdfSignatureProbe.effect] (pure, checked against poppler's `pdfsig` in `tools/verify/signed_pdf_check.py`);
 * this file only reads the file, shows the dialog and returns the answer. A file that cannot be read, or that has no signature, never
 * gets a dialog: the guard must not get in the way of the 99 % of PDFs that are not signed.
 *
 * Every tool of this app writes a NEW file and leaves the source untouched, so the dialog says what is true: the original stays a valid
 * signed copy, the new file will not be.
 */
object SignedPdfGuard {

    /** What the dialog needs to say, separated from Android so the wording rules can be read (and tested) on their own. */
    data class Facts(val approvals: Int, val timestamps: Int, val certifyLevel: Int, val changedAfterLast: Boolean)

    fun factsOf(r: PdfSignatureProbe.Result): Facts =
        Facts(r.approvals.size, r.timestamps.size, r.certifyLevel, r.changedAfterLastSignature)

    /** The result of looking at [file], or null if it could not be read (then the caller simply goes on). */
    suspend fun probe(file: File): PdfSignatureProbe.Result? =
        withContext(Dispatchers.IO) { runCatching { PdfSignatureProbe.scan(file) }.getOrNull() }

    /** True = go on. Shows the dialog only when [tool] would break a signature of [file]. */
    suspend fun confirm(
        activity: Activity,
        file: File,
        tool: PdfSignatureProbe.ToolKind = PdfSignatureProbe.ToolKind.REWRITES
    ): Boolean {
        val r = probe(file) ?: return true
        if (PdfSignatureProbe.effect(r, tool) != PdfSignatureProbe.Effect.BREAKS) return true
        return ask(activity, factsOf(r))
    }

    /** Same for a document that is only a [Uri] (the tools that render the pages straight from the provider): copies it to a temp file to read it. */
    suspend fun confirmUri(
        activity: Activity,
        uri: Uri,
        tool: PdfSignatureProbe.ToolKind = PdfSignatureProbe.ToolKind.REWRITES
    ): Boolean {
        val copy = withContext(Dispatchers.IO) { runCatching { FileUtils.copyUriToTempFile(activity, uri, ".pdf") }.getOrNull() } ?: return true
        try {
            return confirm(activity, copy, tool)
        } finally {
            runCatching { copy.delete() }
        }
    }

    private suspend fun ask(activity: Activity, facts: Facts): Boolean = suspendCancellableCoroutine { cont ->
        val text = StringBuilder()
        if (facts.approvals > 0) text.append(activity.getString(R.string.signed_warn_body, facts.approvals))
        else text.append(activity.getString(R.string.signed_warn_body_timestamp))
        if (facts.certifyLevel > 0) text.append("\n\n").append(activity.getString(R.string.signed_warn_certified))
        if (facts.changedAfterLast) text.append("\n\n").append(activity.getString(R.string.signed_warn_changed))
        val dialog = AlertDialog.Builder(activity)
            .setTitle(R.string.signed_warn_title)
            .setMessage(text.toString())
            .setPositiveButton(R.string.signed_warn_continue) { _, _ -> if (cont.isActive) cont.resume(true) }
            .setNegativeButton(R.string.signed_warn_cancel) { _, _ -> if (cont.isActive) cont.resume(false) }
            .setOnCancelListener { if (cont.isActive) cont.resume(false) }
            .create()
        cont.invokeOnCancellation { runCatching { dialog.dismiss() } }
        dialog.show()
    }
}
