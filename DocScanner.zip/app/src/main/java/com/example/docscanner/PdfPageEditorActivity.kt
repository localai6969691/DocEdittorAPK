package com.example.docscanner

import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.adapter.PdfPageAdapter
import com.example.docscanner.adapter.PdfPageItem
import com.example.docscanner.databinding.ActivityPdfPageEditorBinding
import com.example.docscanner.model.PdfEditorState
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.PageEditorTools
import com.example.docscanner.util.PageRanges
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfImportHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.docscanner.util.SignedPdfGuard

class PdfPageEditorActivity : BaseActivity() {

    private lateinit var binding: ActivityPdfPageEditorBinding
    private lateinit var adapter: PdfPageAdapter
    private val pages = mutableListOf<PdfPageItem>()
    private var hasLoadedOnce = false

    private val onPdfChosen = ActivityResultCallback<Uri?> { uri ->
        if (uri != null) {
            loadPdf(uri)
        } else if (pages.isEmpty()) {
            finish()
        }
    }

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument(), onPdfChosen)

    /** First pick of this screen: a PDF that another app handed over ("Open with" / "Share", see `IncomingFile`) is used directly, otherwise the system picker opens. */
    private fun pickPdfOrUseIncoming() {
        val incoming = intent?.data
        if (incoming != null) onPdfChosen.onActivityResult(incoming) else pdfPicker.launch(arrayOf("application/pdf"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfPageEditorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.tool_pagemanager_title)

        adapter = PdfPageAdapter(
            onDelete = { position ->
                pages.removeAt(position)
                refreshList()
                persistEditorState()
            },
            onRotate = { position ->
                pages[position].rotationDeg = (pages[position].rotationDeg + 90) % 360
                adapter.submitList(pages)
                persistEditorState()
            },
            onToggleSelect = { position ->
                pages[position].selected = !pages[position].selected
                adapter.submitList(pages)
                persistEditorState()
            }
        )
        binding.rvPdfPages.layoutManager = GridLayoutManager(this, 2)
        binding.rvPdfPages.adapter = adapter

        val touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(
            ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.LEFT or ItemTouchHelper.RIGHT, 0
        ) {
            override fun onMove(
                recyclerView: RecyclerView,
                viewHolder: RecyclerView.ViewHolder,
                target: RecyclerView.ViewHolder
            ): Boolean {
                val from = viewHolder.bindingAdapterPosition
                val to = target.bindingAdapterPosition
                if (from == RecyclerView.NO_POSITION || to == RecyclerView.NO_POSITION) return false
                val item = pages.removeAt(from)
                pages.add(to, item)
                adapter.moveItem(from, to)
                persistEditorState()
                return true
            }

            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {}
        })
        touchHelper.attachToRecyclerView(binding.rvPdfPages)

        binding.btnExportPdf.setOnClickListener { export(asImages = false) }
        binding.btnExportImages.setOnClickListener { export(asImages = true) }

        if (savedInstanceState == null) {
            if (PdfEditorState.hasSaved()) {
                offerRestore()
            } else {
                pickPdfOrUseIncoming()
            }
        }
    }

    /** If a previous process left an unfinished page-editor session on disk (killed by the OS,
     *  crashed, phone restarted...) ask whether to pick it back up instead of silently losing
     *  the rotate/delete/reorder work - same idea as MainActivity's scan-session restore prompt. */
    private fun offerRestore() {
        val count = PdfEditorState.savedPageCount()
        AlertDialog.Builder(this)
            .setTitle(R.string.restore_pageeditor_title)
            .setMessage(getString(R.string.restore_pageeditor_message, count))
            .setCancelable(false)
            .setPositiveButton(R.string.restore_pageeditor_continue) { _, _ ->
                val saved = PdfEditorState.restore()
                if (saved.isEmpty()) {
                    pdfPicker.launch(arrayOf("application/pdf"))
                    return@setPositiveButton
                }
                pages.clear()
                pages.addAll(saved.map { PdfPageItem(it.path, it.rotationDeg, it.selected) })
                hasLoadedOnce = true
                refreshList()
            }
            .setNegativeButton(R.string.restore_pageeditor_new) { _, _ ->
                PdfEditorState.clear()
                pdfPicker.launch(arrayOf("application/pdf"))
            }
            .show()
    }

    private fun persistEditorState() {
        PdfEditorState.persist(pages.map { PdfEditorState.SavedPage(it.path, it.rotationDeg, it.selected) })
    }

    private fun loadPdf(uri: Uri) {
        setBusy(true, getString(R.string.loading_pdf))
        lifecycleScope.launch {
            if (!SignedPdfGuard.confirmUri(this@PdfPageEditorActivity, uri)) {
                setBusy(false)
                if (pages.isEmpty()) finish()
                return@launch
            }
            val paths = withContext(Dispatchers.IO) {
                PdfImportHelper.renderAllPagesToFiles(this@PdfPageEditorActivity, uri, dpi = 200) { i ->
                    FileUtils.newPdfEditorPageFile(this@PdfPageEditorActivity, i)
                }
            }
            hasLoadedOnce = true
            setBusy(false)
            if (paths.isEmpty()) {
                Toast.makeText(
                    this@PdfPageEditorActivity,
                    getString(R.string.export_failed, ""),
                    Toast.LENGTH_SHORT
                ).show()
                finish()
                return@launch
            }
            pages.clear()
            pages.addAll(paths.map { PdfPageItem(it) })
            refreshList()
            persistEditorState()
        }
    }

    // ------------------------------------------------------------------------------------------------------------------
    // Page operations menu: add pages from another PDF, duplicate, blank page, crop, paper size, split
    // ------------------------------------------------------------------------------------------------------------------

    private val addPdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) addPagesFromPdf(uri)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_pdf_page_editor, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_pm_add_pdf -> { addPdfPicker.launch(arrayOf("application/pdf")); true }
        R.id.action_pm_duplicate -> { duplicateSelected(); true }
        R.id.action_pm_blank -> { insertBlankPage(); true }
        R.id.action_pm_crop -> { askCrop(); true }
        R.id.action_pm_paper -> { askPaper(); true }
        R.id.action_pm_split_ranges -> { askSplitRanges(); true }
        R.id.action_pm_split_every -> { askSplitEvery(); true }
        else -> super.onOptionsItemSelected(item)
    }

    /** New pages go right after the last ticked page, or at the end when nothing is ticked. */
    private fun insertPosition(): Int {
        val last = pages.indexOfLast { it.selected }
        return if (last >= 0) last + 1 else pages.size
    }

    private fun addPagesFromPdf(uri: Uri) {
        setBusy(true, getString(R.string.loading_pdf))
        lifecycleScope.launch {
            val paths = withContext(Dispatchers.IO) {
                PdfImportHelper.renderAllPagesToFiles(this@PdfPageEditorActivity, uri, dpi = PageEditorTools.DPI) {
                    FileUtils.newPdfEditorExtraPageFile(this@PdfPageEditorActivity)
                }
            }
            setBusy(false)
            if (paths.isEmpty()) {
                Toast.makeText(this@PdfPageEditorActivity, R.string.pm_add_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            pages.addAll(insertPosition(), paths.map { PdfPageItem(it) })
            hasLoadedOnce = true
            refreshList()
            persistEditorState()
            Toast.makeText(this@PdfPageEditorActivity, getString(R.string.pm_added, paths.size), Toast.LENGTH_SHORT).show()
        }
    }

    private fun duplicateSelected() {
        val chosen = pages.filter { it.selected }.map { Triple(it.path, it.rotationDeg, it) }
        if (chosen.isEmpty()) {
            Toast.makeText(this, R.string.pm_select_first, Toast.LENGTH_SHORT).show()
            return
        }
        setBusy(true, null)
        lifecycleScope.launch {
            val copies = withContext(Dispatchers.IO) {
                chosen.mapNotNull { (path, rotation, original) ->
                    val file = FileUtils.newPdfEditorExtraPageFile(this@PdfPageEditorActivity)
                    if (PageEditorTools.duplicate(path, file)) original to PdfPageItem(file.absolutePath, rotation, false) else null
                }
            }
            setBusy(false)
            // each copy goes right after its original; walk from the back so earlier positions stay valid
            copies.map { (original, copy) -> pages.indexOf(original) to copy }
                .filter { it.first >= 0 }
                .sortedByDescending { it.first }
                .forEach { (index, copy) -> pages.add(index + 1, copy) }
            refreshList()
            persistEditorState()
            Toast.makeText(this@PdfPageEditorActivity, getString(R.string.pm_duplicated, copies.size), Toast.LENGTH_SHORT).show()
        }
    }

    private fun insertBlankPage() {
        val position = insertPosition()
        val reference = pages.getOrNull(position - 1) ?: pages.firstOrNull()
        setBusy(true, null)
        lifecycleScope.launch {
            val file = FileUtils.newPdfEditorExtraPageFile(this@PdfPageEditorActivity)
            val ok = withContext(Dispatchers.IO) { PageEditorTools.blankPage(reference?.path, reference?.rotationDeg ?: 0, file) }
            setBusy(false)
            if (!ok) {
                Toast.makeText(this@PdfPageEditorActivity, R.string.pm_blank_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            pages.add(minOf(position, pages.size), PdfPageItem(file.absolutePath))
            hasLoadedOnce = true
            refreshList()
            persistEditorState()
            Toast.makeText(this@PdfPageEditorActivity, R.string.pm_blank_added, Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Applies [operation] to the ticked pages (all pages when none is ticked). Each result is a NEW file with the page's rotation
     * baked in, so the item is replaced (found again by its path - the list may have been reordered meanwhile) and the old file deleted.
     * A page the operation fails on is left untouched and counted in the message.
     */
    private fun transformPages(doneMessage: Int, operation: (PdfPageItem, java.io.File) -> Boolean) {
        val targets = pages.filter { it.selected }.ifEmpty { pages.toList() }.map { Triple(it.path, it.rotationDeg, it) }
        if (targets.isEmpty()) return
        setBusy(true, null)
        lifecycleScope.launch {
            val results = withContext(Dispatchers.Default) {
                targets.map { (path, rotation, original) ->
                    val file = FileUtils.newPdfEditorExtraPageFile(this@PdfPageEditorActivity)
                    // a snapshot of the page, so a rotation tapped meanwhile cannot change what is processed
                    val ok = operation(PdfPageItem(path, rotation, false), file)
                    if (!ok) file.delete()
                    Triple(original, file, ok)
                }
            }
            setBusy(false)
            var done = 0
            results.forEach { (original, file, ok) ->
                val index = pages.indexOf(original)
                if (ok && index >= 0) {
                    pages[index] = PdfPageItem(file.absolutePath, 0, original.selected)
                    runCatching { java.io.File(original.path).delete() }
                    done++
                } else if (ok) {
                    file.delete()
                }
            }
            refreshList()
            persistEditorState()
            Toast.makeText(this@PdfPageEditorActivity, getString(doneMessage, done), Toast.LENGTH_SHORT).show()
            val failed = results.count { !it.third }
            if (failed > 0) Toast.makeText(this@PdfPageEditorActivity, getString(R.string.pm_op_failed, failed), Toast.LENGTH_LONG).show()
        }
    }

    private fun askCrop() {
        if (pages.isEmpty()) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val hint = android.widget.TextView(this).apply {
            setText(R.string.pm_crop_hint)
            textSize = 12f
            setPadding(0, 0, 0, dp(8))
        }
        box.addView(hint)
        fun field(hintRes: Int): EditText = EditText(this).apply {
            setHint(hintRes)
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            isSingleLine = true
            box.addView(this)
        }
        val left = field(R.string.pm_crop_left)
        val top = field(R.string.pm_crop_top)
        val right = field(R.string.pm_crop_right)
        val bottom = field(R.string.pm_crop_bottom)
        AlertDialog.Builder(this)
            .setTitle(R.string.pm_crop_title)
            .setView(box)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                fun value(e: EditText): Float? = e.text.toString().trim().ifEmpty { "0" }.toFloatOrNull()?.takeIf { it in 0f..45f }
                val l = value(left); val t = value(top); val r = value(right); val b = value(bottom)
                if (l == null || t == null || r == null || b == null) {
                    Toast.makeText(this, R.string.pm_crop_invalid, Toast.LENGTH_LONG).show()
                } else {
                    transformPages(R.string.pm_crop_done) { item, file -> PageEditorTools.crop(item.path, item.rotationDeg, l, t, r, b, file) }
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun askPaper() {
        if (pages.isEmpty()) return
        val papers = PageEditorTools.Paper.values()
        AlertDialog.Builder(this)
            .setTitle(R.string.pm_paper_title)
            .setItems(papers.map { getString(it.labelRes) }.toTypedArray()) { _, which ->
                transformPages(R.string.pm_paper_done) { item, file -> PageEditorTools.fitToPaper(item.path, item.rotationDeg, papers[which], file) }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun askSplitRanges() {
        if (pages.isEmpty()) return
        askText(R.string.pm_split_ranges_title, R.string.pm_split_ranges_hint, numeric = false) { text ->
            val parsed = PageRanges.parse(text, pages.size)
            if (parsed.ok) {
                splitInto(parsed.groups)
            } else {
                val bad = parsed.badToken ?: ""
                val message = when (parsed.problem) {
                    PageRanges.Problem.OUT_OF_RANGE -> getString(R.string.pm_split_range, bad, pages.size)
                    PageRanges.Problem.REVERSED -> getString(R.string.pm_split_reversed, bad)
                    PageRanges.Problem.SYNTAX -> getString(R.string.pm_split_syntax, bad)
                    else -> getString(R.string.pm_split_empty)
                }
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun askSplitEvery() {
        if (pages.isEmpty()) return
        askText(R.string.pm_split_every_title, R.string.pm_split_every_hint, numeric = true) { text ->
            val n = text.trim().toIntOrNull()
            if (n == null || n < 1) {
                Toast.makeText(this, R.string.pm_split_every_invalid, Toast.LENGTH_LONG).show()
            } else {
                splitInto(PageRanges.everyN(pages.size, n))
            }
        }
    }

    /** One PDF per group of page positions (in the CURRENT order, with the pending rotations); the editor stays open. */
    private fun splitInto(groups: List<List<Int>>) {
        val snapshot = pages.map { it.path to it.rotationDeg }
        val base = FileUtils.defaultDocName()
        setBusy(true, null)
        lifecycleScope.launch {
            try {
                val files = withContext(Dispatchers.Default) {
                    groups.mapIndexed { n, group ->
                        PdfExporter.exportImagePaths(
                            this@PdfPageEditorActivity,
                            group.map { snapshot[it].first },
                            group.map { snapshot[it].second },
                            baseName = "${base}_part${n + 1}_p${PageRanges.label(group)}",
                            sourceDpi = PageEditorTools.DPI.toFloat()
                        )
                    }
                }
                setBusy(false)
                Toast.makeText(this@PdfPageEditorActivity, getString(R.string.pm_split_done, files.size), Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                setBusy(false)
                Toast.makeText(this@PdfPageEditorActivity, getString(R.string.export_failed, e.message ?: ""), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun askText(titleRes: Int, hintRes: Int, numeric: Boolean, onOk: (String) -> Unit) {
        val input = EditText(this).apply {
            setHint(hintRes)
            inputType = if (numeric) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
            isSingleLine = true
        }
        val frame = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(titleRes)
            .setView(frame)
            .setPositiveButton(android.R.string.ok) { _, _ -> onOk(input.text.toString()) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun refreshList() {
        adapter.submitList(pages)
        title = getString(R.string.page_manager_title, pages.size)
        binding.tvEmptyPages.visibility = if (pages.isEmpty() && hasLoadedOnce) View.VISIBLE else View.GONE
    }

    private fun selectionOrAll(): List<PdfPageItem> {
        val selected = pages.filter { it.selected }
        return selected.ifEmpty { pages }
    }

    private fun export(asImages: Boolean) {
        if (pages.isEmpty()) return
        val chosen = selectionOrAll()
        val paths = chosen.map { it.path }
        val rotations = chosen.map { it.rotationDeg }
        setBusy(true, null)
        lifecycleScope.launch {
            try {
                if (asImages) {
                    val files = withContext(Dispatchers.Default) {
                        PdfExporter.exportAsImages(this@PdfPageEditorActivity, paths, rotations)
                    }
                    setBusy(false)
                    Toast.makeText(
                        this@PdfPageEditorActivity,
                        getString(R.string.export_images_success, files.size),
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    // Pages here always came from rendering a picked PDF at 200dpi (loadPdf() above) -
                    // never a camera capture - so the exported page must keep that real DPI to come
                    // out at the correct physical size (see PdfExporter.ASSUMED_DPI's doc comment).
                    val file = withContext(Dispatchers.Default) {
                        PdfExporter.exportImagePaths(this@PdfPageEditorActivity, paths, rotations, sourceDpi = 200f)
                    }
                    setBusy(false)
                    Toast.makeText(
                        this@PdfPageEditorActivity,
                        getString(R.string.export_success, file.name),
                        Toast.LENGTH_LONG
                    ).show()
                }
                PdfEditorState.clear()
                finish()
            } catch (e: Exception) {
                setBusy(false)
                Toast.makeText(
                    this@PdfPageEditorActivity,
                    getString(R.string.export_failed, e.message ?: ""),
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun setBusy(busy: Boolean, message: String? = null) {
        binding.progressBar.visibility = if (busy) View.VISIBLE else View.GONE
        binding.tvProgress.visibility = if (busy && message != null) View.VISIBLE else View.GONE
        if (message != null) binding.tvProgress.text = message
        binding.btnExportPdf.isEnabled = !busy
        binding.btnExportImages.isEnabled = !busy
    }
}
