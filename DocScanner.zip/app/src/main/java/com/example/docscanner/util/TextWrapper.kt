package com.example.docscanner.util

/**
 * Greedy line breaking that does NOT depend on spaces between words.
 *
 * The first version of [TextPdfBuilder] split a paragraph on `" "`. That works for Vietnamese and English but breaks for
 * Chinese and Japanese (no spaces at all: the whole paragraph was one "word" and ran off the right edge of the page) and
 * for any single word wider than the page (a long URL). Where a line MAY end is a solved problem - Unicode Standard Annex
 * #14 (Line Breaking) - and Android ships it: `android.icu.text.BreakIterator.getLineInstance()` (API 24+, the project's
 * minSdk) returns those break opportunities, including the CJK rules (a line never starts with `。` `、` `）` `」` and never
 * ends with `（` `「`). This class only does the part UAX #14 leaves to "higher-level software": choosing, among the
 * allowed positions, the last one that still fits the width.
 *
 * Pure Kotlin, no Android types, so the algorithm can be (and is - `tools/verify/WrapCheck.java` is a line-by-line Java
 * port run by `text_wrap_check.py`) tested on a desktop JVM. Only the SOURCE of [boundaries] differs there
 * (`java.text.BreakIterator` instead of ICU).
 */
object TextWrapper {

    /**
     * Wraps ONE paragraph (no line feeds - split those off first).
     *
     * @param boundaries break opportunities as ascending offsets into [text] (what a line `BreakIterator` returns; the last
     *        one is `text.length`). A boundary is a place where a line may END; the whitespace in front of it belongs to the
     *        line that ends there and is not counted in its width and not kept in the output.
     * @param measure width of `text[start, end)` in the same unit as [maxWidth].
     * @return the lines, never empty strings, no leading or trailing whitespace. A piece with no break opportunity that is
     *         wider than [maxWidth] on its own (a very long URL, a long run of digits) is cut between code points - never
     *         between a letter and its combining accent - so nothing ever overflows by more than a single character.
     */
    fun wrap(text: String, maxWidth: Float, boundaries: IntArray, measure: (Int, Int) -> Float): List<String> {
        val n = text.length
        val lines = ArrayList<String>()
        val bs = if (boundaries.isNotEmpty() && boundaries[boundaries.size - 1] == n) boundaries else boundaries + n
        var start = skipWhitespace(text, 0)
        var bi = 0
        while (start < n) {
            while (bi < bs.size && bs[bi] <= start) bi++
            var best = -1
            var j = bi
            while (j < bs.size) {
                val b = bs[j]
                val end = trimEnd(text, start, b)
                if (end > start && measure(start, end) > maxWidth) break
                best = b
                j++
            }
            if (best < 0) best = splitInside(text, start, bs[bi], maxWidth, measure)
            val lineEnd = trimEnd(text, start, best)
            if (lineEnd > start) lines.add(text.substring(start, lineEnd))
            start = skipWhitespace(text, best)
        }
        return lines
    }

    /** Cuts the unbreakable piece `text[start, limit)` after as many whole characters (code point + its combining marks) as fit; at least one. */
    private fun splitInside(text: String, start: Int, limit: Int, maxWidth: Float, measure: (Int, Int) -> Float): Int {
        var k = start
        while (k < limit) {
            var next = k + Character.charCount(text.codePointAt(k))
            while (next < limit && isCombining(text.codePointAt(next))) next += Character.charCount(text.codePointAt(next))
            if (k > start && measure(start, trimEnd(text, start, next)) > maxWidth) break
            k = next
        }
        return k
    }

    private fun isCombining(cp: Int): Boolean = when (Character.getType(cp).toByte()) {
        Character.NON_SPACING_MARK, Character.ENCLOSING_MARK, Character.COMBINING_SPACING_MARK -> true
        else -> false
    }

    private fun skipWhitespace(text: String, from: Int): Int {
        var i = from
        while (i < text.length && Character.isWhitespace(text[i])) i++
        return i
    }

    private fun trimEnd(text: String, start: Int, end: Int): Int {
        var e = end
        while (e > start && Character.isWhitespace(text[e - 1])) e--
        return e
    }
}
