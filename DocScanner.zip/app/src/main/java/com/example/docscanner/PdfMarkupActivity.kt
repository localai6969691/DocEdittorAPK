package com.example.docscanner

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.docscanner.databinding.ActivityPdfMarkupBinding
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.OcrHelper
import com.example.docscanner.util.PdfExporter
import com.example.docscanner.util.PdfPageBitmap
import com.example.docscanner.util.PdfTextMarkup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Collections
import java.util.IdentityHashMap
import com.example.docscanner.util.SignedPdfGuard

/**
 * "Tô sáng & gạch chân chữ" (phiên 17): pick a PDF, mark text with a highlighter, underline or strike-out, and save a NEW PDF in which the
 * marks are real PDF annotations ([PdfTextMarkup]) - the page itself is not changed, so the text stays selectable and every reader can
 * remove the marks again. Two ways to choose the text: drag a frame over the words (the words whose centre is inside are marked, one band
 * per line; if the page has no readable word there, the frame itself becomes the mark), or type a phrase and let the app mark every
 * occurrence in the document (accents and case ignored). Words come from OCR of the rendered page, so scans and digital PDFs behave alike.
 * Style and colour can change between marks: each mark keeps the ones it was made with.
 */
class PdfMarkupActivity : BaseActivity() {

    private companion object {
        /** Longest edge of the picture OCR reads (the preview is 1400 px; small words need more detail). */
        const val OCR_MAX_EDGE = 2000

        class Swatch(@StringRes val nameRes: Int, val rgb: FloatArray)

        val SWATCHES = listOf(
            Swatch(R.string.markup_color_yellow, floatArrayOf(1.0f, 0.93f, 0.0f)),
            Swatch(R.string.markup_color_green, floatArrayOf(0.4f, 0.9f, 0.3f)),
            Swatch(R.string.markup_color_pink, floatArrayOf(1.0f, 0.45f, 0.75f)),
            Swatch(R.string.markup_color_blue, floatArrayOf(0.35f, 0.7f, 1.0f)),
            Swatch(R.string.markup_color_red, floatArrayOf(0.85f, 0.1f, 0.1f))
        )
        val STYLES = listOf(
            PdfTextMarkup.Style.HIGHLIGHT to R.string.markup_style_highlight,
            PdfTextMarkup.Style.UNDERLINE to R.string.markup_style_underline,
            PdfTextMarkup.Style.STRIKEOUT to R.string.markup_style_strike
        )
    }

    private lateinit var binding: ActivityPdfMarkupBinding
    private var srcFile: File? = null
    private var session: PdfPageBitmap.Session? = null
    private var pageCount = 0
    private var pageIndex = 0
    private var busy = false
    private var style = PdfTextMarkup.Style.HIGHLIGHT
    private var colorIndex = 0
    private val marks = HashMap<Int, MutableList<PdfTextMarkup.Mark>>()

    /** Marks added by "Tìm & tô" (by identity), so "Bỏ tô tự động" removes exactly those and keeps the hand-made ones. */
    private val autoMarks: MutableSet<PdfTextMarkup.Mark> = Collections.newSetFromMap(IdentityHashMap())

    /** OCR words per page, read once (OCR is the slow part) and reused by the drag selection and the phrase search. */
    private val wordCache = HashMap<Int, List<PdfTextMarkup.WordBox>>()

    private val onPdfChosen = ActivityResultCallback<Uri?> { uri ->
        if (uri == null) {
            finish()
            return@ActivityResultCallback
        }
        setBusy(true)
        lifecycleScope.launch {
            val copy = withContext(Dispatchers.IO) { FileUtils.copyUriToTempFile(this@PdfMarkupActivity, uri, ".pdf") }
            if (copy != null && !SignedPdfGuard.confirm(this@PdfMarkupActivity, copy)) {
                runCatching { copy.delete() }
                finish()
                return@launch
            }
            val opened = copy?.let { f -> withContext(Dispatchers.IO) { PdfPageBitmap.open(f) } }
            if (copy == null || opened == null) {
                copy?.let { runCatching { it.delete() } }
                Toast.makeText(this@PdfMarkupActivity, R.string.redact_open_failed, Toast.LENGTH_LONG).show()
                finish()
                return@launch
            }
            srcFile = copy
            session = opened
            pageCount = opened.pageCount
            showPage(0)
        }
    }

    private val pdfPicker = registerForActivityResult(ActivityResultContracts.OpenDocument(), onPdfChosen)

    /** A PDF handed over by another app ("Open with" / "Share") is used directly; otherwise the system picker opens. */
    private fun pickPdfOrUseIncoming() {
        val incoming = intent?.data
        if (incoming != null) onPdfChosen.onActivityResult(incoming) else pdfPicker.launch(arrayOf("application/pdf"))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPdfMarkupBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)
        title = getString(R.string.markup_title)
        binding.markupView.showFrame = false
        refreshButtons()
        binding.btnMarkupPrev.setOnClickListener { if (!busy && pageIndex > 0) showPage(pageIndex - 1) }
        binding.btnMarkupNext.setOnClickListener { if (!busy && pageIndex < pageCount - 1) showPage(pageIndex + 1) }
        binding.btnMarkupStyle.setOnClickListener { if (!busy) askStyle() }
        binding.btnMarkupColor.setOnClickListener { if (!busy) askColor() }
        binding.btnMarkupFind.setOnClickListener { if (!busy && session != null) askFind() }
        binding.btnMarkupFindClear.setOnClickListener { if (!busy) clearAutoMarks() }
        binding.btnMarkupUndo.setOnClickListener {
            marks[pageIndex]?.let { if (it.isNotEmpty()) autoMarks.remove(it.removeAt(it.size - 1)) }
            refreshView()
        }
        binding.btnMarkupSave.setOnClickListener { confirmAndSave() }
        binding.markupView.onBoxAdded = { frame -> if (!busy) markFrame(frame) }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                val made = marks.values.sumOf { it.size }
                if (made == 0 || busy) {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                } else {
                    AlertDialog.Builder(this@PdfMarkupActivity)
                        .setMessage(getString(R.string.markup_discard, made))
                        .setNegativeButton(R.string.dialog_cancel, null)
                        .setPositiveButton(R.string.sign_discard_exit) { _, _ ->
                            isEnabled = false
                            onBackPressedDispatcher.onBackPressed()
                        }
                        .show()
                }
            }
        })
        pickPdfOrUseIncoming()
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { session?.close() }
        session = null
        if (isFinishing) srcFile?.let { runCatching { it.delete() } }
    }

    private fun setBusy(value: Boolean) {
        busy = value
        binding.markupProgress.visibility = if (value) View.VISIBLE else View.GONE
        binding.btnMarkupSave.isEnabled = !value
        binding.btnMarkupUndo.isEnabled = !value
        binding.btnMarkupFind.isEnabled = !value
        binding.btnMarkupFindClear.isEnabled = !value
    }

    private fun refreshButtons() {
        binding.btnMarkupStyle.text = getString(R.string.markup_style_label, getString(STYLES.first { it.first == style }.second))
        binding.btnMarkupColor.text = getString(R.string.markup_color_label, getString(SWATCHES[colorIndex].nameRes))
    }

    private fun previewColor(m: PdfTextMarkup.Mark): Int {
        val alpha = if (m.style == PdfTextMarkup.Style.HIGHLIGHT) 120 else 90
        return Color.argb(alpha, (m.rgb[0] * 255).toInt(), (m.rgb[1] * 255).toInt(), (m.rgb[2] * 255).toInt())
    }

    private fun refreshView() {
        val list = marks[pageIndex].orEmpty()
        binding.markupView.setBoxes(list.map { it.box })
        binding.markupView.setBoxColors(IntArray(list.size) { previewColor(list[it]) })
    }

    private fun showPage(index: Int) {
        val s = session ?: return
        pageIndex = index
        binding.tvMarkupPage.text = getString(R.string.annotate_page_indicator, index + 1, pageCount)
        binding.btnMarkupPrev.isEnabled = index > 0
        binding.btnMarkupNext.isEnabled = index < pageCount - 1
        setBusy(true)
        lifecycleScope.launch {
            val bmp: Bitmap? = withContext(Dispatchers.Default) { s.render(index, 1400) }
            if (index == pageIndex) {
                binding.markupView.setPage(bmp)
                refreshView()
            }
            setBusy(false)
        }
    }

    private fun askStyle() {
        AlertDialog.Builder(this)
            .setTitle(R.string.markup_style_title)
            .setItems(STYLES.map { getString(it.second) }.toTypedArray()) { _, which ->
                style = STYLES[which].first
                refreshButtons()
            }
            .show()
    }

    private fun askColor() {
        AlertDialog.Builder(this)
            .setTitle(R.string.markup_color_title)
            .setItems(SWATCHES.map { getString(it.nameRes) }.toTypedArray()) { _, which ->
                colorIndex = which
                refreshButtons()
            }
            .show()
    }

    private fun addMarks(page: Int, boxes: List<FloatArray>, auto: Boolean) {
        val rgb = SWATCHES[colorIndex].rgb
        val list = marks.getOrPut(page) { ArrayList() }
        for (b in boxes) {
            val m = PdfTextMarkup.Mark(b, style, rgb)
            list.add(m)
            if (auto) autoMarks.add(m)
        }
    }

    /** Words of [page] as boxes on the displayed page (fractions); cached: from the PDF's own text layer when it has one (util.PdfTextLayer), else OCR. Empty when the page cannot be rendered or read. */
    private suspend fun wordsFor(page: Int): List<PdfTextMarkup.WordBox> {
        wordCache[page]?.let { return it }
        // the PDF's own text layer first (exact, no rendering); a scan has none, so then OCR
        srcFile?.let { f ->
            val layer = withContext(Dispatchers.IO) { com.example.docscanner.util.PdfTextLayer.words(f, page) }
            if (layer != null && layer.size >= 3) {
                wordCache[page] = layer
                return layer
            }
        }
        val s = session ?: return emptyList()
        val bmp: Bitmap = withContext(Dispatchers.Default) { s.render(page, OCR_MAX_EDGE) } ?: return emptyList()
        val list = ArrayList<PdfTextMarkup.WordBox>()
        try {
            val w = bmp.width.toFloat()
            val h = bmp.height.toFloat()
            val lines = OcrHelper.recognizeLines(bmp, OcrHelper.OcrScript.LATIN)
            lines.forEachIndexed { lineIndex, line ->
                for (word in line.words) {
                    val b = word.box
                    list.add(PdfTextMarkup.WordBox(word.text, floatArrayOf(b.left / w, b.top / h, b.right / w, b.bottom / h), lineIndex))
                }
            }
        } finally {
            bmp.recycle()
        }
        wordCache[page] = list
        return list
    }

    /** A frame dragged on the page: mark the words under it, or the frame itself when no word is there. */
    private fun markFrame(frame: FloatArray) {
        val page = pageIndex
        setBusy(true)
        lifecycleScope.launch {
            val words = wordsFor(page)
            val chosen = PdfTextMarkup.wordsInRect(words, frame)
            val boxes = if (chosen.isEmpty()) listOf(frame) else PdfTextMarkup.lineBoxes(words, chosen)
            addMarks(page, boxes, false)
            setBusy(false)
            if (page == pageIndex) refreshView()
        }
    }

    private fun askFind() {
        val input = EditText(this).apply {
            setSingleLine()
            hint = getString(R.string.markup_find_hint)
            val pad = (16 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.markup_find_title)
            .setView(input)
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.markup_find_go) { _, _ ->
                val q = input.text.toString().trim()
                if (q.isNotEmpty()) runFind(q)
            }
            .show()
    }

    /** Reads every page (one at a time, so memory stays flat) and marks each occurrence of [query]; nothing is saved until "Lưu". */
    private fun runFind(query: String) {
        setBusy(true)
        lifecycleScope.launch {
            var hits = 0
            val pagesHit = HashSet<Int>()
            for (page in 0 until pageCount) {
                binding.tvMarkupPage.text = getString(R.string.markup_find_progress, page + 1, pageCount)
                val words = wordsFor(page)
                val ranges = PdfTextMarkup.findPhrase(words, query)
                if (ranges.isEmpty()) continue
                for (r in ranges) addMarks(page, PdfTextMarkup.lineBoxes(words, r.toList()), true)
                hits += ranges.size
                pagesHit.add(page)
            }
            setBusy(false)
            showPage(pageIndex)
            Toast.makeText(
                this@PdfMarkupActivity,
                if (hits == 0) getString(R.string.markup_find_none) else getString(R.string.markup_find_result, hits, pagesHit.size),
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun clearAutoMarks() {
        var removed = 0
        marks.values.forEach { list -> removed += list.count { it in autoMarks }; list.removeAll { it in autoMarks } }
        autoMarks.clear()
        refreshView()
        Toast.makeText(this, getString(R.string.markup_find_cleared, removed), Toast.LENGTH_SHORT).show()
    }

    private fun confirmAndSave() {
        val src = srcFile ?: return
        val made = marks.filterValues { it.isNotEmpty() }
        if (made.isEmpty()) {
            Toast.makeText(this, R.string.markup_nothing, Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(R.string.markup_confirm_title)
            .setMessage(getString(R.string.markup_confirm_message, made.values.sumOf { it.size }, made.size))
            .setNegativeButton(R.string.dialog_cancel, null)
            .setPositiveButton(R.string.markup_save) { _, _ -> save(src, made.mapValues { e -> e.value.toList() }) }
            .show()
    }

    private fun save(src: File, byPage: Map<Int, List<PdfTextMarkup.Mark>>) {
        setBusy(true)
        val out = File(PdfExporter.exportDir(this), "${FileUtils.defaultSecurityName("highlighted")}.pdf")
        lifecycleScope.launch {
            val result = runCatching { withContext(Dispatchers.Default) { PdfTextMarkup.annotate(src, out, byPage) } }
            setBusy(false)
            if (result.isFailure) {
                runCatching { out.delete() }
                val encrypted = result.exceptionOrNull()?.message == "encrypted"
                Toast.makeText(this@PdfMarkupActivity, if (encrypted) R.string.sign_encrypted else R.string.markup_failed, Toast.LENGTH_LONG).show()
                return@launch
            }
            marks.clear()
            Toast.makeText(this@PdfMarkupActivity, getString(R.string.markup_done, out.name, result.getOrNull() ?: 0), Toast.LENGTH_LONG).show()
            finish()
        }
    }
}
