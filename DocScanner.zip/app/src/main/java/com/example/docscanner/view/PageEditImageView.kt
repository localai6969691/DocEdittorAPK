package com.example.docscanner.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import androidx.appcompat.widget.AppCompatImageView
import com.example.docscanner.util.PdfInk
import com.example.docscanner.util.PdfTextMarkup
import com.example.docscanner.util.ReaderEdits

/**
 * One page of the PDF reader, which can also be drawn on (session 23, 4.61). With no tool the view lets touches pass to the list (scrolling). With a tool active a drag
 * on the page draws a frame ([ReaderEdits.frame]) and a tap places text; the marks already made are drawn over the page. The view is exactly as large as the page picture
 * (full width, height from the picture), so a touch point divided by the view size IS the position on the page.
 * The marks are only drawn here; they reach the PDF when the reader saves a copy.
 */
class PageEditImageView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : AppCompatImageView(context, attrs) {

    /** The active tool, or null for plain reading. */
    var tool: ReaderEdits.Kind? = null

    /** The marks of this page; replacing the list redraws. */
    var overlays: List<ReaderEdits.Item> = emptyList()
        set(value) {
            field = value
            invalidate()
        }

    /** A frame was dragged: box 0..1 on this page (the black box; the text tools use [onTextDrag]). */
    var onFrame: ((FloatArray) -> Unit)? = null

    /**
     * The highlight, underline or strike-out tool was dragged (or tapped): start x, y and end x, y as fractions 0..1 of the page. The reader turns it into the words between the two points
     * (like selecting text), or into the dragged rectangle where there is no text under the start.
     */
    var onTextDrag: ((Float, Float, Float, Float) -> Unit)? = null

    /** The words of this page (set while a text tool is active): the drag is previewed as the words it will mark, line by line. */
    var words: List<PdfTextMarkup.WordBox> = emptyList()

    /** Where the words searched for sit on this page (boxes 0..1): painted orange under the marks until a new search or another file replaces them (4.77). */
    var searchBoxes: List<FloatArray> = emptyList()

    /** The pieces of existing text of this page that the edit-text tool can change, as boxes 0..1 (outlined faintly while that tool is active so the person sees what can be tapped). */
    var textBoxes: List<FloatArray> = emptyList()

    /** The text tool or the edit-text tool was tapped: x, y (view pixels) and the view's width and height. */
    var onTap: ((Float, Float, Float, Float) -> Unit)? = null

    /** The pen or the marker finished a stroke: x0, y0, x1, y1, ... as fractions 0..1 of this page. */
    var onStroke: ((FloatArray) -> Unit)? = null

    /** The eraser touched the page (on the first touch and as the finger moves): x, y (view pixels) and the view's width and height. */
    var onErase: ((Float, Float, Float, Float) -> Unit)? = null

    /** Thickness of the stroke being drawn, as a fraction of the page width; 0 = the tool's usual thickness (4.72). */
    var toolWidth: Float = 0f

    /** Colour of the stroke being drawn: the colour picked for the active tool (the pen and the marker alike, 4.69; the marker is drawn translucent). */
    var toolColor: Int = ReaderEdits.DEFAULT_COLOR

    private val density = resources.displayMetrics.density
    private val highlightPaint = Paint().apply { color = Color.argb(110, 255, 235, 59); style = Paint.Style.FILL }
    private val blackPaint = Paint().apply { color = Color.argb(215, 0, 0, 0); style = Paint.Style.FILL }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(217, 26, 26); style = Paint.Style.STROKE; strokeWidth = 2f * density }
    private val previewPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(25, 118, 210); style = Paint.Style.STROKE; strokeWidth = 2f * density }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(217, 26, 26) }
    private val selectionPaint = Paint().apply { color = Color.argb(90, 25, 118, 210); style = Paint.Style.FILL }
    private val textBoxPaint = Paint().apply { color = Color.argb(150, 25, 118, 210); style = Paint.Style.STROKE; strokeWidth = 1f * density }
    private val searchPaint = Paint().apply { color = Color.argb(110, 255, 152, 0); style = Paint.Style.FILL }
    private val coverPaint = Paint().apply { color = Color.WHITE; style = Paint.Style.FILL }
    private val newTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(20, 20, 20) }
    private var selection: List<FloatArray> = emptyList()

    private var dragging = false
    private val live = ArrayList<Float>()
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private var startX = 0f
    private var startY = 0f
    private var curX = 0f
    private var curY = 0f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val active = tool
        if (active == null || drawable == null) return super.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // the page keeps the drag: the list must not start scrolling while a frame is being drawn
                parent?.requestDisallowInterceptTouchEvent(true)
                startX = e.x
                startY = e.y
                curX = e.x
                curY = e.y
                dragging = true
                live.clear()
                selection = emptyList()
                if (active == ReaderEdits.Kind.ERASER) onErase?.invoke(e.x, e.y, width.toFloat(), height.toFloat())
                if (isStroke(active)) addLive(e.x, e.y)
                if (ReaderEdits.isTextMark(active)) updateSelection(e.x, e.y)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                curX = e.x
                curY = e.y
                if (active == ReaderEdits.Kind.ERASER) onErase?.invoke(e.x, e.y, width.toFloat(), height.toFloat())
                if (isStroke(active)) for (i in 0 until e.historySize) addLive(e.getHistoricalX(i), e.getHistoricalY(i))
                if (isStroke(active)) addLive(e.x, e.y)
                if (ReaderEdits.isTextMark(active)) updateSelection(e.x, e.y)
                invalidate()
            }
            MotionEvent.ACTION_UP -> if (dragging) {
                dragging = false
                invalidate()
                if (isStroke(active)) {
                    addLive(e.x, e.y)
                    if (live.isNotEmpty()) onStroke?.invoke(live.toFloatArray())
                    live.clear()
                } else if (active == ReaderEdits.Kind.TEXT || active == ReaderEdits.Kind.EDITTEXT) {
                    onTap?.invoke(e.x, e.y, width.toFloat(), height.toFloat())
                } else if (ReaderEdits.isTextMark(active)) {
                    selection = emptyList()
                    if (width > 0 && height > 0) onTextDrag?.invoke(startX / width, startY / height, e.x / width, e.y / height)
                } else {
                    val box = ReaderEdits.frame(startX, startY, e.x, e.y, width.toFloat(), height.toFloat())
                    if (box != null) onFrame?.invoke(box)
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                live.clear()
                selection = emptyList()
                invalidate()
            }
        }
        return true
    }

    private fun isStroke(kind: ReaderEdits.Kind?): Boolean = kind == ReaderEdits.Kind.PEN || kind == ReaderEdits.Kind.MARKER

    /** Recomputes the words that the drag from its start to (x, y) would mark; empty when this page has no words or the drag did not start on text (the rectangle shows instead). */
    private fun updateSelection(x: Float, y: Float) {
        selection = if (words.isEmpty() || width <= 0 || height <= 0) emptyList()
        else PdfTextMarkup.selectionBoxes(words, startX / width, startY / height, x / width, y / height) ?: emptyList()
    }

    /** Adds a point as fractions of the page; past a cap a long scribble stops growing (the saved stroke is thinned anyway, see PdfInk.simplifyCapped). */
    private fun addLive(x: Float, y: Float) {
        if (width <= 0 || height <= 0 || live.size >= 12000) return
        live.add((x / width).coerceIn(0f, 1f))
        live.add((y / height).coerceIn(0f, 1f))
    }

    private fun drawStroke(canvas: Canvas, points: FloatArray, color: Int, marker: Boolean, widthFraction: Float, w: Float, h: Float) {
        if (points.size < 2) return
        val usual = if (marker) PdfInk.MARKER_WIDTH else PdfInk.PEN_WIDTH
        val thickness = maxOf((if (widthFraction > 0f) widthFraction else usual) * w, 1.5f * density)
        val shown = if (marker) Color.argb((PdfInk.MARKER_OPACITY * 255).toInt(), Color.red(color), Color.green(color), Color.blue(color)) else color
        if (points.size == 2) {
            dotPaint.color = shown
            canvas.drawCircle(points[0] * w, points[1] * h, thickness / 2f, dotPaint)
            return
        }
        val path = Path()
        path.moveTo(points[0] * w, points[1] * h)
        var i = 2
        while (i + 1 < points.size) {
            path.lineTo(points[i] * w, points[i + 1] * h)
            i += 2
        }
        strokePaint.color = shown
        strokePaint.strokeWidth = thickness
        canvas.drawPath(path, strokePaint)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        for (b in searchBoxes) {
            canvas.drawRect(b[0] * w, b[1] * h, b[2] * w, b[3] * h, searchPaint)
        }
        if (tool == ReaderEdits.Kind.EDITTEXT) {
            for (b in textBoxes) {
                canvas.drawRect(b[0] * w, b[1] * h, b[2] * w, b[3] * h, textBoxPaint)
            }
        }
        for (item in overlays) drawItem(canvas, item, w, h)
        if (dragging && isStroke(tool)) {
            drawStroke(canvas, live.toFloatArray(), toolColor, tool == ReaderEdits.Kind.MARKER, toolWidth, w, h)
        } else if (dragging && selection.isNotEmpty()) {
            for (b in selection) canvas.drawRect(b[0] * w, b[1] * h, b[2] * w, b[3] * h, selectionPaint)
        } else if (dragging && tool != null && tool != ReaderEdits.Kind.TEXT && tool != ReaderEdits.Kind.EDITTEXT && tool != ReaderEdits.Kind.ERASER) {
            canvas.drawRect(minOf(startX, curX), minOf(startY, curY), maxOf(startX, curX), maxOf(startY, curY), previewPaint)
        }
    }

    private fun drawItem(canvas: Canvas, item: ReaderEdits.Item, w: Float, h: Float) {
        val b = item.box
        val r = RectF(b[0] * w, b[1] * h, b[2] * w, b[3] * h)
        when (item.kind) {
            ReaderEdits.Kind.HIGHLIGHT -> {
                highlightPaint.color = Color.argb(110, Color.red(item.color), Color.green(item.color), Color.blue(item.color))
                canvas.drawRect(r, highlightPaint)
            }
            ReaderEdits.Kind.UNDERLINE -> { linePaint.color = item.color; canvas.drawLine(r.left, r.bottom, r.right, r.bottom, linePaint) }
            ReaderEdits.Kind.STRIKE -> { linePaint.color = item.color; canvas.drawLine(r.left, r.centerY(), r.right, r.centerY(), linePaint) }
            ReaderEdits.Kind.PEN -> item.points?.let { drawStroke(canvas, it, item.color, false, item.width, w, h) }
            ReaderEdits.Kind.MARKER -> item.points?.let { drawStroke(canvas, it, item.color, true, item.width, w, h) }
            ReaderEdits.Kind.BLACKBOX -> canvas.drawRect(r, blackPaint)
            ReaderEdits.Kind.FORM -> {
                // a preview only: a typed value is drawn over the field (a check box gets a tick, or its old mark is covered); the saved copy has the field really filled in
                val text = item.text ?: return
                canvas.drawRect(r, coverPaint)
                val checkbox = text == "true" || text == "false"
                val shown = if (checkbox) (if (text == "true") "\u2713" else "") else text
                if (shown.isNotEmpty()) {
                    newTextPaint.textSize = r.height() * 0.7f
                    val measured = newTextPaint.measureText(shown)
                    if (measured > r.width() && measured > 0f) newTextPaint.textSize = newTextPaint.textSize * r.width() / measured
                    val y = r.centerY() - (newTextPaint.descent() + newTextPaint.ascent()) / 2f
                    canvas.drawText(shown, if (checkbox) r.centerX() - newTextPaint.measureText(shown) / 2f else r.left, y, newTextPaint)
                }
            }
            ReaderEdits.Kind.ERASER -> {
                // a tool, never a mark: nothing to draw
            }
            ReaderEdits.Kind.PARAGRAPH -> {
                // the paragraph's new wording only exists in the saved copy: here its frame is outlined
                canvas.drawRect(r, previewPaint)
            }
            ReaderEdits.Kind.PICTURE -> {
                // a preview only (4.88): a deleted picture is covered and crossed out, any other change is outlined; the copy that is saved has the picture really changed
                if (item.text == ReaderEdits.PICTURE_DELETE) {
                    canvas.drawRect(r, coverPaint)
                    canvas.drawLine(r.left, r.top, r.right, r.bottom, linePaint)
                    canvas.drawLine(r.left, r.bottom, r.right, r.top, linePaint)
                } else {
                    canvas.drawRect(r, previewPaint)
                }
            }
            ReaderEdits.Kind.EDITTEXT -> {
                // a preview only: the old words are covered and the new ones drawn fitted into the same box; the copy that is saved has the real text in the page's own font
                val text = item.text ?: return
                canvas.drawRect(r, coverPaint)
                newTextPaint.textSize = r.height() * 0.8f
                val measured = newTextPaint.measureText(text)
                if (measured > r.width() && measured > 0f) newTextPaint.textSize = newTextPaint.textSize * r.width() / measured
                val y = r.centerY() - (newTextPaint.descent() + newTextPaint.ascent()) / 2f
                canvas.drawText(text, r.left, y, newTextPaint)
            }
            ReaderEdits.Kind.TEXT -> {
                val text = item.text ?: return
                textPaint.color = item.color
                textPaint.textSize = r.height() * 0.75f
                val measured = textPaint.measureText(text)
                if (measured > r.width() && measured > 0f) textPaint.textSize = textPaint.textSize * r.width() / measured
                val x = r.centerX() - textPaint.measureText(text) / 2f
                val y = r.centerY() - (textPaint.descent() + textPaint.ascent()) / 2f
                canvas.drawText(text, x, y, textPaint)
            }
        }
    }
}
