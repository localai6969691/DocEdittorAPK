package com.example.docscanner.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import androidx.appcompat.widget.AppCompatImageView
import com.example.docscanner.util.ReaderEdits

/**
 * One page of the PDF reader, which can also be drawn on (session 23, 4.61). With no tool the view lets touches pass to the list (scrolling). With a tool active a drag
 * on the page draws a frame ([ReaderEdits.frame]) and a tap places text; the marks already made are drawn over the page. The view is exactly as large as the page picture
 * (full width, height from the picture), so a touch point divided by the view size IS the position on the page.
 * The marks are only drawn here; they reach the PDF when the reader saves a copy.
 */
class PageEditImageView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : AppCompatImageView(context, attrs) {

    /** The active tool, or null for plain reading. */
    var tool: ReaderEdits.Kind? = null

    /** The marks of this page; replacing the list redraws. */
    var overlays: List<ReaderEdits.Item> = emptyList()
        set(value) {
            field = value
            invalidate()
        }

    /** A frame was dragged: box 0..1 on this page. */
    var onFrame: ((FloatArray) -> Unit)? = null

    /** The text tool was tapped: x, y (view pixels) and the view's width and height. */
    var onTap: ((Float, Float, Float, Float) -> Unit)? = null

    private val density = resources.displayMetrics.density
    private val highlightPaint = Paint().apply { color = Color.argb(110, 255, 235, 59); style = Paint.Style.FILL }
    private val blackPaint = Paint().apply { color = Color.argb(215, 0, 0, 0); style = Paint.Style.FILL }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(217, 26, 26); style = Paint.Style.STROKE; strokeWidth = 2f * density }
    private val previewPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(25, 118, 210); style = Paint.Style.STROKE; strokeWidth = 2f * density }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(217, 26, 26) }

    private var dragging = false
    private var startX = 0f
    private var startY = 0f
    private var curX = 0f
    private var curY = 0f

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val active = tool
        if (active == null || drawable == null) return super.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // the page keeps the drag: the list must not start scrolling while a frame is being drawn
                parent?.requestDisallowInterceptTouchEvent(true)
                startX = e.x
                startY = e.y
                curX = e.x
                curY = e.y
                dragging = true
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                curX = e.x
                curY = e.y
                invalidate()
            }
            MotionEvent.ACTION_UP -> if (dragging) {
                dragging = false
                invalidate()
                if (active == ReaderEdits.Kind.TEXT) {
                    onTap?.invoke(e.x, e.y, width.toFloat(), height.toFloat())
                } else {
                    val box = ReaderEdits.frame(startX, startY, e.x, e.y, width.toFloat(), height.toFloat())
                    if (box != null) onFrame?.invoke(box)
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                invalidate()
            }
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        for (item in overlays) drawItem(canvas, item, w, h)
        if (dragging && tool != null && tool != ReaderEdits.Kind.TEXT) {
            canvas.drawRect(minOf(startX, curX), minOf(startY, curY), maxOf(startX, curX), maxOf(startY, curY), previewPaint)
        }
    }

    private fun drawItem(canvas: Canvas, item: ReaderEdits.Item, w: Float, h: Float) {
        val b = item.box
        val r = RectF(b[0] * w, b[1] * h, b[2] * w, b[3] * h)
        when (item.kind) {
            ReaderEdits.Kind.HIGHLIGHT -> canvas.drawRect(r, highlightPaint)
            ReaderEdits.Kind.UNDERLINE -> canvas.drawLine(r.left, r.bottom, r.right, r.bottom, linePaint)
            ReaderEdits.Kind.STRIKE -> canvas.drawLine(r.left, r.centerY(), r.right, r.centerY(), linePaint)
            ReaderEdits.Kind.BLACKBOX -> canvas.drawRect(r, blackPaint)
            ReaderEdits.Kind.TEXT -> {
                val text = item.text ?: return
                textPaint.textSize = r.height() * 0.75f
                val measured = textPaint.measureText(text)
                if (measured > r.width() && measured > 0f) textPaint.textSize = textPaint.textSize * r.width() / measured
                val x = r.centerX() - textPaint.measureText(text) / 2f
                val y = r.centerY() - (textPaint.descent() + textPaint.ascent()) / 2f
                canvas.drawText(text, x, y, textPaint)
            }
        }
    }
}
