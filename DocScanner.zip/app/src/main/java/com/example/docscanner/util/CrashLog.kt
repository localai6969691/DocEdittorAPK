package com.example.docscanner.util

import android.content.Context
import android.os.Build
import androidx.core.content.pm.PackageInfoCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * A crash log that stays on the phone. No Firebase / Crashlytics: those need an account and a `google-services.json`, and
 * would upload data the user never agreed to. Instead the uncaught-exception handler writes a short text file; the next
 * launch ASKS whether to send it (a share sheet - the user sees the whole text and picks the mail / chat app), and the Help
 * screen can send it later.
 *
 * Privacy: the report holds the app and Android version, the device model, and for each exception its class, its stack
 * frames (class and line numbers of OUR code) and its message - EXCEPT a message that contains a '/' or '\', because
 * those are file paths and a path can carry the name of a document ("Hop dong CCCD.pdf"). See [describe].
 */
object CrashLog {
    private const val DIR = "crash"
    private const val KEEP = 3
    private const val MAX_CHARS = 20_000
    private const val ASKED_SUFFIX = ".asked"

    const val HIDDEN_MESSAGE = "(message hidden: it may contain a file path)"

    /** Installs the handler; the previous handler (the system's, which shows the "app stopped" dialog) still runs afterwards. */
    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                write(app, thread.name, error)
            } catch (t: Throwable) {
                // never let the logger hide the real crash
            }
            previous?.uncaughtException(thread, error)
        }
    }

    /** The newest report. Unless [includeAsked], only one the user has not been asked about yet. */
    fun latest(context: Context, includeAsked: Boolean = false): File? =
        dir(context).listFiles()
            ?.filter { it.isFile && (includeAsked || !it.name.endsWith(ASKED_SUFFIX)) }
            ?.maxByOrNull { it.lastModified() }

    /** Remembers that the user was asked about [file] (renames it, keeping it for the Help screen). */
    fun markAsked(file: File) {
        if (!file.name.endsWith(ASKED_SUFFIX)) runCatching { file.renameTo(File(file.parentFile, file.name + ASKED_SUFFIX)) }
    }

    /** Text to send: device line + the report. */
    fun reportText(context: Context, file: File): String = deviceLine(context) + "\n\n" + file.readText(Charsets.UTF_8)

    /** "DocScanner 1.0 (23) | Android 14 (API 34) | Samsung SM-A546B" */
    fun deviceLine(context: Context): String {
        val version = try {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            "${info.versionName} (${PackageInfoCompat.getLongVersionCode(info)})"
        } catch (e: Exception) {
            "?"
        }
        return "DocScanner $version | Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) | ${Build.MANUFACTURER} ${Build.MODEL}"
    }

    private fun dir(context: Context): File = File(context.filesDir, DIR).apply { mkdirs() }

    private fun write(context: Context, threadName: String, error: Throwable) {
        val stamp = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())
        val body = "Time: $stamp\nThread: $threadName\n\n" + describe(error)
        File(dir(context), "crash-$stamp.txt").writeText(body.take(MAX_CHARS), Charsets.UTF_8)
        dir(context).listFiles()?.sortedByDescending { it.lastModified() }?.drop(KEEP)?.forEach { runCatching { it.delete() } }
    }

    /**
     * The exception and its causes: class name, message (hidden if it looks like a path), then at most [maxFrames] stack frames
     * each. Pure function (no Android types) so `tools/verify/crash_log_check.py` can run a Java copy of it.
     */
    fun describe(error: Throwable, maxFrames: Int = 25): String {
        val sb = StringBuilder()
        var current: Throwable? = error
        var depth = 0
        while (current != null && depth < 6) {
            sb.append(if (depth == 0) "" else "Caused by: ").append(current.javaClass.name)
            val message = current.message
            if (!message.isNullOrBlank()) {
                sb.append(": ").append(if (message.contains('/') || message.contains('\\')) HIDDEN_MESSAGE else message.take(300))
            }
            sb.append('\n')
            current.stackTrace.take(maxFrames).forEach { sb.append("    at ").append(it.toString()).append('\n') }
            current = if (current.cause === current) null else current.cause
            depth++
        }
        return sb.toString()
    }
}
