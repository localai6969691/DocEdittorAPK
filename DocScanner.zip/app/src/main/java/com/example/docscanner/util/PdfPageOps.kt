package com.example.docscanner.util

import com.tom_roush.pdfbox.cos.COSArray
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.PDPage
import com.tom_roush.pdfbox.pdmodel.PDPageTree
import java.io.File

/**
 * Rotate, delete and re-order the pages of a PDF FOR REAL (phiên 24, TECHNICAL_DOCS.md 4.64; "other readers can do it, why can't we" of 4.62). The older page editor
 * ([PageEditorTools], [com.example.docscanner.PdfPageEditorActivity]) rebuilds the file from page IMAGES, so text, links and vector drawings are lost; this edits the page TREE of
 * the document itself, so every page keeps its text layer, fonts, links and quality, and a 300-page book is not turned into 300 pictures.
 *
 * The change is described by a plan, a list of [Entry]: result page n is original page `source` turned by `turn` more degrees. Deleting = leaving a page out, re-ordering =
 * the order of the list, rotating = `turn`. A page can appear only once (no duplicate: a copy would share one page object). The planning functions are PURE and the
 * reader / page manager screen only edits the plan until the person saves.
 *
 * What [apply] does besides moving pages (each a rule that a viewer would otherwise notice):
 *  - inheritable page attributes (Resources, MediaBox, CropBox, Rotate) that a page got from an intermediate /Pages node are copied onto the page first, because the new tree is
 *    FLAT (every page directly under the root) and would otherwise lose them;
 *  - the old tree is dropped in one step (the root's /Kids is emptied before the pages are added again; the pages are NOT removed one by one first, which would only matter
 *    for the counts of nodes that are thrown away anyway and would fail on a page without /Parent), so no empty /Pages nodes are left behind;
 *  - bookmarks follow their page to its new position; a bookmark whose page was deleted is dropped ([remapBookmarks]);
 *  - /PageLabels (page numbering such as "i, ii, 1, 2") counts positions, so it is removed whenever pages are deleted or re-ordered (a pure rotation keeps it).
 * NOT handled (honest list, also in 4.64): a form field or a link whose target page was deleted stays in the file and points to a page that no longer exists (viewers ignore it);
 * a PDF that carries a digital signature loses it (the screen asks first with [SignedPdfGuard], like every other edit).
 */
object PdfPageOps {

    /** Result page = original page [source] (0-based) turned [turn] more degrees clockwise (0, 90, 180 or 270). */
    class Entry(val source: Int, val turn: Int) {
        override fun equals(other: Any?): Boolean = other is Entry && other.source == source && other.turn == turn
        override fun hashCode(): Int = source * 31 + turn
        override fun toString(): String = "$source:$turn"
    }

    // ---------------------------------------------------------------- pure planning

    fun identity(count: Int): List<Entry> = List(maxOf(0, count)) { Entry(it, 0) }

    /** Only multiples of 90 are meaningful; anything else is cut toward zero first. Always 0, 90, 180 or 270. */
    fun normalizeTurn(degrees: Int): Int = (((degrees / 90) % 4) + 4) % 4 * 90

    /** Turns the page at [position] (0-based position in the RESULT) by [delta] degrees; an unknown position changes nothing. */
    fun rotated(plan: List<Entry>, position: Int, delta: Int): List<Entry> {
        if (position < 0 || position >= plan.size) return plan
        return plan.mapIndexed { i, e -> if (i == position) Entry(e.source, normalizeTurn(e.turn + delta)) else e }
    }

    /** Leaves out the page at [position]. The LAST remaining page is never deleted (a PDF needs at least one page). */
    fun deleted(plan: List<Entry>, position: Int): List<Entry> {
        if (position < 0 || position >= plan.size || plan.size <= 1) return plan
        return plan.filterIndexed { i, _ -> i != position }
    }

    /** Moves the page at [from] so that it ends up at position [to] (both 0-based positions in the result). */
    fun moved(plan: List<Entry>, from: Int, to: Int): List<Entry> {
        if (from < 0 || from >= plan.size || to < 0 || to >= plan.size || from == to) return plan
        val copy = ArrayList(plan)
        val item = copy.removeAt(from)
        copy.add(to, item)
        return copy
    }

    /** A usable plan: not empty, every source inside the original and used once, every turn 0 / 90 / 180 / 270. */
    fun isValid(plan: List<Entry>, originalCount: Int): Boolean {
        if (plan.isEmpty() || originalCount <= 0) return false
        val seen = HashSet<Int>()
        for (e in plan) {
            if (e.source < 0 || e.source >= originalCount) return false
            if (e.turn != 0 && e.turn != 90 && e.turn != 180 && e.turn != 270) return false
            if (!seen.add(e.source)) return false
        }
        return true
    }

    /** True when saving would give the same file content (every page in place, none turned). */
    fun isUnchanged(plan: List<Entry>, originalCount: Int): Boolean {
        if (plan.size != originalCount) return false
        for (i in plan.indices) if (plan[i].source != i || plan[i].turn != 0) return false
        return true
    }

    /** True when the SEQUENCE of pages changed (some deleted or moved), which is when page numbering ([PageLabels]) no longer fits. */
    fun orderChanged(plan: List<Entry>, originalCount: Int): Boolean {
        if (plan.size != originalCount) return true
        for (i in plan.indices) if (plan[i].source != i) return true
        return false
    }

    /** Bookmarks of the NEW file: each follows its page to the new position, in the old outline order; a bookmark of a deleted page (or with no page, -1) is dropped. */
    fun remapBookmarks(entries: List<PdfBookmarks.Entry>, plan: List<Entry>): List<PdfBookmarks.Entry> {
        val newPosition = HashMap<Int, Int>()
        for (i in plan.indices) newPosition[plan[i].source] = i
        val out = ArrayList<PdfBookmarks.Entry>()
        for (e in entries) {
            val position = newPosition[e.page] ?: continue
            out.add(PdfBookmarks.Entry(e.title, e.level, position))
        }
        return out
    }

    // ---------------------------------------------------------------- PdfBox

    private val INHERITABLE = listOf(COSName.RESOURCES, COSName.MEDIA_BOX, COSName.CROP_BOX, COSName.ROTATE)

    /** Writes the attributes a page inherits from a /Pages node onto the page itself (a flat tree has no node to inherit from). */
    private fun materializeInherited(page: PDPage) {
        val dict = page.cosObject
        for (key in INHERITABLE) {
            if (dict.getDictionaryObject(key) != null) continue
            val inherited = PDPageTree.getInheritableAttribute(dict, key)
            if (inherited != null) dict.setItem(key, inherited)
        }
    }

    /**
     * Applies [plan] to [src] and writes [out] (never the same file as [src]). @return the number of pages written, or -1 when the plan does not fit the file, the file is
     * encrypted (the reader works on an unlocked copy) or anything fails; [out] is removed in that case.
     */
    fun apply(src: File, out: File, plan: List<Entry>): Int {
        var doc: PDDocument? = null
        return try {
            val d = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
            doc = d
            if (d.isEncrypted) return -1
            val tree = d.documentCatalog.pages
            val originals = ArrayList<PDPage>()
            for (page in tree) originals.add(page)
            if (!isValid(plan, originals.size)) return -1
            val bookmarks = PdfBookmarks.read(d)
            for (page in originals) materializeInherited(page)
            val root = tree.cosObject
            root.setItem(COSName.KIDS, COSArray())
            root.setInt(COSName.COUNT, 0)
            for (e in plan) {
                val page = originals[e.source]
                if (e.turn != 0) page.rotation = normalizeTurn(page.rotation + e.turn)
                tree.add(page)
            }
            if (orderChanged(plan, originals.size)) d.documentCatalog.cosObject.removeItem(COSName.PAGE_LABELS)
            if (bookmarks.isNotEmpty()) PdfBookmarks.write(d, remapBookmarks(bookmarks, plan))
            PdfStructureOptimizer.save(d, out)
            plan.size
        } catch (e: Exception) {
            runCatching { out.delete() }
            -1
        } finally {
            runCatching { doc?.close() }
        }
    }
}
