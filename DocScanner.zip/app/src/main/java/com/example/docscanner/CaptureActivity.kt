package com.example.docscanner

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.widget.Toast
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.example.docscanner.databinding.ActivityCaptureBinding
import com.example.docscanner.model.ProjectManager
import com.example.docscanner.model.ScanSessionManager
import com.example.docscanner.util.CaptureStability
import com.example.docscanner.util.FileUtils
import com.example.docscanner.util.FrameDocumentAnalyzer
import com.example.docscanner.util.LevelIndicator
import java.util.concurrent.Executors

/**
 * Camera screen: lets the user shoot as many pages as they want, one at a time.
 *
 * Runs in one of two modes, chosen by whether [ProjectFlow.EXTRA_PROJECT_ID] is present in the
 * launch intent:
 *  - Normal mode (no project id): the original standalone "Quét" flow - every shot goes straight
 *    into [CropActivity] (single-shot mode) for corner adjustment + filter, then control returns
 *    here so the loop can continue until the user taps "Xong, xem lại".
 *  - Project mode (project id present, see `ProjectPickImagesActivity`): shots are only ever
 *    *picked* here, matching that stage's job - crop/split happens later, together, in
 *    `ProjectEditActivity`. Each shot is appended straight to the project's
 *    `Project.pendingRawPaths` and persisted immediately, no per-shot detour.
 */
class CaptureActivity : BaseActivity() {

    private lateinit var binding: ActivityCaptureBinding
    private var imageCapture: ImageCapture? = null
    private var flashOn = false
    private var projectId: String? = null

    /** "Tự động chụp": off by default, per launch of this screen. */
    private var autoCapture = false

    // Burst shooting (phiên 22, PDF list A5; util.IntervalShooter): tap the shutter once, then a photo every 2 / 3 / 5 s while the pages are turned.
    // Outside a project the shots wait in [burstPaths] and go to the crop queue together when the person is done (the normal one-shot flow
    // would open the crop screen after EVERY photo and stop being hands-free).
    private var intervalIndex = 0
    private var shooter: com.example.docscanner.util.IntervalShooter? = null
    private val burstPaths = ArrayList<String>()
    private val burstHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val burstTick = object : Runnable {
        override fun run() {
            val s = shooter ?: return
            val now = android.os.SystemClock.elapsedRealtime()
            if (s.due(now)) { s.onShotStarted(now); takePhoto(burst = true) }
            if (s.running) {
                updateBurstHint(s, now)
                burstHandler.postDelayed(this, BURST_TICK_MS)
            } else {
                binding.tvHint.text = getString(R.string.capture_burst_hint_stopped, s.shots)   // reached the limit by itself
                shooter = null
            }
        }
    }
    private val backCallback = object : androidx.activity.OnBackPressedCallback(false) {
        override fun handleOnBackPressed() { closeCapture() }
    }
    private val stability = CaptureStability()
    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private var lastHintState: CaptureStability.State? = null

    // Level indicator (phiên 17): accelerometer -> tilt from "parallel to the table", smoothed, shown only when it changes by a whole degree.
    private var sensorManager: SensorManager? = null
    private var smoothedTilt = Float.NaN
    private var shownTilt = -1
    private val levelListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            val raw = LevelIndicator.tiltDegrees(event.values[0], event.values[1], event.values[2])
            smoothedTilt = if (smoothedTilt.isNaN()) raw else LevelIndicator.smooth(smoothedTilt, raw)
            val whole = Math.round(smoothedTilt)
            if (whole == shownTilt) return
            shownTilt = whole
            binding.tvLevel.text = if (LevelIndicator.isLevel(smoothedTilt)) getString(R.string.capture_level_flat) else getString(R.string.capture_level_tilt, whole)
            binding.tvLevel.setTextColor(if (LevelIndicator.isLevel(smoothedTilt)) 0xFF7CFC00.toInt() else 0xFFFFFFFF.toInt())
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    private val cropLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            updatePageCount()
        }

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera() else finish()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCaptureBinding.inflate(layoutInflater)
        setContentView(binding.root)

        projectId = intent.getStringExtra(ProjectFlow.EXTRA_PROJECT_ID)

        binding.btnClose.setOnClickListener { closeCapture() }
        onBackPressedDispatcher.addCallback(this, backCallback)
        binding.btnInterval.setOnClickListener { cycleInterval() }
        binding.btnExtension.setOnClickListener { cycleExtension() }
        binding.btnFlash.setOnClickListener { toggleFlash() }
        binding.btnShutter.setOnClickListener { onShutter() }
        binding.btnDoneCapturing.setOnClickListener { finishCapturing() }
        binding.swAutoCapture.setOnCheckedChangeListener { _, checked ->
            if (checked && intervalIndex != 0) { stopBurst(); intervalIndex = 0; updateIntervalLabel() }      // two automatic triggers at once would double-shoot
            autoCapture = checked
            stability.reset()
            binding.tvHint.setText(if (checked) R.string.auto_capture_hint_search else R.string.capture_hint)
        }

        binding.swGrid.setOnCheckedChangeListener { _, checked ->
            binding.gridOverlay.visibility = if (checked) View.VISIBLE else View.GONE
        }
        sensorManager = getSystemService(SENSOR_SERVICE) as? SensorManager

        updatePageCount()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            requestPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    /** Photo mode (PDF list K6): 0 = standard (the camera exactly as before), 1 = HDR, 2 = night - the phone's own camera software, when the phone offers it. Per launch of this screen. */
    private var extensionMode = 0

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            if (extensionMode == 0) {
                bindUseCases(provider, CameraSelector.DEFAULT_BACK_CAMERA, withAnalysis = true)        // the unchanged default path
                return@addListener
            }
            val future = androidx.camera.extensions.ExtensionsManager.getInstanceAsync(this, provider)
            future.addListener({
                val mode = if (extensionMode == 1) androidx.camera.extensions.ExtensionMode.HDR else androidx.camera.extensions.ExtensionMode.NIGHT
                val manager = runCatching { future.get() }.getOrNull()
                if (manager != null && manager.isExtensionAvailable(CameraSelector.DEFAULT_BACK_CAMERA, mode)) {
                    val selector = manager.getExtensionEnabledCameraSelector(CameraSelector.DEFAULT_BACK_CAMERA, mode)
                    bindUseCases(provider, selector, withAnalysis = manager.isImageAnalysisSupported(CameraSelector.DEFAULT_BACK_CAMERA, mode))
                } else {
                    extensionMode = 0                                            // this phone cannot do it: back to the standard camera, say so
                    updateExtensionLabel()
                    Toast.makeText(this, R.string.capture_ext_unsupported, Toast.LENGTH_LONG).show()
                    bindUseCases(provider, CameraSelector.DEFAULT_BACK_CAMERA, withAnalysis = true)
                }
            }, ContextCompat.getMainExecutor(this))
        }, ContextCompat.getMainExecutor(this))
    }

    /** [withAnalysis] false: the extension cannot run with image analysis, so "Tự động chụp" (which needs it) is switched off and disabled while the mode is on. */
    private fun bindUseCases(provider: ProcessCameraProvider, selector: CameraSelector, withAnalysis: Boolean) {
        val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(binding.previewView.surfaceProvider)
        }
        val capture = ImageCapture.Builder()
            .setFlashMode(if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF)
            .build()
        imageCapture = capture
        // Frames for "Tự động chụp"; KEEP_ONLY_LATEST drops frames while the analyzer is busy.
        val analysis = if (withAnalysis) ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()
            .also { it.setAnalyzer(analysisExecutor, FrameDocumentAnalyzer(stability) { state, progress -> onAutoState(state, progress) }) } else null
        if (!withAnalysis) binding.swAutoCapture.isChecked = false
        binding.swAutoCapture.isEnabled = withAnalysis
        try {
            provider.unbindAll()
            if (analysis != null) provider.bindToLifecycle(this, selector, preview, capture, analysis) else provider.bindToLifecycle(this, selector, preview, capture)
        } catch (e: Exception) {
            Log.e(TAG, "Camera bind failed", e)
        }
    }

    private fun cycleExtension() {
        extensionMode = (extensionMode + 1) % 3
        updateExtensionLabel()
        startCamera()                                                            // rebinds; falls back to standard by itself when unsupported
    }

    private fun updateExtensionLabel() {
        binding.btnExtension.setText(when (extensionMode) { 1 -> R.string.capture_ext_hdr; 2 -> R.string.capture_ext_night; else -> R.string.capture_ext_standard })
    }

    /** Called on the analysis thread for every analysed frame. */
    private fun onAutoState(state: CaptureStability.State, progress: Double) {
        if (!autoCapture) return
        runOnUiThread {
            if (!autoCapture || isFinishing) return@runOnUiThread
            if (state == CaptureStability.State.TRIGGER) {
                binding.tvHint.setText(R.string.auto_capture_hint_shot)
                takePhoto()
            } else if (state != lastHintState) {
                binding.tvHint.setText(
                    when (state) {
                        CaptureStability.State.SEARCHING -> R.string.auto_capture_hint_search
                        CaptureStability.State.MOVING -> R.string.auto_capture_hint_moving
                        else -> R.string.auto_capture_hint_hold
                    }
                )
            }
            lastHintState = state
        }
    }

    override fun onResume() {
        super.onResume()
        val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (accelerometer != null) {
            smoothedTilt = Float.NaN
            shownTilt = -1
            binding.tvLevel.visibility = View.VISIBLE
            sensorManager?.registerListener(levelListener, accelerometer, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        stopBurst()                     // the camera is not usable while paused; what was shot so far is kept
        sensorManager?.unregisterListener(levelListener)
        super.onPause()
    }

    /** The volume keys release the shutter (phone held in two hands, no tap to shake the page). The key-down is consumed so the volume bar does not appear. */
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            if (event.repeatCount == 0) onShutter()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) return true
        return super.onKeyUp(keyCode, event)
    }

    override fun onDestroy() {
        burstHandler.removeCallbacks(burstTick)
        analysisExecutor.shutdown()
        super.onDestroy()
    }

    private fun toggleFlash() {
        flashOn = !flashOn
        imageCapture?.flashMode = if (flashOn) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
    }

    /** The shutter button / volume keys: one photo, or - when a burst interval is chosen - start / stop the burst. */
    private fun onShutter() {
        if (intervalIndex == 0) takePhoto()
        else if (shooter?.running == true) stopBurst()
        else startBurst()
    }

    private fun cycleInterval() {
        stopBurst()
        intervalIndex = (intervalIndex + 1) % com.example.docscanner.util.IntervalShooter.CHOICES_SECONDS.size
        if (intervalIndex != 0) binding.swAutoCapture.isChecked = false
        updateIntervalLabel()
        binding.tvHint.setText(if (intervalIndex != 0) R.string.capture_burst_hint_ready else R.string.capture_hint)
    }

    private fun updateIntervalLabel() {
        val seconds = com.example.docscanner.util.IntervalShooter.CHOICES_SECONDS[intervalIndex]
        binding.btnInterval.text = if (seconds == 0) getString(R.string.capture_interval_off) else getString(R.string.capture_interval_on, seconds)
    }

    private fun startBurst() {
        if (imageCapture == null) return
        val seconds = com.example.docscanner.util.IntervalShooter.CHOICES_SECONDS[intervalIndex]
        val s = com.example.docscanner.util.IntervalShooter(seconds * 1000L)
        shooter = s
        s.start(android.os.SystemClock.elapsedRealtime())
        burstHandler.removeCallbacks(burstTick)
        burstHandler.post(burstTick)
    }

    /** Stops the clock; a photo already being saved still finishes and is kept. */
    private fun stopBurst() {
        val s = shooter ?: return
        s.stop()
        burstHandler.removeCallbacks(burstTick)
        binding.tvHint.text = getString(R.string.capture_burst_hint_stopped, s.shots)
        shooter = null
    }

    private fun updateBurstHint(s: com.example.docscanner.util.IntervalShooter, now: Long) {
        val wait = ((s.msUntilNext(now) + 999) / 1000).toInt()
        binding.tvHint.text = getString(R.string.capture_burst_hint_running, s.shots, wait)
    }

    /** [burst]: the photo belongs to a burst - the shooter must always hear that it finished (saved OR failed), or the burst would stall. */
    private fun takePhoto(burst: Boolean = false) {
        val s = if (burst) shooter else null
        val capture = imageCapture ?: run { s?.onShotFinished(); return }
        val pid = projectId
        val file = if (pid != null) {
            val project = ProjectManager.load(this, pid) ?: run { s?.onShotFinished(); return }
            FileUtils.newProjectRawFile(this, pid, project.pendingRawPaths.size)
        } else {
            FileUtils.newCaptureFile(this)
        }
        val outputOptions = ImageCapture.OutputFileOptions.Builder(file).build()
        capture.takePicture(
            outputOptions,
            ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    s?.onShotFinished()
                    if (pid != null) {
                        val project = ProjectManager.load(this@CaptureActivity, pid) ?: return
                        project.pendingRawPaths.add(file.absolutePath)
                        ProjectManager.save(this@CaptureActivity, project)
                        updatePageCount()
                    } else if (burst) {
                        burstPaths.add(file.absolutePath)
                        updatePageCount()
                    } else {
                        val intent = Intent(this@CaptureActivity, CropActivity::class.java).apply {
                            putExtra(CropActivity.EXTRA_IMAGE_PATH, file.absolutePath)
                            putExtra(CropActivity.EXTRA_QUEUE_MODE, false)
                        }
                        cropLauncher.launch(intent)
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    s?.onShotFinished()
                    Log.e(TAG, "Capture failed", exception)
                }
            }
        )
    }

    private fun updatePageCount() {
        val pid = projectId
        val count = if (pid != null) {
            ProjectManager.load(this, pid)?.pendingRawPaths?.size ?: 0
        } else {
            ScanSessionManager.pages.size + burstPaths.size
        }
        backCallback.isEnabled = burstPaths.isNotEmpty()
        binding.tvPageCount.text = getString(R.string.pages_captured_count, count)
        binding.btnDoneCapturing.visibility = if (count > 0) View.VISIBLE else View.GONE
    }

    /** Close (X) / back: shots of a burst that are still waiting are NOT thrown away - they go to the crop queue like every other shot. */
    private fun closeCapture() {
        if (burstPaths.isNotEmpty()) handOverBurst() else finish()
    }

    /** Burst shots -> the same crop queue as gallery photos, WITHOUT clearing the pages already in this session. */
    private fun handOverBurst() {
        stopBurst()
        val paths = burstPaths.toList()
        burstPaths.clear()
        if (paths.isEmpty()) { finish(); return }
        com.example.docscanner.model.PendingCropQueue.setAll(paths.drop(1), null)
        startActivity(Intent(this, CropActivity::class.java).apply {
            putExtra(CropActivity.EXTRA_IMAGE_PATH, paths.first())
            putExtra(CropActivity.EXTRA_QUEUE_MODE, true)
        })
        finish()
    }

    private fun finishCapturing() {
        if (projectId == null && burstPaths.isNotEmpty()) { handOverBurst(); return }
        val pid = projectId
        if (pid != null) {
            // Nothing more to do here - ProjectPickImagesActivity (still on the back stack)
            // reloads the project and refreshes its own count/button in onResume.
            finish()
        } else {
            startActivity(Intent(this, PageListActivity::class.java))
            finish()
        }
    }

    companion object {
        private const val TAG = "CaptureActivity"
        private const val BURST_TICK_MS = 200L
    }
}
