package com.example.docscanner.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.docscanner.R
import com.example.docscanner.databinding.ItemHistoryBinding
import com.example.docscanner.util.FileUtils
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryAdapter(
    private val onClick: (File) -> Unit,
    private val onShare: (File) -> Unit,
    private val onPrint: (File) -> Unit,
    private val onDelete: (File) -> Unit,
    /** null = no star button (the project summary screen lists a project's own files and has no favourites). */
    private val onToggleFavorite: ((File) -> Unit)? = null,
    private val isFavorite: (File) -> Boolean = { false },
    /** null = long press does nothing (the project summary screen). */
    private val onLongClick: ((File) -> Unit)? = null
) : RecyclerView.Adapter<HistoryAdapter.ViewHolder>() {

    private val items = mutableListOf<File>()

    // ---- multi-select (phiên 17): in selection mode a row toggles instead of opening, and the per-row buttons are hidden so no tap can delete by accident ----
    private var selecting = false
    private val selected = LinkedHashSet<String>()
    var onSelectionChanged: (() -> Unit)? = null

    fun beginSelection() { selecting = true; selected.clear(); notifyDataSetChanged() }
    fun endSelection() { selecting = false; selected.clear(); notifyDataSetChanged() }
    fun selectAll() { items.forEach { selected.add(it.name) }; notifyDataSetChanged(); onSelectionChanged?.invoke() }
    fun selectedFiles(): List<File> = items.filter { it.name in selected }
    fun toggle(file: File) {
        if (!selected.add(file.name)) selected.remove(file.name)
        val i = items.indexOfFirst { it.name == file.name }
        if (i >= 0) notifyItemChanged(i)
        onSelectionChanged?.invoke()
    }

    fun submitList(files: List<File>) {
        items.clear()
        items.addAll(files)
        notifyDataSetChanged()
    }

    inner class ViewHolder(val binding: ItemHistoryBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemHistoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val file = items[position]
        holder.binding.tvFileName.text = file.name
        val dateStr = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(file.lastModified()))
        holder.binding.tvFileMeta.text = "$dateStr  •  ${FileUtils.humanFileSize(file.length())}"
        holder.binding.ivFileIcon.setImageResource(
            if (file.extension.equals("pdf", ignoreCase = true)) R.drawable.ic_pdf else R.drawable.ic_book
        )
        holder.binding.root.setOnClickListener { onClick(file) }
        val longClick = onLongClick
        if (longClick == null) {
            holder.binding.root.setOnLongClickListener(null)
            holder.binding.root.isLongClickable = false
        } else {
            holder.binding.root.setOnLongClickListener { longClick(file); true }
        }
        holder.binding.btnShare.setOnClickListener { onShare(file) }
        // printing goes through PdfRenderer, so only PDFs get the button (EPUB/TXT have no print path here)
        val isPdf = file.extension.equals("pdf", ignoreCase = true)
        holder.binding.btnPrint.visibility = if (isPdf) android.view.View.VISIBLE else android.view.View.GONE
        holder.binding.btnPrint.setOnClickListener { onPrint(file) }
        holder.binding.btnDelete.setOnClickListener { onDelete(file) }
        val toggle = onToggleFavorite
        holder.binding.btnFavorite.visibility = if (toggle == null) android.view.View.GONE else android.view.View.VISIBLE
        holder.binding.btnFavorite.setImageResource(if (isFavorite(file)) R.drawable.ic_star else R.drawable.ic_star_outline)
        holder.binding.btnFavorite.setOnClickListener { toggle?.invoke(file) }
        holder.binding.btnShare.visibility = android.view.View.VISIBLE
        holder.binding.btnDelete.visibility = android.view.View.VISIBLE

        holder.binding.cbSelect.visibility = if (selecting) android.view.View.VISIBLE else android.view.View.GONE
        if (selecting) {
            holder.binding.cbSelect.isChecked = file.name in selected
            holder.binding.root.isLongClickable = true
            holder.binding.root.setOnClickListener { toggle(file) }
            holder.binding.root.setOnLongClickListener { toggle(file); true }
            holder.binding.btnShare.visibility = android.view.View.GONE
            holder.binding.btnPrint.visibility = android.view.View.GONE
            holder.binding.btnDelete.visibility = android.view.View.GONE
            holder.binding.btnFavorite.visibility = android.view.View.GONE
        }
    }

    override fun getItemCount(): Int = items.size
}
