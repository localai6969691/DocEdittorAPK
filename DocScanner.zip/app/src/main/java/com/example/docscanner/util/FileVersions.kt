package com.example.docscanner.util

import java.io.File
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest

/**
 * The version history of a library file (phiên 25, TECHNICAL_DOCS.md 4.78 and 4.80; PDF list item 6.1 "version history": every save keeps the old version, it can be put back, and only the last N are kept).
 *
 * How other apps do it (looked up for this work): Google Drive drops a version once it is older than 30 days or 100 newer ones exist, lets a version be kept forever and lets a file be replaced
 * by another with "Upload new version"; OneDrive (personal) keeps up to 25 per file; Dropbox lets the person choose "only the last N versions". This follows them: the last [limit] versions are
 * kept (default [DEFAULT_LIMIT] = 6, set by the person on the main screen), a version can be PINNED so that it is kept whatever the limit says (pinned versions do not count towards it), and
 * [pruneAll] makes a lower limit take effect at once.
 *
 * STORAGE (4.80): a version is NOT a full copy any more. The old content is cut into pieces by CONTENT (FastCDC with a Gear table, the way restic and borg cut files: [CHUNK_MIN] 16 KiB,
 * [CHUNK_AVG] 64 KiB, [CHUNK_MAX] 256 KiB, boundaries that depend on the bytes around them, so a change in the middle of a file moves only the pieces near it), each piece is stored ONCE under its
 * SHA-256 in `<root>/file_versions/chunks/<2 hex>/<hash>`, and a version is a small manifest (`v<id>_<ms>_<0|1>.vm`: `DVM1 <size> <pieces>` then `<hash> <length>` per piece). Measured on real PDFs
 * saved by the app's own PDFBox code (tools/verify/file_versions_dedup_measure.py): a second version of a 2 MB PDF with photos added about a quarter of its size instead of all of it. Pieces no
 * manifest names any more are deleted when a version goes ([gcPool]); if a manifest cannot be read the sweep deletes NOTHING. Putting a version back checks every piece against its hash and
 * length, so a damaged store fails loudly instead of writing a wrong file. Versions made by the first build of this feature, full copies `v<id>_<ms>_<0|1>.ver`, are still listed and restored.
 *
 * The live file stays where it is, in the library. A version is made BEFORE the live file is replaced ([commit]: keep the old content first and only if that worked move the new content in, so a
 * failure anywhere leaves the live file as it was). Restoring a version is the same swap, so the content that was live is itself kept as a version: nothing is lost by restoring (except what
 * the limit later drops, which is the point of the limit). The folder of a file also has `name.txt` with the library file's name (so a renamed file takes its folder along, see [rename], and
 * folders of files that no longer exist can be found, see [purgeOrphans]). Pure `java.io`, no Android: tools/verify/file_versions_real_run_check.py runs it for real against real files.
 */
object FileVersions {

    const val DEFAULT_LIMIT = 6
    const val MIN_LIMIT = 1
    const val MAX_LIMIT = 100

    /** The limits offered on the main screen. */
    val LIMIT_CHOICES: IntArray = intArrayOf(2, 3, 4, 6, 8, 10, 15, 20, 30, 50)

    const val CHUNK_MIN = 16 * 1024
    const val CHUNK_AVG = 64 * 1024
    const val CHUNK_MAX = 256 * 1024

    private const val FOLDER = "file_versions"
    private const val POOL = "chunks"
    private const val NAME_FILE = "name.txt"
    private const val MAGIC = "DVM1"
    private val VERSION_NAME = Regex("""^v(\d+)_(\d+)_([01])\.(ver|vm)$""")

    /** Every change of the store is made under this lock (a sweep of unused pieces must never run while a snapshot is still writing its pieces); reading a list needs no lock. */
    private val lock = Any()

    /** [size] is the size of the content the version holds (not the space it uses); [chunked] false = a full copy made by the first build of the feature. */
    class Version(val id: Long, val time: Long, val size: Long, val pinned: Boolean, val file: File, val chunked: Boolean)

    fun clampLimit(n: Int): Int = n.coerceIn(MIN_LIMIT, MAX_LIMIT)

    // ---------------------------------------------------------------------------------------
    // Cutting a file into pieces by content (FastCDC)
    // ---------------------------------------------------------------------------------------

    /** 256 pseudo-random 64-bit numbers, one per byte value: splitmix64 from a fixed seed, so every build cuts a file in the same places (a different table would stop old pieces being found). */
    private val GEAR: LongArray = LongArray(256).also { table ->
        var z = 0L
        for (i in 0 until 256) {
            z += 0x9E3779B97F4A7C15uL.toLong()
            var x = z
            x = (x xor (x ushr 30)) * 0xBF58476D1CE4E5B9uL.toLong()
            x = (x xor (x ushr 27)) * 0x94D049BB133111EBuL.toLong()
            table[i] = x xor (x ushr 31)
        }
    }

    /** A mask with [bits] bits set, spread over the 64 bits (so the cut depends on about the last 64 bytes, not on the last few). */
    private fun spreadMask(bits: Int): Long {
        var m = 0L
        for (j in 0 until bits) m = m or (1L shl (63 - (j * 64 / bits)))
        return m
    }

    /** The strict mask is used up to the average size, the lax one after it ("normalised chunking"): pieces cluster around the average. */
    private val MASK_S: Long = spreadMask(17)
    private val MASK_L: Long = spreadMask(15)

    /** The length of the piece that starts at [off] when [remaining] bytes are available: at most [CHUNK_MAX], at least [CHUNK_MIN] unless fewer bytes are left. */
    internal fun cutLength(buf: ByteArray, off: Int, remaining: Int): Int {
        if (remaining <= CHUNK_MIN) return remaining
        val limit = minOf(remaining, CHUNK_MAX)
        val normal = minOf(CHUNK_AVG, limit)
        var fp = 0L
        var i = CHUNK_MIN
        while (i < normal) {
            fp = (fp shl 1) + GEAR[buf[off + i].toInt() and 0xFF]
            if ((fp and MASK_S) == 0L) return i + 1
            i++
        }
        while (i < limit) {
            fp = (fp shl 1) + GEAR[buf[off + i].toInt() and 0xFF]
            if ((fp and MASK_L) == 0L) return i + 1
            i++
        }
        return limit
    }

    /** Cuts the whole of [data] (for the checks): the same pieces [forEachChunk] makes of a stream. */
    internal fun chunkLengths(data: ByteArray): List<Int> {
        val out = ArrayList<Int>()
        var off = 0
        while (off < data.size) {
            val len = cutLength(data, off, data.size - off)
            out.add(len)
            off += len
        }
        return out
    }

    /**
     * Cuts a stream into pieces and hands each to [action] (buffer, offset, length; valid only during the call). A piece is cut only when at least [CHUNK_MAX] bytes are in the buffer, or at the
     * end of the stream, so the cuts are exactly the ones [chunkLengths] makes of the whole file.
     */
    private fun forEachChunk(input: InputStream, action: (ByteArray, Int, Int) -> Unit) {
        val buffer = ByteArray(CHUNK_MAX * 2)
        var filled = 0
        var eof = false
        while (true) {
            while (!eof && filled < buffer.size) {
                val n = input.read(buffer, filled, buffer.size - filled)
                if (n < 0) eof = true else filled += n
            }
            var start = 0
            while (filled - start >= CHUNK_MAX || (eof && filled - start > 0)) {
                val len = cutLength(buffer, start, filled - start)
                action(buffer, start, len)
                start += len
            }
            if (eof) return
            System.arraycopy(buffer, start, buffer, 0, filled - start)
            filled -= start
        }
    }

    private fun toHex(bytes: ByteArray): String {
        val sb = StringBuilder(bytes.size * 2)
        for (b in bytes) sb.append(String.format("%02x", b.toInt() and 0xFF))
        return sb.toString()
    }

    private fun sha1(text: String): String = toHex(MessageDigest.getInstance("SHA-1").digest(text.toByteArray(Charsets.UTF_8)))

    // ---------------------------------------------------------------------------------------
    // Where things live
    // ---------------------------------------------------------------------------------------

    private fun base(root: File): File = File(root, FOLDER)

    /** The folder that holds the versions of the library file called [name]. */
    fun dirFor(root: File, name: String): File = File(base(root), sha1(name))

    private fun chunkFile(root: File, hash: String): File = File(File(File(base(root), POOL), hash.substring(0, 2)), hash)

    private fun docDirs(root: File): List<File> = (base(root).listFiles() ?: emptyArray()).filter { it.isDirectory && it.name != POOL }

    private fun readHeader(file: File): Pair<Long, Int>? = try {
        val line = file.bufferedReader().use { it.readLine() }
        val f = line?.split(" ")
        if (f != null && f.size == 3 && f[0] == MAGIC) {
            val size = f[1].toLongOrNull()
            val count = f[2].toIntOrNull()
            if (size != null && count != null && size >= 0 && count >= 0) Pair(size, count) else null
        } else {
            null
        }
    } catch (e: Exception) {
        null
    }

    private fun parse(file: File): Version? {
        val m = VERSION_NAME.matchEntire(file.name) ?: return null
        val id = m.groupValues[1].toLongOrNull() ?: return null
        val time = m.groupValues[2].toLongOrNull() ?: return null
        val chunked = m.groupValues[4] == "vm"
        val size = if (chunked) (readHeader(file)?.first ?: return null) else file.length()
        return Version(id, time, size, m.groupValues[3] == "1", file, chunked)
    }

    /** The versions of [name], newest first. */
    fun list(root: File, name: String): List<Version> {
        val files = dirFor(root, name).listFiles() ?: return emptyList()
        return files.mapNotNull { parse(it) }.sortedByDescending { it.id }
    }

    fun count(root: File, name: String): Int = list(root, name).size

    private fun versionFile(dir: File, id: Long, time: Long, pinned: Boolean, chunked: Boolean): File =
        File(dir, "v${id}_${time}_${if (pinned) 1 else 0}.${if (chunked) "vm" else "ver"}")

    private fun copyFile(from: File, to: File) {
        from.inputStream().use { input -> to.outputStream().use { output -> input.copyTo(output) } }
    }

    // ---------------------------------------------------------------------------------------
    // Keeping and putting back
    // ---------------------------------------------------------------------------------------

    /**
     * Keeps [source] (the content about to be replaced) as the newest version of [name]: cut into pieces, the pieces not stored yet written, the manifest written last. Then drops the oldest
     * UNPINNED versions beyond [limit]. Returns the new version, or null when it could not be made (no space, the folder cannot be created ...): then the pieces it wrote are removed again,
     * nothing is left behind and the callers must NOT go on to replace [source].
     */
    fun snapshot(root: File, name: String, source: File, now: Long, limit: Int): Version? = synchronized(lock) {
        if (!source.isFile) return@synchronized null
        val dir = dirFor(root, name)
        val written = ArrayList<File>()
        var partial: File? = null
        try {
            if (!dir.isDirectory && !dir.mkdirs()) return@synchronized null
            File(dir, NAME_FILE).writeText(name, Charsets.UTF_8)
            val id = (list(root, name).maxOfOrNull { it.id } ?: 0L) + 1L
            val target = versionFile(dir, id, now, false, true)
            val part = File(dir, target.name + ".part")
            partial = part
            val manifest = StringBuilder()
            var total = 0L
            var pieces = 0
            val digest = MessageDigest.getInstance("SHA-256")
            source.inputStream().use { input ->
                forEachChunk(input) { buf, off, len ->
                    digest.reset()
                    digest.update(buf, off, len)
                    val hash = toHex(digest.digest())
                    val cf = chunkFile(root, hash)
                    if (!cf.isFile) {
                        cf.parentFile?.mkdirs()
                        val tmp = File(cf.parentFile, "$hash.part")
                        tmp.outputStream().use { it.write(buf, off, len) }
                        if (!tmp.renameTo(cf)) {
                            tmp.delete()
                            throw IOException("cannot store a piece")
                        }
                        written.add(cf)
                    }
                    manifest.append(hash).append(' ').append(len).append('\n')
                    total += len
                    pieces++
                }
            }
            part.writeText("$MAGIC $total $pieces\n$manifest", Charsets.UTF_8)
            if (!part.renameTo(target)) throw IOException("rename failed")
            prune(root, name, limit)
            list(root, name).firstOrNull { it.id == id } ?: Version(id, now, total, false, target, true)
        } catch (e: Exception) {
            runCatching { partial?.delete() }
            for (c in written) runCatching { c.delete() }
            null
        }
    }

    /** Deletes the oldest unpinned versions in [dir] until [limit] unpinned ones are left (pinned ones are never dropped); returns how many went. Pieces are NOT swept here. */
    private fun pruneDir(dir: File, limit: Int): Int {
        val unpinned = (dir.listFiles() ?: emptyArray()).mapNotNull { parse(it) }.sortedByDescending { it.id }.filter { !it.pinned }
        val extra = unpinned.size - clampLimit(limit)
        if (extra <= 0) return 0
        var removed = 0
        for (v in unpinned.takeLast(extra)) {
            if (v.file.delete()) removed++
        }
        return removed
    }

    /** Deletes the oldest unpinned versions of [name] until [limit] unpinned ones are left, then the pieces nothing uses any more; returns how many versions went. */
    fun prune(root: File, name: String, limit: Int): Int = synchronized(lock) {
        val removed = pruneDir(dirFor(root, name), limit)
        if (removed > 0) gcPool(root)
        removed
    }

    /** How many versions [pruneAll] would delete for [limit]: what lowering the limit costs, to tell the person before it is done. */
    fun excessCount(root: File, limit: Int): Int {
        var n = 0
        for (d in docDirs(root)) {
            val unpinned = (d.listFiles() ?: emptyArray()).mapNotNull { parse(it) }.count { !it.pinned }
            n += maxOf(0, unpinned - clampLimit(limit))
        }
        return n
    }

    /** Applies [limit] to EVERY file at once (a lower limit takes effect now, not at the next save) and sweeps the unused pieces; returns how many versions went. */
    fun pruneAll(root: File, limit: Int): Int = synchronized(lock) {
        var removed = 0
        for (d in docDirs(root)) removed += pruneDir(d, limit)
        if (removed > 0) gcPool(root)
        removed
    }

    /**
     * Deletes the pieces that no manifest names. If ANY manifest cannot be read the sweep stops and deletes nothing: a piece wrongly taken for unused would be data lost for good.
     * Leftover `.part` files of pieces are unused by definition and go with them.
     */
    private fun gcPool(root: File) {
        val pool = File(base(root), POOL)
        if (!pool.isDirectory) return
        val referenced = HashSet<String>()
        for (d in docDirs(root)) {
            val files = d.listFiles() ?: return
            for (f in files) {
                if (!f.name.endsWith(".vm")) continue
                try {
                    f.bufferedReader().use { reader ->
                        reader.readLine()
                        while (true) {
                            val line = reader.readLine() ?: break
                            val sp = line.indexOf(' ')
                            if (sp > 0) referenced.add(line.substring(0, sp))
                        }
                    }
                } catch (e: Exception) {
                    return
                }
            }
        }
        for (shard in pool.listFiles() ?: return) {
            if (!shard.isDirectory) continue
            for (c in shard.listFiles() ?: continue) {
                if (c.name !in referenced) c.delete()
            }
            if (shard.list()?.isEmpty() == true) shard.delete()
        }
    }

    fun setPinned(root: File, name: String, id: Long, pinned: Boolean): Boolean = synchronized(lock) {
        val v = list(root, name).firstOrNull { it.id == id } ?: return@synchronized false
        if (v.pinned == pinned) return@synchronized true
        v.file.renameTo(versionFile(v.file.parentFile ?: return@synchronized false, v.id, v.time, pinned, v.chunked))
    }

    fun delete(root: File, name: String, id: Long): Boolean = synchronized(lock) {
        val v = list(root, name).firstOrNull { it.id == id } ?: return@synchronized false
        val ok = v.file.delete()
        if (ok && v.chunked) gcPool(root)
        ok
    }

    /** Writes the content of version [v] to [out], checking every piece against its hash and length and the total against the manifest; false (and [out] removed) on any mismatch or missing piece. */
    private fun materialize(root: File, v: Version, out: File): Boolean {
        try {
            if (!v.chunked) {
                copyFile(v.file, out)
                return true
            }
            val digest = MessageDigest.getInstance("SHA-256")
            var total = 0L
            out.outputStream().buffered().use { sink ->
                v.file.bufferedReader().use { reader ->
                    reader.readLine()
                    while (true) {
                        val line = reader.readLine() ?: break
                        if (line.isEmpty()) continue
                        val sp = line.indexOf(' ')
                        if (sp <= 0) throw IOException("bad manifest line")
                        val hash = line.substring(0, sp)
                        val len = line.substring(sp + 1).toInt()
                        val data = chunkFile(root, hash).readBytes()
                        digest.reset()
                        if (data.size != len || toHex(digest.digest(data)) != hash) throw IOException("a piece is missing or damaged")
                        sink.write(data)
                        total += len
                    }
                }
            }
            if (total != v.size) throw IOException("size does not match the manifest")
            return true
        } catch (e: Exception) {
            runCatching { out.delete() }
            return false
        }
    }

    /** Writes the content of version [v] to [out] (to look at it, or to build it aside); every piece is checked first, so a damaged store gives false and no file. */
    fun export(root: File, v: Version, out: File): Boolean = materialize(root, v, out)

    /** Puts [incoming] in place of [target]: renaming over it, or when that is refused copying over it; [incoming] is consumed either way. */
    private fun replace(incoming: File, target: File): Boolean {
        target.parentFile?.mkdirs()
        if (incoming.renameTo(target)) return true
        return try {
            copyFile(incoming, target)
            incoming.delete()
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * The safe overwrite: keeps the CURRENT content of [target] as a new version of [name] and only then replaces [target] with [incoming] (moved, so it is gone afterwards). Returns false, with
     * [target] untouched, when the old content could not be kept; [incoming] is left in place then so the caller can offer something else. A [target] that does not exist yet is simply replaced.
     */
    fun commit(root: File, name: String, incoming: File, target: File, now: Long, limit: Int): Boolean {
        if (!incoming.isFile) return false
        if (target.isFile && snapshot(root, name, target, now, limit) == null) return false
        return replace(incoming, target)
    }

    /**
     * Puts version [id] of [name] back as [target]. The chosen version is rebuilt aside FIRST (the snapshot of the current content below may drop the oldest version, which could be this one),
     * then the current content is kept as a version, then the copy replaces [target]. False, with nothing changed, when the version is missing or damaged or the current content could not be kept.
     */
    fun restore(root: File, name: String, id: Long, target: File, now: Long, limit: Int): Boolean {
        val v = list(root, name).firstOrNull { it.id == id } ?: return false
        val aside = File(target.parentFile ?: return false, target.name + ".restore.part")
        if (!materialize(root, v, aside)) return false
        if (!commit(root, name, aside, target, now, limit)) {
            runCatching { aside.delete() }
            return false
        }
        return true
    }

    /**
     * Makes [replacement] the new content of the library file [target] (Drive's "Upload new version", 4.80): the current content is kept as a version first, then [replacement] is COPIED over
     * [target] (it stays where it is). False, with [target] untouched, when the old content could not be kept.
     */
    fun replaceWith(root: File, name: String, replacement: File, target: File, now: Long, limit: Int): Boolean {
        if (!replacement.isFile || !target.isFile) return false
        val aside = File(target.parentFile ?: return false, target.name + ".replace.part")
        try {
            copyFile(replacement, aside)
        } catch (e: Exception) {
            runCatching { aside.delete() }
            return false
        }
        if (!commit(root, name, aside, target, now, limit)) {
            runCatching { aside.delete() }
            return false
        }
        return true
    }

    /** The versions of a renamed library file go with it. Returns false when there was nothing to move or the new name already has a folder. */
    fun rename(root: File, oldName: String, newName: String): Boolean = synchronized(lock) {
        if (oldName == newName) return@synchronized false
        val from = dirFor(root, oldName)
        val to = dirFor(root, newName)
        if (!from.isDirectory || to.exists()) return@synchronized false
        if (!from.renameTo(to)) return@synchronized false
        runCatching { File(to, NAME_FILE).writeText(newName, Charsets.UTF_8) }
        true
    }

    fun deleteAll(root: File, name: String) {
        synchronized(lock) {
            runCatching { dirFor(root, name).deleteRecursively() }
            gcPool(root)
        }
    }

    fun clearAll(root: File) {
        synchronized(lock) { runCatching { base(root).deleteRecursively() } }
    }

    /** Bytes the versions really use: every manifest and full copy plus the pieces (a piece shared by several versions counts once). */
    fun totalSize(root: File): Long {
        var sum = 0L
        for (d in docDirs(root)) {
            d.listFiles()?.forEach { f -> if (VERSION_NAME.matches(f.name)) sum += f.length() }
        }
        val pool = File(base(root), POOL)
        for (shard in pool.listFiles() ?: emptyArray()) {
            shard.listFiles()?.forEach { c -> if (!c.name.endsWith(".part")) sum += c.length() }
        }
        return sum
    }

    /**
     * Removes the folders of files that are no longer in the library: those whose recorded name is not in [existing] AND whose newest content is older than [graceMs] (a file moved to the bin
     * and put back, or briefly missing, keeps its history). A folder without a recorded name is treated the same way. The pieces nothing uses any more are swept afterwards. Returns how many
     * folders went.
     */
    fun purgeOrphans(root: File, existing: Set<String>, now: Long, graceMs: Long): Int = synchronized(lock) {
        var removed = 0
        for (d in docDirs(root)) {
            val recorded = runCatching { File(d, NAME_FILE).readText(Charsets.UTF_8) }.getOrNull()
            if (recorded != null && recorded in existing) continue
            val newest = (d.listFiles()?.maxOfOrNull { it.lastModified() } ?: d.lastModified())
            if (now - newest < graceMs) continue
            if (d.deleteRecursively()) removed++
        }
        if (removed > 0) gcPool(root)
        removed
    }
}
