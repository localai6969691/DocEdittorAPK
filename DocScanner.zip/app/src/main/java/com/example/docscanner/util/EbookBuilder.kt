package com.example.docscanner.util

import com.example.docscanner.R
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Builds ebook files straight from OCR text - no third-party ebook/EPUB library. EPUB is just a
 * ZIP file with a well-defined internal XML structure, so it's written directly with
 * `java.util.zip` (already in the JDK) instead of pulling in a dependency we can't verify without
 * a real build. MOBI/AZW3 are deliberately NOT supported: they are complex proprietary binary
 * formats, Amazon stopped accepting MOBI uploads in March 2025, and Kindle has accepted EPUB
 * directly (via Send to Kindle) since 2022 - so EPUB is both the safer and the more future-proof
 * choice. FB2 (FictionBook 2, the XML ebook format popular in Russian-speaking countries and
 * read by FBReader, PocketBook, KOReader, Calibre...) IS supported: it is plain XML, so unlike
 * MOBI/AZW3 there is nothing proprietary to get wrong and it can be checked with ordinary XML tools.
 */
object EbookBuilder {

    /** One chapter: a title (goes in the table of contents) and its paragraphs, in order. */
    data class Chapter(val title: String, val paragraphs: List<String>)

    // ---------------------------------------------------------------------------------------
    // EPUB
    // ---------------------------------------------------------------------------------------

    fun buildEpub(outFile: File, bookTitle: String, chapters: List<Chapter>) {
        val uuid = "urn:uuid:${UUID.randomUUID()}"
        ZipOutputStream(FileOutputStream(outFile)).use { zip ->
            // Must be the first entry, and stored (uncompressed) - this is what makes a .zip an .epub.
            writeStoredEntry(zip, "mimetype", "application/epub+zip".toByteArray(Charsets.US_ASCII))

            writeTextEntry(zip, "META-INF/container.xml", containerXml())
            writeTextEntry(zip, "OEBPS/styles.css", stylesCss())

            chapters.forEachIndexed { index, chapter ->
                writeTextEntry(zip, "OEBPS/chapter${index + 1}.xhtml", chapterXhtml(chapter))
            }

            writeTextEntry(zip, "OEBPS/nav.xhtml", navXhtml(chapters))
            writeTextEntry(zip, "OEBPS/toc.ncx", tocNcx(uuid, bookTitle, chapters))
            writeTextEntry(zip, "OEBPS/content.opf", contentOpf(uuid, bookTitle, chapters))
        }
    }

    private fun writeStoredEntry(zip: ZipOutputStream, name: String, data: ByteArray) {
        val entry = ZipEntry(name)
        entry.method = ZipEntry.STORED
        entry.size = data.size.toLong()
        entry.compressedSize = data.size.toLong()
        val crc = CRC32()
        crc.update(data)
        entry.crc = crc.value
        zip.putNextEntry(entry)
        zip.write(data)
        zip.closeEntry()
    }

    private fun writeTextEntry(zip: ZipOutputStream, name: String, content: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(content.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    /**
     * Escapes [s] for use as XML text/attribute content. Characters that XML 1.0 does not allow AT ALL (control codes such as
     * U+0000-U+0008, U+000B, U+000C, U+000E-U+001F, lone surrogates, U+FFFE/U+FFFF) are dropped first: they can appear in text
     * taken from OCR or from a PDF's text layer, and a single one makes an EPUB/FB2 invalid XML that readers refuse to open.
     */
    private fun esc(s: String): String = xmlSafe(s)
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace("\"", "&quot;")
        .replace("'", "&apos;")

    private fun xmlSafe(s: String): String {
        var clean = true
        var i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            if (!isXmlChar(cp)) { clean = false; break }
            i += Character.charCount(cp)
        }
        if (clean) return s
        val out = StringBuilder(s.length)
        i = 0
        while (i < s.length) {
            val cp = s.codePointAt(i)
            val len = Character.charCount(cp)
            if (isXmlChar(cp)) out.append(s, i, i + len)
            i += len
        }
        return out.toString()
    }

    /** The `Char` production of XML 1.0. */
    private fun isXmlChar(cp: Int): Boolean =
        cp == 0x9 || cp == 0xA || cp == 0xD || cp in 0x20..0xD7FF || cp in 0xE000..0xFFFD || cp in 0x10000..0x10FFFF

    private fun containerXml(): String = """<?xml version="1.0" encoding="UTF-8"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>"""

    private fun stylesCss(): String = """body { font-family: serif; line-height: 1.5; margin: 1em; }
h1 { text-align: center; font-size: 1.4em; }
p { text-indent: 1.5em; margin: 0 0 0.6em 0; }"""

    private fun chapterXhtml(chapter: Chapter): String {
        val body = if (chapter.paragraphs.isEmpty()) {
            "    <p><em>${esc(AppText.get(R.string.ebook_page_no_text))}</em></p>"
        } else {
            chapter.paragraphs.joinToString("\n") { "    <p>${esc(it)}</p>" }
        }
        return """<?xml version="1.0" encoding="UTF-8"?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>${esc(chapter.title)}</title>
  <link rel="stylesheet" type="text/css" href="styles.css"/>
</head>
<body>
  <h1>${esc(chapter.title)}</h1>
$body
</body>
</html>"""
    }

    private fun navXhtml(chapters: List<Chapter>): String {
        val items = chapters.mapIndexed { i, c ->
            "      <li><a href=\"chapter${i + 1}.xhtml\">${esc(c.title)}</a></li>"
        }.joinToString("\n")
        return """<?xml version="1.0" encoding="UTF-8"?>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops">
<head><title>Mục lục</title></head>
<body>
  <nav epub:type="toc" id="toc">
    <h1>Mục lục</h1>
    <ol>
$items
    </ol>
  </nav>
</body>
</html>"""
    }

    private fun tocNcx(uuid: String, bookTitle: String, chapters: List<Chapter>): String {
        val points = chapters.mapIndexed { i, c ->
            """    <navPoint id="navPoint-${i + 1}" playOrder="${i + 1}">
      <navLabel><text>${esc(c.title)}</text></navLabel>
      <content src="chapter${i + 1}.xhtml"/>
    </navPoint>"""
        }.joinToString("\n")
        return """<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
  <head>
    <meta name="dtb:uid" content="$uuid"/>
    <meta name="dtb:depth" content="1"/>
    <meta name="dtb:totalPageCount" content="0"/>
    <meta name="dtb:maxPageNumber" content="0"/>
  </head>
  <docTitle><text>${esc(bookTitle)}</text></docTitle>
  <navMap>
$points
  </navMap>
</ncx>"""
    }

    private fun contentOpf(uuid: String, bookTitle: String, chapters: List<Chapter>): String {
        val manifestItems = chapters.mapIndexed { i, _ ->
            "    <item id=\"chapter${i + 1}\" href=\"chapter${i + 1}.xhtml\" media-type=\"application/xhtml+xml\"/>"
        }.joinToString("\n")
        val spineItems = chapters.mapIndexed { i, _ ->
            "    <itemref idref=\"chapter${i + 1}\"/>"
        }.joinToString("\n")
        val modified = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
            .apply { timeZone = TimeZone.getTimeZone("UTC") }
            .format(java.util.Date())
        return """<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="BookId">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <dc:identifier id="BookId">$uuid</dc:identifier>
    <dc:title>${esc(bookTitle)}</dc:title>
    <dc:language>vi</dc:language>
    <meta property="dcterms:modified">$modified</meta>
  </metadata>
  <manifest>
    <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
    <item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>
    <item id="css" href="styles.css" media-type="text/css"/>
$manifestItems
  </manifest>
  <spine toc="ncx">
$spineItems
  </spine>
</package>"""
    }

    // ---------------------------------------------------------------------------------------
    // FB2 (FictionBook 2)
    // ---------------------------------------------------------------------------------------

    /** One `.fb2` file (UTF-8 XML, no ZIP). Every chapter becomes a `<section>` with its title, so readers show the same table of contents as the EPUB. */
    fun buildFb2(outFile: File, bookTitle: String, chapters: List<Chapter>) {
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(java.util.Date())
        outFile.writeText(fb2Document(bookTitle, chapters, UUID.randomUUID().toString(), today), Charsets.UTF_8)
    }

    /**
     * The FictionBook 2.x structure (schema order matters to strict readers): description = title-info (genre, author,
     * book-title, date, lang) + document-info (author, program-used, date, id, version); body = a book title followed by
     * one section per chapter. A `<section>` must contain at least one `<p>` (or sub-section), so an empty chapter gets the
     * same "(không có văn bản)" line the TXT export writes, and a book with no chapter at all still gets one section.
     */
    internal fun fb2Document(bookTitle: String, chapters: List<Chapter>, id: String, isoDate: String): String {
        val sb = StringBuilder()
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
        sb.append("<FictionBook xmlns=\"http://www.gribuser.ru/xml/fictionbook/2.0\" xmlns:l=\"http://www.w3.org/1999/xlink\">\n")
        sb.append("<description>\n<title-info>\n")
        sb.append("<genre>nonfiction</genre>\n")
        sb.append("<author><nickname>DocScanner</nickname></author>\n")
        sb.append("<book-title>").append(esc(bookTitle)).append("</book-title>\n")
        sb.append("<date value=\"").append(isoDate).append("\">").append(isoDate).append("</date>\n")
        sb.append("<lang>vi</lang>\n</title-info>\n")
        sb.append("<document-info>\n<author><nickname>DocScanner</nickname></author>\n")
        sb.append("<program-used>DocScanner</program-used>\n")
        sb.append("<date value=\"").append(isoDate).append("\">").append(isoDate).append("</date>\n")
        sb.append("<id>").append(esc(id)).append("</id>\n<version>1.0</version>\n</document-info>\n")
        sb.append("</description>\n<body>\n")
        if (bookTitle.isNotBlank()) sb.append("<title><p>").append(esc(bookTitle)).append("</p></title>\n")
        val noText = AppText.get(R.string.ebook_page_no_text)
        val sections = if (chapters.isEmpty()) listOf(Chapter("", emptyList())) else chapters
        sections.forEach { chapter ->
            sb.append("<section>\n")
            if (chapter.title.isNotBlank()) sb.append("<title><p>").append(esc(chapter.title)).append("</p></title>\n")
            val paragraphs = chapter.paragraphs.filter { it.isNotBlank() }
            if (paragraphs.isEmpty()) {
                sb.append("<p>").append(noText).append("</p>\n")
            } else {
                paragraphs.forEach { sb.append("<p>").append(esc(it.trim())).append("</p>\n") }
            }
            sb.append("</section>\n")
        }
        sb.append("</body>\n</FictionBook>\n")
        return sb.toString()
    }

    // ---------------------------------------------------------------------------------------
    // Plain text
    // ---------------------------------------------------------------------------------------

    fun buildTxt(outFile: File, bookTitle: String, chapters: List<Chapter>) {
        outFile.bufferedWriter(Charsets.UTF_8).use { w ->
            w.write(bookTitle)
            w.write("\n")
            w.write("=".repeat(bookTitle.length.coerceAtLeast(10)))
            w.write("\n\n")
            chapters.forEach { chapter ->
                w.write(chapter.title)
                w.write("\n")
                w.write("-".repeat(chapter.title.length.coerceAtLeast(6)))
                w.write("\n\n")
                if (chapter.paragraphs.isEmpty()) {
                    w.write(AppText.get(R.string.ebook_page_no_text) + "\n\n")
                } else {
                    chapter.paragraphs.forEach { p ->
                        w.write(p)
                        w.write("\n\n")
                    }
                }
            }
        }
    }
}
