package com.example.docscanner.util

/**
 * Folders without moving files (PDF list E8 "move / copy to folder", E9 "folder hierarchy"): a tag written as `Work/Invoices` is the sub-folder `Invoices`
 * of the folder `Work`. A document can sit in several folders at once, nothing on disk is moved, and trash, backup and search keep working because the
 * folder IS a tag ([TagStore]). Choosing a parent folder in the filter shows its sub-folders' documents too.
 *
 * Case and accents are ignored when folders are compared ("công việc/Hoá đơn" and "Cong viec/hoa don" are the same folder), the way [HistoryFilter] already
 * treats tags. Pure Kotlin; tools/verify/history_filter_check.py ports it and checks it against an independent brute-force reference.
 */
object TagTree {

    const val SEPARATOR = '/'

    /** One line of the folder list: [path] is what the filter stores, [label] the last part, [depth] starts at 1, [count] = documents in it or below it. */
    class Row(val path: String, val label: String, val depth: Int, val count: Int)

    /** The parts of a tag: `" Work / Invoices "` -> `[Work, Invoices]`; empty parts are dropped. */
    fun segments(tag: String): List<String> = tag.split(SEPARATOR).map { it.trim() }.filter { it.isNotEmpty() }

    private fun key(parts: List<String>): List<String> = parts.map { HistoryFilter.normalize(it) }

    /** True when [tag] is [filter] itself or lies below it (`Work/Invoices` is below `Work`; `Workshop` is NOT). */
    fun matches(tag: String, filter: String): Boolean {
        val wanted = key(segments(filter))
        if (wanted.isEmpty()) return false
        val have = key(segments(tag))
        return have.size >= wanted.size && have.subList(0, wanted.size) == wanted
    }

    /** Every folder that exists (each prefix of each tag) with the number of distinct documents in it or below it, parents before their children, A to Z. */
    fun rows(tagsByFile: Map<String, Set<String>>): List<Row> {
        class Folder(val shown: List<String>, val files: HashSet<String> = HashSet())
        val folders = HashMap<List<String>, Folder>()
        for (file in tagsByFile.keys.sorted()) {                  // sorted: the spelling shown for a folder does not depend on map order
            for (tag in tagsByFile.getValue(file).sorted()) {
                val parts = segments(tag)
                for (i in 1..parts.size) {
                    val shown = parts.subList(0, i)
                    folders.getOrPut(key(shown)) { Folder(shown) }.files.add(file)
                }
            }
        }
        val order = Comparator<List<String>> { a, b ->
            var result = 0
            var i = 0
            while (result == 0 && i < minOf(a.size, b.size)) { result = a[i].compareTo(b[i]); i++ }
            if (result != 0) result else a.size.compareTo(b.size)    // a parent comes before its children
        }
        return folders.keys.sortedWith(order).map { k ->
            val f = folders.getValue(k)
            Row(f.shown.joinToString(SEPARATOR.toString()), f.shown.last(), f.shown.size, f.files.size)
        }
    }
}
