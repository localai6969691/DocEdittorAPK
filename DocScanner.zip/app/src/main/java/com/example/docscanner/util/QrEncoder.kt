package com.example.docscanner.util

/**
 * QR Code generator (phiên 19, mục 4.47.5; items L14 / M7 of the PDF "Thiếu gì để bán app": export / share as a QR code). Pure Kotlin, no library, no Android: versions 1-40, the four
 * error-correction levels, numeric / alphanumeric / byte (UTF-8) modes, all eight masks with the penalty rules of ISO/IEC 18004 to pick the best. Mirrored line by line in
 * tools/verify/QrCheck.java; tools/verify/qr_check.py renders the matrices and decodes them with OpenCV's QRCodeDetector (an independent decoder) for every version x level.
 * The structure follows the algorithm of Project Nayuki's reference generator (MIT): tables of error-correction codewords / blocks per version, Reed-Solomon over GF(2^8) with
 * polynomial 0x11D, interleaving of blocks, zig-zag placement, BCH-coded format and version information.
 */
object QrEncoder {

    /** Error-correction level; [formatBits] is the 2-bit code stored in the format information (L = 1, M = 0, Q = 3, H = 2). */
    enum class Ecl(val index: Int, val formatBits: Int) { LOW(0, 1), MEDIUM(1, 0), QUARTILE(2, 3), HIGH(3, 2) }

    /** A finished symbol: [size] x [size] modules, `true` = dark. */
    class Qr(val version: Int, val size: Int, val mask: Int, private val modules: BooleanArray) {
        fun get(x: Int, y: Int): Boolean = x in 0 until size && y in 0 until size && modules[y * size + x]
    }

    // [level][version], index 0 unused. From ISO/IEC 18004 (as tabulated in the Nayuki reference): error-correction codewords per block, and number of blocks.
    private val ECC_PER_BLOCK = arrayOf(
        intArrayOf(-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30),
        intArrayOf(-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28),
        intArrayOf(-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30),
        intArrayOf(-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30)
    )
    private val NUM_BLOCKS = arrayOf(
        intArrayOf(-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25),
        intArrayOf(-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49),
        intArrayOf(-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68),
        intArrayOf(-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81)
    )
    private const val ALNUM = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ \$%*+-./:"

    /** Number of data modules (everything except the function patterns) of a symbol of [version]. */
    fun rawDataModules(version: Int): Int {
        var result = (16 * version + 128) * version + 64
        if (version >= 2) {
            val numAlign = version / 7 + 2
            result -= (25 * numAlign - 10) * numAlign - 55
            if (version >= 7) result -= 36
        }
        return result
    }

    /** Data codewords (bytes) a symbol of [version] and [ecl] holds. */
    fun dataCodewords(version: Int, ecl: Ecl): Int = rawDataModules(version) / 8 - ECC_PER_BLOCK[ecl.index][version] * NUM_BLOCKS[ecl.index][version]

    private fun charCountBits(mode: Int, version: Int): Int {
        val k = if (version <= 9) 0 else if (version <= 26) 1 else 2
        return when (mode) { 1 -> intArrayOf(10, 12, 14)[k]; 2 -> intArrayOf(9, 11, 13)[k]; else -> intArrayOf(8, 16, 16)[k] }
    }

    /** The smallest symbol (from [minVersion]) that holds [text] at [ecl], or null when even version 40 is too small. [boost] raises the level while the version stays the same. */
    fun encode(text: String, ecl: Ecl, minVersion: Int = 1, boost: Boolean = true): Qr? {
        val mode = if (text.isNotEmpty() && text.all { it in '0'..'9' }) 1 else if (text.isNotEmpty() && text.all { ALNUM.indexOf(it) >= 0 }) 2 else 4
        val bytes = text.toByteArray(Charsets.UTF_8)
        val count = if (mode == 4) bytes.size else text.length
        val dataBits = when (mode) { 1 -> count / 3 * 10 + (if (count % 3 == 0) 0 else if (count % 3 == 1) 4 else 7); 2 -> count / 2 * 11 + count % 2 * 6; else -> count * 8 }
        var version = minVersion.coerceIn(1, 40)
        while (true) {
            val used = 4 + charCountBits(mode, version) + dataBits
            val fits = count < (1 shl charCountBits(mode, version)) && used <= dataCodewords(version, ecl) * 8
            if (fits) break
            if (version >= 40) return null
            version++
        }
        var level = ecl
        if (boost) for (candidate in arrayOf(Ecl.MEDIUM, Ecl.QUARTILE, Ecl.HIGH)) {
            if (candidate.index > level.index && 4 + charCountBits(mode, version) + dataBits <= dataCodewords(version, candidate) * 8) level = candidate
        }

        // data bit stream: mode, count, payload, terminator, byte alignment, pad bytes 0xEC 0x11
        val bits = ArrayList<Int>()
        fun put(value: Int, length: Int) { for (i in length - 1 downTo 0) bits.add((value ushr i) and 1) }
        put(mode, 4)
        put(count, charCountBits(mode, version))
        when (mode) {
            1 -> { var i = 0; while (i < text.length) { val n = minOf(3, text.length - i); put(text.substring(i, i + n).toInt(), n * 3 + 1); i += n } }
            2 -> { var i = 0; while (i + 1 < text.length) { put(ALNUM.indexOf(text[i]) * 45 + ALNUM.indexOf(text[i + 1]), 11); i += 2 }; if (text.length % 2 == 1) put(ALNUM.indexOf(text.last()), 6) }
            else -> for (b in bytes) put(b.toInt() and 0xFF, 8)
        }
        val capacityBits = dataCodewords(version, level) * 8
        put(0, minOf(4, capacityBits - bits.size))
        put(0, (8 - bits.size % 8) % 8)
        var pad = 0xEC
        while (bits.size < capacityBits) { put(pad, 8); pad = pad xor (0xEC xor 0x11) }
        val data = IntArray(bits.size / 8)
        for (i in bits.indices) data[i ushr 3] = data[i ushr 3] or (bits[i] shl (7 - (i and 7)))

        val codewords = addEccAndInterleave(data, version, level)
        return draw(codewords, version, level)
    }

    // ------------------------------------------------------------------ Reed-Solomon, blocks

    private fun gfMul(x: Int, y: Int): Int {
        var z = 0
        for (i in 7 downTo 0) { z = (z shl 1) xor ((z ushr 7) * 0x11D); z = z xor (((y ushr i) and 1) * x) }
        return z
    }

    private fun rsDivisor(degree: Int): IntArray {
        val result = IntArray(degree)
        result[degree - 1] = 1
        var root = 1
        repeat(degree) {
            for (j in result.indices) {
                result[j] = gfMul(result[j], root)
                if (j + 1 < result.size) result[j] = result[j] xor result[j + 1]
            }
            root = gfMul(root, 0x02)
        }
        return result
    }

    private fun rsRemainder(data: IntArray, divisor: IntArray): IntArray {
        val result = IntArray(divisor.size)
        for (b in data) {
            val factor = b xor result[0]
            System.arraycopy(result, 1, result, 0, result.size - 1)
            result[result.size - 1] = 0
            for (i in result.indices) result[i] = result[i] xor gfMul(divisor[i], factor)
        }
        return result
    }

    private fun addEccAndInterleave(data: IntArray, version: Int, ecl: Ecl): IntArray {
        val numBlocks = NUM_BLOCKS[ecl.index][version]
        val blockEccLen = ECC_PER_BLOCK[ecl.index][version]
        val rawCodewords = rawDataModules(version) / 8
        val numShortBlocks = numBlocks - rawCodewords % numBlocks
        val shortBlockLen = rawCodewords / numBlocks
        val divisor = rsDivisor(blockEccLen)
        val dataBlocks = ArrayList<IntArray>()
        val eccBlocks = ArrayList<IntArray>()
        var k = 0
        for (i in 0 until numBlocks) {
            val len = shortBlockLen - blockEccLen + (if (i < numShortBlocks) 0 else 1)
            val dat = data.copyOfRange(k, k + len)
            k += len
            dataBlocks.add(dat)
            eccBlocks.add(rsRemainder(dat, divisor))
        }
        val result = ArrayList<Int>()
        val maxData = shortBlockLen - blockEccLen + 1
        for (i in 0 until maxData) for (j in 0 until numBlocks) if (i < dataBlocks[j].size) result.add(dataBlocks[j][i])
        for (i in 0 until blockEccLen) for (j in 0 until numBlocks) result.add(eccBlocks[j][i])
        check(result.size == rawCodewords) { "codeword count" }
        return result.toIntArray()
    }

    // ------------------------------------------------------------------ drawing

    private class Grid(val size: Int) {
        val dark = BooleanArray(size * size)
        val function = BooleanArray(size * size)
        fun setFunction(x: Int, y: Int, v: Boolean) { dark[y * size + x] = v; function[y * size + x] = true }
    }

    private fun alignmentPositions(version: Int): IntArray {
        if (version == 1) return IntArray(0)
        val numAlign = version / 7 + 2
        val step = if (version == 32) 26 else (version * 4 + numAlign * 2 + 1) / (numAlign * 2 - 2) * 2
        val size = version * 4 + 17
        val result = IntArray(numAlign)
        result[0] = 6
        var pos = size - 7
        for (i in numAlign - 1 downTo 1) { result[i] = pos; pos -= step }
        return result
    }

    private fun bit(x: Int, i: Int) = ((x ushr i) and 1) != 0

    private fun draw(codewords: IntArray, version: Int, ecl: Ecl): Qr {
        val size = version * 4 + 17
        val g = Grid(size)
        for (i in 0 until size) { g.setFunction(6, i, i % 2 == 0); g.setFunction(i, 6, i % 2 == 0) }
        fun finder(cx: Int, cy: Int) {
            for (dy in -4..4) for (dx in -4..4) {
                val dist = maxOf(Math.abs(dx), Math.abs(dy))
                val xx = cx + dx
                val yy = cy + dy
                if (xx in 0 until size && yy in 0 until size) g.setFunction(xx, yy, dist != 2 && dist != 4)
            }
        }
        finder(3, 3); finder(size - 4, 3); finder(3, size - 4)
        val pos = alignmentPositions(version)
        for (i in pos.indices) for (j in pos.indices) {
            if (i == 0 && j == 0 || i == 0 && j == pos.size - 1 || i == pos.size - 1 && j == 0) continue
            for (dy in -2..2) for (dx in -2..2) g.setFunction(pos[i] + dx, pos[j] + dy, maxOf(Math.abs(dx), Math.abs(dy)) != 1)
        }
        fun format(mask: Int) {
            val data = ecl.formatBits shl 3 or mask
            var rem = data
            repeat(10) { rem = (rem shl 1) xor ((rem ushr 9) * 0x537) }
            val bits = (data shl 10 or rem) xor 0x5412
            for (i in 0..5) g.setFunction(8, i, bit(bits, i))
            g.setFunction(8, 7, bit(bits, 6)); g.setFunction(8, 8, bit(bits, 7)); g.setFunction(7, 8, bit(bits, 8))
            for (i in 9 until 15) g.setFunction(14 - i, 8, bit(bits, i))
            for (i in 0 until 8) g.setFunction(size - 1 - i, 8, bit(bits, i))
            for (i in 8 until 15) g.setFunction(8, size - 15 + i, bit(bits, i))
            g.setFunction(8, size - 8, true)
        }
        format(0)
        if (version >= 7) {
            var rem = version
            repeat(12) { rem = (rem shl 1) xor ((rem ushr 11) * 0x1F25) }
            val bits = version shl 12 or rem
            for (i in 0 until 18) {
                val b = bit(bits, i)
                val a = size - 11 + i % 3
                val c = i / 3
                g.setFunction(a, c, b); g.setFunction(c, a, b)
            }
        }
        // zig-zag placement of the codeword bits
        var idx = 0
        var right = size - 1
        while (right >= 1) {
            if (right == 6) right = 5
            for (vert in 0 until size) for (j in 0 until 2) {
                val x = right - j
                val upward = ((right + 1) and 2) == 0
                val y = if (upward) size - 1 - vert else vert
                if (!g.function[y * size + x] && idx < codewords.size * 8) {
                    g.dark[y * size + x] = bit(codewords[idx ushr 3], 7 - (idx and 7))
                    idx++
                }
            }
            right -= 2
        }
        // pick the mask with the lowest penalty
        var best = 0
        var bestPenalty = Int.MAX_VALUE
        for (m in 0 until 8) {
            applyMask(g, m); format(m)
            val p = penalty(g)
            if (p < bestPenalty) { bestPenalty = p; best = m }
            applyMask(g, m)   // XOR again = undo
        }
        applyMask(g, best); format(best)
        return Qr(version, size, best, g.dark)
    }

    private fun applyMask(g: Grid, mask: Int) {
        val size = g.size
        for (y in 0 until size) for (x in 0 until size) {
            val invert = when (mask) {
                0 -> (x + y) % 2 == 0
                1 -> y % 2 == 0
                2 -> x % 3 == 0
                3 -> (x + y) % 3 == 0
                4 -> (x / 3 + y / 2) % 2 == 0
                5 -> x * y % 2 + x * y % 3 == 0
                6 -> (x * y % 2 + x * y % 3) % 2 == 0
                else -> ((x + y) % 2 + x * y % 3) % 2 == 0
            }
            if (invert && !g.function[y * size + x]) g.dark[y * size + x] = !g.dark[y * size + x]
        }
    }

    /** Penalty of ISO/IEC 18004 section 7.8.3: runs of 5+ (N1 = 3 + extra), 2x2 blocks (N2 = 3), finder-like 1:1:3:1:1 patterns (N3 = 40), dark-module balance (N4 = 10 per 5 %). */
    private fun penalty(g: Grid): Int {
        val size = g.size
        var result = 0
        fun at(x: Int, y: Int) = g.dark[y * size + x]
        for (dir in 0..1) {
            for (a in 0 until size) {
                var run = 1
                val sb = StringBuilder()
                for (b in 0 until size) {
                    val v = if (dir == 0) at(b, a) else at(a, b)
                    sb.append(if (v) '1' else '0')
                    if (b > 0) {
                        val prev = if (dir == 0) at(b - 1, a) else at(a, b - 1)
                        if (v == prev) { run++; if (run == 5) result += 3 else if (run > 5) result++ } else run = 1
                    }
                }
                val line = sb.toString()
                var from = 0
                while (true) { val i = line.indexOf("10111010000", from); if (i < 0) break; result += 40; from = i + 1 }
                from = 0
                while (true) { val i = line.indexOf("00001011101", from); if (i < 0) break; result += 40; from = i + 1 }
            }
        }
        for (y in 0 until size - 1) for (x in 0 until size - 1) {
            val c = at(x, y)
            if (c == at(x + 1, y) && c == at(x, y + 1) && c == at(x + 1, y + 1)) result += 3
        }
        var dark = 0
        for (v in g.dark) if (v) dark++
        val total = size * size
        val k = (Math.abs(dark * 20 - total * 10) + total - 1) / total - 1
        result += maxOf(k, 0) * 10
        return result
    }

    // ------------------------------------------------------------------ payload helpers

    /** The text a phone reads as "join this Wi-Fi network": `WIFI:T:<WPA|WEP|nopass>;S:<ssid>;P:<password>;;` with `\ ; , : "` escaped by a backslash. */
    fun wifiPayload(ssid: String, password: String, security: String): String {
        fun esc(s: String) = buildString { for (c in s) { if (c == '\\' || c == ';' || c == ',' || c == ':' || c == '"') append('\\'); append(c) } }
        val type = when (security.uppercase()) { "WEP" -> "WEP"; "NOPASS", "NONE", "" -> "nopass"; else -> "WPA" }
        return if (type == "nopass") "WIFI:T:nopass;S:${esc(ssid)};;" else "WIFI:T:$type;S:${esc(ssid)};P:${esc(password)};;"
    }
}
