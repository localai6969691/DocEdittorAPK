package com.example.docscanner.util

import java.util.Locale

/**
 * Thu muc theo doi (phien 18, PDF "Thieu gi de ban app" muc F / automation): nguoi dung chon mot thu muc (qua Storage Access Framework); moi lan mo app, tep MOI
 * trong thu muc do (anh, PDF) duoc de nghi nhap. Phan LOGIC chon tep o day thuan tuy (khong Android); ban Java chay duoc `tools/verify/WatchFolderCheck.java`,
 * kiem chung boi `tools/verify/watch_folder_check.py`. Phan Android (liet ke thu muc, quyen lau dai, nhap tep) nam trong `MainActivity`.
 *
 * Quy tac: (1) moi tep chi duoc de nghi MOT LAN (nho theo ma tai lieu, toi da [SEEN_CAP] ma moi nhat); (2) khi moi chon thu muc, tep DA CO duoc danh dau da thay - khong nhap
 * hang ton; (3) tep con dang duoc ghi (sua doi cach day duoi [SETTLE_MS]) hoac rong chua duoc de nghi, den lan mo sau; (4) bo tep an, tep tam (.tmp, .part, .crdownload, .pending, .trashed-*).
 */
object WatchFolder {
    const val SEEN_CAP = 2000
    const val SETTLE_MS = 3000L

    class Entry(val id: String, val name: String, val mime: String, val modified: Long, val size: Long)

    enum class Kind { IMAGE, PDF }

    private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp", "heic", "heif", "bmp", "gif")
    private val TEMP_SUFFIX = listOf(".tmp", ".part", ".crdownload", ".pending", ".download")

    fun kindOf(e: Entry): Kind? {
        val name = e.name.lowercase(Locale.ROOT)
        if (name.startsWith(".") || name.startsWith(".trashed") || TEMP_SUFFIX.any { name.endsWith(it) }) return null
        val ext = name.substringAfterLast('.', "")
        val mime = e.mime.lowercase(Locale.ROOT)
        if (mime == "application/pdf" || ext == "pdf") return Kind.PDF
        if (mime.startsWith("image/") || ext in IMAGE_EXT) return if (mime.startsWith("image/") || mime == "application/octet-stream" || mime.isEmpty()) Kind.IMAGE else null
        return null
    }

    /** Tep MOI (chua thay), thuoc loai ho tro, khong rong, da ngung ghi ([SETTLE_MS] ms), xep theo thoi gian sua roi ten tu nhien. */
    fun pick(listing: List<Entry>, seen: Set<String>, now: Long, settleMs: Long = SETTLE_MS): List<Entry> =
        listing.filter { it.id !in seen && kindOf(it) != null && it.size > 0 && now - it.modified >= settleMs }
            .sortedWith(Comparator { a, b -> if (a.modified != b.modified) a.modified.compareTo(b.modified) else ArchiveImages.natural(a.name, b.name) })

    /** Danh sach da thay sau khi them [add]: giu thu tu, khong trung, bo cac ma CU NHAT khi vuot [cap]. */
    fun remember(seen: List<String>, add: Collection<String>, cap: Int = SEEN_CAP): List<String> {
        val all = LinkedHashSet<String>(seen); all.addAll(add)
        val list = all.toList()
        return if (list.size > cap) list.subList(list.size - cap, list.size) else list
    }

    fun encode(ids: List<String>): String = ids.joinToString("\n")
    fun decode(s: String?): List<String> = if (s.isNullOrEmpty()) emptyList() else s.split('\n').filter { it.isNotEmpty() }
}
