package com.example.docscanner.util

import android.content.Context
import android.content.Intent
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import com.example.docscanner.MainActivity
import com.example.docscanner.R

/**
 * Launcher shortcuts (press and hold the app icon): Scan, Book project, Searchable PDF, Sign. They are DYNAMIC shortcuts on
 * purpose: a static `shortcuts.xml` must name the target package, and this project's `applicationId` comes from the `APP_ID`
 * repository variable (see build.gradle), so it is not known when the XML is written. A dynamic shortcut builds its intent
 * from the running app's own context, so it always matches.
 *
 * Each shortcut starts [MainActivity] with one of the `ACTION_*` strings; `MainActivity.handleShortcutIntent` opens the tool.
 */
object AppShortcuts {
    const val ACTION_SCAN = "com.example.docscanner.shortcut.SCAN"
    const val ACTION_PROJECT = "com.example.docscanner.shortcut.PROJECT"
    const val ACTION_SEARCHABLE = "com.example.docscanner.shortcut.SEARCHABLE"
    const val ACTION_SIGN = "com.example.docscanner.shortcut.SIGN"

    /** The actions above, for `MainActivity` to recognise. */
    val ALL_ACTIONS = setOf(ACTION_SCAN, ACTION_PROJECT, ACTION_SEARCHABLE, ACTION_SIGN)

    /** Publishes the shortcuts. Never throws: a launcher that refuses them must not break the app. */
    fun publish(context: Context) {
        try {
            val icon = IconCompat.createWithResource(context, R.mipmap.ic_launcher)
            fun make(id: String, action: String, labelRes: Int, longLabelRes: Int): ShortcutInfoCompat =
                ShortcutInfoCompat.Builder(context, id)
                    .setShortLabel(context.getString(labelRes))
                    .setLongLabel(context.getString(longLabelRes))
                    .setIcon(icon)
                    .setIntent(Intent(context, MainActivity::class.java).setAction(action))
                    .build()
            ShortcutManagerCompat.setDynamicShortcuts(
                context,
                listOf(
                    make("scan", ACTION_SCAN, R.string.shortcut_scan, R.string.shortcut_scan_long),
                    make("project", ACTION_PROJECT, R.string.shortcut_project, R.string.shortcut_project_long),
                    make("searchable", ACTION_SEARCHABLE, R.string.shortcut_searchable, R.string.shortcut_searchable_long),
                    make("sign", ACTION_SIGN, R.string.shortcut_sign, R.string.shortcut_sign_long)
                )
            )
        } catch (e: Exception) {
            // ignore
        }
    }
}
