package com.example.docscanner.util

import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile

/**
 * Sua PDF hong cau truc (phien 18, PDF "Thieu gi de ban app" B13). PdfBox doc o che do khoan dung: khi bang tham chieu (xref) / `startxref` hong no
 * quet toan bo tep de dung lai (COSParser, "rebuild the trailer if startxref can't be found") - nen "sua" = MO roi LUU LAI (viet xref moi) + KIEM LAI ket qua.
 * Khong cuu duoc tep thieu cay trang hoac noi dung trang bi cat; truong hop do [repair] bao loi thay vi tao tep rong.
 *
 * [diagnose] chi nhin vao BYTE (khong goi PdfBox): tieu de, `%%EOF`, `startxref`, va noi dung tai vi tri do. Ban Java chay duoc `tools/verify/PdfRepairCheck.java`;
 * `tools/verify/pdf_repair_check.py` so voi qpdf. [diagnose] KHONG phat hien moi hong (muc xref sai ben trong bang van lot) - chi de thong bao cho nguoi dung; viec sua luon chay.
 */
object PdfRepair {

    /**
     * Hai muc: HONG NANG ([NO_STARTXREF], [BAD_XREF_OFFSET]) - doc phai DUNG LAI bang tham chieu, qpdf cung bao nhu vay (bai kiem xac nhan 0 bao nham);
     * KHONG CHUAN NHUNG DOC DUOC ([NO_HEADER], [NO_EOF], [JUNK_BEFORE_HEADER]) - cac trinh doc khoan dung (qpdf, PdfBox) van mo duoc, viec sua chi chuan hoa lai tep.
     */
    enum class Diagnosis { OK, NO_HEADER, NO_EOF, JUNK_BEFORE_HEADER, NO_STARTXREF, BAD_XREF_OFFSET;
        val severe: Boolean get() = this == NO_STARTXREF || this == BAD_XREF_OFFSET
    }

    class Result(val pages: Int, val diagnosis: Diagnosis)

    private const val HEADER_WINDOW = 1024
    private const val TAIL_WINDOW = 2048

    private fun indexOf(hay: ByteArray, needle: String, from: Int = 0, last: Boolean = false): Int {
        val n = needle.toByteArray(Charsets.ISO_8859_1)
        if (n.isEmpty() || hay.size < n.size) return -1
        val range = if (last) (hay.size - n.size downTo maxOf(from, 0)) else (maxOf(from, 0)..hay.size - n.size)
        for (i in range) {
            var ok = true
            for (j in n.indices) if (hay[i + j] != n[j]) { ok = false; break }
            if (ok) return i
        }
        return -1
    }

    private fun isWs(b: Byte): Boolean = b == 0x20.toByte() || b == 0x0A.toByte() || b == 0x0D.toByte() || b == 0x09.toByte() || b == 0x0C.toByte() || b == 0.toByte()
    private fun isDigit(b: Byte): Boolean = b in '0'.code.toByte()..'9'.code.toByte()

    /** Doc `[size]` byte dau va [TAIL_WINDOW] byte cuoi; [bytes] day du cho tep nho. */
    fun diagnose(file: File): Diagnosis {
        val size = file.length()
        RandomAccessFile(file, "r").use { raf ->
            val head = ByteArray(minOf(size, HEADER_WINDOW.toLong()).toInt()); raf.readFully(head)
            val tailLen = minOf(size, TAIL_WINDOW.toLong()).toInt()
            val tail = ByteArray(tailLen); raf.seek(size - tailLen); raf.readFully(tail)
            return diagnose(head, tail, size) { off, len ->
                if (off < 0 || off >= size) ByteArray(0) else { raf.seek(off); ByteArray(minOf(len.toLong(), size - off).toInt()).also { raf.readFully(it) } }
            }
        }
    }

    internal fun diagnose(head: ByteArray, tail: ByteArray, size: Long, read: (Long, Int) -> ByteArray): Diagnosis {
        val headerAt = indexOf(head, "%PDF-")
        if (headerAt < 0) return Diagnosis.NO_HEADER
        val eofMissing = indexOf(tail, "%%EOF") < 0   // chi la muc NHE neu startxref va bang tham chiếu con nguyen; tep bi cat duoi thuong mat CA hai
        val s = indexOf(tail, "startxref", last = true)
        if (s < 0) return Diagnosis.NO_STARTXREF
        var i = s + "startxref".length
        while (i < tail.size && isWs(tail[i])) i++
        val digitsStart = i
        var offset = 0L
        while (i < tail.size && isDigit(tail[i]) && offset < Long.MAX_VALUE / 20) { offset = offset * 10 + (tail[i] - '0'.code.toByte()); i++ }
        if (i == digitsStart) return Diagnosis.NO_STARTXREF
        offset += headerAt        // vi tri ghi trong tep tinh tu dau tieu de: co rac phia truoc thi bu do lech (nhu qpdf)
        if (offset <= 0 || offset >= size) return Diagnosis.BAD_XREF_OFFSET
        val at = read(offset, 64)
        var k = 0
        while (k < at.size && isWs(at[k])) k++
        val junk = if (eofMissing) Diagnosis.NO_EOF else if (headerAt > 0) Diagnosis.JUNK_BEFORE_HEADER else Diagnosis.OK
        if (at.size - k >= 4 && String(at, k, 4, Charsets.ISO_8859_1) == "xref") return junk
        // luong xref (PDF 1.5+): "<so> <so> obj"
        var p = k
        var groups = 0
        while (groups < 2) {
            val st = p
            while (p < at.size && isDigit(at[p])) p++
            if (p == st) return Diagnosis.BAD_XREF_OFFSET
            while (p < at.size && isWs(at[p])) p++
            groups++
        }
        return if (at.size - p >= 3 && String(at, p, 3, Charsets.ISO_8859_1) == "obj") junk else Diagnosis.BAD_XREF_OFFSET
    }

    /** Mo [src] (khoan dung) roi luu [out]; ket qua duoc MO LAI de kiem so trang. Loi -> [IOException] / IllegalStateException("encrypted"), khong de lai [out]. */
    fun repair(src: File, out: File): Result {
        val diagnosis = diagnose(src)
        val tmp = File(out.path + ".part")
        try {
            val pages: Int
            val doc = PDDocument.load(src, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(src.parentFile))
            try {
                if (doc.isEncrypted) throw IllegalStateException("encrypted")
                pages = doc.numberOfPages
                if (pages <= 0) throw IOException("khong co trang nao")
                doc.save(tmp)
            } finally { runCatching { doc.close() } }
            val again = PDDocument.load(tmp, MemoryUsageSetting.setupMixed(24L * 1024 * 1024).setTempDir(tmp.parentFile))
            try {
                if (again.numberOfPages != pages) throw IOException("so trang sau khi sua khong khop")
            } finally { runCatching { again.close() } }
            if (out.exists() && !out.delete()) throw IOException("khong ghi de duoc dich")
            if (!tmp.renameTo(out)) throw IOException("khong doi ten duoc")
            return Result(pages, diagnosis)
        } catch (e: Exception) {
            tmp.delete()
            throw e
        }
    }
}
