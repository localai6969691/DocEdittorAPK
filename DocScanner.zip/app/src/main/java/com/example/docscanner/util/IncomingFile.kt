package com.example.docscanner.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.IntentCompat

/**
 * Files that ANOTHER app hands to DocScanner: "Open with" on a PDF (`ACTION_VIEW`) and "Share" of one or several PDFs or
 * pictures (`ACTION_SEND` / `ACTION_SEND_MULTIPLE`). `MainActivity` reads them with [urisOf], decides what they are with
 * [classify], asks which tool should take them and starts that tool with the PDF as the intent's data - the PDF screens use
 * it instead of opening the system file picker (see `pickPdfOrUseIncoming` in each of them).
 */
object IncomingFile {

    enum class Kind { PDF, PDF_MANY, IMAGES, UNSUPPORTED }

    /** Every URI the intent carries: its data, the `EXTRA_STREAM` of a share, and its ClipData (a sender may use any of the three). */
    fun urisOf(intent: Intent): List<Uri> {
        val out = LinkedHashSet<Uri>()
        intent.data?.let { out.add(it) }
        when (intent.action) {
            Intent.ACTION_SEND ->
                IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.let { out.add(it) }
            Intent.ACTION_SEND_MULTIPLE ->
                IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.let { out.addAll(it) }
        }
        val clip = intent.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { out.add(it) }
        }
        return out.toList()
    }

    /**
     * [types] and [names] are the MIME type and the display name of each URI (either may be null: a sender that does not
     * declare a type is judged by the file name). All PDFs -> [Kind.PDF] (one) or [Kind.PDF_MANY]; all pictures -> [Kind.IMAGES];
     * anything else, or a mixture, -> [Kind.UNSUPPORTED] (guessing which half the user meant would be worse than saying no).
     */
    fun classify(types: List<String?>, names: List<String?>): Kind {
        if (types.isEmpty()) return Kind.UNSUPPORTED
        fun isPdf(i: Int) = types[i].equals("application/pdf", ignoreCase = true) ||
            (types[i].isNullOrBlank() || types[i] == "application/octet-stream") && names.getOrNull(i)?.endsWith(".pdf", ignoreCase = true) == true
        fun isImage(i: Int) = types[i]?.startsWith("image/", ignoreCase = true) == true
        val indices = types.indices
        return when {
            indices.all { isPdf(it) } -> if (types.size == 1) Kind.PDF else Kind.PDF_MANY
            indices.all { isImage(it) } -> Kind.IMAGES
            else -> Kind.UNSUPPORTED
        }
    }

    /**
     * What a file IS, from its first bytes: the general answer to "which type does this file manager announce?". A sender that declares nothing, a wildcard or
     * application/octet-stream (some file managers, some drags) is judged by content instead of being refused or guessed per app (session 23, 4.60).
     * [head] = at least the first 12 bytes (fewer is fine). PDF: "%PDF-" at the start, or a few bytes later (a byte-order mark or a blank line before it is common).
     * Returns application/pdf, image/jpeg, image/png, image/webp, application/zip (also .docx / .epub: not handled here), or null when nothing is recognised.
     */
    fun sniffType(head: ByteArray): String? {
        fun at(offset: Int, vararg expected: Int): Boolean =
            head.size >= offset + expected.size && expected.indices.all { (head[offset + it].toInt() and 0xFF) == expected[it] }
        for (offset in 0..4) if (at(offset, 0x25, 0x50, 0x44, 0x46, 0x2D)) return "application/pdf"
        return when {
            at(0, 0xFF, 0xD8, 0xFF) -> "image/jpeg"
            at(0, 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A) -> "image/png"
            at(0, 0x52, 0x49, 0x46, 0x46) && at(8, 0x57, 0x45, 0x42, 0x50) -> "image/webp"
            at(0, 0x50, 0x4B, 0x03, 0x04) -> "application/zip"
            else -> null
        }
    }

    /** The file's display name as the sender's provider reports it, or null. */
    fun displayName(context: Context, uri: Uri): String? = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }
}
