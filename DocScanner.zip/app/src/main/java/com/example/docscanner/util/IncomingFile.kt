package com.example.docscanner.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.IntentCompat

/**
 * Files that ANOTHER app hands to DocScanner: "Open with" on a PDF (`ACTION_VIEW`) and "Share" of one or several PDFs or
 * pictures (`ACTION_SEND` / `ACTION_SEND_MULTIPLE`). `MainActivity` reads them with [urisOf], decides what they are with
 * [classify], asks which tool should take them and starts that tool with the PDF as the intent's data - the PDF screens use
 * it instead of opening the system file picker (see `pickPdfOrUseIncoming` in each of them).
 */
object IncomingFile {

    enum class Kind { PDF, PDF_MANY, IMAGES, UNSUPPORTED }

    /** Every URI the intent carries: its data, the `EXTRA_STREAM` of a share, and its ClipData (a sender may use any of the three). */
    fun urisOf(intent: Intent): List<Uri> {
        val out = LinkedHashSet<Uri>()
        intent.data?.let { out.add(it) }
        when (intent.action) {
            Intent.ACTION_SEND ->
                IntentCompat.getParcelableExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.let { out.add(it) }
            Intent.ACTION_SEND_MULTIPLE ->
                IntentCompat.getParcelableArrayListExtra(intent, Intent.EXTRA_STREAM, Uri::class.java)?.let { out.addAll(it) }
        }
        val clip = intent.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) clip.getItemAt(i).uri?.let { out.add(it) }
        }
        return out.toList()
    }

    /**
     * [types] and [names] are the MIME type and the display name of each URI (either may be null: a sender that does not
     * declare a type is judged by the file name). All PDFs -> [Kind.PDF] (one) or [Kind.PDF_MANY]; all pictures -> [Kind.IMAGES];
     * anything else, or a mixture, -> [Kind.UNSUPPORTED] (guessing which half the user meant would be worse than saying no).
     */
    fun classify(types: List<String?>, names: List<String?>): Kind {
        if (types.isEmpty()) return Kind.UNSUPPORTED
        fun isPdf(i: Int) = types[i].equals("application/pdf", ignoreCase = true) ||
            (types[i].isNullOrBlank() || types[i] == "application/octet-stream") && names.getOrNull(i)?.endsWith(".pdf", ignoreCase = true) == true
        fun isImage(i: Int) = types[i]?.startsWith("image/", ignoreCase = true) == true
        val indices = types.indices
        return when {
            indices.all { isPdf(it) } -> if (types.size == 1) Kind.PDF else Kind.PDF_MANY
            indices.all { isImage(it) } -> Kind.IMAGES
            else -> Kind.UNSUPPORTED
        }
    }

    /** The file's display name as the sender's provider reports it, or null. */
    fun displayName(context: Context, uri: Uri): String? = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (e: Exception) {
        null
    }
}
