package com.example.docscanner.util

import java.text.Normalizer

/**
 * Search INSIDE one EPUB (PDF list C7): every place a word or phrase occurs, with the chapter and a little context.
 *
 * The match ignores case AND accents, the way people type on a phone: "nguyen" finds "Nguyễn", "DUONG" finds "đường" (the letter đ counts
 * as d). It also works on books whose accents are stored as separate combining marks (e + U+0301), which many converters produce: the marks
 * are dropped while folding, and an index map takes every match back to the ORIGINAL text, so the context shown is the book's own text.
 * Runs of whitespace (including no-break spaces) count as one space on both sides, so a phrase split over a line break is found.
 * Pure Kotlin; mirrored by tools/verify/EpubSearchCheck.java.
 */
object EpubSearch {

    const val MAX_HITS = 300
    const val CONTEXT_CHARS = 60

    class Hit(val chapter: Int, val paragraph: Int, val before: String, val match: String, val after: String)

    class Folded(val text: String, val origin: IntArray)

    private fun isMark(c: Char): Boolean = Character.getType(c).let {
        it == Character.NON_SPACING_MARK.toInt() || it == Character.COMBINING_SPACING_MARK.toInt() || it == Character.ENCLOSING_MARK.toInt()
    }

    private fun isSpace(c: Char): Boolean = Character.isWhitespace(c) || Character.isSpaceChar(c)

    /** Lower case, accents removed, đ -> d, whitespace runs -> one space; [Folded.origin] maps each folded char to the index of its source char. */
    fun fold(s: String): Folded {
        val sb = StringBuilder(s.length)
        val map = IntArray(s.length + 1)
        var n = 0
        var lastSpace = true                               // also trims leading whitespace
        for (i in s.indices) {
            val c = s[i]
            if (isSpace(c)) {
                if (!lastSpace) { sb.append(' '); map[n++] = i; lastSpace = true }
                continue
            }
            if (isMark(c)) continue
            var f = Character.toLowerCase(c)
            if (f == 'đ') f = 'd'
            else if (f.code >= 0xC0) {                                     // plain ASCII needs no decomposition (keeps a whole book fast)
                val d = Normalizer.normalize(f.toString(), Normalizer.Form.NFD)
                f = d[0]
                if (isMark(f)) continue
            }
            sb.append(f); map[n++] = i; lastSpace = false
        }
        if (sb.isNotEmpty() && sb[sb.length - 1] == ' ') { sb.setLength(sb.length - 1); n-- }
        map[n] = s.length
        return Folded(sb.toString(), map.copyOf(n + 1))
    }

    /** Whitespace runs -> one space; the ends are kept as they are (the context next to a match must keep its space). */
    private fun squeezeKeep(s: String): String {
        val sb = StringBuilder(s.length)
        var lastSpace = false
        for (c in s) {
            if (isSpace(c)) { if (!lastSpace) sb.append(' '); lastSpace = true } else { sb.append(c); lastSpace = false }
        }
        return sb.toString()
    }

    private fun safeStart(s: String, i: Int): Int = if (i > 0 && i < s.length && Character.isLowSurrogate(s[i]) && Character.isHighSurrogate(s[i - 1])) i - 1 else i

    /**
     * All hits in reading order (at most [limit]). [totalHits] receives the number found, which can be larger than the list when [limit] cut it
     * (the scan goes on counting, so the screen can say "300 of 1 240").
     */
    fun search(chapters: List<EbookBuilder.Chapter>, query: String, limit: Int = MAX_HITS, totalHits: IntArray? = null): List<Hit> {
        val needle = fold(query).text
        val out = ArrayList<Hit>()
        var total = 0
        if (needle.isNotEmpty()) {
            for ((ci, chapter) in chapters.withIndex()) {
                for ((pi, paragraph) in chapter.paragraphs.withIndex()) {
                    val folded = fold(paragraph)
                    var from = 0
                    while (true) {
                        val at = folded.text.indexOf(needle, from)
                        if (at < 0) break
                        total++
                        if (out.size < limit) {
                            val start = folded.origin[at]
                            val end = folded.origin[at + needle.length - 1] + 1            // end of the LAST matched source char
                            var realEnd = end
                            while (realEnd < paragraph.length && isMark(paragraph[realEnd])) realEnd++     // a matched letter keeps its own combining marks
                            val b = safeStart(paragraph, maxOf(0, start - CONTEXT_CHARS))
                            val a = safeStart(paragraph, minOf(paragraph.length, realEnd + CONTEXT_CHARS))
                            out.add(Hit(ci, pi,
                                (if (b > 0) "…" else "") + squeezeKeep(paragraph.substring(b, start)),
                                squeezeKeep(paragraph.substring(start, realEnd)).trim(),
                                squeezeKeep(paragraph.substring(realEnd, a)) + (if (a < paragraph.length) "…" else "")))
                        }
                        from = at + needle.length
                    }
                }
            }
        }
        totalHits?.let { if (it.isNotEmpty()) it[0] = total }
        return out
    }

    /** The text file shown to the person: a header line, then per chapter its title and each hit with the match between « and ». */
    fun render(hits: List<Hit>, chapters: List<EbookBuilder.Chapter>, header: String, more: String?, chapterLabel: (Int, String) -> String): String {
        val sb = StringBuilder(header).append("\n")
        if (more != null) sb.append(more).append("\n")
        var last = -1
        for (h in hits) {
            if (h.chapter != last) { sb.append("\n").append(chapterLabel(h.chapter + 1, chapters[h.chapter].title.trim())).append("\n"); last = h.chapter }
            sb.append("• ").append(h.before).append('«').append(h.match).append('»').append(h.after).append("\n")
        }
        return sb.toString()
    }
}
