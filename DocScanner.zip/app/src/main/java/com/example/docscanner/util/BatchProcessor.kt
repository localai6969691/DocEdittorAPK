package com.example.docscanner.util

import java.io.File

/**
 * One operation applied to many PDFs in a row (the screen picks the files, calls [apply] for each, and reports how many
 * worked). Only operations that need at most one setting are offered, so a single answer can serve every file (compression needs none: the app's PDF compressor has a single mode). Each file
 * is processed independently into a NEW file; a failure on one file (password-protected, damaged) is reported for that
 * file and the rest go on.
 */
object BatchProcessor {

    /** [suffix] is appended to the original name: "Hop dong.pdf" -> "Hop dong_numbered.pdf". */
    enum class Op(val suffix: String) {
        NUMBER("numbered"),
        WATERMARK("watermark"),
        PASSWORD("locked"),
        STRIP("clean"),
        TWO_UP("2up"),
        COMPRESS("compressed")
    }

    /** [argument] is the watermark text or the password; the other operations ignore it. Throws on failure. */
    fun apply(op: Op, argument: String, src: File, out: File) {
        when (op) {
            Op.NUMBER -> PdfDecorator.decorate(
                src, out,
                PdfDecorator.Options(labels = listOf(PdfDecorator.Label(PdfDecorator.Place.BOTTOM_CENTER, "Trang {n} / {N}")))
            )
            Op.WATERMARK -> PdfSecurityTools.watermark(src, out, argument)
            Op.PASSWORD -> PdfSecurityTools.protect(src, out, argument)
            Op.STRIP -> PdfMetadataTools.strip(src, out)
            Op.TWO_UP -> PdfImposer.impose(src, out, PdfImposer.Mode.TWO_UP)
            Op.COMPRESS -> PdfObjectRecompressor.recompress(src, out)
        }
    }
}
