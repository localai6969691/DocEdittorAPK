package com.example.docscanner.util

import java.io.ByteArrayInputStream
import java.security.KeyStore
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Signature
import java.security.cert.X509Certificate
import java.security.interfaces.ECPublicKey
import java.security.interfaces.RSAPublicKey
import java.text.Normalizer

/**
 * Reads a certificate + private key from a PKCS#12 file (`.p12` / `.pfx`) so the digital signature can be made with a certificate the person already
 * owns (PDF list 3.x "chứng thư từ tệp .p12"; a certificate bought from / issued by a certificate authority is what lets a recipient's viewer trust
 * WHO signed). The file itself is never kept: [PdfDigitalSigner.importPkcs12] moves the key into the Android Keystore (where it can be used to sign
 * but not read back) and the bytes and the password are dropped.
 *
 * Everything here is plain `java.security`, so tools/verify/Pkcs12ImportCheck.java (a twin on a JVM) tests the decisions without a phone. What the checks
 * decide, in this order, and what each failure means to the person:
 *  - [Reason.BAD_FILE_OR_PASSWORD]: the file is not PKCS#12 or the password is wrong (the format gives no reliable way to tell the two apart);
 *  - [Reason.NO_KEY]: a file with certificates only (a `.cer` renamed, or a public bundle) has nothing to sign with;
 *  - [Reason.NOT_YET_VALID] / [Reason.EXPIRED]: a signature made with a certificate outside its validity would be reported as invalid by every viewer;
 *  - [Reason.UNSUPPORTED_KEY]: only RSA and EC keys are supported by [CmsSigner] (SHA-256 with RSA PKCS#1 v1.5, or ECDSA);
 *  - [Reason.WEAK_KEY]: RSA under 2 048 bits or an EC curve under 256 bits;
 *  - [Reason.KEY_MISMATCH]: the private key does not belong to the certificate (a sign + verify round trip with random data proves it).
 */
object Pkcs12Import {

    enum class Reason { BAD_FILE_OR_PASSWORD, NO_KEY, EXPIRED, NOT_YET_VALID, UNSUPPORTED_KEY, WEAK_KEY, KEY_MISMATCH }

    class ImportException(val reason: Reason) : Exception(reason.name)

    /** [chain] starts with the signer's own certificate, then the issuers up to (and maybe including) the root. */
    class Result(val key: PrivateKey, val chain: List<X509Certificate>)

    const val MIN_RSA_BITS = 2048
    const val MIN_EC_BITS = 256

    /**
     * The password as typed, then its NFC and NFD forms (when they differ). BouncyCastle (Android's PKCS#12 reader) turns the password into UTF-16
     * as it is, WITHOUT normalising Unicode, so "ệ" typed as one letter does not open a file made with "e" + two combining marks - and files exported
     * on a Mac very often carry the decomposed (NFD) form. tools/verify/pkcs12_bc_check.py measures exactly this failure.
     */
    internal fun passwordVariants(password: CharArray): List<CharArray> {
        val typed = String(password)
        return listOf(typed, Normalizer.normalize(typed, Normalizer.Form.NFC), Normalizer.normalize(typed, Normalizer.Form.NFD)).distinct().map { it.toCharArray() }
    }

    fun read(bytes: ByteArray, password: CharArray, nowMillis: Long = System.currentTimeMillis()): Result {
        val variants = passwordVariants(password)
        try {
            return readWith(bytes, variants, nowMillis)
        } finally {
            variants.forEach { it.fill('\u0000') }
        }
    }

    private fun readWith(bytes: ByteArray, variants: List<CharArray>, nowMillis: Long): Result {
        var key: PrivateKey? = null
        var chain: List<X509Certificate>? = null
        // 1. Android's own reader first: it handles the old encryptions (RC2-40 for certificates, for example), which [Pkcs12Modern] does not
        for (candidate in variants) {
            try {
                val store = KeyStore.getInstance("PKCS12").apply { load(ByteArrayInputStream(bytes), candidate) }
                val alias = store.aliases().toList().firstOrNull { store.isKeyEntry(it) } ?: throw ImportException(Reason.NO_KEY)    // a file of certificates only: nothing to sign with
                key = store.getKey(alias, candidate) as? PrivateKey
                chain = store.getCertificateChain(alias)?.filterIsInstance<X509Certificate>()?.takeIf { it.isNotEmpty() }
                if (key != null && chain != null) break
            } catch (e: ImportException) {
                throw e
            } catch (e: Exception) {
                key = null; chain = null          // wrong password, not a PKCS#12 file, OR a newer encryption this Android cannot read: try the next form / the fallback
            }
        }
        // 2. the fallback reader for what the system refuses although the password is right (OpenSSL 3's PBES2 / AES-256 + HMAC-SHA-256 files)
        if (key == null || chain == null) {
            for (candidate in variants) {
                try {
                    val parsed = Pkcs12Modern.parse(bytes, candidate)
                    key = parsed.privateKey; chain = parsed.chain
                    break
                } catch (e: Pkcs12Modern.ParseException) {
                    // wrong password / malformed / an encryption it does not read: next form of the password
                }
            }
        }
        if (key == null || chain == null) throw ImportException(Reason.BAD_FILE_OR_PASSWORD)
        val leaf = chain[0]
        if (nowMillis < leaf.notBefore.time) throw ImportException(Reason.NOT_YET_VALID)
        if (nowMillis > leaf.notAfter.time) throw ImportException(Reason.EXPIRED)
        val algorithm = when (key.algorithm.uppercase()) {
            "RSA" -> {
                val bits = (leaf.publicKey as? RSAPublicKey)?.modulus?.bitLength() ?: throw ImportException(Reason.KEY_MISMATCH)
                if (bits < MIN_RSA_BITS) throw ImportException(Reason.WEAK_KEY)
                "SHA256withRSA"
            }
            "EC" -> {
                val bits = (leaf.publicKey as? ECPublicKey)?.params?.order?.bitLength() ?: throw ImportException(Reason.KEY_MISMATCH)
                if (bits < MIN_EC_BITS) throw ImportException(Reason.WEAK_KEY)
                "SHA256withECDSA"
            }
            else -> throw ImportException(Reason.UNSUPPORTED_KEY)
        }
        val probe = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val matches = try {
            val sig = Signature.getInstance(algorithm).apply { initSign(key); update(probe) }.sign()
            Signature.getInstance(algorithm).apply { initVerify(leaf.publicKey); update(probe) }.verify(sig)
        } catch (e: Exception) { false }
        if (!matches) throw ImportException(Reason.KEY_MISMATCH)
        return Result(key, chain)
    }
}
