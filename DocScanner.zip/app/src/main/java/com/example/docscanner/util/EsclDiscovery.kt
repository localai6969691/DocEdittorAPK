package com.example.docscanner.util

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Handler
import android.os.Looper

/**
 * Finds eSCL scanners on the Wi-Fi by mDNS / DNS-SD (`_uscan._tcp`, the service type eSCL scanners advertise; the TXT key `rs` holds the resource root, normally `eSCL`)
 * - phiên 17, mục 4.31. Android's NsdManager resolves ONE service at a time, so found services are queued and resolved in turn. Results are delivered on the main thread.
 * Scanners that only advertise the TLS variant (`_uscans._tcp`) are not listed: they use self-signed certificates that the platform rejects; the person can still type their
 * address. Android-only glue and NOT run against a real network: discovery is a convenience, and the typed address ([EsclProtocol.baseUrl]) is the path that is tested.
 */
class EsclDiscovery(context: Context, private val onFound: (Scanner) -> Unit) {

    class Scanner(val name: String, val base: String)

    private val nsd = context.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val main = Handler(Looper.getMainLooper())
    private val queue = ArrayDeque<NsdServiceInfo>()
    private val seen = HashSet<String>()
    private var resolving = false
    private var active = false

    private val discoveryListener = object : NsdManager.DiscoveryListener {
        override fun onDiscoveryStarted(serviceType: String) {}
        override fun onServiceFound(info: NsdServiceInfo) { synchronized(this@EsclDiscovery) { queue.add(info) }; resolveNext() }
        override fun onServiceLost(info: NsdServiceInfo) {}
        override fun onDiscoveryStopped(serviceType: String) {}
        override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { active = false }
        override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
    }

    fun start() {
        if (active) return
        active = true
        try { nsd.discoverServices("_uscan._tcp", NsdManager.PROTOCOL_DNS_SD, discoveryListener) } catch (e: Exception) { active = false }
    }

    fun stop() {
        if (!active) return
        active = false
        try { nsd.stopServiceDiscovery(discoveryListener) } catch (e: Exception) { /* already stopped */ }
        synchronized(this) { queue.clear() }
    }

    @Suppress("DEPRECATION")
    private fun resolveNext() {
        val next: NsdServiceInfo
        synchronized(this) {
            if (resolving) return
            next = queue.removeFirstOrNull() ?: return
            resolving = true
        }
        try {
            nsd.resolveService(next, object : NsdManager.ResolveListener {
                override fun onResolveFailed(info: NsdServiceInfo, errorCode: Int) { done() }
                override fun onServiceResolved(info: NsdServiceInfo) {
                    try { handle(info) } finally { done() }
                }
            })
        } catch (e: Exception) {
            done()
        }
    }

    private fun done() {
        synchronized(this) { resolving = false }
        resolveNext()
    }

    private fun handle(info: NsdServiceInfo) {
        var host = info.host?.hostAddress ?: return
        if (host.contains('%')) host = host.substringBefore('%')      // scope id of a link-local IPv6 address: not usable in a URL
        if (host.contains(':')) host = "[$host]"
        val rs = info.attributes?.get("rs")?.let { String(it, Charsets.UTF_8) }?.trim('/')?.ifEmpty { null } ?: "eSCL"
        val base = EsclProtocol.baseUrl("$host:${info.port}/$rs") ?: return
        if (!seen.add(base)) return
        main.post { onFound(Scanner(info.serviceName ?: base, base)) }
    }
}
