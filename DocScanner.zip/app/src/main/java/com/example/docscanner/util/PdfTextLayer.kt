package com.example.docscanner.util

import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.File

/**
 * The words of a page read from the PDF's OWN text layer (phiên 20, 4.48.7), as [PdfTextMarkup.WordBox] on the displayed page. For a text PDF (an export of this app with its invisible
 * OCR layer, a Word / web export) this is exact and instant, where the OCR path renders the page and guesses. The geometry is [TextLayerWords]; THIS file is the PDFBox glue and has NOT been run
 * (no Android here): it relies on `PDFTextStripper.writeString` being called once per WORD with that word's `TextPosition`s, and on `TextPosition.getXDirAdj / getYDirAdj /
 * getWidthDirAdj / getFontSizeInPt / getPageWidth / getPageHeight` being the position in the DISPLAYED page (rotation applied), origin top-left, y downward; these are the documented meanings.
 *
 * Returns an empty list for a page with no text (a scan): the caller then falls back to OCR. Null for an encrypted file or any failure.
 */
object PdfTextLayer {

    fun words(file: File, pageIndex: Int): List<PdfTextMarkup.WordBox>? = try {
        PDDocument.load(file).use { doc ->
            if (doc.isEncrypted || pageIndex !in 0 until doc.numberOfPages) return null
            val out = ArrayList<PdfTextMarkup.WordBox>()
            val stripper = object : PDFTextStripper() {
                var line = 0
                override fun writeString(text: String, textPositions: List<TextPosition>) {
                    val word = text.trim()
                    if (word.isEmpty() || textPositions.isEmpty()) return
                    val first = textPositions[0]
                    val glyphs = textPositions.map { TextLayerWords.Glyph(it.xDirAdj, it.yDirAdj, it.widthDirAdj, it.fontSizeInPt) }
                    TextLayerWords.wordBox(glyphs, first.pageWidth, first.pageHeight)?.let { out.add(PdfTextMarkup.WordBox(word, it, line)) }
                }
                override fun writeLineSeparator() {
                    line++
                    super.writeLineSeparator()
                }
            }
            stripper.sortByPosition = true
            stripper.startPage = pageIndex + 1
            stripper.endPage = pageIndex + 1
            stripper.getText(doc)
            out
        }
    } catch (e: Exception) {
        null
    }
}
