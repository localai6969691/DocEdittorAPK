package com.example.docscanner.util

import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import java.io.File

/**
 * The words of a page read from the PDF's OWN text layer (phiên 20, 4.48.7), as [PdfTextMarkup.WordBox] on the displayed page. For a text PDF (an export of this app with its invisible
 * OCR layer, a Word / web export) this is exact and instant, where the OCR path renders the page and guesses. The geometry is [TextLayerWords]; this file is the PDFBox glue. It was NOT run
 * until phiên 24 (4.67), and running it found that its one assumption was wrong: `PDFTextStripper.writeString` is called once per RUN of text, not once per word (a space is an
 * ordinary glyph, so a whole line often arrives as one string), which made every line one "word" with one box. It now splits each run into words itself, at the glyphs that are blank,
 * using the position of every glyph (`TextPosition.unicode`, `getXDirAdj / getYDirAdj / getWidthDirAdj / getFontSizeInPt / getPageWidth / getPageHeight`: the position in the
 * DISPLAYED page when the text reads left to right on it, rotation applied, origin top-left, y downward) and never the length of the string, which PDFBox may normalise. Text that is
 * shown at another angle on the displayed page (`TextPosition.dir` is not 0) is skipped: its glyph positions are in the frame of the text direction, not of the page.
 *
 * Returns an empty list for a page with no text (a scan): the caller then falls back to OCR. Null for an encrypted file or any failure.
 */
object PdfTextLayer {

    fun words(file: File, pageIndex: Int): List<PdfTextMarkup.WordBox>? = try {
        PDDocument.load(file).use { doc ->
            if (doc.isEncrypted || pageIndex !in 0 until doc.numberOfPages) return null
            val out = ArrayList<PdfTextMarkup.WordBox>()
            val stripper = object : PDFTextStripper() {
                var line = 0
                override fun writeString(text: String, textPositions: List<TextPosition>) {
                    if (textPositions.isEmpty()) return
                    // Only text that reads left to right along the DISPLAYED page. `dir` is the direction of the text in the page as STORED (from the text matrix, page rotation not applied);
                    // the page is shown turned by its /Rotate, so the text is upright on screen when dir - rotation is 0 (a landscape scan: dir 90 on a /Rotate 90 page; a normal page: 0 and 0).
                    // The glyph positions (xDirAdj ...) are in the frame of the text direction, so for text shown sideways or upside down the boxes would be wrong: such runs are left out and the
                    // caller uses OCR / the dragged rectangle instead of a wrong target.
                    val pageRotation = ((currentPage.rotation % 360) + 360) % 360
                    if (((textPositions[0].dir.toInt() - pageRotation) % 360 + 360) % 360 != 0) return
                    val pageWidth = textPositions[0].pageWidth
                    val pageHeight = textPositions[0].pageHeight
                    val word = StringBuilder()
                    var glyphs = ArrayList<TextLayerWords.Glyph>()
                    for (position in textPositions) {
                        val unicode = position.unicode ?: ""
                        if (unicode.isBlank()) {
                            addWord(word, glyphs, pageWidth, pageHeight)
                            word.setLength(0)
                            glyphs = ArrayList()
                        } else {
                            word.append(unicode)
                            glyphs.add(TextLayerWords.Glyph(position.xDirAdj, position.yDirAdj, position.widthDirAdj, position.fontSizeInPt))
                        }
                    }
                    addWord(word, glyphs, pageWidth, pageHeight)
                }

                private fun addWord(word: StringBuilder, glyphs: List<TextLayerWords.Glyph>, pageWidth: Float, pageHeight: Float) {
                    if (word.isEmpty() || glyphs.isEmpty()) return
                    TextLayerWords.wordBox(glyphs, pageWidth, pageHeight)?.let { out.add(PdfTextMarkup.WordBox(word.toString(), it, line)) }
                }

                override fun writeLineSeparator() {
                    line++
                    super.writeLineSeparator()
                }
            }
            stripper.sortByPosition = true
            stripper.startPage = pageIndex + 1
            stripper.endPage = pageIndex + 1
            stripper.getText(doc)
            out
        }
    } catch (e: Exception) {
        null
    }
}
