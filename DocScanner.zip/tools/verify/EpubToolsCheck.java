import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;
import org.w3c.dom.*;

/**
 * Ban Java chay duoc cua util/EpubTools.kt (phien 18): sua thong tin, doi anh bia, ghep, tach EPUB o MUC GOI ZIP (khong dung lai qua van ban,
 * nen anh / CSS / phong chu duoc giu). Chi dung java.util.zip + DOM nhu ban Kotlin. Chay: java EpubToolsCheck.java <lenh> ...
 */
public class EpubToolsCheck {
    static final String DC = "http://purl.org/dc/elements/1.1/", OPF = "http://www.idpf.org/2007/opf", OPS = "http://www.idpf.org/2007/ops";
    static final String MIME = "application/epub+zip";

    // ---------------------------------------------------------------- duong dan
    static String norm(String p) {
        ArrayList<String> out = new ArrayList<>();
        for (String s : p.split("/")) {
            if (s.isEmpty() || s.equals(".")) continue;
            if (s.equals("..")) { if (!out.isEmpty()) out.remove(out.size() - 1); continue; }
            out.add(s);
        }
        return String.join("/", out);
    }
    static String percentDecode(String s) {
        if (s.indexOf('%') < 0) return s;
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] raw = s.getBytes(StandardCharsets.UTF_8);
        for (int i = 0; i < raw.length; i++) {
            if (raw[i] == '%' && i + 2 < raw.length + 0 && hex(raw[i + 1]) >= 0 && hex(raw[i + 2]) >= 0) {
                b.write(hex(raw[i + 1]) * 16 + hex(raw[i + 2])); i += 2;
            } else b.write(raw[i]);
        }
        return new String(b.toByteArray(), StandardCharsets.UTF_8);
    }
    static int hex(int c) { return c >= '0' && c <= '9' ? c - '0' : c >= 'a' && c <= 'f' ? c - 'a' + 10 : c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1; }
    /** Duong dan trong goi (da giai ma %) cua tham chieu [ref] viet trong tep [base]; null neu la lien ket ngoai / rong. */
    static String resolve(String base, String ref) {
        String r = ref.trim();
        int h = r.indexOf('#'); if (h >= 0) r = r.substring(0, h);
        int q = r.indexOf('?'); if (q >= 0) r = r.substring(0, q);
        if (r.isEmpty()) return null;
        if (r.matches("^[A-Za-z][A-Za-z0-9+.\\-]*:.*") || r.startsWith("//")) return null;
        r = percentDecode(r);
        if (r.startsWith("/")) return norm(r.substring(1));
        String dir = base.contains("/") ? base.substring(0, base.lastIndexOf('/') + 1) : "";
        return norm(dir + r);
    }
    /** Ma hoa % cho phan duong dan trong thuoc tinh href (chi cac ky tu co the lam hong IRI). */
    static String enc(String path) {
        StringBuilder sb = new StringBuilder();
        for (char c : path.toCharArray()) {
            if (c == ' ' || c == '%' || c == '#' || c == '?' || c == '"' || c == '<' || c == '>') sb.append(String.format("%%%02X", (int) c)); else sb.append(c);
        }
        return sb.toString();
    }
    static String relFrom(String fromFile, String target) {
        String[] a = (fromFile.contains("/") ? fromFile.substring(0, fromFile.lastIndexOf('/')) : "").split("/");
        ArrayList<String> from = new ArrayList<>(); for (String s : a) if (!s.isEmpty()) from.add(s);
        ArrayList<String> to = new ArrayList<>(); for (String s : target.split("/")) if (!s.isEmpty()) to.add(s);
        int i = 0; while (i < from.size() && i < to.size() - 1 && from.get(i).equals(to.get(i))) i++;
        StringBuilder sb = new StringBuilder();
        for (int k = i; k < from.size(); k++) sb.append("../");
        for (int k = i; k < to.size(); k++) { sb.append(to.get(k)); if (k < to.size() - 1) sb.append('/'); }
        return sb.toString();
    }

    // ---------------------------------------------------------------- XML
    static Document parse(byte[] data) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        try { f.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false); } catch (Exception ignore) { }
        DocumentBuilder b = f.newDocumentBuilder();
        b.setEntityResolver((p, s) -> new org.xml.sax.InputSource(new StringReader("")));
        return b.parse(new ByteArrayInputStream(data));
    }
    static byte[] serialize(Document d) throws Exception {
        Transformer t = TransformerFactory.newInstance().newTransformer();
        t.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        t.setOutputProperty(OutputKeys.METHOD, "xml");
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        t.transform(new DOMSource(d), new StreamResult(o));
        return o.toByteArray();
    }
    static String esc(String s) {
        StringBuilder sb = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c == '&') sb.append("&amp;"); else if (c == '<') sb.append("&lt;"); else if (c == '>') sb.append("&gt;"); else if (c == '"') sb.append("&quot;");
            else if (c < 0x20 && c != '\t' && c != '\n' && c != '\r') continue; else sb.append(c);
        }
        return sb.toString();
    }
    static boolean hasToken(String s, String t) { for (String x : s.trim().split("\\s+")) if (x.equals(t)) return true; return false; }
    static List<Element> children(Element e, String ns, String local) {
        ArrayList<Element> r = new ArrayList<>();
        for (Node n = e.getFirstChild(); n != null; n = n.getNextSibling())
            if (n instanceof Element && local.equals(n.getLocalName()) && (ns == null || ns.equals(n.getNamespaceURI()))) r.add((Element) n);
        return r;
    }

    // ---------------------------------------------------------------- goi
    static class Item { String id, href, path, type, props, fallback; }
    static class Ref { String idref, linear; }
    static class Pkg {
        ZipFile zip; String opfPath, opfDir, version; Document doc;
        List<Item> items = new ArrayList<>(); Map<String, Item> byId = new HashMap<>(); Map<String, Item> byPath = new HashMap<>();
        List<Ref> spine = new ArrayList<>(); Item nav, ncx;
        String coverId() {
            for (Item i : items) if (hasToken(i.props, "cover-image")) return i.id;
            NodeList ms = doc.getElementsByTagNameNS("*", "meta");
            for (int k = 0; k < ms.getLength(); k++) { Element m = (Element) ms.item(k); if ("cover".equals(m.getAttribute("name")) && byId.containsKey(m.getAttribute("content"))) return m.getAttribute("content"); }
            return null;
        }
    }
    static byte[] readEntry(ZipFile z, String name) throws IOException {
        ZipEntry e = z.getEntry(name); if (e == null) return null;
        try (InputStream in = z.getInputStream(e)) { return in.readAllBytes(); }
    }
    static Pkg load(ZipFile z) throws Exception {
        byte[] c = readEntry(z, "META-INF/container.xml");
        if (c == null) throw new IOException("khong co container.xml");
        NodeList rf = parse(c).getElementsByTagNameNS("*", "rootfile");
        if (rf.getLength() == 0) throw new IOException("khong co rootfile");
        Pkg p = new Pkg(); p.zip = z;
        p.opfPath = norm(percentDecode(((Element) rf.item(0)).getAttribute("full-path")));
        p.opfDir = p.opfPath.contains("/") ? p.opfPath.substring(0, p.opfPath.lastIndexOf('/')) : "";
        byte[] o = readEntry(z, p.opfPath); if (o == null) throw new IOException("khong co tep OPF");
        p.doc = parse(o);
        p.version = p.doc.getDocumentElement().getAttribute("version");
        NodeList its = p.doc.getElementsByTagNameNS("*", "item");
        for (int k = 0; k < its.getLength(); k++) {
            Element e = (Element) its.item(k);
            Item it = new Item(); it.id = e.getAttribute("id"); it.href = e.getAttribute("href"); it.type = e.getAttribute("media-type");
            it.props = e.getAttribute("properties"); it.fallback = e.getAttribute("fallback");
            it.path = resolve(p.opfPath, it.href);
            if (it.id.isEmpty() || it.path == null) continue;
            p.items.add(it); p.byId.put(it.id, it); p.byPath.put(it.path, it);
            if (hasToken(it.props, "nav")) p.nav = it;
            if (it.type.equals("application/x-dtbncx+xml")) p.ncx = it;
        }
        NodeList refs = p.doc.getElementsByTagNameNS("*", "itemref");
        for (int k = 0; k < refs.getLength(); k++) {
            Element e = (Element) refs.item(k); Ref r = new Ref(); r.idref = e.getAttribute("idref"); r.linear = e.getAttribute("linear");
            if (p.byId.containsKey(r.idref)) p.spine.add(r);
        }
        return p;
    }
    static boolean isDoc(Item i) { return i.type.equals("application/xhtml+xml") || i.type.equals("text/html"); }

    // ---------------------------------------------------------------- thong tin
    record Meta(String title, List<String> authors, String language, String publisher, String description, String identifier) { }

    static Meta readMeta(File epub) throws Exception {
        try (ZipFile z = new ZipFile(epub)) {
            Pkg p = load(z);
            NodeList ml = p.doc.getElementsByTagNameNS("*", "metadata");
            if (ml.getLength() == 0) return new Meta("", List.of(), "", "", "", "");
            Element m = (Element) ml.item(0);
            String uid = p.doc.getDocumentElement().getAttribute("unique-identifier");
            String title = "", lang = "", pub = "", desc = "", ident = "";
            List<String> au = new ArrayList<>();
            for (Element e : children(m, DC, "title")) { title = e.getTextContent().trim(); break; }
            for (Element e : children(m, DC, "creator")) { String t = e.getTextContent().trim(); if (!t.isEmpty()) au.add(t); }
            for (Element e : children(m, DC, "language")) { lang = e.getTextContent().trim(); break; }
            for (Element e : children(m, DC, "publisher")) { pub = e.getTextContent().trim(); break; }
            for (Element e : children(m, DC, "description")) { desc = e.getTextContent().trim(); break; }
            for (Element e : children(m, DC, "identifier")) { if (ident.isEmpty() || e.getAttribute("id").equals(uid)) ident = e.getTextContent().trim(); }
            return new Meta(title, au, lang, pub, desc, ident);
        }
    }

    interface Replace { byte[] bytes(String entryName); }   // null = giu nguyen / bo qua theo ngu canh

    /** Ghi lai [src] vao [dst]: mimetype dau tien va KHONG nen; cac tep con lai theo thu tu goc; [replace] doi noi dung, [skip] bo qua, [extra] them moi. */
    static void rewrite(File src, File dst, Map<String, byte[]> replace, Set<String> skip, LinkedHashMap<String, byte[]> extra) throws Exception {
        File tmp = new File(dst.getPath() + ".part");
        try (ZipFile z = new ZipFile(src); ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)))) {
            byte[] mt = MIME.getBytes(StandardCharsets.US_ASCII);
            putStored(out, "mimetype", mt);
            for (Enumeration<? extends ZipEntry> en = z.entries(); en.hasMoreElements(); ) {
                ZipEntry e = en.nextElement(); String n = e.getName();
                if (n.equals("mimetype") || e.isDirectory() || skip.contains(n)) continue;
                byte[] data = replace.containsKey(n) ? replace.get(n) : readEntry(z, n);
                out.putNextEntry(new ZipEntry(n)); out.write(data); out.closeEntry();
            }
            for (Map.Entry<String, byte[]> x : extra.entrySet()) { out.putNextEntry(new ZipEntry(x.getKey())); out.write(x.getValue()); out.closeEntry(); }
        }
        if (dst.exists() && !dst.delete()) throw new IOException("khong ghi de duoc dich");
        if (!tmp.renameTo(dst)) throw new IOException("khong doi ten duoc");
    }
    static void putStored(ZipOutputStream out, String name, byte[] data) throws IOException {
        ZipEntry e = new ZipEntry(name); e.setMethod(ZipEntry.STORED); e.setSize(data.length); e.setCompressedSize(data.length);
        CRC32 c = new CRC32(); c.update(data); e.setCrc(c.getValue());
        out.putNextEntry(e); out.write(data); out.closeEntry();
    }

    static void writeMeta(File src, File dst, Meta meta, String nowIso) throws Exception {
        byte[] opfBytes;
        String opfPath;
        try (ZipFile z = new ZipFile(src)) {
            Pkg p = load(z); opfPath = p.opfPath;
            Document d = p.doc;
            NodeList ml = d.getElementsByTagNameNS("*", "metadata");
            if (ml.getLength() == 0) throw new IOException("OPF khong co metadata");
            Element m = (Element) ml.item(0);
            String oldTitle = "", oldLang = "";
            for (Element e : children(m, DC, "title")) { oldTitle = e.getTextContent().trim(); break; }
            for (Element e : children(m, DC, "language")) { oldLang = e.getTextContent().trim(); break; }
            String title = meta.title().trim().isEmpty() ? oldTitle : meta.title().trim();
            String lang = meta.language().trim().isEmpty() ? oldLang : meta.language().trim();
            List<Element> managed = new ArrayList<>();
            for (String n : new String[]{"title", "creator", "language", "publisher", "description"}) managed.addAll(children(m, DC, n));
            Node anchor = managed.isEmpty() ? null : managed.get(0);
            // thu tu: tieu de, tac gia, ngon ngu, nha xuat ban, mo ta - chen TRUOC phan tu cu dau tien roi xoa phan tu cu
            ArrayList<Element> fresh = new ArrayList<>();
            fresh.add(dc(d, "title", title));
            for (String a : meta.authors()) if (!a.trim().isEmpty()) fresh.add(dc(d, "creator", a.trim()));
            if (!lang.isEmpty()) fresh.add(dc(d, "language", lang));
            if (!meta.publisher().trim().isEmpty()) fresh.add(dc(d, "publisher", meta.publisher().trim()));
            if (!meta.description().trim().isEmpty()) fresh.add(dc(d, "description", meta.description().trim()));
            for (Element f : fresh) { if (anchor != null) m.insertBefore(f, anchor); else m.appendChild(f); }
            for (Element old : managed) m.removeChild(old);
            // dcterms:modified
            boolean found = false;
            for (Element e : children(m, OPF, "meta")) if ("dcterms:modified".equals(e.getAttribute("property"))) { e.setTextContent(nowIso); found = true; }
            if (!found && p.version.startsWith("3")) {
                Element e = d.createElementNS(OPF, "meta"); e.setAttribute("property", "dcterms:modified"); e.setTextContent(nowIso); m.appendChild(e);
            }
            opfBytes = serialize(d);
        }
        Map<String, byte[]> rep = new HashMap<>(); rep.put(opfPath, opfBytes);
        rewrite(src, dst, rep, Set.of(), new LinkedHashMap<>());
    }
    static Element dc(Document d, String local, String text) {
        Element e = d.createElementNS(DC, "dc:" + local); e.setTextContent(text); return e;
    }

    // ---------------------------------------------------------------- bia
    static String mediaTypeOfImage(String ext) {
        switch (ext.toLowerCase()) { case "jpg": case "jpeg": return "image/jpeg"; case "png": return "image/png"; case "gif": return "image/gif"; case "webp": return "image/webp"; default: return null; }
    }
    /** Thay anh bia: neu sach da co anh bia thi GHI DE noi dung tai CHINH duong dan cu (trang bia XHTML tro toi no van dung); chua co thi them muc moi. */
    static void setCover(File src, File dst, byte[] image, String ext, String nowIso) throws Exception {
        String mt = mediaTypeOfImage(ext);
        if (mt == null) throw new IOException("dinh dang anh khong ho tro: " + ext);
        Map<String, byte[]> rep = new HashMap<>(); LinkedHashMap<String, byte[]> extra = new LinkedHashMap<>();
        try (ZipFile z = new ZipFile(src)) {
            Pkg p = load(z); Document d = p.doc; String cid = p.coverId();
            NodeList ml = d.getElementsByTagNameNS("*", "metadata"); NodeList mf = d.getElementsByTagNameNS("*", "manifest");
            if (ml.getLength() == 0 || mf.getLength() == 0) throw new IOException("OPF thieu metadata/manifest");
            Element meta = (Element) ml.item(0), man = (Element) mf.item(0);
            if (cid != null) {
                Item it = p.byId.get(cid); rep.put(it.path, image);
                for (Element e : children(man, OPF, "item")) if (cid.equals(e.getAttribute("id"))) e.setAttribute("media-type", mt);
            } else {
                String name = "images/docscanner-cover." + ext.toLowerCase().replace("jpeg", "jpg");
                String path = norm((p.opfDir.isEmpty() ? "" : p.opfDir + "/") + name);
                while (z.getEntry(path) != null) path = path.replace("docscanner-cover", "docscanner-cover-1");
                String id = "docscanner-cover"; while (p.byId.containsKey(id)) id += "-1";
                Element e = d.createElementNS(OPF, "item"); e.setAttribute("id", id); e.setAttribute("href", enc(relFrom(p.opfPath, path))); e.setAttribute("media-type", mt);
                if (p.version.startsWith("3")) e.setAttribute("properties", "cover-image");
                man.appendChild(e);
                Element m2 = d.createElementNS(OPF, "meta"); m2.setAttribute("name", "cover"); m2.setAttribute("content", id); meta.appendChild(m2);
                extra.put(path, image);
            }
            if (p.version.startsWith("3")) {
                boolean found = false;
                for (Element e : children(meta, OPF, "meta")) if ("dcterms:modified".equals(e.getAttribute("property"))) { e.setTextContent(nowIso); found = true; }
                if (!found) { Element e = d.createElementNS(OPF, "meta"); e.setAttribute("property", "dcterms:modified"); e.setTextContent(nowIso); meta.appendChild(e); }
            }
            rep.put(p.opfPath, serialize(d));
        }
        rewrite(src, dst, rep, Set.of(), extra);
    }

    // ---------------------------------------------------------------- muc luc goc
    static class Toc { String title, path, frag; }
    static List<Toc> tocOf(Pkg p) throws Exception {
        ArrayList<Toc> out = new ArrayList<>();
        if (p.nav != null) {
            byte[] b = readEntry(p.zip, p.nav.path);
            if (b != null) {
                Document d = parse(b); NodeList navs = d.getElementsByTagNameNS("*", "nav"); Element toc = null;
                for (int i = 0; i < navs.getLength() && toc == null; i++) { Element e = (Element) navs.item(i); if (hasToken(e.getAttributeNS(OPS, "type"), "toc")) toc = e; }
                if (toc == null && navs.getLength() > 0) toc = (Element) navs.item(0);
                if (toc != null) {
                    NodeList as = toc.getElementsByTagNameNS("*", "a");
                    for (int i = 0; i < as.getLength(); i++) { Element a = (Element) as.item(i); addToc(out, p.nav.path, a.getAttribute("href"), a.getTextContent()); }
                }
            }
        }
        if (out.isEmpty() && p.ncx != null) {
            byte[] b = readEntry(p.zip, p.ncx.path);
            if (b != null) {
                Document d = parse(b); NodeList pts = d.getElementsByTagNameNS("*", "navPoint");
                for (int i = 0; i < pts.getLength(); i++) {
                    Element np = (Element) pts.item(i);
                    NodeList t = np.getElementsByTagNameNS("*", "text"), c = np.getElementsByTagNameNS("*", "content");
                    if (t.getLength() > 0 && c.getLength() > 0) addToc(out, p.ncx.path, ((Element) c.item(0)).getAttribute("src"), t.item(0).getTextContent());
                }
            }
        }
        return out;
    }
    static void addToc(List<Toc> out, String base, String href, String title) {
        String path = resolve(base, href); String t = title.replaceAll("\\s+", " ").trim();
        if (path == null || t.isEmpty()) return;
        Toc x = new Toc(); x.title = t; x.path = path; int h = href.indexOf('#'); x.frag = h >= 0 ? href.substring(h + 1) : ""; out.add(x);
    }

    // ---------------------------------------------------------------- tham chieu (cat tia ban)
    static final Pattern ATTR = Pattern.compile("(?:\\bsrc|\\bhref|\\bposter|\\bdata|xlink:href)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')", Pattern.CASE_INSENSITIVE);
    static final Pattern CSSURL = Pattern.compile("url\\(\\s*(?:\"([^\"]*)\"|'([^']*)'|([^)\\s]*))\\s*\\)", Pattern.CASE_INSENSITIVE);
    static final Pattern CSSIMPORT = Pattern.compile("@import\\s+(?:\"([^\"]*)\"|'([^']*)')", Pattern.CASE_INSENSITIVE);
    static Set<String> refsOf(String path, String text) {
        LinkedHashSet<String> out = new LinkedHashSet<>();
        for (Pattern pt : new Pattern[]{ATTR, CSSURL, CSSIMPORT}) {
            Matcher m = pt.matcher(text);
            while (m.find()) {
                String v = null; for (int g = 1; g <= m.groupCount(); g++) if (m.group(g) != null) { v = m.group(g); break; }
                if (v == null) continue; String r = resolve(path, v); if (r != null) out.add(r);
            }
        }
        return out;
    }

    // ---------------------------------------------------------------- ghep / tach
    static class Source { File file; List<Integer> spine; String title; Source(File f, List<Integer> s, String t) { file = f; spine = s; title = t; } }

    /** Dung mot EPUB moi tu [books]. [prune]: chi giu tai nguyen duoc cac trang giu lai (va CSS cua chung) nhac toi + anh bia. */
    static void build(List<Source> books, String title, String language, List<String> authors, boolean prune, File dst, String nowIso, String uuid) throws Exception {
        LinkedHashMap<String, byte[]> files = new LinkedHashMap<>();
        StringBuilder manifest = new StringBuilder(), spine = new StringBuilder();
        StringBuilder navLis = new StringBuilder(), ncxPts = new StringBuilder();
        int[] order = {0};
        String firstCoverId = null;
        boolean wrap = books.size() > 1;
        ArrayList<ZipFile> open = new ArrayList<>();
        try {
            for (int bi = 0; bi < books.size(); bi++) {
                Source s = books.get(bi); ZipFile z = new ZipFile(s.file); open.add(z);
                Pkg p = load(z); String pre = "b" + (bi + 1);
                List<Ref> keptRefs = new ArrayList<>();
                if (s.spine == null) keptRefs.addAll(p.spine); else for (int idx : s.spine) if (idx >= 1 && idx <= p.spine.size()) keptRefs.add(p.spine.get(idx - 1));
                if (keptRefs.isEmpty()) throw new IOException("khong co muc nao trong " + s.file.getName());
                Set<String> docPaths = new LinkedHashSet<>(); for (Ref r : keptRefs) docPaths.add(p.byId.get(r.idref).path);
                // tai nguyen giu lai
                Set<String> keep = new LinkedHashSet<>();
                String coverId = p.coverId();
                if (prune) {
                    ArrayDeque<String> queue = new ArrayDeque<>(docPaths);
                    Set<String> seen = new HashSet<>(docPaths);
                    while (!queue.isEmpty()) {
                        String cur = queue.poll(); byte[] b = readEntry(z, cur); if (b == null) continue;
                        Item ci = p.byPath.get(cur);
                        if (ci != null && !isDoc(ci) && !ci.type.equals("text/css")) continue;
                        for (String r : refsOf(cur, new String(b, StandardCharsets.UTF_8))) {
                            Item it = p.byPath.get(r);
                            if (it == null || it == p.nav || it == p.ncx || isDoc(it)) continue;
                            if (seen.add(r)) { keep.add(r); queue.add(r); }
                        }
                    }
                    if (coverId != null && bi == 0) keep.add(p.byId.get(coverId).path);
                } else {
                    for (Item it : p.items) if (it != p.nav && it != p.ncx && !docPaths.contains(it.path)) keep.add(it.path);
                }
                Set<String> include = new LinkedHashSet<>(docPaths); include.addAll(keep);
                // manifest
                for (Item it : p.items) {
                    if (!include.contains(it.path) || it == p.nav || it == p.ncx) continue;
                    manifest.append("<item id=\"").append(esc(pre + "-" + it.id)).append("\" href=\"").append(esc(enc(pre + "/" + it.path))).append("\" media-type=\"").append(esc(it.type)).append('"');
                    String props = Arrays.stream(it.props.trim().split("\\s+")).filter(x -> !x.isEmpty() && !x.equals("nav") && !x.equals("cover-image")).reduce((a, b) -> a + " " + b).orElse("");
                    if (bi == 0 && it.id.equals(coverId)) props = (props + " cover-image").trim();
                    if (!props.isEmpty()) manifest.append(" properties=\"").append(esc(props)).append('"');
                    if (!it.fallback.isEmpty() && include.contains(p.byId.containsKey(it.fallback) ? p.byId.get(it.fallback).path : "")) manifest.append(" fallback=\"").append(esc(pre + "-" + it.fallback)).append('"');
                    manifest.append("/>\n");
                    if (bi == 0 && it.id.equals(coverId)) firstCoverId = pre + "-" + it.id;
                }
                for (Ref r : keptRefs) {
                    spine.append("<itemref idref=\"").append(esc(pre + "-" + r.idref)).append('"');
                    if (!r.linear.isEmpty()) spine.append(" linear=\"").append(esc(r.linear)).append('"');
                    spine.append("/>\n");
                }
                // tep
                for (String path : include) { byte[] b = readEntry(z, path); if (b != null) files.put("OEBPS/" + pre + "/" + path, b); }
                // muc luc
                List<Toc> toc = new ArrayList<>(); for (Toc t : tocOf(p)) if (docPaths.contains(t.path)) toc.add(t);
                if (toc.isEmpty()) { int k = 1; for (String dp : docPaths) { Toc t = new Toc(); t.title = "Part " + k++; t.path = dp; t.frag = ""; toc.add(t); } }
                String indent = wrap ? "  " : "";
                if (wrap) {
                    navLis.append("<li><a href=\"").append(esc(enc(pre + "/" + docPaths.iterator().next()))).append("\">").append(esc(s.title)).append("</a>\n<ol>\n");
                    order[0]++; ncxPts.append("<navPoint id=\"np-").append(order[0]).append("\" playOrder=\"").append(order[0]).append("\"><navLabel><text>").append(esc(s.title)).append("</text></navLabel><content src=\"").append(esc(enc(pre + "/" + docPaths.iterator().next()))).append("\"/>\n");
                }
                for (Toc t : toc) {
                    String href = enc(pre + "/" + t.path) + (t.frag.isEmpty() ? "" : "#" + t.frag);
                    navLis.append(indent).append("<li><a href=\"").append(esc(href)).append("\">").append(esc(t.title)).append("</a></li>\n");
                    order[0]++; ncxPts.append(indent).append("<navPoint id=\"np-").append(order[0]).append("\" playOrder=\"").append(order[0]).append("\"><navLabel><text>").append(esc(t.title)).append("</text></navLabel><content src=\"").append(esc(href)).append("\"/></navPoint>\n");
                }
                if (wrap) { navLis.append("</ol></li>\n"); ncxPts.append("</navPoint>\n"); }
            }
            StringBuilder opf = new StringBuilder();
            opf.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<package xmlns=\"").append(OPF).append("\" version=\"3.0\" unique-identifier=\"bookid\">\n<metadata xmlns:dc=\"").append(DC).append("\">\n");
            opf.append("<dc:identifier id=\"bookid\">urn:uuid:").append(esc(uuid)).append("</dc:identifier>\n<dc:title>").append(esc(title)).append("</dc:title>\n");
            for (String a : authors) opf.append("<dc:creator>").append(esc(a)).append("</dc:creator>\n");
            opf.append("<dc:language>").append(esc(language.isEmpty() ? "vi" : language)).append("</dc:language>\n<meta property=\"dcterms:modified\">").append(esc(nowIso)).append("</meta>\n");
            if (firstCoverId != null) opf.append("<meta name=\"cover\" content=\"").append(esc(firstCoverId)).append("\"/>\n");
            opf.append("</metadata>\n<manifest>\n<item id=\"nav\" href=\"nav.xhtml\" media-type=\"application/xhtml+xml\" properties=\"nav\"/>\n<item id=\"ncx\" href=\"toc.ncx\" media-type=\"application/x-dtbncx+xml\"/>\n");
            opf.append(manifest).append("</manifest>\n<spine toc=\"ncx\">\n").append(spine).append("</spine>\n</package>\n");
            String nav = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:epub=\"" + OPS + "\"><head><title>" + esc(title) + "</title></head><body>\n<nav epub:type=\"toc\"><h1>" + esc(title) + "</h1>\n<ol>\n" + navLis + "</ol></nav>\n</body></html>\n";
            String ncx = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<ncx xmlns=\"http://www.daisy.org/z3986/2005/ncx/\" version=\"2005-1\"><head><meta name=\"dtb:uid\" content=\"urn:uuid:" + esc(uuid) + "\"/></head><docTitle><text>" + esc(title) + "</text></docTitle><navMap>\n" + ncxPts + "</navMap></ncx>\n";
            String container = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<container version=\"1.0\" xmlns=\"urn:oasis:names:tc:opendocument:xmlns:container\"><rootfiles><rootfile full-path=\"OEBPS/content.opf\" media-type=\"application/oebps-package+xml\"/></rootfiles></container>\n";
            File tmp = new File(dst.getPath() + ".part");
            try (ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)))) {
                putStored(out, "mimetype", MIME.getBytes(StandardCharsets.US_ASCII));
                put(out, "META-INF/container.xml", container.getBytes(StandardCharsets.UTF_8));
                put(out, "OEBPS/content.opf", opf.toString().getBytes(StandardCharsets.UTF_8));
                put(out, "OEBPS/nav.xhtml", nav.getBytes(StandardCharsets.UTF_8));
                put(out, "OEBPS/toc.ncx", ncx.getBytes(StandardCharsets.UTF_8));
                for (Map.Entry<String, byte[]> e : files.entrySet()) put(out, e.getKey(), e.getValue());
            }
            if (dst.exists() && !dst.delete()) throw new IOException("khong ghi de duoc dich");
            if (!tmp.renameTo(dst)) throw new IOException("khong doi ten duoc");
        } finally { for (ZipFile z : open) try { z.close(); } catch (IOException ignore) { } }
    }
    static void put(ZipOutputStream out, String name, byte[] b) throws IOException { out.putNextEntry(new ZipEntry(name)); out.write(b); out.closeEntry(); }

    /** Tach: moi phan la mot EPUB gom cac muc spine [a..b] (1-based, bao gom). */
    static List<List<Integer>> parseParts(String spec, int n) {
        ArrayList<List<Integer>> parts = new ArrayList<>();
        for (String piece : spec.split(",", -1)) {
            String t = piece.trim(); if (t.isEmpty()) throw new IllegalArgumentException("phan rong");
            int a, b; int dash = t.indexOf('-');
            if (dash < 0) { a = b = Integer.parseInt(t); } else { a = t.substring(0, dash).trim().isEmpty() ? 1 : Integer.parseInt(t.substring(0, dash).trim()); b = t.substring(dash + 1).trim().isEmpty() ? n : Integer.parseInt(t.substring(dash + 1).trim()); }
            if (a < 1 || b > n || a > b) throw new IllegalArgumentException("khoang khong hop le: " + t);
            ArrayList<Integer> l = new ArrayList<>(); for (int i = a; i <= b; i++) l.add(i); parts.add(l);
        }
        return parts;
    }

    // ---------------------------------------------------------------- CLI
    public static void main(String[] a) throws Exception {
        String now = "2026-10-16T00:00:00Z";
        switch (a[0]) {
            case "meta-read": {
                Meta m = readMeta(new File(a[1]));
                System.out.println("title\t" + m.title()); System.out.println("authors\t" + String.join("|", m.authors())); System.out.println("language\t" + m.language());
                System.out.println("publisher\t" + m.publisher()); System.out.println("description\t" + m.description().replace("\n", "\\n")); System.out.println("identifier\t" + m.identifier()); break;
            }
            case "meta-write": {   // src dst title authors(|) language publisher description
                writeMeta(new File(a[1]), new File(a[2]), new Meta(a[3], a[4].isEmpty() ? List.of() : Arrays.asList(a[4].split("\\|")), a[5], a[6], a[7], ""), now); System.out.println("OK"); break;
            }
            case "cover": {   // src dst image
                String f = a[3]; String ext = f.substring(f.lastIndexOf('.') + 1);
                setCover(new File(a[1]), new File(a[2]), java.nio.file.Files.readAllBytes(new File(f).toPath()), ext, now); System.out.println("OK"); break;
            }
            case "merge": {   // dst title lang src...
                ArrayList<Source> bs = new ArrayList<>(); LinkedHashSet<String> au = new LinkedHashSet<>();
                for (int i = 4; i < a.length; i++) { Meta m = readMeta(new File(a[i])); bs.add(new Source(new File(a[i]), null, m.title().isEmpty() ? new File(a[i]).getName() : m.title())); au.addAll(m.authors()); }
                build(bs, a[2], a[3], new ArrayList<>(au), false, new File(a[1]), now, "00000000-0000-4000-8000-000000000001"); System.out.println("OK"); break;
            }
            case "split": {   // src dstPrefix spec
                File src = new File(a[1]); Meta m; int n;
                try (ZipFile z = new ZipFile(src)) { n = load(z).spine.size(); } m = readMeta(src);
                List<List<Integer>> parts = parseParts(a[3], n); int k = 1;
                for (List<Integer> part : parts) {
                    File out = new File(a[2] + "-" + k + ".epub");
                    build(List.of(new Source(src, part, m.title())), m.title() + " (phần " + k + ")", m.language(), m.authors(), true, out, now, String.format("00000000-0000-4000-8000-%012d", k)); k++;
                }
                System.out.println("OK " + parts.size()); break;
            }
            case "parts": {   // n spec -> in ra cac phan hoac LOI
                try { List<List<Integer>> p = parseParts(a[2], Integer.parseInt(a[1])); StringBuilder sb = new StringBuilder(); for (List<Integer> l : p) sb.append(l.get(0)).append('-').append(l.get(l.size() - 1)).append(';'); System.out.println(sb); }
                catch (Exception e) { System.out.println("LOI"); }
                break;
            }
            case "parts-batch": {   // tep: moi dong "n<TAB>spec" -> mot dong ket qua
                for (String line : java.nio.file.Files.readAllLines(new File(a[1]).toPath(), StandardCharsets.UTF_8)) {
                    int t = line.indexOf('\t'); int n = Integer.parseInt(line.substring(0, t)); String spec = line.substring(t + 1);
                    try { List<List<Integer>> p = parseParts(spec, n); StringBuilder sb = new StringBuilder(); for (List<Integer> l : p) sb.append(l.get(0)).append('-').append(l.get(l.size() - 1)).append(';'); System.out.println(sb); }
                    catch (Exception e) { System.out.println("LOI"); }
                }
                break;
            }
            default: System.out.println("lenh la: " + a[0]); System.exit(2);
        }
    }
}
