#!/usr/bin/env python3
"""Năm tiện ích PdfBox CHẠY THẬT lần đầu (phiên 26, TECHNICAL_DOCS.md 4.81): sửa thông tin PDF, ghép trang N-up / sổ gấp, áp phích, tuyến tính hoá, tự tạo liên kết.

Từ phiên 15 đến 25 mọi tiện ích này chỉ có bản Java / Python "chép lại" (`metadata_check`, `imposition_check`, `poster_check`, `linearize_check`, `pdf_links_portfolio_check`) và phần PdfBox của
mã Kotlin thật chưa từng chạy ở đâu ngoài CI biên dịch. Bộ này biên dịch CHÍNH `PdfMetadataTools.kt`, `PdfImposer.kt`, `PdfPoster.kt`, `PdfLinearizer.kt` (+ `Linearizer.kt`), `PdfAutoLinks.kt`
bằng kotlinc trên PdfBox-Android dựng từ mã nguồn (real_run/toolchain.py), gọi qua `real_run/UtilityHarness.kt`, rồi đo bằng công cụ ĐỘC LẬP:

  A. thông tin PDF (pikepdf, pdfinfo, qpdf): ghi 4 trường (có tiếng Việt, cắt khoảng trắng, trường trống bị bỏ), các mục Info khác được giữ, XMP cũ bị bỏ (nếu không, trình đọc vẫn hiện tiêu đề cũ),
     xoá hẳn, tệp mã hoá bị từ chối, qpdf --check sạch;
  B. ghép trang (pdftoppm): 2-up / 4-up / sổ gấp trên 5 trang có /Rotate 90, CropBox lệch, khổ ngang; mỗi ô trên tờ được DỰNG LẠI từ trang gốc bằng pdftoppm rồi so điểm ảnh
     (đúng chỗ, đúng chiều, đúng thứ tự trang, ô trống thì trắng); thứ tự sổ gấp theo định nghĩa chuẩn (không chép công thức của mã);
  C. áp phích: ghép các tờ lại theo bước (rộng in được - 10 mm chồng) rồi so với trang gốc phóng to dựng bằng pdftoppm; dải chồng của hai tờ kề nhau phải KHỚP; lề không có mực (trừ dấu cắt);
  D. tuyến tính hoá: `qpdf --check` và `qpdf --check-linearization` sạch, `pdfinfo` báo "Optimized: yes", chữ từng trang giữ nguyên, thuộc tính thừa kế (/Rotate, /MediaBox, /Resources từ nút Pages)
     được đẩy xuống từng trang, mục lục giữ nguyên, tệp mã hoá bị từ chối;
  E. tự tạo liên kết: số liên kết, địa chỉ đích, và HÌNH CHỮ NHẬT bấm được so với hộp của chữ do `pdftotext -bbox` đo; trang xoay bị đếm và bỏ qua; không đè lên liên kết sẵn có; `classify` trên 20 từ.
THỬ ÂM TÍNH: 8 bản mã bị làm hỏng (còn XMP cũ, bỏ dịch chuyển trong ô, sai thứ tự sổ gấp, sai bước xếp tờ áp phích, không đẩy /Rotate xuống trang, vùng bấm lệch, VÀ hai bản vá của phiên 26
đặt lại như cũ: /Info trực tiếp bị rơi, thuộc tính thừa kế còn ở nút cha) PHẢI bị bắt.
THAY THẾ DUY NHẤT so với mã thật: `PdfVerify.opensAsPdf` (PdfRenderer của Android) -> kiểm bằng PdfBox "mở được và đủ số trang". KHÔNG kiểm được: máy in thật, Acrobat, điện thoại.
Chạy: python3 tools/verify/utility_real_run_check.py [--fast]   (--mutant=N chỉ chạy bản hỏng thứ N, 1-8; --fast bỏ phần thử âm tính)"""
import os, re, shutil, subprocess, sys, tempfile, time
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
import pikepdf  # noqa: E402
from pikepdf import Array, Dictionary, Name, String  # noqa: E402
from PIL import Image  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="utility-")
DOUBLE = {"PdfVerify.kt": ("    fun opensAsPdf(file: File, expectedPages: Int): Boolean {",
    "    fun opensAsPdf(file: File, expectedPages: Int): Boolean {\n        return try {\n            if (!file.exists() || file.length() <= 0L) return false\n"
    "            com.tom_roush.pdfbox.pdmodel.PDDocument.load(file).use { d -> d.numberOfPages > 0 && (expectedPages <= 0 || d.numberOfPages == expectedPages) }\n        } catch (e: Exception) { false }\n    }")}
FILES = ["PdfMetadataTools.kt", "PdfImposer.kt", "PdfPoster.kt", "PdfLinearizer.kt", "Linearizer.kt", "PdfAutoLinks.kt", "PdfPageGeometry.kt", "PdfStructureOptimizer.kt", "PdfVerify.kt"]
HARNESS = os.path.join(HERE, "real_run", "UtilityHarness.kt")
def build(mutate=None, tag="base"): return tc.compile(FILES, [HARNESS], os.path.join(WORK, "cls-" + tag), mutate, DOUBLE)[0]
def hz(cls, *args):
    r = tc.run(cls, "UtilityHarnessKt", list(args))
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-800:])
    return r.stdout.strip().splitlines()[-1] if r.stdout.strip() else ""
def sh(*c): return subprocess.run(c, capture_output=True, text=True)
def qpdf_clean(path):
    r = sh("qpdf", "--check", path); text = r.stdout + r.stderr
    return r.returncode == 0 and "No syntax or stream encoding errors" in text and "WARNING" not in text, text[-400:]
def P(name): return os.path.join(WORK, name)

# ----------------------------------------------------------------------------------------------------- test documents (built with pikepdf, independent of the code under test)
def helv(pdf): return pdf.make_indirect(Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Helvetica))

def pattern_page(pdf, font, w, h, label, rotate=0, crop=None, seed=0):
    """A page whose RAW content has an asymmetric pattern (red block bottom-left, green block top-right, a label, a diagonal) so any wrong placement / rotation / mirroring shows."""
    x0, y0, x1, y1 = crop if crop else (0, 0, w, h)
    cw, ch = x1 - x0, y1 - y0
    body = (f"1 0 0 rg {x0 + 10} {y0 + 10} {cw * .28:.1f} {ch * .12:.1f} re f\n"
            f"0 .6 0 rg {x1 - cw * .30 - 10:.1f} {y1 - ch * .15 - 10:.1f} {cw * .30:.1f} {ch * .15:.1f} re f\n"
            f"0 0 1 RG 3 w {x0 + 20} {y0 + ch * .3:.1f} m {x1 - 30} {y1 - ch * .4:.1f} l S\n"
            f"0 g BT /F1 {max(18, int(ch * .09))} Tf {x0 + cw * .15:.1f} {y0 + ch * .55:.1f} Td ({label}) Tj ET\n"
            f"0 g 1 w {x0 + 2} {y0 + 2} {cw - 4} {ch - 4} re S\n")
    page = pdf.make_indirect(Dictionary(Type=Name.Page, MediaBox=Array([0, 0, w, h]), Contents=pdf.make_stream(body.encode()), Resources=Dictionary(Font=Dictionary(F1=font))))
    if crop: page.CropBox = Array(list(crop))
    if rotate: page.Rotate = rotate
    return page

def build_doc(path, specs, info=None):
    pdf = pikepdf.new(); font = helv(pdf)
    pages = [pattern_page(pdf, font, **s) for s in specs]
    pdf.Root.Pages.Kids = Array(pages); pdf.Root.Pages.Count = len(pages)
    if info:
        for k, v in info.items(): pdf.docinfo[k] = v
    pdf.save(path, compress_streams=False); return path

SPEC5 = [dict(w=612, h=792, label="P1"), dict(w=612, h=792, label="P2", rotate=90), dict(w=700, h=900, label="P3", crop=(50, 60, 650, 860)),
         dict(w=792, h=612, label="P4"), dict(w=612, h=792, label="P5", rotate=270, crop=(20, 30, 520, 700))]

def displayed_size(spec):
    x0, y0, x1, y1 = spec.get("crop") or (0, 0, spec["w"], spec["h"])
    w, h = x1 - x0, y1 - y0
    return (h, w) if spec.get("rotate", 0) in (90, 270) else (w, h)

def render(pdf, page, w=None, h=None, dpi=None, swap=False):
    """[w] x [h] = the size of the page AS DISPLAYED. poppler (24.02) applies -scale-to-x / -scale-to-y to the UNROTATED page, so a page with /Rotate 90 or 270 gets them swapped ([swap])."""
    if swap and w: w, h = h, w
    base = P("rr")
    for f in [x for x in os.listdir(WORK) if x.startswith("rr")]: os.remove(P(f))
    args = ["pdftoppm", "-cropbox", "-png", "-f", str(page), "-l", str(page)]
    args += ["-scale-to-x", str(w), "-scale-to-y", str(h)] if w else ["-r", str(dpi or 72)]
    sh(*args, pdf, base)
    f = [x for x in os.listdir(WORK) if x.startswith("rr") and x.endswith(".png")][0]
    return np.asarray(Image.open(P(f)).convert("L"), dtype=np.float32)

def mad(a, b):
    if abs(a.shape[0] - b.shape[0]) > 2 or abs(a.shape[1] - b.shape[1]) > 2: return 255.0   # different shapes (e.g. a transposed ground truth) can never pass
    h, w = min(a.shape[0], b.shape[0]), min(a.shape[1], b.shape[1])
    return float(np.abs(a[:h, :w] - b[:h, :w]).mean())

# ----------------------------------------------------------------------------------------------------- A. document information
def group_meta(cls):
    xmp_src = P("meta-src.pdf"); pdf = pikepdf.new(); pdf.add_blank_page(page_size=(300, 300)); pdf.pages[0].Contents = pdf.make_stream(b"BT /F1 20 Tf 20 150 Td (HELLO META) Tj ET")
    pdf.pages[0].Resources = Dictionary(Font=Dictionary(F1=helv(pdf)))
    pdf.docinfo["/Title"] = "Old title"; pdf.docinfo["/Author"] = "Old author"; pdf.docinfo["/Creator"] = "Creator X"; pdf.docinfo["/Producer"] = "Producer Y"; pdf.docinfo["/CreationDate"] = "D:20200101000000Z"
    with pdf.open_metadata(update_docinfo=False) as m: m["dc:title"] = "OLDXMPTITLE"   # update_docinfo=False: do not copy the XMP title into /Info (pikepdf does by default)
    pdf.save(xmp_src)
    with pikepdf.open(xmp_src) as q0: has_xmp = "/Metadata" in q0.Root
    check(has_xmp, "(A0) tệp thử có XMP với tiêu đề cũ")
    check(hz(cls, "meta-read", xmp_src) == "\u241F".join(["Old title", "Old author", "", ""]), "(A1) đọc đúng Info: " + repr(hz(cls, "meta-read", xmp_src)))
    out = P("meta-out.pdf"); r = hz(cls, "meta-write", xmp_src, out, "  Hợp đồng thuê nhà  ", "-", "Chủ đề: đ ơ ư", "a, b")
    check(r == "done", "(A2) ghi: " + r)
    p = pikepdf.open(out); di = p.docinfo
    check(str(di.get("/Title")) == "Hợp đồng thuê nhà", "(A2) tiêu đề tiếng Việt, đã cắt khoảng trắng: " + repr(str(di.get("/Title"))))
    check("/Author" not in di, "(A2) trường trống bị BỎ khỏi Info, không lưu chuỗi rỗng")
    check(str(di.get("/Subject")) == "Chủ đề: đ ơ ư" and str(di.get("/Keywords")) == "a, b", "(A2) chủ đề, từ khoá")
    check(str(di.get("/Creator")) == "Creator X" and "/CreationDate" in di, "(A2) mục Info khác (Creator, CreationDate) được GIỮ")
    check("/Metadata" not in p.Root, "(A2) XMP cũ bị bỏ khỏi catalog (không thì trình đọc vẫn hiện tiêu đề cũ)")
    info = sh("pdfinfo", "-isodates", out).stdout
    check("Hợp đồng thuê nhà" in info and "OLDXMPTITLE" not in info and "Old title" not in info, "(A2) pdfinfo (poppler) thấy tiêu đề mới, không thấy bản cũ")
    check("HELLO META" in sh("pdftotext", out, "-").stdout, "(A2) nội dung trang còn nguyên"); ok, tail = qpdf_clean(out); check(ok, "(A2) qpdf --check sạch " + ("" if ok else tail))
    check(hz(cls, "meta-read", out).split("\u241F")[0] == "Hợp đồng thuê nhà", "(A2) đọc lại bằng chính mã: tiêu đề mới")
    out2 = P("meta-strip.pdf"); r = hz(cls, "meta-strip", xmp_src, out2); p2 = pikepdf.open(out2)
    check(r == "done" and len(list(p2.docinfo.keys())) == 0 and "/Metadata" not in p2.Root, f"(A3) xoá hẳn: Info rỗng ({list(p2.docinfo.keys())}), không XMP")
    ok, tail = qpdf_clean(out2); check(ok and "HELLO META" in sh("pdftotext", out2, "-").stdout, "(A3) tệp xoá thông tin vẫn mở được, chữ còn")
    enc = P("meta-enc.pdf"); pikepdf.open(xmp_src).save(enc, encryption=pikepdf.Encryption(user="u", owner="o"))
    check(hz(cls, "meta-write", enc, P("meta-enc-out.pdf"), "x", "-", "-", "-").startswith("ERR:"), "(A4) tệp mã hoá bị từ chối: " + hz(cls, "meta-strip", enc, P("meta-enc-out2.pdf")))
    check(not os.path.exists(P("meta-enc-out.pdf")), "(A4) từ chối thì không để lại tệp")

# ----------------------------------------------------------------------------------------------------- B. imposition
A4W, A4H, MARG, GAP = 595.276, 841.89, 18.0, 12.0
THR_B = 3.0     # mean absolute pixel difference (0-255) allowed between a cell of the sheet and the source page rendered by pdftoppm at the same size; measured 0.7-0.8 on the real code
def cells(mode):
    w, h = (A4W, A4H) if mode == "FOUR_UP" else (A4H, A4W); rows = 2 if mode == "FOUR_UP" else 1
    cw = (w - 2 * MARG - GAP) / 2; ch = (h - 2 * MARG - (rows - 1) * GAP) / rows
    return (w, h), [(MARG + c * (cw + GAP), h - MARG - (r + 1) * ch - r * GAP, cw, ch) for r in range(rows) for c in range(2)]

def booklet_sides(n):
    """Standard definition: pad to a multiple of 4; sheet k: front [P-1-2k, 2k], back [2k+1, P-2-2k] (0-based, None = blank page)."""
    P_ = ((max(n, 1) + 3) // 4) * 4; sides = []
    for k in range(P_ // 4):
        for pair in ((P_ - 1 - 2 * k, 2 * k), (2 * k + 1, P_ - 2 - 2 * k)):
            sides.append([i if i < n else None for i in pair])
    return sides

def group_impose(cls, src, specs, only=None):
    for mode, perpage in (("TWO_UP", 2), ("FOUR_UP", 4), ("BOOKLET", 2)):
        if only and mode != only: continue
        out = P(f"imp-{mode}.pdf"); r = hz(cls, "impose", src, out, mode)
        if mode == "BOOKLET": sides = booklet_sides(len(specs))
        else: sides = [[i if i < len(specs) else None for i in range(s, s + perpage)] for s in range(0, len(specs), perpage)]
        check(r == str(len(sides)), f"(B-{mode}) số tờ {r} = {len(sides)}")
        if r != str(len(sides)): continue
        (sw, sh_), cl = cells(mode); info = sh("pdfinfo", "-f", "1", "-l", str(len(sides)), out).stdout
        sizes = set(re.findall(r"Page\s+\d+ size:\s+([\d.]+) x ([\d.]+)", info)); okz = all(abs(float(a) - sw) < .6 and abs(float(b) - sh_) < .6 for a, b in sizes)
        check(okz, f"(B-{mode}) khổ tờ {sorted(sizes)[:2]} = {sw:.1f} x {sh_:.1f}")
        worst, bad, blanks_ok = 0.0, [], True
        for si, side in enumerate(sides):
            sheet = render(out, si + 1, dpi=144)
            for ci, pi in enumerate(side):
                x, y, cw, ch = cl[ci]
                if pi is None:
                    region = sheet[int((sh_ - y - ch) * 2):int((sh_ - y) * 2), int(x * 2):int((x + cw) * 2)]
                    if region.mean() < 250: blanks_ok = False
                    continue
                dw, dh = displayed_size(specs[pi]); s = min(cw / dw, ch / dh); fx, fy = x + (cw - dw * s) / 2, y + (ch - dh * s) / 2
                px0, py0 = int(round(fx * 2)), int(round((sh_ - fy - dh * s) * 2)); pw_, ph_ = int(round(dw * s * 2)), int(round(dh * s * 2))
                got = sheet[py0 + 3:py0 + ph_ - 3, px0 + 3:px0 + pw_ - 3]
                want = render(src, pi + 1, w=pw_, h=ph_, swap=specs[pi].get("rotate", 0) in (90, 270))[3:ph_ - 3, 3:pw_ - 3]
                d = mad(got, want); worst = max(worst, d)
                if d > THR_B: bad.append((si + 1, ci, f"P{pi + 1}", round(d, 1)))
        check(not bad, f"(B-{mode}) mỗi ô khớp trang gốc dựng bằng pdftoppm (sai lệch điểm ảnh tối đa {worst:.1f}/255)" + ("" if not bad else f"; SAI: {bad[:4]}"))
        check(blanks_ok, f"(B-{mode}) ô trống (đệm cho đủ bội số của 4 / của tờ) trắng hoàn toàn")
        ok, tail = qpdf_clean(out); check(ok, f"(B-{mode}) qpdf --check sạch")
    # the metric must be able to FAIL: the same comparison with the source flipped must be far above the threshold
    dw, dh = displayed_size(specs[1]); a = render(src, 2, w=int(dw * .5), h=int(dh * .5), swap=True); flip = mad(a, a[::-1, ::-1]); mirror = mad(a, a[:, ::-1]); check(flip > 3 * THR_B and mirror > 3 * THR_B and mad(a, a) == 0, f"(B) phép đo phân biệt được: lật 180° lệch {flip:.1f}, lật gương {mirror:.1f} (ngưỡng {THR_B})")

# ----------------------------------------------------------------------------------------------------- C. poster
PM, POV = 20.0, 28.35
def group_poster(cls, tag, spec, cols, only=False):
    src = build_doc(P(f"post-{tag}.pdf"), [spec]); out = P(f"post-{tag}-out.pdf"); r = hz(cls, "poster", src, out, "0", str(cols))
    dw, dh = displayed_size(spec); land = dw > dh; sw, shh = (A4H, A4W) if land else (A4W, A4H); pw, ph = sw - 2 * PM, shh - 2 * PM
    s = (cols * pw - (cols - 1) * POV) / dw; need = dh * s; rows = 1
    while rows * ph - (rows - 1) * POV < need - 1e-3: rows += 1
    check(r == str(cols * rows), f"(C-{tag}) số tờ {r} = {cols} x {rows} (phải phủ vừa đủ trang phóng {dw * s:.0f} x {need:.0f} pt)")
    if r != str(cols * rows): return
    sizes = set(re.findall(r"Page\s+\d+ size:\s+([\d.]+) x ([\d.]+)", sh("pdfinfo", "-f", "1", "-l", r, out).stdout))
    check(all(abs(float(a) - sw) < .6 and abs(float(b) - shh) < .6 for a, b in sizes), f"(C-{tag}) mọi tờ cỡ A4 {'ngang' if land else 'dọc'} ({sorted(sizes)[:1]})")
    totW = cols * pw - (cols - 1) * POV; totH = rows * ph - (rows - 1) * POV
    canvas = np.full((int(round(totH)), int(round(totW))), -1.0, dtype=np.float32); tiles = {}; margin_ok = True
    for ri in range(rows):
        for ci in range(cols):
            im = render(out, ri * cols + ci + 1, dpi=72)
            H, W = im.shape
            if H < shh - 2 or W < sw - 2: check(False, f"(C-{tag}) kích thước ảnh tờ {W}x{H}"); return
            # the margin carries no ink except the four corner marks (they run along the edges of the printable area, at most MARGIN-4 pt out from the corner)
            band = im[:int(PM - 6), int(70):int(W - 70)]; band2 = im[int(H - PM + 6):, int(70):int(W - 70)]; side = im[int(70):int(H - 70), :int(PM - 6)]; side2 = im[int(70):int(H - 70), int(W - PM + 6):]
            if min(band.min(), band2.min(), side.min(), side2.min()) < 250: margin_ok = False
            area = im[int(PM):int(PM + ph), int(PM):int(PM + pw)]; tiles[(ri, ci)] = area
            x0 = int(round(ci * (pw - POV))); y0 = int(round(ri * (ph - POV)))
            region = canvas[y0:y0 + area.shape[0], x0:x0 + area.shape[1]]; h_, w_ = region.shape
            known = region >= 0
            if known.any(): check(float(np.abs(region[known] - area[:h_, :w_][known]).mean()) < 1.5, f"(C-{tag}) dải chồng của tờ ({ri + 1},{ci + 1}) KHỚP tờ kề trước (sai lệch {float(np.abs(region[known] - area[:h_, :w_][known]).mean()):.2f})")
            region[~known] = area[:h_, :w_][~known]
    check(margin_ok, f"(C-{tag}) lề trống (cắt xén đúng vùng in được), chỉ có dấu cắt ở bốn góc")
    ph_px, pw_px = int(round(need)), int(round(dw * s)); off = int(round((totH - need) / 2)); want = render(src, 1, w=pw_px, h=ph_px, swap=spec.get("rotate", 0) in (90, 270))
    got = canvas[off:off + ph_px, :pw_px]
    check(float(got[2:-2, 2:-2].min()) >= 0, f"(C-{tag}) các tờ ghép phủ kín trang phóng (trừ viền làm tròn 2 điểm ảnh)")
    d = mad(got[4:-4, 4:-4], want[4:-4, 4:-4]); check(d < THR_B, f"(C-{tag}) tờ ghép lại = trang gốc phóng {s:.2f} lần dựng bằng pdftoppm (sai lệch điểm ảnh {d:.1f}/255)")
    ok, tail = qpdf_clean(out); check(ok, f"(C-{tag}) qpdf --check sạch")

# ----------------------------------------------------------------------------------------------------- D. linearization
def build_inherit_doc(path, n=25):
    """Pages node carries MediaBox, Rotate and Resources; the leaves carry only a content stream. Plus Info and a 3-entry outline."""
    pdf = pikepdf.new(); font = helv(pdf); kids = []
    for i in range(n):
        body = f"BT /F1 22 Tf 40 300 Td (LINPAGE{i + 1:03d}) Tj ET\n" + "".join(f"0 g {40 + 6 * j} {40 + (j % 7) * 9} 4 4 re f\n" for j in range(i % 9 * 4))
        kids.append(pdf.make_indirect(Dictionary(Type=Name.Page, Contents=pdf.make_stream(body.encode()))))
    mid = pdf.make_indirect(Dictionary(Type=Name.Pages, Kids=Array(kids[:n // 2]), Count=n // 2))
    for k in kids[:n // 2]: k.Parent = mid
    mid2 = pdf.make_indirect(Dictionary(Type=Name.Pages, Kids=Array(kids[n // 2:]), Count=n - n // 2))
    for k in kids[n // 2:]: k.Parent = mid2
    root = pdf.Root.Pages; root.Kids = Array([mid, mid2]); root.Count = n; root.MediaBox = Array([0, 0, 420, 600]); root.Rotate = 90; root.Resources = Dictionary(Font=Dictionary(F1=font))
    mid.Parent = root; mid2.Parent = root
    pdf.docinfo["/Title"] = "Linear title"
    with pdf.open_outline() as ol:
        for t, pg in (("Một", 0), ("Hai", n // 2), ("Ba", n - 1)): ol.root.append(pikepdf.OutlineItem(t, pg))
    pdf.save(path, compress_streams=False); return path

def group_linear(cls):
    src = build_inherit_doc(P("lin-src.pdf")); out = P("lin-out.pdf"); r = hz(cls, "linearize", src, out)
    check(r == "25", f"(D1) tuyến tính hoá trả số trang: {r}")
    if r != "25": return
    check(hz(cls, "islin", out) == "true" and hz(cls, "islin", src) == "false", "(D1) isLinearized: tệp ra true, tệp vào false")
    ok, tail = qpdf_clean(out); check(ok, "(D1) qpdf --check sạch " + ("" if ok else tail))
    r2 = sh("qpdf", "--check-linearization", out); check(r2.returncode == 0 and "no linearization errors" in (r2.stdout + r2.stderr) and "WARNING" not in (r2.stdout + r2.stderr), "(D1) qpdf --check-linearization: " + (r2.stdout + r2.stderr).strip()[-200:])
    check(re.search(r"Optimized:\s+yes", sh("pdfinfo", out).stdout) is not None, "(D1) pdfinfo (poppler): Optimized: yes")
    a, b = sh("pdftotext", "-layout", src, "-").stdout, sh("pdftotext", "-layout", out, "-").stdout
    check(a == b and "LINPAGE025" in b, "(D1) chữ của cả 25 trang giữ nguyên")
    p = pikepdf.open(out); leaf_ok = all(int(pg.obj.get("/Rotate", -1)) == 90 and "/MediaBox" in pg.obj and "/Resources" in pg.obj for pg in p.pages)
    check(leaf_ok, "(D1) /Rotate, /MediaBox, /Resources thừa kế từ nút Pages được đẩy xuống TỪNG trang (mỗi trang tự mô tả, đúng điều kiện Annex F)")
    check([float(x) for x in p.pages[0].MediaBox] == [0, 0, 420, 600], "(D1) MediaBox đúng 420 x 600")
    with p.open_outline() as ol: titles = [(str(i.title), i.destination) for i in ol.root]
    check([t for t, _ in titles] == ["Một", "Hai", "Ba"], f"(D1) mục lục giữ nguyên {[t for t, _ in titles]}")
    check(str(p.docinfo.get("/Title")) == "Linear title", "(D1) thông tin tài liệu giữ nguyên")
    pg = sh("pdftoppm", "-r", "30", "-png", "-f", "13", "-l", "13", out, P("lin-r")); check(pg.returncode == 0, "(D1) poppler dựng được trang giữa tệp")
    enc = P("lin-enc.pdf"); pikepdf.open(src).save(enc, encryption=pikepdf.Encryption(user="u", owner="o")); e = hz(cls, "linearize", enc, P("lin-enc-out.pdf"))
    check(e.startswith("ERR:") and not os.path.exists(P("lin-enc-out.pdf")), "(D2) tệp mã hoá bị từ chối, không để lại tệp: " + e)
    one = build_doc(P("lin-one.pdf"), [dict(w=200, h=200, label="ONE")]); o1 = P("lin-one-out.pdf"); r3 = hz(cls, "linearize", one, o1)
    ok3, _ = qpdf_clean(o1) if os.path.exists(o1) else (False, ""); l3 = sh("qpdf", "--check-linearization", o1)
    check(r3 == "1" and ok3 and "no linearization errors" in (l3.stdout + l3.stderr), "(D3) PDF một trang cũng tuyến tính hoá đúng: " + r3)
    big = P("lin-big.pdf"); build_inherit_doc(big, 300); ob = P("lin-big-out.pdf"); t0 = time.time(); r4 = hz(cls, "linearize", big, ob); dt = time.time() - t0
    l4 = sh("qpdf", "--check-linearization", ob); check(r4 == "300" and "no linearization errors" in (l4.stdout + l4.stderr), f"(D4) 300 trang, 2 nút trung gian: qpdf sạch ({dt:.1f}s)")

# ----------------------------------------------------------------------------------------------------- E. auto links
def words_bbox(path, page):
    t = sh("pdftotext", "-bbox", "-f", str(page), "-l", str(page), path, "-").stdout
    H = float(re.search(r'<page width="[\d.]+" height="([\d.]+)"', t).group(1))
    return [(m.group(5), float(m.group(1)), H - float(m.group(4)), float(m.group(3)), H - float(m.group(2))) for m in re.finditer(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(.*?)</word>', t)]

CLASSIFY = [("https://a.b/c", "0 13 https://a.b/c"), ("(https://a.b/c).", "1 14 https://a.b/c"), ("www.x.com,", "0 9 https://www.x.com"), ("WWW.X.COM", "0 9 https://WWW.X.COM"), ("bob@example.org", "0 15 mailto:bob@example.org"),
            ("<bob@example.org>", "1 16 mailto:bob@example.org"), ("foo", "-"), ("http://", "-"), ("a@b", "-"), ("example.com", "-"), ("\"https://q.vn/a?b=1&c=2\"", "1 23 https://q.vn/a?b=1&c=2"), ("x.y@z.co.uk;", "0 11 mailto:x.y@z.co.uk"),
            ("https://", "-"), ("...", "-"), ("ftp://x.y", "-"), ("a.b@c.d", "-"), ("www.", "-"), ("(bob+tag@mail.example.org)", "1 25 mailto:bob+tag@mail.example.org"), ("http://localhost:8080/", "0 22 http://localhost:8080/"), ("mailto:bob@x.org", "-")]

def group_links(cls):
    for word, want in CLASSIFY:
        got = hz(cls, "classify", word)
        check(got == want, f"(E0) classify({word!r}) = {got!r}" + ("" if got == want else f" (mong đợi {want!r})"))
    pdf = pikepdf.new(); font = helv(pdf)
    def page(lines, rotate=0, extra=None):
        body = "BT /F1 14 Tf 40 700 Td 20 TL\n" + "".join(f"({l}) Tj T*\n" for l in lines) + "ET\n"
        pg = pdf.make_indirect(Dictionary(Type=Name.Page, MediaBox=Array([0, 0, 612, 792]), Contents=pdf.make_stream(body.encode()), Resources=Dictionary(Font=Dictionary(F1=font))))
        if rotate: pg.Rotate = rotate
        return pg
    p1 = page(["Visit https://example.com/path now", "Mail bob@example.org. thanks", "(www.test.vn), plain words only", "no link here: example and http://", "x https://a.b/c-d_e?f=1 y"])
    p2 = page(["rotated https://rot.example.com page"], rotate=90)
    p3 = page(["already https://linked.example.com done"]); p3.Annots = Array([pdf.make_indirect(Dictionary(Type=Name.Annot, Subtype=Name.Link, Rect=Array([88, 695, 258, 713]), Border=Array([0, 0, 0]), A=Dictionary(S=Name.URI, URI=String("https://old.example.org"))))])
    pdf.Root.Pages.Kids = Array([p1, p2, p3]); pdf.Root.Pages.Count = 3; src = P("links-src.pdf"); pdf.save(src, compress_streams=False)
    out = P("links-out.pdf"); r = hz(cls, "autolinks", src, out); check(r == "4 1", f"(E1) thêm 4 liên kết (trang 1 có 4 địa chỉ: 3 web + 1 email; 'http://' trơ trọi không tính), bỏ qua 1 trang xoay: {r!r}")
    if not r.startswith("4"): return
    q = pikepdf.open(out); links = [[(str(a.A.URI), [float(x) for x in a.Rect]) for a in pg.get("/Annots", []) if a.get("/Subtype") == "/Link"] for pg in q.pages]
    uris1 = sorted(u for u, _ in links[0]); want1 = sorted(["https://example.com/path", "mailto:bob@example.org", "https://www.test.vn", "https://a.b/c-d_e?f=1"])
    check(uris1 == want1, f"(E2) trang 1: đúng 4 địa chỉ đích {uris1}")
    check(len(links[1]) == 0, "(E3) trang xoay /Rotate 90: không tạo liên kết (đã đếm là bỏ qua)")
    check([u for u, _ in links[2]] == ["https://old.example.org"], f"(E4) không tạo liên kết đè lên liên kết sẵn có: {[u for u, _ in links[2]]}")
    words = words_bbox(src, 1); bad = []
    for uri, rect in links[0]:
        token = {"https://example.com/path": "https://example.com/path", "mailto:bob@example.org": "bob@example.org.", "https://www.test.vn": "(www.test.vn),", "https://a.b/c-d_e?f=1": "https://a.b/c-d_e?f=1"}[uri]
        w = [x for x in words if x[0] == token]
        if not w: bad.append((uri, "không thấy từ trong pdftotext")); continue
        _, x0, y0, x1, y1 = w[0]; inner0, inner1 = (x0, x1)
        if token.startswith("("): inner0 = x0 + (x1 - x0) * 1 / len(token); inner1 = x1 - (x1 - x0) * 2 / len(token)   # classify trims '(' and '),' : rough - each char ~ equal width is wrong for proportional fonts, so only a loose horizontal check
        if token.endswith("."): inner1 = x1 - 4.0
        tolx = 6.0 if token.startswith("(") or token.endswith(".") else 2.5
        cy = (y0 + y1) / 2
        if not (abs(rect[0] - inner0) <= tolx and abs(rect[2] - inner1) <= tolx and rect[1] <= cy <= rect[3] and 0.8 * (y1 - y0) <= rect[3] - rect[1] <= 1.8 * (y1 - y0)): bad.append((uri, [round(v, 1) for v in rect], [round(v, 1) for v in (inner0, y0, inner1, y1)]))
    check(not bad, "(E5) vùng bấm khớp hộp chữ do pdftotext đo (ngang ±2,5 pt; dọc chứa tâm dòng, cao 0,8-1,8 lần chữ)" + ("" if not bad else f": {bad}"))
    ok, tail = qpdf_clean(out); check(ok, "(E6) qpdf --check sạch"); check(sh("pdftotext", out, "-").stdout == sh("pdftotext", src, "-").stdout, "(E6) chữ không đổi")
    enc = P("links-enc.pdf"); pikepdf.open(src).save(enc, encryption=pikepdf.Encryption(user="u", owner="o")); check(hz(cls, "autolinks", enc, P("links-enc-out.pdf")).startswith("ERR:"), "(E7) tệp mã hoá bị từ chối")

# ----------------------------------------------------------------------------------------------------- run
MUTANTS = [
    (1, "PdfMetadataTools.kt", "            doc.documentCatalog.metadata = null          // stale XMP would override what we just wrote\n", "", "A"),
    (2, "PdfImposer.kt", "k * inv[4] + f[1], k * inv[5] + f[2]", "f[1], f[2]", "B"),
    (3, "PdfImposer.kt", "intArrayOf(p - 1 - 2 * k, 2 * k, 2 * k + 1, p - 2 - 2 * k)", "intArrayOf(2 * k, p - 1 - 2 * k, 2 * k + 1, p - 2 - 2 * k)", "BK"),
    (4, "PdfPoster.kt", "val tx = MARGIN - window[0] + plan.offsetX", "val tx = MARGIN - window[0] * 0.9f + plan.offsetX", "C"),
    (5, "PdfLinearizer.kt", "listOf(COSName.RESOURCES, COSName.MEDIA_BOX, COSName.CROP_BOX, COSName.ROTATE)", "listOf(COSName.RESOURCES, COSName.MEDIA_BOX, COSName.CROP_BOX)", "D"),
    (6, "PdfAutoLinks.kt", "val baseline = box.upperRightY - base", "val baseline = box.upperRightY - base - 30f", "E"),
    # the two fixes of phiên 26, put back to the old behaviour: the check must have caught the bugs they cured
    (7, "PdfStructureOptimizer.kt", "if (direct == null) { writeOptimizedBody(doc, sink); return }", "if (true) { writeOptimizedBody(doc, sink); return }", "A"),
    (8, "PdfLinearizer.kt", "                    for (key in INHERIT) d.removeItem(key)\n", "", "D"),
]

def run_group(cls, g):
    src = P("imp-src.pdf")
    if g in ("B", "BK") and not os.path.exists(src): build_doc(src, SPEC5)
    if g == "A": group_meta(cls)
    elif g == "B": group_impose(cls, src, SPEC5)
    elif g == "BK": group_impose(cls, src, SPEC5, only="BOOKLET")
    elif g == "C":
        group_poster(cls, "portrait", dict(w=400, h=600, label="POSTER"), 2)
        group_poster(cls, "landscape", dict(w=800, h=500, label="WIDE"), 3)
        group_poster(cls, "rotcrop", dict(w=700, h=900, label="ROT", rotate=270, crop=(50, 60, 650, 860)), 2)
    elif g == "D": group_linear(cls)
    elif g == "E": group_links(cls)

def main():
    args = sys.argv[1:]; fast = "--fast" in args; only = [int(a.split("=")[1]) for a in args if a.startswith("--mutant=")]
    if not only:
        t0 = time.time(); cls = build(); print(f"== dựng mã thật xong ({time.time() - t0:.0f}s)")
        for g in "ABCDE":
            print(f"== nhóm {g}"); run_group(cls, g)
    if not fast:
        print("== THỬ ÂM TÍNH: mỗi bản mã bị làm hỏng PHẢI bị bắt")
        for n, fname, old, new, g in MUTANTS:
            if only and n not in only: continue
            before = len(fails); cls = build({fname: (old, new)}, f"m{n}")
            import io, contextlib; buf = io.StringIO()
            with contextlib.redirect_stdout(buf): run_group(cls, g)
            caught = [l for l in buf.getvalue().splitlines() if l.startswith("LOI")]
            del fails[before:]   # failures of a mutant are the EXPECTED outcome, not failures of the check
            check(len(caught) > 0, f"bản hỏng {n} ({fname}: {old.strip()[:50]!r} -> {new.strip()[:40]!r}) bị bắt bởi {len(caught)} phép kiểm")
    print("\nTAT CA DAT" if not fails else f"\n{len(fails)} LOI: " + "; ".join(fails[:5])); sys.exit(1 if fails else 0)

main()
