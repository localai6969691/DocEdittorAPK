import java.nio.file.*;
import java.util.*;

/** Ban Java chay duoc cua util/KeepAlive.kt::WorkTracker (phien 18): bo dem viec dang chay + dung dich vu nen. Chay: java KeepAliveCheck.java <tep thao tac> */
public class KeepAliveCheck {
    static class WorkTracker {
        final List<String> events; int n = 0;
        WorkTracker(List<String> events) { this.events = events; }
        void acquire() { n++; if (n == 1) events.add("START"); }
        void release() { if (n == 0) return; n--; if (n == 0) events.add("STOP"); }
        void reset() { if (n > 0) { n = 0; events.add("STOP"); } }
    }
    /** Mo phong KeepAlive.during: acquire, chay khoi (co the nem loi), LUON release. */
    static void during(WorkTracker t, boolean fail, Runnable inner) {
        t.acquire();
        try { if (inner != null) inner.run(); if (fail) throw new IllegalStateException("loi gia lap"); }
        finally { t.release(); }
    }
    public static void main(String[] a) throws Exception {
        // moi dong mot kich ban: chuoi thao tac A (acquire), R (release), X (reset/timeout), D (during thanh cong), F (during that bai), N (during long nhau 3 tang, tang giua that bai)
        for (String line : Files.readAllLines(Paths.get(a[0]))) {
            List<String> ev = new ArrayList<>(); WorkTracker t = new WorkTracker(ev);
            for (char c : line.toCharArray()) {
                switch (c) {
                    case 'A': t.acquire(); break;
                    case 'R': t.release(); break;
                    case 'X': t.reset(); break;
                    case 'D': during(t, false, null); break;
                    case 'F': try { during(t, true, null); } catch (IllegalStateException e) { } break;
                    case 'N': try { during(t, false, () -> during(t, true, () -> during(t, false, null))); } catch (IllegalStateException e) { } break;
                    default: break;
                }
            }
            System.out.println(String.join(",", ev) + "|" + t.n);
        }
    }
}
