#!/usr/bin/env python3
"""Nhập MHTML CHẠY THẬT (`util/MhtmlImport.kt`; phiên 25, TECHNICAL_DOCS.md 4.74; mục 9.5 của PDF): lấy trang web ra khỏi tệp .mht / .mhtml rồi (ở ứng dụng) cho đi đúng đường nhập HTML sẵn có `DocumentImport.blocksFromHtml`, không đổi.

Tệp thử do THƯ VIỆN `email` CỦA PYTHON dựng (không phải do mã đang kiểm): multipart/related có ảnh, quoted-printable (UTF-8 và windows-1258 / iso-8859-1), base64, multipart/alternative lồng nhau,
xuống dòng CRLF và LF, tiêu đề gập dòng, ranh giới có ký tự đặc biệt; cộng một mẫu viết tay theo đúng kiểu Chrome ("Snapshot-Content-Location", boundary dài, Content-ID, Content-Location).
Mong đợi là chuỗi HTML gốc: lấy ra PHẢI GIỐNG TỪNG KÝ TỰ (kể cả chữ Việt, xuống dòng, dấu bằng, chữ có dấu `=`), phần đầu tiên là trang (khung / iframe đến sau không thay được), ảnh bị bỏ qua,
thư không có phần HTML cho NULL. (Phần `blocksFromHtml` phía sau là hàm của .html đã có, không đụng tới, nên không chạy lại ở đây.)
KHÔNG kiểm được: tệp MHTML thật của người dùng (mỗi trình duyệt viết hơi khác), trang dựng bằng JavaScript (MHTML chỉ lưu HTML đã dựng). Chạy: python3 tools/verify/mhtml_real_run_check.py"""
import base64, os, sys, tempfile
from email.message import EmailMessage
from email import policy
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="mhtml-")
HARNESS = os.path.join(HERE, "real_run", "MhtmlHarness.kt")
cls = tc.compile(["MhtmlImport.kt"], [HARNESS], os.path.join(WORK, "cls"), None, None)[0]
def run(*a):
    r = tc.run(cls, "MhtmlHarnessKt", list(a))
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-1200:])
    return r.stdout.strip()
def extract(path):
    out = run("html", path); return None if out == "NULL" else bytes.fromhex(out).decode("utf-8")
def write(name, data):
    p = os.path.join(WORK, name); open(p, "wb").write(data if isinstance(data, bytes) else data.encode("utf-8")); return p

PAGE = ('<!DOCTYPE html>\n<html lang="vi"><head><meta charset="utf-8"><title>Báo cáo tháng 11</title></head>\n<body>\n<h1>Chương 1: Giới thiệu</h1>\n'
        '<p>Đây là đoạn văn có chữ Việt: ệ ơ ư, dấu bằng = và a=b&amp;c=d, một dòng rất dài ' + 'abc ' * 40 + 'hết.</p>\n<ul><li>Mục một</li><li>Mục hai</li></ul>\n'
        '<img src="cid:img1"><p>Cuối trang.</p>\n</body></html>\n')

def related(html, cte="quoted-printable", charset="utf-8", extra_html=None, policy_=policy.default):
    msg = EmailMessage(policy=policy_); msg["Subject"] = "Báo cáo"; msg["From"] = "<Saved by Blink>"; msg["MIME-Version"] = "1.0"
    msg.set_content(html, subtype="html", charset=charset, cte=cte)
    msg.make_related()
    msg.add_related(base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="), "image", "png", cid="<img1>")
    if extra_html: msg.add_related(extra_html, subtype="html")
    return msg
def save(msg, name, linesep=b"\r\n"):
    data = msg.as_bytes(policy=policy.SMTP if linesep == b"\r\n" else policy.default.clone(linesep="\n"))
    return write(name, data)

print("== A. trang lấy ra GIỐNG TỪNG KÝ TỰ (tệp do thư viện email của Python dựng)")
for cte in ("quoted-printable", "base64", "8bit"):
    for linesep, ln in ((b"\r\n", "CRLF"), (b"\n", "LF")):
        if cte == "8bit" and linesep == b"\r\n": pass
        msg = related(PAGE, cte=cte); path = save(msg, f"a-{cte}-{ln}.mhtml", linesep)
        got = extract(path); check(got is not None and got.replace("\r\n", "\n") == PAGE, f"{cte} + {ln}: trang giống gốc" + ("" if got and got.replace('\r\n', '\n') == PAGE else f" (nhận {None if got is None else got[:60]!r})"))
print("== B. bảng mã")
LATIN = "<html><body><p>Café déjà vu, naïve façade: ça va très bien à Zürich.</p></body></html>\n"
msg = related(LATIN, cte="quoted-printable", charset="iso-8859-1"); path = save(msg, "b-latin1.mhtml")
got = extract(path); check(got is not None and got.replace("\r\n", "\n") == LATIN, "iso-8859-1 + quoted-printable: chữ có dấu đúng")
import unicodedata
viet = "<html><body><p>Xin chào Việt Nam: Hà Nội, Thành phố Hồ Chí Minh.</p></body></html>\n"
def to_cp1258(text):
    """windows-1258 has few precomposed letters: a letter it lacks (ệ, ố ...) is written as the base letter with its circumflex / breve / horn joined (ê, ô, ă, ơ) + the tone mark as a
    separate combining character (U+0300 U+0301 U+0303 U+0309 U+0323), which the code page does have"""
    TONES = {"\u0300", "\u0301", "\u0303", "\u0309", "\u0323"}
    def enc(c):
        try: return c.encode("cp1258")
        except UnicodeEncodeError: return None
    out = bytearray()
    for ch in text:
        if enc(ch) is not None: out += enc(ch); continue
        d = unicodedata.normalize("NFD", ch)
        base = unicodedata.normalize("NFC", d[0] + "".join(m for m in d[1:] if m not in TONES))
        out += enc(base)
        for m in d[1:]:
            if m in TONES: out += enc(m)
    return bytes(out)
viet_bytes = to_cp1258(viet)
raw = ("MIME-Version: 1.0\r\nContent-Type: multipart/related; boundary=\"B1\"\r\n\r\n--B1\r\nContent-Type: text/html; charset=windows-1258\r\nContent-Transfer-Encoding: base64\r\n\r\n"
       + base64.encodebytes(viet_bytes).decode() + "--B1--\r\n")
got = extract(write("b-cp1258.mhtml", raw))
check(got == viet_bytes.decode("cp1258") and unicodedata.normalize("NFC", got or "") == viet, "windows-1258 (tiếng Việt cũ, dấu rời) + base64: đúng từng điểm mã so với bộ giải mã của Python; gộp dấu (NFC) ra đúng chữ Việt")
nocharset = ("MIME-Version: 1.0\r\nContent-Type: multipart/related; boundary=\"B1\"\r\n\r\n--B1\r\nContent-Type: text/html\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n"
             "<html><head><meta charset=3D\"utf-8\"></head><body>=C4=90=E1=BB=A9c tin =3D l=C3=B2ng tin</body></html>\r\n--B1--\r\n")
check(extract(write("b-nocharset.mhtml", nocharset)) == '<html><head><meta charset="utf-8"></head><body>Đức tin = lòng tin</body></html>', "không khai charset: đọc <meta charset> / UTF-8; '=3D' thành '=' và '=C4=90' thành 'Đ'")

print("== C. cấu trúc")
chrome = ("From: <Saved by Blink>\r\nSnapshot-Content-Location: https://example.com/bao-cao\r\nSubject: =?utf-8?Q?B=C3=A1o_c=C3=A1o?=\r\nDate: Tue, 17 Nov 2026 10:30:00 -0000\r\nMIME-Version: 1.0\r\n"
          "Content-Type: multipart/related;\r\n\ttype=\"text/html\";\r\n\tboundary=\"----MultipartBoundary--Xy12_ab=CdEf9GhIj--\"\r\n\r\n"
          "------MultipartBoundary--Xy12_ab=CdEf9GhIj--\r\nContent-Type: text/html\r\nContent-ID: <frame-A1@mhtml.blink>\r\nContent-Transfer-Encoding: quoted-printable\r\nContent-Location: https://example.com/bao-cao\r\n\r\n"
          "<html><body><h1>Trang chính</h1><iframe src=3D\"https://example.com/f\"></iframe></body></html>\r\n"
          "------MultipartBoundary--Xy12_ab=CdEf9GhIj--\r\nContent-Type: image/png\r\nContent-Transfer-Encoding: base64\r\nContent-Location: https://example.com/a.png\r\n\r\niVBORw0KGgo=\r\n"
          "------MultipartBoundary--Xy12_ab=CdEf9GhIj--\r\nContent-Type: text/html\r\nContent-ID: <frame-B2@mhtml.blink>\r\nContent-Transfer-Encoding: quoted-printable\r\n\r\n<html><body>KHUNG PHU</body></html>\r\n"
          "------MultipartBoundary--Xy12_ab=CdEf9GhIj----\r\n")
got = extract(write("c-chrome.mhtml", chrome))
check(got == '<html><body><h1>Trang chính</h1><iframe src="https://example.com/f"></iframe></body></html>' or got == '<html><body><h1>Trang ch\u00ednh</h1><iframe src="https://example.com/f"></iframe></body></html>', f"mẫu kiểu Chrome (boundary dài có '=', tiêu đề gập dòng bằng tab, ảnh, khung): lấy đúng TRANG CHÍNH, không lấy khung phụ ({got!r:.80})")
check("KHUNG PHU" not in (got or ""), "phần HTML thứ hai (khung) không thay được trang")
nested = ("MIME-Version: 1.0\nContent-Type: multipart/related; boundary=OUT\n\n--OUT\nContent-Type: multipart/alternative; boundary=IN\n\n--IN\nContent-Type: text/plain\n\nchu thuong\n"
          "--IN\nContent-Type: text/html; charset=utf-8\n\n<p>Ban HTML long nhau</p>\n--IN--\n--OUT--\n")
check(extract(write("c-nested.mhtml", nested)) == "<p>Ban HTML long nhau</p>", "multipart/alternative lồng trong multipart/related (xuống dòng LF): lấy bản HTML")
check(extract(write("c-noparts.mhtml", "MIME-Version: 1.0\nContent-Type: multipart/related; boundary=OUT\n\n--OUT\nContent-Type: image/png\nContent-Transfer-Encoding: base64\n\niVBORw0KGgo=\n--OUT--\n")) is None, "thư không có phần HTML -> NULL")
check(extract(write("c-single.mhtml", "MIME-Version: 1.0\nContent-Type: text/html; charset=utf-8\n\n<p>Chi mot phan</p>\n")) == "<p>Chi mot phan</p>\n", "thư một phần text/html (không multipart) cũng lấy được")
check(extract(write("c-empty.mhtml", b"")) is None and extract(write("c-garbage.mhtml", b"\x00\x01\x02 not a mime message")) is None, "tệp rỗng / rác -> NULL, không sập")
check(extract(write("c-loop.mhtml", "MIME-Version: 1.0\nContent-Type: multipart/related; boundary=X\n\n--X\nContent-Type: multipart/related; boundary=X\n\n--X\n--X--\n--X--\n")) is None, "ranh giới lặp / lồng vô hạn không làm treo (có giới hạn độ sâu)")
check(run("mime", write("m1.mhtml", chrome)) == "true" and run("mime", write("m2.html", "<!DOCTYPE html><html><body>hi</body></html>")) == "false", "nhận ra thư MIME so với một trang HTML thường lưu nhầm đuôi")

print("== D. giải mã")
check(run("qp", "a=3Db=\r\nc=E1=BB=87 =C3 x=") == "613d6263e1bb8720c3203d".replace("c3203d", "c320783d"), "quoted-printable: =3D, ngắt dòng mềm, UTF-8 nhiều byte, '=' cuối giữ nguyên")
check(run("b64", "SGVsbG8s\r\nIFfDtnJsZA==") == "48656c6c6f2c20".replace("20", "2057c3b6726c64"), "base64 có xuống dòng và đệm '=': 'Hello, Wörld'")

print("== E. thử âm tính: mã cố tình sai PHẢI bị bắt")
def probe(class_dir):
    def runc(*a): return tc.run(class_dir, "MhtmlHarnessKt", list(a)).stdout.strip()
    ok1 = runc("html", save(related(PAGE, cte="quoted-printable"), "f1.mhtml")) == PAGE.encode().hex() or bytes.fromhex(runc("html", os.path.join(WORK, "f1.mhtml"))).decode().replace("\r\n", "\n") == PAGE
    ok2 = bytes.fromhex(runc("html", os.path.join(WORK, "a-base64-CRLF.mhtml"))).decode().replace("\r\n", "\n") == PAGE
    g = runc("html", os.path.join(WORK, "c-chrome.mhtml")); ok3 = g != "NULL" and "KHUNG PHU" not in bytes.fromhex(g).decode()
    ok4 = runc("html", os.path.join(WORK, "c-nested.mhtml")) == "<p>Ban HTML long nhau</p>".encode().hex()
    ok5 = bytes.fromhex(runc("html", os.path.join(WORK, "a-quoted-printable-LF.mhtml"))).decode() == PAGE   # soft line breaks written as "=\\n" (LF only)
    return ok1 and ok2 and ok3 and ok4 and ok5
check(probe(cls), "đối chứng: mã gốc đạt phép thử")
MUT = (("không giải quoted-printable (=3D giữ nguyên)", "out.write(hexValue(s[i + 1]) * 16 + hexValue(s[i + 2]))\n                i += 3", "out.write(c.code and 0xFF)\n                i++"),
       ("lấy phần HTML CUỐI thay vì đầu (khung phụ thay trang)", "for (part in splitParts(body, boundary)) {", "for (part in splitParts(body, boundary).reversed()) {"),
       ("không bỏ qua ngắt dòng mềm của quoted-printable", "if (j < s.length && s[j] == '\\n') {\n                i = j + 1\n                continue\n            }", ""),
       ("không giải base64", '"base64" -> decodeBase64(body)', '"base64" -> body.toByteArray(Charsets.ISO_8859_1)'))
for name, old, new in MUT:
    try:
        mdir = tc.compile(["MhtmlImport.kt"], [HARNESS], os.path.join(WORK, "mut"), {"MhtmlImport.kt": (old, new)}, None)[0]
        check(not probe(mdir), f"mã sai bị bắt: {name}")
    except RuntimeError as e:
        check(False, f"mutant không biên dịch được: {name}: {str(e)[:110]}")

print()
print("TAT CA DAT" if not fails else f"{len(fails)} LOI")
sys.exit(1 if fails else 0)
