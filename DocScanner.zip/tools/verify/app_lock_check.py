"""Kiểm chứng logic khoá ứng dụng (phiên 15): AppLock.shouldLock + chuỗi sự kiện của AppLockCallbacks.

Bản Python song song của AppLock.kt (shouldLock, onAppBackgrounded, onActivityVisible, markUnlocked) và của bộ đếm activity
trong DocScannerApp.kt (AppLockCallbacks). Mô phỏng các kịch bản thật bằng chuỗi sự kiện (start/stop/unlock/thời gian trôi) và
kiểm xem MÀN HÌNH KHOÁ có hiện đúng lúc không:
  - khởi động nguội khi đang bật khoá -> khoá;  tắt khoá -> không bao giờ khoá;
  - đi lại giữa các màn hình của app (màn sau start TRƯỚC khi màn trước stop) -> không khoá dù mất nhiều thời gian;
  - ra ngoài (picker/camera) rồi quay lại trong 60 giây -> không khoá; quá 60 giây -> khoá;
  - đang ở màn khoá mà bấm Home, quay lại sau 1 giây -> VẪN khoá (chưa mở khoá thì không hết hạn "ân hạn");
  - xoay màn hình (stop rồi start ngay) -> không khoá;
  - bật khoá giữa phiên rồi markUnlocked -> không khoá ngay;
  - máy bị gỡ khoá màn hình (NONE_ENROLLED) -> tự tắt khoá thay vì nhốt người dùng;  lỗi tạm thời (HW_UNAVAILABLE) -> vẫn khoá.
Phiên 22 (mục 4.49.3, D7 "auto-lock"): thời gian ân hạn do người dùng chọn trong AppLock.GRACE_OPTIONS_MS (5 giây / 1 / 5 / 15 / 30 phút):
  - bảng hằng số ĐỌC TỪ AppLock.kt và so với bản Python; tăng dần; ngắn nhất >= 5 giây (xoay màn hình không bao giờ khoá);
  - với MỖI mức: ra ngoài đúng bằng mức -> không khoá, quá 1 ms -> khoá, xoay màn hình (300 ms) và đi lại trong app -> không khoá; thử âm tính: mức 0 sẽ khoá khi xoay.
Chạy: python3 app_lock_check.py
"""
import sys

GRACE_MS = 60_000                      # mức mặc định (DEFAULT_GRACE_INDEX = 1)
GRACE_OPTIONS_MS = [5_000, 60_000, 300_000, 900_000, 1_800_000]
OK, NONE_ENROLLED, NO_HARDWARE, HW_UNAVAILABLE = 0, 11, 12, 1


def should_lock(enabled, unlocked, backgrounded_at, now, grace):
    if not enabled:
        return False
    if not unlocked:
        return True
    return backgrounded_at > 0 and now - backgrounded_at > grace


class App:
    def __init__(self, enabled=True, status=OK, grace=GRACE_MS):
        self.enabled, self.status, self.grace = enabled, status, grace
        self.unlocked, self.backgrounded_at, self.now = False, 0, 1_000
        self.started = 0
        self.lock_shown = 0

    def tick(self, ms):
        self.now += ms

    def start(self, lock_activity=False):
        self.started += 1
        if lock_activity:
            return
        if self.enabled and self.status in (NONE_ENROLLED, NO_HARDWARE):
            self.enabled = False
            return
        lock = should_lock(self.enabled, self.unlocked, self.backgrounded_at, self.now, self.grace)
        if lock:
            self.unlocked = False
            self.lock_shown += 1
        else:
            self.backgrounded_at = 0

    def stop(self):
        if self.started > 0:
            self.started -= 1
        if self.started == 0:
            self.backgrounded_at = self.now

    def unlock(self):
        self.unlocked, self.backgrounded_at = True, 0


def scenario(name, build, expect_locks):
    app = App()
    build(app)
    ok = app.lock_shown == expect_locks
    print(("ok  " if ok else "LOI"), f"{name}: lock_shown={app.lock_shown} (mong đợi {expect_locks})")
    return ok


def cold_start_locks(a):
    a.start()                      # Main
    a.start(lock_activity=True)    # LockActivity bật lên
    a.stop()                       # Main bị che
    a.unlock(); a.stop()           # mở khoá, màn khoá đóng
    a.start()                      # Main hiện lại -> không khoá thêm


def navigate_inside(a):
    a.start(); a.start(lock_activity=True); a.stop(); a.unlock(); a.stop(); a.start()
    for _ in range(5):
        a.tick(120_000)            # ở trong app rất lâu, đi lại giữa các màn
        a.start(); a.stop()        # màn sau start trước, màn trước stop sau


def away_short(a):
    cold_start_locks(a)
    a.stop(); a.tick(30_000); a.start()


def away_long(a):
    cold_start_locks(a)
    a.stop(); a.tick(61_000); a.start()


def home_on_lock_screen(a):
    a.start(); a.start(lock_activity=True); a.stop()   # đang ở màn khoá
    a.stop(); a.tick(1_000); a.start(lock_activity=True)  # Home rồi quay lại: màn khoá hiện lại, chưa mở khoá


def rotation(a):
    cold_start_locks(a)
    a.stop(); a.tick(300); a.start()


def enable_midsession_then_unlock():
    a = App(enabled=False)
    a.start()
    a.enabled = True; a.unlock()   # người dùng bật khoá rồi xác thực thành công
    a.stop(); a.tick(10_000); a.start()
    ok = a.lock_shown == 0
    print(("ok  " if ok else "LOI"), f"bật khoá giữa phiên: lock_shown={a.lock_shown} (mong đợi 0)")
    return ok


def disabled_never_locks():
    a = App(enabled=False)
    a.start(); a.stop(); a.tick(10**7); a.start()
    ok = a.lock_shown == 0
    print(("ok  " if ok else "LOI"), f"tắt khoá: lock_shown={a.lock_shown} (mong đợi 0)")
    return ok


def device_lock_removed():
    a = App(enabled=True, status=NONE_ENROLLED)
    a.start()
    ok = a.lock_shown == 0 and a.enabled is False
    print(("ok  " if ok else "LOI"), f"gỡ khoá màn hình -> tự tắt: lock_shown={a.lock_shown} enabled={a.enabled}")
    return ok


def transient_error_keeps_lock():
    a = App(enabled=True, status=HW_UNAVAILABLE)
    a.start()
    ok = a.lock_shown == 1 and a.enabled is True
    print(("ok  " if ok else "LOI"), f"lỗi tạm thời giữ khoá: lock_shown={a.lock_shown} enabled={a.enabled}")
    return ok


def grace_options():
    import os, re
    src = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "app", "src", "main", "java", "com", "example", "docscanner", "util", "AppLock.kt"), encoding="utf-8").read()
    m = re.search(r"val GRACE_OPTIONS_MS = longArrayOf\(([^)]*)\)", src); kt = [int(x.replace("_", "").replace("L", "")) for x in m.group(1).split(",")]
    d = int(re.search(r"const val DEFAULT_GRACE_INDEX = (\d+)", src).group(1))
    results = []
    def rec(ok, msg): print(("ok  " if ok else "LOI"), msg); results.append(ok)
    rec(kt == GRACE_OPTIONS_MS, f"AppLock.kt GRACE_OPTIONS_MS = bản Python {kt}")
    rec(kt == sorted(set(kt)) and kt[0] >= 5_000, "các mức tăng dần, ngắn nhất >= 5 giây")
    rec(kt[d] == GRACE_MS, f"mức mặc định (chỉ số {d}) = {GRACE_MS} ms như trước phiên 22")
    for g in kt:
        def build(a, wait):
            cold_start_locks(a); a.stop(); a.tick(wait); a.start()
        for wait, locks in ((g - 1, 1), (g, 1), (g + 1, 2)):
            app = App(grace=g); build(app, wait)
            rec(app.lock_shown == locks, f"mức {g // 1000} s: ra ngoài {wait} ms -> khoá {app.lock_shown} lần (mong đợi {locks})")
        app = App(grace=g); cold_start_locks(app); app.stop(); app.tick(300); app.start()
        rec(app.lock_shown == 1, f"mức {g // 1000} s: xoay màn hình (300 ms) không khoá")
        app = App(grace=g); navigate_inside(app)
        rec(app.lock_shown == 1, f"mức {g // 1000} s: đi lại trong app rất lâu không khoá")
    app = App(grace=0); cold_start_locks(app); app.stop(); app.tick(300); app.start()
    rec(app.lock_shown == 2, "ÂM TÍNH: mức 0 sẽ khoá khi xoay màn hình (vì vậy mức ngắn nhất là 5 giây)")
    return results


def main():
    results = grace_options() + [
        scenario("khởi động nguội", cold_start_locks, 1),
        scenario("đi lại trong app, rất lâu", navigate_inside, 1),
        scenario("ra ngoài 30 giây", away_short, 1),
        scenario("ra ngoài 61 giây", away_long, 2),
        scenario("Home ở màn khoá rồi quay lại", home_on_lock_screen, 1),
        scenario("xoay màn hình", rotation, 1),
        enable_midsession_then_unlock(),
        disabled_never_locks(),
        device_lock_removed(),
        transient_error_keeps_lock(),
    ]
    good = all(results)
    print("TAT CA DAT" if good else "CO LOI")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
