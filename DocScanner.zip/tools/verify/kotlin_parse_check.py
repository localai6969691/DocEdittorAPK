#!/usr/bin/env python3
"""Kotlin SYNTAX check with a real parser (tree-sitter-kotlin), TECHNICAL_DOCS.md 4.63.

Why: `kotlin_lint_check.py` is lexical (brackets, Java syntax) and `static_refs_check.py` / `kotlin_exposure_check.py` /
`kotlin_this_scope_check.py` each look for ONE class of error. None of them parses Kotlin, so a missing `)` inside an expression, an `else`
without `if`, a stray `}` that happens to balance, or a malformed lambda gets through until the real compiler runs in CI. This check parses
every `.kt` file into a syntax tree and fails on any ERROR / MISSING node.

Needs: `pip install tree-sitter tree-sitter-kotlin` (pypi; the CI step installs them). If they are missing locally the check says so and
exits 0 with --soft, otherwise it exits 2 (a check that silently does not run would be worse than none).

What it is NOT: a compiler. It sees syntax only: not types, not unresolved names, not `this` scope. A file that parses can still fail `compileDebugKotlin`.

False positives: the tree-sitter grammar is incomplete. KNOWN_BENIGN below lists source lines (stripped, exact) that the parser flags but that
are valid Kotlin and were compiled by CI (`if (c) for (...) stmt` with no braces; a variable called `final`; destructuring in a bodyless `for`).
Matching is by LINE TEXT, not by line number, so edits elsewhere do not break it. A NEW error line that is not in the list fails the check; if it
is a grammar limitation again, add the line to KNOWN_BENIGN with the reason - do not add a line you have not read.

Usage: python3 tools/verify/kotlin_parse_check.py [--soft] [--selftest] [--show-benign]
"""
import glob
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# file -> stripped source lines (first 100 chars) that the grammar flags although the code is valid Kotlin and was compiled by CI (runs #18-#28), or, for
# PageEditImageView.kt (not yet compiled), is a plain `if (c) for (...) stmt`. Reasons: (A) `if (c) for (...) stmt` / destructuring `for ((a, b) in x)` with no braces,
# (B) a soft keyword used as a name (`final`), (C) one-line `{ decl }` bodies, (D) cascade: after one rejected construct the grammar mis-parses the lines that follow.
KNOWN_BENIGN_LINES = {
    'PdfBookmarkActivity.kt': [
        'companion object { const val EXTRA_PDF_PATH = "extra_pdf_path" }',
    ],
    'DocInsight.kt': [
        'eachCandidate(toks) { key, words, start, end -> terms.getOrPut(key) { Term(key, words, start, end) }',
        'for ((t, _) in ranked) if (t.words == 2 && chosen.size < minOf(3, k)) chosen.add(t)',
        "for (t in chosen) inPhrases.addAll(t.key.split(' '))",
        'private class Term(val key: String, val words: Int, val start: Int, val end: Int) { var count = 0 }',
        'return chosen.map { SPACES.replace(text.substring(it.start, it.end), " ").lowercase() }',
        'val chosen = ArrayList<Term>()',
        'val df = HashMap<String, Int>()',
        'val inPhrases = HashSet<String>()',
        'val seen = HashSet<String>()',
        'val terms = LinkedHashMap<String, Term>()',
    ],
    'EpubTools.kt': [
        'for ((bi, s) in books.withIndex()) {',
        'if (s.spine == null) keptRefs.addAll(p.spine) else for (idx in s.spine) if (idx >= 1 && idx <= p.spi',
        'val coverId = p.coverId()',
        'val docPaths = LinkedHashSet<String>(); for (r in keptRefs) docPaths.add(p.byId.getValue(r.idref).pa',
        'val keep = LinkedHashSet<String>()',
        'val keptRefs = ArrayList<Ref>()',
        'val ncx = "<?xml version=\\"1.0\\" encoding=\\"UTF-8\\"?>\\n<ncx xmlns=\\"http://www.daisy.org/z3986/2005/',
    ],
    'OfficeImport.kt': [
        'private class OdtPara(val kind: String, val level: Int, val style: String) { val sb = StringBuilder(',
        'val out = ArrayList<Block>()',
        'var skip = 0',
    ],
    'PdfBookmarks.kt': [
        'for ((i, s) in sources.withIndex()) {',
        'merger.appendDocument(dest, d)',
        'outlines.add(SourceOutline(s.second, d.numberOfPages, read(d)))',
    ],
    'PdfStructureOptimizer.kt': [
        'if (extra != null) for ((k, v) in extra) {',
        'val out = ByteArrayOutputStream(maxOf(64, data.size / 2))',
        "writeName(k, out); out.write(' '.code); out.write(v.toByteArray(Charsets.US_ASCII)); out.write('\\n'.",
    ],
    'PdfStructureTools.kt': [
        'return if (dot <= 0) "$name ($k)" else name.substring(0, dot) + " ($k)" + name.substring(dot)',
        'while (map.containsKey(final)) { final = withSuffix(name, k); k++ }',
    ],
    'TextLineDewarp.kt': [
        'if (col.size >= 3) for (i in 1 until col.size) gapsAll.add(col[i] - col[i - 1])',
    ],
    'PageEditImageView.kt': [
        'if (isStroke(active)) for (i in 0 until e.historySize) addLive(e.getHistoricalX(i), e.getHistoricalY',
    ],
}


def load_parser():
    try:
        import tree_sitter_kotlin as tsk
        from tree_sitter import Language, Parser
    except Exception as exc:  # ImportError or a binding mismatch
        return None, str(exc)
    try:
        return Parser(Language(tsk.language())), None
    except Exception as exc:
        return None, str(exc)


def error_nodes(node, out):
    """Deepest nodes that carry an error (an ERROR node, a MISSING token, or a node the grammar rejects) and have no erroring child."""
    kids = [c for c in node.children if c.has_error or c.type == "ERROR" or c.is_missing]
    if not kids:
        out.append(node)
        return
    for child in kids:
        error_nodes(child, out)


def parse_file(parser, path):
    src = open(path, "rb").read()
    tree = parser.parse(src)
    errs = []
    if tree.root_node.has_error:
        error_nodes(tree.root_node, errs)
    lines = src.decode("utf-8", "replace").split("\n")
    result = []
    for e in errs:
        row = e.start_point[0]
        text = lines[row].strip() if row < len(lines) else ""
        result.append((row + 1, e.type if not e.is_missing else "MISSING", text))
    return result


def selftest(parser):
    good = "package a\n\nclass A {\n    fun f(x: Int): Int {\n        return if (x > 0) x else -x\n    }\n}\n"
    bad_cases = {
        "missing close paren": "package a\n\nfun f() {\n    println(\"x\"\n}\n",
        "two literals in a row": "package a\n\nfun f(): Int {\n    val x = 1 2\n    return x\n}\n",
        "unclosed lambda": "package a\n\nfun f() {\n    listOf(1).map { it + 1 \n}\n",
        "missing fun keyword": "package a\n\nclass A {\n    f(x: Int): Int {\n        return x\n    }\n}\n",
        "extra close brace": "package a\n\nfun f() {\n}\n}\n",
    }
    # what it does NOT catch (measured on 60 real files, 4.63): a mistyped keyword such as `els` for `else` parses as a plain name.
    failures = 0
    t = parser.parse(good.encode())
    if t.root_node.has_error:
        print("FAIL  self-test: valid code flagged"); failures += 1
    else:
        print("ok    valid multi-line code parses clean")
    for name, code in bad_cases.items():
        t = parser.parse(code.encode())
        if t.root_node.has_error:
            print("ok    flagged: " + name)
        else:
            print("FAIL  not flagged: " + name); failures += 1
    return failures


def main(argv):
    soft = "--soft" in argv
    parser, why = load_parser()
    if parser is None:
        print("tree-sitter-kotlin is not installed (" + str(why) + "): pip install tree-sitter tree-sitter-kotlin")
        return 0 if soft else 2
    if "--selftest" in argv:
        n = selftest(parser)
        print("\nTAT CA DAT" if n == 0 else "\n%d LOI" % n)
        return 1 if n else 0

    files = sorted(glob.glob(os.path.join(ROOT, "app", "src", "main", "java", "**", "*.kt"), recursive=True))
    problems = []
    benign = 0
    for path in files:
        base = os.path.basename(path)
        known = KNOWN_BENIGN_LINES.get(base, [])
        for row, kind, text in parse_file(parser, path):
            if text[:100] in known:
                benign += 1
                if "--show-benign" in argv:
                    print("benign %s:%d %s %s" % (base, row, kind, text[:90]))
                continue
            problems.append("%s:%d %s near: %s" % (os.path.relpath(path, ROOT), row, kind, text[:110]))
    print("đã phân tích %d tệp .kt; %d nút lỗi là dương tính giả đã biết (%d dòng trong %d tệp)" % (
        len(files), benign, sum(len(v) for v in KNOWN_BENIGN_LINES.values()), len(KNOWN_BENIGN_LINES)))
    for p in problems:
        print("LOI  " + p)
    print("\nTAT CA DAT" if not problems else "\n%d LOI" % len(problems))
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
