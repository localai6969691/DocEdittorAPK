"""IntervalShooter (phiên 22, mục 4.49.7): đồng hồ của "chụp liên tiếp" (A5). Bản Java IntervalShooterCheck.java chạy 600 phiên mô phỏng
(chu kỳ 2 / 3 / 5 giây, bước tick của Handler 100-400 ms, độ trễ lưu ảnh 50 ms - 9 giây, có ảnh lỗi, có dừng giữa chừng, giới hạn số ảnh); Python kiểm các TÍNH CHẤT
trên vết kết quả (không dùng lại mã của bản ghi):
  1. ảnh đầu tiên chụp NGAY khi bắt đầu;
  2. khoảng cách giữa hai lần bắt đầu chụp >= chu kỳ, và KHÔNG BAO GIỜ chụp chồng lên ảnh đang lưu (lần sau bắt đầu >= lúc ảnh trước lưu xong);
  3. không bù (catch-up): khoảng cách <= max(chu kỳ, độ trễ ảnh trước) + bước tick (không có hai ảnh dồn sát nhau sau khi trễ);
  4. không bao giờ quá giới hạn số ảnh; đủ số ảnh thì tự dừng; sau khi dừng không có ảnh mới nhưng ảnh đang lưu vẫn xong;
  5. ảnh lỗi không được chụp lại: lần sau vẫn đúng chu kỳ.
  THỬ ÂM TÍNH: bộ đồng hồ ngây thơ (chỉ "đã tới giờ" mà không đợi ảnh trước) bị tính chất 2 bắt được khi ảnh lưu chậm hơn chu kỳ.
Chạy: python3 interval_shooter_check.py   (cần java; ~10 giây)
"""
import os, random, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__)); JAVA = os.path.join(HERE, "IntervalShooterCheck.java")
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

rnd = random.Random(2207)
scen = []
for _ in range(600):
    interval = rnd.choice([2000, 3000, 5000]); step = rnd.choice([100, 200, 400]); mx = rnd.choice([1, 2, 5, 10, 300])
    lat = ",".join(str(rnd.choice([50, 300, 800, 1500, 2500, 4000, 6000, 9000, -1])) for _ in range(rnd.randrange(1, 5)))
    dur = rnd.choice([1000, 8000, 30000, 120000]); stop = rnd.choice([-1, -1, 0, 4500, 20000])
    scen.append((interval, mx, step, dur, stop, lat))
r = subprocess.run(["java", JAVA], input="\n".join(f"{i} {m} {s} {d} {st} {l}" for i, m, s, d, st, l in scen) + "\n", capture_output=True, text=True)
if r.returncode != 0: print(r.stderr[-1500:]); sys.exit(1)
out = r.stdout.strip().split("\n"); assert len(out) == len(scen)
def parse(line):
    d = dict(p.split(":", 1) for p in line.split(";"))
    return [int(x) for x in d["shots"].split(",") if x], [int(x) for x in d["finished"].split(",") if x], int(d["running"]), int(d["count"])
T0 = 1000; reached = []; bad = {k: [] for k in ("first", "gap", "overlap", "catchup", "max", "autostop", "stop", "count")}
for (interval, mx, step, dur, stop, lat), line in zip(scen, out):
    starts, fin, running, count = parse(line); lats = [int(x) for x in lat.split(",")]
    lat_of = lambda k: (50 if lats[k % len(lats)] < 0 else lats[k % len(lats)])
    if stop != 0 and starts and starts[0] != T0: bad["first"].append((interval, step, starts[:2]))
    if stop == 0 and starts: bad["stop"].append(("shot after immediate stop", starts))
    for k in range(1, len(starts)):
        gap = starts[k] - starts[k - 1]
        if gap < interval: bad["gap"].append((interval, step, gap))
        if starts[k] < starts[k - 1] + lat_of(k - 1): bad["overlap"].append((interval, lat_of(k - 1), gap))
        if gap > max(interval, lat_of(k - 1)) + step: bad["catchup"].append((interval, lat_of(k - 1), step, gap))
    if len(starts) > mx or count > mx: bad["max"].append((mx, len(starts)))
    if stop >= 0 and any(t >= T0 + stop + step for t in starts): bad["stop"].append((stop, starts[-1]))
    if len(starts) == mx and stop < 0:
        reached.append(1)
        if starts[-1] + lat_of(mx - 1) + step <= T0 + dur and running != 0: bad["autostop"].append((mx, running))
    if count != len(starts): bad["count"].append((count, len(starts)))
check(not bad["first"], "ảnh đầu tiên chụp ngay khi bắt đầu")
check(not bad["gap"], "mọi khoảng cách giữa hai lần bắt đầu chụp >= chu kỳ")
check(not bad["overlap"], "KHÔNG BAO GIỜ chụp chồng lên ảnh đang lưu (lần sau bắt đầu >= lúc ảnh trước lưu xong)")
check(not bad["catchup"], "không bù: sau khi trễ chỉ có MỘT ảnh tới hạn, không dồn sát nhau")
check(not bad["max"], "không bao giờ quá giới hạn số ảnh")
check(not bad["autostop"] and len(reached) > 30, f"đủ số ảnh thì tự dừng (running = false khi ảnh cuối lưu xong); {len(reached)} phiên đã chạm giới hạn")
check(not bad["stop"], "sau khi dừng không có ảnh mới (dừng ngay từ đầu -> không ảnh nào)")
check(not bad["count"], "bộ đếm số ảnh = số lần bắt đầu chụp")
total = sum(len(parse(l)[0]) for l in out)
check(total > 1000, f"{len(scen)} phiên mô phỏng, tổng {total} lần chụp")

# ảnh lỗi không chụp lại: chu kỳ 3 s, độ trễ -1 (lỗi sau 50 ms): các lần chụp vẫn cách đúng 3 s
r2 = subprocess.run(["java", JAVA], input="3000 10 100 20000 -1 -1\n", capture_output=True, text=True).stdout.strip()
st, _, _, _ = parse(r2)
check(len(st) >= 6 and all(b - a == 3000 for a, b in zip(st, st[1:])), f"ảnh lỗi không bị chụp lại: các lần chụp vẫn cách đúng 3 s {st[:4]}…")
# ảnh lưu chậm hơn chu kỳ (6 s > 2 s): mỗi ảnh đợi ảnh trước xong
r3 = subprocess.run(["java", JAVA], input="2000 10 100 40000 -1 6000\n", capture_output=True, text=True).stdout.strip()
st, _, _, _ = parse(r3)
check(len(st) >= 5 and all(6000 <= b - a <= 6100 for a, b in zip(st, st[1:])), f"ảnh lưu chậm (6 s > chu kỳ 2 s): nhịp chụp theo ảnh lưu chậm, không chồng {st[:4]}…")

# THỬ ÂM TÍNH: đồng hồ ngây thơ không đợi ảnh trước
def naive(interval, step, dur, lat):
    starts, nxt, t = [], 1000, 1000
    while t <= 1000 + dur:
        if t >= nxt: starts.append(t); nxt = t + interval
        t += step
    return starts
ns = naive(2000, 100, 40000, 6000)
check(any(b < a + 6000 for a, b in zip(ns, ns[1:])), "ÂM TÍNH: đồng hồ ngây thơ chụp chồng lên ảnh đang lưu -> tính chất 'không chồng' có răng")

print(); print("TAT CA DAT" if not fails else f"{len(fails)} LOI: {fails}")
sys.exit(1 if fails else 0)
