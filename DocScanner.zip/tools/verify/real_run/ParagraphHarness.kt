import com.example.docscanner.util.PdfParagraphEditor
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.File
import java.io.FileInputStream

/**
 * Harness for tools/verify/paragraph_real_run_check.py: runs the REAL util/PdfParagraphEditor.kt.
 *   blocks <pdf> <page>                     -> one line per block: `firstIndex lineCount widthPt fontSize | text | x0 y0 x1 y1 (fractions, "-" when off the page)`
 *   pick <pdf> <page> <x> <y>               -> firstIndex of the block under the point or "-"
 *   apply <src> <out> <page:first:textfile[:overlap]>[,...] [fallbackfont.ttf]  -> OK or the failure (the text is read from the file, UTF-8); `overlap` = keep extra lines even over other text
 *   trial <src> <page> <first> <textfile> [fallbackfont.ttf] [overlap]          -> the Result (Success / Substituted(chars) / Overlaps / ...) without saving anything
 */
fun fonts(path: String?): List<() -> java.io.InputStream?> =
    if (path == null || path == "-") emptyList() else listOf({ FileInputStream(File(path)) })

fun main(args: Array<String>) {
    try {
        when (args[0]) {
            "blocks" -> PDDocument.load(File(args[1])).use { d ->
                for (b in PdfParagraphEditor.blocks(d, args[2].toInt())) {
                    println("${b.firstIndex} ${b.lineCount} ${"%.3f".format(b.widthPt)} ${b.fontSize} ${b.align} | ${b.text} | " + (b.placed?.joinToString(" ") { "%.4f".format(it) } ?: "-"))
                }
            }
            "pick" -> PDDocument.load(File(args[1])).use { d ->
                println(PdfParagraphEditor.pick(PdfParagraphEditor.blocks(d, args[2].toInt()), args[3].toFloat(), args[4].toFloat())?.firstIndex?.toString() ?: "-")
            }
            "apply" -> {
                val edits = args[3].split(",").map { s ->
                    val t = s.split(":", limit = 4)
                    PdfParagraphEditor.Edit(t[0].toInt(), t[1].toInt(), File(t[2]).readText(Charsets.UTF_8), allowOverlap = t.getOrNull(3) == "overlap")
                }
                PdfParagraphEditor.applyAll(File(args[1]), File(args[2]), edits, fonts(args.getOrNull(4)))
                println("OK")
            }
            "trial" -> {
                val r = PdfParagraphEditor.trial(File(args[1]), args[2].toInt(), args[3].toInt(), File(args[4]).readText(Charsets.UTF_8), fonts(args.getOrNull(5)), args.getOrNull(6) == "overlap")
                println(if (r is PdfParagraphEditor.Result.MissingGlyphs || r is PdfParagraphEditor.Result.Substituted) r.toString() else r::class.simpleName)
            }
        }
    } catch (e: Exception) {
        println("ERR:" + e.javaClass.simpleName + ":" + e.message)
    }
}
