import com.example.docscanner.util.PdfParagraphEditor
import com.tom_roush.pdfbox.pdmodel.PDDocument
import java.io.File

/**
 * Harness for tools/verify/paragraph_real_run_check.py: runs the REAL util/PdfParagraphEditor.kt.
 *   blocks <pdf> <page>                     -> one line per block: `firstIndex lineCount widthPt fontSize | text | x0 y0 x1 y1 (fractions, "-" when off the page)`
 *   pick <pdf> <page> <x> <y>               -> firstIndex of the block under the point or "-"
 *   apply <src> <out> <page:first:textfile>[,<page:first:textfile>...]   -> OK or the failure (the text is read from the file, UTF-8)
 */
fun main(args: Array<String>) {
    try {
        when (args[0]) {
            "blocks" -> PDDocument.load(File(args[1])).use { d ->
                for (b in PdfParagraphEditor.blocks(d, args[2].toInt())) {
                    println("${b.firstIndex} ${b.lineCount} ${"%.3f".format(b.widthPt)} ${b.fontSize} | ${b.text} | " + (b.placed?.joinToString(" ") { "%.4f".format(it) } ?: "-"))
                }
            }
            "pick" -> PDDocument.load(File(args[1])).use { d ->
                println(PdfParagraphEditor.pick(PdfParagraphEditor.blocks(d, args[2].toInt()), args[3].toFloat(), args[4].toFloat())?.firstIndex?.toString() ?: "-")
            }
            "apply" -> {
                val edits = args[3].split(",").map { s ->
                    val t = s.split(":", limit = 3)
                    PdfParagraphEditor.Edit(t[0].toInt(), t[1].toInt(), File(t[2]).readText(Charsets.UTF_8))
                }
                PdfParagraphEditor.applyAll(File(args[1]), File(args[2]), edits)
                println("OK")
            }
        }
    } catch (e: Exception) {
        println("ERR:" + e.javaClass.simpleName + ":" + e.message)
    }
}
