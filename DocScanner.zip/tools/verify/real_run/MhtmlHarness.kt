import com.example.docscanner.util.MhtmlImport
import java.io.File

/**
 * Harness for tools/verify/mhtml_real_run_check.py: runs the REAL util/MhtmlImport.kt.
 *   html <file>     the page text as UTF-8 in hex, or NULL
 *   mime <file>     true / false: MhtmlImport.looksLikeMime
 *   qp <text>       quoted-printable decode (Latin-1 text on the command line) -> hex;  b64 <text>  base64 decode -> hex
 */
private fun hex(b: ByteArray): String = b.joinToString("") { String.format("%02x", it.toInt() and 0xFF) }

fun main(args: Array<String>) {
    when (args[0]) {
        "html" -> {
            val html = MhtmlImport.htmlOf(File(args[1]).readBytes())
            println(if (html == null) "NULL" else hex(html.toByteArray(Charsets.UTF_8)))
        }
        "mime" -> println(MhtmlImport.looksLikeMime(File(args[1]).readBytes()))
        "qp" -> println(hex(MhtmlImport.decodeQuotedPrintable(args[1])))
        "b64" -> println(hex(MhtmlImport.decodeBase64(args[1])))
    }
}
