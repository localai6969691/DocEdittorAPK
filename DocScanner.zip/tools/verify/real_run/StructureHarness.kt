import com.example.docscanner.util.PdfRepair
import com.example.docscanner.util.PdfStructureTools
import java.io.File
import java.util.Base64

/**
 * Harness for tools/verify/structure_real_run_check.py: runs the REAL util/PdfStructureTools.kt and util/PdfRepair.kt. Text arguments / results that may hold anything (names, descriptions)
 * are base64; a failure prints "ERR:<exception class>:<message>" as the LAST line. Output = every line printed.
 *   att-list <src>                                  -> one line per attachment: <b64 name> <size> <b64 description>
 *   att-extract <src> <b64 name> <outfile>          -> size written, or "-"
 *   att-add <src> <out> <b64 name> <datafile> <b64 mime | -> <b64 description | ->   -> b64 of the name finally used
 *   att-remove <src> <out> <b64 name>,<b64 name>... -> number removed
 *   portfolio <src> -> true/false      portfolio-set <src> <out> <0|1>
 *   layers-list <src> -> "<b64 name> <true|false>" per layer      layers-set <src> <out> <1,0,1>
 *   links-list <src> -> "<page> <KIND> <b64 target>" per link      links-remove <src> <out> <0|1>  -> number removed
 *   diag <src> -> diagnosis name       repair <src> <out> -> "<pages> <diagnosis>"
 */
private fun d(s: String) = String(Base64.getDecoder().decode(s), Charsets.UTF_8)
private fun e(s: String) = Base64.getEncoder().encodeToString(s.toByteArray(Charsets.UTF_8))
private fun opt(s: String): String? = if (s == "-") null else d(s)

fun main(args: Array<String>) {
    try {
        when (args[0]) {
            "att-list" -> for (a in PdfStructureTools.listAttachments(File(args[1]))) println("${e(a.name)} ${a.size} ${e(a.description)}")
            "att-extract" -> { val b = PdfStructureTools.extractAttachment(File(args[1]), d(args[2])); if (b == null) println("-") else { File(args[3]).writeBytes(b); println(b.size) } }
            "att-add" -> println(e(PdfStructureTools.addAttachment(File(args[1]), File(args[2]), d(args[3]), File(args[4]).readBytes(), opt(args[5]), opt(args[6]) ?: "")))
            "att-remove" -> println(PdfStructureTools.removeAttachments(File(args[1]), File(args[2]), args[3].split(",").filter { it.isNotEmpty() }.map { d(it) }.toSet()))
            "portfolio" -> println(PdfStructureTools.isPortfolio(File(args[1])))
            "portfolio-set" -> { PdfStructureTools.setPortfolio(File(args[1]), File(args[2]), args[3] == "1"); println("done") }
            "layers-list" -> for (l in PdfStructureTools.listLayers(File(args[1]))) println("${e(l.name)} ${l.enabled}")
            "layers-set" -> { PdfStructureTools.setLayers(File(args[1]), File(args[2]), args[3].split(",").map { it == "1" }); println("done") }
            "links-list" -> for (l in PdfStructureTools.listLinks(File(args[1]))) println("${l.page} ${l.kind} ${e(l.target)}")
            "links-remove" -> println(PdfStructureTools.removeLinks(File(args[1]), File(args[2]), args[3] == "1"))
            "diag" -> println(PdfRepair.diagnose(File(args[1])).name)
            "repair" -> { val r = PdfRepair.repair(File(args[1]), File(args[2])); println("${r.pages} ${r.diagnosis.name}") }
            else -> println("ERR:usage:" + args[0])
        }
    } catch (t: Throwable) {
        println("ERR:" + t.javaClass.simpleName + ":" + (t.message ?: ""))
    }
}
