import com.example.docscanner.util.PdfImageEditor
import com.tom_roush.pdfbox.cos.COSName
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.graphics.color.PDDeviceRGB
import com.tom_roush.pdfbox.pdmodel.graphics.image.PDImageXObject
import java.io.ByteArrayInputStream
import java.io.File

/**
 * Harness for tools/verify/image_edit_real_run_check.py: runs the REAL util/PdfImageEditor.kt.
 *   list <pdf> <page>                      -> one line per picture: `index wPx hPx llx lly urx ury | x0 y0 x1 y1` (the last four = fractions of the displayed page, "-" when off the page)
 *   pick <pdf> <page> <x> <y>              -> index of the picture under the point, or "-"
 *   gesture <pdf> <page> <index> <dx> <dy> <scale> -> the box the reader previews for that drag (PdfImageEditor.gestureBox)
 *   apply <src> <out> <ops>                -> ops separated by ';': del:page:index | tf:page:index:dx:dy:scale:turn[:flip h|v|hv|-[:opacity]] | crop:page:index:left:top:right:bottom | rep:page:index:wPx:hPx:<raw RGB file>; prints OK or the failure
 */
fun main(args: Array<String>) {
    try {
        when (args[0]) {
            "list" -> PDDocument.load(File(args[1])).use { d ->
                for (p in PdfImageEditor.pictures(d, args[2].toInt())) {
                    val b = p.box
                    val pl = p.placed?.joinToString(" ") { "%.5f".format(it) } ?: "-"
                    println("${p.index} ${p.widthPx} ${p.heightPx} ${b[0]} ${b[1]} ${b[2]} ${b[3]} | $pl")
                }
            }
            "gesture" -> PDDocument.load(File(args[1])).use { d ->
                val p = PdfImageEditor.pictures(d, args[2].toInt())[args[3].toInt()]
                println(PdfImageEditor.gestureBox(p.placed!!, args[4].toFloat(), args[5].toFloat(), args[6].toFloat())?.joinToString(" ") { "%.5f".format(it) } ?: "-")
            }
            "pick" -> PDDocument.load(File(args[1])).use { d ->
                println(PdfImageEditor.pick(PdfImageEditor.pictures(d, args[2].toInt()), args[3].toFloat(), args[4].toFloat())?.index?.toString() ?: "-")
            }
            "apply" -> {
                val ops = args[3].split(";").map { s ->
                    val t = s.split(":")
                    when (t[0]) {
                        "del" -> PdfImageEditor.Op.Delete(t[1].toInt(), t[2].toInt())
                        "tf" -> PdfImageEditor.Op.Transform(t[1].toInt(), t[2].toInt(), t[3].toFloat(), t[4].toFloat(), t[5].toFloat(), t[6].toFloat(),
                            flipH = t.getOrElse(7) { "-" }.contains("h"), flipV = t.getOrElse(7) { "-" }.contains("v"), opacity = t.getOrNull(8)?.toFloat())
                        "crop" -> PdfImageEditor.Op.Crop(t[1].toInt(), t[2].toInt(), t[3].toFloat(), t[4].toFloat(), t[5].toFloat(), t[6].toFloat())
                        "rep" -> {
                            val w = t[3].toInt(); val h = t[4].toInt(); val raw = File(t[5]).readBytes()
                            PdfImageEditor.Op.Replace(t[1].toInt(), t[2].toInt()) { doc -> PDImageXObject(doc, ByteArrayInputStream(raw), null, w, h, 8, PDDeviceRGB.INSTANCE) }
                        }
                        else -> throw IllegalArgumentException("op " + t[0])
                    }
                }
                PdfImageEditor.applyAll(File(args[1]), File(args[2]), ops)
                println("OK")
            }
        }
    } catch (e: Exception) {
        println("ERR:" + e.javaClass.simpleName + ":" + e.message)
    }
}
