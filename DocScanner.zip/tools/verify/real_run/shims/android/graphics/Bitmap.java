package android.graphics;

/** Stand-in for android.graphics.Bitmap on a plain JVM (phiên 26): an int[] of ARGB pixels. Only what PdfBox-Android's LosslessFactory and the project's PdfRedactor / PdfStamper use. */
public final class Bitmap {
    public enum Config { ALPHA_8, RGB_565, ARGB_4444, ARGB_8888, RGBA_F16, HARDWARE }

    private final int width;
    private final int height;
    private final int[] px;
    private boolean recycled;

    private Bitmap(int w, int h, int[] pixels) { width = w; height = h; px = pixels; }

    public static Bitmap createBitmap(int w, int h, Config c) {
        if (w <= 0 || h <= 0) throw new IllegalArgumentException("width and height must be > 0");
        return new Bitmap(w, h, new int[w * h]);                       // transparent black, like Android
    }
    public static Bitmap createBitmap(int[] colors, int w, int h, Config c) { return new Bitmap(w, h, colors.clone()); }

    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public Config getConfig() { return Config.ARGB_8888; }
    public boolean hasAlpha() { return true; }                          // Android: an ARGB_8888 bitmap reports alpha
    public boolean isMutable() { return true; }
    public boolean isRecycled() { return recycled; }
    public void recycle() { recycled = true; }
    public int getPixel(int x, int y) { return px[y * width + x]; }
    public void setPixel(int x, int y, int color) { px[y * width + x] = color; }
    public void getPixels(int[] out, int offset, int stride, int x, int y, int w, int h) {
        for (int row = 0; row < h; row++) System.arraycopy(px, (y + row) * width + x, out, offset + row * stride, w);
    }
    public void setPixels(int[] in, int offset, int stride, int x, int y, int w, int h) {
        for (int row = 0; row < h; row++) System.arraycopy(in, offset + row * stride, px, (y + row) * width + x, w);
    }
    public Bitmap copy(Config c, boolean mutable) { return new Bitmap(width, height, px.clone()); }
    /** test hook: the raw ARGB array (not in android.graphics) */
    public int[] rawPixels() { return px; }
}
