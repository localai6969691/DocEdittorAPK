package android.graphics;

/** Stand-in for android.graphics.Paint: colour and style only (that is all PdfRedactor uses). */
public class Paint {
    public enum Style { FILL, STROKE, FILL_AND_STROKE }
    private int color = 0xFF000000;
    private Style style = Style.FILL;
    public Paint() { }
    public Paint(int flags) { }
    public int getColor() { return color; }
    public void setColor(int c) { color = c; }
    public Style getStyle() { return style; }
    public void setStyle(Style s) { style = s; }
    public void setAntiAlias(boolean b) { }
    public void setAlpha(int a) { color = (a << 24) | (color & 0xFFFFFF); }
}
