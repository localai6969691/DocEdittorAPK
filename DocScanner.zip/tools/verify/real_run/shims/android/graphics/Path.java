package android.graphics;
import java.util.ArrayList;
/**
 * SCRATCH shim (tools/verify/real_run): android.jar's Path throws "Stub!" off-device, and PdfBox-Android keeps the clipping area of EVERY page in one (PDGraphicsState), so nothing that reads a
 * page could run. This records the points of the path and answers bounds; boolean operations (op) keep the first path. Enough for text extraction and annotations; NOT for rendering.
 */
public class Path {
    public enum Op { DIFFERENCE, INTERSECT, UNION, XOR, REVERSE_DIFFERENCE }
    public enum FillType { WINDING, EVEN_ODD, INVERSE_WINDING, INVERSE_EVEN_ODD }
    public enum Direction { CW, CCW }
    private final ArrayList<float[]> points = new ArrayList<>();
    private FillType fillType = FillType.WINDING;
    private float lastX, lastY;
    public Path() {}
    public Path(Path src) { if (src != null) { points.addAll(src.points); fillType = src.fillType; lastX = src.lastX; lastY = src.lastY; } }
    private void add(float x, float y) { points.add(new float[]{x, y}); lastX = x; lastY = y; }
    public void moveTo(float x, float y) { add(x, y); }
    public void lineTo(float x, float y) { add(x, y); }
    public void quadTo(float x1, float y1, float x2, float y2) { add(x1, y1); add(x2, y2); }
    public void cubicTo(float x1, float y1, float x2, float y2, float x3, float y3) { add(x1, y1); add(x2, y2); add(x3, y3); }
    public void rMoveTo(float dx, float dy) { add(lastX + dx, lastY + dy); }
    public void rLineTo(float dx, float dy) { add(lastX + dx, lastY + dy); }
    public void close() {}
    public void reset() { points.clear(); }
    public void rewind() { points.clear(); }
    public void set(Path src) { points.clear(); points.addAll(src.points); fillType = src.fillType; }
    public boolean isEmpty() { return points.isEmpty(); }
    public void setFillType(FillType t) { fillType = t; }
    public FillType getFillType() { return fillType; }
    public void addRect(float l, float t, float r, float b, Direction d) { add(l, t); add(r, t); add(r, b); add(l, b); }
    public void addRect(RectF rc, Direction d) { addRect(rc.left, rc.top, rc.right, rc.bottom, d); }
    public void addPath(Path src) { points.addAll(src.points); }
    public void addPath(Path src, Matrix m) { points.addAll(src.points); }
    public void transform(Matrix m) {}
    public void transform(Matrix m, Path dst) { if (dst != null && dst != this) dst.set(this); }
    public void offset(float dx, float dy) { for (float[] p : points) { p[0] += dx; p[1] += dy; } }
    public boolean op(Path p, Op op) { return true; }
    public boolean op(Path a, Path b, Op op) { set(a); return true; }
    public void computeBounds(RectF out, boolean exact) {
        if (points.isEmpty()) { out.set(0, 0, 0, 0); return; }
        float l = Float.MAX_VALUE, t = Float.MAX_VALUE, r = -Float.MAX_VALUE, b = -Float.MAX_VALUE;
        for (float[] p : points) { l = Math.min(l, p[0]); r = Math.max(r, p[0]); t = Math.min(t, p[1]); b = Math.max(b, p[1]); }
        out.set(l, t, r, b);
    }
}
