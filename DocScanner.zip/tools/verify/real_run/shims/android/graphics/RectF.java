package android.graphics;
/** SCRATCH shim: a plain rectangle (android.jar's constructors throw "Stub!" off-device). */
public class RectF {
    public float left, top, right, bottom;
    public RectF() {}
    public RectF(float l, float t, float r, float b) { left = l; top = t; right = r; bottom = b; }
    public RectF(RectF o) { if (o != null) set(o); }
    public RectF(Rect o) { if (o != null) { left = o.left; top = o.top; right = o.right; bottom = o.bottom; } }
    public final float width() { return right - left; }
    public final float height() { return bottom - top; }
    public final float centerX() { return (left + right) * 0.5f; }
    public final float centerY() { return (top + bottom) * 0.5f; }
    public final boolean isEmpty() { return left >= right || top >= bottom; }
    public void setEmpty() { left = right = top = bottom = 0; }
    public void set(RectF o) { left = o.left; top = o.top; right = o.right; bottom = o.bottom; }
    public void set(float l, float t, float r, float b) { left = l; top = t; right = r; bottom = b; }
    public void offset(float dx, float dy) { left += dx; top += dy; right += dx; bottom += dy; }
    public void inset(float dx, float dy) { left += dx; top += dy; right -= dx; bottom -= dy; }
    public boolean contains(float x, float y) { return left < right && top < bottom && x >= left && x < right && y >= top && y < bottom; }
    public boolean contains(RectF o) { return left < right && top < bottom && left <= o.left && top <= o.top && right >= o.right && bottom >= o.bottom; }
    public boolean intersect(RectF o) { if (left < o.right && o.left < right && top < o.bottom && o.top < bottom) { left = Math.max(left, o.left); top = Math.max(top, o.top); right = Math.min(right, o.right); bottom = Math.min(bottom, o.bottom); return true; } return false; }
    public boolean intersects(RectF a, RectF b) { return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom; }
    public void union(RectF o) { union(o.left, o.top, o.right, o.bottom); }
    public void union(float l, float t, float r, float b) { if (l < r && t < b) { if (left < right && top < bottom) { left = Math.min(left, l); top = Math.min(top, t); right = Math.max(right, r); bottom = Math.max(bottom, b); } else { left = l; top = t; right = r; bottom = b; } } }
    public void union(float x, float y) { if (x < left) left = x; else if (x > right) right = x; if (y < top) top = y; else if (y > bottom) bottom = y; }
    public void sort() { if (left > right) { float t = left; left = right; right = t; } if (top > bottom) { float t = top; top = bottom; bottom = t; } }
    public void round(Rect dst) { dst.set(Math.round(left), Math.round(top), Math.round(right), Math.round(bottom)); }
    public void roundOut(Rect dst) { dst.set((int) Math.floor(left), (int) Math.floor(top), (int) Math.ceil(right), (int) Math.ceil(bottom)); }
}
