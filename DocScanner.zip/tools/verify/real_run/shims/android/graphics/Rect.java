package android.graphics;
/** SCRATCH shim: a plain integer rectangle. */
public class Rect {
    public int left, top, right, bottom;
    public Rect() {}
    public Rect(int l, int t, int r, int b) { left = l; top = t; right = r; bottom = b; }
    public Rect(Rect o) { if (o != null) set(o); }
    public final int width() { return right - left; }
    public final int height() { return bottom - top; }
    public final int centerX() { return (left + right) >> 1; }
    public final int centerY() { return (top + bottom) >> 1; }
    public final boolean isEmpty() { return left >= right || top >= bottom; }
    public void setEmpty() { left = right = top = bottom = 0; }
    public void set(int l, int t, int r, int b) { left = l; top = t; right = r; bottom = b; }
    public void set(Rect o) { left = o.left; top = o.top; right = o.right; bottom = o.bottom; }
    public void offset(int dx, int dy) { left += dx; top += dy; right += dx; bottom += dy; }
    public boolean contains(int x, int y) { return left < right && top < bottom && x >= left && x < right && y >= top && y < bottom; }
    public boolean contains(Rect o) { return left < right && top < bottom && left <= o.left && top <= o.top && right >= o.right && bottom >= o.bottom; }
    public boolean intersect(Rect o) { if (left < o.right && o.left < right && top < o.bottom && o.top < bottom) { left = Math.max(left, o.left); top = Math.max(top, o.top); right = Math.min(right, o.right); bottom = Math.min(bottom, o.bottom); return true; } return false; }
    public void union(Rect o) { if (o.isEmpty()) return; if (isEmpty()) { set(o); return; } left = Math.min(left, o.left); top = Math.min(top, o.top); right = Math.max(right, o.right); bottom = Math.max(bottom, o.bottom); }
}
