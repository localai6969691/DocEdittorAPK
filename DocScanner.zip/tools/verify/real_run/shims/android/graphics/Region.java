package android.graphics;
/** SCRATCH shim: a region is its bounding rectangle (enough for PdfBox's clipping bookkeeping off-device). */
public class Region {
    public enum Op { DIFFERENCE, INTERSECT, UNION, XOR, REVERSE_DIFFERENCE, REPLACE }
    private final Rect bounds = new Rect();
    public Region() {}
    public Region(Region r) { if (r != null) bounds.set(r.bounds); }
    public Region(Rect r) { if (r != null) bounds.set(r); }
    public Region(int l, int t, int r, int b) { bounds.set(l, t, r, b); }
    public boolean setPath(Path p, Region clip) {
        RectF f = new RectF(); p.computeBounds(f, true); Rect r = new Rect(); f.roundOut(r);
        if (clip != null && !clip.bounds.isEmpty()) r.intersect(clip.bounds);
        bounds.set(r); return !bounds.isEmpty();
    }
    public boolean set(Rect r) { bounds.set(r); return !bounds.isEmpty(); }
    public boolean set(Region r) { bounds.set(r.bounds); return !bounds.isEmpty(); }
    public void setEmpty() { bounds.setEmpty(); }
    public boolean isEmpty() { return bounds.isEmpty(); }
    public boolean isRect() { return true; }
    public Rect getBounds() { return new Rect(bounds); }
    public boolean getBounds(Rect r) { r.set(bounds); return !bounds.isEmpty(); }
    public Path getBoundaryPath() { Path p = new Path(); p.addRect(bounds.left, bounds.top, bounds.right, bounds.bottom, Path.Direction.CW); return p; }
    public boolean contains(int x, int y) { return bounds.contains(x, y); }
    public boolean op(Rect r, Op op) { if (op == Op.INTERSECT) return bounds.intersect(r); if (op == Op.UNION) bounds.union(r); return true; }
    public boolean op(Region r, Op op) { return op(r.bounds, op); }
    public boolean op(Region a, Region b, Op op) { bounds.set(a.bounds); return op(b.bounds, op); }
    public boolean quickReject(Rect r) { return bounds.isEmpty() || !(bounds.left < r.right && r.left < bounds.right && bounds.top < r.bottom && r.top < bounds.bottom); }
}
