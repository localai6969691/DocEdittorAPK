package android.graphics;

/** Stand-in for android.graphics.Canvas: fills only (drawColor, drawRect), clipped to the bitmap, no anti-aliasing - the rectangles of a redaction are whole pixels anyway. */
public class Canvas {
    private final Bitmap bitmap;
    public Canvas(Bitmap bitmap) { this.bitmap = bitmap; }
    public void drawColor(int color) { java.util.Arrays.fill(bitmap.rawPixels(), color); }
    public void drawRect(float left, float top, float right, float bottom, Paint paint) {
        int x0 = Math.max(0, Math.round(left)), y0 = Math.max(0, Math.round(top)), x1 = Math.min(bitmap.getWidth(), Math.round(right)), y1 = Math.min(bitmap.getHeight(), Math.round(bottom));
        int[] px = bitmap.rawPixels();
        for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) px[y * bitmap.getWidth() + x] = paint.getColor();
    }
    public void drawRect(RectF r, Paint paint) { drawRect(r.left, r.top, r.right, r.bottom, paint); }
}
