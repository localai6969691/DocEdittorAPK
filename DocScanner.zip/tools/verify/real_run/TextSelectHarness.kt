import com.example.docscanner.util.PdfTextLayer
import com.example.docscanner.util.PdfTextMarkup
import com.example.docscanner.util.ReaderEdits
import java.io.File

/**
 * Harness for tools/verify/text_select_check.py: runs the REAL util/PdfTextLayer.kt (PdfBox reads the words of a page), util/PdfTextMarkup.kt (selection, highlight writer) and util/ReaderEdits.kt.
 *   words <pdf> <page>                              one line per word:  text <TAB> l,t,r,b <TAB> line      (or NULL)
 *   select <pdf> <page> ax ay bx by                 one line per band:  l,t,r,b                            (or NONE)
 *   annotate <pdf> <out> <page> ax ay bx by <style> highlight | underline | strike  -> number of annotations written (or NONE)
 *   (stdin) NEAR <maxDistance> <x> <y> <spec> | BETWEEN <first> <last> <n> | SEL <ax> <ay> <bx> <by> <spec>      spec = word;word;...  word = l,t,r,b,line
 *   (stdin) UNDO <ops>                              ops = space-separated:  N (new group) | A<group> (add an item of that group) | U (undo)  -> the groups of the items left, in order
 */
private fun spec(s: String): List<PdfTextMarkup.WordBox> = if (s == "-") emptyList() else s.split(";").mapIndexed { i, w ->
    val f = w.split(",")
    PdfTextMarkup.WordBox("w$i", floatArrayOf(f[0].toFloat(), f[1].toFloat(), f[2].toFloat(), f[3].toFloat()), f[4].toInt())
}

private fun bands(b: List<FloatArray>?): String = if (b == null) "NONE" else b.joinToString("|") { x -> x.joinToString(",") { v -> "%.5f".format(java.util.Locale.US, v) } }

fun main(args: Array<String>) {
    when (args.getOrNull(0)) {
        "words" -> {
            val w = PdfTextLayer.words(File(args[1]), args[2].toInt())
            if (w == null) println("NULL") else for (x in w) println(x.text + "\t" + x.box.joinToString(",") + "\t" + x.line)
        }
        "select" -> {
            val w = PdfTextLayer.words(File(args[1]), args[2].toInt()) ?: emptyList()
            val s = PdfTextMarkup.selectionBoxes(w, args[3].toFloat(), args[4].toFloat(), args[5].toFloat(), args[6].toFloat())
            if (s == null) println("NONE") else for (b in s) println(b.joinToString(","))
        }
        "annotate" -> {
            val page = args[3].toInt()
            val w = PdfTextLayer.words(File(args[1]), page) ?: emptyList()
            val s = PdfTextMarkup.selectionBoxes(w, args[4].toFloat(), args[5].toFloat(), args[6].toFloat(), args[7].toFloat())
            if (s == null) { println("NONE"); return }
            val style = when (args[8]) { "underline" -> PdfTextMarkup.Style.UNDERLINE; "strike" -> PdfTextMarkup.Style.STRIKEOUT; else -> PdfTextMarkup.Style.HIGHLIGHT }
            val rgb = floatArrayOf(1f, 0.92f, 0.23f)
            println(PdfTextMarkup.annotate(File(args[1]), File(args[2]), mapOf(page to s.map { PdfTextMarkup.Mark(it, style, rgb) })))
        }
        else -> while (true) {
            val line = readLine() ?: break
            val t = line.split(" ")
            when (t[0]) {
                "NEAR" -> println(PdfTextMarkup.nearestWord(spec(t[4]), t[2].toFloat(), t[3].toFloat(), if (t[1] == "any") Float.MAX_VALUE else t[1].toFloat()))
                "BETWEEN" -> println(PdfTextMarkup.wordsBetween(spec(List(t[3].toInt()) { "0,0,1,1,0" }.joinToString(";")), t[1].toInt(), t[2].toInt()).joinToString(","))
                "SEL" -> println(bands(PdfTextMarkup.selectionBoxes(spec(t[5]), t[1].toFloat(), t[2].toFloat(), t[3].toFloat(), t[4].toFloat())))
                "UNDO" -> {
                    val e = ReaderEdits()
                    var group = 0
                    for (op in t.drop(1)) {
                        if (op == "N") group = e.newGroup()
                        else if (op == "U") e.undo()
                        else if (op.startsWith("A")) e.add(ReaderEdits.Item(ReaderEdits.Kind.HIGHLIGHT, 0, floatArrayOf(0f, 0f, 1f, 1f), group = op.substring(1).toInt()))
                    }
                    println(e.items.joinToString(",") { it.group.toString() })
                }
                else -> println("?")
            }
        }
    }
}
