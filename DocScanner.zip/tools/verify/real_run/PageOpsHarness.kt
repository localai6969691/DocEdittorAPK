import com.example.docscanner.util.PdfPageOps
import java.io.File

/**
 * Test harness for tools/verify/page_ops_check.py: runs the REAL util/PdfPageOps.kt (compiled by kotlinc, on a PdfBox-Android built from its source).
 *   apply <src> <out> <plan>            plan = "source:turn,source:turn,..."   -> prints the page count (or -1)
 *   (stdin) one command per line:  ROT <plan> <pos> <delta> | DEL <plan> <pos> | MOV <plan> <from> <to> | VAL <count> <plan> | UNCH <count> <plan> | ORD <count> <plan> | NORM <deg> | ID <count>
 * An empty plan is written as "-".
 */
private fun parse(s: String): List<PdfPageOps.Entry> =
    if (s == "-" || s.isEmpty()) emptyList() else s.split(",").map { val p = it.split(":"); PdfPageOps.Entry(p[0].toInt(), p[1].toInt()) }

private fun show(plan: List<PdfPageOps.Entry>): String = if (plan.isEmpty()) "-" else plan.joinToString(",") { "${it.source}:${it.turn}" }

fun main(args: Array<String>) {
    if (args.isNotEmpty() && args[0] == "apply") {
        println(PdfPageOps.apply(File(args[1]), File(args[2]), parse(args[3])))
        return
    }
    while (true) {
        val line = readLine() ?: break
        val t = line.split(" ")
        when (t[0]) {
            "ROT" -> println(show(PdfPageOps.rotated(parse(t[1]), t[2].toInt(), t[3].toInt())))
            "DEL" -> println(show(PdfPageOps.deleted(parse(t[1]), t[2].toInt())))
            "MOV" -> println(show(PdfPageOps.moved(parse(t[1]), t[2].toInt(), t[3].toInt())))
            "VAL" -> println(if (PdfPageOps.isValid(parse(t[2]), t[1].toInt())) 1 else 0)
            "UNCH" -> println(if (PdfPageOps.isUnchanged(parse(t[2]), t[1].toInt())) 1 else 0)
            "ORD" -> println(if (PdfPageOps.orderChanged(parse(t[2]), t[1].toInt())) 1 else 0)
            "NORM" -> println(PdfPageOps.normalizeTurn(t[1].toInt()))
            "ID" -> println(show(PdfPageOps.identity(t[1].toInt())))
            else -> println("?")
        }
    }
}
