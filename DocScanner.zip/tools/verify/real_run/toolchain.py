"""Toolchain to RUN the project's real Kotlin code off-device (phiên 24, TECHNICAL_DOCS.md 4.64).

Until phiên 24 the PdfBox part of the code was only ever compiled by GitHub Actions: every check in tools/verify mirrored the logic in Java or rebuilt the expected PDF with
pikepdf, and said so ("CHƯA kiểm: phần PdfBox chưa biên dịch / chạy"). This module makes the real thing runnable wherever GitHub is reachable:

  1. kotlinc (the version in build.gradle) from the JetBrains GitHub release;
  2. android.jar (API 35) from the Sable/android-platforms repository on GitHub (Google's own download is not needed: only the signatures are compiled against);
  3. PdfBox-Android (the exact tag of app/build.gradle) cloned from GitHub and compiled with the JDK's javac. Three files need libraries that live only on Maven (BouncyCastle,
     JP2ForAndroid), so they are replaced by small stand-ins that keep the public API: certificate-based encryption and JPEG 2000 do not work in the scratch build, everything else
     (page tree, annotations, forms, content streams, password encryption, saving) is the real PdfBox-Android code;
  4. a two-line shim for android.util.Log (android.jar's own methods throw "Stub!" off-device).

Everything is cached under DOCSCANNER_TOOLCHAIN (default ~/.cache/docscanner-toolchain); the first build takes a few minutes, later runs are instant.
What this does NOT give: a phone. Anything that needs a real Android framework (Bitmap, Canvas, PdfRenderer, views) is stubbed by android.jar and throws "Stub!" when called, so only
code that is pure Kotlin + PdfBox + java.* can be run; a check says so when it touches something else. It is not the Gradle build either: AndroidX, ML Kit, CameraX and the generated
R / binding classes are absent, so whole-project compilation is only informative (compare against a baseline, see kotlin_diff in 4.64), never a replacement for CI.
"""
import glob, hashlib, os, re, shutil, subprocess, sys, tempfile, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(HERE)))
UTIL = os.path.join(ROOT, "app/src/main/java/com/example/docscanner/util")
HOME = os.environ.get("DOCSCANNER_TOOLCHAIN") or os.path.expanduser("~/.cache/docscanner-toolchain")


def _read(path):
    return open(path, encoding="utf-8").read()


def versions():
    top = _read(os.path.join(ROOT, "build.gradle"))
    app = _read(os.path.join(ROOT, "app/build.gradle"))
    kotlin = re.search(r"kotlin[-.\w]*['\"]?\s*[:=,]?\s*['\"]?(\d+\.\d+\.\d+)", top)
    kt = re.search(r"org\.jetbrains\.kotlin\.android['\"]?\s+version\s+['\"](\d+\.\d+\.\d+)", top) or kotlin
    pdfbox = re.search(r"pdfbox-android:(\d+\.\d+\.\d+\.\d+)", app)
    return (kt.group(1) if kt else "2.2.10"), (pdfbox.group(1) if pdfbox else "2.0.27.0")


def _download(url, dest):
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    tmp = dest + ".part"
    with urllib.request.urlopen(url, timeout=300) as r, open(tmp, "wb") as f:
        shutil.copyfileobj(r, f)
    os.replace(tmp, dest)


def _javac(args):
    return subprocess.run(["java", "-m", "jdk.compiler/com.sun.tools.javac.Main", "-nowarn", "-proc:none", "-encoding", "UTF-8"] + args, capture_output=True, text=True)


class Toolchain:
    def __init__(self, home=HOME):
        self.home = home
        self.kotlin_version, self.pdfbox_version = versions()
        self.kotlinc = os.path.join(home, "kotlinc", "bin", "kotlinc")
        self.android_jar = os.path.join(home, "android.jar")
        self.pdfbox_out = os.path.join(home, "pdfbox-out")
        self.shim_out = os.path.join(home, "shim-out")
        self.coroutines = os.path.join(home, "kotlinc", "lib", "kotlinx-coroutines-core-jvm.jar")
        self.stdlib = os.path.join(home, "kotlinc", "lib", "kotlin-stdlib.jar")

    # ------------------------------------------------------------------ one-time build
    def available(self):
        return all(os.path.exists(p) for p in (self.kotlinc, self.android_jar, os.path.join(self.pdfbox_out, "com"), os.path.join(self.shim_out, "android")))

    def ensure(self, log=print):
        if self.available():
            return True
        if shutil.which("java") is None:
            log("no java on PATH"); return False
        try:
            if not os.path.exists(self.kotlinc):
                log(f"downloading kotlinc {self.kotlin_version} ...")
                z = os.path.join(self.home, "kotlin-compiler.zip")
                _download(f"https://github.com/JetBrains/kotlin/releases/download/v{self.kotlin_version}/kotlin-compiler-{self.kotlin_version}.zip", z)
                subprocess.run(["unzip", "-q", "-o", z, "-d", self.home], check=True)
                os.remove(z)
            if not os.path.exists(self.android_jar):
                log("downloading android.jar (API 35) ...")
                _download("https://raw.githubusercontent.com/Sable/android-platforms/master/android-35/android.jar", self.android_jar)
            if not os.path.exists(os.path.join(self.shim_out, "android")):
                self._build_shim()
            if not os.path.exists(os.path.join(self.pdfbox_out, "com")):
                self._build_pdfbox(log)
        except Exception as exc:  # network, git or compile problems: the caller reports "toolchain unavailable"
            log(f"toolchain build failed: {exc}")
            return False
        return self.available()

    def _build_shim(self):
        src = os.path.join(self.home, "shim-src", "android", "util")
        os.makedirs(src, exist_ok=True)
        methods = "".join(f"    public static int {n}(String t, String m) {{ return 0; }}\n    public static int {n}(String t, String m, Throwable e) {{ return 0; }}\n" for n in "vdiwe")
        open(os.path.join(src, "Log.java"), "w").write(
            "package android.util;\n/** scratch shim: android.jar's Log throws Stub! off-device */\npublic final class Log {\n    private Log() {}\n" + methods +
            "    public static int w(String t, Throwable e) { return 0; }\n    public static boolean isLoggable(String t, int l) { return false; }\n"
            "    public static String getStackTraceString(Throwable e) { return String.valueOf(e); }\n    public static int println(int p, String t, String m) { return 0; }\n}\n")
        os.makedirs(self.shim_out, exist_ok=True)
        r = _javac(["-d", self.shim_out, os.path.join(src, "Log.java")])
        if r.returncode:
            raise RuntimeError("shim: " + r.stderr[:500])

    def _build_pdfbox(self, log):
        src = os.path.join(self.home, "pdfbox-android")
        if not os.path.exists(src):
            log(f"cloning PdfBox-Android v{self.pdfbox_version} ...")
            subprocess.run(["git", "clone", "-q", "--depth", "1", "--branch", f"v{self.pdfbox_version}", "https://github.com/TomRoush/PdfBox-Android.git", src], check=True)
        base = os.path.join(src, "library/src/main/java/com/tom_roush/pdfbox")
        # stand-ins for the three files that need BouncyCastle / JP2ForAndroid (public API kept; see the module docstring)
        open(os.path.join(base, "pdmodel/encryption/SecurityProvider.java"), "w").write(
            "package com.tom_roush.pdfbox.pdmodel.encryption;\nimport java.io.IOException;\nimport java.security.Provider;\nimport java.security.Security;\n"
            "public class SecurityProvider {\n    private SecurityProvider() { }\n    public static Provider getProvider() throws IOException {\n"
            "        Provider[] all = Security.getProviders();\n        if (all.length == 0) throw new IOException(\"no security provider\");\n        return all[0];\n    }\n"
            "    public static void setProvider(Provider provider) { }\n}\n")
        open(os.path.join(base, "pdmodel/encryption/PublicKeySecurityHandler.java"), "w").write(
            "package com.tom_roush.pdfbox.pdmodel.encryption;\nimport java.io.IOException;\nimport com.tom_roush.pdfbox.cos.COSArray;\nimport com.tom_roush.pdfbox.pdmodel.PDDocument;\n"
            "public final class PublicKeySecurityHandler extends SecurityHandler {\n    public static final String FILTER = \"Adobe.PubSec\";\n"
            "    public PublicKeySecurityHandler() { }\n    public PublicKeySecurityHandler(PublicKeyProtectionPolicy policy) { }\n"
            "    @Override public void prepareForDecryption(PDEncryption e, COSArray id, DecryptionMaterial m) throws IOException { throw new IOException(\"public-key encryption: not in the scratch build\"); }\n"
            "    @Override public void prepareDocumentForEncryption(PDDocument doc) throws IOException { throw new IOException(\"public-key encryption: not in the scratch build\"); }\n}\n")
        open(os.path.join(base, "filter/JPXFilter.java"), "w").write(
            "package com.tom_roush.pdfbox.filter;\nimport java.io.IOException;\nimport java.io.InputStream;\nimport java.io.OutputStream;\nimport com.tom_roush.pdfbox.cos.COSDictionary;\n"
            "public final class JPXFilter extends Filter {\n"
            "    @Override public DecodeResult decode(InputStream encoded, OutputStream decoded, COSDictionary parameters, int index, DecodeOptions options) throws IOException { throw new IOException(\"JPX: not in the scratch build\"); }\n"
            "    @Override public DecodeResult decode(InputStream encoded, OutputStream decoded, COSDictionary parameters, int index) throws IOException { throw new IOException(\"JPX: not in the scratch build\"); }\n"
            "    @Override protected void encode(InputStream input, OutputStream encoded, COSDictionary parameters) throws IOException { throw new IOException(\"JPX: not in the scratch build\"); }\n}\n")
        sources = glob.glob(os.path.join(src, "library/src/main/java/**/*.java"), recursive=True)
        listing = os.path.join(self.home, "pdfbox-sources.txt")
        open(listing, "w").write("\n".join(sources) + "\n")
        log(f"compiling PdfBox-Android ({len(sources)} files) ...")
        shutil.rmtree(self.pdfbox_out, ignore_errors=True)
        os.makedirs(self.pdfbox_out)
        r = _javac(["-Xmaxerrs", "50", "-cp", self.android_jar, "-d", self.pdfbox_out, "@" + listing])
        if r.returncode:
            shutil.rmtree(self.pdfbox_out, ignore_errors=True)
            raise RuntimeError("PdfBox-Android did not compile: " + (r.stderr or r.stdout)[:800])

    # ------------------------------------------------------------------ compile + run project code
    def classpath(self, *extra):
        return os.pathsep.join([*extra, self.shim_out, self.pdfbox_out, self.android_jar, self.coroutines, self.stdlib])

    def _util_definitions(self):
        out = {}
        for f in glob.glob(os.path.join(UTIL, "*.kt")):
            for name in re.findall(r"^(?:internal |private |public )?(?:object|class|enum class|data class|interface|sealed class|abstract class)\s+(\w+)", _read(f), re.M):
                out[name] = f
        return out

    @staticmethod
    def replace_function(text, signature, new_function):
        """Returns [text] with the Kotlin function that starts at [signature] (exact text up to and including the opening brace) replaced by [new_function]; braces are matched
        (strings and comments of that function are simple enough in this project to be counted as they are). Used for TEST DOUBLES: PdfVerify.opensAsPdf renders with Android's
        PdfRenderer, which does not exist off-device, so the real-run checks swap it for a PdfBox page-count check (stated in each check's docstring)."""
        start = text.index(signature)
        depth, i = 0, text.index("{", start)
        begin = i
        while i < len(text):
            if text[i] == "{": depth += 1
            elif text[i] == "}":
                depth -= 1
                if depth == 0: break
            i += 1
        return text[:start] + new_function + text[i + 1:]

    def compile(self, util_files, extra_files=(), out_dir=None, mutate=None, doubles=None):
        """Compiles util/<name>.kt files of the REAL project plus [extra_files] (harness, stand-ins). Other util files that the compiler reports as unresolved are added automatically.
        [mutate] = {file name: (old, new)} compiles a doctored COPY (negative tests). [doubles] = {file name: (function signature, new function text)} swaps whole functions for
        test doubles (see [replace_function]). @return (out_dir, [files used]) or raises RuntimeError with the compiler messages."""
        key = hashlib.sha256("".join(sorted(f"{n}{o}{w}" for n, (o, w) in (mutate or {}).items())).encode()).hexdigest()[:10]
        out_dir = out_dir or tempfile.mkdtemp(prefix="kt-run-")
        shutil.rmtree(out_dir, ignore_errors=True)
        os.makedirs(out_dir)
        defs = self._util_definitions()
        files = [os.path.join(UTIL, f) for f in util_files]
        scratch = tempfile.mkdtemp(prefix="kt-src-") if (mutate or doubles) else None
        for _ in range(15):
            used = []
            for f in files:
                name = os.path.basename(f)
                if (mutate and name in mutate) or (doubles and name in doubles):
                    text = _read(f)
                    if doubles and name in doubles:
                        text = self.replace_function(text, *doubles[name])
                    if mutate and name in mutate:
                        old, new = mutate[name]
                        if old not in text:
                            raise RuntimeError(f"mutation target not found in {name}: {old[:60]}")
                        text = text.replace(old, new, 1)
                    f = os.path.join(scratch, name)
                    open(f, "w", encoding="utf-8").write(text)
                used.append(f)
            r = subprocess.run([self.kotlinc, "-nowarn", "-jvm-target", "17", "-cp", self.classpath(), *used, *extra_files, "-d", out_dir],
                               capture_output=True, text=True, env={**os.environ, "JAVA_OPTS": "-Xmx2g"})
            if r.returncode == 0:
                return out_dir, [os.path.basename(f) for f in files]
            err = r.stderr + r.stdout
            missing = [defs[n] for n in set(re.findall(r"error: unresolved reference '(\w+)'", err)) if n in defs and defs[n] not in files]
            if not missing:
                raise RuntimeError(err[:2500])
            files += sorted(set(missing))
        raise RuntimeError("too many rounds adding util files")

    def run(self, out_dir, main_class, args=(), stdin=None, timeout=300):
        return subprocess.run(["java", "-Dfile.encoding=UTF-8", "-Dstdout.encoding=UTF-8", "-cp", self.classpath(out_dir), main_class, *args],
                              input=stdin, capture_output=True, text=True, timeout=timeout)


def get(required=True):
    """Toolchain ready to use, or None (when not [required]) / SystemExit(2) when it cannot be built here."""
    tc = Toolchain()
    if tc.ensure():
        return tc
    if required:
        print("The real-run toolchain is not available here (needs java, git, unzip and access to github.com). Skipping is NOT a pass: run this where GitHub is reachable.")
        raise SystemExit(2)
    return None


if __name__ == "__main__":
    tc = get()
    print("toolchain ready:", tc.home, "| kotlinc", tc.kotlin_version, "| PdfBox-Android", tc.pdfbox_version)
