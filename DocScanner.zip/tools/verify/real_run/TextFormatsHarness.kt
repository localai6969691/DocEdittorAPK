import com.example.docscanner.util.OdtWriter
import com.example.docscanner.util.TextExporters
import java.io.File

/**
 * Harness for tools/verify/text_formats_check.py: runs the REAL util/TextExporters.kt (rtf, latex) and util/OdtWriter.kt.
 *   <kind: rtf|tex|odt> <title file> <pages file> <out file>      pages file: UTF-8, pages separated by a line holding only  =====PAGE=====
 */
fun main(args: Array<String>) {
    val kind = args[0]
    val title = File(args[1]).readText(Charsets.UTF_8)
    val pages = File(args[2]).readText(Charsets.UTF_8).split("\n=====PAGE=====\n")
    val out = File(args[3])
    when (kind) {
        "rtf" -> out.writeText(TextExporters.rtf(title, pages), Charsets.UTF_8)
        "tex" -> out.writeText(TextExporters.latex(title, pages), Charsets.UTF_8)
        "odt" -> out.outputStream().buffered().use { OdtWriter.write(title, pages, it) }
        else -> error("unknown kind $kind")
    }
    println("ok")
}
