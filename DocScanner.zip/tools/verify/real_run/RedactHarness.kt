import android.graphics.Bitmap
import com.example.docscanner.util.PdfRedactor
import com.example.docscanner.util.PdfStamper
import java.io.File

/**
 * Harness for tools/verify/redactor_real_run_check.py: the REAL util/PdfRedactor.kt and util/PdfStamper.kt on PdfBox-Android, with the shim android.graphics (real_run/shims) and PdfPageBitmapDouble.kt
 * (pages drawn by poppler). Result = last stdout line; a failure prints "ERR:<class>:<message>".
 *   redact <src> <out> <dpi> <page>:<l>,<t>,<r>,<b>[;<l>,<t>,<r>,<b>...] ...    -> number of pages replaced by pictures
 *   pixelrect <l> <t> <r> <b> <w> <h>                                           -> "l t r b"
 *   stamp <src> <out> <cx> <cy> <wf> <pages csv> <image rgba file> <w> <h>      -> number of pages stamped      (rgba file: w*h*4 bytes R,G,B,A)
 *   rectfor <cx> <cy> <wf> <aspect> <dw> <dh>                                   -> "x y w h"
 */
fun main(args: Array<String>) {
    try {
        when (args[0]) {
            "redact" -> {
                val map = HashMap<Int, List<FloatArray>>()
                for (i in 4 until args.size) { val (p, rs) = args[i].split(":"); map[p.toInt()] = rs.split(";").map { r -> r.split(",").map { it.toFloat() }.toFloatArray() } }
                println(PdfRedactor.redact(File(args[1]), File(args[2]), map, args[3].toFloat()))
            }
            "pixelrect" -> println(PdfRedactor.pixelRect(floatArrayOf(args[1].toFloat(), args[2].toFloat(), args[3].toFloat(), args[4].toFloat()), args[5].toInt(), args[6].toInt()).joinToString(" "))
            "stamp" -> {
                val w = args[8].toInt(); val h = args[9].toInt(); val raw = File(args[7]).readBytes(); val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                for (y in 0 until h) for (x in 0 until w) { val o = (y * w + x) * 4; bmp.setPixel(x, y, ((raw[o + 3].toInt() and 255) shl 24) or ((raw[o].toInt() and 255) shl 16) or ((raw[o + 1].toInt() and 255) shl 8) or (raw[o + 2].toInt() and 255)) }
                println(PdfStamper.stamp(File(args[1]), File(args[2]), bmp, PdfStamper.Placement(args[3].toFloat(), args[4].toFloat(), args[5].toFloat()), args[6].split(",").map { it.toInt() }.toSet()))
            }
            "rectfor" -> println(PdfStamper.rectFor(PdfStamper.Placement(args[1].toFloat(), args[2].toFloat(), args[3].toFloat()), args[4].toFloat(), args[5].toFloat(), args[6].toFloat()).joinToString(" "))
            else -> println("ERR:usage:" + args[0])
        }
    } catch (t: Throwable) { println("ERR:" + t.javaClass.simpleName + ":" + (t.message ?: "")) }
}
