import com.example.docscanner.util.PdfAutoToc
import com.example.docscanner.util.PdfBookmarks
import java.io.File

/**
 * Harness for tools/verify/autotoc_real_run_check.py: runs the REAL util/PdfAutoToc.kt and util/PdfBookmarks.saveWithOutline.
 *   detect <pdf>               first line the status (FOUND | NO_TEXT | NO_HEADINGS | UNREADABLE), then one line per entry: level|page0|title
 *   lines <pdf>                every line of the text layer: page0|size|bold|top|text (for debugging)
 *   make <src> <out>           detect, then write the outline into a copy: prints the number of entries written, or the status when nothing was made
 */
fun main(args: Array<String>) {
    if (args[0] == "lines") {
        com.tom_roush.pdfbox.pdmodel.PDDocument.load(File(args[1])).use { doc ->
            for (l in PdfAutoToc.readLines(doc)) println(l.page.toString() + "|" + l.size + "|" + l.bold + "|" + "%.1f".format(java.util.Locale.ROOT, l.top) + "|" + l.text)
        }
        return
    }
    val result = PdfAutoToc.detect(File(args[1]))
    when (args[0]) {
        "detect" -> {
            println(result.status.name)
            for (e in result.entries) println(e.level.toString() + "|" + e.page + "|" + e.title)
        }
        "make" -> {
            if (result.status != PdfAutoToc.Status.FOUND) {
                println(result.status.name)
            } else {
                PdfBookmarks.saveWithOutline(File(args[1]), File(args[2]), result.entries)
                println(result.entries.size)
            }
        }
    }
}
