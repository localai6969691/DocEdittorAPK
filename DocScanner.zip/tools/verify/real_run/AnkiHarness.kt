import com.example.docscanner.util.AnkiDeck
import java.io.File
import java.util.Base64

/**
 * Harness for tools/verify/anki_real_run_check.py: runs the REAL util/AnkiDeck.kt. Text arguments are base64; the result is every line printed ("ERR:<class>:<message>" last on failure).
 *   cards <b64 text>                          -> one line per card: <b64 front> <b64 back>
 *   split <b64 line>                          -> "<b64 front> <b64 back>" or "-"
 *   tsv <cards file>                          -> the tab-separated text, base64 (cards file: one `<b64 front> <b64 back>` per line)
 *   stmts <cards file> <b64 deck> <nowMs> <out file> -> writes every statement: `<b64 sql>` then one `i:<n>` / `s:<b64>` token per argument, tab separated
 *   pack <collection file> <out apkg>         -> zips the collection
 *   csum <b64 text> / guid <b64 front> <b64 back> / deckid <b64 name>
 */
private fun d(s: String) = String(Base64.getDecoder().decode(s), Charsets.UTF_8)
private fun e(s: String) = Base64.getEncoder().encodeToString(s.toByteArray(Charsets.UTF_8))
private fun readCards(path: String) = File(path).readLines().filter { it.isNotBlank() }.map { val p = it.split(" "); AnkiDeck.Card(d(p[0]), d(p[1])) }

fun main(args: Array<String>) {
    try {
        when (args[0]) {
            "cards" -> for (c in AnkiDeck.cardsFromText(d(args[1]))) println("${e(c.front)} ${e(c.back)}")
            "split" -> { val p = AnkiDeck.split(d(args[1])); println(if (p == null) "-" else "${e(p.first)} ${e(p.second)}") }
            "tsv" -> println(e(AnkiDeck.tsv(readCards(args[1]))))
            "stmts" -> File(args[4]).writeText(AnkiDeck.statements(readCards(args[1]), d(args[2]), args[3].toLong()).joinToString("\n") { st ->
                (listOf(e(st.sql)) + st.args.map { a -> if (a is Long) "i:$a" else "s:" + e(a.toString()) }).joinToString("\t") })
            "pack" -> { AnkiDeck.pack(File(args[1]), File(args[2])); println("done") }
            "csum" -> println(AnkiDeck.fieldChecksum(d(args[1])))
            "guid" -> println(AnkiDeck.guid(d(args[1]), d(args[2])))
            "deckid" -> println(AnkiDeck.deckId(d(args[1])))
            else -> println("ERR:usage:" + args[0])
        }
    } catch (t: Throwable) { println("ERR:" + t.javaClass.simpleName + ":" + (t.message ?: "")) }
}
