import com.example.docscanner.util.ReaderEdits

/**
 * Harness for tools/verify/reader_edits_real_run_check.py: drives the REAL util/ReaderEdits.kt from commands on stdin, one per line, and prints one line per command.
 *   add <label> <KIND> <page> <x0,y0,x1,y1> <group> <points|-> <width> [chunk] [name]   adds a mark (the label is kept in `text`); prints true / false
 *   newgroup                              prints the next group number
 *   undo | redo                           prints the label of the mark the step touched, or -
 *   erase <page> <x> <y>                  erases the mark under the point (and its group): prints how many went, 0 when none
 *   hit <page> <x> <y>                    prints the label of the mark under the point, or -
 *   state                                 the labels in list order, comma separated ("-" when empty); then canRedo
 *   clear
 */
fun main() {
    val edits = ReaderEdits()
    while (true) {
        val line = readLine() ?: break
        val t = line.trim().split(" ")
        when (t[0]) {
            "add" -> {
                val box = t[4].split(",").map { it.toFloat() }.toFloatArray()
                val pts = if (t[6] == "-") null else t[6].split(",").map { it.toFloat() }.toFloatArray()
                println(edits.add(ReaderEdits.Item(ReaderEdits.Kind.valueOf(t[2]), t[3].toInt(), box, t[1], points = pts, group = t[5].toInt(), width = t[7].toFloat(), chunk = t.getOrNull(8)?.toInt() ?: -1, name = t.getOrNull(9)?.takeIf { it != "-" })))
            }
            "newgroup" -> println(edits.newGroup())
            "undo" -> println(edits.undo()?.text ?: "-")
            "redo" -> println(edits.redo()?.text ?: "-")
            "erase" -> {
                val hit = edits.hit(t[1].toInt(), t[2].toFloat(), t[3].toFloat())
                println(if (hit == null) 0 else edits.erase(hit))
            }
            "hit" -> println(edits.hit(t[1].toInt(), t[2].toFloat(), t[3].toFloat())?.text ?: "-")
            "state" -> println((if (edits.isEmpty()) "-" else edits.items.joinToString(",") { it.text ?: "?" }) + " redo=" + edits.canRedo())
            "clear" -> {
                edits.clear()
                println("cleared")
            }
        }
    }
}
