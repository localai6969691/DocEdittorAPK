import com.example.docscanner.util.VoiceCommand

/**
 * Harness for tools/verify/voice_command_real_run_check.py. `query` : every stdin line is a heard sentence -> the query toQuery leaves ("" printed as "-").
 * `pick` : the FIRST stdin line is the heard sentence, every other line a tool name -> the chosen index or "-".
 */
fun main(args: Array<String>) {
    val lines = generateSequence(::readLine).toList()
    when (args.getOrElse(0) { "" }) {
        "query" -> for (l in lines) println(VoiceCommand.toQuery(l).ifEmpty { "-" })
        "pick" -> println(VoiceCommand.pick(lines.first(), lines.drop(1))?.toString() ?: "-")
    }
}
