import com.example.docscanner.util.OperationLog

/**
 * Harness for tools/verify/operation_log_real_run_check.py: runs the REAL pure functions of util/OperationLog.kt on lines read from stdin.
 *   build      each line `time TAB actionHex TAB detailHex` (UTF-8 in hex, so no shell or whitespace trouble) -> the log lines, chained from nothing
 *   verify     each line is a log line -> `STATUS count badSeq head`
 *   roundtrip  each line is a log line -> the line parsed and encoded again (or NULL), then the detail in hex
 *   trim       each line is a log line -> `size firstSeq` after OperationLog.trim
 */
private fun hex(s: String): String = s.toByteArray(Charsets.UTF_8).joinToString("") { String.format("%02x", it.toInt() and 0xFF) }
private fun unhex(h: String): String = String(ByteArray(h.length / 2) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }, Charsets.UTF_8)

fun main(args: Array<String>) {
    val lines = generateSequence(::readLine).toList().filter { it.isNotEmpty() }
    when (args[0]) {
        "build" -> {
            var last: OperationLog.Entry? = null
            for (l in lines) {
                val f = l.split("\t")
                val e = OperationLog.next(last, f[0].toLong(), unhex(f[1]), unhex(f[2]))
                println(OperationLog.encode(e))
                last = e
            }
        }
        "verify" -> {
            val v = OperationLog.verify(lines)
            println(v.status.name + " " + v.count + " " + v.badSeq + " " + v.head)
        }
        "roundtrip" -> for (l in lines) {
            val e = OperationLog.parse(l)
            println(if (e == null) "NULL" else OperationLog.encode(e))
            println(if (e == null) "-" else hex(e.detail))
        }
        "trim" -> {
            val t = OperationLog.trim(lines)
            println(t.size.toString() + " " + (OperationLog.parse(t.first())?.seq ?: -1))
        }
    }
}
