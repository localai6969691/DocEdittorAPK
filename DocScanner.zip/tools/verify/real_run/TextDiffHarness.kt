import com.example.docscanner.util.TextDiff
import java.io.File

/**
 * Harness for tools/verify/text_diff_check.py: the REAL util/TextDiff.kt.
 *   words <pdf>                      the words of the PDF, space-separated (or NULL)
 *   compare <old> <new> <report>     oldWords newWords kept removed added approximate pagesChanged(comma)   (or NULL)
 *   (stdin) DIFF <old words> | <new words>     ->  approximate kept removed added then one "k:oi:ni" per edit, comma-separated
 */
fun main(args: Array<String>) {
    when (args.getOrNull(0)) {
        "words" -> println(TextDiff.words(File(args[1]))?.words?.joinToString(" ") ?: "NULL")
        "compare" -> {
            val r = TextDiff.compare(File(args[1]), File(args[2]), File(args[3]), "Report <A&B>")
            println(if (r == null) "NULL" else "${r.oldWords} ${r.newWords} ${r.kept} ${r.removed} ${r.added} ${r.approximate} ${r.pagesChanged.joinToString(",")}")
        }
        else -> while (true) {
            val line = readLine() ?: break
            val body = line.removePrefix("DIFF ")
            val parts = body.split(" | ")
            val a = parts[0].split(" ").filter { it.isNotEmpty() }
            val b = parts[1].split(" ").filter { it.isNotEmpty() }
            val o = TextDiff.diff(a, b)
            println("${o.approximate} ${o.kept} ${o.removed} ${o.added} " + o.edits.joinToString(",") { "${it.kind}:${it.oldIndex}:${it.newIndex}" })
        }
    }
}
