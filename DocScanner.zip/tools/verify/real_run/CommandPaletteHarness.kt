import com.example.docscanner.util.CommandPalette
import com.example.docscanner.util.ToolPreset

/**
 * Harness for tools/verify/command_palette_real_run_check.py. stdin: the FIRST line is the query, every other line a name. Prints the ranked indices separated by spaces ("-" when none).
 * With the argument `fold`, every stdin line is folded and printed. With `preset <goals comma separated>` it prints the groups ToolPreset.groupsToOpen opens, comma separated, in order.
 */
fun main(args: Array<String>) {
    if (args.isNotEmpty() && args[0] == "preset") {
        println(ToolPreset.groupsToOpen(args.getOrElse(1) { "" }.split(",").filter { it.isNotEmpty() }.toSet()).joinToString(","))
        return
    }
    val lines = generateSequence(::readLine).toList()
    if (args.isNotEmpty() && args[0] == "fold") {
        for (l in lines) println(CommandPalette.fold(l))
        return
    }
    val ranked = CommandPalette.rank(lines.first(), lines.drop(1))
    println(if (ranked.isEmpty()) "-" else ranked.joinToString(" "))
}
