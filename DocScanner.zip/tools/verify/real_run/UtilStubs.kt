package com.example.docscanner.util

import android.content.Context
import android.net.Uri
import java.io.File

/** Test-only stand-ins for two helpers that need a phone (content resolver); the code under test only reaches them from mergeUris, which these runs never call. */
object FileUtils { fun copyUriToTempFile(context: Context, uri: Uri, suffix: String): File? = null }
object PdfImportHelper { fun displayName(context: Context, uri: Uri): String = "" }

/** Only the SHAPE that TextExporters.htmlFromChapters / markdownFromChapters need; the real EbookBuilder reads Android resources (R.string) and cannot be compiled off-device. */
object EbookBuilder {
    data class Chapter(val title: String, val paragraphs: List<String>)
}
