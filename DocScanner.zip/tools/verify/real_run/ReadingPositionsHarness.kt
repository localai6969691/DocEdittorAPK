import com.example.docscanner.util.PdfReadingPositions
import java.util.Base64

/**
 * Harness for tools/verify/reading_positions_real_run_check.py: runs the REAL util/PdfReadingPositions.kt. One command per stdin line, every text argument base64 (the stored text holds
 * tabs and newlines), every result one line:
 *   put <text> <key> <page>              -> base64 of the new text          putp <text> <key> <page> <zoom>   -> base64 of the new text
 *   get <text> <key>                     -> page or "-"                      getp <text> <key>                 -> "<page> <zoom>" or "-"
 *   dec <text>                           -> base64 of "page TAB key" lines (oldest first)       nz <zoom> -> normalised zoom      key <name> <length> -> base64 of the key
 */
private fun d(s: String) = String(Base64.getDecoder().decode(s), Charsets.UTF_8)
private fun e(s: String) = Base64.getEncoder().encodeToString(s.toByteArray(Charsets.UTF_8))

fun main() {
    while (true) {
        val t = (readLine() ?: break).split(" ")
        when (t[0]) {
            "put" -> println(e(PdfReadingPositions.put(d(t[1]), d(t[2]), t[3].toInt())))
            "putp" -> println(e(PdfReadingPositions.putPlace(d(t[1]), d(t[2]), t[3].toInt(), t[4].toFloat())))
            "get" -> println(PdfReadingPositions.get(d(t[1]), d(t[2]))?.toString() ?: "-")
            "getp" -> { val p = PdfReadingPositions.getPlace(d(t[1]), d(t[2])); println(if (p == null) "-" else "${p.page} ${p.zoom}") }
            "dec" -> println(e(PdfReadingPositions.decode(d(t[1])).entries.joinToString("") { "${it.value}\t${it.key}\n" }))
            "nz" -> println(PdfReadingPositions.normalizeZoom(t[1].toFloat()))
            "key" -> println(e(PdfReadingPositions.key(d(t[1]), t[2].toLong())))
            else -> println("?")
        }
    }
}
