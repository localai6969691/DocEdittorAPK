import com.example.docscanner.util.LinkCheck
import java.io.File

/**
 * Harness for tools/verify/link_check_check.py: the REAL util/LinkCheck.kt.
 *   scan <pdf>                 one line per link:  page <TAB> KIND <TAB> PROBLEM <TAB> target      (or NULL)
 *   probe <url> [local]        STATUS code        ("local" = allowLocal, for the test server only)
 *   (stdin) URI <text> | HOST <text> | CODE <n>
 */
fun main(args: Array<String>) {
    when (args.getOrNull(0)) {
        "scan" -> {
            val links = LinkCheck.scan(File(args[1]))
            if (links == null) println("NULL") else for (l in links) println("${l.page}\t${l.kind}\t${l.problem}\t${l.target}")
        }
        "probe" -> {
            val p = LinkCheck.probe(args[1], 1500, args.getOrNull(2) == "local")
            println("${p.status} ${p.code}")
        }
        else -> while (true) {
            val line = readLine() ?: break
            val rest = line.substringAfter(' ', "")
            when (line.substringBefore(' ')) {
                "URI" -> { val (k, p) = LinkCheck.classifyUri(rest); println("$k $p") }
                "HOST" -> println(if (LinkCheck.isPublicHost(if (rest == "~null~") null else rest)) 1 else 0)
                "CODE" -> println(LinkCheck.statusOfCode(rest.toInt()))
                else -> println("?")
            }
        }
    }
}
