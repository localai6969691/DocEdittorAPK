import com.example.docscanner.util.PptxWriter
import com.example.docscanner.util.QrEncoder
import com.example.docscanner.util.TiffWriter
import com.example.docscanner.util.XlsxWriter
import com.example.docscanner.util.ZipPack
import java.io.File
import java.util.Base64
import java.util.TimeZone

/**
 * Harness for tools/verify/formats_real_run_check.py: runs the REAL util/ZipPack.kt, TiffWriter.kt, QrEncoder.kt, XlsxWriter.kt and PptxWriter.kt. Text arguments are base64 (names, passwords),
 * the result is every line printed; a failure prints "ERR:<exception class>:<message>" as the LAST line.
 *   zip-write <out> <b64 password | -> <b64 name>|<path>...      zip-names <b64 name>...  -> b64 per line      zip-store <b64 name> / zip-pw <b64 pw> -> true|false
 *   zip-dos <millis> <tz id> -> "<time> <date>"      zip-pbkdf2 <b64 pw> <b64 salt> <iterations> <dkLen> -> hex
 *   tiff <out> <kind:w:h:dpi:path>...  (kind GRAY_DEFLATE | RGB_DEFLATE)      dpi-for <widthPx> <widthPoints>
 *   qr <LOW|MEDIUM|QUARTILE|HIGH> <minVersion> <boost 0|1> <b64 text> -> "<version> <size> <mask>" then `size` lines of 0/1, or "null"      wifi <b64 ssid> <b64 pw> <security> -> b64
 *   xlsx <out> <spec file>  (spec: `S<TAB>b64 name` starts a sheet, `R<TAB>b64 cell<TAB>b64 cell...` is a row)      xlsx-name <b64 name> <b64 taken,b64 taken...> -> b64      xlsx-num <b64 text> -> number | -      xlsx-col <index>
 *   pptx <out> <w>:<h>:<b64 alt>:<jpeg path>...      pptx-size <w> <h> -> "<cx> <cy>"      pptx-fit <w> <h> <cx> <cy> -> "<x> <y> <cx> <cy>"
 */
private fun d(s: String) = String(Base64.getDecoder().decode(s), Charsets.UTF_8)
private fun e(s: String) = Base64.getEncoder().encodeToString(s.toByteArray(Charsets.UTF_8))

fun main(args: Array<String>) {
    try {
        when (args[0]) {
            "zip-write" -> {
                val names = ArrayList<String>(); val files = ArrayList<File>()
                for (i in 3 until args.size) { val p = args[i].split("|"); names.add(d(p[0])); files.add(File(p[1])) }
                ZipPack.write(files, names, File(args[1]), if (args[2] == "-") null else d(args[2])); println("done")
            }
            "zip-names" -> for (n in ZipPack.entryNames(args.drop(1).map { d(it) })) println(e(n))
            "zip-store" -> println(ZipPack.shouldStore(d(args[1])))
            "zip-pw" -> println(ZipPack.passwordAcceptable(d(args[1])))
            "zip-dos" -> { val (t, dt) = ZipPack.dosDateTime(args[1].toLong(), TimeZone.getTimeZone(args[2])); println("$t $dt") }
            "zip-pbkdf2" -> println(ZipPack.pbkdf2HmacSha1(d(args[1]).toByteArray(Charsets.UTF_8), Base64.getDecoder().decode(args[2]), args[3].toInt(), args[4].toInt()).joinToString("") { "%02x".format(it) })
            "tiff" -> {
                TiffWriter.Writer(File(args[1])).use { w ->
                    for (i in 2 until args.size) { val p = args[i].split(":", limit = 5); w.add(TiffWriter.Page(p[1].toInt(), p[2].toInt(), TiffWriter.Kind.valueOf(p[0]), File(p[4]).readBytes(), p[3].toInt())) }
                }
                println("done")
            }
            "dpi-for" -> println(TiffWriter.dpiFor(args[1].toInt(), args[2].toFloat()))
            "qr" -> {
                val q = QrEncoder.encode(d(args[4]), QrEncoder.Ecl.valueOf(args[1]), args[2].toInt(), args[3] == "1")
                if (q == null) println("null") else {
                    println("${q.version} ${q.size} ${q.mask}")
                    for (y in 0 until q.size) println((0 until q.size).joinToString("") { x -> if (q.get(x, y)) "1" else "0" })
                }
            }
            "wifi" -> println(e(QrEncoder.wifiPayload(d(args[1]), d(args[2]), args[3])))
            "xlsx" -> {
                val sheets = ArrayList<XlsxWriter.Sheet>(); var name: String? = null; var rows = ArrayList<List<String>>()
                for (line in File(args[2]).readLines()) {
                    val t = line.split("\t")
                    if (t[0] == "S") { if (name != null) sheets.add(XlsxWriter.Sheet(name, rows)); name = d(t[1]); rows = ArrayList() }
                    else if (t[0] == "R") rows.add(t.drop(1).map { d(it) })
                }
                if (name != null) sheets.add(XlsxWriter.Sheet(name, rows))
                XlsxWriter.write(sheets, File(args[1])); println("done")
            }
            "xlsx-name" -> println(e(XlsxWriter.safeSheetName(d(args[1]), args[2].split(",").filter { it.isNotEmpty() }.map { d(it) }.toSet())))
            "xlsx-num" -> println(XlsxWriter.asNumber(d(args[1]))?.toString() ?: "-")
            "xlsx-col" -> println(XlsxWriter.columnName(args[1].toInt()))
            "pptx" -> {
                val slides = args.drop(2).map { val p = it.split(":", limit = 4); PptxWriter.Slide(File(p[3]).readBytes(), p[0].toInt(), p[1].toInt(), d(p[2])) }
                PptxWriter.write(slides, File(args[1])); println("done")
            }
            "pptx-size" -> { val (cx, cy) = PptxWriter.slideSize(args[1].toInt(), args[2].toInt()); println("$cx $cy") }
            "pptx-fit" -> println(PptxWriter.fit(args[1].toInt(), args[2].toInt(), args[3].toLong(), args[4].toLong()).joinToString(" "))
            else -> println("ERR:usage:" + args[0])
        }
    } catch (t: Throwable) {
        println("ERR:" + t.javaClass.simpleName + ":" + (t.message ?: ""))
    }
}
