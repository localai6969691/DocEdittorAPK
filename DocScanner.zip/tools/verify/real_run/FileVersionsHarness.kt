import com.example.docscanner.util.FileVersions
import java.io.File

/**
 * Harness for tools/verify/file_versions_real_run_check.py: runs the REAL util/FileVersions.kt against real files. Arguments are all plain strings (the root is a temp folder).
 *   snap <root> <name> <source> <now> <limit>          prints the id of the new version, or NULL
 *   list <root> <name>                                  one line per version, newest first: id|time|size|pinned|chunked
 *   pin <root> <name> <id> <0|1>   |   del <root> <name> <id>          true / false
 *   commit <root> <name> <incoming> <target> <now> <limit>               true / false
 *   restore <root> <name> <id> <target> <now> <limit>                    true / false
 *   replace <root> <name> <replacement> <target> <now> <limit>           true / false (the replacement is copied, it stays)
 *   rename <root> <old> <new>      |   purge <root> <now> <graceMs> <existing names, comma separated, "-" for none>     the number of folders removed
 *   excess <root> <limit>          |   pruneall <root> <limit>           the number of versions a lower limit would delete / deleted
 *   total <root>                   |   clear <root>   |   delall <root> <name>
 *   cuts <file>                    the lengths of the pieces FileVersions cuts the file into, space separated
 */
fun main(args: Array<String>) {
    if (args[0] == "cuts") {
        println(FileVersions.chunkLengths(File(args[1]).readBytes()).joinToString(" "))
        return
    }
    val root = File(args[1])
    when (args[0]) {
        "snap" -> println(FileVersions.snapshot(root, args[2], File(args[3]), args[4].toLong(), args[5].toInt())?.id ?: "NULL")
        "list" -> for (v in FileVersions.list(root, args[2])) println(v.id.toString() + "|" + v.time + "|" + v.size + "|" + v.pinned + "|" + v.chunked)
        "pin" -> println(FileVersions.setPinned(root, args[2], args[3].toLong(), args[4] == "1"))
        "del" -> println(FileVersions.delete(root, args[2], args[3].toLong()))
        "commit" -> println(FileVersions.commit(root, args[2], File(args[3]), File(args[4]), args[5].toLong(), args[6].toInt()))
        "restore" -> println(FileVersions.restore(root, args[2], args[3].toLong(), File(args[4]), args[5].toLong(), args[6].toInt()))
        "replace" -> println(FileVersions.replaceWith(root, args[2], File(args[3]), File(args[4]), args[5].toLong(), args[6].toInt()))
        "rename" -> println(FileVersions.rename(root, args[2], args[3]))
        "purge" -> println(FileVersions.purgeOrphans(root, if (args[4] == "-") emptySet() else args[4].split(",").toSet(), args[2].toLong(), args[3].toLong()))
        "excess" -> println(FileVersions.excessCount(root, args[2].toInt()))
        "pruneall" -> println(FileVersions.pruneAll(root, args[2].toInt()))
        "total" -> println(FileVersions.totalSize(root))
        "clear" -> {
            FileVersions.clearAll(root)
            println("cleared")
        }
        "delall" -> {
            FileVersions.deleteAll(root, args[2])
            println("deleted")
        }
    }
}
