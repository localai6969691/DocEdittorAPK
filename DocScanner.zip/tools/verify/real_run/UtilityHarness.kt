import com.example.docscanner.util.PdfAutoLinks
import com.example.docscanner.util.PdfImposer
import com.example.docscanner.util.PdfLinearizer
import com.example.docscanner.util.PdfMetadataTools
import com.example.docscanner.util.PdfPoster
import java.io.File

/**
 * Harness for tools/verify/utility_real_run_check.py: runs the REAL util/PdfMetadataTools.kt, PdfImposer.kt, PdfPoster.kt, PdfLinearizer.kt (+ Linearizer.kt) and PdfAutoLinks.kt
 * (compiled by kotlinc, on a PdfBox-Android built from its source). One command per call, the result is the LAST line of stdout; a failure prints "ERR:<exception class>:<message>".
 *   meta-read <src>                                  -> title \u241F author \u241F subject \u241F keywords
 *   meta-write <src> <out> <title> <author> <subject> <keywords>   (an empty argument is written as "-")
 *   meta-strip <src> <out>
 *   impose <src> <out> <TWO_UP|FOUR_UP|BOOKLET>      -> number of sheets
 *   poster <src> <out> <pageIndex> <cols>            -> number of sheets
 *   linearize <src> <out>                            -> number of pages
 *   islin <file>                                     -> true / false
 *   autolinks <src> <out>                            -> "<added> <skippedPages>"
 *   classify <word>                                  -> "<start> <end> <uri>" or "-"
 */
fun main(args: Array<String>) {
    try {
        when (args[0]) {
            "meta-read" -> {
                val i = PdfMetadataTools.read(File(args[1]))
                println(listOf(i.title, i.author, i.subject, i.keywords).joinToString("\u241F"))
            }
            "meta-write" -> {
                fun a(i: Int) = if (args[i] == "-") "" else args[i]
                PdfMetadataTools.write(File(args[1]), File(args[2]), PdfMetadataTools.Info(a(3), a(4), a(5), a(6)))
                println("done")
            }
            "meta-strip" -> { PdfMetadataTools.strip(File(args[1]), File(args[2])); println("done") }
            "impose" -> println(PdfImposer.impose(File(args[1]), File(args[2]), PdfImposer.Mode.valueOf(args[3])))
            "poster" -> println(PdfPoster.poster(File(args[1]), File(args[2]), args[3].toInt(), args[4].toInt()))
            "linearize" -> println(PdfLinearizer.linearize(File(args[1]), File(args[2])))
            "islin" -> println(PdfLinearizer.isLinearized(File(args[1])))
            "autolinks" -> { val r = PdfAutoLinks.addLinks(File(args[1]), File(args[2])); println("${r.added} ${r.skippedPages}") }
            "classify" -> { val t = PdfAutoLinks.classify(args[1]); println(if (t == null) "-" else "${t.start} ${t.end} ${t.uri}") }
            else -> println("ERR:usage:" + args[0])
        }
    } catch (t: Throwable) {
        println("ERR:" + t.javaClass.simpleName + ":" + (t.message ?: ""))
    }
}
