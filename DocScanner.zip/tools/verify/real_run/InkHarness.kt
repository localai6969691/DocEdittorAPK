import com.example.docscanner.util.PdfInk
import java.io.File

/**
 * Harness for tools/verify/ink_real_run_check.py: runs the REAL util/PdfInk.kt.
 *   annotate <src> <out> <spec>   spec = strokes separated by '|', each: page;marker(0|1);#RRGGBB;width;x,y x,y x,y ...   (x, y = 0..1 from the top-left of the DISPLAYED page)
 * Prints the number of annotations written, or "ERR <message>".
 */
fun main(args: Array<String>) {
    val src = File(args[1])
    val out = File(args[2])
    val byPage = HashMap<Int, MutableList<PdfInk.Stroke>>()
    for (spec in args[3].split("|")) {
        val f = spec.split(";")
        val points = f[4].trim().split(" ").flatMap { it.split(",") }.map { it.toFloat() }.toFloatArray()
        val rgb = f[2].removePrefix("#").toInt(16)
        byPage.getOrPut(f[0].toInt()) { ArrayList() }.add(PdfInk.Stroke(points, 0xFF000000.toInt() or rgb, f[3].toFloat(), f[1] == "1"))
    }
    try {
        println(PdfInk.annotate(src, out, byPage))
    } catch (e: Exception) {
        println("ERR " + e.message)
    }
}
