package com.example.docscanner.util

import android.graphics.Bitmap
import java.io.File
import javax.imageio.ImageIO

/**
 * Test double for util/PdfPageBitmap.kt (tools/verify/redactor_real_run_check.py): the platform PdfRenderer does not exist on a JVM, so a page is drawn by poppler (`pdftoppm -cropbox`: the page AS
 * DISPLAYED, rotation and CropBox applied - the same promise PdfRenderer makes) and loaded into the shim Bitmap. Same public API as the real object.
 */
object PdfPageBitmap {
    class Session private constructor(private val file: File) : AutoCloseable {
        val pageCount: Int get() = Regex("Pages:\\s+(\\d+)").find(run("pdfinfo", file.path))?.groupValues?.get(1)?.toInt() ?: 0

        private fun run(vararg cmd: String): String = ProcessBuilder(*cmd).redirectErrorStream(true).start().let { p -> val t = p.inputStream.bufferedReader().readText(); p.waitFor(); t }

        private fun png(index: Int, dpi: Double): java.awt.image.BufferedImage {
            val tmp = File.createTempFile("pb-", "")
            try {
                ProcessBuilder("pdftoppm", "-cropbox", "-png", "-r", dpi.toString(), "-f", (index + 1).toString(), "-l", (index + 1).toString(), "-singlefile", file.path, tmp.path).redirectErrorStream(true).start().waitFor()
                return ImageIO.read(File(tmp.path + ".png"))
            } finally { File(tmp.path + ".png").delete(); tmp.delete() }
        }

        fun render(index: Int, targetWidth: Int): Bitmap? {
            if (index !in 0 until pageCount) return null
            val base = png(index, 72.0)                                   // 1 pixel = 1 point: the displayed size in points
            val w = targetWidth.coerceAtLeast(1)
            val h = (base.height.toFloat() * w / base.width).toInt().coerceIn(1, 6000)
            val big = png(index, 72.0 * w / base.width)
            val scaled = java.awt.image.BufferedImage(w, h, java.awt.image.BufferedImage.TYPE_INT_ARGB)
            val g = scaled.createGraphics()
            g.setRenderingHint(java.awt.RenderingHints.KEY_INTERPOLATION, java.awt.RenderingHints.VALUE_INTERPOLATION_BILINEAR)
            g.drawImage(big, 0, 0, w, h, null); g.dispose()
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val row = IntArray(w)
            for (y in 0 until h) { scaled.getRGB(0, y, w, 1, row, 0, w); bmp.setPixels(row, 0, w, 0, y, w, 1) }
            return bmp
        }

        fun pageWidthPoints(index: Int): Float = if (index !in 0 until pageCount) 0f else png(index, 72.0).width.toFloat()

        override fun close() { }

        companion object { fun open(file: File): Session? = Session(file).takeIf { it.pageCount > 0 } }
    }

    fun open(file: File): Session? = Session.open(file)
    fun renderFirstPage(file: File, targetWidth: Int = 1400): Bitmap? = open(file)?.use { it.render(0, targetWidth) }
}
