import com.example.docscanner.util.PdfFormFiller
import com.example.docscanner.util.PdfTextEditor
import java.io.File

/**
 * Harness for tools/verify/text_edit_real_run_check.py: runs the REAL util/PdfTextEditor.kt (position tracking, picking, trial, applyAll).
 *   chunks <pdf> <page>                       one line per piece: index|x0 y0 x1 y1 (fractions of the DISPLAYED page, top-left origin)|text
 *   pick <pdf> <page> <x> <y>                 index of the piece under the point, or -1
 *   trial <pdf> <page> <index> <text>         Success | MissingGlyphs:<chars> | ScaleOutOfRange | UnsupportedFont | ChunkNotFound
 *   apply <src> <out> <page>:<index>:<text>|...   writes the copy, prints OK or "ERR <message>"
 *   fields <pdf> <page>                       one line per form field widget on the page: name|kind|value|x0 y0 x1 y1 (fractions of the DISPLAYED page)
 *   pickfield <pdf> <page> <x> <y>            name of the field under the point, or -
 *   fill <src> <out> <name>=<value>|...       fills the fields into a copy, prints the number changed or "ERR <message>"
 */
fun main(args: Array<String>) {
    when (args[0]) {
        "chunks" -> for (c in PdfTextEditor.placedChunks(File(args[1]), args[2].toInt())) {
            println(c.chunk.index.toString() + "|" + c.box.joinToString(" ") { "%.4f".format(java.util.Locale.ROOT, it) } + "|" + c.chunk.text)
        }
        "pick" -> {
            val placed = PdfTextEditor.placedChunks(File(args[1]), args[2].toInt())
            println(PdfTextEditor.pick(placed, args[3].toFloat(), args[4].toFloat())?.chunk?.index ?: -1)
        }
        "trial" -> {
            val r = PdfTextEditor.trial(File(args[1]), args[2].toInt(), args[3].toInt(), args[4])
            println(
                when (r) {
                    is PdfTextEditor.EditResult.Success -> "Success"
                    is PdfTextEditor.EditResult.MissingGlyphs -> "MissingGlyphs:" + r.chars
                    is PdfTextEditor.EditResult.ScaleOutOfRange -> "ScaleOutOfRange"
                    is PdfTextEditor.EditResult.UnsupportedFont -> "UnsupportedFont"
                    is PdfTextEditor.EditResult.ChunkNotFound -> "ChunkNotFound"
                }
            )
        }
        "fields" -> for (f in PdfFormFiller.placedFields(File(args[1]), args[2].toInt())) {
            println(f.field.name + "|" + f.field.kind + "|" + f.field.value + "|" + f.box.joinToString(" ") { "%.4f".format(java.util.Locale.ROOT, it) })
        }
        "pickfield" -> {
            val placed = PdfFormFiller.placedFields(File(args[1]), args[2].toInt())
            println(PdfFormFiller.pickField(placed, args[3].toFloat(), args[4].toFloat())?.field?.name ?: "-")
        }
        "fill" -> {
            val values = args[3].split("|").associate { val i = it.indexOf('='); it.substring(0, i) to it.substring(i + 1) }
            try {
                println(PdfFormFiller.fill(File(args[1]), File(args[2]), values))
            } catch (e: Exception) {
                println("ERR " + e.message)
            }
        }
        "apply" -> {
            val edits = args[3].split("|").map {
                val f = it.split(":", limit = 3)
                PdfTextEditor.Replacement(f[0].toInt(), f[1].toInt(), f[2])
            }
            try {
                PdfTextEditor.applyAll(File(args[1]), File(args[2]), edits)
                println("OK")
            } catch (e: Exception) {
                println("ERR " + e.message)
            }
        }
    }
}
