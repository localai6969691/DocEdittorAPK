"""Văn bản mẫu cho doc_insight_check.py (phiên 20, 4.48.3). VIẾT TAY theo khuôn của tài liệu thật (hoá đơn GTGT, phiếu thu, hợp đồng thuê nhà, CCCD, sao kê, bằng tốt nghiệp,
CV, công văn, đơn xin...), KHÔNG lấy từ bảng cụm từ của DocInsight: bài kiểm chỉ có ý nghĩa nếu đáp án không do chính bảng đó sinh ra. Không phải mã của ứng dụng."""

DOCS = {
"INVOICE": [
"CÔNG TY TNHH THƯƠNG MẠI ABC\nMã số thuế: 0312345678\nĐịa chỉ: 12 Nguyễn Huệ, Quận 1, TP. Hồ Chí Minh\nHÓA ĐƠN GIÁ TRỊ GIA TĂNG\nKý hiệu: 1C24TAA  Số: 0000123\nNgày 05 tháng 03 năm 2024\nHọ tên người mua hàng: Nguyễn Văn An\nTên đơn vị: Công ty Cổ phần Xây dựng Việt\nSTT Tên hàng hóa, dịch vụ Đơn vị tính Số lượng Đơn giá Thành tiền\n1 Giấy A4 Double A Ram 50 120.000 6.000.000\nCộng tiền hàng: 6.000.000\nThuế suất GTGT: 10%  Tiền thuế GTGT: 600.000\nTổng cộng tiền thanh toán: 6.600.000",
"INVOICE\nInvoice No: INV-2024-0457\nDate: 14 March 2024\nBill To: Northwind Traders, 55 Queen Street\nDescription Qty Unit Price Amount\nConsulting services 10 150.00 1,500.00\nSubtotal 1,500.00\nVAT 10% 150.00\nTotal due 1,650.00\nPayment terms: 30 days. Please quote the invoice number when paying.",
"HOA DON GTGT\nKy hieu: 2C24MAA So: 00045\nDon vi ban hang: CTY TNHH DICH VU XYZ MST: 0101234567\nNguoi mua hang: Tran Thi B\nTen hang Don vi tinh So luong Don gia Thanh tien\nDich vu van chuyen chuyen 2 1.500.000 3.000.000\nThue suat 8% Tien thue 240.000\nTong cong tien thanh toan 3.240.000",
"TAX INVOICE\nSupplier: Blue Harbour Pty Ltd  ABN 12 345 678 901\nInvoice number 20418\nCustomer: Hill Street Cafe\nItem Quantity Unit price Total\nCoffee beans 5kg 2 28.00 56.00\nGST 10% 5.60\nTotal 61.60",
],
"RECEIPT": [
"CÔNG TY CỔ PHẦN GIÁO DỤC ABC\nPHIẾU THU\nNgày 12 tháng 04 năm 2024  Số: PT0045\nHọ tên người nộp tiền: Lê Thị Hoa\nĐịa chỉ: 45 Lý Thường Kiệt, Hà Nội\nLý do nộp: Học phí tháng 4\nSố tiền: 2.500.000 đồng\nĐã nhận đủ số tiền (viết bằng chữ): hai triệu năm trăm nghìn đồng\nNgười lập phiếu    Thủ quỹ",
"SUPERMARKET FRESH\nRECEIPT\nCashier: Linh\nMilk 1L 25,000\nBread 15,000\nTotal 40,000\nCash 50,000\nChange due 10,000\nThank you for shopping with us!",
"SIEU THI MINI MART\nBIEN LAI THANH TOAN\nThu ngan: Hung\nSua tuoi 2 x 18.000 36.000\nTong cong 36.000\nTien khach dua 50.000\nTien thua 14.000\nCam on quy khach va hen gap lai",
"Payment received\nReceipt #2231\nReceived from John Smith the amount of $450.00 for rent for May.\nPayment received by bank transfer on 3 May 2024.\nThank you.",
],
"CONTRACT": [
"CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM\nĐộc lập - Tự do - Hạnh phúc\nHỢP ĐỒNG THUÊ NHÀ\nHôm nay, ngày 01/06/2024, chúng tôi gồm:\nBên cho thuê (Bên A): Ông Phạm Văn Long\nBên thuê (Bên B): Bà Nguyễn Thị Mai\nHai bên cùng thỏa thuận ký hợp đồng với các điều khoản sau:\nĐiều 1. Bên A cho Bên B thuê căn hộ số 12.\nĐiều 2. Giá thuê 8.000.000 đồng/tháng. Tiền đặt cọc 16.000.000 đồng.\nĐiều 3. Hợp đồng có hiệu lực từ ngày 01/06/2024.",
"SERVICES AGREEMENT\nThis Agreement is made between Alpha Ltd (Party A) and Beta Inc (Party B).\n1. Scope. Party B shall provide the services described in Schedule 1.\n2. Term. This Agreement takes effect on 1 July 2024 and may be terminated by either party with 30 days notice.\nIN WITNESS WHEREOF the parties have signed this Agreement.",
"HOP DONG LAO DONG\nBen A: Cong ty TNHH Sao Mai\nBen B: Ong Do Minh Tuan\nDieu 1: Cong viec va dia diem lam viec\nDieu 2: Thoi han hop dong 12 thang\nCac ben thoa thuan giai quyet tranh chap bang thuong luong.",
"RESIDENTIAL LEASE\nThe Landlord leases to the Tenant the premises at 9 Oak Road. The Tenant shall pay a security deposit of $1,200. The parties agree that this lease is governed by local law. Hereby signed.",
],
"ID_DOCUMENT": [
"CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM\nSOCIALIST REPUBLIC OF VIET NAM\nCăn cước công dân / Citizen Identity Card\nSố / No.: 079123456789\nHọ và tên / Full name: NGUYỄN VĂN AN\nNgày sinh / Date of birth: 12/05/1990\nGiới tính / Sex: Nam  Quốc tịch / Nationality: Việt Nam\nQuê quán / Place of origin: Nam Định\nNơi thường trú / Place of residence: Quận 3, TP. Hồ Chí Minh\nCó giá trị đến / Date of expiry: 12/05/2030",
"CHỨNG MINH NHÂN DÂN\nSố: 024567891\nHọ tên: TRẦN THỊ B\nSinh ngày: 03-02-1985\nNguyên quán: Hải Dương\nDân tộc: Kinh  Tôn giáo: Không\nNơi ĐKHK thường trú: Hà Nội",
"PASSPORT\nHỘ CHIẾU\nType P  Country code VNM\nSurname NGUYEN  Given names VAN AN\nNationality VIETNAMESE\nDate of birth 12 MAY 1990  Sex M\nDate of expiry 11 JUN 2032\nPassport No. C1234567",
"GIẤY PHÉP LÁI XE\nDRIVER LICENSE\nSố/No: 790123456789\nHọ tên/Name: LÊ VĂN CƯỜNG\nNgày sinh/Date of birth: 05/09/1988\nHạng/Class: B2   Có giá trị đến: 05/09/2028",
],
"BANK_STATEMENT": [
"NGÂN HÀNG TMCP ABC - CHI NHÁNH SÀI GÒN\nSAO KÊ TÀI KHOẢN\nSố tài khoản: 0123456789  Chủ tài khoản: NGUYEN VAN AN\nTừ ngày 01/03/2024 đến ngày 31/03/2024\nSố dư đầu kỳ: 12.500.000\nNgày GD  Diễn giải  Ghi nợ  Ghi có  Số dư\n03/03 Chuyển khoản tiền nhà 5.000.000 7.500.000\n15/03 Lương tháng 3 20.000.000 27.500.000\nSố dư cuối kỳ: 27.500.000",
"BANK STATEMENT\nAccount number: 4455 6677\nStatement period: 1 Mar 2024 - 31 Mar 2024\nOpening balance 1,240.50\nDate Description Debit Credit Balance\n05 Mar Grocery store 62.10 1,178.40\n12 Mar Salary 2,100.00 3,278.40\nClosing balance 3,278.40",
"SAO KE\nSo tai khoan 9704 1234\nSo du dau ky 3.000.000\nNoi dung giao dich: Thanh toan hoa don dien\nGhi no 450.000\nSo du cuoi ky 2.550.000",
"Account statement\nAccount number: 0099 8877\nOpening balance: 500.00\nTransaction: ATM withdrawal 100.00 debit\nTransaction: deposit 250.00 credit\nClosing balance: 650.00",
],
"CERTIFICATE": [
"BỘ GIÁO DỤC VÀ ĐÀO TẠO\nTRƯỜNG ĐẠI HỌC BÁCH KHOA\nBẰNG TỐT NGHIỆP ĐẠI HỌC\nHiệu trưởng Trường Đại học Bách khoa cấp bằng kỹ sư cho: Nguyễn Văn An\nNgành: Công nghệ thông tin  Xếp loại: Giỏi\nSố hiệu: 123456  Số vào sổ: 789/2020",
"GIẤY KHAI SINH\nHọ, chữ đệm, tên: NGUYỄN MINH KHOA\nNgày, tháng, năm sinh: 02/09/2019\nNơi sinh: Bệnh viện Từ Dũ\nHọ tên cha: Nguyễn Văn An  Họ tên mẹ: Trần Thị B\nĐăng ký ngày 10/09/2019",
"CERTIFICATE OF COMPLETION\nThis is to certify that Jane Doe has successfully completed the course Introduction to Data Analysis. Awarded on 15 June 2023.",
"GIẤY CHỨNG NHẬN\nCông ty TNHH ABC chứng nhận anh Lê Văn C đã hoàn thành khóa đào tạo an toàn lao động.\nCấp ngày 20/08/2022 - Số hiệu: ATLD-0098",
],
"RESUME": [
"Nguyen Van An\nSoftware Engineer\nEmail: an.nguyen@example.com  LinkedIn: linkedin.com/in/an\nProfessional Summary\nBackend developer with 6 years of experience.\nWork Experience\n2019-2024 Senior Developer, ABC Corp\nEducation\nBSc Computer Science, HUST 2018\nSkills\nJava, Kotlin, SQL",
"SƠ YẾU LÝ LỊCH / CV\nMục tiêu nghề nghiệp: Trở thành chuyên viên kế toán.\nKinh nghiệm làm việc\n2020 - 2024: Kế toán tổng hợp, Công ty ABC\nHọc vấn\nCử nhân Kế toán - Đại học Kinh tế\nKỹ năng: Excel, MISA\nSở thích: Đọc sách, du lịch\nNgười tham chiếu: Cô Lan, 0901234567",
"RESUME\nCareer Objective: To obtain a marketing position.\nWork Experience\nMarketing Assistant, XYZ Ltd, 2021-2023\nSkills: SEO, copywriting\nReferences available on request.",
"Curriculum Vitae\nPersonal details\nName: Maria Lopez\nEmployment history\nTeacher, Lincoln School 2015-2020\nEducation\nMA Education, 2014\nSkills: languages, planning",
],
"OFFICIAL_LETTER": [
"UBND QUẬN 1\nSỞ GIÁO DỤC VÀ ĐÀO TẠO\nSố: 245/CV-SGD\nV/v báo cáo kết quả thực hiện\nCỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM\nĐộc lập - Tự do - Hạnh phúc\nKính gửi: Các trường tiểu học trên địa bàn\nCăn cứ Kế hoạch số 12/KH-UBND, Sở đề nghị các đơn vị báo cáo.\nNơi nhận:\n- Như trên;\n- Lưu: VT.",
"ỦY BAN NHÂN DÂN THÀNH PHỐ\nQUYẾT ĐỊNH\nVề việc bổ nhiệm cán bộ\nCăn cứ Luật Tổ chức chính quyền địa phương;\nQUYẾT ĐỊNH:\nĐiều 1. Bổ nhiệm ông Trần Văn D giữ chức vụ Trưởng phòng.\nNơi nhận: - Như Điều 3; - Lưu VT.",
"Dear Sir or Madam,\nTo whom it may concern: I am writing to confirm that Mr. Smith has been employed by our company since 2019.\nYours faithfully,\nHuman Resources Department",
"MEMORANDUM\nTo: All staff\nFrom: Office of the Director\nSubject: Holiday schedule\nPlease note the office will be closed on 2 September. Sincerely, Admin Office",
],
"FORM": [
"CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM\nĐộc lập - Tự do - Hạnh phúc\nĐƠN XIN XÁC NHẬN TẠM TRÚ\nKính gửi: Công an phường 5\nTôi tên là: Nguyễn Văn An  Ngày tháng năm sinh: 12/05/1990\nTôi xin cam đoan những thông tin trên là đúng sự thật.\nNgười làm đơn (ký, ghi rõ họ tên)",
"TỜ KHAI ĐĂNG KÝ KHAI SINH\nMẫu số 01\nHọ và tên người đi đăng ký: ..........\nTôi cam đoan nội dung khai trên đây là đúng sự thật.",
"APPLICATION FORM\nFull name: ______\nDate of birth: ______\nPosition applied for: ______\nI declare that the information given is true.",
"REGISTRATION FORM\nFull name\nPhone number\nCourse\nPlease complete all fields. The registration form must be returned by Friday.",
"PHIẾU ĐĂNG KÝ DỰ THI\nHọ và tên thí sinh: ..........\nĐăng ký môn thi: ..........\nBiểu mẫu số 3",
],
}

NEGATIVES = [
"Pho bo recipe: simmer the beef bones for six hours with charred onion and ginger. Add star anise, cinnamon and cloves. Serve the noodles in a bowl with sliced beef, herbs and lime.",
"The city council voted on Tuesday to extend the bus lines to the northern suburbs. Residents welcomed the decision, saying commuting times would fall by half. The project will begin next spring.",
"Hôm qua tôi đi chợ mua rau và cá. Trời nắng đẹp, mọi người đều vui vẻ. Chiều về tôi nấu cơm cho cả nhà và xem phim.",
"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.",
"def main():\n    print('hello world')\n    for i in range(10):\n        total += i\n    return total",
"ok see you at 7 then, don't forget the keys, bring the charger too lol",
]

# Câu cho bài kiểm tóm tắt: ba chủ đề + vài câu lẻ (từ hiếm, để có nút bị cô lập trong đồ thị)
POOL = [
# kinh tế gia đình
"Chi phí thuê nhà là khoản chi lớn nhất trong ngân sách hàng tháng của nhiều gia đình ở thành phố.",
"Nhiều gia đình chọn lập ngân sách hàng tháng để theo dõi chi phí thuê nhà, điện nước và ăn uống.",
"Khoản tiết kiệm đều đặn mỗi tháng giúp gia đình có quỹ dự phòng khi chi phí phát sinh bất ngờ.",
"Các chuyên gia khuyên nên dành ít nhất mười phần trăm thu nhập hàng tháng cho quỹ dự phòng của gia đình.",
"Chi phí điện nước tăng vào mùa hè khiến ngân sách hàng tháng của gia đình bị vượt dự kiến.",
"Việc ghi chép chi tiêu hàng ngày giúp gia đình nhận ra những khoản chi phí không cần thiết.",
"Một ngân sách rõ ràng giúp gia đình thương lượng giá thuê nhà tốt hơn với chủ nhà.",
# scanning
"A document scanner turns a printed page into a digital image that the phone can store and share.",
"Good lighting and a flat surface help the scanner detect the edges of the page and straighten the image.",
"Optical character recognition reads the scanned page and turns the image into text that can be searched.",
"The recognized text of a scanned page lets the user search every document by its content.",
"Scanned pages are usually combined into a single PDF so that the whole document can be shared at once.",
"A higher scan resolution makes the recognized text more accurate but also makes the PDF file larger.",
"Compression reduces the size of a scanned PDF so that the document can be sent by email.",
"Many scanner apps let the user crop the page and remove shadows before the document is saved.",
# du lịch
"Mùa mưa ở miền Trung thường kéo dài từ tháng chín đến tháng mười hai, nên du khách cần chuẩn bị áo mưa.",
"Phố cổ Hội An thu hút nhiều du khách vì những ngôi nhà cổ và đèn lồng rực rỡ vào buổi tối.",
"Du khách nên đặt phòng khách sạn sớm vì Hội An rất đông vào dịp lễ hội đèn lồng.",
"Ẩm thực miền Trung nổi tiếng với món mì Quảng, cao lầu và bánh mì được du khách yêu thích.",
# câu lẻ (ít từ chung)
"Chiếc đồng hồ cổ của ông tôi vẫn gõ nhịp đều đặn trong căn phòng yên tĩnh.",
"The astronomer photographed a distant nebula using a borrowed telescope last winter.",
"Những chú chim sẻ nhỏ làm tổ dưới mái hiên mỗi độ xuân về.",
]
