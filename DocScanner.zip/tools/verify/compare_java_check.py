"""Kiểm chứng bản Java của thuật toán so sánh (phiên 15): CompareCheck.java phải cho cùng kết quả với mô hình numpy compare_align_model.py.

Java CHẠY ĐƯỢC trên JVM thật và là bản song song từng bước của PdfComparer.kt (như CmsCheck.java với chữ ký số). Ở đây cho cùng các cặp ảnh qua cả hai bản và so:
  - hộp khác nhau: cùng số hộp, mỗi hộp của numpy có một hộp Java trùng gần như hoàn toàn (IoU >= 0.9);
  - dịch chuyển toàn trang ước lượng: giống hệt;
  - ghép trang: danh sách cặp giống hệt (kể cả khi chèn/xoá/sửa trang và cả tài liệu bị dịch+xoay).
Chạy: python3 compare_java_check.py   (cần numpy, pillow, opencv-python, java 11+)
"""
import os, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import numpy as np
import compare_align_model as M
from compare_check import text_page, warp

HERE = os.path.dirname(os.path.abspath(__file__))


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    return cond


def write_raw(path, arr):
    open(path, "wb").write(arr.astype(np.uint8).tobytes())


def java(*args):
    r = subprocess.run(["java", os.path.join(HERE, "CompareCheck.java"), *map(str, args)], capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout, r.stderr); raise SystemExit("java thất bại")
    return r.stdout.splitlines()


def iou(a, b):
    ax0, ay0, ax1, ay1 = a[0], a[1], a[0] + a[2], a[1] + a[3]
    bx0, by0, bx1, by1 = b[0], b[1], b[0] + b[2], b[1] + b[3]
    iw, ih = max(0, min(ax1, bx1) - max(ax0, bx0)), max(0, min(ay1, by1) - max(ay0, by0))
    inter = iw * ih
    return inter / float(a[2] * a[3] + b[2] * b[3] - inter)


def main():
    good = True
    with tempfile.TemporaryDirectory(dir=OUT) as wd:
        a = text_page(1)
        h, w = a.shape
        cases = {
            "giống hệt": a.copy(),
            "dịch (18,12)": warp(a, dx=18, dy=12),
            "dịch (-17,15)": warp(a, dx=-17, dy=15),
            "xoay 0,3°": warp(a, rot=0.3),
            "xoay 0,5° + co 1,01": warp(a, rot=0.5, sc=1.01),
            "co 1,02": warp(a, sc=1.02),
            "xoay 1°": warp(a, rot=1.0),
            "xoay 2°": warp(a, rot=2.0),
            "xoay 3°": warp(a, rot=3.0),
            "co 3%": warp(a, sc=1.03),
            "xoay 1,5° + co 2% + dịch": warp(a, rot=1.5, sc=1.02, dx=10, dy=-8),
            "đổi số tiền + xoay 2°": warp(text_page(1, total="7,250,000"), rot=2.0),
            "đổi số tiền 1→7": text_page(1, total="7,250,000"),
            "đổi số tiền + dịch": warp(text_page(1, total="7,250,000"), dx=18, dy=12),
            "trang khác hẳn": text_page(2),
        }
        write_raw(os.path.join(wd, "a.raw"), a)
        for name, b in cases.items():
            write_raw(os.path.join(wd, "b.raw"), b)
            out = java("pair", os.path.join(wd, "a.raw"), os.path.join(wd, "b.raw"), w, h)
            jboxes = [tuple(map(int, l.split()[1:])) for l in out if l.startswith("BOX")]
            jglobal = tuple(map(int, [l for l in out if l.startswith("GLOBAL")][0].split()[1:]))
            py_g = M.estimate_global(a, b)
            pboxes = [tuple(int(v) for v in bx) for bx in M.compare_pages(a, b)]
            same_g = jglobal == tuple(int(v) for v in py_g)
            matched = all(any(iou(p, j) >= 0.9 for j in jboxes) for p in pboxes)
            good &= check(same_g and len(jboxes) == len(pboxes) and matched,
                          f"{name}: Java {len(jboxes)} hộp / numpy {len(pboxes)} hộp, dịch toàn trang Java {jglobal} = numpy {tuple(int(v) for v in py_g)}")

        # ghép trang
        P = [text_page(s, total=f"{s},000") for s in range(1, 9)]
        edited = P[4].copy(); edited[300:340, 100:500] = 255
        old = [P[0], P[1], P[2], P[3], P[4], P[5]]
        new = [warp(p, rot=0.3, dx=7, dy=-5) for p in [P[0], P[1], P[6], P[2], edited, P[5]]]
        paths = []
        for i, img in enumerate(old + new):
            pth = os.path.join(wd, f"p{i}.raw"); write_raw(pth, img); paths.append(pth)
        out = java("pages", w, h, len(old), len(new), *paths)
        jpairs = [tuple(map(int, l.split()[1:])) for l in out if l.startswith("PAIR")]
        sigs = M.normalized_signatures([M.raw_signature(p) for p in old + new])
        ppairs = M.align_pages(sigs[:len(old)], sigs[len(old):])
        good &= check(jpairs == ppairs == [(0, 0), (1, 1), (2, 3), (4, 4), (5, 5)], f"ghép trang: Java {jpairs} = numpy {ppairs}")
    print("TAT CA DAT" if good else "CO LOI")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
