// Bản Java chạy được của VaultCrypto (phiên 17): cùng định dạng, cùng thứ tự với app/.../util/VaultCrypto.kt.
// Dùng bởi vault_check.py.  java VaultCryptoCheck.java keygen <ra>  |  enc <khoá hex> <tên hex> <vào> <ra>  |  dec <khoá hex> <vào> <ra>  |  peek <khoá hex> <vào>
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.SecureRandom;
import javax.crypto.*;
import javax.crypto.spec.*;

public class VaultCryptoCheck {
    static final byte[] MAGIC = {'D', 'S', 'V', '1'};
    static final int VERSION = 1, CHUNK_LOG2 = 16, CHUNK = 1 << 16, TAG = 16, MAX_NAME = 1024, KEY = 32, PREFIX = 7, IV = 12;
    static final byte[] PARAMS_AAD = {'D', 'S', 'V', '1', (byte) VERSION, (byte) CHUNK_LOG2};

    static byte[] nonce(byte[] prefix, long index, boolean last) {
        byte[] n = new byte[12];
        System.arraycopy(prefix, 0, n, 0, PREFIX);
        n[7] = (byte) (index >>> 24); n[8] = (byte) (index >>> 16); n[9] = (byte) (index >>> 8); n[10] = (byte) index; n[11] = (byte) (last ? 1 : 0);
        return n;
    }
    static Cipher gcm(int mode, byte[] key, byte[] nonce, byte[] aad) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(mode, new SecretKeySpec(key, "AES"), new GCMParameterSpec(TAG * 8, nonce)); c.updateAAD(aad); return c;
    }
    static int readUpTo(InputStream in, byte[] buf) throws IOException { int n = 0; while (n < buf.length) { int r = in.read(buf, n, buf.length - n); if (r < 0) break; n += r; } return n; }

    static void encrypt(SecretKey master, String name, InputStream in, OutputStream out) throws Exception {
        byte[] nb = name.getBytes(StandardCharsets.UTF_8);
        if (nb.length < 1 || nb.length > MAX_NAME) throw new IllegalArgumentException("name");
        SecureRandom r = new SecureRandom(); byte[] fileKey = new byte[KEY], prefix = new byte[PREFIX]; r.nextBytes(fileKey); r.nextBytes(prefix);
        Cipher wc = Cipher.getInstance("AES/GCM/NoPadding"); wc.init(Cipher.ENCRYPT_MODE, master); wc.updateAAD(PARAMS_AAD);
        byte[] wrappedKey = wc.doFinal(fileKey); byte[] iv = wc.getIV();
        ByteArrayOutputStream wrapped = new ByteArrayOutputStream(); wrapped.write(iv.length); wrapped.write(iv); wrapped.write(wrappedKey);
        ByteArrayOutputStream h = new ByteArrayOutputStream();
        h.write(MAGIC); h.write(VERSION); h.write(CHUNK_LOG2); h.write(wrapped.size() >>> 8); h.write(wrapped.size() & 0xFF); h.write(wrapped.toByteArray()); h.write(prefix);
        byte[] header = h.toByteArray(); out.write(header);
        ByteArrayOutputStream head = new ByteArrayOutputStream(); head.write(nb.length >>> 8); head.write(nb.length & 0xFF); head.write(nb);
        PushbackInputStream src = new PushbackInputStream(new SequenceInputStream(new ByteArrayInputStream(head.toByteArray()), in), 1);
        byte[] buf = new byte[CHUNK]; long index = 0;
        while (true) {
            int n = readUpTo(src, buf); int next = src.read(); boolean last = next < 0; if (!last) src.unread(next);
            out.write(gcm(Cipher.ENCRYPT_MODE, fileKey, nonce(prefix, index, last), header).doFinal(buf, 0, n));
            if (last) break; index++;
        }
        out.flush();
    }

    static String decrypt(SecretKey master, InputStream in, OutputStream out) throws Exception {
        byte[] fixed = new byte[8];
        if (readUpTo(in, fixed) != 8) throw new SecurityException("short header");
        for (int i = 0; i < 4; i++) if (fixed[i] != MAGIC[i]) throw new SecurityException("not a vault file");
        if (fixed[4] != VERSION || fixed[5] != CHUNK_LOG2) throw new SecurityException("unsupported version");
        int wrapLen = ((fixed[6] & 0xFF) << 8) | (fixed[7] & 0xFF);
        if (wrapLen != 1 + IV + KEY + TAG) throw new SecurityException("bad key block");
        byte[] wrapped = new byte[wrapLen], prefix = new byte[PREFIX];
        if (readUpTo(in, wrapped) != wrapLen || readUpTo(in, prefix) != PREFIX) throw new SecurityException("short header");
        if (wrapped[0] != IV) throw new SecurityException("bad IV length");
        ByteArrayOutputStream hb = new ByteArrayOutputStream(); hb.write(fixed); hb.write(wrapped); hb.write(prefix); byte[] header = hb.toByteArray();
        byte[] fileKey;
        try {
            Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE, master, new GCMParameterSpec(TAG * 8, java.util.Arrays.copyOfRange(wrapped, 1, 1 + IV))); c.updateAAD(PARAMS_AAD);
            fileKey = c.doFinal(wrapped, 1 + IV, wrapLen - 1 - IV);
        } catch (AEADBadTagException e) { throw new SecurityException("wrong key or damaged key block"); }
        PushbackInputStream src = new PushbackInputStream(in, 1);
        byte[] buf = new byte[CHUNK + TAG]; long index = 0; String name = "";
        while (true) {
            int n = readUpTo(src, buf);
            if (n < TAG + 1) throw new SecurityException("truncated at chunk " + index);
            boolean last;
            if (n < buf.length) last = true; else { int next = src.read(); last = next < 0; if (!last) src.unread(next); }
            byte[] plain;
            try { plain = gcm(Cipher.DECRYPT_MODE, fileKey, nonce(prefix, index, last), header).doFinal(buf, 0, n); }
            catch (AEADBadTagException e) { throw new SecurityException("chunk " + index + " failed authentication"); }
            int from = 0;
            if (index == 0) {
                if (plain.length < 3) throw new SecurityException("no name");
                int len = ((plain[0] & 0xFF) << 8) | (plain[1] & 0xFF);
                if (len < 1 || len > MAX_NAME || 2 + len > plain.length) throw new SecurityException("bad name");
                name = new String(plain, 2, len, StandardCharsets.UTF_8); from = 2 + len;
                if (out == null) return name;
            }
            if (out != null) out.write(plain, from, plain.length - from);
            if (last) break; index++;
        }
        if (out != null) out.flush();
        return name;
    }

    static byte[] unhex(String h) { byte[] b = new byte[h.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return b; }
    public static void main(String[] a) throws Exception {
        if (a[0].equals("keygen")) { byte[] k = new byte[32]; new SecureRandom().nextBytes(k); StringBuilder s = new StringBuilder(); for (byte x : k) s.append(String.format("%02x", x & 0xff)); Files.write(Paths.get(a[1]), s.toString().getBytes()); return; }
        SecretKey key = new SecretKeySpec(unhex(a[1]), "AES");
        try {
            if (a[0].equals("enc")) { try (InputStream in = Files.newInputStream(Paths.get(a[3])); OutputStream out = new BufferedOutputStream(Files.newOutputStream(Paths.get(a[4])))) { encrypt(key, new String(unhex(a[2]), StandardCharsets.UTF_8), in, out); } System.out.println("OK"); }
            else if (a[0].equals("dec")) { String name; try (InputStream in = new BufferedInputStream(Files.newInputStream(Paths.get(a[2]))); OutputStream out = new BufferedOutputStream(Files.newOutputStream(Paths.get(a[3])))) { name = decrypt(key, in, out); } System.out.println("OK " + new String(name.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8).chars().mapToObj(c -> String.format("%04x", c)).reduce("", String::concat)); }
            else if (a[0].equals("peek")) { try (InputStream in = new BufferedInputStream(Files.newInputStream(Paths.get(a[2])))) { String name = decrypt(key, in, null); System.out.println("OK " + name.chars().mapToObj(c -> String.format("%04x", c)).reduce("", String::concat)); } }
        } catch (SecurityException e) { System.out.println("TAMPER " + e.getMessage()); }
    }
}
