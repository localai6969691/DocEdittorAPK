"""Kiểm chứng PdfBookmarks (phiên 17, mục 4.32): tách PDF theo mục lục, ghép PDF giữ chữ + mục lục.

PHẦN A - phần lập kế hoạch thuần (BookmarksCheck.java = bản Java của normalizeLevels / maxLevel / sections / entriesForPart / mergedOutline) so với bản tham chiếu ĐỘC LẬP
viết khác đi trong Python trên 2 500 mục lục ngẫu nhiên (mức nhảy cóc, mục lục bắt đầu ở mức 3, nhiều mục cùng trang, trang ngoài khoảng, tên chữ Việt).
PHẦN A2 - các phép SỬA (xoá kèm mục con, đổi tên, thêm đúng chỗ theo trang) Java = tham chiếu độc lập trên 2 500 ca, kèm bất biến: danh sách luôn hợp lệ về mức; xoá bớt đúng
số mục con; thêm giữ thứ tự trang.
PHẦN A3 (phiên 19) - lên / xuống / thụt vào / đưa ra ngoài: Java theo mức = MÔ HÌNH CÂY viết riêng (đổi chỗ anh em, đổi cha, rồi trải phẳng) trên 3 000 ca, kèm bất biến hoán vị + hợp lệ về mức và thử âm tính.
PHẦN B - ĐẦU-CUỐI trên PDF thật, đọc lại bằng pikepdf (độc lập với mã đang kiểm): sách 40 trang có mục lục 3 tầng, mỗi trang mang một nhãn duy nhất trong nội dung.
  Tách ở mức 1 và mức 2: phần i chứa ĐÚNG các trang của chương i (đối chiếu nhãn từng trang), mục lục trong phần trỏ đúng nhãn trang gốc mà nó từng trỏ tới, tên và mức giữ nguyên (đã lùi mức).
  Ghép [B (không mục lục), A (có mục lục), C (có mục lục)]: tổng số trang, mỗi dấu trang cấp tệp trỏ trang đầu của tệp, mỗi dấu trang lồng trỏ đúng nhãn trang gốc của nó; pdftotext lấy được chữ của
  trang ghép (chữ không bị biến thành ảnh); qpdf --check.
THỬ ÂM TÍNH: mục lục ghép "quên dịch trang" (không cộng độ lệch) phải bị bài kiểm đầu-cuối bắt.
Chạy: python3 bookmarks_check.py   (cần java 11+, pikepdf, pdftotext, qpdf)
"""
import os, random, re, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import pikepdf
from pikepdf import Name, Array, Dictionary
HERE = os.path.dirname(os.path.abspath(__file__))
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
    return cond
hx = lambda s: s.encode("utf-8").hex(); unhx = lambda h: bytes.fromhex(h).decode("utf-8")

# ---------------------------------------------------------------- tham chiếu độc lập
def r_norm(es):
    out, prev = [], 0
    for t, l, p in es:
        l = max(1, l); l = min(l, prev + 1); out.append((t, l, p)); prev = l
    return out
def r_max(es, n): return max([l for t, l, p in r_norm(es) if 0 <= p < n], default=0)
def r_sections(es, n, level, preface, ptitle):
    cand = sorted([(p, i, t) for i, (t, l, p) in enumerate(r_norm(es)) if l == level and 0 <= p < n])
    starts = []
    for p, i, t in cand:
        if not starts or starts[-1][0] != p: starts.append((p, t))
    if not starts: return []
    secs = []
    if preface and starts[0][0] > 0: secs.append((ptitle, 0, starts[0][0] - 1))
    for k, (p, t) in enumerate(starts): secs.append((t, p, (starts[k + 1][0] - 1) if k + 1 < len(starts) else n - 1))
    return secs
def r_part(es, first, last, level): return [(t, l - level + 1, p - first) for t, l, p in r_norm(es) if first <= p <= last and l >= level]
def r_merge(files):
    out, off = [], 0
    for name, n, es in files:
        if n > 0:
            out.append((name, 1, off)); out += [(t, l + 1, p + off) for t, l, p in r_norm(es) if 0 <= p < n]
        off += n
    return out

def java(blocks):
    fin, fout = os.path.join(OUT, "bm_in.txt"), os.path.join(OUT, "bm_out.txt")
    open(fin, "w", encoding="utf-8").write("\n---\n".join(blocks) + "\n")
    subprocess.run(["java", os.path.join(HERE, "BookmarksCheck.java"), fin, fout], check=True)
    return open(fout, encoding="utf-8").read().split("\n")[:-1]
def eline(t, l, p): return f"E\t{hx(t)}\t{l}\t{p}"
def parse_entries(s): return [(unhx(a), int(b), int(c)) for a, b, c in (x.split(" ") for x in s.split(";") if x)]
def parse_secs(s): return [(unhx(a), int(b), int(c)) for a, b, c in (x.split(" ") for x in s.split(";") if x)]

print("== A. lập kế hoạch thuần (Java <-> tham chiếu độc lập) ==")
rnd = random.Random(23)
TITLES = ["Chương 1", "Mở đầu", "Phụ lục A", "Điều 3. Thời hạn", "1.1 Khái niệm", "Lời nói đầu", "Ghi chú: 😀", "x"]
blocks, expects = [], []
for _ in range(2500):
    n = rnd.randint(1, 60)
    es = [(rnd.choice(TITLES) + str(rnd.randint(0, 9)), rnd.choice([0, 1, 1, 1, 2, 2, 3, 3, 5]), rnd.choice([rnd.randint(-2, n + 2), rnd.randint(0, n - 1), rnd.randint(0, n - 1)])) for _ in range(rnd.randint(0, 14))]
    kind = rnd.choice("NXSSPM")
    body = [eline(*e) for e in es]
    if kind == "N": blocks.append("\n".join(["N"] + body)); expects.append(("N", r_norm(es)))
    elif kind == "X": blocks.append("\n".join([f"X\t{n}"] + body)); expects.append(("X", r_max(es, n)))
    elif kind == "S":
        lv, pf = rnd.randint(1, 3), rnd.choice([0, 1]); blocks.append("\n".join([f"S\t{n}\t{lv}\t{pf}\t{hx('Phần đầu')}"] + body)); expects.append(("S", r_sections(es, n, lv, bool(pf), "Phần đầu")))
    elif kind == "P":
        a = rnd.randint(0, n - 1); b = rnd.randint(a, n - 1); lv = rnd.randint(1, 3); blocks.append("\n".join([f"P\t{lv}\t{a}\t{b}"] + body)); expects.append(("P", r_part(es, a, b, lv)))
    else:
        files = [(rnd.choice(TITLES), rnd.randint(0, 20), [(t, l, rnd.randint(-1, 21)) for t, l, p in es[:rnd.randint(0, 5)]]) for _ in range(rnd.randint(1, 4))]
        blocks.append("\n".join(["M"] + sum([[f"F\t{hx(nm)}\t{n2}"] + [eline(*e) for e in fes] for nm, n2, fes in files], []))); expects.append(("M", r_merge(files)))
got = java(blocks); bad = 0; kinds = {}
for (k, exp), g in zip(expects, got):
    kinds[k] = kinds.get(k, 0) + 1
    if k == "X": ok = int(g) == exp
    elif k == "S": ok = parse_secs(g) == exp
    else: ok = parse_entries(g) == exp
    bad += 0 if ok else 1
check(bad == 0 and min(kinds.values()) > 100, f"2 500 ca (chuẩn hoá mức, mức sâu nhất, chương, mục lục của phần, mục lục ghép): Java = tham chiếu, {bad} lệch; số ca mỗi loại {kinds}")

def r_delete(es, i):
    n = r_norm(es)
    if not 0 <= i < len(n): return n
    j = i + 1
    while j < len(n) and n[j][1] > n[i][1]: j += 1
    return r_norm(n[:i] + n[j:])
def r_rename(es, i, t):
    n = r_norm(es); t = t.strip()
    return n if not 0 <= i < len(n) or not t else [(t, l, p) if k == i else (tt, l, p) for k, (tt, l, p) in enumerate(n)] if False else [((t if k == i else tt), l, p) for k, (tt, l, p) in enumerate(n)]
def r_insert(es, t, page, level, n_pages):
    n = r_norm(es); t = t.strip()
    if not t or not 0 <= page < n_pages: return n
    at = max([k + 1 for k, (tt, l, p) in enumerate(n) if p <= page], default=0)
    return r_norm(n[:at] + [(t, max(level, 1), page)] + n[at:])
print("== A2. phép sửa ==")
blocks, expects = [], []
for _ in range(2500):
    n = rnd.randint(1, 40)
    es = [(rnd.choice(TITLES) + str(rnd.randint(0, 9)), rnd.choice([1, 1, 2, 2, 3, 4]), rnd.randint(0, n - 1)) for _ in range(rnd.randint(0, 12))]
    es.sort(key=lambda e: e[2]); body = [eline(*e) for e in es]
    k = rnd.choice("DRI"); idx = rnd.randint(-1, max(len(es), 1))
    if k == "D": blocks.append("\n".join([f"D\t{idx}"] + body)); expects.append(r_delete(es, idx))
    elif k == "R":
        t = rnd.choice(["Tên mới", "  ", "Chương mới 😀", ""]); blocks.append("\n".join([f"R\t{idx}\t{hx(t)}"] + body)); expects.append(r_rename(es, idx, t))
    else:
        t = rnd.choice(["Mục thêm", " Mục thêm ", ""]); pg = rnd.randint(-1, n); lv = rnd.randint(0, 5); blocks.append("\n".join([f"I\t{hx(t)}\t{pg}\t{lv}\t{n}"] + body)); expects.append(r_insert(es, t, pg, lv, n))
got = java(blocks); bad = [i for i, (g, e) in enumerate(zip(got, expects)) if parse_entries(g) != e]
check(not bad, f"2 500 ca sửa (xoá / đổi tên / thêm): Java = tham chiếu độc lập ({len(bad)} lệch)")
valid = all(all(1 <= l <= (expects[i][k - 1][1] + 1 if k else 1) for k, (t, l, p) in enumerate(expects[i])) for i in range(len(expects)))
check(valid, "mọi kết quả sửa đều hợp lệ về mức (mức đầu = 1, mỗi mức sâu hơn mức trước nhiều nhất 1)")
demo = [("Chương 1", 1, 0), ("1.1", 2, 2), ("1.1.1", 3, 3), ("Chương 2", 1, 6)]
d = parse_entries(java(["D\t1\n" + "\n".join(eline(*e) for e in demo)])[0])
check(d == [("Chương 1", 1, 0), ("Chương 2", 1, 6)], "xoá '1.1' mang theo mục con '1.1.1' nhưng không đụng 'Chương 2'")
i2 = parse_entries(java([f"I\t{hx('1.2')}\t4\t2\t10\n" + "\n".join(eline(*e) for e in demo)])[0])
check(i2 == [("Chương 1", 1, 0), ("1.1", 2, 2), ("1.1.1", 3, 3), ("1.2", 2, 4), ("Chương 2", 1, 6)], "thêm '1.2' (mức 2, trang 5) vào đúng giữa '1.1.1' và 'Chương 2'")

print("== A3. di chuyển / đổi cấp (phiên 19): danh sách phẳng (Java) <-> mô hình CÂY viết riêng ==")
# Mô hình cây: mỗi nút [tên, trang, [con...]]. Mọi phép làm trên cây (đổi chỗ anh em, đổi cha), rồi trải phẳng - hoàn toàn khác cách làm theo mức của bản Java.
def t_build(n):
    root = []; stack = [(0, root)]
    for t, l, p in n:
        node = [t, p, []]
        while stack[-1][0] >= l: stack.pop()
        stack[-1][1].append(node); stack.append((l, node[2]))
    return root
def t_flat(nodes, level=1):
    out = []
    for t, p, kids in nodes: out.append((t, level, p)); out += t_flat(kids, level + 1)
    return out
def t_locate(nodes, idx, parent=None, parent_list=None, parent_pos=None, counter=None):
    """Trả (danh sách chứa, vị trí, cha=(danh sách ông, vị trí cha) hoặc None) của nút thứ idx theo thứ tự trải phẳng."""
    counter = counter if counter is not None else [0]
    for pos, node in enumerate(nodes):
        if counter[0] == idx: return nodes, pos, (parent_list, parent_pos) if parent is not None else None
        counter[0] += 1
        r = t_locate(node[2], idx, node, nodes, pos, counter)
        if r: return r
    return None
def t_op(es, idx, op):
    n = r_norm(es); root = t_build(n)
    if not 0 <= idx < len(n): return n
    lst, pos, par = t_locate(root, idx)
    if op == "U":
        if pos > 0: lst[pos - 1], lst[pos] = lst[pos], lst[pos - 1]
    elif op == "W":
        if pos + 1 < len(lst): lst[pos + 1], lst[pos] = lst[pos], lst[pos + 1]
    elif op == "T":
        if pos > 0:
            node = lst.pop(pos); lst[pos - 1][2].append(node)
    elif op == "O":
        if par is not None:
            grand, ppos = par
            node = lst[pos]; later = lst[pos + 1:]; del lst[pos:]   # nút và các anh em đứng sau rời khỏi cha
            node[2] += later                                         # anh em đứng sau thành con của nút (giữ nguyên thứ tự hiển thị)
            grand.insert(ppos + 1, node)
    return t_flat(root)
blocks, expects = [], []
for _ in range(3000):
    n = rnd.randint(1, 40)
    es = [(rnd.choice(TITLES) + str(k), rnd.choice([1, 1, 2, 2, 3, 4]), rnd.randint(0, n - 1)) for k in range(rnd.randint(0, 14))]
    es.sort(key=lambda e: e[2]); body = [eline(*e) for e in es]
    op = rnd.choice("UWTO"); idx = rnd.randint(-1, max(len(es), 1))
    blocks.append("\n".join([f"{op}\t{idx}"] + body)); expects.append(t_op(es, idx, op))
got = java(blocks); bad = [i for i, (g, e) in enumerate(zip(got, expects)) if parse_entries(g) != e]
check(not bad, f"3 000 ca (lên / xuống / thụt vào / đưa ra): Java theo mức = mô hình cây độc lập ({len(bad)} lệch)")
# bất biến: các phép chỉ ĐỔI CHỖ / ĐỔI CẤP - không mất, không thêm, không đổi tên hay trang của mục nào
def multiset(x): return sorted((t, p) for t, l, p in x)
perm_ok = True
for blk, g in zip(blocks, got):
    lines = blk.split("\n"); es0 = [(unhx(a), int(b), int(c)) for a, b, c in (ln.split("\t")[1:] for ln in lines[1:])]
    if multiset(parse_entries(g)) != multiset(r_norm(es0)): perm_ok = False; break
check(perm_ok, "bất biến: kết quả là hoán vị của danh sách cũ (không mất / thêm / đổi tên / đổi trang mục nào)")
level_ok = all(all(1 <= l <= (parse_entries(g)[k - 1][1] + 1 if k else 1) for k, (t, l, p) in enumerate(parse_entries(g))) for g in got)
check(level_ok, "bất biến: mọi kết quả đều hợp lệ về mức (mức đầu = 1, mỗi mức sâu hơn mức trước nhiều nhất 1)")
# các hàm 'can...' (nút nào hiện trong hộp thoại) phải ĐÚNG KHI VÀ CHỈ KHI phép tương ứng thật sự đổi danh sách (tên mục khác nhau nên so sánh theo nội dung được)
cblocks, cexp = [], []
for _ in range(2000):
    n = rnd.randint(1, 30)
    es = [(f"m{k}", rnd.choice([1, 1, 2, 2, 3, 4]), rnd.randint(0, n - 1)) for k in range(rnd.randint(0, 12))]; es.sort(key=lambda e: e[2])
    idx = rnd.randint(-1, len(es) + 1); body = [eline(*e) for e in es]
    cblocks.append("\n".join([f"u\t{idx}"] + body)); nn = r_norm(es)
    cexp.append("".join("1" if t_op(es, idx, op) != nn else "0" for op in "UWTO"))
cgot = java(cblocks); cbad = [i for i, (g, e) in enumerate(zip(cgot, cexp)) if g != e]
check(not cbad, f"2 000 ca: canMoveUp / canMoveDown / canIndent / canOutdent = 'phép đó có đổi danh sách không' theo mô hình cây ({len(cbad)} lệch)")
demo = [("A", 1, 0), ("A1", 2, 1), ("A2", 2, 2), ("B", 1, 3), ("B1", 2, 4)]
dj = lambda op, i: parse_entries(java([f"{op}\t{i}\n" + "\n".join(eline(*e) for e in demo)])[0])
check(dj("W", 0) == [("B", 1, 3), ("B1", 2, 4), ("A", 1, 0), ("A1", 2, 1), ("A2", 2, 2)], "'A' xuống: đi cùng hai con, đổi chỗ với 'B' cùng con của nó")
check(dj("U", 2) == [("A", 1, 0), ("A2", 2, 2), ("A1", 2, 1), ("B", 1, 3), ("B1", 2, 4)], "'A2' lên: đổi chỗ với 'A1', không chui ra khỏi 'A'")
check(dj("U", 1) == [("A", 1, 0), ("A1", 2, 1), ("A2", 2, 2), ("B", 1, 3), ("B1", 2, 4)], "'A1' là con đầu: lên thì không đổi gì")
check(dj("T", 3) == [("A", 1, 0), ("A1", 2, 1), ("A2", 2, 2), ("B", 2, 3), ("B1", 3, 4)], "'B' thụt vào: thành con cuối của 'A', mang theo 'B1'")
check(dj("T", 0) == [(t, l, p) for t, l, p in demo], "mục đầu tiên không thụt vào được")
check(dj("O", 1) == [("A", 1, 0), ("A1", 1, 1), ("A2", 2, 2), ("B", 1, 3), ("B1", 2, 4)], "'A1' ra ngoài: ngang hàng 'A'; 'A2' đứng sau thành con của 'A1'")
check(dj("O", 0) == [(t, l, p) for t, l, p in demo], "mục cấp cao nhất không đưa ra ngoài được")
# THỬ ÂM TÍNH: bản 'đưa ra ngoài' quên mang con theo (chỉ đổi cấp một mình mục đó) phải bị mô hình cây bắt
def bad_outdent(es, idx):
    n = r_norm(es)
    return r_norm([(t, l - 1 if k == idx and l > 1 else l, p) for k, (t, l, p) in enumerate(n)])
mut = 0
for _ in range(1500):
    es = [(f"m{k}", rnd.choice([1, 2, 2, 3, 3, 4]), k) for k in range(rnd.randint(3, 12))]; i = rnd.randrange(len(es))
    if bad_outdent(es, i) != t_op(es, i, "O"): mut += 1
check(mut > 50, f"thử âm tính: bản 'đổi cấp mình mục đó, bỏ con lại' khác mô hình cây ở {mut}/1500 ca (bị bắt)")

# ---------------------------------------------------------------- phần B: PDF thật
def page_stream(tag): return f"BT /F1 12 Tf 72 700 Td ({tag}) Tj ET".encode()
def make_pdf(path, tag, n, entries):
    pdf = pikepdf.new(); font = pdf.make_indirect(Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Helvetica))
    for i in range(n):
        pg = pdf.add_blank_page(page_size=(595, 842)); pg.Resources = Dictionary(Font=Dictionary(F1=font)); pg.Contents = pdf.make_stream(page_stream(f"{tag}-{i:04d}"))
    write_outline(pdf, entries); pdf.save(path); return path
def write_outline(pdf, entries):
    if not entries: return
    with pdf.open_outline() as ol:
        stack = [ol.root]
        for t, l, p in r_norm(entries):
            item = pikepdf.OutlineItem(t, p); stack[l - 1].append(item); stack[:] = stack[:l] + [item.children]
def tag_of(pdf, i): return re.search(rb"\(([A-Z]+-\d+)\)", pdf.pages[i].Contents.read_bytes()).group(1).decode()
def read_outline(pdf):
    out = []; ids = [p.objgen for p in pdf.pages]
    with pdf.open_outline() as ol:
        def walk(items, level):
            for it in items:
                d = it.destination; page = ids.index(d[0].objgen) if d is not None and isinstance(d, pikepdf.Array) else -1
                out.append((str(it.title), level, page)); walk(it.children, level + 1)
        walk(ol.root, 1)
    return out
BOOK = [("Lời nói đầu", 1, 0), ("Phần I", 1, 4), ("Chương 1", 2, 4), ("1.1 Khái niệm", 3, 5), ("1.2 Ví dụ", 3, 9), ("Chương 2", 2, 12), ("Phần II", 1, 20), ("Chương 3", 2, 20),
        ("Chương 4", 2, 27), ("4.1 Tổng kết", 3, 30), ("Phụ lục", 1, 33), ("Tài liệu tham khảo", 1, 37)]
book = make_pdf(os.path.join(OUT, "bm_book.pdf"), "BOOK", 40, BOOK)
src = pikepdf.open(book); entries_src = read_outline(src)
check(entries_src == [(t, l, p) for t, l, p in BOOK], "đọc mục lục bằng pikepdf độc lập: 12 mục, 3 tầng, đúng trang")
print("== B1. tách ==")
for level in (1, 2):
    blocks = [f"S\t40\t{level}\t1\t{hx('Phần đầu')}\n" + "\n".join(eline(*e) for e in entries_src)]
    secs = parse_secs(java(blocks)[0]); expect_secs = r_sections(entries_src, 40, level, True, "Phần đầu")
    check(secs == expect_secs, f"mức {level}: {len(secs)} chương = tham chiếu ({[s[0] for s in secs][:4]}...)")
    ok_pages = ok_outline = True
    for t, first, last in secs:
        pb = [f"P\t{level}\t{first}\t{last}\n" + "\n".join(eline(*e) for e in entries_src)]
        part_entries = parse_entries(java(pb)[0])
        part = pikepdf.new()
        for i in range(first, last + 1): part.pages.append(src.pages[i])
        write_outline(part, part_entries)
        if [tag_of(part, i) for i in range(len(part.pages))] != [f"BOOK-{i:04d}" for i in range(first, last + 1)]: ok_pages = False
        back = read_outline(part); orig = {(t2, p2) for t2, l2, p2 in entries_src if first <= p2 <= last and l2 >= level}
        got = {(t2, tag_of(part, p2)) for t2, l2, p2 in back}
        if {(t2, f"BOOK-{p2:04d}") for t2, p2 in orig} != got or [l2 for t2, l2, p2 in back][:1] != [1] and back: ok_outline = False
    check(ok_pages, f"mức {level}: mỗi phần chứa ĐÚNG các trang của chương (nhãn từng trang)")
    check(ok_outline, f"mức {level}: mục lục trong phần trỏ đúng trang gốc, tên giữ nguyên, mức đã lùi về 1")
# phần mở đầu: trang 1-3 trước "Phần I" khi mục lục bắt đầu muộn
late = [("Chương 1", 1, 3), ("Chương 2", 1, 8)]
s = parse_secs(java([f"S\t12\t1\t1\t{hx('Phần đầu')}\n" + "\n".join(eline(*e) for e in late)])[0]); s2 = parse_secs(java([f"S\t12\t1\t0\t{hx('Phần đầu')}\n" + "\n".join(eline(*e) for e in late)])[0])
check(s == [("Phần đầu", 0, 2), ("Chương 1", 3, 7), ("Chương 2", 8, 11)] and s2 == [("Chương 1", 3, 7), ("Chương 2", 8, 11)], "trang đứng trước chương đầu: thành 'Phần đầu' hoặc bị bỏ theo lựa chọn")
check(parse_secs(java([f"S\t10\t3\t1\t{hx('x')}\n" + "\n".join(eline(*e) for e in BOOK)])[0]) != [] and parse_secs(java([f"S\t10\t1\t1\t{hx('x')}"])[0]) == [], "không có dấu trang ở mức đó -> không tách (danh sách rỗng, không lỗi)")
print("== B3. sửa mục lục trên PDF thật ==")
ed = parse_entries(java(["D\t5\n" + "\n".join(eline(*e) for e in entries_src)])[0])           # xoá 'Chương 2' (mức 2)
ed = parse_entries(java([f"R\t0\t{hx('Lời tựa')}\n" + "\n".join(eline(*e) for e in ed)])[0])
ed = parse_entries(java([f"I\t{hx('Bảng tra cứu')}\t38\t1\t40\n" + "\n".join(eline(*e) for e in ed)])[0])
edited = pikepdf.open(book, allow_overwriting_input=False); write_outline(edited, []); ep = os.path.join(OUT, "bm_edited.pdf")
cp = pikepdf.new()
for pg in edited.pages: cp.pages.append(pg)
write_outline(cp, ed); cp.save(ep); ed_doc = pikepdf.open(ep)
back = [(t, l, tag_of(ed_doc, p)) for t, l, p in read_outline(ed_doc)]
want = [(("Lời tựa" if (t, l, p) == BOOK[0] else t), l, f"BOOK-{p:04d}") for t, l, p in BOOK if t != "Chương 2"] + [("Bảng tra cứu", 1, "BOOK-0038")]
want.sort(key=lambda x: int(x[2].split("-")[1])) if False else None
check(sorted(back, key=lambda x: (int(x[2].split("-")[1]), x[1])) == sorted(want, key=lambda x: (int(x[2].split("-")[1]), x[1])) and len(back) == len(want), f"sau xoá + đổi tên + thêm: mục lục đọc lại từ PDF thật có {len(back)} mục, đúng tên / mức / nhãn trang")
check(subprocess.run(["qpdf", "--check", ep], capture_output=True).returncode == 0, "PDF đã sửa mục lục qua qpdf --check")
print("== B2. ghép ==")
A = make_pdf(os.path.join(OUT, "bm_A.pdf"), "AAA", 12, [("Mở đầu", 1, 0), ("Mục 1", 1, 3), ("Mục 1.1", 2, 4), ("Mục 2", 1, 8)])
B = make_pdf(os.path.join(OUT, "bm_B.pdf"), "BBB", 5, [])
C = make_pdf(os.path.join(OUT, "bm_C.pdf"), "CCC", 7, [("Phần C1", 1, 0), ("Phần C2", 1, 5)])
files = [("Hồ sơ B", B), ("Hợp đồng A", A), ("Phụ lục C", C)]
docs = [pikepdf.open(p) for _, p in files]; counts = [len(d.pages) for d in docs]; ents = [read_outline(d) for d in docs]
blk = "M\n" + "\n".join(f"F\t{hx(n)}\t{c}\n" + "\n".join(eline(*e) for e in es) for (n, _), c, es in zip(files, counts, ents))
merged_entries = parse_entries(java([blk])[0])
merged = pikepdf.new()
for d in docs:
    for pg in d.pages: merged.pages.append(pg)
write_outline(merged, merged_entries)
mp = os.path.join(OUT, "bm_merged.pdf"); merged.save(mp); mp_doc = pikepdf.open(mp)
check(len(mp_doc.pages) == 24, "tổng số trang 5 + 12 + 7 = 24")
back = read_outline(mp_doc)
tags = [tag_of(mp_doc, i) for i in range(24)]
exp, off = [], 0
for (nm, _), d, es, c in zip(files, docs, ents, counts):
    exp.append((nm, 1, tags[off])); exp += [(t, l + 1, f"{'BBB' if nm == 'Hồ sơ B' else 'AAA' if nm == 'Hợp đồng A' else 'CCC'}-{p:04d}") for t, l, p in es]; off += c
got = [(t, l, tags[p]) for t, l, p in back]
check(got == exp, f"mọi dấu trang ghép (file + lồng) trỏ đúng nhãn trang gốc: {len(got)} dấu trang, tên + mức + trang khớp")
txt = subprocess.run(["pdftotext", "-f", "9", "-l", "9", mp, "-"], capture_output=True, text=True).stdout
check("AAA-0003" in txt, "pdftotext lấy được chữ của trang 9 trong PDF ghép (chữ KHÔNG bị biến thành ảnh): " + txt.strip()[:20])
check(subprocess.run(["qpdf", "--check", mp], capture_output=True).returncode == 0, "qpdf --check đạt")
unshifted = [(t, l, (p - 5 if p >= 5 else p)) for t, l, p in merged_entries]   # sai: "quên dịch trang" (coi như B không có trang nào)
bad = pikepdf.new()
for d in docs:
    for pg in d.pages: bad.pages.append(pg)
write_outline(bad, unshifted); bp = os.path.join(OUT, "bm_bad.pdf"); bad.save(bp); bad_doc = pikepdf.open(bp)
bad_got = [(t, l, tag_of(bad_doc, p)) for t, l, p in read_outline(bad_doc)]
check(bad_got != exp, "thử âm tính: mục lục ghép 'quên dịch trang' bị bài kiểm đầu-cuối bắt (dấu trang trỏ sai nhãn trang)")
print()
print("TAT CA DAT" if not FAILS else f"CO {len(FAILS)} LOI: " + "; ".join(FAILS[:5]))
sys.exit(1 if FAILS else 0)
