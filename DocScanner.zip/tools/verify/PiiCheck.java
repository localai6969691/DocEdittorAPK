// Bản Java chạy được của PiiDetector.find / fold / luhn / wordsCovering (phiên 16): cùng biểu thức chính quy (java.util.regex), cùng thứ tự ưu tiên.
// Dùng bởi pii_check.py: java PiiCheck.java <tệp vào> <tệp ra>. Vào mỗi dòng: "find\t<văn bản>" hoặc "words\t<start>\t<end>\t<từ1>\t<từ2>...".
// Ra mỗi dòng: "<start>:<end>:<KIND>;..." (rỗng nếu không có) hoặc "<first>-<last>" / "none".
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.Normalizer;
import java.util.*;
import java.util.regex.*;

public class PiiCheck {
    static final Pattern EMAIL = Pattern.compile("[A-Za-z0-9._%+\\-]+@[A-Za-z0-9\\-]+(?:\\.[A-Za-z0-9\\-]+)*\\.[A-Za-z]{2,}");
    static final Pattern CARD = Pattern.compile("(?<!\\d)\\d{4}(?:[ \\-]?\\d{4}){2,3}(?:[ \\-]?\\d{1,3})?(?!\\d)");
    static final Pattern CITIZEN = Pattern.compile("(?<!\\d)0(?:0[1-9]|[1-8]\\d|9[0-6])\\d{9}(?!\\d)");
    static final Pattern PHONE_MOBILE = Pattern.compile("(?<![\\d+])(?:\\+84|84|0)[ .\\-]?[35789](?:[ .\\-]?\\d){8}(?!\\d)");
    static final Pattern PHONE_LANDLINE = Pattern.compile("(?<![\\d+])0[ .\\-]?2(?:[ .\\-]?\\d){9}(?!\\d)");
    static final Pattern CITIZEN_CONTEXT = Pattern.compile("(?i)(?:cmnd|cmt|cccd|can cuoc|chung minh)[^\\d\\n]{0,25}(\\d{12}|\\d{9})(?!\\d)");
    static final Pattern TAX_CONTEXT = Pattern.compile("(?i)(?:mst|ma so thue|tax ?id|tax ?code)[^\\d\\n]{0,20}(\\d{10}(?:-\\d{3})?|\\d{13})(?!\\d)");
    static final Pattern ACCOUNT_CONTEXT = Pattern.compile("(?i)(?:stk|so tai khoan|tai khoan|account(?: ?(?:no|number))?)[^\\d\\n]{0,20}(\\d{6,19})(?!\\d)");

    record Candidate(int start, int end, String kind, int priority) {}

    static String fold(String text) {
        StringBuilder sb = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == 'đ') sb.append('d');
            else if (c == 'Đ') sb.append('D');
            else sb.append(Normalizer.normalize(String.valueOf(c), Normalizer.Form.NFD).charAt(0));
        }
        return sb.toString();
    }

    static boolean luhn(String digits) {
        int sum = 0; boolean dbl = false;
        for (int i = digits.length() - 1; i >= 0; i--) {
            int d = digits.charAt(i) - '0';
            if (dbl) { d *= 2; if (d > 9) d -= 9; }
            sum += d; dbl = !dbl;
        }
        return !digits.isEmpty() && sum % 10 == 0;
    }

    static String find(String text) {
        String folded = fold(text);
        List<Candidate> found = new ArrayList<>();
        Matcher m = EMAIL.matcher(text);
        while (m.find()) found.add(new Candidate(m.start(), m.end(), "EMAIL", 1));
        m = CARD.matcher(text);
        while (m.find()) {
            String digits = m.group().replaceAll("[^0-9]", "");
            if (digits.length() >= 13 && digits.length() <= 19 && luhn(digits)) found.add(new Candidate(m.start(), m.end(), "CARD", 3));
        }
        m = CITIZEN_CONTEXT.matcher(folded);
        while (m.find()) found.add(new Candidate(m.start(1), m.end(1), "CITIZEN_ID", 2));
        m = CITIZEN.matcher(text);
        while (m.find()) found.add(new Candidate(m.start(), m.end(), "CITIZEN_ID", 4));
        m = TAX_CONTEXT.matcher(folded);
        while (m.find()) found.add(new Candidate(m.start(1), m.end(1), "TAX_ID", 2));
        m = ACCOUNT_CONTEXT.matcher(folded);
        while (m.find()) found.add(new Candidate(m.start(1), m.end(1), "ACCOUNT", 2));
        m = PHONE_MOBILE.matcher(text);
        while (m.find()) found.add(new Candidate(m.start(), m.end(), "PHONE", 5));
        m = PHONE_LANDLINE.matcher(text);
        while (m.find()) found.add(new Candidate(m.start(), m.end(), "PHONE", 5));
        found.sort(Comparator.comparingInt(Candidate::priority).thenComparingInt(Candidate::start).thenComparingInt(c -> -(c.end() - c.start())));
        List<Candidate> accepted = new ArrayList<>();
        for (Candidate c : found) {
            boolean overlap = false;
            for (Candidate a : accepted) if (c.start() < a.end() && a.start() < c.end()) { overlap = true; break; }
            if (!overlap) accepted.add(c);
        }
        accepted.sort(Comparator.comparingInt(Candidate::start));
        StringBuilder sb = new StringBuilder();
        for (Candidate c : accepted) sb.append(c.start()).append(':').append(c.end()).append(':').append(c.kind()).append(';');
        return sb.toString();
    }

    static String wordsCovering(List<String> words, int start, int end) {
        int pos = 0, first = -1, last = -1;
        for (int i = 0; i < words.size(); i++) {
            int ws = pos, we = pos + words.get(i).length();
            if (we > start && ws < end) { if (first < 0) first = i; last = i; }
            pos = we + 1;
        }
        return first < 0 ? "none" : first + "-" + last;
    }

    public static void main(String[] a) throws Exception {
        List<String> out = new ArrayList<>();
        for (String line : Files.readAllLines(Paths.get(a[0]), StandardCharsets.UTF_8)) {
            String[] p = line.split("\t", -1);
            if (p[0].equals("find")) out.add(find(p[1]));
            else {
                List<String> words = new ArrayList<>(Arrays.asList(p).subList(3, p.length));
                out.add(wordsCovering(words, Integer.parseInt(p[1]), Integer.parseInt(p[2])));
            }
        }
        Files.write(Paths.get(a[1]), out, StandardCharsets.UTF_8);
    }
}
