import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

/** Ban Java chay duoc cua PdfAutoLinks.classify (phien 18). Chay: java LinkTokensCheck.java <tep>: moi dong mot tu -> "start end uri" hoac "-". */
public class LinkTokensCheck {
    static final Pattern URL = Pattern.compile("^(https?://|www\\.)[^\\s<>\"]+$", Pattern.CASE_INSENSITIVE);
    static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9._%+\\-]+@[A-Za-z0-9.\\-]+\\.[A-Za-z]{2,}$");
    static final String LEADING = "([{<'\"“‘";
    static final String TRAILING = ".,;:!?)]}>'\"”’";
    static String classify(String word) {
        int s = 0, e = word.length();
        while (s < e && LEADING.indexOf(word.charAt(s)) >= 0) s++;
        while (e > s && TRAILING.indexOf(word.charAt(e - 1)) >= 0) e--;
        if (e <= s) return "-";
        String token = word.substring(s, e);
        if (URL.matcher(token).matches()) {
            String uri = token.toLowerCase(Locale.ROOT).startsWith("www.") ? "https://" + token : token;
            return s + " " + e + " " + uri;
        }
        if (EMAIL.matcher(token).matches()) return s + " " + e + " mailto:" + token;
        return "-";
    }
    public static void main(String[] a) throws Exception { for (String w : Files.readAllLines(Paths.get(a[0]), StandardCharsets.UTF_8)) System.out.println(classify(w)); }
}
