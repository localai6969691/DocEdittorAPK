"""Kiểm chứng TextWrapper (phiên 16): ngắt dòng theo quy tắc Unicode (UAX #14) thay vì theo khoảng trắng.

Vấn đề cũ: TextPdfBuilder tách đoạn bằng " " nên tiếng Trung / Nhật (không có dấu cách) là MỘT "từ" dài và tràn khỏi trang; từ dài quá khổ (URL) cũng tràn.
Cách làm: điểm được phép ngắt lấy từ BreakIterator dòng (Android: android.icu.text.BreakIterator, API 24+), thuật toán tham lam chọn điểm cuối cùng còn vừa
(TextWrapper.kt). WrapCheck.java là bản Java chạy được của thuật toán đó (chỉ NGUỒN điểm ngắt khác: java.text.BreakIterator thay cho ICU).

Bài kiểm này kiểm TÍNH CHẤT CỦA THUẬT TOÁN, không phụ thuộc bộ tách dòng đưa vào: Java trả cả danh sách điểm ngắt đã dùng, rồi với mỗi dòng
  1. không vượt khổ (đo bằng phông THẬT Noto Sans CJK, ImageFont.getlength của CẢ DÒNG, độc lập với bảng độ rộng từng ký tự đưa cho Java),
     trừ một ký tự đơn lẻ không thể chia;
  2. không mất / thêm / đổi thứ tự chữ; không khoảng trắng đầu/cuối dòng; không dòng rỗng;
  3. chỗ ngắt là MỘT điểm ngắt được cấp (sau tối đa khoảng trắng), hoặc là cắt cưỡng bức - mà chỉ được khi mảnh không-ngắt-được đó rộng hơn khổ;
  4. THAM LAM: kéo dòng tới điểm ngắt kế tiếp thì vượt khổ (không để dòng ngắn khi còn chỗ);
  5. cắt cưỡng bức không tách chữ khỏi dấu thanh (NFD).
Thêm: trên các mẫu tự nhiên (Trung, Nhật) không dòng nào bắt đầu bằng dấu đóng/dấu câu (tính chất của bộ tách dòng: JDK đạt; ICU của Android theo LB13 chặt hơn);
300 đoạn ngẫu nhiên x 3 khổ; THỬ ÂM TÍNH: thuật toán cũ (tách bằng dấu cách) trên đúng các đoạn CJK/URL/số liền phải làm tràn - nếu không, bài kiểm này
không phát hiện được lỗi gốc.
Chạy: python3 text_wrap_check.py   (cần java 11+, Pillow, phông Noto Sans CJK qua fontconfig)
"""
import os, random, re, subprocess, sys, unicodedata
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
from PIL import ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
SIZE = 12  # cỡ chữ thân bài của TextPdfBuilder (BODY_SIZE)
MAX_W = 515.0  # PAGE_WIDTH 595 - 2 * MARGIN 40


def find_font():
    r = subprocess.run(["fc-match", "-f", "%{file}", "Noto Sans CJK TC:style=Regular"], capture_output=True, text=True)
    path = r.stdout.strip()
    if path and os.path.exists(path):
        return path
    sys.exit("không tìm thấy phông Noto Sans CJK (cài fonts-noto-cjk)")


FONT = ImageFont.truetype(find_font(), SIZE)
CLOSING = set("。、，．）」』】〉》〕］｝!?！？：；,.:;)]}\u3001\u3002\u300d\u300f\uff09")


MARK_W = 0.0  # độ rộng bộ đo gán cho một dấu kết hợp: 0 với phông thật; >0 để kích hoạt đoạn bảo vệ "không tách chữ khỏi dấu" (xem main)


def char_width(ch):
    if unicodedata.combining(ch):
        return MARK_W
    return FONT.getlength(ch)


def real_width(s):
    return FONT.getlength(s)


def old_wrap(text, max_w):
    """Thuật toán CŨ của TextPdfBuilder.wrapText (tách bằng dấu cách) - để thử âm tính."""
    lines, cur = [], ""
    for word in text.split(" "):
        cand = word if not cur else cur + " " + word
        if not cur or real_width(cand) <= max_w:
            cur = cand
        else:
            lines.append(cur); cur = word
    if cur:
        lines.append(cur)
    return lines


ZH = "这是一个很长的中文段落，里面没有任何空格。它应该在合适的位置换行，而且句号、逗号、顿号和右括号（例如这个）不能出现在一行的开头；引号“像这样”也要保持完整。" * 3
JA = "日本語の長い文章です。「引用符」や（括弧）も、行頭に閉じ括弧や句読点が来ないように正しく処理されるはずです。ひらがなとカタカナとKanji漢字が混ざっています。" * 3
KO = "한국어 문장은 단어 사이에 공백이 있어서 공백에서 줄바꿈이 됩니다. 그러나 아주 긴 단어도 처리해야 합니다. " * 4
VI = "Xin chào các bạn, đây là một đoạn văn tiếng Việt khá dài để kiểm tra việc ngắt dòng theo từ; không có từ nào được cắt đôi giữa chữ và dấu thanh. " * 4
VI_NFD = unicodedata.normalize("NFD", VI)
EN = "A well-known state-of-the-art long-term solution, for example: this sentence is written in plain English with hyphenated words. " * 4
URL = "Xem tại https://example.com/" + "a-very-long-path-segment-without-any-space/" * 3 + "end?query=" + "0123456789" * 20 + " cảm ơn."
DIGITS = "0123456789" * 80
MIXED = "Chương 1: 概要 Overview — 本書では「OCR」と PDF の関係を説明します。Xem thêm tại mục 2.3 (trang 45), hoặc 参见第三章。" * 3
SPACES = "  hai   dấu   cách   liên   tiếp   và   đầu   dòng   có   dấu   cách  " * 6
SINGLE = "字"
NFD_LONG = unicodedata.normalize("NFD", "tiếngViệtđẹpquáởđâyhỡi" * 30)  # một "từ" 400+ ký tự, đầy dấu kết hợp, không dấu cách
SAMPLES = [("ZH", ZH), ("JA", JA), ("KO", KO), ("VI", VI), ("VI-NFD", VI_NFD), ("EN", EN), ("URL", URL), ("DIGITS", DIGITS),
           ("MIXED", MIXED), ("SPACES", SPACES), ("SINGLE", SINGLE), ("NFD-LONG", NFD_LONG)]

ALPHABETS = [list("这是一个很长的中文段落里面没有空格应该在合适位置换行文字测试"), list("日本語のテキストですひらがなカタカナ漢字文章"),
             ["Việt", "Nam", "xin", "chào", "đây", "là", "một", "đoạn", "văn", "ngắt", "dòng", "tiếng", "well-known", "OCR", "PDF", "12.345", "https://a.b/c-d"],
             ["。", "、", "，", "）", "（", "「", "」", " ", " "]]


def random_paragraph(rng):
    n = rng.randint(1, 120)
    parts = []
    for _ in range(n):
        alpha = rng.choice(ALPHABETS)
        parts.append(rng.choice(alpha))
        if len(alpha[0]) > 1 and rng.random() < 0.8:
            parts.append(" ")
    return "".join(parts).strip() or "字"


def first_piece(s):
    """Phần đầu của s tới chỗ có thể ngắt kiểu Latin: dấu cách hoặc sau dấu gạch nối."""
    m = re.match(r"\S*?-|\S+", s)
    return m.group(0) if m else s


def run_java(paras, max_w, tag):
    chars = sorted({ord(c) for p in paras for c in p})
    tpath, ppath, opath, bpath = (os.path.join(OUT, f"wrap_{tag}_{x}") for x in ("table.txt", "paras.txt", "out.txt", "bounds.txt"))
    with open(tpath, "w", encoding="utf-8") as f:
        for cp in chars:
            f.write(f"{cp}\t{char_width(chr(cp)):.5f}\n")
    with open(ppath, "w", encoding="utf-8") as f:
        f.write("\n".join(paras) + "\n")
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", os.path.join(HERE, "WrapCheck.java"), tpath, ppath, str(max_w), opath, bpath],
                       capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit("Java lỗi:\n" + r.stdout + r.stderr)
    out = [[] for _ in paras]
    with open(opath, encoding="utf-8") as f:
        for line in f.read().split("\n"):
            if line:
                i, t = line.split("\t", 1)
                out[int(i)].append(t)
    bounds = [[] for _ in paras]
    with open(bpath, encoding="utf-8") as f:
        for line in f.read().split("\n"):
            if line:
                i, t = line.split("\t", 1)
                bounds[int(i)] = [int(x) for x in t.split(",") if x != ""]
    return list(zip(out, bounds))


FAILS = []


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond:
        FAILS.append(what)
    return cond


def graphemes_of(line):
    """Số 'ký tự người đọc' (code point không tính dấu kết hợp)."""
    return sum(1 for ch in line if not unicodedata.combining(ch))


def table_width(s):
    return sum(char_width(c) for c in s)


def verify(text, lines, bounds, max_w):
    """Các tính chất của thuật toán (xem đầu tệp). Trả về danh sách vấn đề."""
    problems = []
    if not lines:
        return ["không có dòng nào"]
    n = len(text)
    bset = sorted(set(bounds) | {n})
    pos = 0
    spans = []
    for i, ln in enumerate(lines):
        while pos < n and text[pos].isspace():
            pos += 1
        if not text.startswith(ln, pos):
            return problems + [f"dòng {i} không phải đoạn con liên tiếp của văn bản gốc"]
        spans.append((pos, pos + len(ln)))
        pos += len(ln)
        if ln != ln.strip() or not ln:
            problems.append(f"dòng {i}: rỗng hoặc có khoảng trắng đầu/cuối")
        if real_width(ln) > max_w + 0.5 and graphemes_of(ln) > 1:
            problems.append(f"dòng {i}: rộng {real_width(ln):.1f} > {max_w} ({graphemes_of(ln)} ký tự)")
    if text[pos:].strip():
        problems.append("mất chữ ở cuối")
    for i, (a, e) in enumerate(spans):
        # (3) chỗ ngắt hợp lệ?
        if e < n:
            cands = [b for b in bset if b >= e and not text[e:b].strip()]
            on_boundary = bool(cands)
            first_b = next((b for b in bset if b > a), n)
            if not on_boundary:
                piece_w = table_width(text[a:first_b].rstrip())
                if not piece_w > max_w:
                    problems.append(f"dòng {i}: cắt cưỡng bức giữa mảnh vừa khổ ({piece_w:.1f} <= {max_w}) tại {e}")
                if e < n and unicodedata.combining(text[e]):
                    problems.append(f"dòng {i}: cắt rời chữ và dấu kết hợp tại {e}")
            else:
                # (4) tham lam: điểm ngắt kế tiếp sau điểm đã dùng phải làm dòng vượt khổ
                b = cands[0]
                nxt = next((x for x in bset if x > b), None)
                if nxt is not None:
                    w2 = table_width(text[a:nxt].rstrip())
                    if w2 <= max_w:
                        problems.append(f"dòng {i} chưa đầy: kéo tới điểm ngắt {nxt} vẫn vừa ({w2:.1f} <= {max_w})")
    strip = lambda s_: "".join(ch for ch in s_ if not ch.isspace())
    if strip("".join(lines)) != strip(text):
        problems.append("mất/thêm/đổi thứ tự chữ")
    return problems


def closing_at_line_start(lines):
    return [i for i, l in enumerate(lines) if i > 0 and l[0] in CLOSING]


def main():
    print("phông:", FONT.path, "cỡ", SIZE, "| khổ", MAX_W)
    paras = [t for _, t in SAMPLES]
    res = run_java(paras, MAX_W, "samples")
    for (name, text), (lines, bounds) in zip(SAMPLES, res):
        probs = verify(text, lines, bounds, MAX_W)
        check(not probs, f"{name}: {len(lines)} dòng, rộng nhất {max(real_width(l) for l in lines):.1f}/{MAX_W}" + (" — " + "; ".join(probs[:3]) if probs else ""))
    for name in ("ZH", "JA"):
        lines = res[[n for n, _ in SAMPLES].index(name)][0]
        check(not closing_at_line_start(lines), f"{name}: không dòng nào bắt đầu bằng dấu đóng ngoặc / dấu câu (bộ tách dòng JDK; ICU theo LB13 còn chặt hơn)")

    for mw in (120.0, 40.0):
        res2 = run_java(paras, mw, f"w{int(mw)}")
        bad = []
        for (name, text), (lines, bounds) in zip(SAMPLES, res2):
            bad += [f"{name}@{mw}: {p}" for p in verify(text, lines, bounds, mw)]
        check(not bad, f"khổ hẹp {mw}: {len(SAMPLES)} đoạn mẫu (có từ dài hơn khổ nên có cắt cưỡng bức)" + (" — " + "; ".join(bad[:3]) if bad else ""))

    rng = random.Random(20261009)
    rnd = [random_paragraph(rng) for _ in range(300)]
    for mw in (60.0, 200.0, MAX_W):
        resr = run_java(rnd, mw, f"rnd{int(mw)}")
        bad = []
        for text, (lines, bounds) in zip(rnd, resr):
            bad += [f"{p}  <- {text[:30]!r}" for p in verify(text, lines, bounds, mw)]
        check(not bad, f"300 đoạn ngẫu nhiên, khổ {mw}: không vượt khổ, không mất chữ, ngắt hợp lệ, tham lam" + (" — " + "; ".join(bad[:2]) if bad else ""))

    overflow = {}
    for name, text in SAMPLES:
        overflow[name] = sum(1 for l in old_wrap(text, MAX_W) if real_width(l) > MAX_W + 0.5)
    check(overflow["ZH"] > 0 and overflow["JA"] > 0 and overflow["URL"] > 0 and overflow["DIGITS"] > 0,
          f"thử âm tính: thuật toán CŨ làm tràn khổ ở ZH/JA/URL/DIGITS (số dòng tràn: ZH={overflow['ZH']}, JA={overflow['JA']}, URL={overflow['URL']}, DIGITS={overflow['DIGITS']}) — bài kiểm này phát hiện được lỗi gốc")
    check(overflow["VI"] == 0 and overflow["EN"] == 0 and overflow["KO"] == 0,
          "thuật toán cũ không tràn với văn bản có dấu cách (Việt/Anh/Hàn) — hành vi cũ ở đó không bị phá vỡ")

    # đoạn bảo vệ "không tách chữ khỏi dấu kết hợp": với phông thật dấu có độ rộng 0 nên không bao giờ bị kích hoạt; một bộ đo cho dấu độ rộng > 0
    # (phông thiếu glyph dấu, dấu rơi về phông dự phòng...) thì có. Thử với độ rộng dấu 4 - mọi chỗ cắt cưỡng bức phải rơi TRƯỚC một chữ cái, không trước dấu.
    global MARK_W
    MARK_W = 4.0
    try:
        for mw in (40.0, 120.0, MAX_W):
            (lines, bounds), = run_java([NFD_LONG], mw, f"marks{int(mw)}")
            probs = verify(NFD_LONG, lines, bounds, mw)
            starts = [i for i, l in enumerate(lines) if l and unicodedata.combining(l[0])]
            check(not probs and not starts, f"bộ đo cho dấu rộng 4, khổ {mw}: {len(lines)} dòng, không dòng nào bắt đầu bằng dấu kết hợp" + (" — " + "; ".join(probs[:2]) if probs else ""))
    finally:
        MARK_W = 0.0

    # thử âm tính 2: một bộ ngắt dòng sai (ngắt giữa chữ và dấu) phải bị bài kiểm bắt
    text = VI_NFD
    fake_lines = [text[i:i + 30] for i in range(0, len(text), 30)]
    check(any("dấu kết hợp" in p or "cắt cưỡng bức" in p or "không phải đoạn con" in p or "chưa đầy" in p for p in verify(text, fake_lines, [], MAX_W)),
          "thử âm tính: một kết quả cắt bừa 30 ký tự/dòng bị bài kiểm bắt")
    print("\nTAT CA DAT" if not FAILS else f"\nCO {len(FAILS)} LOI")
    sys.exit(1 if FAILS else 0)


if __name__ == "__main__":
    main()
