import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.*;
import java.util.*;
import java.util.regex.*;

/** Bản Java song song CÙNG THUẬT TOÁN của util/BackupSchedule.kt (phiên 20, 4.48.5). Lệnh qua stdin: NAME <ms> <múi giờ> | OURS <tên> | DEL <keep> <tên>... | DUE <last> <now> <ngày> */
public class BackupScheduleCheck {
    static final String PREFIX = "docscanner_auto_", SUFFIX = ".zip", STAMP = "yyyyMMdd_HHmmss";
    static final Pattern NAME = Pattern.compile("^docscanner_auto_([0-9]{8}_[0-9]{6})\\.zip$");
    static final long GRACE = 6L * 3600 * 1000;
    static String fileName(long t, TimeZone z) { SimpleDateFormat f = new SimpleDateFormat(STAMP, Locale.ROOT); f.setTimeZone(z); return PREFIX + f.format(new Date(t)) + SUFFIX; }
    static boolean isOurs(String n) {
        Matcher m = NAME.matcher(n); if (!m.find()) return false;
        SimpleDateFormat f = new SimpleDateFormat(STAMP, Locale.ROOT); f.setTimeZone(TimeZone.getTimeZone("UTC")); f.setLenient(false);
        try { return f.parse(m.group(1)) != null; } catch (ParseException e) { return false; }
    }
    static List<String> toDelete(List<String> names, int keep) {
        int k = Math.max(1, Math.min(30, keep));
        List<String> ours = new ArrayList<>(); for (String n : names) if (isOurs(n) && !ours.contains(n)) ours.add(n);
        ours.sort(Comparator.reverseOrder());
        return ours.size() > k ? new ArrayList<>(ours.subList(k, ours.size())) : new ArrayList<>();
    }
    static boolean isDue(long last, long now, int days) { return days > 0 && (last <= 0 || now - last >= days * 86400000L - GRACE); }
    public static void main(String[] a) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8)); String line;
        while ((line = in.readLine()) != null) {
            if (line.isEmpty()) continue; String[] p = line.split("\t", -1);
            switch (p[0]) {
                case "NAME": System.out.println(fileName(Long.parseLong(p[1]), TimeZone.getTimeZone(p[2]))); break;
                case "OURS": System.out.println(isOurs(p[1])); break;
                case "DEL": System.out.println(String.join("|", toDelete(Arrays.asList(p).subList(2, p.length), Integer.parseInt(p[1])))); break;
                case "DUE": System.out.println(isDue(Long.parseLong(p[1]), Long.parseLong(p[2]), Integer.parseInt(p[3]))); break;
            }
        }
    }
}
