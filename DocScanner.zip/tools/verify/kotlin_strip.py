"""Gỡ chú thích và nội dung chuỗi / ký tự khỏi mã Kotlin bằng MỘT lượt quét đúng chuẩn (dùng chung cho các bộ kiểm Kotlin, mục 4.57).
Lý do tồn tại: bản cũ dùng các biểu thức chính quy nối tiếp (gỡ /* */ rồi gỡ "..." ) nên chuỗi `"*/*"` (kiểu MIME) bị coi là mở đầu chú thích khối và xoá cả đoạn mã dài.
Quy tắc: chuỗi "..." (có \\ thoát), chuỗi thô \"\"\"...\"\"\", ký tự '...', chú thích dòng //, chú thích khối /* */ (Kotlin cho phép lồng nhau). Nội dung bị thay bằng khoảng trắng
(giữ nguyên xuống dòng) để số dòng không đổi. Chuỗi mẫu `${...}` giữ phần biểu thức bên trong nếu muốn; ở đây thay cả chuỗi bằng "" vì các bộ kiểm không cần nó."""

def strip(src):
    out = []; i = 0; n = len(src)
    while i < n:
        c = src[i]; nxt = src[i + 1] if i + 1 < n else ""
        if c == "/" and nxt == "/":                       # chú thích dòng
            while i < n and src[i] != "\n": i += 1
        elif c == "/" and nxt == "*":                     # chú thích khối, lồng nhau
            depth = 1; i += 2
            while i < n and depth:
                if src.startswith("/*", i): depth += 1; i += 2
                elif src.startswith("*/", i): depth -= 1; i += 2
                else:
                    if src[i] == "\n": out.append("\n")
                    i += 1
        elif src.startswith('"""', i):                    # chuỗi thô
            j = src.find('"""', i + 3)
            j = n if j < 0 else j + 3
            out.append('""' + "".join("\n" for ch in src[i:j] if ch == "\n")); i = j
        elif c == '"':                                    # chuỗi thường
            i += 1
            while i < n and src[i] != '"' and src[i] != "\n":
                i += 2 if src[i] == "\\" else 1
            if i < n and src[i] == '"': i += 1
            out.append('""')
        elif c == "'":                                    # ký tự
            j = i + 1
            if j < n and src[j] == "\\": j += 2
            else: j += 1
            if j < n and src[j] == "'": out.append("' '"); i = j + 1
            else: out.append(c); i += 1                   # dấu ' lạc (không phải ký tự): giữ nguyên
        else:
            out.append(c); i += 1
    return "".join(out)
