// Bản Java chạy được của PageEditorTools.cropRect / fitRect / Paper.portraitPixels (phiên 16). Dùng bởi page_tools_check.py.
// Vào: dòng "crop\tW\tH\tL\tT\tR\tB" hoặc "fit\tsrcW\tsrcH\tcanvasW\tcanvasH" hoặc "paper\twidthMm\theightMm". Ra: các số cách nhau tab.
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class PageToolsCheck {
    static float pct(float v) { return Math.min(45f, Math.max(0f, v)); }

    static int[] cropRect(int width, int height, float l, float t, float r, float b) {
        int left = (int) (width * pct(l) / 100f);
        int top = (int) (height * pct(t) / 100f);
        int right = (int) (width * pct(r) / 100f);
        int bottom = (int) (height * pct(b) / 100f);
        int w = Math.max(1, width - left - right);
        int h = Math.max(1, height - top - bottom);
        return new int[]{left, top, left + w, top + h};
    }

    static float[] fitRect(int srcW, int srcH, int canvasW, int canvasH) {
        float scale = Math.min((float) canvasW / srcW, (float) canvasH / srcH);
        float w = srcW * scale, h = srcH * scale;
        float x = (canvasW - w) / 2f, y = (canvasH - h) / 2f;
        return new float[]{x, y, x + w, y + h};
    }

    public static void main(String[] a) throws Exception {
        List<String> out = new ArrayList<>();
        for (String line : Files.readAllLines(Paths.get(a[0]), StandardCharsets.UTF_8)) {
            String[] p = line.split("\t");
            switch (p[0]) {
                case "crop": {
                    int[] r = cropRect(Integer.parseInt(p[1]), Integer.parseInt(p[2]), Float.parseFloat(p[3]), Float.parseFloat(p[4]), Float.parseFloat(p[5]), Float.parseFloat(p[6]));
                    out.add(r[0] + "\t" + r[1] + "\t" + r[2] + "\t" + r[3]); break;
                }
                case "fit": {
                    float[] r = fitRect(Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]), Integer.parseInt(p[4]));
                    out.add(r[0] + "\t" + r[1] + "\t" + r[2] + "\t" + r[3]); break;
                }
                case "paper": {
                    out.add(Math.round(Float.parseFloat(p[1]) / 25.4f * 200) + "\t" + Math.round(Float.parseFloat(p[2]) / 25.4f * 200)); break;
                }
                default: throw new IllegalArgumentException(line);
            }
        }
        Files.write(Paths.get(a[1]), out, StandardCharsets.UTF_8);
    }
}
