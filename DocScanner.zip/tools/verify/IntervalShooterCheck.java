import java.io.*;
import java.util.*;

/**
 * Java twin of app/.../util/IntervalShooter.kt (phiên 22, 4.49.7), plus a tiny simulator: one scenario per stdin line
 *   "<intervalMs> <maxShots> <tickStepMs> <durationMs> <stopAtMs|-1> <latencyMs,latencyMs,...>"   (latency -1 = the shot FAILS after 50 ms)
 * The simulator starts the shooter at t = 1000, ticks every tickStepMs like the Handler of CaptureActivity, saves each photo after the next latency
 * of the list (cycling), and prints "shots:t1,t2,..;finished:f1,..;running:0|1;count:n".
 */
public class IntervalShooterCheck {
    static class Shooter {
        final long intervalMs; final int maxShots; boolean running; int shots; boolean busy; long nextAt;
        Shooter(long i, int m) { intervalMs = i; maxShots = m; }
        void start(long now) { running = true; shots = 0; busy = false; nextAt = now; }
        void stop() { running = false; }
        boolean due(long now) { if (!running || busy) return false; if (shots >= maxShots) return false; return now >= nextAt; }
        void onShotStarted(long now) { busy = true; shots++; nextAt = now + intervalMs; }
        void onShotFinished() { busy = false; if (shots >= maxShots) running = false; }
    }

    public static void main(String[] a) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in)); String line;
        while ((line = r.readLine()) != null) {
            String[] f = line.trim().split(" ");
            long interval = Long.parseLong(f[0]); int max = Integer.parseInt(f[1]); long step = Long.parseLong(f[2]), duration = Long.parseLong(f[3]), stopAt = Long.parseLong(f[4]);
            String[] lat = f[5].split(","); Shooter s = new Shooter(interval, max);
            List<Long> starts = new ArrayList<>(), finishes = new ArrayList<>(); long finishAt = -1; int li = 0; boolean pendingOk = true;
            final long T0 = 1000; s.start(T0);
            for (long t = T0; t <= T0 + duration; t += step) {
                if (stopAt >= 0 && t >= T0 + stopAt && s.running) s.stop();
                if (finishAt >= 0 && t >= finishAt) { s.onShotFinished(); finishes.add(t); finishAt = -1; }
                if (s.due(t)) {
                    s.onShotStarted(t); starts.add(t);
                    long l = Long.parseLong(lat[li++ % lat.length]);
                    finishAt = t + (l < 0 ? 50 : l);
                }
            }
            StringBuilder sb = new StringBuilder("shots:");
            for (int i = 0; i < starts.size(); i++) sb.append(i > 0 ? "," : "").append(starts.get(i));
            sb.append(";finished:"); for (int i = 0; i < finishes.size(); i++) sb.append(i > 0 ? "," : "").append(finishes.get(i));
            sb.append(";running:").append(s.running ? 1 : 0).append(";count:").append(s.shots);
            System.out.println(sb);
        }
    }
}
