// Bản Java chạy được của TableExtractor, XlsxWriter, PptxWriter, TextExporters (+ DocxWriter.escape/paragraphsFromText) - phiên 16, mục 4.30.
// Dùng bởi export_check.py. Cùng thuật toán và cùng thứ tự, viết lại từng dòng từ Kotlin.
//   java ExportCheck.java table <vào> <ra>      vào: mỗi bảng là các dòng "L T R B chữ" (số thực), bảng cách nhau bằng dòng "==="; ra: mỗi hàng một dòng, ô cách nhau bằng \u001f; bảng cách nhau "==="
//   java ExportCheck.java xlsx  <vào> <ra.xlsx> vào: "SHEET\t<tên>" rồi các dòng "ROW\t<ô>\t<ô>..." (ô viết bằng \\uXXXX)
//   java ExportCheck.java pptx  <ra.pptx> <tệp.jpg,w,h,alt>...
//   java ExportCheck.java html|md <vào> <ra>    vào: "TITLE\t<tiêu đề>" rồi mỗi trang "PAGE\t<chữ>" (\\n và \\uXXXX)
//   java ExportCheck.java misc  <vào> <ra>      vào: "num\t<chữ>" | "col\t<n>" | "sheet\t<tên>\t<đã có1>|<đã có2>" ; ra: một dòng mỗi ca
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;
import java.util.zip.*;

public class ExportCheck {
    // ---------------- DocxWriter.escape / paragraphsFromText ----------------
    static final String PAGE_BREAK = "\uE000";
    static String escape(String text) {
        StringBuilder sb = new StringBuilder(text.length() + 16);
        for (int i = 0; i < text.length(); ) {
            int cp = text.codePointAt(i); i += Character.charCount(cp);
            boolean legal = cp == 0x9 || cp == 0xA || cp == 0xD || (cp >= 0x20 && cp <= 0xD7FF) || (cp >= 0xE000 && cp <= 0xFFFD) || (cp >= 0x10000 && cp <= 0x10FFFF);
            if (!legal) continue;
            if (cp == '&') sb.append("&amp;"); else if (cp == '<') sb.append("&lt;"); else if (cp == '>') sb.append("&gt;"); else sb.appendCodePoint(cp);
        }
        return sb.toString();
    }
    static List<String> paragraphsFromText(String text) {
        List<String> out = new ArrayList<>();
        for (String block : text.split("\\n\\s*\\n", -1)) {
            List<String> lines = new ArrayList<>();
            for (String l : block.split("\\R", -1)) { String t = l.strip(); if (!t.isEmpty()) lines.add(t); }
            if (lines.isEmpty()) continue;
            int longest = 0; for (String l : lines) longest = Math.max(longest, l.length());
            StringBuilder current = new StringBuilder();
            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i);
                if (line.equals(PAGE_BREAK)) { if (current.length() > 0) { out.add(current.toString()); current.setLength(0); } out.add(PAGE_BREAK); continue; }
                if (current.length() > 0) current.append(' ');
                current.append(line);
                boolean endsSentence = ".!?:;…".indexOf(line.charAt(line.length() - 1)) >= 0;
                boolean shortLine = line.length() < 0.7 * longest;
                if (endsSentence || shortLine || i == lines.size() - 1) { out.add(current.toString()); current.setLength(0); }
            }
            if (current.length() > 0) out.add(current.toString());
        }
        return out;
    }

    // ---------------- TextExporters ----------------
    static List<String> paragraphsOf(String page) { List<String> r = new ArrayList<>(); for (String p : paragraphsFromText(page)) if (!p.equals(PAGE_BREAK)) r.add(p); return r; }
    static String html(String title, List<String> pages) {
        StringBuilder sb = new StringBuilder();
        sb.append("<!DOCTYPE html>\n<html lang=\"vi\">\n<head>\n<meta charset=\"utf-8\">\n");
        sb.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n");
        sb.append("<title>").append(escape(title)).append("</title>\n");
        sb.append("<style>body{max-width:42em;margin:2em auto;padding:0 1em;font-family:Georgia,'Times New Roman',serif;line-height:1.6}");
        sb.append("section.page{border-top:1px solid #ccc;margin-top:2em;padding-top:1em}h2{font-size:1em;color:#666;font-weight:normal}</style>\n");
        sb.append("</head>\n<body>\n<h1>").append(escape(title)).append("</h1>\n");
        for (int i = 0; i < pages.size(); i++) {
            sb.append("<section class=\"page\" id=\"p").append(i + 1).append("\">\n<h2>Trang ").append(i + 1).append("</h2>\n");
            for (String p : paragraphsOf(pages.get(i))) sb.append("<p>").append(escape(p)).append("</p>\n");
            sb.append("</section>\n");
        }
        sb.append("</body>\n</html>\n");
        return sb.toString();
    }
    static final String INLINE_SPECIALS = "\\`*_[]<>&|";
    static String mdEscape(String text, boolean startOfBlock) {
        StringBuilder sb = new StringBuilder(text.length() + 8);
        for (int i = 0; i < text.length(); i++) { char c = text.charAt(i); if (INLINE_SPECIALS.indexOf(c) >= 0) sb.append('\\'); sb.append(c); }
        String out = sb.toString();
        if (startOfBlock) {
            Matcher m = Pattern.compile("^(#{1,6}|[+\\-=~]|[0-9]{1,9}[.)])").matcher(out);
            if (m.find()) {
                String marker = m.group();
                int at = (marker.charAt(0) >= '0' && marker.charAt(0) <= '9') ? marker.length() - 1 : 0;
                out = out.substring(0, at) + "\\" + out.substring(at);
            }
        }
        return out;
    }
    static String markdown(String title, List<String> pages) {
        StringBuilder sb = new StringBuilder();
        sb.append("# ").append(mdEscape(title.replace('\n', ' '), false)).append("\n\n");
        for (int i = 0; i < pages.size(); i++) {
            if (i > 0) sb.append("---\n\n");
            sb.append("## Trang ").append(i + 1).append("\n\n");
            for (String p : paragraphsOf(pages.get(i))) sb.append(mdEscape(p, true)).append("\n\n");
        }
        return sb.toString();
    }

    static String htmlChapters(String title, List<String[]> chapters) {   // moi phan tu: [tieu de, doan 1, doan 2, ...]
        StringBuilder sb = new StringBuilder();
        sb.append("<!DOCTYPE html>\n<html lang=\"vi\">\n<head>\n<meta charset=\"utf-8\">\n");
        sb.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n");
        sb.append("<title>").append(escape(title)).append("</title>\n");
        sb.append("<style>body{max-width:42em;margin:2em auto;padding:0 1em;font-family:Georgia,'Times New Roman',serif;line-height:1.6}");
        sb.append("section.chapter{border-top:1px solid #ccc;margin-top:2em;padding-top:1em}</style>\n");
        sb.append("</head>\n<body>\n<h1>").append(escape(title)).append("</h1>\n");
        for (int i = 0; i < chapters.size(); i++) {
            String[] ch = chapters.get(i);
            sb.append("<section class=\"chapter\" id=\"c").append(i + 1).append("\">\n<h2>").append(escape(ch[0])).append("</h2>\n");
            for (int k = 1; k < ch.length; k++) sb.append("<p>").append(escape(ch[k])).append("</p>\n");
            sb.append("</section>\n");
        }
        sb.append("</body>\n</html>\n");
        return sb.toString();
    }
    static String markdownChapters(String title, List<String[]> chapters) {
        StringBuilder sb = new StringBuilder();
        sb.append("# ").append(mdEscape(title.replace('\n', ' '), false)).append("\n\n");
        for (String[] ch : chapters) {
            sb.append("## ").append(mdEscape(ch[0].replace('\n', ' '), false)).append("\n\n");
            for (int k = 1; k < ch.length; k++) sb.append(mdEscape(ch[k], true)).append("\n\n");
        }
        return sb.toString();
    }

    // ---------------- TableExtractor ----------------
    record Word(String text, float left, float top, float right, float bottom) { float centerY() { return (top + bottom) / 2f; } float height() { return bottom - top; } }
    record Cell(float left, float right, String text) {}
    static float median(List<Float> v) { List<Float> s = new ArrayList<>(v); Collections.sort(s); return s.size() % 2 == 1 ? s.get(s.size() / 2) : (s.get(s.size() / 2 - 1) + s.get(s.size() / 2)) / 2f; }
    static List<List<String>> oneColumn(List<List<Cell>> rows) {
        List<List<String>> out = new ArrayList<>();
        for (List<Cell> r : rows) { StringBuilder sb = new StringBuilder(); for (int i = 0; i < r.size(); i++) { if (i > 0) sb.append(' '); sb.append(r.get(i).text()); } out.add(List.of(sb.toString())); }
        return out;
    }
    static float boundaryIn(int[] coverage, int from, int to, int minBuckets, float minX, float step) {
        int bestStart = -1, bestLen = 0, s = -1;
        for (int k = from; k <= to; k++) {
            boolean zero = k < to && coverage[k] == 0;
            if (zero && s < 0) s = k;
            if (!zero && s >= 0) { if (k - s > bestLen) { bestLen = k - s; bestStart = s; } s = -1; }
        }
        return bestLen >= minBuckets ? minX + bestStart * step : minX + (from + to) / 2f * step;
    }
    static List<Float> findBoundaries(List<List<Cell>> rows, float minX, float maxX, float medianH) {
        float step = Math.max(1f, medianH / 10f);
        int buckets = (int) ((maxX - minX) / step) + 2;
        int[] coverage = new int[buckets];
        for (List<Cell> r : rows) {
            boolean[] seen = new boolean[buckets];
            for (Cell cell : r) {
                int a = Math.max(0, Math.min(buckets - 1, (int) ((cell.left() - minX) / step)));
                int b = Math.max(0, Math.min(buckets - 1, (int) ((cell.right() - minX) / step)));
                for (int k = a; k <= b; k++) seen[k] = true;
            }
            for (int k = 0; k < buckets; k++) if (seen[k]) coverage[k]++;
        }
        int tolerance = (int) (0.1f * rows.size());
        int firstUsed = -1, lastUsed = -1;
        for (int k = 0; k < buckets; k++) if (coverage[k] > tolerance) { if (firstUsed < 0) firstUsed = k; lastUsed = k; }
        List<Float> boundaries = new ArrayList<>();
        if (firstUsed < 0) return boundaries;
        int minGutterBuckets = (int) Math.ceil((double) (0.8f * medianH / step));
        int runStart = -1;
        for (int k = firstUsed; k <= lastUsed + 1; k++) {
            boolean free = k <= lastUsed && coverage[k] <= tolerance;
            if (free && runStart < 0) runStart = k;
            if (!free && runStart >= 0) {
                if (runStart > firstUsed && k - runStart >= minGutterBuckets) boundaries.add(boundaryIn(coverage, runStart, k, minGutterBuckets, minX, step));
                runStart = -1;
            }
        }
        return boundaries;
    }
    static List<List<String>> extract(List<Word> words) {
        List<Word> usable = new ArrayList<>();
        for (Word w : words) if (!w.text().isBlank() && w.height() > 0f && w.right() >= w.left()) usable.add(w);
        if (usable.isEmpty()) return new ArrayList<>();
        List<Float> hs = new ArrayList<>(); for (Word w : usable) hs.add(w.height());
        float medianH = median(hs);
        List<Word> sorted = new ArrayList<>(usable); sorted.sort(Comparator.comparing(Word::centerY));
        List<List<Word>> rowWords = new ArrayList<>(); float rowCenter = 0f;
        for (Word w : sorted) {
            if (rowWords.isEmpty() || w.centerY() - rowCenter > 0.6f * medianH) { List<Word> n = new ArrayList<>(); n.add(w); rowWords.add(n); rowCenter = w.centerY(); }
            else { List<Word> row = rowWords.get(rowWords.size() - 1); row.add(w); double sum = 0; for (Word x : row) sum += (double) x.centerY(); rowCenter = (float) sum / row.size(); }
        }
        float cellGap = 0.8f * medianH;
        List<List<Cell>> rows = new ArrayList<>();
        for (List<Word> ws : rowWords) {
            List<Word> ordered = new ArrayList<>(ws); ordered.sort(Comparator.comparing(Word::left));
            List<Cell> cells = new ArrayList<>(); int start = 0;
            for (int i = 1; i <= ordered.size(); i++) {
                if (i == ordered.size() || ordered.get(i).left() - ordered.get(i - 1).right() > cellGap) {
                    List<Word> part = ordered.subList(start, i); float maxR = part.get(0).right(); StringBuilder sb = new StringBuilder();
                    for (int k = 0; k < part.size(); k++) { maxR = Math.max(maxR, part.get(k).right()); if (k > 0) sb.append(' '); sb.append(part.get(k).text()); }
                    cells.add(new Cell(part.get(0).left(), maxR, sb.toString())); start = i;
                }
            }
            rows.add(cells);
        }
        List<List<Cell>> tableRows = new ArrayList<>(); for (List<Cell> r : rows) if (r.size() >= 2) tableRows.add(r);
        if (tableRows.size() < 2) return oneColumn(rows);
        float minX = Float.MAX_VALUE, maxX = -Float.MAX_VALUE; for (Word w : usable) { minX = Math.min(minX, w.left()); maxX = Math.max(maxX, w.right()); }
        List<Float> boundaries = findBoundaries(tableRows, minX, maxX, medianH);
        if (boundaries.isEmpty()) return oneColumn(rows);
        int columns = boundaries.size() + 1;
        List<List<String>> grid = new ArrayList<>();
        for (List<Cell> r : rows) {
            StringBuilder[] line = new StringBuilder[columns]; for (int i = 0; i < columns; i++) line[i] = new StringBuilder();
            for (Cell cell : r) {
                int col = 0; for (float bnd : boundaries) if (bnd <= cell.left()) col++;
                if (line[col].length() > 0) line[col].append(' ');
                line[col].append(cell.text());
            }
            List<String> row = new ArrayList<>(); for (StringBuilder sb : line) row.add(sb.toString()); grid.add(row);
        }
        return grid;
    }

    // ---------------- XlsxWriter ----------------
    static String asNumber(String text) {
        String t = text.strip();
        if (!t.matches("-?(0|[1-9][0-9]{0,14})")) return null;
        if (t.equals("-0")) return null;
        return Long.toString(Long.parseLong(t));
    }
    static String columnName(int index) {
        int n = index; StringBuilder sb = new StringBuilder();
        do { sb.insert(0, (char) ('A' + n % 26)); n = n / 26 - 1; } while (n >= 0);
        return sb.toString();
    }
    static String safeSheetName(String name, Set<String> taken) {
        String base = edges(name.replaceAll("[\\[\\]:*?/\\\\]", " ")); if (base.isEmpty()) base = "Sheet";
        if (base.length() > 31) { base = edges(base.substring(0, 31)); if (base.isEmpty()) base = "Sheet"; }
        Set<String> lower = new HashSet<>(); for (String t : taken) lower.add(t.toLowerCase());
        String candidate = base; int n = 2;
        while (lower.contains(candidate.toLowerCase())) {
            String suffix = " (" + n + ")";
            String head = base.length() > 31 - suffix.length() ? base.substring(0, 31 - suffix.length()) : base;
            candidate = head.stripTrailing() + suffix; n++;
        }
        return candidate;
    }
    static String edges(String s) { int a = 0, b = s.length(); while (a < b && (Character.isWhitespace(s.charAt(a)) || s.charAt(a) == '\'')) a++; while (b > a && (Character.isWhitespace(s.charAt(b - 1)) || s.charAt(b - 1) == '\'')) b--; return s.substring(a, b); }
    static String trimQuotes(String s) { int a = 0, b = s.length(); while (a < b && s.charAt(a) == '\'') a++; while (b > a && s.charAt(b - 1) == '\'') b--; return s.substring(a, b); }
    static final String XML_HEAD = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>";
    static final String NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
    static String sheetXml(List<List<String>> rows) {
        int width = 0; for (List<String> r : rows) width = Math.max(width, r.size());
        StringBuilder sb = new StringBuilder();
        sb.append(XML_HEAD).append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
        if (width > 0) {
            sb.append("<cols>");
            for (int c = 0; c < width; c++) {
                int longest = 0; for (List<String> r : rows) longest = Math.max(longest, c < r.size() ? r.get(c).length() : 0);
                int w = Math.max(8, Math.min(60, longest)) + 2;
                sb.append("<col min=\"").append(c + 1).append("\" max=\"").append(c + 1).append("\" width=\"").append(w).append("\" customWidth=\"1\"/>");
            }
            sb.append("</cols>");
        }
        sb.append("<sheetData>");
        for (int r = 0; r < rows.size(); r++) {
            sb.append("<row r=\"").append(r + 1).append("\">");
            List<String> row = rows.get(r);
            for (int c = 0; c < row.size(); c++) {
                String text = row.get(c); if (text.isEmpty()) continue;
                String ref = columnName(c) + (r + 1); String number = asNumber(text);
                if (number != null) sb.append("<c r=\"").append(ref).append("\"><v>").append(number).append("</v></c>");
                else sb.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(escape(text)).append("</t></is></c>");
            }
            sb.append("</row>");
        }
        sb.append("</sheetData></worksheet>");
        return sb.toString();
    }
    static void put(ZipOutputStream zip, String name, byte[] bytes) throws IOException { zip.putNextEntry(new ZipEntry(name)); zip.write(bytes); zip.closeEntry(); }
    static void put(ZipOutputStream zip, String name, String content) throws IOException { put(zip, name, content.getBytes(StandardCharsets.UTF_8)); }
    static void writeXlsx(List<String> sheetNames, List<List<List<String>>> sheets, File out) throws IOException {
        if (sheets.isEmpty()) { sheets = new ArrayList<>(); sheets.add(new ArrayList<>()); sheetNames = new ArrayList<>(); sheetNames.add("Sheet1"); }
        List<String> names = new ArrayList<>(); for (String n : sheetNames) names.add(safeSheetName(n, new HashSet<>(names)));
        try (ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(out))) {
            StringBuilder overrides = new StringBuilder();
            for (int i = 0; i < sheets.size(); i++) overrides.append("<Override PartName=\"/xl/worksheets/sheet").append(i + 1).append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
            put(zip, "[Content_Types].xml", XML_HEAD + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" + overrides + "</Types>");
            put(zip, "_rels/.rels", XML_HEAD + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"" + NS_REL + "/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            StringBuilder sh = new StringBuilder(); for (int i = 0; i < names.size(); i++) sh.append("<sheet name=\"").append(escape(names.get(i))).append("\" sheetId=\"").append(i + 1).append("\" r:id=\"rId").append(i + 1).append("\"/>");
            put(zip, "xl/workbook.xml", XML_HEAD + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"" + NS_REL + "\"><sheets>" + sh + "</sheets></workbook>");
            StringBuilder rl = new StringBuilder(); for (int i = 0; i < sheets.size(); i++) rl.append("<Relationship Id=\"rId").append(i + 1).append("\" Type=\"").append(NS_REL).append("/worksheet\" Target=\"worksheets/sheet").append(i + 1).append(".xml\"/>");
            put(zip, "xl/_rels/workbook.xml.rels", XML_HEAD + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" + rl + "<Relationship Id=\"rId" + (sheets.size() + 1) + "\" Type=\"" + NS_REL + "/styles\" Target=\"styles.xml\"/></Relationships>");
            put(zip, "xl/styles.xml", XML_HEAD + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                "<fonts count=\"1\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
                "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>" +
                "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/></cellXfs></styleSheet>");
            for (int i = 0; i < sheets.size(); i++) put(zip, "xl/worksheets/sheet" + (i + 1) + ".xml", sheetXml(sheets.get(i)));
        }
    }

    // ---------------- PptxWriter ----------------
    static final long LONGEST = 12_192_000L;
    static final String NS_A = "http://schemas.openxmlformats.org/drawingml/2006/main", NS_R = NS_REL, NS_P = "http://schemas.openxmlformats.org/presentationml/2006/main";
    static final String GROUP_PROPS = "<p:nvGrpSpPr><p:cNvPr id=\"1\" name=\"\"/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x=\"0\" y=\"0\"/><a:ext cx=\"0\" cy=\"0\"/><a:chOff x=\"0\" y=\"0\"/><a:chExt cx=\"0\" cy=\"0\"/></a:xfrm></p:grpSpPr>";
    static long[] slideSize(int w, int h) { return w >= h ? new long[]{LONGEST, Math.max(1L, LONGEST * h / w)} : new long[]{Math.max(1L, LONGEST * w / h), LONGEST}; }
    static long[] fit(int w, int h, long sx, long sy) {
        long cx, cy;
        if ((long) w * sy >= (long) h * sx) { cx = sx; cy = Math.max(1L, sx * h / w); } else { cy = sy; cx = Math.max(1L, sy * w / h); }
        return new long[]{(sx - cx) / 2, (sy - cy) / 2, cx, cy};
    }
    static String repeat(String s, int n) { return s.repeat(n); }
    static String rels(String[][] items) { StringBuilder sb = new StringBuilder(XML_HEAD + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"); for (String[] it : items) sb.append("<Relationship Id=\"").append(it[0]).append("\" Type=\"").append(NS_REL).append("/").append(it[1]).append("\" Target=\"").append(it[2]).append("\"/>"); return sb.append("</Relationships>").toString(); }
    static void writePptx(List<String[]> slides, File out) throws IOException {
        // slides: {path, w, h, alt}
        int w0 = Integer.parseInt(slides.get(0)[1]), h0 = Integer.parseInt(slides.get(0)[2]);
        long[] size = slideSize(w0, h0); long cx = size[0], cy = size[1];
        String fills = repeat("<a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill>", 3), lines = repeat("<a:ln w=\"6350\"><a:solidFill><a:schemeClr val=\"phClr\"/></a:solidFill></a:ln>", 3);
        String theme = XML_HEAD + "<a:theme xmlns:a=\"" + NS_A + "\" name=\"Office Theme\"><a:themeElements>" +
            "<a:clrScheme name=\"Office\"><a:dk1><a:sysClr val=\"windowText\" lastClr=\"000000\"/></a:dk1><a:lt1><a:sysClr val=\"window\" lastClr=\"FFFFFF\"/></a:lt1>" +
            "<a:dk2><a:srgbClr val=\"44546A\"/></a:dk2><a:lt2><a:srgbClr val=\"E7E6E6\"/></a:lt2>" +
            "<a:accent1><a:srgbClr val=\"4472C4\"/></a:accent1><a:accent2><a:srgbClr val=\"ED7D31\"/></a:accent2><a:accent3><a:srgbClr val=\"A5A5A5\"/></a:accent3>" +
            "<a:accent4><a:srgbClr val=\"FFC000\"/></a:accent4><a:accent5><a:srgbClr val=\"5B9BD5\"/></a:accent5><a:accent6><a:srgbClr val=\"70AD47\"/></a:accent6>" +
            "<a:hlink><a:srgbClr val=\"0563C1\"/></a:hlink><a:folHlink><a:srgbClr val=\"954F72\"/></a:folHlink></a:clrScheme>" +
            "<a:fontScheme name=\"Office\"><a:majorFont><a:latin typeface=\"Calibri Light\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:majorFont>" +
            "<a:minorFont><a:latin typeface=\"Calibri\"/><a:ea typeface=\"\"/><a:cs typeface=\"\"/></a:minorFont></a:fontScheme>" +
            "<a:fmtScheme name=\"Office\"><a:fillStyleLst>" + fills + "</a:fillStyleLst><a:lnStyleLst>" + lines + "</a:lnStyleLst>" +
            "<a:effectStyleLst>" + repeat("<a:effectStyle><a:effectLst/></a:effectStyle>", 3) + "</a:effectStyleLst><a:bgFillStyleLst>" + fills + "</a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>";
        String master = XML_HEAD + "<p:sldMaster xmlns:a=\"" + NS_A + "\" xmlns:r=\"" + NS_R + "\" xmlns:p=\"" + NS_P + "\"><p:cSld><p:bg><p:bgRef idx=\"1001\"><a:schemeClr val=\"bg1\"/></p:bgRef></p:bg><p:spTree>" + GROUP_PROPS + "</p:spTree></p:cSld>" +
            "<p:clrMap bg1=\"lt1\" tx1=\"dk1\" bg2=\"lt2\" tx2=\"dk2\" accent1=\"accent1\" accent2=\"accent2\" accent3=\"accent3\" accent4=\"accent4\" accent5=\"accent5\" accent6=\"accent6\" hlink=\"hlink\" folHlink=\"folHlink\"/>" +
            "<p:sldLayoutIdLst><p:sldLayoutId id=\"2147483649\" r:id=\"rId1\"/></p:sldLayoutIdLst></p:sldMaster>";
        String layout = XML_HEAD + "<p:sldLayout xmlns:a=\"" + NS_A + "\" xmlns:r=\"" + NS_R + "\" xmlns:p=\"" + NS_P + "\" type=\"blank\" preserve=\"1\"><p:cSld name=\"Blank\"><p:spTree>" + GROUP_PROPS + "</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>";
        try (ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(out))) {
            StringBuilder so = new StringBuilder(); for (int i = 0; i < slides.size(); i++) so.append("<Override PartName=\"/ppt/slides/slide").append(i + 1).append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slide+xml\"/>");
            put(zip, "[Content_Types].xml", XML_HEAD + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/><Default Extension=\"jpeg\" ContentType=\"image/jpeg\"/>" +
                "<Override PartName=\"/ppt/presentation.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml\"/>" +
                "<Override PartName=\"/ppt/slideMasters/slideMaster1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml\"/>" +
                "<Override PartName=\"/ppt/slideLayouts/slideLayout1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml\"/>" +
                "<Override PartName=\"/ppt/theme/theme1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.theme+xml\"/>" + so + "</Types>");
            put(zip, "_rels/.rels", rels(new String[][]{{"rId1", "officeDocument", "ppt/presentation.xml"}}));
            StringBuilder ids = new StringBuilder(); for (int i = 0; i < slides.size(); i++) ids.append("<p:sldId id=\"").append(256 + i).append("\" r:id=\"rId").append(i + 2).append("\"/>");
            put(zip, "ppt/presentation.xml", XML_HEAD + "<p:presentation xmlns:a=\"" + NS_A + "\" xmlns:r=\"" + NS_R + "\" xmlns:p=\"" + NS_P + "\"><p:sldMasterIdLst><p:sldMasterId id=\"2147483648\" r:id=\"rId1\"/></p:sldMasterIdLst><p:sldIdLst>" + ids + "</p:sldIdLst><p:sldSz cx=\"" + cx + "\" cy=\"" + cy + "\"/><p:notesSz cx=\"6858000\" cy=\"9144000\"/></p:presentation>");
            String[][] pr = new String[slides.size() + 2][]; pr[0] = new String[]{"rId1", "slideMaster", "slideMasters/slideMaster1.xml"};
            for (int i = 0; i < slides.size(); i++) pr[i + 1] = new String[]{"rId" + (i + 2), "slide", "slides/slide" + (i + 1) + ".xml"};
            pr[slides.size() + 1] = new String[]{"rId" + (slides.size() + 2), "theme", "theme/theme1.xml"};
            put(zip, "ppt/_rels/presentation.xml.rels", rels(pr));
            put(zip, "ppt/slideMasters/slideMaster1.xml", master);
            put(zip, "ppt/slideMasters/_rels/slideMaster1.xml.rels", rels(new String[][]{{"rId1", "slideLayout", "../slideLayouts/slideLayout1.xml"}, {"rId2", "theme", "../theme/theme1.xml"}}));
            put(zip, "ppt/slideLayouts/slideLayout1.xml", layout);
            put(zip, "ppt/slideLayouts/_rels/slideLayout1.xml.rels", rels(new String[][]{{"rId1", "slideMaster", "../slideMasters/slideMaster1.xml"}}));
            put(zip, "ppt/theme/theme1.xml", theme);
            for (int i = 0; i < slides.size(); i++) {
                String[] s = slides.get(i); int w = Integer.parseInt(s[1]), h = Integer.parseInt(s[2]); long[] f = fit(w, h, cx, cy);
                String xml = XML_HEAD + "<p:sld xmlns:a=\"" + NS_A + "\" xmlns:r=\"" + NS_R + "\" xmlns:p=\"" + NS_P + "\"><p:cSld><p:spTree>" + GROUP_PROPS +
                    "<p:pic><p:nvPicPr><p:cNvPr id=\"2\" name=\"Trang " + (i + 1) + "\" descr=\"" + escape(s[3]).replace("\"", "&quot;") + "\"/><p:cNvPicPr><a:picLocks noChangeAspect=\"1\"/></p:cNvPicPr><p:nvPr/></p:nvPicPr>" +
                    "<p:blipFill><a:blip r:embed=\"rId2\"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x=\"" + f[0] + "\" y=\"" + f[1] + "\"/><a:ext cx=\"" + f[2] + "\" cy=\"" + f[3] + "\"/></a:xfrm><a:prstGeom prst=\"rect\"><a:avLst/></a:prstGeom></p:spPr></p:pic></p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>";
                put(zip, "ppt/slides/slide" + (i + 1) + ".xml", xml);
                put(zip, "ppt/slides/_rels/slide" + (i + 1) + ".xml.rels", rels(new String[][]{{"rId1", "slideLayout", "../slideLayouts/slideLayout1.xml"}, {"rId2", "image", "../media/image" + (i + 1) + ".jpeg"}}));
                put(zip, "ppt/media/image" + (i + 1) + ".jpeg", Files.readAllBytes(Paths.get(s[0])));
            }
        }
    }

    // ---------------- driver ----------------
    static String unesc(String s) {
        StringBuilder o = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char d = s.charAt(i + 1);
                if (d == '\\') { o.append('\\'); i++; } else if (d == 'n') { o.append('\n'); i++; }
                else if (d == 'u') { o.append((char) Integer.parseInt(s.substring(i + 2, i + 6), 16)); i += 5; } else o.append(c);
            } else o.append(c);
        }
        return o.toString();
    }

    public static void main(String[] a) throws Exception {
        switch (a[0]) {
            case "table": {
                List<String> out = new ArrayList<>(); List<Word> cur = new ArrayList<>();
                List<String> lines = Files.readAllLines(Paths.get(a[1]), StandardCharsets.UTF_8); lines.add("===");
                for (String l : lines) {
                    if (l.equals("===")) {
                        for (List<String> row : extract(cur)) out.add(String.join("\u001f", row));
                        out.add("==="); cur = new ArrayList<>();
                    } else if (!l.isEmpty()) {
                        String[] p = l.split(" ", 5);
                        cur.add(new Word(p[4], Float.parseFloat(p[0]), Float.parseFloat(p[1]), Float.parseFloat(p[2]), Float.parseFloat(p[3])));
                    }
                }
                out.remove(out.size() - 1); out.add("===");
                Files.write(Paths.get(a[2]), out, StandardCharsets.UTF_8); break;
            }
            case "xlsx": {
                List<String> names = new ArrayList<>(); List<List<List<String>>> sheets = new ArrayList<>();
                for (String l : Files.readAllLines(Paths.get(a[1]), StandardCharsets.UTF_8)) {
                    String[] p = l.split("\t", -1);
                    if (p[0].equals("SHEET")) { names.add(unesc(p[1])); sheets.add(new ArrayList<>()); }
                    else if (p[0].equals("ROW")) { List<String> row = new ArrayList<>(); for (int i = 1; i < p.length; i++) row.add(unesc(p[i])); sheets.get(sheets.size() - 1).add(row); }
                }
                writeXlsx(names, sheets, new File(a[2])); break;
            }
            case "pptx": {
                List<String[]> slides = new ArrayList<>();
                for (int i = 2; i < a.length; i++) slides.add(a[i].split(",", 4));
                writePptx(slides, new File(a[1])); break;
            }
            case "html": case "md": {
                String title = ""; List<String> pages = new ArrayList<>();
                for (String l : Files.readAllLines(Paths.get(a[1]), StandardCharsets.UTF_8)) {
                    int tab = l.indexOf('\t'); if (tab < 0) continue; String kind = l.substring(0, tab), val = unesc(l.substring(tab + 1));
                    if (kind.equals("TITLE")) title = val; else if (kind.equals("PAGE")) pages.add(val);
                }
                Files.write(Paths.get(a[2]), (a[0].equals("html") ? html(title, pages) : markdown(title, pages)).getBytes(StandardCharsets.UTF_8)); break;
            }
            case "chtml": case "cmd": {   // tep vao: TITLE<TAB>ten sach; CHAP<TAB>ten chuong; PARA<TAB>doan (them vao chuong hien tai)
                String title = ""; List<List<String>> chs = new ArrayList<>();
                for (String l : Files.readAllLines(Paths.get(a[1]), StandardCharsets.UTF_8)) {
                    int tab = l.indexOf('\t'); if (tab < 0) continue; String kind = l.substring(0, tab), val = unesc(l.substring(tab + 1));
                    if (kind.equals("TITLE")) title = val; else if (kind.equals("CHAP")) { List<String> c = new ArrayList<>(); c.add(val); chs.add(c); } else if (kind.equals("PARA")) chs.get(chs.size() - 1).add(val);
                }
                List<String[]> arr = new ArrayList<>(); for (List<String> c : chs) arr.add(c.toArray(new String[0]));
                Files.write(Paths.get(a[2]), (a[0].equals("chtml") ? htmlChapters(title, arr) : markdownChapters(title, arr)).getBytes(StandardCharsets.UTF_8)); break;
            }
            case "misc": {
                List<String> out = new ArrayList<>();
                for (String l : Files.readAllLines(Paths.get(a[1]), StandardCharsets.UTF_8)) {
                    String[] p = l.split("\t", -1);
                    switch (p[0]) {
                        case "num": { String n = asNumber(unesc(p[1])); out.add(n == null ? "text" : n); break; }
                        case "col": out.add(columnName(Integer.parseInt(p[1]))); break;
                        case "sheet": { Set<String> taken = new HashSet<>(); if (p.length > 2 && !p[2].isEmpty()) for (String t : p[2].split("\\|", -1)) taken.add(unesc(t)); out.add(safeSheetName(unesc(p[1]), taken)); break; }
                        default: throw new IllegalArgumentException(l);
                    }
                }
                Files.write(Paths.get(a[2]), out, StandardCharsets.UTF_8); break;
            }
            default: throw new IllegalArgumentException(a[0]);
        }
    }
}
