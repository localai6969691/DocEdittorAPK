"""Kiểm chứng WatchFolder (phiên 18): chọn tệp MỚI trong thư mục theo dõi.

WatchFolderCheck.java là bản Java chạy được của util/WatchFolder.kt. So với bản tham chiếu Python viết riêng trên 300 danh sách ngẫu nhiên (tên có số, tên ẩn / tạm, loại
tệp lạ, tệp rỗng, tệp mới ghi dở, tệp đã thấy) cộng các ca viết tay: mỗi tệp chỉ đề nghị một lần; tệp đã thấy không bao giờ quay lại; tệp ghi dở (< 3 giây) hoãn tới lần sau;
tệp tạm / ẩn / rỗng / loại lạ không bao giờ được đề nghị; thứ tự (thời gian sửa, rồi tên tự nhiên); `remember` giữ thứ tự, bỏ trùng, bỏ mã CŨ NHẤT khi vượt trần.
Chạy: python3 watch_folder_check.py   (cần java 11+)
"""
import os, random, re, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); FAILS = []
def check(c, w):
    print(("ok  " if c else "LOI"), w)
    if not c: FAILS.append(w)
tmp = tempfile.mkdtemp(prefix="watch_")
def java(mode, text):
    p = os.path.join(tmp, "in.txt"); open(p, "w", encoding="utf-8").write(text)
    r = subprocess.run(["java", os.path.join(HERE, "WatchFolderCheck.java"), mode, p], capture_output=True, text=True)
    if r.returncode != 0: print(r.stderr[-600:])
    return r.stdout.rstrip("\n").split("\n") if r.stdout.strip() else []
IMG = {"jpg", "jpeg", "png", "webp", "heic", "heif", "bmp", "gif"}; TEMP = (".tmp", ".part", ".crdownload", ".pending", ".download")
def ref_kind(name, mime):
    n = name.lower()
    if n.startswith(".") or n.startswith(".trashed") or n.endswith(TEMP): return None
    ext = n.rsplit(".", 1)[1] if "." in n else ""; m = mime.lower()
    if m == "application/pdf" or ext == "pdf": return "PDF"
    if m.startswith("image/") or ext in IMG: return "IMAGE" if (m.startswith("image/") or m == "application/octet-stream" or m == "") else None
    return None
def nat_key(n): return ([(0, int(t), "") if t[0].isdigit() else (1, 0, t.lower()) for t in re.findall(r"[0-9]+|[^0-9]+", n)], n)
def java_batch(mode, texts):
    p = os.path.join(tmp, "batch.txt"); open(p, "w", encoding="utf-8").write("".join(t + "===\n" for t in texts))
    r = subprocess.run(["java", os.path.join(HERE, "WatchFolderCheck.java"), mode, p], capture_output=True, text=True)
    if r.returncode != 0: print(r.stderr[-600:])
    out, cur = [], []
    for l in r.stdout.split("\n")[:-1]:
        if l == "===": out.append(cur); cur = []
        else: cur.append(l)
    return out
def pick_text(entries, seen, now, settle=3000): return f"{now} {settle}\n" + "|".join(seen) + "\n" + "".join(f"{i}\t{n}\t{m}\t{t}\t{s}\n" for i, n, m, t, s in entries)
def ref_remember(cap, seen, add):
    allv = list(dict.fromkeys(seen + add)); return allv[-cap:] if len(allv) > cap else allv
def ref_pick(entries, seen, now, settle):
    ok = [e for e in entries if e[0] not in seen and ref_kind(e[1], e[2]) and e[4] > 0 and now - e[3] >= settle]
    return [(e[0], ref_kind(e[1], e[2])) for e in sorted(ok, key=lambda e: (e[3], nat_key(e[1])))]
def run_pick(entries, seen, now, settle=3000):
    text = f"{now} {settle}\n" + "|".join(seen) + "\n" + "".join(f"{i}\t{n}\t{m}\t{t}\t{s}\n" for i, n, m, t, s in entries)
    return [tuple(l.split("\t")) for l in java("pick", text)]
NOW = 1_700_000_000_000
H = [("a", "scan1.jpg", "image/jpeg", NOW - 10000, 500), ("b", "doc.pdf", "application/pdf", NOW - 9000, 500), ("c", ".hidden.png", "image/png", NOW - 9000, 5), ("d", "x.jpg.part", "image/jpeg", NOW - 9000, 5),
     ("e", "notes.txt", "text/plain", NOW - 9000, 5), ("f", "empty.png", "image/png", NOW - 9000, 0), ("g", "fresh.jpg", "image/jpeg", NOW - 500, 5), ("h", "IMG_10.HEIC", "application/octet-stream", NOW - 8000, 5),
     ("i", "IMG_2.heic", "", NOW - 8000, 5), ("j", "seen.png", "image/png", NOW - 9000, 5), ("k", "movie.jpg", "video/mp4", NOW - 9000, 5), ("l", ".trashed-1700-a.jpg", "image/jpeg", NOW - 9000, 5)]
got = run_pick(H, ["j"], NOW); exp = ref_pick(H, {"j"}, NOW, 3000)
check(got == exp and [g[0] for g in got] == ["a", "b", "i", "h"], f"ca viết tay: bỏ ẩn / tạm / rỗng / loại lạ / đang ghi dở / đã thấy; IMG_2 trước IMG_10 (tự nhiên): {[g[0] for g in got]}")
check(run_pick(H, ["j"], NOW + 5000) != got and "g" in [g[0] for g in run_pick(H, ["j"], NOW + 5000)], "tệp ghi dở (fresh.jpg) hoãn lần này, lần mở SAU (5 giây sau) thì được đề nghị")
check(run_pick(H, [e[0] for e in H], NOW + 99999) == [], "mọi tệp đã thấy -> không đề nghị gì (mỗi tệp chỉ một lần)")
rnd = random.Random(18); bad = 0
names = ["scan", "IMG_", "doc", ".h", "photo-", "a", "Z"]; exts = [".jpg", ".png", ".pdf", ".heic", ".txt", ".part", ".tmp", ".webp", "", ".PDF", ".JPG", ".mp4"]; mimes = ["image/jpeg", "image/png", "application/pdf", "application/octet-stream", "", "text/plain", "video/mp4", "image/heic"]
cases, refs = [], []
for t in range(300):
    es = [(f"id{i}", rnd.choice(names) + str(rnd.randint(0, 120)) + rnd.choice(exts), rnd.choice(mimes), NOW - rnd.choice([0, 500, 2999, 3000, 3001, 10000, 99999]) - rnd.randint(0, 3) * 7, rnd.choice([0, 1, 100, 10**6])) for i in range(rnd.randint(0, 25))]
    seen = [e[0] for e in es if rnd.random() < 0.3]
    cases.append(pick_text(es, seen, NOW)); refs.append(ref_pick(es, set(seen), NOW, 3000))
got_cases = java_batch("pick-batch", cases)
bad = sum(1 for g, r in zip(got_cases, refs) if [tuple(x.split("\t")) for x in g] != r) + (1000 if len(got_cases) != len(refs) else 0)
check(bad == 0, "300 danh sách ngẫu nhiên khớp bản tham chiếu Python viết riêng")
# mỗi tệp chỉ một lần: mô phỏng nhiều lần mở app
es = [(f"f{i}", f"p{i}.jpg", "image/jpeg", NOW - 10000, 10) for i in range(8)]; seen = []; offered = []
for visit in range(4):
    new = run_pick(es, seen, NOW); offered += [n[0] for n in new]
    seen = java("remember", "2000\n" + "|".join(seen) + "\n" + "|".join(n[0] for n in new) + "\n")[0].split("|") if new else seen
    if visit == 1: es.append(("late", "late.jpg", "image/jpeg", NOW - 10000, 10))
check(sorted(offered) == sorted([e[0] for e in es]) and len(offered) == len(set(offered)), "4 lần mở app liên tiếp, giữa chừng có tệp mới: mỗi tệp được đề nghị ĐÚNG MỘT lần")
rc = [(3, ["a", "b"], ["c", "d"]), (3, [], ["a", "a", "b"]), (5, ["a"], []), (2, ["a", "b", "c"], ["a"]), (1, ["x"], ["y"])]
for _ in range(200):
    cap = rnd.randint(1, 12); s = list(dict.fromkeys(f"i{rnd.randint(0, 20)}" for _ in range(rnd.randint(0, 15)))); a = [f"i{rnd.randint(0, 25)}" for _ in range(rnd.randint(0, 10))]; rc.append((cap, s, a))
got = java_batch("remember-batch", [f"{cap}\n" + "|".join(s) + "\n" + "|".join(a) + "\n" for cap, s, a in rc])
ok = len(got) == len(rc) and all((g[0].split("|") if g and g[0] else []) == ref_remember(cap, s, a) for g, (cap, s, a) in zip(got, rc))
check(ok, f"remember: {len(rc)} ca (giữ thứ tự, bỏ trùng, bỏ mã CŨ NHẤT khi vượt trần) khớp tham chiếu")
print("\nTAT CA DAT" if not FAILS else f"\n{len(FAILS)} LOI"); sys.exit(1 if FAILS else 0)
