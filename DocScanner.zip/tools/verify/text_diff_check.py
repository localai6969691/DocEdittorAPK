#!/usr/bin/env python3
"""So sánh VĂN BẢN hai PDF từng từ (`util/TextDiff.kt`; phiên 24, TECHNICAL_DOCS.md 4.68; PDF 11.3) CHẠY THẬT trên PdfBox thật.

  A. `diff` chính xác: 3 000 cặp chuỗi ngẫu nhiên (bảng chữ nhỏ để có từ lặp), số từ GIỮ LẠI = độ dài dãy con chung dài nhất tính độc lập bằng quy hoạch động Python, và kết quả DỰNG LẠI được cả hai
     văn bản (các từ '=' + '-' theo thứ tự = bản cũ; '=' + '+' = bản mới; chỉ số tăng dần);
  B. văn bản lớn (vượt bảng chính xác): 6 000 từ với sửa ở đầu, giữa và cuối: kết quả dựng lại đúng cả hai bản, số từ giữ lại KHÔNG ít hơn kịch bản sửa thật đã dùng để tạo ra bản mới, không cờ "gần đúng";
     ca xấu (hàng nghìn từ lặp, không có mốc duy nhất) vẫn dựng lại đúng và bị đánh dấu gần đúng;
  C. PDF thật (reportlab + DejaVu, tiếng Việt): các từ PdfBox = các từ `pdftotext` (cùng chuỗi); so hai bản có sửa 1 từ, xoá 1 câu, thêm 1 đoạn: số từ thêm / bớt và các trang đổi khớp kịch bản; báo cáo HTML
     đọc lại bằng bộ phân tích độc lập: '=' + <ins> = văn bản mới, '=' + <del> = văn bản cũ, ký tự < > & trong tiêu đề và trong chữ được thoát; hai bản giống nhau -> không thay đổi; bản quét -> 0 từ;
  D. THỬ ÂM TÍNH: 5 bản Kotlin hỏng (bảng LCS lấy min, mốc xử lý hai lần, không thoát HTML, số trang đổi lệch, chỉ số đoạn đuôi sai) PHẢI bị bắt (`--fast` bỏ; `--mutant=N`).
KHÔNG kiểm được: màn hình chọn cách so sánh trên máy. Cần: java 17+, github.com (toolchain), reportlab, Pillow, poppler.
Chạy: python3 tools/verify/text_diff_check.py [--fast] [--mutant=N]"""
import html, os, random, re, shutil, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
from reportlab.pdfgen import canvas  # noqa: E402
from reportlab.pdfbase import pdfmetrics  # noqa: E402
from reportlab.pdfbase.ttfonts import TTFont  # noqa: E402
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)
tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="textdiff-")
FILES = ["TextDiff.kt"]; HARNESS = os.path.join(HERE, "real_run", "TextDiffHarness.kt"); STUBS = os.path.join(HERE, "real_run", "UtilStubs.kt")
def build(mutate=None, tag="base"): return tc.compile(FILES, [HARNESS, STUBS], os.path.join(WORK, "cls-" + tag), mutate)[0]
def run(cls, args, stdin=None):
    r = tc.run(cls, "TextDiffHarnessKt", args, stdin=stdin)
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-700:])
    return r.stdout
def sh(*c): return subprocess.run(c, capture_output=True, text=True)
rnd = random.Random(24)

def lcs(a, b):
    n, m = len(a), len(b); prev = [0] * (m + 1)
    for i in range(n - 1, -1, -1):
        cur = [0] * (m + 1)
        for j in range(m - 1, -1, -1): cur[j] = prev[j + 1] + 1 if a[i] == b[j] else max(prev[j], cur[j + 1])
        prev = cur
    return prev[0]
def parse_edits(s): return [(e.split(":")[0], int(e.split(":")[1]), int(e.split(":")[2])) for e in s.split(",") if e]
def valid(a, b, edits):
    oa = [a[o] for k, o, n in edits if k in "=-"]; nb = [b[n] for k, o, n in edits if k in "=+"]
    io = [o for k, o, n in edits if k in "=-"]; inn = [n for k, o, n in edits if k in "=+"]
    eq_same = all(a[o] == b[n] for k, o, n in edits if k == "=")
    return oa == a and nb == b and io == sorted(io) and inn == sorted(inn) and eq_same
def diff_many(cls, pairs):
    lines = [" ".join(a) + " | " + " ".join(b) for a, b in pairs]
    out = run(cls, [], "\n".join("DIFF " + l for l in lines) + "\n").split("\n")[:-1]; res = []
    for line in out:
        approx, kept, rem, add, edits = line.split(" ", 4) if line.count(" ") >= 4 else (line.split(" ") + [""])[:5]
        res.append((approx == "true", int(kept), int(rem), int(add), parse_edits(edits)))
    return res

print("== A. diff chính xác"); cls = build()
pairs = []
for _ in range(3000):
    k = rnd.choice([2, 3, 5, 12]); a = [f"w{rnd.randint(0, k)}" for _ in range(rnd.randint(0, 30))]
    b = list(a)
    for _ in range(rnd.randint(0, 6)):
        op = rnd.choice("idr"); p = rnd.randint(0, max(len(b) - 1, 0))
        if op == "i": b.insert(p, f"w{rnd.randint(0, k)}")
        elif op == "d" and b: b.pop(p)
        elif b: b[p] = f"w{rnd.randint(0, k)}"
    if rnd.random() < .15: b = [f"w{rnd.randint(0, k)}" for _ in range(rnd.randint(0, 30))]
    pairs.append((a, b))
res = diff_many(cls, pairs); bad = []
for (a, b), (approx, kept, rem, add, edits) in zip(pairs, res):
    if kept != lcs(a, b) or rem != len(a) - kept or add != len(b) - kept or not valid(a, b, edits) or approx: bad.append((a[:6], b[:6], kept, lcs(a, b)))
check(not bad, f"3 000 cặp: số từ giữ lại = LCS tính độc lập, dựng lại đúng cả hai bản, không cờ gần đúng {bad[:1]}")
print("== B. văn bản lớn")
vocab = [f"t{i}" for i in range(9000)]
base = rnd.sample(vocab, 6000); new = list(base)
# ground-truth edit script: replace 40 words at the start, delete 30 in the middle, insert 50 near the end, replace 40 at the end
del_cnt = rep_cnt = 0
for i in range(40): new[i] = "NEW" + str(i); rep_cnt += 1
for _ in range(30): new.pop(3000); del_cnt += 1
for i in range(50): new.insert(5500, "INS" + str(i))
for i in range(40): new[-1 - i] = "TAIL" + str(i); rep_cnt += 1
(r,) = diff_many(cls, [(base, new)]); approx, kept, rem, add, edits = r
check(valid(base, new, edits), "6 000 từ, sửa ở đầu / giữa / cuối: dựng lại đúng cả hai bản")
check(kept >= len(base) - del_cnt - rep_cnt and not approx, f"giữ lại {kept} từ >= {len(base) - del_cnt - rep_cnt} (kịch bản sửa thật), không cờ gần đúng")
bad_a = [f"x{i % 3}" for i in range(4000)]; bad_b = [f"x{(i * 7 + 1) % 3}" for i in range(4600)]
(r2,) = diff_many(cls, [(bad_a, bad_b)]); check(valid(bad_a, bad_b, r2[4]) and r2[0], f"ca xấu (4 000 x 4 600 từ lặp, không mốc duy nhất): vẫn dựng lại đúng và bị đánh dấu gần đúng (giữ {r2[1]})")

print("== C. PDF thật")
pdfmetrics.registerFont(TTFont("DejaVu", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
P1 = "Hợp đồng thuê nhà phải ghi rõ thời hạn, tiền đặt cọc và quyền sửa chữa của người thuê."
P2 = "Chủ nhà đồng ý giảm giá nếu khách thuê dài hạn ba năm và trả trước sáu tháng liền."
P3 = "Mọi tranh chấp được giải quyết thông qua thương lượng giữa hai bên trước khi kiện ra tòa."
P4 = "Tiền điện nước do bên thuê tự thanh toán hằng tháng theo chỉ số công tơ của nhà cung cấp."
def make_pdf(path, pages):
    c = canvas.Canvas(path, pagesize=(612, 792)); c.setFont("DejaVu", 12)
    for page in pages:
        y = 720
        for para in page:
            words, line = para.split(" "), ""
            for w in words:
                t = (line + " " + w).strip()
                if pdfmetrics.stringWidth(t, "DejaVu", 12) <= 468: line = t
                else: c.drawString(72, y, line); y -= 18; line = w
            c.drawString(72, y, line); y -= 28
        c.showPage()
    c.save()
old = os.path.join(WORK, "old.pdf"); new_ = os.path.join(WORK, "new.pdf"); same = os.path.join(WORK, "same.pdf")
make_pdf(old, [[P1, P2], [P3, P4]]); make_pdf(same, [[P1, P2], [P3, P4]])
P2n = P2.replace("giảm giá", "tăng giá"); P4n = ""  # page 2: P3 loses nothing, P4 removed; a new paragraph is added to page 2
NEWP = "Điều khoản bổ sung: bên thuê không được cho thuê lại khi chưa có sự đồng ý bằng văn bản."
make_pdf(new_, [[P1, P2n], [P3, NEWP]])
def poppler_tokens(path): return re.sub(r"\s+", " ", sh("pdftotext", path, "-").stdout).strip().split(" ")
kw = run(cls, ["words", old]).strip().split(" ")
check(kw == poppler_tokens(old), f"các từ PdfBox = các từ pdftotext ({len(kw)} từ, tiếng Việt đủ dấu)")
rep = os.path.join(WORK, "rep.html"); out = run(cls, ["compare", old, new_, rep]).strip().split(" ")
o_words, n_words = kw, run(cls, ["words", new_]).strip().split(" ")
true_kept = lcs(o_words, n_words)
check(int(out[2]) == true_kept and int(out[3]) == len(o_words) - true_kept and int(out[4]) == len(n_words) - true_kept, f"đếm: giữ {out[2]} bớt {out[3]} thêm {out[4]} = LCS độc lập ({true_kept})")
check(out[6] == "1,2" and out[5] == "false", f"các trang đổi của bản mới: {out[6]} (trang 1: 'giảm giá' -> 'tăng giá'; trang 2: bỏ P4, thêm điều khoản)")
h = open(rep, encoding="utf-8").read()
def rebuild(h, keep_tag):
    """words of the version made of '=' words plus the <keep_tag> words: drop the other marked words first, then every tag"""
    body = h[h.index("</h1>"):]; body = re.sub(r"<h2>.*?</h2>", " ", body)
    drop = "del" if keep_tag == "ins" else "ins"; body = re.sub(rf"<{drop}>.*?</{drop}>", " ", body); body = re.sub(r"<[^>]+>", " ", body)
    return html.unescape(re.sub(r"\s+", " ", body)).strip().split(" ")
# the summary line "+N -M (K =)" sits right after <h1>: cut it
def clean(tokens): return [t for t in tokens if t and not re.fullmatch(r"\+\d+|-\d+|\(\d+|=\)", t)]
ri, rd_ = clean(rebuild(h, "ins")), clean(rebuild(h, "del"))
dd = lambda x, y: (len(x), len(y), next(((i, a, b) for i, (a, b) in enumerate(zip(x, y)) if a != b), None))
check(ri == n_words and rd_ == o_words, f"báo cáo HTML đọc lại độc lập: '=' + <ins> = văn bản mới, '=' + <del> = văn bản cũ  [mới {dd(ri, n_words)} cũ {dd(rd_, o_words)}]")
check("Report &lt;A&amp;B&gt;" in h and "<h1>Report <A" not in h, "tiêu đề có < > & được thoát trong HTML")
o2 = run(cls, ["compare", old, same, os.path.join(WORK, "s.html")]).strip().split(" "); check(o2[3] == "0" and o2[4] == "0" and o2[6] == "" if len(o2) > 6 else True, f"hai bản giống nhau -> không thay đổi ({o2})")
img = os.path.join(WORK, "img.pdf"); from PIL import Image as PI; PI.new("RGB", (200, 200), (240, 240, 240)).save(os.path.join(WORK, "b.png"))
c = canvas.Canvas(img, pagesize=(612, 792)); c.drawImage(os.path.join(WORK, "b.png"), 50, 100, 400, 400); c.showPage(); c.save()
o3 = run(cls, ["compare", img, img, os.path.join(WORK, "i.html")]).strip().split(" "); check(o3[0] == "0" and o3[1] == "0", f"bản quét (không lớp chữ): 0 từ ({o3[:2]})")

ONLY = next((int(a.split("=")[1]) for a in sys.argv if a.startswith("--mutant=")), None)
if "--fast" in sys.argv and ONLY is None: print("== D. bỏ qua thử âm tính (--fast)")
else:
    print("== D. thử âm tính")
    # (the mutant "+ 2 instead of + 1 in the LCS table" is EQUIVALENT - it only doubles every value, no decision changes - so it is not used)
    MUT = [("bảng LCS lấy min thay vì max", ("else maxOf(table[(i + 1) * width + j], table[i * width + j + 1])", "else minOf(table[(i + 1) * width + j], table[i * width + j + 1])")),
           # (an inverted comparator in the anchor chain only changes WHICH unique words become anchors: each one is still a true match and the gaps are compared exactly, so the output is unchanged - a speed difference, not testable by output)
           ("mốc được xử lý hai lần", ("            pa = ia + 1\n            pb = ib + 1", "            pa = ia\n            pb = ib")),
           ("không thoát HTML", ('private fun escape(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")', "private fun escape(s: String): String = s")),
           ("số trang đổi lệch một", ("if (edit.kind != EQUAL) changed.add(p + 1)", "if (edit.kind != EQUAL) changed.add(p)")),
           # (stopping the common-prefix trim one word early is EQUIVALENT in output: the exact table handles what is left)
           ("chỉ số từ của đoạn đuôi chung sai", ("for (k in 0 until tail) out.add(Edit(EQUAL, ei + k, ej + k))", "for (k in 0 until tail) out.add(Edit(EQUAL, ei + k, ej))"))]
    for number, (name, (old_, new_s)) in enumerate(MUT, 1):
        if ONLY is not None and number != ONLY: continue
        try: mcls = build({"TextDiff.kt": (old_, new_s)}, tag="mut")
        except RuntimeError as exc: check("mutation target not found" not in str(exc), f"ÂM TÍNH '{name}': bản hỏng không biên dịch (bị bắt)"); continue
        caught = False
        try:
            rs = diff_many(mcls, pairs[:300] + [(base, new)])
            for (a, b), (approx, kept, rem, add, edits) in zip(pairs[:300] + [(base, new)], rs):
                if kept != lcs(a, b) and len(a) < 40 or not valid(a, b, edits): caught = True; break
            if rs[-1][1] < len(base) - del_cnt - rep_cnt: caught = True      # the large case must keep at least as many words as the real edit script does
            if not caught:
                oo = run(mcls, ["compare", old, new_, os.path.join(WORK, "m.html")]).strip().split(" ")
                hh = open(os.path.join(WORK, "m.html"), encoding="utf-8").read()
                if oo[6] != "1,2" or "Report &lt;A&amp;B&gt;" not in hh: caught = True
        except SystemExit: caught = True
        check(caught, f"ÂM TÍNH '{name}': bản hỏng bị bắt")
shutil.rmtree(WORK, ignore_errors=True); print("\nTAT CA DAT" if not fails else f"\n{len(fails)} LOI"); sys.exit(1 if fails else 0)
