import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.CRC32;

/**
 * Java twin of app/.../util/EpubNotes.kt (phiên 23, 4.50). The logic is copied statement by statement; only the language differs.
 * stdin, one command per line (all text is hex of UTF-16 code units, 4 hex digits per unit, so lone surrogates and emoji survive the pipe):
 *   BOOK                      starts a new book (clears the notes too)
 *   C                         starts a chapter;   P <hex>  adds a paragraph to the current chapter;   T <hex>  sets the title of the current chapter
 *   FP                        prints the fingerprint
 *   ADD c p s e | ERASE c p s e | REMOVE c p s e | TOG c p      change the notes; LAST c p  sets the reading position
 *   DUMP                      prints the notes: "H c p s e" / "B c p" / "L c p" lines, then "END"
 *   ENC                       prints the encoded text as hex;   DEC <hex>  replaces the notes by decode(text) (prints "STALE" / "OK" first)
 *   SNIP <max> <hex>          prints snippet(text, max) as hex
 *   RENDER                    prints render(...) as hex (fixed labels: header "HEAD", "BM", "HL", chapter label "Ch<n>:<title>")
 *   FILE <dir>                save -> load round trip in a real folder, then a stale load; prints a few facts
 */
public class EpubNotesCheck {
    static final int MAX_NOTES = 5000;
    static final String HEADER = "DOCSCANNER-EPUB-NOTES 1";

    static class Mark { int chapter, paragraph, start, end; Mark(int c, int p, int s, int e) { chapter = c; paragraph = p; start = s; end = e; } }
    static class Place { int chapter, paragraph; Place(int c, int p) { chapter = c; paragraph = p; } }
    static class Notes {
        List<Mark> highlights; List<Place> bookmarks; Place last; boolean stale;
        Notes(List<Mark> h, List<Place> b, Place l, boolean s) { highlights = h; bookmarks = b; last = l; stale = s; }
    }
    static Notes empty() { return new Notes(new ArrayList<>(), new ArrayList<>(), null, false); }

    static boolean isSpace(char c) { return Character.isWhitespace(c) || Character.isSpaceChar(c); }

    static final Comparator<Mark> MARK_ORDER = (a, b) -> a.chapter != b.chapter ? Integer.compare(a.chapter, b.chapter)
            : a.paragraph != b.paragraph ? Integer.compare(a.paragraph, b.paragraph) : Integer.compare(a.start, b.start);
    static final Comparator<Place> PLACE_ORDER = (a, b) -> a.chapter != b.chapter ? Integer.compare(a.chapter, b.chapter) : Integer.compare(a.paragraph, b.paragraph);

    static void putInt(CRC32 crc, int v) { crc.update((v >>> 24) & 0xFF); crc.update((v >>> 16) & 0xFF); crc.update((v >>> 8) & 0xFF); crc.update(v & 0xFF); }

    static String fingerprint(List<List<String>> chapters) {
        CRC32 crc = new CRC32(); int count = 0;
        for (List<String> chapter : chapters) {
            crc.update(1); putInt(crc, chapter.size());
            for (String p : chapter) { byte[] b = p.getBytes(StandardCharsets.UTF_8); putInt(crc, b.length); crc.update(b, 0, b.length); count++; }
        }
        return String.format("%08x", crc.getValue()) + "-" + count;
    }

    static int clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

    static int[] snap(String text, int start, int end) {
        int s = clamp(start, 0, text.length()), e = clamp(end, 0, text.length());
        if (s > 0 && s < text.length() && Character.isLowSurrogate(text.charAt(s)) && Character.isHighSurrogate(text.charAt(s - 1))) s--;
        if (e > 0 && e < text.length() && Character.isLowSurrogate(text.charAt(e)) && Character.isHighSurrogate(text.charAt(e - 1))) e++;
        return new int[]{s, e};
    }

    static List<Mark> addHighlight(List<Mark> list, int chapter, int paragraph, String text, int start, int end) {
        int[] se = snap(text, Math.min(start, end), Math.max(start, end));
        int s = se[0], e = se[1];
        while (s < e && isSpace(text.charAt(s))) s++;
        while (e > s && isSpace(text.charAt(e - 1))) e--;
        if (s >= e) return list;
        List<Mark> out = new ArrayList<>(list.size() + 1);
        int ns = s, ne = e; boolean merged = false;
        for (Mark m : list) {
            if (m.chapter == chapter && m.paragraph == paragraph && m.start <= ne && m.end >= ns) { ns = Math.min(ns, m.start); ne = Math.max(ne, m.end); merged = true; }
            else out.add(m);
        }
        if (!merged && out.size() >= MAX_NOTES) return list;
        out.add(new Mark(chapter, paragraph, ns, ne));
        out.sort(MARK_ORDER);
        return out;
    }

    static List<Mark> eraseHighlight(List<Mark> list, int chapter, int paragraph, String text, int start, int end) {
        int[] se = snap(text, Math.min(start, end), Math.max(start, end));
        int s = se[0], e = se[1];
        if (s >= e) return list;
        List<Mark> out = new ArrayList<>(list.size() + 1);
        for (Mark m : list) {
            if (m.chapter != chapter || m.paragraph != paragraph || m.end <= s || m.start >= e) { out.add(m); continue; }
            if (m.start < s) out.add(new Mark(chapter, paragraph, m.start, s));
            if (m.end > e) out.add(new Mark(chapter, paragraph, e, m.end));
        }
        out.sort(MARK_ORDER);
        return out;
    }

    static List<Mark> removeHighlight(List<Mark> list, Mark mark) {
        List<Mark> out = new ArrayList<>();
        for (Mark m : list) if (!(m.chapter == mark.chapter && m.paragraph == mark.paragraph && m.start == mark.start && m.end == mark.end)) out.add(m);
        return out;
    }

    static boolean hasBookmark(List<Place> list, int c, int p) { for (Place x : list) if (x.chapter == c && x.paragraph == p) return true; return false; }

    static List<Place> toggleBookmark(List<Place> list, int c, int p) {
        if (hasBookmark(list, c, p)) { List<Place> out = new ArrayList<>(); for (Place x : list) if (!(x.chapter == c && x.paragraph == p)) out.add(x); return out; }
        if (list.size() >= MAX_NOTES) return list;
        List<Place> out = new ArrayList<>(list); out.add(new Place(c, p)); out.sort(PLACE_ORDER); return out;
    }

    static String encode(String fingerprint, Notes notes) {
        StringBuilder sb = new StringBuilder(HEADER).append('\n').append("F ").append(fingerprint).append('\n');
        if (notes.last != null) sb.append("L ").append(notes.last.chapter).append(' ').append(notes.last.paragraph).append('\n');
        for (Place b : notes.bookmarks) sb.append("B ").append(b.chapter).append(' ').append(b.paragraph).append('\n');
        for (Mark h : notes.highlights) sb.append("H ").append(h.chapter).append(' ').append(h.paragraph).append(' ').append(h.start).append(' ').append(h.end).append('\n');
        return sb.toString();
    }

    // Kotlin: String.toIntOrNull() accepts an optional sign and decimal digits (no spaces, no empty string), fails past Int range. Same here.
    static Integer toIntOrNull(String s) {
        if (s.isEmpty()) return null;
        int i = 0; if (s.charAt(0) == '-' || s.charAt(0) == '+') { if (s.length() == 1) return null; i = 1; }
        for (int k = i; k < s.length(); k++) if (Character.digit(s.charAt(k), 10) < 0) return null;   // Kotlin's digitOf accepts Unicode digits too
        try { return Integer.parseInt(s.charAt(0) == '+' ? s.substring(1) : s); } catch (NumberFormatException ex) { return null; }
    }

    static int[] ints(String[] parts, int from, int count) {
        if (parts.length != from + count) return null;
        int[] r = new int[count];
        for (int i = 0; i < count; i++) { Integer v = toIntOrNull(parts[from + i]); if (v == null || v < 0) return null; r[i] = v; }
        return r;
    }

    // Kotlin: String.split(' ') keeps empty strings between neighbouring spaces (limit 0 here removes trailing empties - so use -1).
    static String[] splitSpace(String s) { return s.split(" ", -1); }

    // Kotlin's String.trim() / trimEnd() use Char.isWhitespace(), which on the JVM is Character.isWhitespace || Character.isSpaceChar (NBSP counts). Same as isSpace.
    static String ktTrim(String s) {
        int a = 0, b = s.length();
        while (a < b && isSpace(s.charAt(a))) a++;
        while (b > a && isSpace(s.charAt(b - 1))) b--;
        return s.substring(a, b);
    }

    static Notes decode(String text, String fingerprint, List<List<String>> chapters) {
        String[] lines = text.split("\n", -1);
        if (lines.length == 0 || !ktTrim(lines[0]).equals(HEADER)) return empty();
        String fp = null;
        for (String l : lines) if (l.startsWith("F ")) { fp = ktTrim(l.substring(2)); break; }
        if (fp == null) return empty();
        if (!fp.equals(fingerprint)) return new Notes(new ArrayList<>(), new ArrayList<>(), null, true);
        List<Mark> highlights = new ArrayList<>(); List<Place> bookmarks = new ArrayList<>(); Place last = null;
        for (int li = 1; li < lines.length; li++) {
            String line = ktTrim(lines[li]);
            if (line.length() < 3) continue;
            String[] parts = splitSpace(line);
            if (parts[0].equals("L")) {
                int[] v = ints(parts, 1, 2);
                if (v != null && v[0] < chapters.size() && v[1] < chapters.get(v[0]).size()) last = new Place(v[0], v[1]);
            } else if (parts[0].equals("B")) {
                int[] v = ints(parts, 1, 2);
                if (v != null && v[0] < chapters.size() && v[1] < chapters.get(v[0]).size() && !hasBookmark(bookmarks, v[0], v[1])) bookmarks = toggleBookmark(bookmarks, v[0], v[1]);
            } else if (parts[0].equals("H")) {
                int[] v = ints(parts, 1, 4);
                if (v != null && v[0] < chapters.size() && v[1] < chapters.get(v[0]).size()) {
                    String p = chapters.get(v[0]).get(v[1]); int e = Math.min(v[3], p.length());
                    if (v[2] < e) highlights = addHighlight(highlights, v[0], v[1], p, v[2], e);
                }
            }
        }
        return new Notes(highlights, bookmarks, last, false);
    }

    static File fileFor(File dir, File epub) {
        StringBuilder safe = new StringBuilder();
        for (char c : epub.getName().toCharArray()) safe.append((c == '/' || c == '\\' || c == ':' || c < 32) ? '_' : c);
        String s = safe.length() > 150 ? safe.substring(0, 150) : safe.toString();
        return new File(dir, s + ".notes");
    }

    static boolean save(File file, String fingerprint, Notes notes) {
        try {
            if (file.getParentFile() != null) file.getParentFile().mkdirs();
            File tmp = new File(file.getPath() + ".tmp");
            Files.write(tmp.toPath(), encode(fingerprint, notes).getBytes(StandardCharsets.UTF_8));
            if (file.exists() && !file.delete()) { tmp.delete(); return false; }
            else if (!tmp.renameTo(file)) { tmp.delete(); return false; }
            else return true;
        } catch (Exception e) { return false; }
    }

    static Notes load(File file, String fingerprint, List<List<String>> chapters) {
        if (!file.isFile()) return empty();
        String text;
        try { text = new String(Files.readAllBytes(file.toPath()), StandardCharsets.UTF_8); } catch (Exception e) { return empty(); }
        Notes notes = decode(text, fingerprint, chapters);
        if (notes.stale) { File aside = new File(file.getPath() + ".stale"); if (aside.exists()) aside.delete(); file.renameTo(aside); }
        return notes;
    }

    static String snippet(String text, int max) {
        StringBuilder sb = new StringBuilder(); boolean lastSpace = true;
        for (int i = 0; i < text.length(); i++) { char c = text.charAt(i); if (isSpace(c)) { if (!lastSpace) sb.append(' '); lastSpace = true; } else { sb.append(c); lastSpace = false; } }
        String s = ktTrim(sb.toString());
        if (s.length() <= max) return s;
        int cut = max;
        if (cut > 0 && Character.isLowSurrogate(s.charAt(cut)) && Character.isHighSurrogate(s.charAt(cut - 1))) cut--;
        s = s.substring(0, cut);
        int b = s.length(); while (b > 0 && isSpace(s.charAt(b - 1))) b--;   // Kotlin trimEnd()
        return s.substring(0, b) + "\u2026";
    }

    static String chapterLabel(int n, String title) { return "Ch" + n + ":" + title; }

    static String render(List<List<String>> paragraphs, List<String> titles, Notes notes, String header, String bookmarksHead, String highlightsHead) {
        StringBuilder sb = new StringBuilder(header).append('\n');
        if (!notes.bookmarks.isEmpty()) {
            sb.append('\n').append(bookmarksHead).append('\n');
            for (Place b : notes.bookmarks) {
                if (b.chapter >= paragraphs.size() || b.paragraph >= paragraphs.get(b.chapter).size()) continue;
                sb.append("\u2022 ").append(chapterLabel(b.chapter + 1, ktTrim(b.chapter < titles.size() ? titles.get(b.chapter) : ""))).append(": ")
                  .append(snippet(paragraphs.get(b.chapter).get(b.paragraph), 120)).append('\n');
            }
        }
        if (!notes.highlights.isEmpty()) {
            sb.append('\n').append(highlightsHead).append('\n');
            for (Mark h : notes.highlights) {
                if (h.chapter >= paragraphs.size() || h.paragraph >= paragraphs.get(h.chapter).size()) continue;
                String p = paragraphs.get(h.chapter).get(h.paragraph); int e = Math.min(h.end, p.length());
                if (h.start >= e) continue;
                sb.append("\u2022 ").append(chapterLabel(h.chapter + 1, ktTrim(h.chapter < titles.size() ? titles.get(h.chapter) : ""))).append(": ")
                  .append(snippet(p.substring(h.start, e), 400)).append('\n');
            }
        }
        return sb.toString();
    }

    // ---------------- driver ----------------
    static String unhex(String h) { StringBuilder sb = new StringBuilder(); for (int i = 0; i + 4 <= h.length(); i += 4) sb.append((char) Integer.parseInt(h.substring(i, i + 4), 16)); return sb.toString(); }
    static String hex(String s) { StringBuilder sb = new StringBuilder(); for (int i = 0; i < s.length(); i++) sb.append(String.format("%04x", (int) s.charAt(i))); return sb.toString(); }

    static List<List<String>> book = new ArrayList<>(); static List<String> titles = new ArrayList<>(); static Notes notes = empty();

    static void dump(PrintStream out) {
        for (Mark h : notes.highlights) out.println("H " + h.chapter + " " + h.paragraph + " " + h.start + " " + h.end);
        for (Place b : notes.bookmarks) out.println("B " + b.chapter + " " + b.paragraph);
        if (notes.last != null) out.println("L " + notes.last.chapter + " " + notes.last.paragraph);
        out.println("END");
    }

    public static void main(String[] a) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.US_ASCII)); String line;
        PrintStream out = new PrintStream(System.out, false, "UTF-8");
        while ((line = r.readLine()) != null) {
            String[] t = line.trim().split(" ");
            switch (t[0]) {
                case "BOOK": book = new ArrayList<>(); titles = new ArrayList<>(); notes = empty(); break;
                case "C": book.add(new ArrayList<>()); titles.add(""); break;
                case "P": book.get(book.size() - 1).add(t.length > 1 ? unhex(t[1]) : ""); break;
                case "T": titles.set(titles.size() - 1, t.length > 1 ? unhex(t[1]) : ""); break;
                case "FP": out.println(fingerprint(book)); break;
                case "ADD": { int c = Integer.parseInt(t[1]), p = Integer.parseInt(t[2]); notes = new Notes(addHighlight(notes.highlights, c, p, book.get(c).get(p), Integer.parseInt(t[3]), Integer.parseInt(t[4])), notes.bookmarks, notes.last, false); break; }
                case "ERASE": { int c = Integer.parseInt(t[1]), p = Integer.parseInt(t[2]); notes = new Notes(eraseHighlight(notes.highlights, c, p, book.get(c).get(p), Integer.parseInt(t[3]), Integer.parseInt(t[4])), notes.bookmarks, notes.last, false); break; }
                case "REMOVE": notes = new Notes(removeHighlight(notes.highlights, new Mark(Integer.parseInt(t[1]), Integer.parseInt(t[2]), Integer.parseInt(t[3]), Integer.parseInt(t[4]))), notes.bookmarks, notes.last, false); break;
                case "TOG": notes = new Notes(notes.highlights, toggleBookmark(notes.bookmarks, Integer.parseInt(t[1]), Integer.parseInt(t[2])), notes.last, false); break;
                case "LAST": notes = new Notes(notes.highlights, notes.bookmarks, new Place(Integer.parseInt(t[1]), Integer.parseInt(t[2])), false); break;
                case "DUMP": dump(out); break;
                case "ENC": out.println(hex(encode(fingerprint(book), notes))); break;
                case "DEC": { Notes n = decode(t.length > 1 ? unhex(t[1]) : "", fingerprint(book), book); out.println(n.stale ? "STALE" : "OK"); notes = n; break; }
                case "SNIP": out.println(hex(snippet(t.length > 2 ? unhex(t[2]) : "", Integer.parseInt(t[1])))); break;
                case "RENDER": out.println(hex(render(book, titles, notes, "HEAD", "BM", "HL"))); break;
                case "FILE": {
                    File dir = new File(t[1]); File epub = new File("/some/where/My: Book\\x.epub"); File f = fileFor(dir, epub);
                    String fp = fingerprint(book);
                    boolean saved = save(f, fp, notes);
                    boolean noTmp = !new File(f.getPath() + ".tmp").exists();
                    Notes back = load(f, fp, book); Notes saveAgain = back; boolean again = save(f, fp, saveAgain);
                    out.println("SAVED " + saved + " " + noTmp + " " + again + " " + f.getName());
                    notes = back; dump(out);
                    List<List<String>> other = new ArrayList<>(book); other.add(new ArrayList<>(Arrays.asList("x")));
                    Notes stale = load(f, fingerprint(other), other);
                    out.println("STALE " + stale.stale + " " + stale.highlights.size() + " " + f.exists() + " " + new File(f.getPath() + ".stale").exists());
                    Notes none = load(new File(dir, "nothing.notes"), fp, book);
                    out.println("MISSING " + none.stale + " " + none.highlights.size());
                    break;
                }
                default: break;
            }
        }
        out.flush();
    }
}
