"""Kiểm chứng cú pháp chuỗi tài nguyên (phiên 16): trong res/values*/strings.xml
  1. dấu nháy ĐƠN ' phải có \\ đứng trước (aapt2 từ chối: "Apostrophe not preceded by \\") - lỗi biên dịch thật;
  2. dấu nháy KÉP " phải có \\ đứng trước (không thì Android nuốt dấu: "Lưu & thoát" mất ngoặc kép);
  3. mọi %1$d / %2$s dùng chỉ số (một chuỗi có hai %s không đánh số là cảnh báo / lỗi định dạng) và các chỉ số liên tục từ 1;
  4. không có hai chuỗi trùng tên; mọi tên là định danh Java hợp lệ.
Thử âm tính: chuỗi mẫu có ' trần phải bị bắt.
Chạy: python3 strings_check.py
"""
import glob, os, re, sys
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
def audit(text, label):
    problems, names, count = [], {}, 0
    for m in re.finditer(r'<string name="([^"]+)"([^>]*)>(.*?)</string>', text, flags=re.S):
        name, attrs, body = m.group(1), m.group(2), m.group(3)
        count += 1
        if 'translatable="false"' in attrs: pass
        if name in names: problems.append(f"{label}: trùng tên {name}")
        names[name] = 1
        if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", name): problems.append(f"{label}: tên không hợp lệ {name}")
        if re.search(r"(?<!\\)'", body): problems.append(f"{label}: {name} có dấu nháy đơn không escape")
        if re.search(r'(?<!\\)"', body): problems.append(f"{label}: {name} có dấu nháy kép không escape")
        idx = re.findall(r"%(\d+)\$[sdf]", body)
        bare = re.findall(r"%[sdf]", body)
        if bare and len(bare) + len(idx) > 1: problems.append(f"{label}: {name} trộn %s không đánh số với nhiều đối số")
        if idx and sorted({int(i) for i in idx}) != list(range(1, max(int(i) for i in idx) + 1)): problems.append(f"{label}: {name} chỉ số đối số không liên tục {sorted(set(idx))}")
    return problems, count
files = sorted(glob.glob(os.path.join(ROOT, "app/src/main/res/values*/strings.xml")))
allp, total = [], 0
for f in files:
    p, c = audit(open(f, encoding="utf-8").read(), os.path.relpath(f, ROOT)); allp += p; total += c
check(not allp, f"{total} chuỗi trong {len(files)} tệp strings.xml: nháy đơn / nháy kép đều có \\, chỉ số đối số liên tục, tên không trùng" + (f" — {allp[:4]}" if allp else ""))
neg, _ = audit('<resources><string name="x">it\'s a "test" %s %s</string></resources>', "mau")
check(len(neg) >= 3, f"thử âm tính: chuỗi mẫu có ' trần, \" trần, hai %s không đánh số bị bắt ({len(neg)} vấn đề)")
def table(text):
    out = {}
    for m in re.finditer(r'<string name="([^"]+)"([^>]*)>(.*?)</string>', text, flags=re.S):
        out[m.group(1)] = (m.group(2), sorted(re.findall(r"%\d+\$[sdf]", m.group(3))))
    return out
def parity(base_text, tr_text, label):
    b, t, problems = table(base_text), table(tr_text), []
    need = {k for k, (attrs, _) in b.items() if 'translatable="false"' not in attrs}
    missing, extra = sorted(need - set(t)), sorted(set(t) - set(b))
    if missing: problems.append(f"{label}: thiếu {len(missing)} khoá, ví dụ {missing[:3]}")
    if extra: problems.append(f"{label}: thừa {len(extra)} khoá không có ở bản gốc, ví dụ {extra[:3]}")
    for k in need & set(t):
        if b[k][1] != t[k][1]: problems.append(f"{label}: {k} khác tham số {b[k][1]} vs {t[k][1]}")
    return problems
base = open(os.path.join(ROOT, "app/src/main/res/values/strings.xml"), encoding="utf-8").read()
translations = [f for f in files if os.path.dirname(f).split(os.sep)[-1] not in ("values", "values-night")]
for f in translations:
    pp = parity(base, open(f, encoding="utf-8").read(), os.path.relpath(f, ROOT))
    check(not pp, f"{os.path.relpath(f, ROOT)}: khớp bản gốc (khoá + tham số)" + (f" -- {pp[:4]}" if pp else ""))
if not translations: print("--   chưa có bản dịch nào (values-<mã>): bước khớp khoá/tham số chưa có gì để kiểm")
t_base = '<resources><string name="a">A %1$s %2$d</string><string name="b">B</string><string name="c" translatable="false">C</string></resources>'
negs = [parity(t_base, '<resources><string name="a">A %1$s</string><string name="b">B</string></resources>', "m"),
        parity(t_base, '<resources><string name="a">A %2$d %1$s</string></resources>', "m"),
        parity(t_base, '<resources><string name="a">A %1$s %2$d</string><string name="b">B</string><string name="z">Z</string></resources>', "m")]
ok_case = parity(t_base, '<resources><string name="a">%2$d then %1$s</string><string name="b">B</string></resources>', "m")
check(all(negs) and not ok_case, f"thử âm tính: thiếu tham số / thiếu khoá / khoá thừa bị bắt ({[len(n) for n in negs]}); đổi thứ tự tham số trong câu vẫn hợp lệ")
print("\nTAT CA DAT" if not FAILS else f"\nCO {len(FAILS)} LOI")
sys.exit(1 if FAILS else 0)
