// Bản Java song song (chạy được trên máy tính) của app/.../util/DocxWriter.kt (phiên 15): cùng thuật toán chia đoạn, thoát XML và dựng gói .docx.
// Dùng bởi tools/verify/docx_check.py:  java DocxCheck.java <input.txt (UTF-8)> <out.docx> <paragraphs.txt>
// paragraphs.txt nhận các đoạn đã chia (mỗi đoạn một dòng, \f thay cho ngắt trang) để so với bản Python.
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.Pattern;
import java.util.zip.*;

public class DocxCheck {
    static final String PAGE_BREAK = "\uE000";
    static final String NS_W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
    static final String NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";

    static List<String> paragraphsFromText(String text) {
        List<String> out = new ArrayList<>();
        for (String block : text.split("\\n\\s*\\n", -1)) {
            List<String> lines = new ArrayList<>();
            for (String l : block.split("\\R", -1)) { String t = l.trim(); if (!t.isEmpty()) lines.add(t); }
            if (lines.isEmpty()) continue;
            int longest = 0; for (String l : lines) longest = Math.max(longest, l.length());
            StringBuilder cur = new StringBuilder();
            for (int i = 0; i < lines.size(); i++) {
                String line = lines.get(i);
                if (line.equals(PAGE_BREAK)) {
                    if (cur.length() > 0) { out.add(cur.toString()); cur.setLength(0); }
                    out.add(PAGE_BREAK);
                    continue;
                }
                if (cur.length() > 0) cur.append(' ');
                cur.append(line);
                char last = line.charAt(line.length() - 1);
                boolean endsSentence = ".!?:;…".indexOf(last) >= 0;
                boolean isShort = line.length() < 0.7 * longest;
                if (endsSentence || isShort || i == lines.size() - 1) { out.add(cur.toString()); cur.setLength(0); }
            }
            if (cur.length() > 0) out.add(cur.toString());
        }
        return out;
    }

    static String escape(String text) {
        StringBuilder sb = new StringBuilder(text.length() + 16);
        for (int i = 0; i < text.length(); ) {
            int cp = text.codePointAt(i); i += Character.charCount(cp);
            boolean legal = cp == 0x9 || cp == 0xA || cp == 0xD || (cp >= 0x20 && cp <= 0xD7FF) || (cp >= 0xE000 && cp <= 0xFFFD) || (cp >= 0x10000 && cp <= 0x10FFFF);
            if (!legal) continue;
            if (cp == '&') sb.append("&amp;"); else if (cp == '<') sb.append("&lt;"); else if (cp == '>') sb.append("&gt;"); else sb.appendCodePoint(cp);
        }
        return sb.toString();
    }

    static String documentXml(List<String> paragraphs) {
        StringBuilder body = new StringBuilder();
        for (String p : paragraphs) {
            if (p.equals(PAGE_BREAK)) body.append("<w:p><w:r><w:br w:type=\"page\"/></w:r></w:p>");
            else body.append("<w:p><w:r><w:t xml:space=\"preserve\">").append(escape(p)).append("</w:t></w:r></w:p>");
        }
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
            + "<w:document xmlns:w=\"" + NS_W + "\" xmlns:r=\"" + NS_R + "\"><w:body>" + body
            + "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/>"
            + "<w:pgMar w:top=\"1134\" w:right=\"1134\" w:bottom=\"1134\" w:left=\"1701\" w:header=\"709\" w:footer=\"709\" w:gutter=\"0\"/>"
            + "</w:sectPr></w:body></w:document>";
    }

    static final String CONTENT_TYPES = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
        + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
        + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
        + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
        + "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/>"
        + "<Override PartName=\"/word/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml\"/>"
        + "</Types>";
    static final String PACKAGE_RELS = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
        + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
        + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/>"
        + "</Relationships>";
    static final String DOCUMENT_RELS = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
        + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
        + "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>"
        + "</Relationships>";
    static final String STYLES = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
        + "<w:styles xmlns:w=\"" + NS_W + "\"><w:docDefaults><w:rPrDefault><w:rPr>"
        + "<w:rFonts w:ascii=\"Times New Roman\" w:hAnsi=\"Times New Roman\" w:cs=\"Times New Roman\" w:eastAsia=\"Times New Roman\"/>"
        + "<w:sz w:val=\"26\"/><w:szCs w:val=\"26\"/><w:lang w:val=\"vi-VN\"/></w:rPr></w:rPrDefault>"
        + "<w:pPrDefault><w:pPr><w:spacing w:after=\"120\" w:line=\"300\" w:lineRule=\"auto\"/></w:pPr></w:pPrDefault></w:docDefaults>"
        + "<w:style w:type=\"paragraph\" w:default=\"1\" w:styleId=\"Normal\"><w:name w:val=\"Normal\"/></w:style></w:styles>";

    static void write(List<String> paragraphs, String out) throws IOException {
        try (ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(out))) {
            part(zip, "[Content_Types].xml", CONTENT_TYPES);
            part(zip, "_rels/.rels", PACKAGE_RELS);
            part(zip, "word/document.xml", documentXml(paragraphs.isEmpty() ? Arrays.asList("") : paragraphs));
            part(zip, "word/_rels/document.xml.rels", DOCUMENT_RELS);
            part(zip, "word/styles.xml", STYLES);
        }
    }

    static void part(ZipOutputStream zip, String name, String content) throws IOException {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(content.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    public static void main(String[] args) throws Exception {
        String text = new String(Files.readAllBytes(Paths.get(args[0])), StandardCharsets.UTF_8);
        List<String> paragraphs = paragraphsFromText(text);
        write(paragraphs, args[1]);
        StringBuilder sb = new StringBuilder();
        for (String p : paragraphs) sb.append(p.equals(PAGE_BREAK) ? "\f" : p).append("\n");
        Files.write(Paths.get(args[2]), sb.toString().getBytes(StandardCharsets.UTF_8));
    }
}
