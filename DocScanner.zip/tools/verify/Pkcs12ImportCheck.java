import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.security.cert.X509Certificate;
import java.security.interfaces.*;
import java.util.*;

/**
 * Java twin of app/.../util/Pkcs12Import.kt (phiên 22, 4.49.8): same checks in the same order.
 *   java Pkcs12ImportCheck.java <file.p12> <passwordHexUtf8> <nowMillis> <outPrefix>
 * prints "OK <RSA|EC> <chainLength>" and writes <outPrefix>.pk8 (the private key, PKCS#8) and <outPrefix>.<i>.der (the chain, leaf first),
 * or prints "ERR <REASON>".
 */
public class Pkcs12ImportCheck {
    static class Fail extends Exception { final String reason; Fail(String r) { super(r); reason = r; } }

    /** Mirror of PdfDigitalSigner.commonName. */
    static String commonName(String subject) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?:^|,)\\s*CN=((?:\\\\.|[^,])*)", java.util.regex.Pattern.CASE_INSENSITIVE).matcher(subject);
        if (!m.find()) return subject;
        String r = m.group(1).replaceAll("\\\\(.)", "$1").trim();
        return r.isEmpty() ? subject : r;
    }

    public static void main(String[] a) throws Exception {
        if (a[0].equals("subject")) {       // subject <p12> <passwordHex>: the leaf's RFC 2253 subject (what AndroidKeyStore's info().subject holds) and its commonName, hex UTF-8
            KeyStore ks = KeyStore.getInstance("PKCS12"); ks.load(new ByteArrayInputStream(Files.readAllBytes(Paths.get(a[1]))), new String(unhex(a[2]), StandardCharsets.UTF_8).toCharArray());
            String alias = Collections.list(ks.aliases()).get(0);
            String name = ((X509Certificate) ks.getCertificate(alias)).getSubjectX500Principal().getName();
            System.out.println(hex(name.getBytes(StandardCharsets.UTF_8)) + " " + hex(commonName(name).getBytes(StandardCharsets.UTF_8))); return;
        }
        if (a[0].equals("mismatch")) {      // mismatch <out.p12> <password> <key.pk8> <cert.der>: a PKCS#12 whose key does NOT belong to its certificate (cryptography and openssl refuse to build one)
            java.security.PrivateKey k = java.security.KeyFactory.getInstance("RSA").generatePrivate(new java.security.spec.PKCS8EncodedKeySpec(Files.readAllBytes(Paths.get(a[3]))));
            java.security.cert.Certificate c = java.security.cert.CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(Files.readAllBytes(Paths.get(a[4]))));
            KeyStore ks = KeyStore.getInstance("PKCS12"); ks.load(null, null); ks.setKeyEntry("signer", k, a[2].toCharArray(), new java.security.cert.Certificate[]{c});
            try (OutputStream o = new FileOutputStream(a[1])) { ks.store(o, a[2].toCharArray()); }
            System.out.println("WROTE"); return;
        }
        byte[] bytes = Files.readAllBytes(Paths.get(a[0]));
        char[] password = new String(unhex(a[1]), StandardCharsets.UTF_8).toCharArray();
        long now = Long.parseLong(a[2]);
        try {
            KeyStore store;
            try { store = KeyStore.getInstance("PKCS12"); store.load(new ByteArrayInputStream(bytes), password); } catch (Exception e) { throw new Fail("BAD_FILE_OR_PASSWORD"); }
            String alias = null;
            for (String s : Collections.list(store.aliases())) if (store.isKeyEntry(s)) { alias = s; break; }
            if (alias == null) throw new Fail("NO_KEY");
            PrivateKey key;
            try { key = (PrivateKey) store.getKey(alias, password); } catch (Exception e) { throw new Fail("BAD_FILE_OR_PASSWORD"); }
            if (key == null) throw new Fail("NO_KEY");
            java.security.cert.Certificate[] raw = store.getCertificateChain(alias);
            List<X509Certificate> chain = new ArrayList<>();
            if (raw != null) for (java.security.cert.Certificate c : raw) if (c instanceof X509Certificate) chain.add((X509Certificate) c);
            if (chain.isEmpty()) throw new Fail("NO_KEY");
            X509Certificate leaf = chain.get(0);
            if (now < leaf.getNotBefore().getTime()) throw new Fail("NOT_YET_VALID");
            if (now > leaf.getNotAfter().getTime()) throw new Fail("EXPIRED");
            String alg; String kind = key.getAlgorithm().toUpperCase(Locale.ROOT);
            if (kind.equals("RSA")) {
                if (!(leaf.getPublicKey() instanceof RSAPublicKey)) throw new Fail("KEY_MISMATCH");
                if (((RSAPublicKey) leaf.getPublicKey()).getModulus().bitLength() < 2048) throw new Fail("WEAK_KEY");
                alg = "SHA256withRSA";
            } else if (kind.equals("EC")) {
                if (!(leaf.getPublicKey() instanceof ECPublicKey)) throw new Fail("KEY_MISMATCH");
                if (((ECPublicKey) leaf.getPublicKey()).getParams().getOrder().bitLength() < 256) throw new Fail("WEAK_KEY");
                alg = "SHA256withECDSA";
            } else throw new Fail("UNSUPPORTED_KEY");
            byte[] probe = new byte[32]; new SecureRandom().nextBytes(probe);
            boolean matches;
            try {
                Signature s = Signature.getInstance(alg); s.initSign(key); s.update(probe); byte[] sig = s.sign();
                Signature v = Signature.getInstance(alg); v.initVerify(leaf.getPublicKey()); v.update(probe); matches = v.verify(sig);
            } catch (Exception e) { matches = false; }
            if (!matches) throw new Fail("KEY_MISMATCH");
            Files.write(Paths.get(a[3] + ".pk8"), key.getEncoded());
            for (int i = 0; i < chain.size(); i++) Files.write(Paths.get(a[3] + "." + i + ".der"), chain.get(i).getEncoded());
            System.out.println("OK " + (kind.equals("RSA") ? "RSA" : "EC") + " " + chain.size());
        } catch (Fail f) { System.out.println("ERR " + f.reason); }
    }
    static String hex(byte[] b) { StringBuilder sb = new StringBuilder(); for (byte x : b) sb.append(String.format("%02x", x)); return sb.toString(); }
    static byte[] unhex(String h) { byte[] b = new byte[h.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return b; }
}
