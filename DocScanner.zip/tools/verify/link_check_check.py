#!/usr/bin/env python3
"""Kiểm tra liên kết của PDF CHẠY THẬT (`util/LinkCheck.kt`; phiên 24, TECHNICAL_DOCS.md 4.68; PDF 11.9) trên PdfBox thật và một máy chủ HTTP cục bộ.

  A. `classifyUri` (bảng 30 địa chỉ có đáp án viết tay: http / https đúng sai, mailto, tel, ftp, file, JavaScript) và `isPublicHost` (mô hình ĐỘC LẬP bằng module `ipaddress` của Python trên 3 000 địa chỉ IPv4
     ngẫu nhiên + các tên máy và IPv6 viết tay: localhost, *.local, tên không có dấu chấm, 10.x, 172.16-31, 192.168, 169.254, 100.64/10, ::1, fc00::, fe80::) + `statusOfCode`;
  B. quét PDF thật (pikepdf dựng): địa chỉ web đúng / có dấu cách / rỗng, mailto, tel, liên kết tới trang 3, tới một trang KHÔNG còn trong cây trang, tới đích có tên còn / mất, liên kết không có đích, JavaScript;
     và ca thực tế: liên kết tới trang 4 rồi XOÁ trang 4 -> `PAGE_MISSING`; tệp mã hoá -> null;
  C. thăm dò trực tuyến với máy chủ cục bộ (200, 301 -> 200, 404, 410, 500, HEAD bị từ chối 405 / 403 rồi GET được, treo quá thời gian, cổng không ai nghe) và quy tắc RIÊNG TƯ: địa chỉ nội bộ KHÔNG bị thăm dò
     (máy chủ không nhận yêu cầu nào) trừ khi cờ thử nghiệm bật; thăm dò chỉ gửi HEAD / GET tới đúng đường dẫn;
  D. THỬ ÂM TÍNH: 5 bản Kotlin hỏng (nhận địa chỉ web sai, coi 10.x là công khai, không phát hiện trang mất, coi 404 là tốt, bỏ thử GET khi HEAD bị từ chối) PHẢI bị bắt (`--fast` bỏ; `--mutant=N`).
KHÔNG kiểm được: hộp thoại và tiến trình trên máy, mạng Internet thật (máy chủ thử chạy cục bộ), liên kết trong tệp PDF dùng khoá đích hiếm. Cần: java 17+, github.com (toolchain), pikepdf.
Chạy: python3 tools/verify/link_check_check.py [--fast] [--mutant=N]"""
import ipaddress, os, random, re, shutil, socket, subprocess, sys, tempfile, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
import pikepdf  # noqa: E402
from pikepdf import Array, Dictionary, Name, String  # noqa: E402
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)
tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="linkchk-")
FILES = ["LinkCheck.kt"]; HARNESS = os.path.join(HERE, "real_run", "LinkCheckHarness.kt"); STUBS = os.path.join(HERE, "real_run", "UtilStubs.kt")
def build(mutate=None, tag="base"): return tc.compile(FILES, [HARNESS, STUBS], os.path.join(WORK, "cls-" + tag), mutate)[0]
def run(cls, args, stdin=None):
    r = tc.run(cls, "LinkCheckHarnessKt", args, stdin=stdin)
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-700:])
    return r.stdout
rnd = random.Random(24)

# ---------------------------------------------------------------- A. pure
print("== A. phần thuần"); cls = build()
URI = [("https://example.com/a?b=1", "WEB NONE"), ("http://example.com", "WEB NONE"), ("HTTPS://Example.COM/x", "WEB NONE"), ("http://bad host/x", "WEB BAD_ADDRESS"), ("http://", "WEB BAD_ADDRESS"),
       ("https://", "WEB BAD_ADDRESS"), ("http://.com", "WEB BAD_ADDRESS"), ("http://a..b.com", "WEB BAD_ADDRESS"), ("https://exa mple.com", "WEB BAD_ADDRESS"), ("http://192.168.1.1/admin", "WEB NONE"),
       ("mailto:info@example.com", "MAIL NONE"), ("mailto:a@b.co?subject=Hi%20there", "MAIL NONE"), ("MAILTO:Ten.Ho@mail.vn", "MAIL NONE"), ("mailto:not-an-email", "MAIL BAD_ADDRESS"), ("mailto:", "MAIL BAD_ADDRESS"),
       ("mailto:a@b", "MAIL BAD_ADDRESS"), ("tel:+84901234567", "PHONE NONE"), ("tel:+84 90 123 4567", "PHONE NONE"), ("tel:(028) 3822-1234", "PHONE NONE"), ("tel:abc", "PHONE BAD_ADDRESS"), ("tel:", "PHONE BAD_ADDRESS"),
       ("tel:12", "PHONE BAD_ADDRESS"), ("ftp://files.example.com/x", "OTHER NONE"), ("file:///sdcard/x.pdf", "OTHER NONE"), ("javascript:alert(1)", "OTHER NONE"), ("app://open", "OTHER NONE"), ("  https://example.com/pad  ", "WEB NONE"),
       ("https://example.com/with space", "WEB BAD_ADDRESS"), ("https://tiếng-việt.vn/", "WEB NONE"), ("https://例え.jp/", "WEB NONE"), ("https://xn--ti-ng-vit.vn", "WEB NONE"), ("https://user:pw@example.com:8080/p?q=1#f", "WEB NONE"),
       ("https://[2001:db8::1]:8443/x", "WEB NONE"), ("https://example.com:80x/", "WEB BAD_ADDRESS"), ("tel:12345", "PHONE NONE"), ("tel:1234", "PHONE BAD_ADDRESS"), ("tel:+1-800-555-0100", "PHONE NONE"), ("", "OTHER NONE")]
got = run(cls, [], "\n".join("URI " + u for u, _ in URI) + "\n").split("\n")[:-1]
check(all(g == w for (_, w), g in zip(URI, got)), f"{len(URI)} địa chỉ có đáp án viết tay: {[(u, w, g) for (u, w), g in zip(URI, got) if g != w][:2]}")
def py_public(h):
    h = h.lower().strip("[]")
    if h in ("localhost",) or h.endswith((".local", ".lan", ".internal", ".localdomain", ".home.arpa")): return False
    try: ip = ipaddress.ip_address(h)
    except ValueError: return "." in h
    if isinstance(ip, ipaddress.IPv4Address):
        nets = ["0.0.0.0/8", "10.0.0.0/8", "127.0.0.0/8", "169.254.0.0/16", "172.16.0.0/12", "192.168.0.0/16", "100.64.0.0/10", "224.0.0.0/3"]
        return not any(ip in ipaddress.ip_network(n) for n in nets)
    return not (ip.is_loopback or ip.is_unspecified or ip.is_multicast or ip.is_link_local or ip in ipaddress.ip_network("fc00::/7") or ip.ipv4_mapped is not None)
hosts = ["localhost", "LOCALHOST", "printer.local", "nas.lan", "router.internal", "intranet", "example.com", "sub.example.co.uk", "10.0.0.1", "172.15.0.1", "172.16.0.1", "172.31.255.255", "172.32.0.1", "192.168.0.10",
         "192.169.0.1", "169.254.169.254", "100.64.0.1", "100.127.255.255", "100.128.0.1", "8.8.8.8", "1.1.1.1", "[::1]", "::1", "fc00::1", "fd12:3456::1", "fe80::1", "2001:4860:4860::8888", "::ffff:10.0.0.1", "ff02::1", "256.1.1.1x", ""]
hosts += [".".join(str(rnd.randint(0, 255)) for _ in range(4)) for _ in range(3000)]
got = run(cls, [], "\n".join("HOST " + (h if h else "~null~") for h in hosts) + "\n").split("\n")[:-1]
want = [("1" if (py_public(h) if h else False) else "0") for h in hosts]
bad = [(h, w, g) for h, w, g in zip(hosts, want, got) if w != g and h != "256.1.1.1x"]
check(not bad, f"{len(hosts)} máy chủ (viết tay + 3 000 IPv4 ngẫu nhiên): isPublicHost khớp mô hình ipaddress độc lập {bad[:2]}")
codes = [100, 200, 204, 301, 302, 399, 400, 401, 403, 404, 410, 418, 500, 503]
got = run(cls, [], "\n".join(f"CODE {c}" for c in codes) + "\n").split("\n")[:-1]
exp = ["HTTP_ERROR", "OK", "OK", "OK", "OK", "OK", "HTTP_ERROR", "HTTP_ERROR", "HTTP_ERROR", "NOT_FOUND", "NOT_FOUND", "HTTP_ERROR", "HTTP_ERROR", "HTTP_ERROR"]
check(got == exp, f"mã trả về: 2xx / 3xx tốt, 404 / 410 mất, mã khác là lỗi máy chủ {list(zip(codes, got))[:3]}")

# ---------------------------------------------------------------- B. real PDFs
print("== B. quét PDF thật")
def build_links(path):
    pdf = pikepdf.new()
    for _ in range(5): pdf.add_blank_page(page_size=(612, 792))
    orphan = pdf.make_indirect(Dictionary(Type=Name.Page, MediaBox=Array([0, 0, 612, 792])))          # a page object that is NOT in the page tree
    pdf.Root.Names = Dictionary(Dests=Dictionary(Names=Array([String("chap2"), Array([pdf.pages[1].obj, Name.Fit])])))
    def link(**kw): return pdf.make_indirect(Dictionary(Type=Name.Annot, Subtype=Name.Link, Rect=Array([50, 700, 200, 720]), Border=Array([0, 0, 0]), **kw))
    uri = lambda u: Dictionary(S=Name.URI, URI=String(u))
    p0 = [link(A=uri("https://example.com/a")), link(A=uri("http://bad host/x")), link(A=uri("http://")), link(A=uri("mailto:info@example.com")), link(A=uri("mailto:not-an-email")),
          link(A=uri("tel:+84 90 123 4567")), link(A=uri("tel:abc")), link(Dest=Array([pdf.pages[2].obj, Name.Fit])), link(Dest=Array([orphan, Name.Fit])),
          link(A=Dictionary(S=Name.GoTo, D=String("chap2"))), link(A=Dictionary(S=Name.GoTo, D=String("nosuch"))), link(), link(A=Dictionary(S=Name.JavaScript, JS=String("app.alert(1)"))),
          link(A=uri("ftp://files.example.com/x")), link(A=Dictionary(S=Name.GoTo, D=Array([pdf.pages[4].obj, Name.XYZ, 0, 792, 0])))]
    pdf.pages[0].Annots = Array(p0)
    pdf.pages[1].Annots = Array([link(A=uri("https://example.org/b"))])
    pdf.save(path)
EXP = [(0, "WEB", "NONE", "https://example.com/a"), (0, "WEB", "BAD_ADDRESS", "http://bad host/x"), (0, "WEB", "BAD_ADDRESS", "http://"), (0, "MAIL", "NONE", "mailto:info@example.com"),
       (0, "MAIL", "BAD_ADDRESS", "mailto:not-an-email"), (0, "PHONE", "NONE", "tel:+84 90 123 4567"), (0, "PHONE", "BAD_ADDRESS", "tel:abc"), (0, "PAGE", "NONE", "page 3"),
       (0, "PAGE", "PAGE_MISSING", "page 0"), (0, "NAMED", "NONE", "chap2"), (0, "NAMED", "NAMED_MISSING", "nosuch"), (0, "OTHER", "NO_TARGET", ""), (0, "OTHER", "NONE", ""),
       (0, "OTHER", "NONE", "ftp://files.example.com/x"), (0, "PAGE", "NONE", "page 5"), (1, "WEB", "NONE", "https://example.org/b")]
def scan(cls, path):
    out = run(cls, ["scan", path]).strip("\n")
    if out == "NULL": return None
    res = []
    for l in out.split("\n"):
        if l: p, k, pr, t = (l.split("\t") + [""])[:4]; res.append((int(p), k, pr, t))
    return res
lp = os.path.join(WORK, "links.pdf"); build_links(lp); got = scan(cls, lp)
check(got == EXP, f"16 liên kết đủ loại: loại, vấn đề và đích đúng từng cái {[(a, b) for a, b in zip(got or [], EXP) if a != b][:2]}")
# the page of the dest in the *orphan* case is reported as PAGE with number -1 + 1 = 0: "page 0" (documented): what matters is PAGE_MISSING
dp = os.path.join(WORK, "deleted.pdf")
with pikepdf.new() as pdf:
    for _ in range(5): pdf.add_blank_page(page_size=(612, 792))
    pdf.pages[0].Annots = Array([pdf.make_indirect(Dictionary(Type=Name.Annot, Subtype=Name.Link, Rect=Array([50, 700, 200, 720]), Dest=Array([pdf.pages[3].obj, Name.Fit]))),
                                 pdf.make_indirect(Dictionary(Type=Name.Annot, Subtype=Name.Link, Rect=Array([50, 600, 200, 620]), Dest=Array([pdf.pages[1].obj, Name.Fit])))])
    del pdf.pages[3]; pdf.save(dp)
got = scan(cls, dp); check(got is not None and [g[2] for g in got] == ["PAGE_MISSING", "NONE"], f"ca thực tế: liên kết tới trang 4 rồi XOÁ trang 4 -> PAGE_MISSING; liên kết tới trang 2 vẫn tốt ({got})")
ep = os.path.join(WORK, "enc.pdf")
with pikepdf.open(lp) as pdf: pdf.save(ep, encryption=pikepdf.Encryption(user="u", owner="o"))
check(scan(cls, ep) is None, "tệp mã hoá -> null (trình đọc làm việc trên bản đã mở khoá)")
np_ = os.path.join(WORK, "none.pdf")
with pikepdf.new() as pdf: pdf.add_blank_page(page_size=(612, 792)); pdf.save(np_)
check(scan(cls, np_) == [], "PDF không có liên kết -> danh sách rỗng")

# ---------------------------------------------------------------- C. probe against a local server
print("== C. thăm dò trực tuyến (máy chủ cục bộ)")
LOG = []
class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass
    def _do(self, method):
        LOG.append((method, self.path)); p = self.path
        if p == "/ok": self.send_response(200)
        elif p == "/redir": self.send_response(301); self.send_header("Location", "/ok")
        elif p == "/nf": self.send_response(404)
        elif p == "/gone": self.send_response(410)
        elif p == "/err": self.send_response(500)
        elif p == "/nohead": self.send_response(405 if method == "HEAD" else 200)
        elif p == "/forbidhead": self.send_response(403 if method == "HEAD" else 200)
        elif p == "/slow": time.sleep(3); self.send_response(200)
        else: self.send_response(404)
        self.send_header("Content-Length", "0"); self.end_headers()
    def do_HEAD(self): self._do("HEAD")
    def do_GET(self): self._do("GET")
srv = ThreadingHTTPServer(("127.0.0.1", 0), H); port = srv.server_address[1]; threading.Thread(target=srv.serve_forever, daemon=True).start()
def probe(cls, path, local=True):
    args = ["probe", f"http://127.0.0.1:{port}{path}"] + (["local"] if local else []); return run(cls, args).strip()
CASES = [("/ok", "OK 200"), ("/redir", "OK 200"), ("/nf", "NOT_FOUND 404"), ("/gone", "NOT_FOUND 410"), ("/err", "HTTP_ERROR 500"), ("/nohead", "OK 200"), ("/forbidhead", "OK 200"), ("/slow", "TIMEOUT 0")]
for path, want in CASES: LOG.clear(); g = probe(cls, path); check(g == want, f"{path}: {g} (đáp án {want}); yêu cầu đã gửi {[m for m, _ in LOG][:3]}")
LOG.clear(); probe(cls, "/nohead"); check([m for m, _ in LOG] == ["HEAD", "GET"], f"HEAD bị từ chối (405) -> thử lại bằng GET: {LOG}")
LOG.clear(); probe(cls, "/ok"); check([m for m, _ in LOG] == ["HEAD"], f"máy chủ chấp nhận HEAD -> CHỈ HEAD, không tải nội dung: {LOG}")
LOG.clear(); g = probe(cls, "/ok", local=False); check(g == "SKIPPED_LOCAL 0" and not LOG, f"địa chỉ nội bộ KHÔNG bị thăm dò khi không bật cờ thử nghiệm ({g}, máy chủ nhận {len(LOG)} yêu cầu)")
s = socket.socket(); s.bind(("127.0.0.1", 0)); dead = s.getsockname()[1]; s.close()
g = run(cls, ["probe", f"http://127.0.0.1:{dead}/x", "local"]).strip(); check(g == "UNREACHABLE 0", f"cổng không ai nghe: {g}")
g = run(cls, ["probe", "http://no-such-host-docscanner.invalid/x"]).strip(); check(g.startswith(("UNREACHABLE", "SKIPPED_LOCAL")), f"tên miền không tồn tại: {g}")
srv.shutdown()

ONLY = next((int(a.split("=")[1]) for a in sys.argv if a.startswith("--mutant=")), None)
if "--fast" in sys.argv and ONLY is None: print("== D. bỏ qua thử âm tính (--fast)")
else:
    print("== D. thử âm tính")
    srv2 = ThreadingHTTPServer(("127.0.0.1", 0), H); port = srv2.server_address[1]; threading.Thread(target=srv2.serve_forever, daemon=True).start()
    MUT = [("nhận mọi địa chỉ web", ("!h.isNullOrBlank() && !h.startsWith(\".\") && !h.endsWith(\".\") && !h.contains(\"..\")", "true")),
           ("coi 10.x là công khai", ("p[0] == 10 || p[0] == 127", "p[0] == 127")),
           ("không phát hiện trang mất", ("if (n in 0 until pages) Problem.NONE else Problem.PAGE_MISSING", "Problem.NONE")),
           ("coi 404 là tốt", ("code == 404 || code == 410 -> Status.NOT_FOUND", "code == 410 -> Status.NOT_FOUND")),
           ("bỏ thử GET khi HEAD bị từ chối", ("if (code == 403 || code == 405 || code == 501) code = request(url.trim(), \"GET\", timeoutMs)", ""))]
    for number, (name, (old, new)) in enumerate(MUT, 1):
        if ONLY is not None and number != ONLY: continue
        try: mcls = build({"LinkCheck.kt": (old, new)}, tag="mut")
        except RuntimeError as exc: check("mutation target not found" not in str(exc), f"ÂM TÍNH '{name}': bản hỏng không biên dịch (bị bắt)"); continue
        caught = False
        try:
            got = run(mcls, [], "\n".join("URI " + u for u, _ in URI) + "\n").split("\n")[:-1]
            if any(g != w for (_, w), g in zip(URI, got)): caught = True
            got = run(mcls, [], "\n".join("HOST " + (h if h else "~null~") for h in hosts[:40]) + "\n").split("\n")[:-1]
            if any(g != w for g, w in zip(got, want[:40])): caught = True
            sc = scan(mcls, lp)
            if sc != EXP: caught = True
            if run(mcls, ["probe", f"http://127.0.0.1:{port}/nf", "local"]).strip() != "NOT_FOUND 404": caught = True
            if run(mcls, ["probe", f"http://127.0.0.1:{port}/nohead", "local"]).strip() != "OK 200": caught = True
        except SystemExit: caught = True
        check(caught, f"ÂM TÍNH '{name}': bản hỏng bị bắt")
    srv2.shutdown()
shutil.rmtree(WORK, ignore_errors=True); print("\nTAT CA DAT" if not fails else f"\n{len(fails)} LOI"); sys.exit(1 if fails else 0)
