#!/usr/bin/env python3
"""Lịch sử chỉnh sửa của trình đọc CHẠY THẬT (`util/ReaderEdits.kt`; phiên 25, TECHNICAL_DOCS.md 4.72): Hoàn tác, LÀM LẠI, TẨY (xoá nét / dấu dưới ngón tay), nhóm (một lần kéo qua nhiều dòng),
thay thế (sửa lại cùng một đoạn chữ / ô biểu mẫu), độ dày nét.

Kịch bản viết TAY với kết quả mong đợi viết tay (không phải một bản cài lại cùng logic): mỗi dòng của kịch bản là một lệnh, mỗi dòng mong đợi là kết quả của nó.
KHÔNG kiểm được: cảm ứng thật, vẽ lại trang sau khi tẩy / làm lại. Chạy: python3 tools/verify/reader_edits_real_run_check.py"""
import os, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="redits-")
HARNESS = os.path.join(HERE, "real_run", "ReaderEditsHarness.kt")
cls = tc.compile(["ReaderEdits.kt"], [HARNESS], os.path.join(WORK, "cls"), None, None)[0]
def run(script):
    r = tc.run(cls, "ReaderEditsHarnessKt", [], stdin="\n".join(script) + "\n")
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-1200:])
    return r.stdout.splitlines()
def scenario(name, steps):
    out = run([s for s, _ in steps]); want = [w for _, w in steps]
    check(out == want, name + ("" if out == want else f"\n   nhận     {out}\n   mong đợi {want}"))

BOX = "0.1,0.1,0.2,0.2"
def add(label, kind="HIGHLIGHT", page=0, box=BOX, group=0, pts="-", width=0): return f"add {label} {kind} {page} {box} {group} {pts} {width}"

print("== A. hoàn tác / làm lại")
scenario("làm lại đưa lại đúng thứ tự; một dấu mới xoá phần làm lại", [
    (add("a"), "true"), (add("b"), "true"), (add("c"), "true"), ("state", "a,b,c redo=false"),
    ("undo", "c"), ("undo", "b"), ("state", "a redo=true"),
    ("redo", "b"), ("state", "a,b redo=true"), ("redo", "c"), ("redo", "-"), ("state", "a,b,c redo=false"),
    ("undo", "c"), (add("d"), "true"), ("state", "a,b,d redo=false"), ("redo", "-"),
])
scenario("nhóm: hoàn tác và làm lại CẢ nhóm (một lần kéo qua 3 dòng)", [
    (add("x"), "true"), ("newgroup", "1"), (add("l1", group=1), "true"), (add("l2", group=1), "true"), (add("l3", group=1), "true"), (add("y"), "true"),
    ("undo", "y"), ("undo", "l1"), ("state", "x redo=true"),            # the whole group went with ONE undo
    ("redo", "l3"), ("state", "x,l1,l2,l3 redo=true"),                    # and came back with ONE redo, in the same order (it reports the last mark it put back)
    ("redo", "y"), ("state", "x,l1,l2,l3,y redo=false"),
])
scenario("hoàn tác khi không còn gì / làm lại khi không còn gì", [("undo", "-"), ("redo", "-"), ("state", "- redo=false")])
scenario("xoá hết rồi không làm lại được", [(add("a"), "true"), ("undo", "a"), ("clear", "cleared"), ("redo", "-"), ("state", "- redo=false")])

print("== B. thay thế (sửa lại cùng đoạn chữ / ô): hoàn tác trả lại BẢN TRƯỚC, không mất hẳn")
def addc(label, kind, chunk=-1, name="-", page=0): return f"add {label} {kind} {page} {BOX} 0 - 0 {chunk} {name}"
scenario("EDITTEXT: sửa lại cùng đoạn thay lần trước; hoàn tác trả BẢN TRƯỚC, làm lại đưa bản sau", [
    (addc("e1", "EDITTEXT", 3), "true"), (addc("e2", "EDITTEXT", 3), "true"), ("state", "e2 redo=false"),
    (addc("other", "EDITTEXT", 4), "true"), ("state", "e2,other redo=false"),          # another piece is a separate edit
    (addc("e3", "EDITTEXT", 3, page=1), "true"), ("state", "e2,other,e3 redo=false"),   # the same piece number on ANOTHER page too
    ("undo", "e3"), ("undo", "other"), ("undo", "e1"), ("state", "e1 redo=true"),        # the earlier wording is back, not lost
    ("redo", "e2"), ("state", "e2 redo=true"),
])
scenario("FORM: điền lại cùng một ô chỉ giữ giá trị cuối (theo tên ô); hoàn tác trả giá trị trước", [
    (addc("f1", "FORM", name="nm"), "true"), (addc("f2", "FORM", name="nm"), "true"), (addc("f3", "FORM", name="ok"), "true"),
    ("state", "f2,f3 redo=false"), ("undo", "f3"), ("undo", "f1"), ("state", "f1 redo=true"),
])
print("== C. tẩy")
LINE = "0.1,0.5,0.5,0.5,0.9,0.5"; LBOX = "0.1,0.5,0.9,0.5"
scenario("chạm trúng nét bút thì xoá nét đó; chạm xa thì không", [
    (add("s1", "PEN", 0, LBOX, 0, LINE, 0.004), "true"),
    ("hit 0 0.3 0.5", "s1"), ("hit 0 0.3 0.6", "-"), ("hit 0 0.3 0.515", "s1"), ("hit 1 0.3 0.5", "-"),     # 0.015 radius; another page: nothing
    ("erase 0 0.3 0.6", "0"), ("state", "s1 redo=false"),
    ("erase 0 0.3 0.5", "1"), ("state", "- redo=false"),
    ("undo", "s1"), ("state", "s1 redo=true"),                                # undo of an erase puts it back
    ("redo", "s1"), ("state", "- redo=false"),                                # redo erases it again; nothing is left to redo
])
scenario("nét dày (bút dạ) chạm tới cả ngoài mép nét; nét mảnh thì không", [
    (add("thin", "PEN", 0, "0.1,0.2,0.9,0.2", 0, "0.1,0.2,0.9,0.2", 0.004), "true"),
    (add("fat", "MARKER", 0, "0.1,0.4,0.9,0.4", 0, "0.1,0.4,0.9,0.4", 0.044), "true"),
    ("hit 0 0.5 0.231", "-"),           # 0.031 above the thin stroke: outside 0.015 + 0.002
    ("hit 0 0.5 0.215", "thin"),        # 0.015 above: inside 0.015 + 0.002
    ("hit 0 0.5 0.436", "fat"),         # 0.036 above the fat one: inside 0.015 + 0.022
    ("hit 0 0.5 0.45", "-"),            # 0.05: outside
])
scenario("dấu dạng hộp (tô sáng, hộp đen): chạm trong hộp hoặc sát mép", [
    (add("h", "HIGHLIGHT", 0, "0.2,0.3,0.6,0.35"), "true"),
    ("hit 0 0.4 0.32", "h"), ("hit 0 0.4 0.36", "h"), ("hit 0 0.4 0.40", "-"), ("hit 0 0.1 0.32", "-"),
])
scenario("tẩy một dòng của nhóm xoá CẢ nhóm; hoàn tác trả đủ đúng chỗ", [
    (add("k"), "true"), ("newgroup", "1"),
    (add("g1", "HIGHLIGHT", 0, "0.1,0.1,0.5,0.12", 1), "true"), (add("g2", "HIGHLIGHT", 0, "0.1,0.13,0.5,0.15", 1), "true"), (add("m"), "true"),
    ("erase 0 0.3 0.14", "2"), ("state", "k,m redo=false"),
    ("undo", "g1"), ("state", "k,g1,g2,m redo=true"),
])
scenario("tẩy lấy dấu MỚI NHẤT khi hai dấu chồng nhau", [
    (add("old", "HIGHLIGHT", 0, "0.2,0.2,0.6,0.3"), "true"), (add("new", "BLACKBOX", 0, "0.3,0.2,0.5,0.3"), "true"),
    ("hit 0 0.4 0.25", "new"), ("erase 0 0.4 0.25", "1"), ("state", "old redo=false"), ("hit 0 0.4 0.25", "old"),
])
print("== D. giới hạn")
scenario("quá MAX_ITEMS (500) thì từ chối, làm lại không vượt quá", [(add(f"m{i}"), "true") for i in range(500)] + [(add("extra"), "false")])

print("== E. thử âm tính: mã cố tình sai PHẢI bị bắt")
def behaves(class_dir):
    """True when this build does what the hand-written expectations say: a new mark clears Redo, and undo takes a whole group"""
    def runc(lines):
        out = tc.run(class_dir, "ReaderEditsHarnessKt", [], stdin="\n".join(lines) + "\n").stdout.split("\n")
        return out[:-1] if out and out[-1] == "" else out
    r = runc([add("a"), add("b"), "undo", add("c"), "redo", "state"])
    g = runc([add("k"), "newgroup", add("g1", group=1), add("g2", group=1), "undo", "state"])
    return r == ["true", "true", "b", "true", "-", "a,c redo=false"] and g == ["true", "1", "true", "true", "g1", "k redo=true"]
def mutant_fails(old, new):
    try: mdir = tc.compile(["ReaderEdits.kt"], [HARNESS], os.path.join(WORK, "mut"), {"ReaderEdits.kt": (old, new)}, None)[0]
    except RuntimeError as e: return "không biên dịch: " + str(e)[:100]
    return not behaves(mdir)
check(behaves(cls), "đối chứng: mã gốc đạt phép thử của thử âm tính")
for name, old, new in (("một dấu mới KHÔNG xoá phần làm lại", "        undoStack.add(Change.Added(item))\n        redoStack.clear()", "        undoStack.add(Change.Added(item))"),
                       ("hoàn tác không lấy cả nhóm", "val again = group != 0 && next is Change.Added && next.item.group == group\n        } while (again)\n        return touched\n    }\n\n    /** Puts back", "val again = false\n        } while (again)\n        return touched\n    }\n\n    /** Puts back")):
    r = mutant_fails(old, new); check(r is True, f"mã sai bị bắt: {name}" + ("" if r is True else f" ({r})"))

print()
print("TAT CA DAT" if not fails else f"{len(fails)} LOI")
sys.exit(1 if fails else 0)
