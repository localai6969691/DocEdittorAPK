"""Ghim băm SHA-256 của `rus.traineddata` (OCR chữ Cyrillic; `TesseractOcr.kt`, phiên 23, mục 4.45 / 6).
Đọc URL, khung kích thước và `EXPECTED_SHA256` TRỰC TIẾP từ TesseractOcr.kt (không chép lại, để khỏi lệch), tải tệp (hoặc dùng --file), rồi:
  - ngoài khung MIN_BYTES..MAX_BYTES, hoặc không tải được từ mọi URL  -> LỖI (exit 1);
  - EXPECTED_SHA256 còn TRỐNG -> exit 0 và in đúng dòng cần dán vào mã (+ ghi vào $GITHUB_STEP_SUMMARY nếu có);
  - đã điền và KHỚP -> exit 0;  đã điền nhưng KHÁC -> LỖI (tệp ở kho tessdata_fast đã đổi hoặc bị hỏng).
Dùng: python3 tessdata_pin_check.py             tải thật (cần mạng; chạy trong GitHub Actions)
      python3 tessdata_pin_check.py --file F    dùng tệp F thay vì tải
      python3 tessdata_pin_check.py --selftest  tự kiểm logic, KHÔNG cần mạng (chạy được ở mọi nơi)"""
import hashlib, os, re, sys, tempfile, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
KT = os.path.join(HERE, "..", "..", "app", "src", "main", "java", "com", "example", "docscanner", "util", "TesseractOcr.kt")

def parse(src):
    urls = re.search(r"private val URLS = listOf\((.*?)\)", src, re.S)
    sha = re.search(r'private const val EXPECTED_SHA256 = "([0-9a-fA-F]*)"', src)
    lo = re.search(r"private const val MIN_BYTES = ([\d_]+)L", src)
    hi = re.search(r"private const val MAX_BYTES = ([\d_]+)L", src)
    if not (urls and sha and lo and hi): raise SystemExit("LOI: không đọc được URLS / EXPECTED_SHA256 / MIN_BYTES / MAX_BYTES trong TesseractOcr.kt (đổi tên? sửa bộ kiểm này)")
    u = re.findall(r'"(https://[^"]+)"', urls.group(1))
    if not u: raise SystemExit("LOI: URLS rỗng")
    return u, sha.group(1).lower(), int(lo.group(1).replace("_", "")), int(hi.group(1).replace("_", ""))

def fetch(urls):
    err = []
    for u in urls:
        try:
            opener = urllib.request.build_opener()
            return opener.open(urllib.request.Request(u, headers={"User-Agent": "docscanner-ci"}), timeout=120).read(), u
        except Exception as e: err.append(f"{u}: {e}")
    raise SystemExit("LOI: không tải được từ URL nào:\n  " + "\n  ".join(err))

def judge(data, expected, lo, hi, log=print):
    """-> exit code"""
    got = hashlib.sha256(data).hexdigest()
    log(f"kích thước {len(data)} byte, sha256 {got}")
    if not (lo <= len(data) <= hi):
        log(f"LOI: ngoài khung {lo}..{hi} byte"); return 1
    if not expected:
        log("THONG BAO: EXPECTED_SHA256 còn trống. Dán dòng sau vào TesseractOcr.kt:")
        log(f'    private const val EXPECTED_SHA256 = "{got}"'); return 0
    if got != expected:
        log(f"LOI: băm khác giá trị đã ghim ({expected}); tệp ở kho tessdata_fast đã đổi hoặc bị hỏng"); return 1
    log("DAT: khớp băm đã ghim"); return 0

def selftest():
    src = open(KT, encoding="utf-8").read()
    urls, exp, lo, hi = parse(src)
    ok = True
    def case(name, data, expected, want):
        nonlocal ok
        out = []; rc = judge(data, expected, lo, hi, out.append)
        good = rc == want
        print(("ok   " if good else "LOI  ") + name); ok &= good
        return out
    body = os.urandom(lo + 1000)
    h = hashlib.sha256(body).hexdigest()
    case("đã ghim và khớp -> 0", body, h, 0)
    out = case("chưa ghim -> 0 và in đúng dòng cần dán", body, "", 0)
    ok &= any(l.strip() == f'private const val EXPECTED_SHA256 = "{h}"' for l in out)
    print(("ok   " if any(l.strip().startswith('private const val EXPECTED_SHA256 = "') for l in out) else "LOI  ") + "dòng in ra đúng cú pháp Kotlin")
    case("đã ghim nhưng tệp khác -> 1", os.urandom(lo + 1000), h, 1)
    case("tệp quá nhỏ (trang lỗi HTML) -> 1", b"<html>404</html>", "", 1)
    case("tệp quá lớn -> 1", b"\0" * (hi + 1), "", 1)
    case("đúng biên dưới -> 0", b"\1" * lo, "", 0)
    case("đúng biên trên -> 0", b"\1" * hi, "", 0)
    print(("ok   " if len(urls) >= 1 and all(u.startswith("https://") for u in urls) else "LOI  ") + f"TesseractOcr.kt có {len(urls)} URL https và khung {lo}..{hi}; băm đã ghim: {'(trống)' if not exp else exp}")
    ok &= len(urls) >= 1 and all(u.startswith("https://") for u in urls)
    # parse phải báo lỗi rõ khi mã đổi hình dạng
    try: parse("object X {}"); ok = False; print("LOI  parse không báo lỗi khi mất hằng")
    except SystemExit: print("ok   parse báo lỗi rõ khi TesseractOcr.kt mất hằng")
    print(); print("TAT CA DAT" if ok else "CO LOI"); return 0 if ok else 1

def main(a):
    if "--selftest" in a: return selftest()
    urls, expected, lo, hi = parse(open(KT, encoding="utf-8").read())
    if "--file" in a: data = open(a[a.index("--file") + 1], "rb").read(); src = "tệp cục bộ"
    else: data, src = fetch(urls)
    print("nguồn:", src)
    lines = []
    rc = judge(data, expected, lo, hi, lambda s: (print(s), lines.append(s)))
    summary = os.environ.get("GITHUB_STEP_SUMMARY")
    if summary:
        with open(summary, "a", encoding="utf-8") as f: f.write("### rus.traineddata\n```\n" + "\n".join(lines) + "\n```\n")
    return rc

if __name__ == "__main__": sys.exit(main(sys.argv[1:]))
