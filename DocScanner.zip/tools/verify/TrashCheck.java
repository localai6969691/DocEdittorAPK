// Bản Java chạy được của TrashStore + BulkRename (phiên 17): cùng logic, chạy trên thư mục THẬT.
// Dùng bởi trash_rename_check.py. Lệnh: trash <thùng> <tệp> <now> | list <thùng> | restore <thùng> <xuất> <số thứ tự> | purge <thùng> <now> | empty <thùng>
//   | pure <tệp ca> | plan <tệp ca> (tệp ca: dòng 1 = mẫu, dòng 2 = số bắt đầu, dòng 3 = tên đang có (phân cách bằng \t), các dòng sau "tên\tmodified")
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class TrashCheck {
    static final long DAY = 86_400_000L;
    static final int RETENTION = 30;

    // ---- SmartNamer ----
    static String sanitize(String raw) {
        StringBuilder b = new StringBuilder();
        for (char c : raw.toCharArray()) b.append("\\/:*?\"<>|\n\r\t".indexOf(c) >= 0 ? ' ' : c);
        String collapsed = trimDots(b.toString().replaceAll("\\s+", " ").strip());
        if (collapsed.length() > 60) collapsed = collapsed.substring(0, 60);
        return trimDots(collapsed.strip());
    }
    static String trimDots(String s) { int a = 0, e = s.length(); while (a < e && s.charAt(a) == '.') a++; while (e > a && s.charAt(e - 1) == '.') e--; return s.substring(a, e).strip(); }
    interface Exists { boolean test(String n); }
    static String uniqueName(Exists exists, String base, String ext) {
        String e = ext.isEmpty() ? "" : "." + ext; String c = base + e; int n = 2;
        while (exists.test(c)) { c = base + " (" + n + ")" + e; n++; }
        return c;
    }

    // ---- TrashStore ----
    static String trashName(long at, String orig) { return at + "__" + orig; }
    static long[] parseAt = new long[1]; static String parseName;
    static boolean parse(String n) {
        int cut = n.indexOf("__");
        if (cut <= 0 || cut + 2 >= n.length()) return false;
        String d = n.substring(0, cut);
        if (d.length() > 18) return false;
        for (char c : d.toCharArray()) if (c < '0' || c > '9') return false;
        parseAt[0] = Long.parseLong(d); parseName = n.substring(cut + 2); return true;
    }
    static boolean isExpired(long at, long now) { return now >= at && now - at >= RETENTION * DAY; }
    static int daysLeft(long at, long now) {
        long left = RETENTION * DAY - (now - at);
        if (left <= 0) return 0;
        return (int) Math.min(RETENTION, (left + DAY - 1) / DAY);
    }
    static class Entry { File file; long at; String orig; Entry(File f, long a, String o) { file = f; at = a; orig = o; } }

    static boolean move(File s, File d) {
        if (s.renameTo(d)) return true;
        try { Files.copy(s.toPath(), d.toPath()); s.delete(); return true; } catch (Exception e) { d.delete(); return false; }
    }
    static boolean moveToTrash(File trash, File file, long now) { return moveToTrash(trash, file, now, null); }
    static File metaFile(File trash, Entry e) { return new File(trash, trashName(e.at, e.orig + ".meta")); }
    static boolean moveToTrash(File trash, File file, long now, String meta) {
        if (!file.isFile()) return false;
        trash.mkdirs();
        File target = new File(trash, trashName(now, file.getName()));
        if (target.exists()) return false;
        if (!move(file, target)) return false;
        if (file.getName().toLowerCase().endsWith(".pdf")) {
            String nm = file.getName();
            File side = new File(file.getParentFile(), nm.substring(0, nm.length() - 4) + ".txt");
            if (side.isFile()) move(side, new File(trash, trashName(now, side.getName())));
        }
        if (meta != null) try { Files.write(new File(trash, trashName(now, file.getName() + ".meta")).toPath(), meta.getBytes(StandardCharsets.UTF_8)); } catch (Exception e) { }
        return true;
    }
    static boolean isSidecar(List<Entry> all, Entry e) {
        if (!e.orig.toLowerCase().endsWith(".txt")) return false;
        String base = e.orig.substring(0, e.orig.length() - 4);
        for (Entry o : all) if (o.at == e.at && o.orig.equalsIgnoreCase(base + ".pdf")) return true;
        return false;
    }
    static boolean isMeta(List<Entry> all, Entry e) {
        if (!e.orig.endsWith(".meta")) return false;
        String base = e.orig.substring(0, e.orig.length() - 5);
        for (Entry o : all) if (o.at == e.at && o.orig.equals(base)) return true;
        return false;
    }
    static List<Entry> entries(File trash) {
        List<Entry> all = new ArrayList<>();
        File[] fs = trash.listFiles(File::isFile);
        if (fs != null) for (File f : fs) if (parse(f.getName())) all.add(new Entry(f, parseAt[0], parseName));
        List<Entry> out = new ArrayList<>();
        for (Entry e : all) if (!isSidecar(all, e) && !isMeta(all, e)) out.add(e);
        out.sort((a, b) -> a.at != b.at ? Long.compare(b.at, a.at) : a.orig.compareTo(b.orig));
        return out;
    }
    static File sidecarOf(File trash, Entry e) {
        if (!e.orig.toLowerCase().endsWith(".pdf")) return null;
        File f = new File(trash, trashName(e.at, e.orig.substring(0, e.orig.length() - 4) + ".txt"));
        return f.isFile() ? f : null;
    }
    static File restore(File trash, File export, Entry e) {
        if (!e.file.isFile()) return null;
        export.mkdirs();
        int dot = e.orig.lastIndexOf('.');
        String ext = dot >= 0 ? e.orig.substring(dot + 1) : "";
        String base = ext.isEmpty() ? e.orig : e.orig.substring(0, e.orig.length() - ext.length() - 1);
        File side = sidecarOf(trash, e);
        String name = uniqueName(n -> new File(export, n).exists() || (side != null && new File(export, (n.endsWith(".pdf") ? n.substring(0, n.length() - 4) : n) + ".txt").exists()), base, ext);
        File target = new File(export, name);
        if (!move(e.file, target)) return null;
        if (side != null) { String tn = target.getName(); move(side, new File(export, tn.substring(0, tn.lastIndexOf('.')) + ".txt")); }
        metaFile(trash, e).delete();
        return target;
    }
    static void deleteForever(File trash, Entry e) { File sc = sidecarOf(trash, e); if (sc != null) sc.delete(); metaFile(trash, e).delete(); e.file.delete(); }
    static int purge(File trash, long now) {
        int n = 0; File[] fs = trash.listFiles(File::isFile);
        if (fs != null) for (File f : fs) if (parse(f.getName()) && isExpired(parseAt[0], now) && f.delete()) n++;
        return n;
    }
    static int empty(File trash) {
        int n = 0; File[] fs = trash.listFiles(File::isFile);
        if (fs != null) for (File f : fs) if (parse(f.getName()) && f.delete()) n++;
        return n;
    }

    // ---- TrashMeta ----
    static String hexOf(String x) { StringBuilder b = new StringBuilder(); for (byte y : x.getBytes(StandardCharsets.UTF_8)) b.append(String.format("%02x", y & 0xff)); return b.toString(); }
    static String unhexOrNull(String h) {
        if (h.isEmpty() || h.length() % 2 != 0) return null;
        byte[] b = new byte[h.length() / 2];
        for (int i = 0; i < b.length; i++) { try { b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); } catch (Exception e) { return null; } if (h.charAt(2 * i) == '+' || h.charAt(2 * i) == '-' || h.charAt(2 * i + 1) == '+' || h.charAt(2 * i + 1) == '-') return null; }
        return new String(b, StandardCharsets.UTF_8);
    }
    static String metaEncode(boolean fav, List<String> tags) { StringBuilder b = new StringBuilder("fav=" + (fav ? "1" : "0") + "\n"); for (String t : tags) b.append("tag=").append(hexOf(t)).append("\n"); return b.toString(); }
    static String metaDecode(String text) {
        boolean fav = false; LinkedHashSet<String> tags = new LinkedHashSet<>();
        for (String line : text.split("\n", -1)) {
            String l = line.trim();
            if (l.equals("fav=1")) fav = true;
            else if (l.startsWith("tag=")) { String t = unhexOrNull(l.substring(4)); if (t != null && !t.isEmpty()) tags.add(t); }
        }
        StringBuilder o = new StringBuilder(fav ? "1" : "0"); o.append("|");
        boolean first = true; for (String t : tags) { if (!first) o.append(","); o.append(hexOf(t)); first = false; }
        return o.toString();
    }

    // ---- BulkRename ----
    static List<String> plan(List<String[]> items, String pattern, int start, Set<String> taken) {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd", Locale.US); fmt.setTimeZone(TimeZone.getTimeZone("UTC"));
        Map<String, Integer> existing = new HashMap<>();
        for (String t : taken) existing.merge(t.toLowerCase(), 1, Integer::sum);
        Set<String> assigned = new HashSet<>();
        int w = Math.max(1, String.valueOf(Math.max(0, start + items.size() - 1)).length());
        List<String> out = new ArrayList<>();
        for (int i = 0; i < items.size(); i++) {
            String name = items.get(i)[0]; long mod = Long.parseLong(items.get(i)[1]);
            int dot = name.lastIndexOf('.');
            String ext = dot > 0 ? name.substring(dot + 1) : "";
            String oldBase = dot > 0 ? name.substring(0, dot) : name;
            String num = String.valueOf(start + i); while (num.length() < w) num = "0" + num;
            String raw = pattern.replace("{n}", num).replace("{name}", oldBase).replace("{date}", fmt.format(new Date(mod)));
            String base = sanitize(raw);
            if (base.isEmpty()) { base = sanitize(oldBase); if (base.isEmpty()) base = "document"; }
            final String own = name;
            String nn = uniqueName(c -> { String l = c.toLowerCase(); return assigned.contains(l) || (existing.getOrDefault(l, 0) > 0 && !c.equals(own)); }, base, ext);
            assigned.add(nn.toLowerCase());
            if (!nn.equals(name)) existing.put(name.toLowerCase(), existing.getOrDefault(name.toLowerCase(), 1) - 1);
            out.add(nn);
        }
        return out;
    }

    public static void main(String[] a) throws Exception {
        switch (a[0]) {
            case "trash": System.out.println(moveToTrash(new File(a[1]), new File(a[2]), Long.parseLong(a[3])) ? "OK" : "FAIL"); break;
            case "trashm": System.out.println(moveToTrash(new File(a[1]), new File(a[2]), Long.parseLong(a[3]), new String(Files.readAllBytes(Paths.get(a[4])), StandardCharsets.UTF_8)) ? "OK" : "FAIL"); break;
            case "readmeta": { List<Entry> es = entries(new File(a[1])); File m = metaFile(new File(a[1]), es.get(Integer.parseInt(a[2]))); System.out.println(m.isFile() ? new String(Files.readAllBytes(m.toPath()), StandardCharsets.UTF_8).replace("\n", "|") : "NONE"); break; }
            case "forever": { List<Entry> es = entries(new File(a[1])); deleteForever(new File(a[1]), es.get(Integer.parseInt(a[2]))); System.out.println("OK"); break; }
            case "list": for (Entry e : entries(new File(a[1]))) System.out.println(e.at + "\t" + e.orig); break;
            case "restore": { List<Entry> es = entries(new File(a[1])); File r = restore(new File(a[1]), new File(a[2]), es.get(Integer.parseInt(a[3]))); System.out.println(r == null ? "FAIL" : r.getName()); break; }
            case "purge": System.out.println(purge(new File(a[1]), Long.parseLong(a[2]))); break;
            case "empty": System.out.println(empty(new File(a[1]))); break;
            case "pure": {
                for (String ln : Files.readAllLines(Paths.get(a[1]))) {
                    String[] p = ln.split("\t", -1);
                    if (p[0].equals("parse")) System.out.println(parse(p[1]) ? parseAt[0] + "\t" + parseName : "NULL");
                    else if (p[0].equals("expired")) System.out.println(isExpired(Long.parseLong(p[1]), Long.parseLong(p[2])));
                    else if (p[0].equals("left")) System.out.println(daysLeft(Long.parseLong(p[1]), Long.parseLong(p[2])));
                    else if (p[0].equals("menc")) { List<String> tg = new ArrayList<>(); for (String h : p[2].split(",", -1)) if (!h.isEmpty()) tg.add(unhexOrNull(h)); System.out.println(hexOf(metaEncode(p[1].equals("1"), tg))); }
                    else if (p[0].equals("mdec")) System.out.println(metaDecode(p[1].isEmpty() ? "" : unhexOrNull(p[1])));
                }
                break;
            }
            case "plan": {   // nhiều ca ngăn bằng dòng "---"; ra mỗi ca một dòng, các tên cách nhau bằng tab
                List<String> ls = Files.readAllLines(Paths.get(a[1]));
                ls.add("---");
                List<String> block = new ArrayList<>();
                for (String ln : ls) {
                    if (!ln.equals("---")) { block.add(ln); continue; }
                    if (block.size() < 3) { block.clear(); continue; }
                    String pattern = block.get(0); int start = Integer.parseInt(block.get(1));
                    Set<String> taken = new HashSet<>(); for (String t : block.get(2).split("\t", -1)) if (!t.isEmpty()) taken.add(t);
                    List<String[]> items = new ArrayList<>(); for (int i = 3; i < block.size(); i++) if (!block.get(i).isEmpty()) items.add(block.get(i).split("\t", -1));
                    System.out.println(String.join("\t", plan(items, pattern, start, taken)));
                    block.clear();
                }
                break;
            }
        }
    }
}
