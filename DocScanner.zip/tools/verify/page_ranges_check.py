"""Kiểm chứng PageRanges (phiên 16): đọc khoảng trang kiểu "1-3, 5, 8-".

PageRangesCheck.java là bản Java chạy được của PageRanges.parse. Bài kiểm KHÔNG so Java với chính nó: nó so với một bản tham chiếu viết ĐỘC LẬP bằng Python
(đọc từng ký tự, không dùng biểu thức chính quy) trên (1) các ca viết tay có đáp án cho trước và (2) 20 000 chuỗi ngẫu nhiên từ bộ ký tự "0123456789-, ;x".
Hai bên phải cho đúng cùng kết quả (nhóm trang, hoặc cùng lý do + mảnh bị từ chối). Thử âm tính: một bản tham chiếu cố ý sai (cho phép 1-99 trong tệp 20 trang
bằng cách cắt bớt) phải bị bài kiểm bắt - nếu không, bài kiểm không phân biệt được "đã tách đúng" với "tách lặng lẽ sai".
Chạy: python3 page_ranges_check.py   (cần java 11+)
"""
import os, random, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
HERE = os.path.dirname(os.path.abspath(__file__))
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
    return cond

def reference(spec, n, clamp=False):
    """Bản tham chiếu: đọc từng ký tự."""
    parts, cur = [], ""
    for ch in spec:
        if ch in ",;":
            parts.append(cur); cur = ""
        else:
            cur += ch
    parts.append(cur)
    toks = [p.strip() for p in parts if p.strip()]
    if not toks: return "ERR\tEMPTY\t"
    groups = []
    for t in toks:
        # tách thành: số đầu, dấu gạch, số cuối - chỉ cho phép khoảng trắng quanh dấu gạch
        i = 0
        while i < len(t) and t[i].isdigit(): i += 1
        a = t[:i]
        rest = t[i:].lstrip()
        dash = False
        if rest.startswith("-"):
            dash = True; rest = rest[1:].lstrip()
        j = 0
        while j < len(rest) and rest[j].isdigit(): j += 1
        b, tail = rest[:j], rest[j:]
        # Java \s* cho phép khoảng trắng; khoảng trắng GIỮA hai số không có dấu gạch là lỗi
        if tail.strip() != "" or tail != "":
            return f"ERR\tSYNTAX\t{t}"
        if not dash and (a == "" or b != ""):
            return f"ERR\tSYNTAX\t{t}"
        if a == "" and b == "":
            return f"ERR\tSYNTAX\t{t}"
        frm = 1 if a == "" else int(a)
        to = frm if not dash else (n if b == "" else int(b))
        if clamp: to = min(to, n)
        if frm < 1 or frm > n or to < 1 or to > n: return f"ERR\tOUT_OF_RANGE\t{t}"
        if frm > to: return f"ERR\tREVERSED\t{t}"
        groups.append(",".join(str(k) for k in range(frm - 1, to)))
    return "OK\t" + "|".join(groups)

HAND = [  # (số trang, chuỗi, kết quả mong đợi)
    (20, "1-3, 5, 8-", "OK\t0,1,2|4|7,8,9,10,11,12,13,14,15,16,17,18,19"),
    (10, "-3", "OK\t0,1,2"), (10, "5", "OK\t4"), (10, " 2 - 4 ; 7 ", "OK\t1,2,3|6"), (10, "10", "OK\t9"), (10, "1", "OK\t0"),
    (10, "", "ERR\tEMPTY\t"), (10, " , ; ", "ERR\tEMPTY\t"), (10, "-", "ERR\tSYNTAX\t-"), (10, "5 8", "ERR\tSYNTAX\t5 8"),
    (10, "a", "ERR\tSYNTAX\ta"), (10, "1-3-5", "ERR\tSYNTAX\t1-3-5"), (10, "1--3", "ERR\tSYNTAX\t1--3"),
    (10, "0", "ERR\tOUT_OF_RANGE\t0"), (10, "11", "ERR\tOUT_OF_RANGE\t11"), (10, "1-11", "ERR\tOUT_OF_RANGE\t1-11"),
    (10, "99999999999999999999", "ERR\tOUT_OF_RANGE\t99999999999999999999"), (10, "5-3", "ERR\tREVERSED\t5-3"),
    (20, "1-99", "ERR\tOUT_OF_RANGE\t1-99"), (1, "1-", "OK\t0"), (1, "-1", "OK\t0"), (3, "2-", "OK\t1,2"),
]
def run_java(cases, tag):
    cin, cout = os.path.join(OUT, f"pr_{tag}.in"), os.path.join(OUT, f"pr_{tag}.out")
    with open(cin, "w", encoding="utf-8") as f:
        for n, s in cases: f.write(f"{n}\t{s}\n")
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", os.path.join(HERE, "PageRangesCheck.java"), cin, cout], capture_output=True, text=True)
    if r.returncode != 0: sys.exit("Java lỗi:\n" + r.stdout + r.stderr)
    return open(cout, encoding="utf-8").read().split("\n")[:len(cases)]

res = run_java([(n, s) for n, s, _ in HAND], "hand")
bad = [(n, s, e, g) for (n, s, e), g in zip(HAND, res) if e != g]
check(not bad, f"{len(HAND)} ca viết tay có đáp án cho trước" + (f" — sai: {bad[:2]}" if bad else ""))
ref_bad = [(n, s) for n, s, e in HAND if reference(s, n) != e]
check(not ref_bad, f"bản tham chiếu Python cũng đúng {len(HAND)} ca viết tay (nếu không, tham chiếu vô giá trị): {ref_bad[:2]}")

rng = random.Random(16)
alphabet = "0123456789-, ;x"
fuzz = []
for _ in range(20000):
    n = rng.choice([1, 2, 5, 10, 20, 100])
    s = "".join(rng.choice(alphabet) for _ in range(rng.randint(0, 12)))
    fuzz.append((n, s))
jres = run_java(fuzz, "fuzz")
diff = [(n, s, reference(s, n), g) for (n, s), g in zip(fuzz, jres) if reference(s, n) != g]
check(not diff, f"20 000 chuỗi ngẫu nhiên: Java = tham chiếu độc lập" + (f" — lệch {len(diff)}: {diff[:2]}" if diff else ""))
ok_cnt = sum(1 for g in jres if g.startswith("OK")); err_cnt = len(jres) - ok_cnt
check(ok_cnt > 500 and err_cnt > 500, f"bộ ngẫu nhiên có cả ca hợp lệ ({ok_cnt}) lẫn bị từ chối ({err_cnt}) — không lệch về một phía")

# thử âm tính: tham chiếu 'cắt bớt' (clamp) khác Java ở các ca vượt trang
clamped = [(n, s) for n, s, _ in HAND if reference(s, n, clamp=True) != reference(s, n)]
check(bool(clamped), f"thử âm tính: bản 'cắt bớt cho vừa' cho kết quả khác ở {len(clamped)} ca (vd {clamped[:1]}) — bài kiểm phân biệt được tách đúng với tách lặng lẽ sai")
print("\nTAT CA DAT" if not FAILS else f"\nCO {len(FAILS)} LOI")
sys.exit(1 if FAILS else 0)
