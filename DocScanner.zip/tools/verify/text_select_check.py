#!/usr/bin/env python3
"""Chọn chữ theo dòng (tô sáng / gạch chân / gạch ngang) CHẠY THẬT (`PdfTextMarkup.selectionBoxes`, `PdfTextLayer.words`, `ReaderEdits.undo`; phiên 24, TECHNICAL_DOCS.md 4.67).

Lần đầu `PdfTextLayer` - đoạn keo PdfBox đọc từng từ và hộp chữ của một trang, ghi chú trong mã suốt từ phiên 20 là "chưa từng chạy" - được chạy thật, trên PdfBox-Android dựng từ nguồn,
và so với **poppler** (`pdftotext -bbox`, một bộ đọc khác hẳn). PDF thử dựng bằng reportlab với DejaVu Sans (tiếng Việt đủ dấu), nhiều đoạn, nhiều dòng, cả trang xoay 90 độ.
  A. phần thuần (`nearestWord`, `wordsBetween`, `selectionBoxes`) so với mô hình Python độc lập trên 4 000 ca ngẫu nhiên (lưới chữ có xê dịch, chạm giữa hai dòng, ngoài lề, kéo ngược);
  B. `ReaderEdits.undo` có nhóm: 3 000 kịch bản ngẫu nhiên so với mô hình - hoàn tác xoá CẢ vùng chọn nhiều dòng một lần, các nét lẻ vẫn từng cái một;
  C. `PdfTextLayer.words` thật = poppler: cùng chuỗi từ, cùng thứ tự, hộp chữ khớp (trang thường và xoay 90), số dòng khớp, trang không có chữ (ảnh) cho danh sách rỗng;
  D. chọn trên PDF thật: kéo từ từ A tới từ B qua ba dòng -> đúng MỘT dải mỗi dòng, dải đầu bắt đầu ở từ A, dải cuối kết thúc ở từ B, dòng giữa trọn dòng; kéo ngược cho cùng kết quả; chạm
     = một từ; bắt đầu ngoài lề / ở vùng không có chữ -> không chọn (giữ khung chữ nhật); kéo quá cuối trang -> chọn tới hết;
  E. `PdfTextMarkup.annotate` thật rồi poppler VẼ lại: mọi từ được chọn có điểm ảnh vàng (tô sáng, trong suốt), KHÔNG từ nào ngoài vùng chọn bị tô; gạch chân / gạch ngang ghi đúng loại chú thích;
  F. THỬ ÂM TÍNH: 8 bản Kotlin hỏng (không sắp xếp điểm đầu / cuối, bỏ ngưỡng bắt đầu, chỉ chọn từ đầu, hoàn tác không theo nhóm, bỏ trọng số dọc, đếm dòng sai, kéo quá cuối không chọn tới hết, không bỏ chữ hiện nghiêng) PHẢI bị bắt (`--fast` bỏ; `--mutant=N` một bản).
KHÔNG kiểm được: cảm ứng thật, hiển thị xem trước trên màn hình, trang hai cột (thứ tự đọc của PDFTextStripper chạy theo hàng nên một lựa chọn trong một cột lấy cả hàng bên kia - giới hạn đã ghi ở 4.67).
Cần: java 17+, github.com (toolchain), reportlab, pikepdf, Pillow, poppler. Chạy: python3 tools/verify/text_select_check.py [--fast] [--mutant=N]"""
import html, math, os, random, re, shutil, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
import pikepdf  # noqa: E402
from PIL import Image  # noqa: E402
from reportlab.pdfgen import canvas  # noqa: E402
from reportlab.pdfbase import pdfmetrics  # noqa: E402
from reportlab.pdfbase.ttfonts import TTFont  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)
tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="textsel-")
FILES = ["PdfTextLayer.kt", "PdfTextMarkup.kt", "TextLayerWords.kt", "ReaderEdits.kt", "PdfStructureOptimizer.kt", "PdfVerify.kt"]
HARNESS = os.path.join(HERE, "real_run", "TextSelectHarness.kt"); STUBS = os.path.join(HERE, "real_run", "UtilStubs.kt")
DOUBLE = {"PdfVerify.kt": ("    fun opensAsPdf(file: File, expectedPages: Int): Boolean {",
    "    fun opensAsPdf(file: File, expectedPages: Int): Boolean {\n        return try {\n            if (!file.exists() || file.length() <= 0L) return false\n"
    "            com.tom_roush.pdfbox.pdmodel.PDDocument.load(file).use { d -> d.numberOfPages > 0 && (expectedPages <= 0 || d.numberOfPages == expectedPages) }\n        } catch (e: Exception) { false }\n    }")}
def build(mutate=None, tag="base"): return tc.compile(FILES, [HARNESS, STUBS], os.path.join(WORK, "cls-" + tag), mutate, DOUBLE)[0]
def run(cls, args, stdin=None):
    r = tc.run(cls, "TextSelectHarnessKt", args, stdin=stdin)
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-700:])
    return r.stdout
def sh(*c): return subprocess.run(c, capture_output=True, text=True)

# ---------------------------------------------------------------- PDFs (reportlab) and the poppler oracle
pdfmetrics.registerFont(TTFont("DejaVu", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"))
TEXT = ["Tôi muốn thuê một căn nhà gần trường học của con gái tôi vào tháng tới nếu giá hợp lý.",
        "Hợp đồng thuê nhà phải ghi rõ thời hạn, tiền đặt cọc và quyền sửa chữa của người thuê.",
        "Chủ nhà đồng ý giảm giá nếu khách thuê dài hạn ba năm và trả trước sáu tháng liền.",
        "Mọi tranh chấp được giải quyết thông qua thương lượng giữa hai bên trước khi kiện ra tòa.",
        "Bên thuê có trách nhiệm giữ gìn tài sản trong nhà và báo ngay khi có hư hỏng xảy ra.",
        "Tiền điện nước do bên thuê tự thanh toán hằng tháng theo chỉ số công tơ của nhà cung cấp.",
        "Khi hết hạn hợp đồng hai bên cùng kiểm tra lại nhà và bàn giao chìa khóa cho chủ nhà.",
        "Mỗi bên giữ một bản hợp đồng có chữ ký đầy đủ của cả hai người để làm bằng chứng sau này."]
def wrap(text, width_pt, size=12):
    out, cur = [], ""
    for w in text.split(" "):
        t = (cur + " " + w).strip()
        if pdfmetrics.stringWidth(t, "DejaVu", size) <= width_pt: cur = t
        else: out.append(cur); cur = w
    return out + [cur]
def make_text_pdf(path, rotate=0, paragraphs=TEXT):
    c = canvas.Canvas(path, pagesize=(612, 792)); c.setFont("DejaVu", 12)
    if rotate: c.setPageRotation(rotate)
    y = 720
    for para in paragraphs:
        for line in wrap(para, 468):
            c.drawString(72, y, line); y -= 18
        y -= 10
    c.showPage(); c.save()
def make_text_pdf_upright_rotated(path, paragraphs=TEXT):
    """Stored portrait 612x792 with /Rotate 90 and the content turned the other way, so the page is DISPLAYED landscape (792x612) with upright, horizontal text - what a landscape scan or a
    landscape export looks like. Displayed (dx, dy from the top) = stored (sy, sx), so a line that reads right along the display is drawn along the stored +y axis."""
    c = canvas.Canvas(path, pagesize=(612, 792)); c.setPageRotation(90)
    k = 0
    for para in paragraphs:
        for line in wrap(para, 640):
            c.saveState(); c.translate(80 + 18 * k, 72); c.rotate(90); c.setFont("DejaVu", 12); c.drawString(0, 0, line); c.restoreState(); k += 1
        k += 1
    c.showPage(); c.save()
def make_image_pdf(path):
    from PIL import Image as PI
    PI.new("RGB", (400, 500), (230, 230, 230)).save(os.path.join(WORK, "blank.png"))
    c = canvas.Canvas(path, pagesize=(612, 792)); c.drawImage(os.path.join(WORK, "blank.png"), 50, 100, 500, 600); c.showPage(); c.save()
def poppler_words(path):
    out = sh("pdftotext", "-bbox", "-f", "1", "-l", "1", path, "-").stdout
    pg = re.search(r'<page width="([\d.]+)" height="([\d.]+)"', out); W, H = float(pg.group(1)), float(pg.group(2))
    ws = [(html.unescape(m.group(5)), float(m.group(1)), float(m.group(2)), float(m.group(3)), float(m.group(4))) for m in
          re.finditer(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(.*?)</word>', out)]
    return W, H, ws
def kotlin_words(cls, path):
    out = run(cls, ["words", path, "0"]).strip("\n")
    if out == "NULL": return None
    res = []
    for l in out.split("\n"):
        if not l: continue
        t, b, ln = l.split("\t"); res.append((t, [float(x) for x in b.split(",")], int(ln)))
    return res
def lines_of(ws, tol=3.0):
    """poppler words -> list of lines (list of word indices), grouped by vertical centre"""
    lines = []
    for i, (_, x0, y0, x1, y1) in enumerate(ws):
        yc = (y0 + y1) / 2
        for ln in lines:
            if abs(ln["y"] - yc) <= tol: ln["idx"].append(i); break
        else: lines.append({"y": yc, "idx": [i]})
    return [ln["idx"] for ln in lines]

# ---------------------------------------------------------------- A. pure vs model
def m_near(words, x, y, maxd):
    best, bd = -1, float("inf")
    for i, (l, t, r, b, _) in enumerate(words):
        dx = max(l - x, 0, x - r); dy = max(t - y, 0, y - b); d = math.hypot(dx, dy * 2)
        if d < bd: bd, best = d, i
    return best if best >= 0 and bd <= maxd else -1
def m_between(n, a, b): return [] if not (0 <= a < n and 0 <= b < n) else list(range(min(a, b), max(a, b) + 1))
def m_sel(words, ax, ay, bx, by):
    s = m_near(words, ax, ay, 0.04)
    if s < 0: return None
    top, bottom = min(w[1] for w in words), max(w[3] for w in words)
    e = len(words) - 1 if by > bottom else (0 if by < top else m_near(words, bx, by, float("inf"))); chosen = m_between(len(words), s, e); by_line = {}
    for i in sorted(chosen):
        l, t, r, b, ln = words[i]
        if ln not in by_line: by_line[ln] = [l, t, r, b]
        else: c = by_line[ln]; c[0] = min(c[0], l); c[1] = min(c[1], t); c[2] = max(c[2], r); c[3] = max(c[3], b)
    out = []
    for ln in sorted(by_line):
        l, t, r, b = by_line[ln]; pad = (b - t) * 0.08; cl = lambda v: min(max(v, 0.0), 1.0)
        out.append([cl(l), cl(t - pad), cl(r), cl(b + pad)])
    return out
def spec_of(words): return ";".join(f"{l:.5f},{t:.5f},{r:.5f},{b:.5f},{ln}" for l, t, r, b, ln in words)
def parse_bands(s): return None if s == "NONE" else [[float(v) for v in b.split(",")] for b in s.split("|") if b]

print("== A. phần thuần so với mô hình độc lập"); cls = build(); rnd = random.Random(24)
def random_words():
    words, ln = [], 0
    rows = rnd.randint(1, 6); y = rnd.uniform(0.05, 0.2)
    for _ in range(rows):
        x = rnd.uniform(0.05, 0.15); h = rnd.uniform(0.012, 0.02)
        for _ in range(rnd.randint(1, 7)):
            w = rnd.uniform(0.02, 0.12)
            if x + w > 0.95: break
            words.append((x, y + rnd.uniform(-0.002, 0.002), x + w, y + h + rnd.uniform(-0.002, 0.002), ln)); x += w + rnd.uniform(0.008, 0.02)
        y += h * 1.7 + rnd.uniform(0, 0.01); ln += 1
    return words
cmds, want = [], []
for _ in range(4000):
    words = random_words() or [(0.1, 0.1, 0.2, 0.12, 0)]
    kind = rnd.choice("NNBSSS")
    pts = [(rnd.uniform(0, 1), rnd.uniform(0, 1)) if rnd.random() < .4 else
           (lambda w: ((w[0] + w[2]) / 2 + rnd.uniform(-0.02, 0.02), (w[1] + w[3]) / 2 + rnd.uniform(-0.03, 0.03)))(rnd.choice(words)) for _ in range(2)]
    sp = spec_of(words)
    if kind == "N":
        md = rnd.choice(["any", "0.04", "0.01"]); cmds.append(f"NEAR {md} {pts[0][0]:.5f} {pts[0][1]:.5f} {sp}"); want.append(str(m_near(words, pts[0][0], pts[0][1], float('inf') if md == 'any' else float(md))))
    elif kind == "B":
        n = len(words); a, b = rnd.randint(-1, n), rnd.randint(-1, n); cmds.append(f"BETWEEN {a} {b} {n}"); want.append(",".join(map(str, m_between(n, a, b))))
    else:
        cmds.append(f"SEL {pts[0][0]:.5f} {pts[0][1]:.5f} {pts[1][0]:.5f} {pts[1][1]:.5f} {sp}"); want.append(m_sel(words, *pts[0], *pts[1]))
got = run(cls, [], "\n".join(cmds) + "\n").split("\n")[:-1]; bad = []
for c, w, g in zip(cmds, want, got):
    if c.startswith("SEL"):
        gb = parse_bands(g)
        ok = (gb is None and w is None) or (gb is not None and w is not None and len(gb) == len(w) and all(abs(a - b) < 3e-5 for x, y in zip(gb, w) for a, b in zip(x, y)))
    else: ok = g == w
    if not ok: bad.append((c[:60], w, g))
check(not bad, f"4 000 ca: nearestWord / wordsBetween / selectionBoxes của Kotlin thật khớp mô hình độc lập {bad[:1]}")

print("== B. hoàn tác theo nhóm")
def m_undo(ops):
    items = []; group = 0; counter = 0
    for op in ops:
        if op == "N": counter += 1; group = counter
        elif op == "U":
            if items:
                last = items.pop()
                if last != 0:
                    while items and items[-1] == last: items.pop()
        else: items.append(int(op[1:]))
    return ",".join(map(str, items))
cmds, want = [], []
for _ in range(3000):
    ops, groups = [], 0
    for _ in range(rnd.randint(0, 25)):
        r = rnd.random()
        if r < .15: ops.append("N"); groups += 1
        elif r < .35: ops.append("U")
        else: ops.append("A" + str(rnd.randint(0, groups) if groups else 0))
    cmds.append("UNDO " + " ".join(ops)); want.append(m_undo(["N" if o == "N" else o for o in ops]))
got = run(cls, [], "\n".join(cmds) + "\n").split("\n")[:-1]
check(got == want, f"3 000 kịch bản hoàn tác: nhóm bị gỡ trọn vẹn, nét lẻ gỡ từng cái {[(c, w, g) for c, w, g in zip(cmds, want, got) if w != g][:1]}")
def U(s): return run(cls, [], f"UNDO {s}\n").strip()
check(U("N A1 A1 A1 U") == "" and U("A0 A0 N A1 A1 U") == "0,0" and U("N A1 A1 N A2 A2 U") == "1,1", "ví dụ: ba dải của một vùng chọn mất cùng lúc; hai nét lẻ và vùng chọn khác không bị động tới")

# ---------------------------------------------------------------- C. real PdfBox words vs poppler
print("== C. PdfTextLayer.words (PdfBox thật) so với poppler")
def compare_words(path, label):
    W, H, pw = poppler_words(path); kw = kotlin_words(cls, path)
    if kw is None: check(False, f"{label}: PdfTextLayer trả NULL"); return None
    same_text = [t for t, _, _ in kw] == [w[0] for w in pw]
    first_diff = next(((i, a, b) for i, (a, b) in enumerate(zip([t for t, _, _ in kw], [w[0] for w in pw])) if a != b), None)
    check(same_text, f"{label}: cùng {len(pw)} từ, cùng thứ tự đọc với poppler" + ("" if same_text else f"  Kotlin {len(kw)} từ, poppler {len(pw)} từ; khác đầu tiên: {first_diff}; đuôi Kotlin {[t for t, _, _ in kw][-3:]} poppler {[w[0] for w in pw][-3:]}"))
    if not same_text: return None
    worst_x = worst_yc = 0.0; contain = 0
    for (t, b, ln), (_, x0, y0, x1, y1) in zip(kw, pw):
        kx0, ky0, kx1, ky1 = b[0] * W, b[1] * H, b[2] * W, b[3] * H
        worst_x = max(worst_x, abs(kx0 - x0), abs(kx1 - x1)); worst_yc = max(worst_yc, abs((ky0 + ky1) / 2 - (y0 + y1) / 2))
        yc, hh = (y0 + y1) / 2, (y1 - y0)
        if ky0 <= yc - 0.25 * hh and ky1 >= yc + 0.25 * hh: contain += 1
    check(worst_x <= 2.5, f"{label}: bề ngang từng từ khớp poppler (lệch tối đa {worst_x:.2f} pt)")
    check(worst_yc <= 4.0 and contain == len(kw), f"{label}: hộp chữ bao trùm phần giữa của hộp poppler, tâm dọc lệch tối đa {worst_yc:.2f} pt ({contain}/{len(kw)} từ)")
    pl = lines_of(pw); kl = sorted(set(l for _, _, l in kw))
    check(len(kl) == len(pl), f"{label}: số dòng {len(kl)} = poppler {len(pl)}")
    return W, H, pw, kw, pl
p0 = os.path.join(WORK, "t0.pdf"); make_text_pdf(p0)
p90 = os.path.join(WORK, "t90.pdf"); make_text_pdf_upright_rotated(p90, TEXT[:5])
pside = os.path.join(WORK, "side.pdf"); make_text_pdf(pside, rotate=90)
pimg = os.path.join(WORK, "img.pdf"); make_image_pdf(pimg)
r0 = compare_words(p0, "trang thường"); r90 = compare_words(p90, "trang xoay 90, chữ hiện thẳng (bản quét ngang)")
sw = kotlin_words(cls, pside)
check(sw == [], f"trang xoay 90 mà chữ hiện NGHIÊNG: bỏ qua (danh sách rỗng, không hộp sai) - ca này dùng OCR / khung chữ nhật ({'NULL' if sw is None else len(sw)} từ)")
check(run(cls, ["words", pimg, "0"]).strip() == "", "trang chỉ có ảnh (như bản quét): danh sách từ rỗng, không NULL, không lỗi")

# ---------------------------------------------------------------- D. selection on a real PDF
print("== D. chọn theo dòng trên PDF thật")
def sel_bands(path, ax, ay, bx, by):
    out = run(cls, ["select", path, "0", f"{ax:.5f}", f"{ay:.5f}", f"{bx:.5f}", f"{by:.5f}"]).strip()
    return None if out == "NONE" else [[float(v) for v in l.split(",")] for l in out.split("\n") if l]
def center(W, H, w): return ((w[1] + w[3]) / 2 / W, (w[2] + w[4]) / 2 / H)
def expected_bands(W, H, pw, pl, s, e):
    lo, hi = min(s, e), max(s, e); bands = []
    for ln in pl:
        idx = [i for i in ln if lo <= i <= hi]
        if idx: bands.append((min(pw[i][1] for i in idx) / W, max(pw[i][3] for i in idx) / W))
    return bands
def band_ok(got, exp, W):
    return got is not None and len(got) == len(exp) and all(abs(g[0] * W - e[0] * W) <= 2.5 and abs(g[2] * W - e[1] * W) <= 2.5 for g, e in zip(got, exp))
for label, rr, path in (("trang thường", r0, p0), ("trang xoay 90, chữ hiện thẳng", r90, p90)):
    if not rr: continue
    W, H, pw, kw, pl = rr
    s = pl[0][2]; e = pl[2][3]                                      # third word of the first line .. fourth word of the third line
    a, b = center(W, H, pw[s]), center(W, H, pw[e]); got = sel_bands(path, *a, *b); exp = expected_bands(W, H, pw, pl, s, e)
    check(band_ok(got, exp, W) and len(exp) == 3, f"{label}: kéo từ từ #{s} tới từ #{e} qua ba dòng -> đúng ba dải, dải đầu bắt đầu ở từ đầu, dải cuối kết thúc ở từ cuối, dòng giữa trọn dòng ({None if got is None else len(got)} dải)")
    back = sel_bands(path, *b, *a); check(back is not None and got is not None and all(abs(x - y) < 1e-4 for u, v in zip(back, got) for x, y in zip(u, v)) and len(back) == len(got), f"{label}: kéo NGƯỢC (từ cuối về từ đầu) cho cùng kết quả")
    t = pl[1][min(4, len(pl[1]) - 1)]; tap = sel_bands(path, *center(W, H, pw[t]), *center(W, H, pw[t]))
    check(tap is not None and len(tap) == 1 and abs(tap[0][0] * W - pw[t][1]) <= 2.5 and abs(tap[0][2] * W - pw[t][3]) <= 2.5, f"{label}: chạm một từ -> đúng một dải ôm từ đó")
    check(sel_bands(path, 0.5, 0.96, 0.6, 0.97) is None, f"{label}: bắt đầu ở lề trống phía dưới trang -> không chọn (giữ khung chữ nhật)")
    alls = sel_bands(path, *center(W, H, pw[0]), 0.9, 0.99); check(alls is not None and len(alls) == len(pl), f"{label}: kéo quá cuối trang -> chọn tới hết ({None if alls is None else len(alls)} dải = {len(pl)} dòng)")
    k = pl[len(pl) // 2][1]; upp = sel_bands(path, *center(W, H, pw[k]), 0.1, 0.01); expu = expected_bands(W, H, pw, pl, 0, k)
    check(band_ok(upp, expu, W), f"{label}: kéo quá ĐẦU trang -> chọn ngược tới từ đầu tiên ({None if upp is None else len(upp)} dải = {len(expu)})")
check(run(cls, ["select", pimg, "0", "0.5", "0.5", "0.6", "0.6"]).strip() == "NONE", "trang chỉ có ảnh: không có từ nên không chọn (khung chữ nhật vẫn dùng được)")

# ---------------------------------------------------------------- E. write the marks, let poppler draw them
print("== E. ghi chú thích thật rồi poppler vẽ lại")
def render(path):
    base = os.path.join(WORK, "rr"); sh("pdftoppm", "-cropbox", "-r", "72", "-png", "-f", "1", "-l", "1", path, base)
    f = [x for x in os.listdir(WORK) if x.startswith("rr") and x.endswith(".png")][0]; im = Image.open(os.path.join(WORK, f)).convert("RGB"); os.remove(os.path.join(WORK, f)); return im
YEL = lambda p: p[0] > 200 and p[1] > 200 and p[2] < 215 and p[2] < p[0] - 20
def yellow_in(im, W, H, w, frac=0.5):
    # the middle band of the poppler box of the word (the padded band of the next line never reaches another line's middle band)
    px = im.load(); x0, x1 = int(w[1] + 1), int(w[3] - 1); yc = (w[2] + w[4]) / 2; hh = (w[4] - w[2]) * frac / 2
    pts = [px[x, y] for x in range(max(x0, 0), min(x1, im.size[0] - 1)) for y in range(int(yc - hh), int(yc + hh) + 1) if 0 <= y < im.size[1]]
    return sum(1 for p in pts if YEL(p)) / max(len(pts), 1)
if r0:
    W, H, pw, kw, pl = r0; s, e = pl[0][3], pl[2][2]
    a, b = center(W, H, pw[s]), center(W, H, pw[e]); out = os.path.join(WORK, "hl.pdf")
    n = run(cls, ["annotate", p0, out, "0", f"{a[0]:.5f}", f"{a[1]:.5f}", f"{b[0]:.5f}", f"{b[1]:.5f}", "highlight"]).strip()
    check(n == "3", f"tô sáng qua ba dòng: ghi 3 chú thích ({n})")
    im = render(out); lo, hi = min(s, e), max(s, e)
    sel_ok = [i for i in range(len(pw)) if lo <= i <= hi and yellow_in(im, W, H, pw[i]) > 0.15]; sel_bad = [i for i in range(len(pw)) if not lo <= i <= hi and yellow_in(im, W, H, pw[i]) > 0.0]
    check(len(sel_ok) == hi - lo + 1, f"poppler vẽ: cả {hi - lo + 1} từ được chọn đều có nền vàng ({len(sel_ok)})")
    check(not sel_bad, f"poppler vẽ: KHÔNG từ nào ngoài vùng chọn bị tô ({sel_bad[:5]})")
    with pikepdf.open(out) as pdf:
        an = list(pdf.pages[0].Annots); check(len(an) == 3 and all(str(x.Subtype) == "/Highlight" and len(x.QuadPoints) == 8 for x in an), "cấu trúc: 3 chú thích /Highlight có /QuadPoints")
    for style, subtype in (("underline", "/Underline"), ("strike", "/StrikeOut")):
        o2 = os.path.join(WORK, style + ".pdf"); n2 = run(cls, ["annotate", p0, o2, "0", f"{a[0]:.5f}", f"{a[1]:.5f}", f"{b[0]:.5f}", f"{b[1]:.5f}", style]).strip()
        with pikepdf.open(o2) as pdf: sub = {str(x.Subtype) for x in pdf.pages[0].Annots}
        check(n2 == "3" and sub == {subtype}, f"{style}: 3 chú thích đúng loại {subtype}")
    check(sh("qpdf", "--check", out).returncode == 0, "qpdf --check sạch")

# ---------------------------------------------------------------- F. negative tests
ONLY = next((int(a.split("=")[1]) for a in sys.argv if a.startswith("--mutant=")), None)
if "--fast" in sys.argv and ONLY is None: print("== F. bỏ qua thử âm tính (--fast)")
else:
    print("== F. thử âm tính")
    MUT = [("không sắp xếp điểm đầu / cuối (kéo ngược mất)", "PdfTextMarkup.kt", ("for (i in minOf(first, last)..maxOf(first, last)) out.add(i)", "for (i in first..last) out.add(i)")),
           ("bỏ ngưỡng bắt đầu (bắt đầu ở đâu cũng chọn)", "PdfTextMarkup.kt", ("const val SELECT_START_DISTANCE = 0.04f", "const val SELECT_START_DISTANCE = 50f")),
           ("chỉ chọn từ đầu tiên", "PdfTextMarkup.kt", ("wordsBetween(words, first, endWord(words, bx, by))", "wordsBetween(words, first, first)")),
           ("hoàn tác không theo nhóm", "ReaderEdits.kt", ("while (list.isNotEmpty() && list[list.size - 1].group == last.group)", "while (false)")),
           ("bỏ trọng số dọc khi tìm từ gần nhất", "PdfTextMarkup.kt", ("val d = hypot(dx, dy * 2f)", "val d = hypot(dx, dy * 0.2f)")),
           ("đếm dòng sai (mọi từ một dòng)", "PdfTextLayer.kt", ("                    line++\n", "")),
           ("kéo quá cuối trang không chọn tới hết", "PdfTextMarkup.kt", ("        if (y > bottom) return words.size - 1\n", "")),
           ("không bỏ chữ hiện nghiêng (hộp sai trên trang xoay)", "PdfTextLayer.kt", ("if (((textPositions[0].dir.toInt() - pageRotation) % 360 + 360) % 360 != 0) return", ""))]
    for number, (name, fname, (old, new)) in enumerate(MUT, 1):
        if ONLY is not None and number != ONLY: continue
        try: mcls = build({fname: (old, new)}, tag="mut")
        except RuntimeError as exc: check("mutation target not found" not in str(exc), f"ÂM TÍNH '{name}': bản hỏng không biên dịch (bị bắt)"); continue
        caught = False
        try:
            def sel_m(path, ax, ay, bx, by):
                o = run(mcls, ["select", path, "0", f"{ax:.5f}", f"{ay:.5f}", f"{bx:.5f}", f"{by:.5f}"]).strip()
                return None if o == "NONE" else [[float(v) for v in l.split(",")] for l in o.split("\n") if l]
            W, H, pw, kw, pl = r0; s, e = pl[0][2], pl[2][3]; a, b = center(W, H, pw[s]), center(W, H, pw[e])
            exp = expected_bands(W, H, pw, pl, s, e); g1 = sel_m(p0, *a, *b); g2 = sel_m(p0, *b, *a); g3 = sel_m(p0, 0.5, 0.96, 0.6, 0.97)
            if not band_ok(g1, exp, W) or not band_ok(g2, exp, W) or g3 is not None: caught = True
            got = run(mcls, [], "\n".join(cmds[:0]) + "UNDO N A1 A1 A1 U\nNEAR any 0.5 0.5 0.05,0.49,0.15,0.51,0;0.45,0.2,0.55,0.25,1\n").split("\n")
            # a word on the SAME line but 0.35 away sideways beats a word straight above at 0.25 (vertical distance counts double): index 0
            if got[0] != "" or got[1] != "0": caught = True
            kl = run(mcls, ["words", p0, "0"]).strip().split("\n")
            if len({l.split("\t")[2] for l in kl}) != len(pl): caught = True
            if run(mcls, ["words", pside, "0"]).strip() != "": caught = True
            if not band_ok(sel_m(p0, *center(W, H, pw[0]), 0.9, 0.99), expected_bands(W, H, pw, pl, 0, len(pw) - 1), W): caught = True
        except SystemExit: caught = True
        check(caught, f"ÂM TÍNH '{name}': bản hỏng bị bắt")
shutil.rmtree(WORK, ignore_errors=True); print("\nTAT CA DAT" if not fails else f"\n{len(fails)} LOI"); sys.exit(1 if fails else 0)
