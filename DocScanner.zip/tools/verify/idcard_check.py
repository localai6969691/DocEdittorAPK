"""Kiểm chứng IdCardComposer (phiên 15): bố cục thẻ trên A4 ở KÍCH THƯỚC THẬT và phép cắt theo tỉ lệ.

Bản Python song song của app/.../util/IdCardComposer.kt (cardSize, layout, cropToAspect). Poppler dựng một trang A4 mà mỗi thẻ là một
hình chữ nhật màu đặt đúng theo `layout`, rồi đo trên ảnh 300 dpi: kích thước thẻ phải đúng 85,6 x 53,98 mm (hoặc 125 x 88 mm), nằm giữa
trang theo chiều ngang, khối thẻ nằm giữa trang theo chiều dọc, mặt trước ở trên mặt sau, khoảng cách giữa hai thẻ ≈ 10 mm.
Chạy: python3 idcard_check.py   (cần numpy, pillow, pikepdf, pdftoppm)
"""
import os, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import numpy as np
from PIL import Image
import pikepdf
from pikepdf import Dictionary

A4W, A4H = 595.276, 841.89
MM = 72 / 25.4
GAP = 28.0
PRESETS = {"ID1": (85.6, 53.98), "ID3": (125.0, 88.0)}


def card_size(p):
    w, h = PRESETS[p]
    return w * MM, h * MM


def layout(count, cw, ch, pw=A4W, ph=A4H):
    total = count * ch + max(count - 1, 0) * GAP
    top = ph - (ph - total) / 2
    x = (pw - cw) / 2
    return [(x, top - (i + 1) * ch - i * GAP, cw, ch) for i in range(count)]


def crop_to_aspect(w, h, aspect):
    cur = w / h
    if cur > aspect:
        nw = min(max(int(h * aspect), 1), w)
        return ((w - nw) // 2, 0, nw, h)
    nh = min(max(int(w / aspect), 1), h)
    return (0, (h - nh) // 2, w, nh)


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    return cond


def main():
    good = True
    cw, ch = card_size("ID1")
    good &= check(abs(cw - 242.65) < 0.05 and abs(ch - 153.02) < 0.05, f"ID-1 = {cw:.2f} x {ch:.2f} pt (85,6 x 53,98 mm)")
    for count in (1, 2):
        cells = layout(count, cw, ch)
        inside = all(x >= 0 and y >= 0 and x + w <= A4W and y + h <= A4H for x, y, w, h in cells)
        centered_x = all(abs(x - (A4W - cw) / 2) < 1e-6 for x, y, w, h in cells)
        top_gap = A4H - (cells[0][1] + ch); bottom_gap = cells[-1][1]
        good &= check(inside and centered_x and abs(top_gap - bottom_gap) < 1e-6, f"{count} thẻ: nằm trong trang, giữa ngang, khối cân giữa dọc (trên {top_gap:.1f} = dưới {bottom_gap:.1f})")
    c2 = layout(2, cw, ch)
    good &= check(c2[0][1] > c2[1][1] and abs((c2[0][1] - (c2[1][1] + ch)) - GAP) < 1e-6, "mặt trước ở trên mặt sau, cách nhau 28 pt (~10 mm)")

    # cắt theo tỉ lệ
    for (w, h) in [(1600, 1000), (1000, 1600), (856, 540), (2000, 600), (300, 900)]:
        x, y, nw, nh = crop_to_aspect(w, h, 85.6 / 53.98)
        ok = x >= 0 and y >= 0 and x + nw <= w and y + nh <= h and abs(nw / nh - 85.6 / 53.98) < 0.01 and (nw == w or nh == h)
        good &= check(ok, f"cropToAspect {w}x{h} -> {nw}x{nh} (tỉ lệ {nw / nh:.3f}, lớn nhất có thể, nằm giữa)")

    # poppler đo thật, ở 300 dpi
    for preset in ("ID1", "ID3"):
        cw, ch = card_size(preset)
        cells = layout(2, cw, ch)
        ops = "".join(f"{r} {g} {b} rg {x} {y} {w} {h} re f\n" for (x, y, w, h), (r, g, b) in zip(cells, [(1, 0, 0), (0, 0, 1)]))
        pdf = pikepdf.new(); pg = pdf.add_blank_page(page_size=(A4W, A4H)); pg.Resources = Dictionary(); pg.Contents = pdf.make_stream(ops.encode())
        path = os.path.join(OUT, f"idcard_{preset}.pdf"); pdf.save(path)
        base = path[:-4]
        subprocess.run(["pdftoppm", "-r", "300", "-png", "-singlefile", path, base], check=True)
        img = np.array(Image.open(base + ".png").convert("RGB")).astype(int)
        px_mm = 300 / 25.4
        red = (img[:, :, 0] > 200) & (img[:, :, 1] < 60) & (img[:, :, 2] < 60)
        blue = (img[:, :, 2] > 200) & (img[:, :, 0] < 60) & (img[:, :, 1] < 60)
        def bbox(mask):
            ys, xs = np.where(mask); return xs.min(), ys.min(), xs.max() + 1, ys.max() + 1
        rx0, ry0, rx1, ry1 = bbox(red); bx0, by0, bx1, by1 = bbox(blue)
        wmm = (rx1 - rx0) / px_mm; hmm = (ry1 - ry0) / px_mm
        exp_w, exp_h = PRESETS[preset]
        good &= check(abs(wmm - exp_w) < 0.4 and abs(hmm - exp_h) < 0.4, f"{preset} đo được {wmm:.1f} x {hmm:.1f} mm (đúng {exp_w} x {exp_h})")
        left_mm = rx0 / px_mm; right_mm = (img.shape[1] - rx1) / px_mm
        good &= check(abs(left_mm - right_mm) < 0.5, f"{preset}: lề trái {left_mm:.1f} mm = lề phải {right_mm:.1f} mm (căn giữa ngang)")
        top_mm = ry0 / px_mm; bottom_mm = (img.shape[0] - by1) / px_mm
        good &= check(abs(top_mm - bottom_mm) < 0.6 and ry0 < by0, f"{preset}: lề trên {top_mm:.1f} mm = lề dưới {bottom_mm:.1f} mm, mặt trước (đỏ) ở trên mặt sau (xanh)")
        gap_mm = (by0 - ry1) / px_mm
        good &= check(abs(gap_mm - GAP / MM) < 0.5, f"{preset}: khoảng cách hai thẻ {gap_mm:.1f} mm (mong đợi {GAP / MM:.1f})")
    print("TAT CA DAT" if good else "CO LOI")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
