#!/usr/bin/env python3
"""Kiểm chứng TiffWriter (phiên 19, mục 4.47.4): TIFF nhiều trang (đen trắng Group 4, xám / màu Deflate + predictor).

Bản Java (TiffCheck.java, cùng bố cục tệp với Kotlin) ghi tệp; rồi tệp được đọc bằng BA bộ đọc độc lập và so từng điểm ảnh:
  1. một bộ phân tích cấu trúc TIFF viết riêng (đầu tệp, chuỗi IFD, thẻ sắp tăng dần, mọi offset chẵn và nằm trong tệp, dải dữ liệu không chồng nhau);
  2. libtiff qua Pillow (số trang, kích thước, chế độ, từng điểm ảnh, dpi);
  3. libtiff qua OpenCV (imreadmulti) cho trang xám / màu, và ImageMagick (`convert`) cho trang bất kỳ.
Luồng Group 4 lấy từ chính libtiff (Pillow ghi TIFF group4 rồi ta cắt lấy dải) để kiểm cả quy ước PhotometricInterpretation 1 (BlackIsZero) mà không phụ thuộc bộ mã hoá của ứng dụng
(bộ mã hoá Ccitt4Encoder đã được kiểm với libtiff ở phiên 6-7).
Chạy: python3 tiff_check.py  (cần java, pillow, numpy, opencv-python, ImageMagick `convert`)
"""
import io, os, random, struct, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import numpy as np
from PIL import Image
import cv2
HERE = os.path.dirname(os.path.abspath(__file__))
FAIL = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: FAIL.append(msg)
    return ok
rnd = random.Random(1906); nprnd = np.random.RandomState(1906)

def g4_strip(img1):
    """Luồng G4 do libtiff tạo cho ảnh 1 bit (chế độ '1'); trả (bytes, photometric)."""
    buf = io.BytesIO(); img1.save(buf, format="TIFF", compression="group4"); buf.seek(0)
    t = Image.open(buf); off, cnt = t.tag_v2[273], t.tag_v2[279]
    if isinstance(off, tuple): off, cnt = off[0], cnt[0]
    return buf.getvalue()[off:off + cnt], t.tag_v2[262], t.tag_v2.get(278)

def make_bilevel(w, h):
    k = rnd.choice(["text", "noise", "white", "black", "stripes", "edge"])
    a = np.ones((h, w), dtype=bool)                        # True = trắng
    if k == "text":
        for _ in range(max(1, h // 9)):
            y = rnd.randrange(h); x = rnd.randrange(w); a[y:y + rnd.randint(1, 3), x:x + rnd.randint(1, max(2, w // 2))] = False
    elif k == "noise": a = nprnd.rand(h, w) > 0.5
    elif k == "black": a[:] = False
    elif k == "stripes": a[:, ::max(2, rnd.randint(2, 7))] = False
    elif k == "edge": a[:, : w // 2] = False
    return Image.fromarray((a * 255).astype(np.uint8)).convert("1")

def photo(w, h, ch):
    yy, xx = np.mgrid[0:h, 0:w]
    base = [(xx * 255 // max(w - 1, 1)), (yy * 255 // max(h - 1, 1)), ((xx + yy) * 255 // max(w + h - 2, 1))]
    a = np.stack([base[i % 3] for i in range(ch)], axis=2) if ch > 1 else base[0][:, :, None]
    a = a + nprnd.randint(-6, 7, size=a.shape)
    return np.clip(a, 0, 255).astype(np.uint8)

def parse_tiff(path):
    """Bộ phân tích cấu trúc TIFF viết riêng: danh sách trang [{tag: (type, count, value-or-list)}] và các lỗi cấu trúc."""
    d = open(path, "rb").read(); errs = []; pages = []
    if d[:4] != b"II*\x00": return [], ["đầu tệp sai"]
    off = struct.unpack_from("<I", d, 4)[0]; seen = set(); spans = []
    while off:
        if off in seen: errs.append("vòng IFD"); break
        seen.add(off)
        if off % 2 or off + 2 > len(d): errs.append(f"IFD ở offset lẻ / ngoài tệp {off}"); break
        n = struct.unpack_from("<H", d, off)[0]; tags = {}; last = -1
        for i in range(n):
            tag, typ, cnt, val = struct.unpack_from("<HHII", d, off + 2 + 12 * i)
            if tag <= last: errs.append("thẻ không tăng dần")
            last = tag; size = {3: 2, 4: 4, 5: 8}[typ] * cnt
            if size <= 4: raw = d[off + 2 + 12 * i + 8: off + 2 + 12 * i + 8 + size]
            else:
                if val % 2 or val + size > len(d): errs.append(f"giá trị thẻ {tag} lẻ / ngoài tệp")
                raw = d[val:val + size]
            fmt = {3: "H", 4: "I", 5: "I"}[typ]; vals = list(struct.unpack("<" + fmt * (cnt * (2 if typ == 5 else 1)), raw)); tags[tag] = vals
        so, sc = tags[273][0], tags[279][0]
        if so + sc > len(d): errs.append("dải dữ liệu ngoài tệp")
        spans.append((so, so + sc, "strip")); spans.append((off, off + 2 + 12 * n + 4, "ifd"))
        pages.append(tags); off = struct.unpack_from("<I", d, off + 2 + 12 * n)[0]
    spans.sort()
    for (a0, a1, _), (b0, b1, _) in zip(spans, spans[1:]):
        if a1 > b0: errs.append("hai vùng chồng nhau")
    return pages, errs

def run_java(lines, out):
    spec = os.path.join(OUT, "tiff_spec.txt"); open(spec, "w").write("\n".join(lines) + "\n")
    r = subprocess.run(["java", os.path.join(HERE, "TiffCheck.java"), spec, out], capture_output=True, text=True)
    if r.returncode: print(r.stderr[-1500:]); sys.exit(1)

# ---------------------------------------------------------------- 1. bilevel G4 nhiều trang
print("== 1. G4 đen trắng: nhiều trang, kích thước lẻ, trang trắng / đen / nhiễu ==")
imgs, lines, pol = [], [], set()
sizes = [(1, 1), (7, 5), (8, 8), (9, 3), (63, 40), (64, 64), (65, 17), (200, 120), (1000, 30), (2480 // 8, 3508 // 8)]
for w, h in sizes + [(rnd.randint(1, 300), rnd.randint(1, 200)) for _ in range(30)]:
    im = make_bilevel(w, h); strip, photometric, rps = g4_strip(im); pol.add(photometric)
    imgs.append(im); lines.append("\t".join(["G4", str(w), str(h), str(rnd.choice([72, 150, 200, 300])), strip.hex()]))
check(pol == {1}, f"libtiff ghi group4 (chế độ '1', trắng = bit 1) với PhotometricInterpretation = {pol} (1 = BlackIsZero: cùng quy ước với luồng của Ccitt4Encoder, đã khớp từng byte với libtiff ở phiên 6-7 và với /BlackIs1 false của PDF)")
out = os.path.join(OUT, "t_g4.tif"); run_java(lines, out)
pages, errs = parse_tiff(out)
check(not errs and len(pages) == len(imgs), f"cấu trúc: {len(pages)} IFD nối đúng chuỗi, thẻ tăng dần, offset chẵn, dải không chồng nhau ({errs[:2]})")
t = Image.open(out); bad = []
check(getattr(t, "n_frames", 1) == len(imgs), f"Pillow / libtiff đếm đúng {len(imgs)} trang")
for i, (im, ln) in enumerate(zip(imgs, lines)):
    t.seek(i)
    if t.size != im.size or t.mode != "1" or not np.array_equal(np.array(t.convert("L")), np.array(im.convert("L"))): bad.append(i)
    dpi = int(ln.split("\t")[3])
    if abs(t.info.get("dpi", (0, 0))[0] - dpi) > 0.5: bad.append(("dpi", i))
check(not bad, f"{len(imgs)} trang G4: từng điểm ảnh và dpi đọc lại bằng libtiff khớp bản gốc ({bad[:3]})")
ok_cv, frames = cv2.imreadmulti(out, flags=cv2.IMREAD_GRAYSCALE); badcv = [i for i, (f, im) in enumerate(zip(frames, imgs)) if f.shape != (im.size[1], im.size[0]) or not np.array_equal(f > 127, np.array(im.convert("L")) > 127)]
check(ok_cv and len(frames) == len(imgs) and not badcv, f"OpenCV (libtiff) đọc {len(frames)} trang, khớp từng điểm ảnh ({badcv[:3]})")
r = subprocess.run(["convert", out + "[5]", "-depth", "8", "gray:-"], capture_output=True); im5 = np.array(imgs[5].convert("L")).flatten()
check(r.returncode == 0 and np.array_equal(np.frombuffer(r.stdout, np.uint8) > 127, im5 > 127), "ImageMagick đọc trang 5 khớp")

# ---------------------------------------------------------------- 2. xám / màu Deflate + predictor
print("== 2. xám và màu: Deflate + predictor ngang ==")
pages_np, lines = [], []
for kind, ch in (("GRAY", 1), ("RGB", 3), ("RGB", 3), ("GRAY", 1), ("RGB", 3)):
    w, h = rnd.choice([(1, 1), (3, 2), (17, 9), (64, 48), (255, 100), (333, 211)])
    a = photo(w, h, ch) if rnd.random() < .7 else nprnd.randint(0, 256, size=(h, w, ch)).astype(np.uint8)
    pages_np.append((kind, a)); lines.append("\t".join([kind, str(w), str(h), "300", a.tobytes().hex()]))
out2 = os.path.join(OUT, "t_color.tif"); run_java(lines, out2)
pg2, errs2 = parse_tiff(out2); check(not errs2 and len(pg2) == len(pages_np), f"cấu trúc: {len(pg2)} IFD ({errs2[:2]})")
t2 = Image.open(out2); bad2 = []
for i, (kind, a) in enumerate(pages_np):
    t2.seek(i); got = np.array(t2.convert("RGB" if kind == "RGB" else "L")); exp = a[:, :, 0] if kind == "GRAY" else a
    if got.shape != exp.shape or not np.array_equal(got, exp): bad2.append(i)
check(not bad2 and t2.n_frames == len(pages_np), f"{len(pages_np)} trang xám / RGB (gồm ảnh nhiễu hoàn toàn và ảnh 1x1): từng điểm ảnh đọc lại bằng libtiff khớp ({bad2})")
ok_cv2, frames2 = cv2.imreadmulti(out2, flags=cv2.IMREAD_UNCHANGED)
badcv2 = []
for i, ((kind, a), f) in enumerate(zip(pages_np, frames2)):
    exp = a[:, :, 0] if kind == "GRAY" else a[:, :, ::-1]; f = f if f.ndim == 2 or kind == "RGB" else f[:, :, 0]
    if f.shape != exp.shape or not np.array_equal(f, exp): badcv2.append(i)
check(ok_cv2 and len(frames2) == len(pages_np) and not badcv2, f"OpenCV đọc {len(frames2)} trang xám / màu khớp từng điểm ảnh ({badcv2})")
# predictor có ích thật: ảnh chuyển sắc nén nhỏ hơn nhiều so với không predictor
a = photo(400, 300, 3); import zlib
with_pred = len(zlib.compress(np.concatenate([a[:, :1], np.diff(a.astype(np.int16), axis=1).astype(np.uint8)], axis=1).tobytes(), 6)); without = len(zlib.compress(a.tobytes(), 6))
check(with_pred < without, f"predictor ngang làm Deflate nhỏ hơn: {with_pred} < {without} byte trên ảnh chuyển sắc có nhiễu nhẹ")

# ---------------------------------------------------------------- 3. trộn trang G4 + màu, và thử âm tính
print("== 3. trộn G4 / xám / màu trong một tệp; thử âm tính ==")
im = make_bilevel(90, 50); strip, _, _ = g4_strip(im); col = photo(60, 40, 3)
mixed = [f"G4\t90\t50\t200\t{strip.hex()}", f"RGB\t60\t40\t200\t{col.tobytes().hex()}", f"G4\t90\t50\t200\t{strip.hex()}"]
out3 = os.path.join(OUT, "t_mixed.tif"); run_java(mixed, out3); t3 = Image.open(out3); okm = t3.n_frames == 3
t3.seek(1); okm &= np.array_equal(np.array(t3.convert("RGB")), col); t3.seek(2); okm &= np.array_equal(np.array(t3.convert("L")), np.array(im.convert("L")))
check(okm, "G4, màu, G4 trong một tệp: ba trang đều đúng (con trỏ IFD tiếp theo được vá đúng qua các loại trang)")
# lỗi cố ý: bỏ thẻ predictor trên trang màu -> libtiff đọc ra ảnh sai
src = open(os.path.join(HERE, "TiffCheck.java"), encoding="utf-8").read(); bad_src = src.replace('if (!kind.equals("G4")) entries.add(new long[]{317, 3, 1, 2});', 'if (!kind.equals("G4")) entries.add(new long[]{317, 3, 1, 1});')
assert bad_src != src
md = os.path.join(OUT, "mut_tiff"); os.makedirs(md, exist_ok=True); open(os.path.join(md, "TiffCheck.java"), "w", encoding="utf-8").write(bad_src)
spec = os.path.join(OUT, "tiff_spec.txt"); open(spec, "w").write(f"RGB\t60\t40\t200\t{col.tobytes().hex()}\n")
subprocess.run(["java", os.path.join(md, "TiffCheck.java"), spec, os.path.join(md, "o.tif")], check=True)
tm = Image.open(os.path.join(md, "o.tif")).convert("RGB"); check(not np.array_equal(np.array(tm), col), "âm tính: bản 'ghi thẻ predictor = 1 dù dữ liệu đã vi phân' cho ảnh SAI (bị bắt)")
bad_src = src.replace("entries.add(new long[]{262, 3, 1, photometric});", "entries.add(new long[]{262, 3, 1, kind.equals(\"G4\") ? 0 : photometric});")
open(os.path.join(md, "TiffCheck.java"), "w", encoding="utf-8").write(bad_src)
open(spec, "w").write(f"G4\t90\t50\t200\t{strip.hex()}\n"); subprocess.run(["java", os.path.join(md, "TiffCheck.java"), spec, os.path.join(md, "o2.tif")], check=True)
tm2 = Image.open(os.path.join(md, "o2.tif")).convert("L"); check(not np.array_equal(np.array(tm2), np.array(im.convert("L"))), "âm tính: bản 'G4 với PhotometricInterpretation = 0' (giả định sai ban đầu) cho ảnh ĐẢO MÀU (bị bắt)")
print()
print("TAT CA DAT" if not FAIL else f"CÓ {len(FAIL)} LỖI")
sys.exit(1 if FAIL else 0)
