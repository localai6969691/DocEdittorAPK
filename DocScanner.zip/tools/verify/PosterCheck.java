// Bản Java chạy được của PdfPoster.plan (phiên 19, mục 4.47.3): cùng công thức, cùng thứ tự phép tính float với app/.../util/PdfPoster.kt. Dùng bởi poster_check.py.
//   java PosterCheck.java <tệp vào> <tệp ra>   mỗi dòng vào: "<rộng hiển thị> <cao hiển thị> <số tờ ngang>"
//   mỗi dòng ra: "sheetW sheetH cols rows scale offsetX offsetY pw ph | wx wy ; wx wy ; ..."  (số float in bằng Float.toString)
import java.nio.file.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class PosterCheck {
    static final float A4_WIDTH = 595.276f, A4_HEIGHT = 841.89f, MARGIN = 20f, OVERLAP = 28.35f;
    static String plan(float dw, float dh, int cols) {
        int c = Math.max(2, Math.min(6, cols));
        boolean landscape = dw > dh;
        float sheetW = landscape ? A4_HEIGHT : A4_WIDTH, sheetH = landscape ? A4_WIDTH : A4_HEIGHT;
        float pw = sheetW - 2 * MARGIN, ph = sheetH - 2 * MARGIN;
        float totalW = c * pw - (c - 1) * OVERLAP;
        float s = totalW / dw;
        float needed = dh * s;
        int rows = Math.max(1, (int) Math.ceil(((needed - ph) / (ph - OVERLAP) - 1e-4)) + 1);
        float totalH = rows * ph - (rows - 1) * OVERLAP;
        StringBuilder w = new StringBuilder();
        for (int r = 0; r < rows; r++) for (int col = 0; col < c; col++) w.append(col * (pw - OVERLAP)).append(' ').append(totalH - r * (ph - OVERLAP) - ph).append(" ; ");
        return sheetW + " " + sheetH + " " + c + " " + rows + " " + s + " " + 0f + " " + ((totalH - needed) / 2f) + " " + pw + " " + ph + " | " + w;
    }
    public static void main(String[] a) throws Exception {
        StringBuilder out = new StringBuilder();
        for (String ln : Files.readAllLines(Paths.get(a[0]), StandardCharsets.UTF_8)) { if (ln.isBlank()) continue; String[] p = ln.trim().split(" "); out.append(plan(Float.parseFloat(p[0]), Float.parseFloat(p[1]), Integer.parseInt(p[2]))).append("\n"); }
        Files.write(Paths.get(a[1]), out.toString().getBytes(StandardCharsets.UTF_8));
    }
}
