"""Kiểm chứng ArchiveImages (phiên 18): nhập ảnh từ gói CBZ/ZIP vào hàng đợi quét + kiểm dung lượng trống.

ArchiveImagesCheck.java là bản Java chạy được của util/ArchiveImages.kt. So với bản tham chiếu ĐỘC LẬP bằng Python:
A - thứ tự tự nhiên: 400 danh sách tên ngẫu nhiên (số có/không có số 0 đứng đầu, chữ hoa/thường, chữ Việt) khớp key sắp xếp tham chiếu; ví dụ p2 < p10.
B - chọn ảnh: bỏ thư mục, __MACOSX, tệp ẩn, Thumbs.db, tệp không phải ảnh; chấp nhận dấu gạch ngược kiểu Windows.
C - giải nén an toàn (zip-slip: tên '../evil.jpg', '/abs/x.png'; mọi tệp ra đều nằm trong thư mục đích và tên chỉ do app đặt), đúng thứ tự, đúng từng byte;
    zip-bomb: tệp giải nén vượt trần bị bỏ dù khai báo nhỏ; trần số tệp / tổng dung lượng; gói hỏng -> ERR, không để lại tệp.
D - dung lượng trống: công thức 2 x đầu vào + 64 MB, bão hoà ở Long.MAX_VALUE (không tràn số).
Chạy: python3 archive_images_check.py   (cần java 11+)
"""
import os, random, re, shutil, subprocess, sys, tempfile, zipfile
HERE = os.path.dirname(os.path.abspath(__file__)); FAILS = []
def check(c, w):
    print(("ok  " if c else "LOI"), w)
    if not c: FAILS.append(w)
def java(*a):
    r = subprocess.run(["java", os.path.join(HERE, "ArchiveImagesCheck.java"), *map(str, a)], capture_output=True, text=True)
    if r.returncode != 0: print(r.stderr[-800:])
    return r.stdout.rstrip("\n").split("\n") if r.stdout.strip() else []
tmp = tempfile.mkdtemp(prefix="arc_")
P = lambda n: os.path.join(tmp, n)
def key(n): return ([(0, int(t), "") if t[0].isdigit() else (1, 0, t.lower()) for t in re.findall(r"[0-9]+|[^0-9]+", n)], n)

print("== A. thứ tự tự nhiên ==")
rnd = random.Random(11); bad = 0
words = ["p", "P", "trang", "Trang", "chương ", "ảnh", "Ảnh", "img_", "IMG-", "a", "Z", "_"]
lists = []
for _ in range(400):
    names = {rnd.choice(words) + str(rnd.choice([rnd.randint(0, 12), rnd.randint(0, 3000), "00" + str(rnd.randint(1, 20))])) + rnd.choice([".jpg", ".png", "", "b.jpg", "/1.png"]) for _ in range(rnd.randint(2, 25))}
    lists.append(sorted(names))
# một tệp, các danh sách cách nhau bằng dòng "---"; Java sắp từng danh sách một lượt (khởi động JVM 400 lần quá chậm)
shuf = []
for names in lists:
    s = names[:]; rnd.shuffle(s); shuf.append(s)
open(P("l.txt"), "w", encoding="utf-8").write("".join("\n".join(s) + "\n---\n" for s in shuf))
out_lines = java("sort-batch", P("l.txt")); got_lists = []; cur = []
for l in out_lines:
    if l == "---": got_lists.append(cur); cur = []
    else: cur.append(l)
bad = sum(1 for g, names in zip(got_lists, lists) if g != sorted(names, key=key))
if len(got_lists) != len(lists): bad += 1000
check(bad == 0, "400 danh sách ngẫu nhiên khớp key tham chiếu độc lập")
open(P("l.txt"), "w", encoding="utf-8").write("\n".join(["p10.jpg", "p2.jpg", "p1.jpg", "p02.jpg", "P3.jpg"]) + "\n")
check(java("sort", P("l.txt")) == ["p1.jpg", "p02.jpg", "p2.jpg", "P3.jpg", "p10.jpg"], "p1 < p02 < p2 < P3 < p10 (số theo giá trị, không phân biệt hoa thường, số 0 đầu không đảo thứ tự lung tung)")

print("== B. chọn ảnh ==")
cases = [("a.jpg", True), ("dir/b.PNG", True), ("c.webp", True), ("d.jpeg", True), ("e.gif", True), ("f.bmp", True), ("x/", False), ("__MACOSX/._a.jpg", False), (".hidden.png", False), ("dir/.cache/z.jpg", False),
         ("Thumbs.db", False), ("sub/thumbs.DB", False), ("note.txt", False), ("noext", False), ("win\\dir\\p.jpg", True), ("win\\.hid\\p.jpg", False), ("a.jpg.txt", False), ("ComicInfo.xml", False)]
open(P("c.txt"), "w", encoding="utf-8").write("\n".join(c for c, _ in cases) + "\n")
check(java("isimage", P("c.txt")) == ["true" if e else "false" for _, e in cases], f"{len(cases)} tên: ảnh / không phải ảnh phân loại đúng")

print("== C. giải nén an toàn ==")
def mkzip(path, entries):
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for n, d in entries: z.writestr(zipfile.ZipInfo(n), d, compress_type=zipfile.ZIP_DEFLATED)
D = {n: rnd.randbytes(300 + i * 17) for i, n in enumerate(["p1.jpg", "p2.jpg", "p10.jpg", "p9.png", "ch2/001.png", "ch10/001.png", "ch2/010.png"])}
entries = [(n, D[n]) for n in D] + [("__MACOSX/._p1.jpg", b"junk"), (".hidden.png", b"junk"), ("Thumbs.db", b"junk"), ("readme.txt", b"hello"), ("../evil.jpg", b"EVIL"), ("/abs/evil.png", b"EVIL"), ("win\\dir\\w.png", b"WIN"), ("empty/", b"")]
Z = P("a.cbz"); mkzip(Z, entries)
parent = P("sandbox"); os.makedirs(parent); out = os.path.join(parent, "out")
before = set(os.listdir(tmp))
res = java("extract", Z, out, "arc_", 1000, 10**9, 10**10)
names = [l.split("\t")[0] for l in res]
allimg = [n for n, _ in entries if not n.endswith("/") and re.search(r"\.(jpe?g|png)$", n, re.I) and not n.startswith((".", "__MACOSX")) and "/." not in n]
ref = sorted(allimg, key=lambda n: key(n.replace("\\", "/")))
content = {n: d for n, d in entries}
check(len(res) == len(ref) and names == [f"arc_{i+1:04d}.{n.rsplit('.',1)[1].lower()}" for i, n in enumerate(ref)], f"{len(ref)} ảnh, đặt tên arc_0001... đúng thứ tự tự nhiên: {names}")
check(all(open(os.path.join(out, nm), "rb").read() == content[src] for nm, src in zip(names, ref)), "nội dung từng ảnh khớp từng byte với ảnh gốc trong gói")
check(os.listdir(parent) == ["out"] and set(os.listdir(tmp)) == before | {"sandbox"} and not os.path.exists(P("evil.jpg")) and not os.path.exists("/abs/evil.png"), "zip-slip: không có tệp nào ngoài thư mục đích")
check(all(re.fullmatch(r"arc_\d{4}\.(jpg|png)", f) for f in os.listdir(out)) and len(os.listdir(out)) == len(ref), "mọi tệp ra đều có dạng arc_NNNN.jpg|png do app đặt; không có tệp thừa")
out2 = os.path.join(parent, "out2"); r = java("extract", Z, out2, "x_", 3, 10**9, 10**10)
check([l.split("\t")[0] for l in r] == [f"x_{i+1:04d}.{n.rsplit('.',1)[1].lower()}" for i, n in enumerate(ref[:3])], f"trần số tệp = 3 -> đúng 3 ảnh đầu theo thứ tự tự nhiên: {[l.split(chr(9))[0] for l in r]}")
# zip-bomb: 5 MB số 0 nén còn vài KB; trần mỗi tệp 1 MB
bomb = P("bomb.cbz"); small = rnd.randbytes(500)
mkzip(bomb, [("a.jpg", small), ("b.jpg", b"\0" * (5 * 1024 * 1024)), ("c.jpg", small)])
r = java("extract", bomb, os.path.join(parent, "bomb"), "b_", 100, 1024 * 1024, 10**10)
check(len(r) == 2 and all(int(l.split("\t")[1]) == 500 for l in r) and sorted(os.listdir(os.path.join(parent, "bomb"))) == ["b_0001.jpg", "b_0002.jpg"], "zip-bomb: tệp giải nén vượt trần bị bỏ, hai tệp nhỏ còn lại giữ, không để lại tệp dở")
r = java("extract", bomb, os.path.join(parent, "bomb2"), "t_", 100, 10**9, 2000)
check(len(r) == 1 and r[0].startswith("t_0001"), f"trần TỔNG dung lượng 2000 byte: dừng đúng chỗ ({len(r)} ảnh)")
bad_zip = P("bad.cbz"); open(bad_zip, "wb").write(b"khong phai zip" * 10)
check(java("extract", bad_zip, os.path.join(parent, "bad"), "z_", 10, 10**6, 10**7) == ["ERR"], "gói hỏng -> ERR")

print("== D. dung lượng trống ==")
M = 64 * 1024 * 1024; LM = 2**63 - 1
cases = [(0, 0), (M - 1, 0), (M, 0), (10**9, 10**9), (2 * 10**9 + M, 10**9), (2 * 10**9 + M - 1, 10**9), (LM, LM // 2), (LM, LM // 2 + 1), (LM, LM), (5, LM)]
cases += [(rnd.randint(0, 10**11), rnd.randint(0, 10**10)) for _ in range(200)]
def ref_enough(free, inp): return free >= min(LM, 2 * inp + M)
open(P("s.txt"), "w").write("\n".join(f"{a} {b}" for a, b in cases) + "\n")
got = java("space", P("s.txt"))
check(got == [("true" if ref_enough(a, b) else "false") for a, b in cases], f"{len(cases)} cặp (trống, đầu vào) khớp công thức tham chiếu, kể cả sát biên và Long.MAX_VALUE")

shutil.rmtree(tmp, ignore_errors=True)
print("\nTAT CA DAT" if not FAILS else f"\n{len(FAILS)} LOI"); sys.exit(1 if FAILS else 0)
