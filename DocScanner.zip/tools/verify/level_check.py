"""Kiểm chứng LevelIndicator (phiên 17): thước thăng bằng của camera.

Hằng số đọc TRỰC TIẾP từ LevelIndicator.kt. Công thức acos(|gz|/|g|) được đối chiếu với một cách tính ĐỘC LẬP: đặt máy theo góc xoay (roll quanh trục Y, pitch quanh
trục X) -> ma trận xoay -> vectơ trọng lực đo được trong hệ máy = R^T (0,0,-g) -> góc giữa pháp tuyến màn hình và phương thẳng đứng theo ma trận (arccos của phần tử R[2][2]).
Hai cách phải khớp trên 5 000 góc ngẫu nhiên, mọi độ lớn g, mặt úp hay ngửa, kèm nhiễu nhỏ. Ca tay: nằm phẳng 0, dựng đứng 90, 45 độ, g=0 (rơi tự do) -> 0.
Bộ lọc mượt: hội tụ về giá trị thật; nhiễu đều ±4 độ giảm độ lệch chuẩn đúng như lý thuyết sqrt(a/(2-a)). Ngưỡng 3 độ.
Chạy: python3 level_check.py   (cần numpy)
"""
import math, os, re, sys
import numpy as np
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
src = open(os.path.join(ROOT, "app/src/main/java/com/example/docscanner/util/LevelIndicator.kt"), encoding="utf-8").read()
LEVEL = float(re.search(r"LEVEL_DEGREES = ([\d.]+)f", src).group(1)); ALPHA = float(re.search(r"SMOOTH_ALPHA = ([\d.]+)f", src).group(1))
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
def tilt(gx, gy, gz):
    n = math.sqrt(gx * gx + gy * gy + gz * gz)
    if n < 1e-3: return 0.0
    return math.degrees(math.acos(min(1.0, max(0.0, abs(gz) / n))))
check(LEVEL == 3.0 and abs(ALPHA - 0.2) < 1e-9, f"ngưỡng {LEVEL} độ, hệ số lọc {ALPHA}")
check(abs(tilt(0, 0, 9.81)) < 1e-4 and abs(tilt(0, 0, -9.81)) < 1e-4, "nằm phẳng (ngửa hoặc úp): 0 độ")
check(abs(tilt(0, 9.81, 0) - 90) < 1e-4 and abs(tilt(9.81, 0, 0) - 90) < 1e-4, "dựng đứng: 90 độ")
check(abs(tilt(0, 9.81 * math.sin(math.radians(45)), 9.81 * math.cos(math.radians(45))) - 45) < 1e-3, "nghiêng 45 độ")
check(tilt(0, 0, 0) == 0.0, "g = 0 (rơi tự do / không tín hiệu): 0, không chia cho 0")
def rot_x(a): c, s = math.cos(a), math.sin(a); return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
def rot_y(a): c, s = math.cos(a), math.sin(a); return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
rng = np.random.default_rng(9); worst = 0.0
for _ in range(5000):
    roll, pitch = rng.uniform(-math.pi / 2, math.pi / 2, 2) * rng.choice([1, 1, 0.1])
    R = rot_y(roll) @ rot_x(pitch)           # máy -> thế giới
    face_down = rng.random() < 0.5
    if face_down: R = R @ np.diag([1, -1, -1])   # lật úp
    g = float(rng.uniform(8.5, 11.0))
    gdev = R.T @ np.array([0, 0, g])          # trọng lực đo trong hệ máy
    independent = math.degrees(math.acos(min(1.0, abs(R[2][2]))))   # góc giữa pháp tuyến màn hình và phương đứng
    worst = max(worst, abs(tilt(*gdev) - independent))
check(worst < 1e-3, f"5 000 góc ngẫu nhiên: công thức = cách tính qua ma trận xoay (lệch tối đa {worst:.2e} độ)")
est = 30.0; seq = [10.0]
for _ in range(60): est += ALPHA * (10.0 - est)
check(abs(est - 10.0) < 0.01, f"bộ lọc hội tụ về 10 độ sau 60 mẫu ({est:.3f})")
noise = rng.uniform(-4, 4, 400); s = 20.0; out = []
for x in noise: s += ALPHA * ((20.0 + x) - s); out.append(s)
theory = float(np.std(noise)) * math.sqrt(ALPHA / (2 - ALPHA))   # độ lệch chuẩn ổn định của bộ lọc mũ
sd = float(np.std(np.array(out[40:]) - 20.0))
check(abs(sd - theory) < 0.25 * theory and sd < 0.5 * float(np.std(noise)) and max(abs(np.array(out[40:]) - 20.0)) < 4.0, f"nhiễu đều ±4 độ: độ lệch chuẩn {np.std(noise):.2f} -> {sd:.2f} (lý thuyết {theory:.2f}), cực đại còn {max(abs(np.array(out[40:]) - 20.0)):.2f} < 4")
check(3.0 <= LEVEL and (2.99 <= LEVEL) and not (3.01 <= LEVEL), "ranh giới: 3,0 độ vẫn là 'song song', 3,01 thì không")
print()
print("TAT CA DAT" if not FAILS else f"CO {len(FAILS)} LOI")
sys.exit(1 if FAILS else 0)
