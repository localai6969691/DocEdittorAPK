import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

/**
 * Bản Java song song, CÙNG THUẬT TOÁN, của util/PdfSignatureProbe.kt (phiên 20). Dùng bởi signed_pdf_check.py.
 * Dùng:  java SignatureProbeCheck.java <chunk> <tệp.pdf>...
 * Mỗi tệp in:  FILE <đường dẫn> <độ dài>   rồi mỗi chữ ký:  SIG <vị trí> <a> <b> <c> <d> <subfilter|-> <ts 0/1> <mức DocMDP>
 */
public class SignatureProbeCheck {
    static final String KEY = "/ByteRange";
    static final int MAX_SIGNATURES = 64, WINDOW = 4096;
    static final Pattern SUBFILTER = Pattern.compile("/SubFilter\\s*/([A-Za-z0-9._\\-]+)");
    static final Pattern DOC_TIMESTAMP = Pattern.compile("/Type\\s*/DocTimeStamp");
    static final Pattern DOC_MDP = Pattern.compile("/TransformMethod\\s*/DocMDP");
    static final Pattern P_LEVEL = Pattern.compile("/P(?![A-Za-z])\\s*([123])(?![0-9])");

    interface Source { byte[] read(long off, int len) throws Exception; }

    record Sig(long position, long a, long b, long c, long d, String sub, boolean ts, int level) {}

    static boolean isWs(byte b) { return b == 32 || b == 10 || b == 13 || b == 9 || b == 12 || b == 0; }

    static long[] parseRange(byte[] head) {
        int p = 0;
        while (p < head.length && isWs(head[p])) p++;
        if (p >= head.length || head[p] != '[') return null;
        p++;
        long[] out = new long[4];
        for (int n = 0; n < 4; n++) {
            while (p < head.length && isWs(head[p])) p++;
            int s = p; long v = 0;
            while (p < head.length && head[p] >= '0' && head[p] <= '9') {
                if (p - s > 15) return null;
                v = v * 10 + (head[p] - '0');
                p++;
            }
            if (p == s) return null;
            out[n] = v;
        }
        while (p < head.length && isWs(head[p])) p++;
        if (p >= head.length || head[p] != ']') return null;
        return out;
    }

    static Sig parseAt(long pos, long length, Source read) throws Exception {
        byte[] head = read.read(pos + KEY.length(), 160);
        long[] r = parseRange(head);
        if (r == null) return null;
        long a = r[0], b = r[1], c = r[2], d = r[3];
        if (a != 0 || b <= 0 || c <= a + b || d < 0 || c + d > length) return null;
        byte[] x = read.read(a + b, 1);
        if (x.length == 0 || x[0] != '<') return null;
        byte[] y = read.read(c - 1, 1);
        if (y.length == 0 || y[0] != '>') return null;

        long beforeStart = Math.max(0, a + b - WINDOW);
        String before = new String(read.read(beforeStart, (int) (a + b - beforeStart)), StandardCharsets.ISO_8859_1);
        int lastEnd = before.lastIndexOf("endobj");
        if (lastEnd >= 0) before = before.substring(lastEnd + 6);
        String after = new String(read.read(c, WINDOW), StandardCharsets.ISO_8859_1);
        int nextEnd = after.indexOf("endobj");
        if (nextEnd >= 0) after = after.substring(0, nextEnd);
        String meta = before + " " + after;

        Matcher m = SUBFILTER.matcher(meta);
        String sub = m.find() ? m.group(1) : null;
        boolean ts = DOC_TIMESTAMP.matcher(meta).find() || (sub != null && sub.equalsIgnoreCase("ETSI.RFC3161"));
        int level = 0;
        if (DOC_MDP.matcher(meta).find()) {
            int i = meta.indexOf("/TransformParams");
            String params = i >= 0 ? meta.substring(i) : meta;
            Matcher pm = P_LEVEL.matcher(params);
            level = pm.find() ? Integer.parseInt(pm.group(1)) : 2;
        }
        return new Sig(pos, a, b, c, d, sub, ts, level);
    }

    static List<Sig> scan(long length, int chunkSize, Source read) throws Exception {
        byte[] key = KEY.getBytes(StandardCharsets.US_ASCII);
        List<Sig> found = new ArrayList<>();
        long base = 0;
        while (base < length && found.size() < MAX_SIGNATURES) {
            byte[] chunk = read.read(base, chunkSize + key.length);
            if (chunk.length == 0) break;
            int i = 0;
            while (i < chunk.length && i < chunkSize) {
                boolean match = i + key.length <= chunk.length;
                for (int k = 0; match && k < key.length; k++) if (chunk[i + k] != key[k]) match = false;
                if (match) {
                    Sig s = parseAt(base + i, length, read);
                    if (s != null) found.add(s);
                    i += key.length;
                } else i++;
            }
            base += chunkSize;
        }
        found.sort(Comparator.comparingLong(Sig::position));
        return found;
    }

    public static void main(String[] args) throws Exception {
        int chunk = Integer.parseInt(args[0]);
        for (int n = 1; n < args.length; n++) {
            try (RandomAccessFile raf = new RandomAccessFile(args[n], "r")) {
                Source src = (off, len) -> {
                    if (off < 0 || off >= raf.length() || len <= 0) return new byte[0];
                    int cnt = (int) Math.min(len, raf.length() - off);
                    byte[] buf = new byte[cnt];
                    raf.seek(off); raf.readFully(buf);
                    return buf;
                };
                System.out.println("FILE " + args[n] + " " + raf.length());
                for (Sig s : scan(raf.length(), chunk, src))
                    System.out.println("SIG " + s.position + " " + s.a + " " + s.b + " " + s.c + " " + s.d + " " + (s.sub == null ? "-" : s.sub) + " " + (s.ts ? 1 : 0) + " " + s.level);
            }
        }
    }
}
