#!/usr/bin/env python3
"""CHE THÔNG TIN (`util/PdfRedactor.kt`) và ĐÓNG DẤU / CHỮ KÝ ẢNH (`util/PdfStamper.kt`) chạy thật (phiên 26, TECHNICAL_DOCS.md 4.85).

`PdfRedactor` là tính năng riêng tư quan trọng nhất của app: hứa rằng chữ dưới hộp đen KHÔNG còn trong tệp. Từ phiên 18 chỉ có bản Python dựng lại (`redact_check.py`); mã Kotlin chưa từng chạy. Máy này không có
Android nên bộ kiểm dùng (1) shim `android.graphics` Bitmap / Canvas / Paint / Color trên JVM (`real_run/shims`), (2) `real_run/PdfPageBitmapDouble.kt` thay `PdfRenderer` bằng poppler (`pdftoppm -cropbox`: trang
như đang hiển thị), (3) thay `PdfVerify.opensAsPdf` như các bộ kiểm real-run khác; mọi thứ còn lại là mã thật + PdfBox-Android thật. Đo bằng công cụ khác:
  A. PHẢN CHỨNG "chữ còn trong tệp": sau khi che, `pdftotext` không thấy từ nhạy cảm, TOÀN BỘ byte của tệp không chứa nó (kể cả số 12 chữ số), trang đã che không còn /Font, trang không che giữ nguyên chữ chọn được;
  B. HÌNH: trang đã che dựng lại bằng pdftoppm so với trang gốc dựng cùng cỡ + hộp đen vẽ bằng Python (làm tròn RA NGOÀI): toàn bộ hộp đen kể cả mép, ngoài hộp giống gốc, vùng chữ nhạy cảm (hộp chữ do `pdftotext -bbox` đo) đen hoàn toàn;
     trên trang thường, trang xoay 90 + CropBox lệch;
  C. khổ trang ra = khổ hiển thị của gốc; số trang; trả về số trang bị thay bằng ảnh; tệp mã hoá / không phải PDF bị từ chối và không để lại tệp; `pixelRect` so với mô hình viết lại (500 ca ngẫu nhiên);
  D. ĐÓNG DẤU: chữ của trang đóng dấu VẪN chọn được (không dựng ảnh), ảnh đúng chỗ theo hình học viết lại (đã trộn alpha: nửa trong suốt hiện nền), trang không chọn giữ nguyên, `rectFor` 200 ca ngẫu nhiên.
THỬ ÂM TÍNH: 6 bản mã bị làm hỏng (làm tròn mép trái / mép phải hộp vào trong, không vẽ hộp, đóng dấu không bù xoay, `rectFor` không kẹp, che không bỏ /Font) PHẢI bị bắt.
KHÔNG kiểm được: PdfRenderer của máy thật (khác poppler ở khử răng cưa), điện thoại. Chạy: python3 tools/verify/redactor_real_run_check.py [--fast]   (--mutant=N chỉ chạy bản hỏng thứ N, 1-6)"""
import io, math, os, random, re, subprocess, sys, tempfile
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
import pikepdf  # noqa: E402
from pikepdf import Array, Dictionary, Name  # noqa: E402
from PIL import Image  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="redact-")
DOUBLE = {"PdfVerify.kt": ("    fun opensAsPdf(file: File, expectedPages: Int): Boolean {",
    "    fun opensAsPdf(file: File, expectedPages: Int): Boolean {\n        return try {\n            if (!file.exists() || file.length() <= 0L) return false\n"
    "            com.tom_roush.pdfbox.pdmodel.PDDocument.load(file).use { d -> d.numberOfPages > 0 && (expectedPages <= 0 || d.numberOfPages == expectedPages) }\n        } catch (e: Exception) { false }\n    }")}
FILES = ["PdfRedactor.kt", "PdfStamper.kt", "PdfPageGeometry.kt", "PdfStructureOptimizer.kt", "PdfVerify.kt"]
EXTRA = [os.path.join(HERE, "real_run", "RedactHarness.kt"), os.path.join(HERE, "real_run", "PdfPageBitmapDouble.kt")]
def build(mutate=None, tag="base"): return tc.compile(FILES, EXTRA, os.path.join(WORK, "cls-" + tag), mutate, DOUBLE)[0]
def hz(cls, *args):
    r = tc.run(cls, "RedactHarnessKt", [str(a) for a in args])
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-800:])
    return r.stdout.strip().splitlines()[-1] if r.stdout.strip() else ""
def sh(*c): return subprocess.run(c, capture_output=True, text=True)
def P(n): return os.path.join(WORK, n)

def make_source():
    pdf = pikepdf.new(); font = pdf.make_indirect(Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Helvetica)); res = Dictionary(Font=Dictionary(F1=font))
    def page(w, h, body, rotate=0, crop=None):
        pg = pdf.make_indirect(Dictionary(Type=Name.Page, MediaBox=Array([0, 0, w, h]), Contents=pdf.make_stream(body.encode()), Resources=res))
        if crop: pg.CropBox = Array(list(crop))
        if rotate: pg.Rotate = rotate
        return pg
    p0 = page(612, 792, "BT /F1 24 Tf 72 700 Td (ALPHA PUBLIC TEXT) Tj ET\nBT /F1 24 Tf 72 600 Td (SECRET-ID 123456789012) Tj ET\nBT /F1 24 Tf 72 500 Td (KEEP BELOW LINE) Tj ET\n0 0 1 rg 30 30 80 40 re f\n")
    p1 = page(612, 792, "BT /F1 24 Tf 72 400 Td (PAGE TWO UNTOUCHED) Tj ET\n")
    p2 = page(700, 900, "BT /F1 24 Tf 120 500 Td (ROTATED SECRET WORD) Tj ET\n1 0 0 rg 70 80 90 40 re f\n", rotate=90, crop=(50, 60, 650, 860))
    pdf.Root.Pages.Kids = Array([p0, p1, p2]); pdf.Root.Pages.Count = 3; path = P("src.pdf"); pdf.save(path, compress_streams=False); return path

def displayed(spec_w, spec_h, crop, rot):
    x0, y0, x1, y1 = crop or (0, 0, spec_w, spec_h); w, h = x1 - x0, y1 - y0
    return (h, w) if rot in (90, 270) else (w, h)
DISP = [displayed(612, 792, None, 0), displayed(612, 792, None, 0), displayed(700, 900, (50, 60, 650, 860), 90)]
ROT = [0, 0, 90]

def render(pdf, page, w, h, swap=False):
    for f in [x for x in os.listdir(WORK) if x.startswith("rr")]: os.remove(P(f))
    if swap: w, h = h, w
    sh("pdftoppm", "-cropbox", "-png", "-f", str(page), "-l", str(page), "-scale-to-x", str(w), "-scale-to-y", str(h), pdf, P("rr"))
    f = [x for x in os.listdir(WORK) if x.startswith("rr") and x.endswith(".png")][0]
    return np.asarray(Image.open(P(f)).convert("L"), dtype=np.float32)

def words(pdf, page):
    t = sh("pdftotext", "-bbox", "-f", str(page), "-l", str(page), pdf, "-").stdout
    pw, ph = (float(x) for x in re.search(r'<page width="([\d.]+)" height="([\d.]+)"', t).groups())
    return pw, ph, [(m.group(5), float(m.group(1)), float(m.group(2)), float(m.group(3)), float(m.group(4))) for m in re.finditer(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(.*?)</word>', t)]

def py_pixelrect(f, w, h):
    l = min(max(math.floor(min(f[0], f[2]) * w), 0), w - 1); t = min(max(math.floor(min(f[1], f[3]) * h), 0), h - 1)
    r = min(max(math.ceil(max(f[0], f[2]) * w), l + 1), w); b = min(max(math.ceil(max(f[1], f[3]) * h), t + 1), h); return [l, t, r, b]

def clamp01(x): return min(max(x, 0.0), 1.0)

def group_redact(cls):
    src = make_source(); out = P("out.pdf"); dpi = 144.0
    # fractions of the DISPLAYED page, from poppler's own word boxes, grown a little and left with fractional edges on purpose
    pw0, ph0, w0 = words(src, 1); sec = [w for w in w0 if w[0].startswith("SECRET-ID") or w[0] == "123456789012"]
    pad = 3.3
    fr0 = [(min(w[1] for w in sec) - pad) / pw0, (min(w[2] for w in sec) - pad) / ph0, (max(w[3] for w in sec) + pad) / pw0, (max(w[4] for w in sec) + pad) / ph0]
    # page 3 is shown rotated with an offset CropBox, and `pdftotext -bbox` ignores both: locate the text in the DISPLAYED render instead (black pixels; the red block is gray ~76)
    pw2, ph2 = 800, 600; shot = render(src, 3, pw2, ph2, swap=True); ys, xs = np.where(shot < 40)
    tb = (xs.min(), ys.min(), xs.max() + 1, ys.max() + 1)
    fr2 = [(tb[0] - pad) / pw2, (tb[1] - pad) / ph2, (tb[2] + pad) / pw2, (tb[3] + pad) / ph2]
    check(len(xs) > 500 and tb[3] - tb[1] > 150 and tb[2] - tb[0] < 40, f"(0) trang 3 hiển thị 800 x 600 (ngang, đã xoay + CropBox); chữ 'ROTATED SECRET WORD' nằm ở ({tb[0]},{tb[1]})-({tb[2]},{tb[3]}) px: dữ liệu thử đúng")
    r = hz(cls, "redact", src, out, dpi, "0:" + ",".join(f"{v:.5f}" for v in fr0), "2:" + ",".join(f"{v:.5f}" for v in fr2))
    check(r == "2", f"(C1) trả về số trang bị thay bằng ảnh = 2: {r}")
    if r != "2": return
    with pikepdf.open(out) as q:
        check(len(q.pages) == 3, "(C2) số trang giữ nguyên (3)")
        has_font = [("/Font" in (pg.get("/Resources") or {})) for pg in q.pages]
    check(has_font == [False, True, False], f"(A1) trang đã che KHÔNG còn /Font (chỉ ảnh); trang không che giữ nguyên: {has_font}")
    raw = open(out, "rb").read()
    check(b"SECRET" not in raw and b"123456789012" not in raw and b"ROTATED" not in raw, "(A2) TOÀN BỘ byte của tệp ra không chứa 'SECRET', số 12 chữ số, 'ROTATED' (kể cả trong luồng nén / metadata)")
    t0 = sh("pdftotext", "-f", "1", "-l", "1", out, "-").stdout; t1 = sh("pdftotext", "-f", "2", "-l", "2", out, "-").stdout; t2 = sh("pdftotext", "-f", "3", "-l", "3", out, "-").stdout
    check(t0.strip() == "" and t2.strip() == "", f"(A3) pdftotext trang đã che: không có chữ nào ({t0.strip()[:20]!r}, {t2.strip()[:20]!r}) - cả 'ALPHA PUBLIC TEXT' cùng trang cũng thành ảnh (cái giá đã nói trên màn hình)")
    check("PAGE TWO UNTOUCHED" in t1, "(A4) trang không che giữ nguyên chữ chọn được")
    sizes = re.findall(r"Page\s+\d+ size:\s+([\d.]+) x ([\d.]+)", sh("pdfinfo", "-f", "1", "-l", "3", out).stdout)
    check(all(abs(float(a) - DISP[i][0]) < 0.6 and abs(float(b) - DISP[i][1]) < 0.6 for i, (a, b) in enumerate(sizes)) and len(sizes) == 3, f"(C3) khổ trang ra = khổ HIỂN THỊ của gốc (kể cả trang xoay + CropBox): {sizes}")
    for idx, fr in ((0, fr0), (2, fr2)):
        dw, dh = DISP[idx]; W = min(max(int(dw * dpi / 72), 200), 3000); H = int(dh * W / dw)    # as the code does: width from dpi, height follows
        swap = ROT[idx] in (90, 270)
        want = render(src, idx + 1, W, H, swap); px = py_pixelrect(fr, W, H); want[px[1]:px[3], px[0]:px[2]] = 0
        got = render(out, idx + 1, W, H)
        inside = got[px[1] + 2:px[3] - 2, px[0] + 2:px[2] - 2]; mask = np.ones_like(want, dtype=bool); mask[px[1]:px[3], px[0]:px[2]] = False
        outside_diff = float(np.abs(got[mask] - want[mask]).mean())
        check(float(inside.max()) <= 12, f"(B{idx + 1}) hộp đen phủ KÍN cả mép: {px[2] - px[0]} x {px[3] - px[1]} px, điểm sáng nhất trong hộp = {float(inside.max()):.0f}/255 (làm tròn RA NGOÀI; bỏ vành 2 px ngoài cùng vì poppler lấy mẫu lại mép ảnh)")
        check(outside_diff < 2.0, f"(B{idx + 1}) ngoài hộp giống trang gốc dựng cùng cỡ (sai lệch điểm ảnh trung bình {outside_diff:.2f}/255)")
        worst = 0.0
        if idx == 0:
            pw_, ph_, ws = words(src, 1); tgt = [w for w in ws if (w[0].startswith("SECRET-ID") or w[0] == "123456789012")]; sx, sy = W / pw_, H / ph_
            for w_ in tgt:
                reg = got[int(w_[2] * sy):int(math.ceil(w_[4] * sy)), int(w_[1] * sx):int(math.ceil(w_[3] * sx))]; worst = max(worst, float(reg.max()))
        else:
            sx, sy = W / pw2, H / ph2; reg = got[int(tb[1] * sy):int(math.ceil(tb[3] * sy)), int(tb[0] * sx):int(math.ceil(tb[2] * sx))]; worst = float(reg.max())
        check(worst <= 12, f"(B{idx + 1}) vùng chữ nhạy cảm (hộp chữ poppler đo trên bản gốc) ĐEN HOÀN TOÀN trong tệp ra: sáng nhất {worst:.0f}/255")
    # not a PDF / encrypted: refused, nothing left behind
    enc = P("enc.pdf"); pikepdf.open(src).save(enc, encryption=pikepdf.Encryption(user="u", owner="o")); eo = P("enc-out.pdf")
    r = hz(cls, "redact", enc, eo, dpi, "0:0.1,0.1,0.5,0.2"); check(r.startswith("ERR:") and not os.path.exists(eo), "(C4) tệp mã hoá bị từ chối, không để lại tệp: " + r[:60])
    junk = P("junk.pdf"); open(junk, "wb").write(os.urandom(2000)); jo = P("junk-out.pdf"); r = hz(cls, "redact", junk, jo, dpi, "0:0.1,0.1,0.5,0.2")
    check(r.startswith("ERR:") and not os.path.exists(jo), "(C4) không phải PDF: bị từ chối, không để lại tệp: " + r[:60])
    rnd = random.Random(9); bad = []
    for _ in range(500):
        w, h = rnd.randint(1, 3000), rnd.randint(1, 4000); f = [rnd.uniform(-0.3, 1.3) for _ in range(4)] if rnd.random() < .5 else [rnd.choice([0, 1, .5, .25]) for _ in range(4)]
        want = " ".join(str(x) for x in py_pixelrect([clamp01(v) for v in f], w, h)); g = hz(cls, "pixelrect", *[f"{v:.6f}" for v in f], w, h)
        if g != want and rnd.random() < 2: bad.append((f, w, h, g, want))
        if len(bad) > 3: break
    check(not bad, "(C5) pixelRect khớp mô hình viết lại trên 500 hộp ngẫu nhiên (ngoài khung, đảo trái/phải, 1 px)" + ("" if not bad else f": {bad[:2]}"))

def stamp_image(path, w=40, h=20):
    a = np.zeros((h, w, 4), dtype=np.uint8)
    a[:, :w // 2] = (220, 30, 30, 255)           # left half opaque red
    a[:, w // 2:] = (30, 30, 220, 0)             # right half fully transparent blue
    open(path, "wb").write(a.tobytes()); return a

def group_stamp(cls):
    src = make_source(); out = P("stamped.pdf"); raw = P("stamp.rgba"); a = stamp_image(raw); cx, cy, wf = 0.3, 0.8, 0.25
    r = hz(cls, "stamp", src, out, cx, cy, wf, "0,2", raw, 40, 20); check(r == "2", f"(D1) đóng dấu 2 trang: {r}")
    if r != "2": return
    t = [sh("pdftotext", "-f", str(i), "-l", str(i), out, "-").stdout for i in (1, 2, 3)]
    check("SECRET-ID" in t[0] and "PAGE TWO UNTOUCHED" in t[1] and "ROTATED SECRET WORD" in t[2], "(D2) chữ của cả ba trang VẪN chọn được (đóng dấu không dựng ảnh trang)")
    with pikepdf.open(src) as qs, pikepdf.open(out) as qo:
        same = qs.pages[1].Contents.read_bytes() == qo.pages[1].Contents.read_bytes()
    check(same, "(D3) trang không chọn giữ nguyên luồng nội dung từng byte")
    for idx in (0, 2):
        dw, dh = DISP[idx]; W, H = int(dw * 2), int(dh * 2); swap = ROT[idx] in (90, 270)
        base = render(src, idx + 1, W, H, swap); got = render(out, idx + 1, W, H, swap)
        aspect = 40 / 20; w = min(max(wf, 0.04), 0.95) * dw; h = w / aspect
        if h > dh: h = dh; w = h * aspect
        x = min(max(cx * dw - w / 2, 0), dw - w); ytop = min(max(cy * dh - h / 2, 0), dh - h)
        x0, y0, x1, y1 = int(round(x * 2)), int(round(ytop * 2)), int(round((x + w) * 2)), int(round((ytop + h) * 2)); mid = (x0 + x1) // 2
        left = got[y0 + 3:y1 - 3, x0 + 3:mid - 3]; right_got = got[y0 + 3:y1 - 3, mid + 3:x1 - 3]; right_base = base[y0 + 3:y1 - 3, mid + 3:x1 - 3]
        red_gray = 0.299 * 220 + 0.587 * 30 + 0.114 * 30
        check(abs(float(left.mean()) - red_gray) < 8, f"(D4) trang {idx + 1}: nửa ĐỤC của ảnh đúng chỗ ({x0},{y0})-({x1},{y1}): xám trung bình {float(left.mean()):.0f} (đỏ = {red_gray:.0f})")
        check(float(np.abs(right_got - right_base).mean()) < 2, f"(D4) trang {idx + 1}: nửa TRONG SUỐT hiện nền gốc (alpha được tôn trọng): sai lệch {float(np.abs(right_got - right_base).mean()):.2f}")
        mask = np.ones_like(base, dtype=bool); mask[max(0, y0 - 4):y1 + 4, max(0, x0 - 4):x1 + 4] = False
        check(float(np.abs(got[mask] - base[mask]).mean()) < 1.0, f"(D4) trang {idx + 1}: ngoài khung ảnh giống gốc ({float(np.abs(got[mask] - base[mask]).mean()):.2f})")
    rnd = random.Random(4); bad = []
    for _ in range(200):
        cx_, cy_, wf_ = rnd.uniform(-0.2, 1.2), rnd.uniform(-0.2, 1.2), rnd.uniform(0, 1.2); asp = rnd.choice([0.0, 0.5, 2.0, 4.0, 0.2]); dw, dh = rnd.choice([(612, 792), (792, 612), (300, 300)])
        w = min(max(wf_, 0.04), 0.95) * dw; a_ = asp if asp > 0.01 else 1.0; h = w / a_
        if h > dh: h = dh; w = h * a_
        x = min(max(clamp01(cx_) * dw - w / 2, 0), dw - w); yt = min(max(clamp01(cy_) * dh - h / 2, 0), dh - h); want = [x, dh - yt - h, w, h]
        got = [float(v) for v in hz(cls, "rectfor", cx_, cy_, wf_, asp, dw, dh).split(" ")]
        if any(abs(g - e) > 0.01 for g, e in zip(got, want)): bad.append((cx_, cy_, wf_, asp, dw, dh, got, want))
        if len(bad) > 2: break
    check(not bad, "(D5) rectFor khớp mô hình viết lại trên 200 ca (kẹp vào trong, không rộng / cao hơn trang)" + ("" if not bad else f": {bad[:1]}"))

MUTANTS = [
    (1, "PdfRedactor.kt", "val l = floor(minOf(f[0], f[2]).coerceIn(0f, 1f) * w).toInt().coerceIn(0, w - 1)", "val l = ceil(minOf(f[0], f[2]).coerceIn(0f, 1f) * w).toInt().coerceIn(0, w - 1)", "R"),
    (2, "PdfRedactor.kt", "canvas.drawRect(px[0].toFloat(), px[1].toFloat(), px[2].toFloat(), px[3].toFloat(), paint)", "", "R"),
    (3, "PdfRedactor.kt", "val r = ceil(maxOf(f[0], f[2]).coerceIn(0f, 1f) * w).toInt().coerceIn(l + 1, w)", "val r = floor(maxOf(f[0], f[2]).coerceIn(0f, 1f) * w).toInt().coerceIn(l + 1, w)", "R"),
    (4, "PdfStamper.kt", "cs.transform(geo.displayMatrix())", "", "S"),
    (5, "PdfStamper.kt", "val x = (cx - w / 2f).coerceIn(0f, displayWidth - w)", "val x = (cx - w / 2f)", "S"),
    (6, "PdfRedactor.kt", "outDoc.addPage(page)", "outDoc.addPage(page); outDoc.importPage(srcDoc.getPage(i))", "R"),
]
def run_group(cls, g):
    if g == "R": group_redact(cls)
    else: group_stamp(cls)

def main():
    args = sys.argv[1:]; fast = "--fast" in args; only = [int(a.split("=")[1]) for a in args if a.startswith("--mutant=")]
    if not only:
        cls = build(); print("== che thông tin"); group_redact(cls); print("== đóng dấu"); group_stamp(cls)
    if not fast:
        print("== THỬ ÂM TÍNH: mỗi bản mã bị làm hỏng PHẢI bị bắt")
        import contextlib
        for n, fname, old, new, g in MUTANTS:
            if only and n not in only: continue
            before = len(fails); cls = build({fname: (old, new)}, f"m{n}"); buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                try: run_group(cls, g)
                except SystemExit as e: print("LOI harness " + str(e)[:80])
                except Exception as e: print("LOI ngoại lệ " + repr(e)[:80])
            caught = [l for l in buf.getvalue().splitlines() if l.startswith("LOI")]; del fails[before:]
            check(len(caught) > 0, f"bản hỏng {n} ({fname}: {(new.strip() or 'xoá dòng')[:50]!r}) bị bắt bởi {len(caught)} phép kiểm")
    print("\nTAT CA DAT" if not fails else f"\n{len(fails)} LOI: " + "; ".join(fails[:4])); sys.exit(1 if fails else 0)

main()
