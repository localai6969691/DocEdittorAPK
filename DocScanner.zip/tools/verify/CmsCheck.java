// Bản Java song song (chạy được trên máy tính) của app/.../util/DerWriter.kt + CmsSigner.kt (phiên 15).
// Cùng thuật toán, cùng thứ tự các bước; chỉ khác chỗ lấy khoá/chứng thư (tệp thay cho AndroidKeyStore).
// Dùng bởi tools/verify/digital_signature_check.py:  java CmsCheck.java <content.bin> <key.pk8> <cert.der> <out.der> [signingTimeMillis]
import java.io.*;
import java.math.BigInteger;
import java.nio.file.*;
import java.security.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.text.SimpleDateFormat;
import java.util.*;

public class CmsCheck {

    // ---------- DerWriter ----------
    static byte[] concat(byte[]... parts) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        for (byte[] p : parts) o.write(p, 0, p.length);
        return o.toByteArray();
    }

    static byte[] lengthBytes(int n) {
        if (n < 128) return new byte[]{(byte) n};
        int count = 0;
        for (int v = n; v > 0; v >>>= 8) count++;
        byte[] out = new byte[1 + count];
        out[0] = (byte) (0x80 | count);
        for (int i = 0; i < count; i++) out[1 + i] = (byte) (n >>> (8 * (count - 1 - i)));
        return out;
    }

    static byte[] tlv(int tag, byte[] content) { return concat(new byte[]{(byte) tag}, lengthBytes(content.length), content); }
    static byte[] sequence(byte[]... parts) { return tlv(0x30, concat(parts)); }
    static byte[] setOf(byte[]... parts) { return tlv(0x31, concat(sortedForSet(parts))); }
    static byte[] nullValue() { return new byte[]{0x05, 0x00}; }
    static byte[] octetString(byte[] b) { return tlv(0x04, b); }
    static byte[] integer(BigInteger v) { return tlv(0x02, v.toByteArray()); }

    static byte[] oid(String dotted) {
        String[] parts = dotted.split("\\.");
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        o.write(Integer.parseInt(parts[0]) * 40 + Integer.parseInt(parts[1]));
        for (int i = 2; i < parts.length; i++) {
            long v = Long.parseLong(parts[i]);
            int groups = 1;
            for (long t = v >>> 7; t > 0; t >>>= 7) groups++;
            for (int g = groups - 1; g >= 0; g--) {
                int b = (int) ((v >>> (7 * g)) & 0x7F);
                o.write(g > 0 ? (b | 0x80) : b);
            }
        }
        return tlv(0x06, o.toByteArray());
    }

    static byte[] utcTime(long millis) {
        SimpleDateFormat f = new SimpleDateFormat("yyMMddHHmmss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return tlv(0x17, f.format(new Date(millis)).getBytes());
    }

    /** DER SET OF: components sorted ascending as octet strings, the shorter padded with trailing zeros (X.690 11.6). */
    static byte[][] sortedForSet(byte[][] parts) {
        byte[][] copy = parts.clone();
        Arrays.sort(copy, (a, b) -> {
            int n = Math.max(a.length, b.length);
            for (int i = 0; i < n; i++) {
                int x = i < a.length ? (a[i] & 0xFF) : 0;
                int y = i < b.length ? (b[i] & 0xFF) : 0;
                if (x != y) return Integer.compare(x, y);
            }
            return 0;
        });
        return copy;
    }

    // ---------- DerReader (chỉ đủ để lấy issuer và serial nguyên bản từ chứng thư) ----------
    /** @return {tag, headerLength, contentLength} of the element starting at offset. */
    static int[] header(byte[] d, int off) {
        int tag = d[off] & 0xFF;
        int first = d[off + 1] & 0xFF;
        if (first < 128) return new int[]{tag, 2, first};
        int count = first & 0x7F, len = 0;
        for (int i = 0; i < count; i++) len = (len << 8) | (d[off + 2 + i] & 0xFF);
        return new int[]{tag, 2 + count, len};
    }

    /** {serialTlv, issuerTlv} copied byte-for-byte from the TBSCertificate. */
    static byte[][] serialAndIssuer(byte[] cert) {
        int[] outer = header(cert, 0);                 // Certificate ::= SEQUENCE
        int tbsOff = outer[1];
        int[] tbs = header(cert, tbsOff);              // TBSCertificate ::= SEQUENCE
        int p = tbsOff + tbs[1];
        if ((cert[p] & 0xFF) == 0xA0) { int[] v = header(cert, p); p += v[1] + v[2]; }   // [0] version (v3)
        int[] ser = header(cert, p);
        byte[] serial = Arrays.copyOfRange(cert, p, p + ser[1] + ser[2]);
        p += ser[1] + ser[2];
        int[] alg = header(cert, p);                   // signature AlgorithmIdentifier
        p += alg[1] + alg[2];
        int[] iss = header(cert, p);
        byte[] issuer = Arrays.copyOfRange(cert, p, p + iss[1] + iss[2]);
        return new byte[][]{serial, issuer};
    }

    // ---------- CmsSigner ----------
    static final String OID_SIGNED_DATA = "1.2.840.113549.1.7.2";
    static final String OID_DATA = "1.2.840.113549.1.7.1";
    static final String OID_CONTENT_TYPE = "1.2.840.113549.1.9.3";
    static final String OID_MESSAGE_DIGEST = "1.2.840.113549.1.9.4";
    static final String OID_SIGNING_TIME = "1.2.840.113549.1.9.5";
    static final String OID_SHA256 = "2.16.840.1.101.3.4.2.1";
    static final String OID_SHA256_RSA = "1.2.840.113549.1.1.11";
    static final String OID_ECDSA_SHA256 = "1.2.840.10045.4.3.2";

    interface RawSigner { byte[] sign(byte[] data) throws Exception; }

    static byte[] algorithm(String oid) { return sequence(oid(oid), nullValue()); }

    static byte[] attribute(String oid, byte[] value) { return sequence(oid(oid), setOf(value)); }

    static final String OID_TS_TOKEN = "1.2.840.113549.1.9.16.2.14";

    static byte[] buildDetached(byte[] contentDigest, byte[] certDer, RawSigner signer, long signingTimeMillis) throws Exception { return buildDetached(contentDigest, certDer, signer, signingTimeMillis, null, new java.util.ArrayList<>(), false); }

    static byte[] buildDetached(byte[] contentDigest, byte[] certDer, RawSigner signer, long signingTimeMillis, byte[] token) throws Exception { return buildDetached(contentDigest, certDer, signer, signingTimeMillis, token, new java.util.ArrayList<>(), false); }

    /** [token] = RFC 3161 TimeStampToken (DER) -> unsignedAttrs [1] IMPLICIT (phiên 20, mirror of CmsSigner.buildDetached(timestamper)). */
    /** chainDer = the OTHER certificates to embed after the signer's own; ecdsa = ECDSA over SHA-256 (algorithm identifier WITHOUT parameters, RFC 5758). Mirror of CmsSigner.buildDetached (phiên 22, 4.49.8). */
    static byte[] buildDetached(byte[] contentDigest, byte[] certDer, RawSigner signer, long signingTimeMillis, byte[] token, java.util.List<byte[]> chainDer, boolean ecdsa) throws Exception {
        byte[][] sa = serialAndIssuer(certDer);
        byte[][] attrs = sortedForSet(new byte[][]{
                attribute(OID_CONTENT_TYPE, oid(OID_DATA)),
                attribute(OID_SIGNING_TIME, utcTime(signingTimeMillis)),
                attribute(OID_MESSAGE_DIGEST, octetString(contentDigest))});
        byte[] attrsContent = concat(attrs);
        byte[] toSign = tlv(0x31, attrsContent);                    // the signature covers the attributes tagged as a plain SET
        byte[] signature = signer.sign(toSign);
        java.util.List<byte[]> parts = new java.util.ArrayList<>(java.util.Arrays.asList(
                integer(BigInteger.ONE),
                sequence(sa[1], sa[0]),                              // IssuerAndSerialNumber
                algorithm(OID_SHA256),
                tlv(0xA0, attrsContent),                             // ...but is stored as [0] IMPLICIT
                ecdsa ? sequence(oid(OID_ECDSA_SHA256)) : algorithm(OID_SHA256_RSA),
                octetString(signature)));
        if (token != null) parts.add(tlv(0xA1, attribute(OID_TS_TOKEN, token)));   // unsignedAttrs [1] IMPLICIT
        byte[] signerInfo = sequence(parts.toArray(new byte[0][]));
        byte[] signedData = sequence(
                integer(BigInteger.ONE),
                setOf(algorithm(OID_SHA256)),
                sequence(oid(OID_DATA)),                             // detached: no content inside
                tlv(0xA0, concat(certDer, concat(chainDer.toArray(new byte[0][])))),
                setOf(signerInfo));
        return sequence(oid(OID_SIGNED_DATA), tlv(0xA0, signedData));
    }

    public static void main(String[] args) throws Exception {
        byte[] content = Files.readAllBytes(Paths.get(args[0]));
        String alg = args.length > 6 ? args[6] : "RSA";
        boolean ecdsa = alg.equals("EC");
        PrivateKey key = KeyFactory.getInstance(alg).generatePrivate(new PKCS8EncodedKeySpec(Files.readAllBytes(Paths.get(args[1]))));
        byte[] cert = Files.readAllBytes(Paths.get(args[2]));
        long when = args.length > 4 ? Long.parseLong(args[4]) : System.currentTimeMillis();
        byte[] token = args.length > 5 && !args[5].equals("-") ? Files.readAllBytes(Paths.get(args[5])) : null;
        java.util.List<byte[]> chain = new java.util.ArrayList<>();
        for (int i = 7; i < args.length; i++) { byte[] extra = Files.readAllBytes(Paths.get(args[i])); if (!Arrays.equals(extra, cert)) chain.add(extra); }
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(content);
        byte[] cms = buildDetached(digest, cert, data -> {
            Signature s = Signature.getInstance(ecdsa ? "SHA256withECDSA" : "SHA256withRSA");
            s.initSign(key);
            s.update(data);
            return s.sign();
        }, when, token, chain, ecdsa);
        Files.write(Paths.get(args[3]), cms);
        System.out.println("CMS " + cms.length + " bytes");
    }
}
