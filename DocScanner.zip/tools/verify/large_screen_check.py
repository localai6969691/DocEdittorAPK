"""Kiểm chứng LargeScreen (phiên 17): bố cục máy tính bảng / ngang.

(1) Hàm thuần `contentWidthDp`: bản Python so với hằng số đọc TRỰC TIẾP từ LargeScreen.kt (không chép tay): <= 640 dp không làm gì, rộng hơn thì cột 640 dp.
(2) Mọi tên trong FULL_WIDTH_SCREENS phải là một Activity có thật (lớp `: AppCompatActivity`) VÀ có trong AndroidManifest - gõ sai tên thì danh sách loại trừ
    im lặng không loại trừ gì và camera bị kéo hẹp. THỬ ÂM TÍNH: bản sao danh sách có một tên gõ sai phải bị bắt.
(3) Mọi màn hình khai trong manifest mà bố cục chính là camera / ảnh trang (tên chứa Capture/Crop/Barcode) phải nằm trong danh sách.
Chạy: python3 large_screen_check.py
"""
import os, re, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..")
MAIN = os.path.join(ROOT, "app", "src", "main")
KT = os.path.join(MAIN, "java", "com", "example", "docscanner")
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
src = open(os.path.join(KT, "util", "LargeScreen.kt"), encoding="utf-8").read()
MAX = int(re.search(r"const val MAX_CONTENT_DP = (\d+)", src).group(1))
names = re.findall(r'"([A-Za-z]+Activity)"', re.search(r"FULL_WIDTH_SCREENS = setOf\((.*?)\)", src, re.S).group(1))
def width(w): return MAX if w > MAX else None
check(MAX == 640, f"cột nội dung rộng tối đa {MAX} dp")
check([width(w) for w in (360, 411, 600, 640, 641, 800, 1280)] == [None, None, None, None, 640, 640, 640], "điện thoại và máy tính bảng nhỏ không đổi; từ 641 dp trở lên cột 640 dp")
manifest = open(os.path.join(MAIN, "AndroidManifest.xml"), encoding="utf-8").read()
declared = set(re.findall(r'android:name="\.(\w+Activity)"', manifest))
classes = set()
for dp, _, fs in os.walk(KT):
    for f in fs:
        if f.endswith(".kt"):
            classes |= set(re.findall(r"class (\w+Activity)\s*:\s*(?:AppCompatActivity|BaseActivity)", open(os.path.join(dp, f), encoding="utf-8").read()))
missing = [n for n in names if n not in classes or n not in declared]
check(not missing and len(names) >= 8, f"{len(names)} tên loại trừ đều là Activity có thật và có trong manifest {missing}")
bad = names[:-1] + [names[-1] + "X"]
check([n for n in bad if n not in classes], "thử âm tính: tên gõ sai bị bắt")
must = [d for d in declared if re.search(r"Capture|Crop|Barcode", d)]
check(all(m in names for m in must), f"các màn camera/cắt ({sorted(must)}) đều nằm trong danh sách loại trừ")
print()
print("TAT CA DAT" if not FAILS else f"CO {len(FAILS)} LOI")
sys.exit(1 if FAILS else 0)
