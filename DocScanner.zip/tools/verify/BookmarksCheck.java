// Bản Java chạy được của PdfBookmarks (phần lập kế hoạch thuần, phiên 17): cùng logic, cùng thứ tự với app/.../util/PdfBookmarks.kt.
// Dùng bởi bookmarks_check.py.  java BookmarksCheck.java <tệp ca> <tệp ra>
// Ca ngăn bằng "---". Dòng đầu: "N" (chuẩn hoá mức) | "X\t<số trang>" (mức sâu nhất) | "S\t<số trang>\t<mức>\t<lời mở 0|1>\t<tên lời mở hex>" (các chương)
//   | "P\t<mức>\t<đầu>\t<cuối>" (mục lục của một phần) | "M" (ghép: các dòng "F\t<tên hex>\t<số trang>" mở một tệp, rồi các dòng "E" của tệp đó).
//   | "U|W|T|O\t<chỉ số>" (lên / xuống / thụt vào / đưa ra ngoài, phiên 19) | "D\t<chỉ số>" (xoá kèm con) | "R\t<chỉ số>\t<tên hex>" (đổi tên) | "I\t<tên hex>\t<trang>\t<mức>\t<số trang>" (thêm).
// Dòng mục lục: "E\t<tên hex>\t<mức>\t<trang>". Ra mỗi ca một dòng.
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class BookmarksCheck {
    static class E { String t; int level, page; E(String t, int l, int p) { this.t = t; level = l; page = p; } }
    static String hex(String s) { StringBuilder b = new StringBuilder(); for (byte x : s.getBytes(StandardCharsets.UTF_8)) b.append(String.format("%02x", x & 0xff)); return b.toString(); }
    static String unhex(String h) { byte[] b = new byte[h.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return new String(b, StandardCharsets.UTF_8); }

    static List<E> normalize(List<E> in) {
        List<E> out = new ArrayList<>(); int prev = 0;
        for (E e : in) { int level = Math.min(Math.max(e.level, 1), prev + 1); out.add(new E(e.t, level, e.page)); prev = level; }
        return out;
    }
    static List<E> delete(List<E> in, int index) {
        List<E> n = normalize(in); if (index < 0 || index >= n.size()) return n;
        int end = index + 1; while (end < n.size() && n.get(end).level > n.get(index).level) end++;
        List<E> r = new ArrayList<>(n.subList(0, index)); r.addAll(n.subList(end, n.size())); return normalize(r);
    }
    static List<E> rename(List<E> in, int index, String title) {
        List<E> n = normalize(in); String t = title.trim(); if (index < 0 || index >= n.size() || t.isEmpty()) return n;
        List<E> r = new ArrayList<>(); for (int i = 0; i < n.size(); i++) r.add(i == index ? new E(t, n.get(i).level, n.get(i).page) : n.get(i)); return r;
    }
    static List<E> insert(List<E> in, String title, int page, int level, int pageCount) {
        List<E> n = normalize(in); String t = title.trim(); if (t.isEmpty() || page < 0 || page >= pageCount) return n;
        int at = 0; for (int i = 0; i < n.size(); i++) if (n.get(i).page <= page) at = i + 1;
        List<E> r = new ArrayList<>(n.subList(0, at)); r.add(new E(t, Math.max(level, 1), page)); r.addAll(n.subList(at, n.size())); return normalize(r);
    }
    static int blockEnd(List<E> n, int index) { int end = index + 1; while (end < n.size() && n.get(end).level > n.get(index).level) end++; return end; }
    static boolean canMoveUp(List<E> in, int index) { List<E> n = normalize(in); if (index < 0 || index >= n.size()) return false; int level = n.get(index).level, j = index - 1; while (j >= 0 && n.get(j).level > level) j--; return j >= 0 && n.get(j).level == level; }
    static boolean canMoveDown(List<E> in, int index) { List<E> n = normalize(in); if (index < 0 || index >= n.size()) return false; int end = blockEnd(n, index); return end < n.size() && n.get(end).level == n.get(index).level; }
    static List<E> moveUp(List<E> in, int index) {
        List<E> n = normalize(in); if (index < 0 || index >= n.size()) return n;
        int level = n.get(index).level, j = index - 1; while (j >= 0 && n.get(j).level > level) j--;
        if (j < 0 || n.get(j).level != level) return n;
        int end = blockEnd(n, index);
        List<E> r = new ArrayList<>(n.subList(0, j)); r.addAll(n.subList(index, end)); r.addAll(n.subList(j, index)); r.addAll(n.subList(end, n.size())); return normalize(r);
    }
    static List<E> moveDown(List<E> in, int index) {
        List<E> n = normalize(in); if (index < 0 || index >= n.size()) return n;
        int end = blockEnd(n, index); if (end >= n.size() || n.get(end).level != n.get(index).level) return n;
        int nextEnd = blockEnd(n, end);
        List<E> r = new ArrayList<>(n.subList(0, index)); r.addAll(n.subList(end, nextEnd)); r.addAll(n.subList(index, end)); r.addAll(n.subList(nextEnd, n.size())); return normalize(r);
    }
    static boolean canIndent(List<E> in, int index) { List<E> n = normalize(in); return index >= 1 && index < n.size() && n.get(index - 1).level >= n.get(index).level; }
    static boolean canOutdent(List<E> in, int index) { List<E> n = normalize(in); return index >= 0 && index < n.size() && n.get(index).level > 1; }
    static List<E> shift(List<E> in, int index, int delta) {
        List<E> n = normalize(in); int end = blockEnd(n, index); List<E> r = new ArrayList<>();
        for (int i = 0; i < n.size(); i++) r.add(i >= index && i < end ? new E(n.get(i).t, n.get(i).level + delta, n.get(i).page) : n.get(i));
        return normalize(r);
    }
    static List<E> indent(List<E> in, int index) { return canIndent(in, index) ? shift(in, index, 1) : normalize(in); }
    static List<E> outdent(List<E> in, int index) { return canOutdent(in, index) ? shift(in, index, -1) : normalize(in); }
    static int maxLevel(List<E> in, int pages) { int m = 0; for (E e : normalize(in)) if (e.page >= 0 && e.page < pages) m = Math.max(m, e.level); return m; }
    static List<int[]> sections(List<E> in, int pages, int level, boolean preface, String prefaceTitle, List<String> titles) {
        List<E> starts = new ArrayList<>(); List<Integer> order = new ArrayList<>(); List<E> norm = normalize(in);
        for (int i = 0; i < norm.size(); i++) { E e = norm.get(i); if (e.level == level && e.page >= 0 && e.page < pages) { starts.add(e); order.add(i); } }
        Integer[] idx = new Integer[starts.size()]; for (int i = 0; i < idx.length; i++) idx[i] = i;
        Arrays.sort(idx, (a, b) -> starts.get(a).page != starts.get(b).page ? Integer.compare(starts.get(a).page, starts.get(b).page) : Integer.compare(order.get(a), order.get(b)));
        List<E> distinct = new ArrayList<>();
        for (int i : idx) { E e = starts.get(i); if (distinct.isEmpty() || distinct.get(distinct.size() - 1).page != e.page) distinct.add(e); }
        List<int[]> out = new ArrayList<>();
        if (distinct.isEmpty()) return out;
        if (preface && distinct.get(0).page > 0) { out.add(new int[]{0, distinct.get(0).page - 1}); titles.add(prefaceTitle); }
        for (int i = 0; i < distinct.size(); i++) { out.add(new int[]{distinct.get(i).page, i + 1 < distinct.size() ? distinct.get(i + 1).page - 1 : pages - 1}); titles.add(distinct.get(i).t); }
        return out;
    }
    @SuppressWarnings("unchecked")
    public static void main(String[] a) throws Exception {
        List<String> lines = new ArrayList<>(Files.readAllLines(Paths.get(a[0]), StandardCharsets.UTF_8)); lines.add("---");
        StringBuilder res = new StringBuilder(); List<String> block = new ArrayList<>();
        for (String ln : lines) {
            if (!ln.equals("---")) { block.add(ln); continue; }
            if (block.isEmpty()) continue;
            String[] h = block.get(0).split("\t", -1); List<E> es = new ArrayList<>(); List<Object[]> files = new ArrayList<>();
            for (int i = 1; i < block.size(); i++) {
                String[] p = block.get(i).split("\t", -1);
                if (p[0].equals("E")) { E e = new E(unhex(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3])); if (h[0].equals("M") && !files.isEmpty()) ((List<E>) files.get(files.size() - 1)[2]).add(e); else es.add(e); }
                else if (p[0].equals("F")) files.add(new Object[]{unhex(p[1]), Integer.parseInt(p[2]), new ArrayList<E>()});
            }
            StringBuilder o = new StringBuilder();
            switch (h[0]) {
                case "N": for (E e : normalize(es)) o.append(hex(e.t)).append(" ").append(e.level).append(" ").append(e.page).append(";"); break;
                case "D": for (E e : delete(es, Integer.parseInt(h[1]))) o.append(hex(e.t)).append(" ").append(e.level).append(" ").append(e.page).append(";"); break;
                case "R": for (E e : rename(es, Integer.parseInt(h[1]), unhex(h[2]))) o.append(hex(e.t)).append(" ").append(e.level).append(" ").append(e.page).append(";"); break;
                case "I": for (E e : insert(es, unhex(h[1]), Integer.parseInt(h[2]), Integer.parseInt(h[3]), Integer.parseInt(h[4]))) o.append(hex(e.t)).append(" ").append(e.level).append(" ").append(e.page).append(";"); break;
                case "U": for (E e : moveUp(es, Integer.parseInt(h[1]))) o.append(hex(e.t)).append(" ").append(e.level).append(" ").append(e.page).append(";"); break;
                case "W": for (E e : moveDown(es, Integer.parseInt(h[1]))) o.append(hex(e.t)).append(" ").append(e.level).append(" ").append(e.page).append(";"); break;
                case "T": for (E e : indent(es, Integer.parseInt(h[1]))) o.append(hex(e.t)).append(" ").append(e.level).append(" ").append(e.page).append(";"); break;
                case "O": for (E e : outdent(es, Integer.parseInt(h[1]))) o.append(hex(e.t)).append(" ").append(e.level).append(" ").append(e.page).append(";"); break;
                case "u": o.append(canMoveUp(es, Integer.parseInt(h[1])) ? 1 : 0).append(canMoveDown(es, Integer.parseInt(h[1])) ? 1 : 0).append(canIndent(es, Integer.parseInt(h[1])) ? 1 : 0).append(canOutdent(es, Integer.parseInt(h[1])) ? 1 : 0); break;
                case "X": o.append(maxLevel(es, Integer.parseInt(h[1]))); break;
                case "S": { List<String> titles = new ArrayList<>(); List<int[]> s = sections(es, Integer.parseInt(h[1]), Integer.parseInt(h[2]), h[3].equals("1"), unhex(h[4]), titles); for (int i = 0; i < s.size(); i++) o.append(hex(titles.get(i))).append(" ").append(s.get(i)[0]).append(" ").append(s.get(i)[1]).append(";"); break; }
                case "P": { int level = Integer.parseInt(h[1]), first = Integer.parseInt(h[2]), last = Integer.parseInt(h[3]); for (E e : normalize(es)) if (e.page >= first && e.page <= last && e.level >= level) o.append(hex(e.t)).append(" ").append(e.level - level + 1).append(" ").append(e.page - first).append(";"); break; }
                case "M": { int offset = 0; for (Object[] f : files) { int pc = (Integer) f[1]; if (pc > 0) { o.append(hex((String) f[0])).append(" 1 ").append(offset).append(";"); for (E e : normalize((List<E>) f[2])) if (e.page >= 0 && e.page < pc) o.append(hex(e.t)).append(" ").append(e.level + 1).append(" ").append(e.page + offset).append(";"); } offset += pc; } break; }
            }
            res.append(o).append("\n"); block.clear();
        }
        Files.write(Paths.get(a[1]), res.toString().getBytes(StandardCharsets.UTF_8));
    }
}
