"""Kiểm chứng PdfStructureTools (phiên 18): tệp đính kèm, lớp hiển thị (OCG), liên kết trong PDF.

PdfStructureTools.kt gọi PdfBox, KHÔNG chạy được ở đây. Bài kiểm này dựng LẠI bằng pikepdf đúng cấu trúc mà từng hàm Kotlin tạo ra (mỗi hàm Python
`mirror_*` ghi rõ nó phản chiếu hàm Kotlin nào, từng bước một) rồi kiểm KẾT QUẢ bằng công cụ độc lập, không tin chính bản dựng lại:
A - đính kèm: poppler `pdfdetach` (liệt kê + trích từng byte), pypdf (`attachments`), `qpdf --check`; tên Việt / trùng tên / không đuôi / nhiều dấu chấm; cây có `Kids`
    được làm phẳng đúng; xoá hết thì gỡ hẳn mục `/EmbeddedFiles`; bất biến của cây tên (khoá SẮP XẾP) có THỬ ÂM TÍNH.
B - lớp OCG: VẼ TRANG bằng poppler rồi đo màu điểm ảnh - 3 cấu hình ban đầu (BaseState ON / BaseState OFF + mảng ON / chỉ mảng OFF) x 8 tổ hợp bật tắt = 24 ca,
    và danh sách trạng thái đọc ra khớp với cái poppler vẽ (tức cách hiểu ON / OFF / BaseState đúng như trình xem thật). Ca lớp nằm ở CẢ HAI mảng.
C - liên kết: pypdf; phân loại web / nhảy trang (đích rõ, /Dest trực tiếp, tên cũ /Dests, tên mới /Names /Dests) / khác (Launch) khớp bảng chân trị viết tay;
    xoá liên kết web / mọi liên kết chỉ đụng liên kết, chú thích khác (Text, Highlight) còn nguyên.
GIỚI HẠN (nói thẳng): chứng minh cấu trúc đúng và có hiệu lực, KHÔNG chứng minh các lời gọi API PdfBox trong Kotlin biên dịch và chạy đúng - việc đó chỉ lộ ở CI / máy thật.
Chạy: python3 pdf_structure_check.py   (cần pikepdf, pypdf, Pillow, poppler-utils, qpdf)
"""
import itertools, os, random, shutil, subprocess, sys, tempfile
import pikepdf
from pikepdf import Array, Dictionary, Name, String
from PIL import Image
import pypdf
FAILS = []
def check(c, w):
    print(("ok  " if c else "LOI"), w)
    if not c: FAILS.append(w)
tmp = tempfile.mkdtemp(prefix="pdfstruct_"); P = lambda n: os.path.join(tmp, n)
def run(*a): return subprocess.run(list(a), capture_output=True, text=True)
def qpdf_ok(path):
    r = run("qpdf", "--check", path); return r.returncode in (0, 3) and "No syntax or stream encoding errors" in (r.stdout + r.stderr), r.stdout + r.stderr
def blank(n_pages=1, size=(300, 100)):
    pdf = pikepdf.Pdf.new()
    for _ in range(n_pages): pdf.add_blank_page(page_size=size)
    return pdf

# =============================================================== A. tệp đính kèm
def sorted_invariant(path):
    p = pikepdf.open(path); arr = p.Root.Names.EmbeddedFiles.Names; ks = [bytes(arr[i]) for i in range(0, len(arr), 2)]; p.close(); return ks == sorted(ks)
def embedded_map(pdf):
    """Phản chiếu PdfStructureTools.embeddedMap / collectEmbedded: đi hết cây tên (Names và Kids)."""
    out = {}
    names = pdf.Root.get("/Names")
    if names is None or "/EmbeddedFiles" not in names: return out
    def walk(node):
        if "/Names" in node:
            arr = node.Names
            for i in range(0, len(arr), 2): out[str(arr[i])] = arr[i + 1]
        if "/Kids" in node:
            for k in node.Kids: walk(k)
    walk(names.EmbeddedFiles); return out
def store_embedded(pdf, m):
    """Phản chiếu storeEmbedded: cây PHẲNG, khoá sắp xếp; rỗng thì gỡ hẳn /EmbeddedFiles."""
    if "/Names" not in pdf.Root: pdf.Root.Names = pdf.make_indirect(Dictionary())
    if not m:
        if "/EmbeddedFiles" in pdf.Root.Names: del pdf.Root.Names["/EmbeddedFiles"]
        return
    arr = Array()
    for k in sorted(m, key=lambda x: bytes(String(x))):     # theo BYTE THÔ của chuỗi đã mã hoá (ISO 32000 mục 7.9.6), không theo chuỗi Python/Java
        arr.append(String(k)); arr.append(m[k])
    pdf.Root.Names.EmbeddedFiles = Dictionary(Names=arr)
def with_suffix(name, k):
    dot = name.rfind(".")
    return f"{name} ({k})" if dot <= 0 else name[:dot] + f" ({k})" + name[dot:]
def mirror_add(pdf, name, data, mime, desc):
    """Phản chiếu PdfStructureTools.addAttachment."""
    m = embedded_map(pdf); final = name; k = 2
    while final in m: final = with_suffix(name, k); k += 1
    ef = pdf.make_stream(data); ef.Type = Name.EmbeddedFile
    ef.Subtype = Name("/" + (mime if mime and mime.strip() else "application/octet-stream"))
    ef.Params = Dictionary(Size=len(data), CreationDate=String("D:20261017000000Z"), ModDate=String("D:20261017000000Z"))
    fs = Dictionary(Type=Name.Filespec, F=String(final), UF=String(final), EF=Dictionary(F=ef, UF=ef))
    if desc.strip(): fs.Desc = String(desc.strip())
    m[final] = pdf.make_indirect(fs); store_embedded(pdf, m); return final
def mirror_remove(pdf, names):
    m = embedded_map(pdf); n = sum(1 for x in names if m.pop(x, None) is not None); store_embedded(pdf, m); return n

print("== A. tệp đính kèm ==")
rnd = random.Random(2026)
FILES = [("báo cáo.txt", ("Nội dung tiếng Việt\n" * 500).encode(), "text/plain"), ("Hợp đồng ký.pdf", rnd.randbytes(70_000), "application/pdf"), ("rong.bin", b"", None),
         ("khong_duoi", b"x" * 10, "application/octet-stream"), ("archive.tar.gz", rnd.randbytes(5000), "application/gzip"), ("a.txt", b"first", "text/plain")]
pdf = blank(2)
for n, d, mt in FILES: mirror_add(pdf, n, d, mt, "mô tả " + n)
used = [mirror_add(pdf, "a.txt", b"second", "text/plain", ""), mirror_add(pdf, "a.txt", b"third", "text/plain", ""), mirror_add(pdf, "khong_duoi", b"y", None, ""), mirror_add(pdf, "archive.tar.gz", b"z", None, "")]
check(used == ["a (2).txt", "a (3).txt", "khong_duoi (2)", "archive.tar (2).gz"], f"trùng tên: {used}")
pdf.save(P("att.pdf")); pdf.close()
ok, msg = qpdf_ok(P("att.pdf")); check(ok, "qpdf --check đạt sau khi thêm 10 tệp đính kèm")
listing = run("pdfdetach", "-list", P("att.pdf")).stdout.splitlines()
expected = dict((n, d) for n, d, _ in FILES); expected.update({"a (2).txt": b"second", "a (3).txt": b"third", "khong_duoi (2)": b"y", "archive.tar (2).gz": b"z"})
check(listing[0].startswith(f"{len(expected)} embedded files"), f"pdfdetach đếm đúng {len(expected)} tệp: {listing[0]}")
got_names = [l.split(": ", 1)[1] for l in listing[1:]]
check(sorted(got_names) == sorted(expected), "pdfdetach liệt kê đúng tên (kể cả tên tiếng Việt)")
check(sorted_invariant(P("att.pdf")), "khoá trong cây tên sắp theo BYTE THÔ (đúng đặc tả; tên ASCII lẫn tên tiếng Việt)")
good = True
for i, nm in enumerate(got_names, 1):
    out = P(f"x{i}.bin"); run("pdfdetach", "-save", str(i), "-o", out, P("att.pdf"))
    if not os.path.exists(out) or open(out, "rb").read() != expected[nm]: good = False; print("  khác:", nm)
check(good, "pdfdetach trích từng tệp: khớp TỪNG BYTE với dữ liệu đưa vào (kể cả tệp rỗng và tệp 70 KB không nén được)")
rd = pypdf.PdfReader(P("att.pdf")); pa = {k: v[0] for k, v in rd.attachments.items()}
check(pa == expected, "pypdf (đọc độc lập) thấy cùng tên và cùng nội dung")
# xoá
pdf = pikepdf.open(P("att.pdf")); n = mirror_remove(pdf, {"a.txt", "báo cáo.txt", "khong_co.txt"}); pdf.save(P("att2.pdf")); pdf.close()
check(n == 2, "xoá: đếm 2 tệp đã xoá (tên không có thì bỏ qua)")
left = [l.split(": ", 1)[1] for l in run("pdfdetach", "-list", P("att2.pdf")).stdout.splitlines()[1:]]
check(sorted(left) == sorted(set(expected) - {"a.txt", "báo cáo.txt"}) and qpdf_ok(P("att2.pdf"))[0], "sau khi xoá còn đúng các tệp còn lại; qpdf đạt")
pdf = pikepdf.open(P("att2.pdf")); mirror_remove(pdf, set(embedded_map(pdf))); pdf.save(P("att3.pdf")); pdf.close()
rt = pikepdf.open(P("att3.pdf"))
check("/EmbeddedFiles" not in rt.Root.Names and run("pdfdetach", "-list", P("att3.pdf")).stdout.startswith("0 embedded files") and qpdf_ok(P("att3.pdf"))[0], "xoá hết: mục /EmbeddedFiles bị gỡ, pdfdetach báo 0 tệp"); rt.close()
# cây có Kids
pdf = blank(1)
def fs_of(name, data):
    ef = pdf.make_stream(data); ef.Type = Name.EmbeddedFile
    return pdf.make_indirect(Dictionary(Type=Name.Filespec, F=String(name), UF=String(name), EF=Dictionary(F=ef)))
k1 = pdf.make_indirect(Dictionary(Limits=Array([String("a1"), String("b2")]), Names=Array([String("a1"), fs_of("a1", b"AAA"), String("b2"), fs_of("b2", b"BBB")])))
k2 = pdf.make_indirect(Dictionary(Limits=Array([String("c3"), String("d4")]), Names=Array([String("c3"), fs_of("c3", b"CCC"), String("d4"), fs_of("d4", b"DDD")])))
pdf.Root.Names = Dictionary(EmbeddedFiles=Dictionary(Kids=Array([k1, k2])))
seen = sorted(embedded_map(pdf)); check(seen == ["a1", "b2", "c3", "d4"], f"cây có Kids: đọc đủ 4 tệp từ hai nút con {seen}")
mirror_remove(pdf, {"b2"}); mirror_add(pdf, "e5", b"EEE", "text/plain", ""); pdf.save(P("kids.pdf")); pdf.close()
l = [x.split(": ", 1)[1] for x in run("pdfdetach", "-list", P("kids.pdf")).stdout.splitlines()[1:]]
check(l == ["a1", "c3", "d4", "e5"] and qpdf_ok(P("kids.pdf"))[0], f"làm phẳng cây Kids + xoá + thêm: {l}")
# bất biến + thử âm tính
check(sorted_invariant(P("att.pdf")) and sorted_invariant(P("kids.pdf")) and sorted_invariant(P("att2.pdf")), "bất biến: khoá trong cây tên sắp theo byte thô sau thêm / xoá / làm phẳng Kids")
pdf = blank(1); arr = Array([String("z"), fs_of("z", b"1"), String("a"), fs_of("a", b"2")]); pdf.Root.Names = Dictionary(EmbeddedFiles=Dictionary(Names=arr)); pdf.save(P("unsorted.pdf")); pdf.close()
check(not sorted_invariant(P("unsorted.pdf")), "thử âm tính: bộ kiểm bất biến bắt được cây tên KHÔNG sắp xếp (nếu quên sắp xếp)")
# thử âm tính thứ hai - đúng lỗi của setNames: sắp theo chuỗi (Java/Python) khi trộn ASCII và tiếng Việt
pdf = blank(1); ks = sorted(["Hợp đồng ký.pdf", "a.txt", "báo cáo.txt", "rong.bin"])      # thứ tự theo chuỗi
arr = Array()
for k in ks: arr.append(String(k)); arr.append(fs_of(k, b"1"))
pdf.Root.Names = Dictionary(EmbeddedFiles=Dictionary(Names=arr)); pdf.save(P("strsorted.pdf")); pdf.close()
check(not sorted_invariant(P("strsorted.pdf")), "thử âm tính: sắp theo CHUỖI (như PdfBox setNames) vi phạm thứ tự byte thô khi trộn ASCII và tiếng Việt - bộ kiểm bắt được")

# =============================================================== B. lớp OCG
RED, GREEN, BLUE = (255, 0, 0), (0, 255, 0), (0, 0, 255)
COLORS = [RED, GREEN, BLUE]; CENTERS = [(50, 50), (150, 50), (250, 50)]; BLACK_PX = (160, 95)
def layered_pdf(base_state, on_idx, off_idx):
    pdf = blank(1); page = pdf.pages[0]
    ocgs = [pdf.make_indirect(Dictionary(Type=Name.OCG, Name=String(f"Lớp {i+1}"))) for i in range(3)]
    page.Resources = Dictionary(Properties=Dictionary(L1=ocgs[0], L2=ocgs[1], L3=ocgs[2]))
    content = b"0 0 0 rg 140 0 40 12 re f\n" + b"".join(f"/OC /L{i+1} BDC {c[0]/255} {c[1]/255} {c[2]/255} rg {10+100*i} 20 80 60 re f EMC\n".encode() for i, c in enumerate(COLORS))
    page.Contents = pdf.make_stream(content)
    d = Dictionary(Order=Array(ocgs))
    if base_state: d.BaseState = Name("/" + base_state)
    if on_idx is not None: d.ON = Array([ocgs[i] for i in on_idx])
    if off_idx is not None: d.OFF = Array([ocgs[i] for i in off_idx])
    pdf.Root.OCProperties = Dictionary(OCGs=Array(ocgs), D=d)
    return pdf, ocgs
def same(a, b): return a.objgen == b.objgen
def mirror_layers_list(pdf):
    """Hiểu ON/OFF/BaseState theo đặc tả (Kotlin dùng PDOptionalContentProperties.isGroupEnabled): thành viên mảng thắng, còn lại theo BaseState."""
    props = pdf.Root.OCProperties; d = props.D; base_on = str(d.get("/BaseState", Name.ON)) != "/OFF"
    on = [o.objgen for o in d.get("/ON", [])]; off = [o.objgen for o in d.get("/OFF", [])]
    res = []
    for g in props.OCGs:
        if g.objgen in off and g.objgen not in on: res.append(False)
        elif g.objgen in on and g.objgen not in off: res.append(True)
        elif g.objgen in on and g.objgen in off: res.append(base_on)   # mâu thuẫn: không xác định theo đặc tả -> trước khi sửa chỉ ghi nhận
        else: res.append(base_on)
    return res
def mirror_set_layers(pdf, enabled):
    """Phản chiếu PdfStructureTools.setLayers: bật = có trong ON và không có trong OFF; tắt = ngược lại; không đụng BaseState."""
    props = pdf.Root.OCProperties; d = props.D
    if "/ON" not in d: d.ON = Array()
    if "/OFF" not in d: d.OFF = Array()
    on, off = d.ON, d.OFF
    def idx(arr, g): return [i for i in range(len(arr)) if arr[i].objgen == g.objgen]
    for i, g in enumerate(props.OCGs):
        add, drop = (on, off) if enabled[i] else (off, on)
        for j in reversed(idx(drop, g)): del drop[j]
        if not idx(add, g): add.append(g)
def render_visible(path):
    base = P("r_" + str(abs(hash(path)) % 10**8)); run("pdftoppm", "-r", "72", "-png", "-singlefile", path, base)
    im = Image.open(base + ".png").convert("RGB"); os.unlink(base + ".png")
    return [im.getpixel(c) == col for c, col in zip(CENTERS, COLORS)], im.getpixel(BLACK_PX) == (0, 0, 0)
print("== B. lớp OCG (vẽ bằng poppler, đo màu) ==")
CONFIGS = {"BaseState ON, OFF=[L2]": ("ON", None, [1]), "BaseState OFF, ON=[L1,L3]": ("OFF", [0, 2], None), "không BaseState, chỉ OFF=[L1,L3]": (None, None, [0, 2])}
bad_list = 0
for name, (b, on_i, off_i) in CONFIGS.items():
    pdf, _ = layered_pdf(b, on_i, off_i); pdf.save(P("l0.pdf")); listing = mirror_layers_list(pdf); pdf.close()
    vis, black = render_visible(P("l0.pdf"))
    if listing != vis or not black: bad_list += 1; print("  khác:", name, listing, vis)
check(bad_list == 0, "danh sách trạng thái (cách hiểu ON/OFF/BaseState) khớp với cái poppler vẽ ở cả 3 cấu hình ban đầu")
bad = 0; total = 0
for name, (b, on_i, off_i) in CONFIGS.items():
    for combo in itertools.product([True, False], repeat=3):
        pdf, _ = layered_pdf(b, on_i, off_i); mirror_set_layers(pdf, list(combo)); pdf.save(P("l1.pdf")); pdf.close(); total += 1
        vis, black = render_visible(P("l1.pdf"))
        if vis != list(combo) or not black or not qpdf_ok(P("l1.pdf"))[0]: bad += 1; print("  khác:", name, combo, vis)
check(bad == 0, f"{total} ca (3 cấu hình x 8 tổ hợp): sau setLayers poppler vẽ ĐÚNG những lớp được bật, hình ngoài lớp luôn còn")
pdf, ocgs = layered_pdf("ON", [0, 1], [1, 2]); mirror_set_layers(pdf, [False, True, True]); pdf.save(P("l2.pdf")); pdf.close()
vis, _ = render_visible(P("l2.pdf")); r = pikepdf.open(P("l2.pdf")); dd = r.Root.OCProperties.D
check(vis == [False, True, True] and len(dd.ON) == 2 and len(dd.OFF) == 1, f"lớp nằm ở CẢ HAI mảng: sau khi đặt, mỗi lớp ở đúng MỘT mảng (ON={len(dd.ON)}, OFF={len(dd.OFF)}), vẽ đúng"); r.close()
pdf, _ = layered_pdf("ON", None, [1]); mirror_set_layers(pdf, [True, False, True]); pdf.save(P("l3.pdf")); pdf.close()
r = pikepdf.open(P("l3.pdf")); dd = r.Root.OCProperties.D
check(len(dd.OFF) == 1 and len(dd.ON) == 2 and all(any(x.objgen == g.objgen for x in r.Root.OCProperties.OCGs) for g in list(dd.ON) + list(dd.OFF)), "phần tử mảng là THAM CHIẾU tới đúng các lớp có thật (không phải bản sao)"); r.close()

# =============================================================== C. liên kết
def ensure_annots(page):
    if "/Annots" not in page: page.Annots = Array()
    return page
def link_pdf():
    pdf = blank(3)
    def link(page_idx, rect, **kw):
        a = pdf.make_indirect(Dictionary(Type=Name.Annot, Subtype=Name.Link, Rect=Array(rect), Border=Array([0, 0, 0]), **kw)); ensure_annots(pdf.pages[page_idx].obj).Annots.append(a); return a
    def other(page_idx, subtype, rect):
        a = pdf.make_indirect(Dictionary(Type=Name.Annot, Subtype=Name(subtype), Rect=Array(rect), Contents=String("ghi chú"))); ensure_annots(pdf.pages[page_idx].obj).Annots.append(a)
    p2 = pdf.pages[1].obj
    link(0, [10, 10, 90, 30], A=Dictionary(S=Name.URI, URI=String("https://example.com/a?utm=1")))
    link(0, [10, 40, 90, 60], A=Dictionary(S=Name.GoTo, D=Array([p2, Name.Fit])))
    link(0, [10, 70, 90, 90], Dest=Array([pdf.pages[2].obj, Name.XYZ, 0, 100, 0]))
    other(0, "/Text", [200, 10, 220, 30]); other(0, "/Highlight", [200, 40, 280, 60])
    link(1, [10, 10, 90, 30], A=Dictionary(S=Name.URI, URI=String("mailto:ai@example.com")))
    link(1, [10, 40, 90, 60], A=Dictionary(S=Name.Launch, F=String("run.exe")))
    link(1, [10, 70, 90, 90], Dest=String("chuong1"))
    link(2, [10, 10, 90, 30], A=Dictionary(S=Name.GoTo, D=String("chuong2")))
    link(2, [10, 40, 90, 60], A=Dictionary(S=Name.GoTo, D=String("khong_co")))
    # tên CŨ: /Catalog /Dests (dict) ; tên MỚI: /Names /Dests (cây tên)
    pdf.Root.Dests = Dictionary(chuong1=Array([pdf.pages[2].obj, Name.Fit]))
    pdf.Root.Names = Dictionary(Dests=Dictionary(Names=Array([String("chuong2"), Dictionary(D=Array([pdf.pages[0].obj, Name.Fit]))])))
    return pdf
def page_no(pdf, pageobj):
    for i, p in enumerate(pdf.pages):
        if p.obj.objgen == pageobj.objgen: return i + 1
    return -1
def resolve_named(pdf, name):
    d = pdf.Root.get("/Dests")
    if d is not None and ("/" + name) in d: return d["/" + name]
    nm = pdf.Root.get("/Names")
    if nm is not None and "/Dests" in nm:
        def walk(node):
            if "/Names" in node:
                a = node.Names
                for i in range(0, len(a), 2):
                    if str(a[i]) == name: return a[i + 1]
            for k in node.get("/Kids", []):
                r = walk(k)
                if r is not None: return r
        return walk(nm.Dests)
def mirror_describe(pdf, page, a):
    """Phản chiếu PdfStructureTools.describe."""
    act = a.get("/A")
    if act is not None and str(act.get("/S")) == "/URI": return ("WEB", str(act.URI))
    dest = act.get("/D") if (act is not None and str(act.get("/S")) == "/GoTo") else a.get("/Dest")
    if dest is None: return ("OTHER", "")
    if isinstance(dest, pikepdf.String):
        r = resolve_named(pdf, str(dest))
        if r is None: return ("OTHER", str(dest))
        dest = r.D if isinstance(r, pikepdf.Dictionary) and "/D" in r else r
    if isinstance(dest, pikepdf.Array) and len(dest) > 0:
        n = page_no(pdf, dest[0]); return ("PAGE", str(n)) if n >= 0 else ("OTHER", "")
    return ("OTHER", "")
def mirror_list_links(pdf):
    out = []
    for pi, page in enumerate(pdf.pages):
        for a in page.obj.get("/Annots", []):
            if str(a.get("/Subtype")) == "/Link": out.append((pi + 1,) + mirror_describe(pdf, pi + 1, a))
    return out
def mirror_remove_links(pdf, only_web):
    removed = 0
    for page in pdf.pages:
        if "/Annots" not in page.obj: continue
        keep = Array()
        for a in page.obj.Annots:
            is_link = str(a.get("/Subtype")) == "/Link"; act = a.get("/A")
            drop = is_link and (not only_web or (act is not None and str(act.get("/S")) == "/URI"))
            if drop: removed += 1
            else: keep.append(a)
        if len(keep) != len(page.obj.Annots): page.obj.Annots = keep
    return removed
print("== C. liên kết ==")
pdf = link_pdf(); pdf.save(P("links.pdf"))
EXPECT = [(1, "WEB", "https://example.com/a?utm=1"), (1, "PAGE", "2"), (1, "PAGE", "3"), (2, "WEB", "mailto:ai@example.com"), (2, "OTHER", ""), (2, "PAGE", "3"), (3, "PAGE", "1"), (3, "OTHER", "khong_co")]
got = mirror_list_links(pdf); check(got == EXPECT, f"phân loại 8 liên kết khớp bảng chân trị viết tay (đích rõ, /Dest, tên cũ, tên mới, Launch, tên không có): {got}")
rd = pypdf.PdfReader(P("links.pdf")); pn = [(i + 1, len([a for a in (p.get("/Annots") or []) if a.get_object().get("/Subtype") == "/Link"]), len(p.get("/Annots") or [])) for i, p in enumerate(rd.pages)]
check(pn == [(1, 3, 5), (2, 3, 3), (3, 2, 2)], f"pypdf (độc lập) đếm liên kết/chú thích mỗi trang đúng: {pn}")
pdf = pikepdf.open(P("links.pdf")); n1 = mirror_remove_links(pdf, True); pdf.save(P("links_web.pdf")); pdf.close()
rd = pypdf.PdfReader(P("links_web.pdf")); kinds = []
for p in rd.pages:
    for a in (p.get("/Annots") or []):
        a = a.get_object(); kinds.append((a["/Subtype"], "URI" if (a.get("/A") and a["/A"].get("/S") == "/URI") else "-"))
check(n1 == 2 and not any(k[1] == "URI" for k in kinds) and sum(1 for k in kinds if k[0] == "/Link") == 6 and sum(1 for k in kinds if k[0] in ("/Text", "/Highlight")) == 2 and qpdf_ok(P("links_web.pdf"))[0], f"xoá liên kết WEB: bỏ đúng 2 (kể cả mailto), 6 liên kết khác + Text + Highlight còn nguyên ({n1})")
pdf = pikepdf.open(P("links.pdf")); n2 = mirror_remove_links(pdf, False); pdf.save(P("links_all.pdf")); pdf.close()
rd = pypdf.PdfReader(P("links_all.pdf")); rest = [a.get_object()["/Subtype"] for p in rd.pages for a in (p.get("/Annots") or [])]
check(n2 == 8 and sorted(rest) == ["/Highlight", "/Text"] and qpdf_ok(P("links_all.pdf"))[0] and run("pdftoppm", "-r", "30", "-png", "-singlefile", P("links_all.pdf"), P("la")).returncode == 0, f"xoá MỌI liên kết: bỏ 8, chỉ còn chú thích Text + Highlight; poppler vẽ được ({n2})")

shutil.rmtree(tmp, ignore_errors=True)
print("\nTAT CA DAT" if not FAILS else f"\n{len(FAILS)} LOI"); sys.exit(1 if FAILS else 0)
