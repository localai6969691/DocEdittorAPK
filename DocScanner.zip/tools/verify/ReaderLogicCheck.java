import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Java twin of ZoomMath.kt and PdfReadingPositions.kt (phiên 23, 4.59), statement by statement. stdin, one command per line:
 *   ZOOM scale offsetX width target fx fy      -> "scale offsetX scrollDy"
 *   PAD height scale                           -> extra bottom padding
 *   CONTENTX x offsetX scale                   -> content x
 *   PUT <text-hex> <key-hex> <page>            -> new text as hex      (text / key are hex of UTF-16 code units, 4 digits each)
 *   GET <text-hex> <key-hex>                   -> page or -1
 *   KEY <name-hex> <length>                    -> key as hex
 *   FRAME ax ay bx by w h                      -> "x0 y0 x1 y1" or "-"   (ReaderEdits.frame)
 *   STAMPBOX x y w h widthFraction aspect      -> "x0 y0 x1 y1" or "-"   (ReaderEdits.stampBox)
 *   SNIFF <bytes-hex>                          -> mime type or "-"   (IncomingFile.sniffType; bytes as 2 hex digits each)
 *   RESET | SPUT <key-hex> <page> | SGET <key-hex> | STEXT     the same PUT / GET on a stored text kept between commands (like SharedPreferences)
 */
public class ReaderLogicCheck {
    static final float MAX_ZOOM = 4f;
    static float clampX(float x, float width, float scale) { float lo = width * (1f - scale), hi = 0f; return x < lo ? lo : (x > hi ? hi : x); }
    static float coerce(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
    static String zoomTo(float scale, float offsetX, float width, float target, float fx, float fy) {
        float s = coerce(target, 1f, MAX_ZOOM);
        if (s == scale) return scale + " " + offsetX + " 0";
        float ox = clampX(fx - (fx - offsetX) * (s / scale), width, s);
        int dy = Math.round(fy / scale - fy / s);                        // Kotlin roundToInt() = round half up, like Math.round
        return s + " " + ox + " " + dy;
    }
    static int extraBottomPadding(float height, float scale) { return (int) (height * (1f - 1f / scale)); }
    static float contentX(float x, float offsetX, float scale) { return (x - offsetX) / scale; }

    static final int MAX_ENTRIES = 100;
    static String clean(String s) { StringBuilder sb = new StringBuilder(); for (char c : s.toCharArray()) sb.append((c == '\t' || c == '\n' || c == '\r') ? ' ' : c); return sb.toString(); }
    static String key(String name, long length) { return clean(name) + "|" + length; }
    static Integer toIntOrNull(String s) {
        if (s.isEmpty()) return null;
        int i = 0; if (s.charAt(0) == '-' || s.charAt(0) == '+') { if (s.length() == 1) return null; i = 1; }
        for (int k = i; k < s.length(); k++) if (Character.digit(s.charAt(k), 10) < 0) return null;
        try { return Integer.parseInt(s.charAt(0) == '+' ? s.substring(1) : s); } catch (NumberFormatException e) { return null; }
    }
    static LinkedHashMap<String, Integer> decode(String text) {
        LinkedHashMap<String, Integer> map = new LinkedHashMap<>();
        for (String line : text.split("\n", -1)) {
            int tab = line.indexOf('\t');
            if (tab <= 0) continue;
            Integer page = toIntOrNull(line.substring(0, tab));
            if (page == null || page < 0) continue;
            String k = line.substring(tab + 1);
            if (k.isEmpty()) continue;
            map.remove(k); map.put(k, page);
        }
        return map;
    }
    static String encode(Map<String, Integer> map) { StringBuilder sb = new StringBuilder(); for (Map.Entry<String, Integer> e : map.entrySet()) sb.append(e.getValue()).append('\t').append(e.getKey()).append('\n'); return sb.toString(); }
    static int get(String text, String key) { Integer v = decode(text).get(clean(key)); return v == null ? -1 : v; }
    static String put(String text, String key, int page) {
        LinkedHashMap<String, Integer> map = decode(text); String k = clean(key);
        map.remove(k); map.put(k, Math.max(page, 0));
        while (map.size() > MAX_ENTRIES) map.remove(map.keySet().iterator().next());
        return encode(map);
    }

    static String unhex(String h) { StringBuilder sb = new StringBuilder(); for (int i = 0; i + 4 <= h.length(); i += 4) sb.append((char) Integer.parseInt(h.substring(i, i + 4), 16)); return sb.toString(); }
    static String hex(String s) { StringBuilder sb = new StringBuilder(); for (int i = 0; i < s.length(); i++) sb.append(String.format("%04x", (int) s.charAt(i))); return sb.toString(); }

    static boolean at(byte[] head, int offset, int... expected) {
        if (head.length < offset + expected.length) return false;
        for (int i = 0; i < expected.length; i++) if ((head[offset + i] & 0xFF) != expected[i]) return false;
        return true;
    }
    static String sniffType(byte[] head) {
        for (int offset = 0; offset <= 4; offset++) if (at(head, offset, 0x25, 0x50, 0x44, 0x46, 0x2D)) return "application/pdf";
        if (at(head, 0, 0xFF, 0xD8, 0xFF)) return "image/jpeg";
        if (at(head, 0, 0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)) return "image/png";
        if (at(head, 0, 0x52, 0x49, 0x46, 0x46) && at(head, 8, 0x57, 0x45, 0x42, 0x50)) return "image/webp";
        if (at(head, 0, 0x50, 0x4B, 0x03, 0x04)) return "application/zip";
        return null;
    }
    static byte[] bytesOf(String h) { if (h.equals("-")) return new byte[0]; byte[] b = new byte[h.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return b; }

    static final float MIN_SIDE = 0.01f;
    static String box(float... v) { return v[0] + " " + v[1] + " " + v[2] + " " + v[3]; }
    static String frame(float ax, float ay, float bx, float by, float width, float height) {
        if (width <= 0f || height <= 0f) return "-";
        float x0 = coerce(Math.min(ax, bx) / width, 0f, 1f), x1 = coerce(Math.max(ax, bx) / width, 0f, 1f);
        float y0 = coerce(Math.min(ay, by) / height, 0f, 1f), y1 = coerce(Math.max(ay, by) / height, 0f, 1f);
        if (x1 - x0 < MIN_SIDE || y1 - y0 < MIN_SIDE) return "-";
        return box(x0, y0, x1, y1);
    }
    static String stampBox(float x, float y, float width, float height, float widthFraction, float aspect) {
        if (width <= 0f || height <= 0f || aspect <= 0.01f) return "-";
        float bw = coerce(widthFraction, 0.05f, 0.9f);
        float bh = (bw * width / aspect) / height;
        if (bh > 1f) { bh = 1f; bw = bh * height * aspect / width; }
        float cx = coerce(x / width, 0f, 1f), cy = coerce(y / height, 0f, 1f);
        float x0 = coerce(cx - bw / 2f, 0f, 1f - bw), y0 = coerce(cy - bh / 2f, 0f, 1f - bh);
        return box(x0, y0, x0 + bw, y0 + bh);
    }

    static String stored = "";

    public static void main(String[] a) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.US_ASCII)); String line;
        PrintStream out = new PrintStream(System.out, false, "UTF-8");
        while ((line = r.readLine()) != null) {
            String[] t = line.trim().split(" ");
            switch (t[0]) {
                case "ZOOM": out.println(zoomTo(Float.parseFloat(t[1]), Float.parseFloat(t[2]), Float.parseFloat(t[3]), Float.parseFloat(t[4]), Float.parseFloat(t[5]), Float.parseFloat(t[6]))); break;
                case "PAD": out.println(extraBottomPadding(Float.parseFloat(t[1]), Float.parseFloat(t[2]))); break;
                case "CONTENTX": out.println(contentX(Float.parseFloat(t[1]), Float.parseFloat(t[2]), Float.parseFloat(t[3]))); break;
                case "PUT": out.println(hex(put(t.length > 1 ? unhex(t[1]) : "", unhex(t[2]), Integer.parseInt(t[3])))); break;
                case "GET": out.println(get(t.length > 1 ? unhex(t[1]) : "", unhex(t[2]))); break;
                case "KEY": out.println(hex(key(unhex(t[1]), Long.parseLong(t[2])))); break;
                case "FRAME": out.println(frame(Float.parseFloat(t[1]), Float.parseFloat(t[2]), Float.parseFloat(t[3]), Float.parseFloat(t[4]), Float.parseFloat(t[5]), Float.parseFloat(t[6]))); break;
                case "STAMPBOX": out.println(stampBox(Float.parseFloat(t[1]), Float.parseFloat(t[2]), Float.parseFloat(t[3]), Float.parseFloat(t[4]), Float.parseFloat(t[5]), Float.parseFloat(t[6]))); break;
                case "SNIFF": { String m = sniffType(bytesOf(t.length > 1 ? t[1] : "-")); out.println(m == null ? "-" : m); break; }
                case "RESET": stored = ""; break;
                case "SPUT": stored = put(stored, unhex(t[1]), Integer.parseInt(t[2])); break;
                case "SGET": out.println(get(stored, unhex(t[1]))); break;
                case "STEXT": out.println(hex(stored)); break;
                default: break;
            }
        }
        out.flush();
    }
}
