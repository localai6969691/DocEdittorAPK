"""Kiểm chứng xuất FB2 (phiên 16): EbookBuilder.buildFb2 / fb2Document và việc làm sạch ký tự XML không hợp lệ (cũng dùng cho EPUB).

Fb2Check.java là bản Java chạy được của đúng hàm đó (cùng logic, cùng thứ tự phần tử). Kiểm bằng công cụ ĐỘC LẬP, không phải bằng chính mã vừa viết:
  1. xmllint --noout: tệp đúng cú pháp XML (kể cả với ký tự điều khiển \\x00 \\x0b \\x0c \\x1f, surrogate lẻ, U+FFFE trong văn bản đầu vào);
  2. lxml: đúng thứ tự phần tử của lược đồ FictionBook 2.x (title-info: genre, author, book-title, date, lang; document-info: author, program-used, date, id, version;
     body: title?, section+; section: title?, p+), namespace đúng, mỗi section có ít nhất một <p>;
  3. pandoc -f fb2 (trình đọc FB2 của bên thứ ba): đọc được, tên sách / tên chương / các đoạn khớp với đầu vào đã bỏ ký tự cấm;
  4. THỬ ÂM TÍNH: văn bản có ký tự điều khiển đưa thẳng vào XML (không làm sạch) bị xmllint từ chối - tức là việc làm sạch là cần thiết, không phải thừa.
Chạy: python3 fb2_check.py   (cần java 11+, xmllint, pandoc, lxml)
"""
import json, os, re, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
from lxml import etree

HERE = os.path.dirname(os.path.abspath(__file__))
NS = "{http://www.gribuser.ru/xml/fictionbook/2.0}"
FAILS = []


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond:
        FAILS.append(what)
    return cond


def enc(s):
    """Viết chuỗi cho Fb2Check.java: ký tự ngoài ASCII in được -> \\uXXXX (UTF-16, nên emoji thành cặp surrogate), '\\' -> '\\\\'."""
    out = []
    for ch in s:
        o = ord(ch)
        if ch == "\\":
            out.append("\\\\")
        elif 0x20 <= o < 0x7F:
            out.append(ch)
        else:
            b = ch.encode("utf-16-be", "surrogatepass")
            for i in range(0, len(b), 2):
                out.append("\\u%02x%02x" % (b[i], b[i + 1]))
    return "".join(out)


def is_xml_char(cp):
    return cp in (9, 10, 13) or 0x20 <= cp <= 0xD7FF or 0xE000 <= cp <= 0xFFFD or 0x10000 <= cp <= 0x10FFFF


def expected_text(s):
    return "".join(ch for ch in s if is_xml_char(ord(ch)))


def write_case(name, book, chapters):
    path = os.path.join(OUT, f"fb2_{name}.in")
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"BOOK\t{enc(book)}\n")
        for title, paras in chapters:
            f.write(f"C\t{enc(title)}\n")
            for p in paras:
                f.write(f"P\t{enc(p)}\n")
    out = os.path.join(OUT, f"fb2_{name}.fb2")
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", os.path.join(HERE, "Fb2Check.java"), path, out], capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit("Java lỗi:\n" + r.stdout + r.stderr)
    return out


def structure_problems(path, n_sections):
    problems = []
    root = etree.parse(path).getroot()
    if root.tag != NS + "FictionBook":
        return [f"gốc là {root.tag}"]
    kids = [c.tag.replace(NS, "") for c in root]
    if kids != ["description", "body"]:
        problems.append(f"con của FictionBook: {kids}")
    desc = root.find(NS + "description")
    ti = [c.tag.replace(NS, "") for c in desc.find(NS + "title-info")]
    if ti != ["genre", "author", "book-title", "date", "lang"]:
        problems.append(f"title-info: {ti}")
    di = [c.tag.replace(NS, "") for c in desc.find(NS + "document-info")]
    if di != ["author", "program-used", "date", "id", "version"]:
        problems.append(f"document-info: {di}")
    body = root.find(NS + "body")
    bk = [c.tag.replace(NS, "") for c in body]
    if bk not in (["title"] + ["section"] * n_sections, ["section"] * n_sections):
        problems.append(f"body: {bk}")
    for i, sec in enumerate(body.findall(NS + "section")):
        sk = [c.tag.replace(NS, "") for c in sec]
        if not sk or sk.count("p") < 1 or any(t not in ("title", "p") for t in sk) or ("title" in sk and sk[0] != "title"):
            problems.append(f"section {i}: {sk}")
    return problems


def pandoc_plain(path):
    r = subprocess.run(["pandoc", "-f", "fb2", "-t", "json", path], capture_output=True, text=True)
    if r.returncode != 0:
        return None, r.stderr
    return json.loads(r.stdout), ""


def pandoc_text(block_or_inlines):
    """Gom chữ từ cây JSON của pandoc."""
    out = []
    def walk(x):
        if isinstance(x, dict):
            if x.get("t") == "Str":
                out.append(x["c"])
            elif x.get("t") in ("Space", "SoftBreak", "LineBreak"):
                out.append(" ")
            else:
                walk(x.get("c"))
        elif isinstance(x, list):
            for y in x:
                walk(y)
    walk(block_or_inlines)
    return "".join(out)


CASES = {
    "normal": ("Sách thử nghiệm", [("Chương 1: Mở đầu", ["Xin chào các bạn.", "Đoạn thứ hai có dấu: ắ ằ ẳ ẵ ặ, ư ơ đ."]),
                                   ("Chương 2", ["Một đoạn duy nhất."]), ("第三章 中文", ["这是一个中文段落，没有空格。", "日本語の段落です。"])]),
    "specials": ("Tom & Jerry <\"book\"> 'x'", [("A < B && C > D", ["if (a < b && c > d) { echo \"x\" }", "&amp; đã escape sẵn?  &lt;tag&gt;", "dấu \\ ngược và \\u0041 chữ"])]),
    "controls": ("Sách\x00 có\x0b ký\x0c tự\x1f lạ", [("Chương\x00\x01", ["ctrl: a\x00b\x0bc\x0cd\x1fe\x7ff \ufffe g \uffff h", "lone: \ud800 x \udfff y", "emoji 😀 và 𝒳 giữ nguyên", "tab\ttab và CR\r giữ"]),
                                                     ("\x00\x01", ["\x00\x0b"])]),
    "empty-chapter": ("Có chương rỗng", [("Chương có chữ", ["abc"]), ("Chương không có đoạn nào", []), ("Chương toàn đoạn trắng", ["   ", ""])]),
    "no-chapters": ("Không có chương", []),
    "blank-titles": ("", [("", ["chỉ có đoạn, tên chương trống"]), ("   ", ["tên chương toàn dấu cách"])]),
    "long": ("Đoạn dài", [("Chương dài", ["từ " * 5000, "x" * 100000])]),
}


def main():
    for name, (book, chapters) in CASES.items():
        path = write_case(name, book, chapters)
        r = subprocess.run(["xmllint", "--noout", path], capture_output=True, text=True)
        check(r.returncode == 0, f"{name}: xmllint — XML đúng cú pháp" + ("" if r.returncode == 0 else " — " + r.stderr[:150]))
        n_sections = max(1, len(chapters))
        probs = structure_problems(path, n_sections)
        check(not probs, f"{name}: thứ tự phần tử FictionBook, {n_sections} section" + (" — " + "; ".join(probs[:2]) if probs else ""))
        raw = open(path, encoding="utf-8").read()
        check(all(is_xml_char(ord(c)) for c in raw), f"{name}: không còn ký tự cấm của XML 1.0 trong tệp")

        doc, err = pandoc_plain(path)
        if not check(doc is not None, f"{name}: pandoc -f fb2 đọc được" + (" — " + err[:120] if doc is None else "")):
            continue
        blocks = doc["blocks"]
        text_all = pandoc_text(blocks)
        meta = pandoc_text(doc["meta"].get("title", {}))
        want_book = " ".join(expected_text(book).split())
        if want_book:
            check(" ".join(meta.split()) == want_book or want_book in " ".join(text_all.split()), f"{name}: tên sách đọc lại khớp ({want_book[:40]!r})")
        # mọi đoạn (đã bỏ ký tự cấm, thu gọn khoảng trắng) phải xuất hiện, theo đúng thứ tự
        compact = " ".join(text_all.split())
        pos = 0
        ok = True
        miss = ""
        for title, paras in chapters:
            for t in ([title] if title.strip() else []) + [p for p in paras if p.strip()]:
                w = " ".join(expected_text(t).split())
                if not w:
                    continue
                if len(w) > 2000:
                    w = w[:2000]
                i = compact.find(w, pos)
                if i < 0:
                    ok = False; miss = w[:40]; break
                pos = i + len(w)
            if not ok:
                break
        check(ok, f"{name}: pandoc đọc lại đủ tên chương và các đoạn, đúng thứ tự" + ("" if ok else f" — thiếu {miss!r}"))

    # tên chương phải là tiêu đề (mục lục) khi đọc bằng pandoc: pandoc bọc mỗi <section> trong một Div và đưa tên chương thành Header cấp 2
    # (tên sách là Header cấp 1), nên phải duyệt đệ quy qua các Div
    doc, _ = pandoc_plain(os.path.join(OUT, "fb2_normal.fb2"))
    headers = []
    def collect(blocks):
        for b in blocks:
            if b["t"] == "Header":
                headers.append((b["c"][0], pandoc_text(b["c"][2])))
            elif b["t"] == "Div":
                collect(b["c"][1])
    collect(doc["blocks"])
    check(headers == [(1, "Sách thử nghiệm"), (2, "Chương 1: Mở đầu"), (2, "Chương 2"), (2, "第三章 中文")],
          f"normal: tên sách = tiêu đề cấp 1, mỗi chương = tiêu đề cấp 2 theo đúng thứ tự (mục lục): {headers}")

    # thử âm tính: ký tự điều khiển đưa thẳng vào XML (không làm sạch) phải bị từ chối
    bad = os.path.join(OUT, "fb2_unsanitized.fb2")
    with open(bad, "w", encoding="utf-8") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n<FictionBook xmlns="http://www.gribuser.ru/xml/fictionbook/2.0"><body><section><p>a\x0bb</p></section></body></FictionBook>\n')
    r = subprocess.run(["xmllint", "--noout", bad], capture_output=True, text=True)
    check(r.returncode != 0, "thử âm tính: ký tự \\x0b chưa làm sạch bị xmllint từ chối — việc làm sạch là cần thiết")
    # và bản làm sạch của đúng nội dung đó thì qua
    ctrl = open(os.path.join(OUT, "fb2_controls.fb2"), encoding="utf-8").read()
    check("\x0b" not in ctrl and "\x00" not in ctrl, "ca 'controls': \\x00 và \\x0b không còn trong tệp xuất")
    print("\nTAT CA DAT" if not FAILS else f"\nCO {len(FAILS)} LOI")
    sys.exit(1 if FAILS else 0)


if __name__ == "__main__":
    main()
