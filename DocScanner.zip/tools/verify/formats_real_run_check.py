#!/usr/bin/env python3
"""Năm bộ ghi định dạng CHẠY THẬT (phiên 26, TECHNICAL_DOCS.md 4.84): `ZipPack` (ZIP + AES-256), `TiffWriter`, `QrEncoder`, `XlsxWriter`, `PptxWriter`.

Từ phiên 7-17 mỗi tệp chỉ có bản Java / Python "chép lại" (`zip_pack_check`, `ZipPackCheck.java`, `export_check`, `qr_check`...); mã Kotlin thật chưa từng chạy ở đâu ngoài CI biên dịch. Bộ này biên dịch CHÍNH các tệp
đó (kotlinc, `real_run/FormatsHarness.kt`) rồi đo bằng công cụ ĐỘC LẬP, không công cụ nào là mã của dự án:
  A. ZIP: tên trong ZIP / chọn STORED / độ dài mật khẩu / giờ DOS / PBKDF2 so với đặc tả viết lại trong Python và `hashlib.pbkdf2_hmac`; ZIP thường đọc bằng `zipfile`, `unzip -t`, 7-Zip;
     ZIP AES-256 (WinZip AE-2) với mật khẩu tiếng Việt và ký tự ngoài BMP: pyzipper và 7-Zip phải GIẢI MÃ đúng từng byte, sai mật khẩu bị từ chối, sửa 1 byte bị HMAC bắt;
  B. TIFF nhiều trang (xám / RGB, nén Deflate + predictor): PIL và tifffile đọc lại đúng điểm ảnh, DPI, số trang; `dpiFor`;
  C. QR: 48 ký hiệu (số / chữ-số / byte, tiếng Việt, 4 mức sửa lỗi) GIỐNG HỆT TỪNG Ô bản tham chiếu `qrcodegen` (Nayuki) cùng mặt nạ + phiên bản nhỏ nhất; OpenCV không đọc sai ký hiệu nào; phiên bản 40 và các giới hạn
     dung lượng; boost; Wi-Fi thoát ký tự. (Mặt nạ tự chọn KHÔNG đòi trùng: ba bản cài đặt chuẩn tính điểm phạt N3 ở biên hơi khác nhau.)
  D. XLSX: openpyxl đọc lại kiểu ô (số nguyên là số, "0912…", "1.234", "-0" là chữ), ký tự đặc biệt / điều khiển / emoji, cột rộng (AA..), 1 000 dòng, tên sheet hợp lệ và không trùng;
  E. PPTX: python-pptx đọc lại khổ trang, vị trí ảnh (vừa khung, giữ tỉ lệ, căn giữa), chữ thay thế, ảnh nguyên byte.
THỬ ÂM TÍNH: 7 bản mã bị làm hỏng (1001 vòng PBKDF2, mật khẩu mã hoá Latin-1 thay vì UTF-8, đổi bit định dạng mức L/M của QR, "-0" thành số, ảnh PPTX lệch về góc, DPI cắt thay vì làm tròn,
thiếu kiểu ô "Normal" trong styles.xml) PHẢI bị bắt.
KHÔNG kiểm được: Excel / PowerPoint / WinRAR thật, máy quét QR thật, máy in. Chạy: python3 tools/verify/formats_real_run_check.py [--fast]   (--mutant=N chỉ chạy bản hỏng thứ N, 1-7)"""
import base64, datetime, hashlib, io, os, random, re, subprocess, sys, tempfile, zipfile, zoneinfo
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="formats-")
FILES = ["ZipPack.kt", "TiffWriter.kt", "QrEncoder.kt", "XlsxWriter.kt", "PptxWriter.kt", "DocxWriter.kt"]; HARNESS = os.path.join(HERE, "real_run", "FormatsHarness.kt")
def build(mutate=None, tag="base"): return tc.compile(FILES, [HARNESS], os.path.join(WORK, "cls-" + tag), mutate)[0]
b = lambda s: base64.b64encode(s.encode()).decode(); u = lambda s: base64.b64decode(s).decode()
def hz(cls, *args):
    r = tc.run(cls, "FormatsHarnessKt", [str(a) for a in args])
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-800:])
    return r.stdout.strip("\n").split("\n") if r.stdout.strip() else []
def last(cls, *args): out = hz(cls, *args); return out[-1] if out else ""
def sh(*c): return subprocess.run(c, capture_output=True, text=True)
def P(n): return os.path.join(WORK, n)
def wf(name, data): open(P(name), "wb").write(data); return P(name)

# ------------------------------------------------------------------------------------------------------------------------------ A. ZIP
def model_names(names):
    used, out = set(), []
    for raw in names:
        base = raw.split("/")[-1].split("\\")[-1]
        base = "".join("_" if (ord(c) < 32 or c in ':*?"<>|') else c for c in base)
        base = base.strip("".join(chr(i) for i in range(33))).strip(".") or "file"
        cand, n = base, 2
        while cand.lower() in used:
            dot = base.rfind("."); cand = (base[:dot] + f" ({n})" + base[dot:]) if dot > 0 else f"{base} ({n})"; n += 1
        used.add(cand.lower()); out.append(cand)
    return out

def group_zip(cls):
    names = ["a.pdf", "A.PDF", "../x/y\\z.txt", "co:lon*?.txt", "  .hidden. ", "", "báo cáo.txt", "báo cáo.txt", "tab\there.txt", "noext", "noext", "a.pdf"]
    got = [u(x) for x in hz(cls, "zip-names", *[b(n) for n in names])]; want = model_names(names)
    check(got == want, "(A1) entryNames khớp đặc tả viết lại (bỏ thư mục, ký tự cấm -> _, không trùng không phân biệt hoa thường, ' (2)'...): " + ("" if got == want else f"{got} != {want}"))
    store = {"a.pdf": True, "X.JPG": True, "b.webp": True, "c.docx": True, "d.txt": False, "e": False, "f.tar.gz": True, "g.PNG": True, "h.csv": False}
    bad = [n for n, w in store.items() if last(cls, "zip-store", b(n)) != str(w).lower()]; check(not bad, f"(A2) shouldStore (đuôi đã nén thì STORED): sai {bad}")
    pws = {"1234567": False, "12345678": True, "Mật khẩu": True, "😀😀😀😀😀😀😀": False, "😀😀😀😀😀😀😀😀": True, "": False}
    bad = [p for p, w in pws.items() if last(cls, "zip-pw", b(p)) != str(w).lower()]; check(not bad, f"(A3) passwordAcceptable (đếm ĐIỂM MÃ: emoji tính 1 ký tự): sai {bad}")
    bad = []
    for ms, tz in [(1_700_000_000_000, "Asia/Ho_Chi_Minh"), (1_700_000_001_000, "UTC"), (1_700_000_001_999, "UTC"), (318_211_199_000, "UTC"), (315_532_800_000, "UTC"), (4_102_444_799_000, "America/New_York"), (-5_000_000_000, "UTC"), (1_709_251_199_000, "Asia/Tokyo")]:
        dt = datetime.datetime.fromtimestamp(ms / 1000, zoneinfo.ZoneInfo(tz))
        w = (0, (1 << 5) | 1) if dt.year < 1980 else ((dt.hour << 11) | (dt.minute << 5) | (dt.second // 2), ((dt.year - 1980) << 9) | (dt.month << 5) | dt.day)
        g = tuple(int(x) for x in last(cls, "zip-dos", ms, tz).split(" "))
        if g != w: bad.append((ms, tz, g, w))
    check(not bad, "(A4) dosDateTime: 8 mốc thời gian (kể cả trước 1980 -> kẹp, giây lẻ, múi giờ) khớp datetime của Python" + ("" if not bad else f": {bad[:2]}"))
    bad = []
    for pw, salt, it, dk in [("password", b"salt", 1, 20), ("password", b"salt", 1000, 66), ("Mật khẩu 123", os.urandom(16), 1000, 66), ("pässwörd-€-😀x", os.urandom(16), 1000, 66), ("x", b"", 3, 7), ("a" * 100, os.urandom(8), 4096, 32)]:
        w = hashlib.pbkdf2_hmac("sha1", pw.encode(), salt, it, dk).hex(); g = last(cls, "zip-pbkdf2", b(pw), base64.b64encode(salt).decode(), it, dk)
        if g != w: bad.append((pw[:8], it, dk))
    check(not bad, "(A5) pbkdf2HmacSha1 khớp hashlib.pbkdf2_hmac từng byte (mật khẩu có dấu, ngoài BMP, salt rỗng, 4096 vòng)" + ("" if not bad else f": sai {bad}"))
    rnd = random.Random(5); text = ("Xin chào thế giới, đây là báo cáo tháng. " * 3000).encode(); jpg = bytes(rnd.getrandbits(8) for _ in range(300_000)); binf = bytes(rnd.getrandbits(8) for _ in range(1_500_000))
    members = {"báo cáo.txt": text, "ảnh.jpg": jpg, "trống.txt": b"", "tài liệu.pdf": b"%PDF-" + bytes(rnd.getrandbits(8) for _ in range(50_000)), "data.bin": binf}
    paths = {n: wf(f"zin-{i}", d) for i, (n, d) in enumerate(members.items())}
    spec = [f"{b(n)}|{paths[n]}" for n in members]; expect_store = {n: ZIP_STORE(n) for n in members}
    out = P("plain.zip"); r = last(cls, "zip-write", out, "-", *spec); check(r == "done", "(A6) ghi ZIP thường: " + r)
    with zipfile.ZipFile(out) as z:
        okz = z.testzip() is None and sorted(z.namelist()) == sorted(members) and all(z.read(n) == d for n, d in members.items())
        meth = {i.filename: i.compress_type for i in z.infolist()}
    check(okz, "(A6) zipfile (Python) đọc đúng tên + nội dung từng byte (tiếng Việt, tệp rỗng, 1,5 MB)")
    check(all((meth[n] == zipfile.ZIP_STORED) == expect_store[n] for n in members), f"(A6) phương pháp: STORED cho .jpg/.pdf, DEFLATED cho còn lại: {meth}")
    r = sh("unzip", "-tq", out); check(r.returncode == 0 and "No errors" in r.stdout, "(A6) unzip -t: " + r.stdout.strip()[-60:])
    r = sh("7z", "t", out); check(r.returncode == 0 and "Everything is Ok" in r.stdout, "(A6) 7-Zip kiểm ZIP thường: " + ("ok" if r.returncode == 0 else r.stdout[-120:]))
    import pyzipper
    for pw in ["Mật khẩu 123", "password123", "pässwörd-€-😀x"]:
        enc = P("aes.zip"); r = last(cls, "zip-write", enc, b(pw), *spec); check(r == "done", f"(A7) ghi ZIP AES-256 mật khẩu {pw!r}: {r}")
        with pyzipper.AESZipFile(enc) as z:
            z.setpassword(pw.encode()); names_ok = sorted(z.namelist()) == sorted(members); data_ok = all(z.read(n) == d for n, d in members.items()); meth = {i.filename: i.compress_type for i in z.infolist()}
            tz_ok = z.testzip() is None
        check(names_ok and data_ok and tz_ok, f"(A7) pyzipper giải mã đúng từng byte cả 5 tệp (mật khẩu {pw!r}), HMAC xác thực")
        check(all((meth[n] == zipfile.ZIP_STORED) == expect_store[n] for n in members), "(A7) phương pháp thật trong khối AES: STORED cho .jpg/.pdf, DEFLATED cho còn lại")
        r = sh("7z", "t", "-p" + pw, enc); check(r.returncode == 0 and "Everything is Ok" in r.stdout, f"(A7) 7-Zip giải mã ZIP AES-256 mật khẩu {pw!r}: " + ("ok" if r.returncode == 0 else (r.stdout + r.stderr)[-150:]))
        outd = P("x7z"); sh("rm", "-rf", outd); r = sh("7z", "x", "-p" + pw, "-o" + outd, enc, "-y")
        same = all(os.path.exists(os.path.join(outd, n)) and open(os.path.join(outd, n), "rb").read() == d for n, d in members.items()); check(same, "(A7) 7-Zip giải nén ra đúng từng byte")
        if pw == "Mật khẩu 123":
            r = sh("7z", "t", "-pSaiMatKhau99", enc); check(r.returncode != 0, "(A8) sai mật khẩu bị 7-Zip từ chối")
            try:
                with pyzipper.AESZipFile(enc) as z: z.setpassword(b"SaiMatKhau99"); z.read("báo cáo.txt"); wrong = False
            except Exception: wrong = True
            check(wrong, "(A8) sai mật khẩu bị pyzipper từ chối")
            blob = bytearray(open(enc, "rb").read()); pos = blob.find(b"\x01\x99\x07\x00\x02\x00AE\x03") ; hdr = blob.find(b"PK\x03\x04", blob.find(b"PK\x03\x04") + 1)
            blob[hdr + 120] ^= 0x01; wf("tamper.zip", bytes(blob))
            r = sh("7z", "t", "-p" + pw, P("tamper.zip")); check(r.returncode != 0, "(A8) sửa 1 byte dữ liệu mã hoá: 7-Zip báo lỗi (HMAC / CRC)")
    check(sh("zipinfo", "-v", enc).stdout.count("encrypted") >= 5 or "encrypted" in sh("zipinfo", enc).stdout or True, "(A9) (thông tin)")
ZIPSTORE_EXT = {"pdf", "jpg", "jpeg", "png", "webp", "epub", "zip", "docx", "xlsx", "pptx", "cbz", "mp4", "gz", "7z"}
def ZIP_STORE(name): return name.rsplit(".", 1)[-1].lower() in ZIPSTORE_EXT if "." in name else False

# ------------------------------------------------------------------------------------------------------------------------------ B. TIFF
def group_tiff(cls):
    from PIL import Image, ImageSequence
    import tifffile
    rnd = random.Random(3); pages = [("GRAY_DEFLATE", 64, 48, 200), ("RGB_DEFLATE", 50, 70, 300), ("GRAY_DEFLATE", 1, 1, 72), ("RGB_DEFLATE", 600, 800, 150), ("GRAY_DEFLATE", 257, 3, 96)]
    arrs, spec = [], []
    for i, (kind, w, h, dpi) in enumerate(pages):
        ch = 3 if kind.startswith("RGB") else 1
        a = np.zeros((h, w, ch), dtype=np.uint8) if i != 3 else None
        if i == 3: yy, xx = np.mgrid[0:h, 0:w]; a = np.stack([(xx * 255 // w), (yy * 255 // h), ((xx + yy) * 255 // (w + h))], axis=-1).astype(np.uint8)
        else: a = np.frombuffer(bytes(rnd.getrandbits(8) for _ in range(w * h * ch)), dtype=np.uint8).reshape(h, w, ch)
        arrs.append(a); spec.append(f"{kind}:{w}:{h}:{dpi}:{wf(f'tif{i}.raw', a.tobytes())}")
    out = P("multi.tif"); r = last(cls, "tiff", out, *spec); check(r == "done", "(B1) ghi TIFF 5 trang: " + r)
    im = Image.open(out); frames = [f.copy() for f in ImageSequence.Iterator(im)]
    check(len(frames) == 5, f"(B1) PIL thấy {len(frames)} trang")
    bad = []
    for i, (kind, w, h, dpi) in enumerate(pages):
        f = frames[i]; ch = 3 if kind.startswith("RGB") else 1
        arr = np.asarray(f.convert("RGB" if ch == 3 else "L")).reshape(h, w, ch)
        if f.size != (w, h) or f.mode != ("RGB" if ch == 3 else "L") or not np.array_equal(arr, arrs[i]): bad.append((i + 1, f.size, f.mode, bool(np.array_equal(arr, arrs[i]))))
    check(not bad, "(B2) PIL (libtiff): mỗi trang đúng khổ, kiểu (xám / RGB) và ĐÚNG TỪNG ĐIỂM ẢNH (Deflate + predictor)" + ("" if not bad else f": {bad}"))
    with tifffile.TiffFile(out) as t:
        tags = []
        for i, pg in enumerate(t.pages):
            tg = pg.tags; dpi = tg["XResolution"].value; tags.append((int(tg["Compression"].value), int(tg["Predictor"].value) if "Predictor" in tg else 0, int(tg["ResolutionUnit"].value), dpi[0] / dpi[1], int(tg["SamplesPerPixel"].value)))
        data_ok = all(np.array_equal(np.squeeze(pg.asarray()), np.squeeze(arrs[i])) for i, pg in enumerate(t.pages))
    check(data_ok, "(B3) tifffile (bộ đọc thứ hai) cũng đọc đúng từng điểm ảnh")
    check(all(tags[i][0] in (8, 32946) and tags[i][1] == 2 and tags[i][2] == 2 and abs(tags[i][3] - pages[i][3]) < 0.01 and tags[i][4] == (3 if pages[i][0].startswith("RGB") else 1) for i in range(5)),
          f"(B3) thẻ: nén Deflate, predictor 2, đơn vị inch, DPI đúng từng trang {[round(t[3]) for t in tags]}")
    bad = [(w, p, last(cls, "dpi-for", w, p)) for w, p, e in [(1700, 595.0, 206), (1000, 612.0, 118), (1, 612.0, 1), (100, 0.0, 200), (2480, 595.276, 300), (100, 5000.0, 1)] if last(cls, "dpi-for", w, p) != str(e)]
    check(not bad, f"(B4) dpiFor (làm tròn, tối thiểu 1, 200 khi khổ <= 0): sai {bad}")

# ------------------------------------------------------------------------------------------------------------------------------ C. QR
def group_qr(cls):
    import cv2
    from qrcodegen import QrCode, QrSegment
    det = cv2.QRCodeDetector(); ECC = {"LOW": QrCode.Ecc.LOW, "MEDIUM": QrCode.Ecc.MEDIUM, "QUARTILE": QrCode.Ecc.QUARTILE, "HIGH": QrCode.Ecc.HIGH}
    texts = ["12345678901234567890", "HELLO WORLD 123 $%*+-./:", "https://example.com/path?a=1&b=2", "Xin chào Việt Nam – ứng dụng quét tài liệu", "A", "0", "WIFI:T:WPA;S:nhà;P:pass;;", "x" * 120,
             "Số 12345 và chữ hoa ABC " * 8, "9" * 300, "b" * 1000, "Mã vạch 2D: ABC-123 " * 20]
    def parse(out):
        if out[0] == "null": return None
        v, size, mask = (int(x) for x in out[0].split(" ")); return v, mask, np.array([[int(c) for c in r] for r in out[1:1 + size]], dtype=np.uint8)
    def ref(text, ecl, version, mask):
        q = QrCode.encode_segments(QrSegment.make_segments(text), ECC[ecl], version, version, mask, False); n = q.get_size()
        return q, np.array([[1 if q.get_module(x, y) else 0 for x in range(n)] for y in range(n)], dtype=np.uint8)
    def decode(m):
        for scale in (10, 6, 14):
            img = np.pad(1 - m, 4, constant_values=1).repeat(scale, 0).repeat(scale, 1).astype(np.uint8) * 255
            t, _, _ = det.detectAndDecode(img)
            if t: return t
        return ""
    n = same = wrong = decoded = 0; diffs = []; worse = []
    for t in texts:
        for ecl in ECC:
            r = parse(hz(cls, "qr", ecl, 1, 0, b(t))); n += 1
            if r is None: diffs.append((t[:10], ecl, "null")); continue
            v, mask, m = r; q, qm = ref(t, ecl, v, mask)
            if qm.shape == m.shape and np.array_equal(qm, m): same += 1
            else: diffs.append((t[:10], ecl, v, mask, int((qm != m).sum()) if qm.shape == m.shape else "shape"))
            smallest = min(QrCode.encode_segments(QrSegment.make_segments(t), ECC[ecl], 1, 40, -1, False)._version, 40)
            if smallest != v: diffs.append((t[:10], ecl, "phiên bản", v, smallest))
            pens = [ref(t, ecl, v, k)[0]._get_penalty_score() for k in range(8)]
            if pens[mask] > min(pens) * 1.06: worse.append((t[:10], ecl, mask, pens[mask], min(pens)))
            d = decode(m)
            if d == t: decoded += 1
            elif d: wrong += 1
    check(not diffs, f"(C1) {same}/{n} ký hiệu (12 nội dung x 4 mức sửa lỗi; số / chữ-số / byte, tiếng Việt, tới phiên bản ~20) GIỐNG HỆT TỪNG Ô bản tham chiếu qrcodegen (Nayuki) cùng mặt nạ, và đúng phiên bản nhỏ nhất" + ("" if not diffs else f": lệch {diffs[:4]}"))
    check(wrong == 0 and decoded >= n * 0.85, f"(C2) OpenCV giải mã {decoded}/{n} ký hiệu, KHÔNG có ký hiệu nào ra sai chuỗi ({wrong}); số còn lại là giới hạn bộ phát hiện của OpenCV ở ký hiệu lớn (không phải lỗi mã hoá: ma trận đã giống hệt tham chiếu)")
    check(not worse, f"(C3) mặt nạ do mã chọn có điểm phạt (theo cách tính của qrcodegen) không quá 6% so với mặt nạ tốt nhất: {len(worse)} ký hiệu vượt" + ("" if not worse else f" {worse[:3]}") + ". Lưu ý: ba bản cài đặt chuẩn (ISO, zxing, qrcodegen) tính mẫu N3 ở biên hơi khác nhau nên KHÔNG đòi trùng mặt nạ")
    big = "b" * 2953; o = hz(cls, "qr", "LOW", 1, 0, b(big)); r = parse(o)
    check(r is not None and r[0] == 40 and r[2].shape == (177, 177), f"(C4) 2 953 byte ở mức L = vừa đúng phiên bản 40 (177 x 177): {o[0]}")
    if r is not None:
        q, qm = ref(big, "LOW", 40, r[1]); check(np.array_equal(qm, r[2]), "(C4) ký hiệu phiên bản 40 giống hệt từng ô bản tham chiếu")
    check(hz(cls, "qr", "LOW", 1, 0, b("b" * 2954))[0] == "null", "(C4) 2 954 byte: quá lớn -> null")
    check(hz(cls, "qr", "LOW", 1, 0, b("9" * 7089))[0] != "null" and hz(cls, "qr", "LOW", 1, 0, b("9" * 7090))[0] == "null", "(C4) giới hạn số: 7 089 chữ số vừa, 7 090 -> null")
    o = hz(cls, "qr", "LOW", 1, 1, b("Xin chào")); o0 = hz(cls, "qr", "LOW", 1, 0, b("Xin chào")); check(o[0].split(" ")[0] == o0[0].split(" ")[0], "(C5) boost nâng mức sửa lỗi nhưng GIỮ phiên bản: " + o[0])
    rb = parse(o); check(decode(rb[2]) == "Xin chào" and not np.array_equal(rb[2], parse(o0)[2]), "(C5) ký hiệu đã boost đọc đúng và khác ký hiệu mức L (đã nâng mức)")
    o = hz(cls, "qr", "LOW", 12, 0, b("A")); check(o[0].startswith("12 "), "(C6) minVersion 12 được tôn trọng: " + o[0])
    w = u(last(cls, "wifi", b("Nhà;Số:1"), b('pa"ss,wo\\rd'), "WPA")); check(w == 'WIFI:T:WPA;S:Nhà\\;Số\\:1;P:pa\\"ss\\,wo\\\\rd;;', "(C7) Wi-Fi: thoát ; : , \" \\ bằng dấu gạch chéo ngược: " + w)
    check(u(last(cls, "wifi", b("net"), b(""), "nopass")) == "WIFI:T:nopass;S:net;;" and u(last(cls, "wifi", b("net"), b("p"), "wep")) == "WIFI:T:WEP;S:net;P:p;;", "(C7) Wi-Fi không mật khẩu / WEP")

# ------------------------------------------------------------------------------------------------------------------------------ D. XLSX
def model_sheet(name, taken):
    edges = lambda t: t.strip(" \t\r\n\u00a0'")
    base = edges(re.sub(r"[\[\]:*?/\\]", " ", name)) or "Sheet"
    if len(base) > 31: base = edges(base[:31]) or "Sheet"
    low = {x.lower() for x in taken}; cand, n = base, 2
    while cand.lower() in low: suf = f" ({n})"; cand = base[:31 - len(suf)].rstrip() + suf; n += 1
    return cand

def group_xlsx(cls):
    import openpyxl
    rows1 = [["Tên", "Tuổi", "SĐT", "Giá"], ["Nguyễn Văn A", "42", "0912345678", "1.234"], ["Trần B", "-17", "  7  ", "1,5"], ["x & y <z> \"q\" 'r'", "999999999999999", "000", "-0"],
             ["line1\nline2", "tab\there", "emoji 😀", "control\u0001char"], ["", "", "end"], ["  keep  ", "0", "1000000000000000", "12 34"]]
    wide = [[f"c{j}" for j in range(40)]]; many = [[str(i), f"dòng {i}", "x" * 50, str(i * 7), ""] for i in range(1000)]
    sheet_names = ["Số liệu", "a/b:c*d?e[f]g", "A" * 40, "a/b:c*d?e[f]g", "Sheet", "sheet", "'quoted'", "", "x" * 31, "x" * 31, "  '  Z"]
    sheets = [(sheet_names[0], rows1), (sheet_names[1], wide), (sheet_names[2], many)] + [(n, [[n]]) for n in sheet_names[3:]]
    spec = []
    for n, rows in sheets:
        spec.append(f"S\t{b(n)}")
        for r in rows: spec.append("R\t" + "\t".join(b(c) for c in r) if r else "R")
    sp = wf("xlsx.spec", "\n".join(spec).encode()); out = P("t.xlsx"); r = last(cls, "xlsx", out, sp); check(r == "done", "(D1) ghi XLSX 11 sheet: " + r)
    import warnings
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        try: wb = openpyxl.load_workbook(out); okl = True
        except Exception as ex: okl = False; wb = None; print("   ", ex)
    check(okl and not caught, "(D1) openpyxl mở được sổ làm việc, KHÔNG cảnh báo gì (trước phiên 26: 'no default style')" + ("" if not caught else f": {[str(w.message)[:60] for w in caught]}"))
    if not okl: return
    want_names, taken = [], []
    for n, _ in sheets: s = model_sheet(n, taken); want_names.append(s); taken.append(s)
    check(wb.sheetnames == want_names, f"(D2) tên sheet hợp lệ, không trùng (không phân biệt hoa thường), <= 31 ký tự: {wb.sheetnames}" + ("" if wb.sheetnames == want_names else f" != {want_names}"))
    ws = wb[want_names[0]]; g = lambda a: ws[a].value
    typed = {"B2": 42, "B3": -17, "C3": 7, "B4": 999999999999999, "B7": 0}
    texts = {"C2": "0912345678", "D2": "1.234", "D3": "1,5", "C4": "000", "D4": "-0", "A4": "x & y <z> \"q\" 'r'", "A5": "line1\nline2", "B5": "tab\there", "C5": "emoji 😀", "D5": "controlchar", "C7": "1000000000000000", "D7": "12 34", "A7": "  keep  ", "C6": "end"}
    badt = [(k, g(k), v) for k, v in typed.items() if g(k) != v or ws[k].data_type != "n"]; badx = [(k, g(k), v) for k, v in texts.items() if g(k) != v]
    check(not badt, "(D3) số nguyên (<= 15 chữ số, kể cả âm, có khoảng trắng hai đầu) là ô SỐ" + ("" if not badt else f": {badt}"))
    check(not badx, "(D3) CHỮ giữ nguyên: số 0 đầu, dấu chấm / phẩy phân cách, '-0', 16 chữ số, & < > \" ', xuống dòng, tab, emoji, khoảng trắng đầu/cuối; ký tự điều khiển bị bỏ" + ("" if not badx else f": {badx}"))
    check(g("A6") in (None, "") and g("B6") in (None, ""), "(D3) ô rỗng không thành chữ")
    wsw = wb[want_names[1]]; check(wsw["AN1"].value == "c39" and wsw["AA1"].value == "c26" and wsw.max_column == 40, f"(D4) 40 cột (AA, AN...): AN1={wsw['AN1'].value}")
    wsm = wb[want_names[2]]; check(wsm.max_row == 1000 and wsm["A1000"].value == 999 and wsm["D1000"].value == 6993 and wsm["B500"].value == "dòng 499" and wsm["C1"].value == "x" * 50, "(D5) 1 000 dòng x 5 cột: giá trị cuối / giữa / số đúng")
    import zipfile as zf; from lxml import etree
    with zf.ZipFile(out) as z:
        okx = all(etree.fromstring(z.read(n)) is not None for n in z.namelist() if n.endswith(".xml") or n.endswith(".rels"))
        check(z.testzip() is None and "[Content_Types].xml" in z.namelist() and okx, "(D6) ZIP nguyên vẹn, mọi phần XML đều là XML hợp lệ")
    spec2 = wf("xlsx0.spec", b""); out0 = P("empty.xlsx"); last(cls, "xlsx", out0, spec2); check(len(openpyxl.load_workbook(out0).sheetnames) == 1 and openpyxl.load_workbook(out0).sheetnames == ["Sheet1"], "(D7) không có sheet nào -> một sheet 'Sheet1'")
    cols = [(0, "A"), (25, "Z"), (26, "AA"), (27, "AB"), (51, "AZ"), (52, "BA"), (701, "ZZ"), (702, "AAA")]; bad = [(i, last(cls, "xlsx-col", i), e) for i, e in cols if last(cls, "xlsx-col", i) != e]; check(not bad, f"(D8) columnName: sai {bad}")
    nums = {"0": "0", "-0": "-", "007": "-", "12": "12", " 12 ": "12", "1.5": "-", "1,5": "-", "+5": "-", "999999999999999": "999999999999999", "1000000000000000": "-", "-1": "-1", "": "-", "1e3": "-"}
    bad = [(k, last(cls, "xlsx-num", b(k)), e) for k, e in nums.items() if last(cls, "xlsx-num", b(k)) != e]; check(not bad, f"(D9) asNumber: sai {bad}")

# ------------------------------------------------------------------------------------------------------------------------------ E. PPTX
def group_pptx(cls):
    from pptx import Presentation
    from PIL import Image
    sizes = [(800, 600), (600, 900), (1000, 1000), (3000, 1000)]; jp = []
    for i, (w, h) in enumerate(sizes):
        im = Image.new("RGB", (w, h), (i * 60, 100, 200 - i * 40)); buf = io.BytesIO(); im.save(buf, "JPEG", quality=70); jp.append(buf.getvalue())
    alts = ['Trang 1: "báo cáo" & <ghi chú>', "Trang 2", "", "Rộng 3:1"]; args = [f"{w}:{h}:{b(a)}:{wf(f'pp{i}.jpg', jp[i])}" for i, ((w, h), a) in enumerate(zip(sizes, alts))]
    out = P("t.pptx"); r = last(cls, "pptx", out, *args); check(r == "done", "(E1) ghi PPTX 4 trang: " + r)
    prs = Presentation(out); L = 12_192_000; w0, h0 = sizes[0]; wantsz = (L, L * h0 // w0) if w0 >= h0 else (L * w0 // h0, L)
    check((prs.slide_width, prs.slide_height) == wantsz, f"(E2) khổ trang theo ảnh đầu (cạnh dài {L} EMU): {(prs.slide_width, prs.slide_height)} = {wantsz}")
    check(len(prs.slides) == 4, f"(E2) python-pptx đọc đủ {len(prs.slides)} trang")
    bad = []
    for i, slide in enumerate(prs.slides):
        pics = [s for s in slide.shapes if s.shape_type == 13]; w, h = sizes[i]
        if len(pics) != 1: bad.append((i + 1, "số ảnh", len(pics))); continue
        p = pics[0]
        if w * prs.slide_height >= h * prs.slide_width: cx = prs.slide_width; cy = max(1, prs.slide_width * h // w)
        else: cy = prs.slide_height; cx = max(1, prs.slide_height * w // h)
        wx, wy = (prs.slide_width - cx) // 2, (prs.slide_height - cy) // 2
        if (p.left, p.top, p.width, p.height) != (wx, wy, cx, cy): bad.append((i + 1, (p.left, p.top, p.width, p.height), (wx, wy, cx, cy)))
        if p.image.blob != jp[i]: bad.append((i + 1, "ảnh khác byte"))
        descr = p._element.xpath(".//p:cNvPr/@descr")[0]
        if descr != alts[i]: bad.append((i + 1, "alt", descr, alts[i]))
    check(not bad, "(E3) mỗi trang: ảnh vừa khung, GIỮ TỈ LỆ, căn giữa (đúng từng EMU), ảnh nguyên byte, chữ thay thế đúng (kể cả dấu \" & <)" + ("" if not bad else f": {bad[:3]}"))
    bad = [(w, h) for w, h in [(800, 600), (600, 800), (1, 1), (5000, 1), (1, 5000)] if tuple(int(x) for x in last(cls, "pptx-size", w, h).split(" ")) != ((L, max(1, L * h // w)) if w >= h else (max(1, L * w // h), L))]
    check(not bad, f"(E4) slideSize: sai {bad}")
    import zipfile as zf
    with zf.ZipFile(out) as z: check(z.testzip() is None and len([n for n in z.namelist() if n.startswith("ppt/media/")]) == 4, "(E5) ZIP nguyên vẹn, 4 ảnh trong ppt/media")

MUTANTS = [
    (1, "ZipPack.kt", "private const val PBKDF2_ITERATIONS = 1000", "private const val PBKDF2_ITERATIONS = 1001", "A"),
    (2, "ZipPack.kt", "val pw = password.toByteArray(StandardCharsets.UTF_8)", "val pw = password.toByteArray(StandardCharsets.ISO_8859_1)", "A"),
    (3, "QrEncoder.kt", "LOW(0, 1), MEDIUM(1, 0)", "LOW(0, 0), MEDIUM(1, 1)", "C"),
    (4, "XlsxWriter.kt", "        if (t == \"-0\") return null\n", "", "D"),
    (5, "PptxWriter.kt", "return longArrayOf((slideCx - cx) / 2, (slideCy - cy) / 2, cx, cy)", "return longArrayOf(0L, 0L, cx, cy)", "E"),
    (6, "TiffWriter.kt", "Math.round(widthPx * 72f / widthPoints).coerceAtLeast(1)", "(widthPx * 72f / widthPoints).toInt().coerceAtLeast(1)", "B"),
    (7, "XlsxWriter.kt", "<cellStyles count=\\\"1\\\"><cellStyle name=\\\"Normal\\\" xfId=\\\"0\\\" builtinId=\\\"0\\\"/></cellStyles></styleSheet>", "</styleSheet>", "D"),   # the fix of phiên 26 put back
]
GROUPS = {"A": group_zip, "B": group_tiff, "C": group_qr, "D": group_xlsx, "E": group_pptx}

def main():
    args = sys.argv[1:]; fast = "--fast" in args; only = [int(a.split("=")[1]) for a in args if a.startswith("--mutant=")]
    if not only:
        cls = build()
        for g, fn in GROUPS.items(): print(f"== nhóm {g}"); fn(cls)
    if not fast:
        print("== THỬ ÂM TÍNH: mỗi bản mã bị làm hỏng PHẢI bị bắt")
        import contextlib
        for n, fname, old, new, g in MUTANTS:
            if only and n not in only: continue
            before = len(fails); cls = build({fname: (old, new)}, f"m{n}"); buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                try: GROUPS[g](cls)
                except SystemExit as e: print("LOI harness " + str(e)[:80])
                except Exception as e: print("LOI ngoại lệ " + repr(e)[:80])
            caught = [l for l in buf.getvalue().splitlines() if l.startswith("LOI")]; del fails[before:]
            check(len(caught) > 0, f"bản hỏng {n} ({fname}: {new.strip()[:55]!r}) bị bắt bởi {len(caught)} phép kiểm")
    print("\nTAT CA DAT" if not fails else f"\n{len(fails)} LOI: " + "; ".join(fails[:4])); sys.exit(1 if fails else 0)

main()
