"""Kiểm chứng việc dùng PageOrientation cho ẢNH THẺ (phiên 15): tự xoay đúng chiều có đáng tin trên ảnh thẻ (ít dòng, chữ nhỏ) không?

PageOrientation (bản Python song song: orientation_check.detect) đã được kiểm trên TRANG văn bản (480 trang, 0 sai). Thẻ CCCD/GPLX khác trang:
chỉ 5-8 dòng chữ ngắn, có ô ảnh chân dung, nhiều dòng IN HOA. Script này dựng ảnh thẻ giả (1011 x 638 px = 85,6 x 54 mm ở 300 dpi) với nội dung kiểu CCCD
(Họ tên IN HOA, ngày sinh, giới tính, quốc tịch, quê quán, nơi thường trú), xoay 0/90/180/270 độ, thêm nghiêng nhẹ và nhiễu, rồi đo:
  - đúng / từ chối (không chắc) / SAI. SAI phải bằng 0: một lần tự xoay nhầm tệ hơn không xoay.
Kết quả quyết định thiết kế: IdCardComposer chỉ tự xoay khi detect trả về một số; khi từ chối thì hỏi người dùng (nút "Xoay 180°").
Chạy: python3 card_orientation_check.py   (cần cv2, numpy, pillow)
"""
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
import cv2, numpy as np
from PIL import Image, ImageDraw, ImageFont
from orientation_check import detect, FONTS

W, H = 1011, 638
CARD_VI = [
    ("CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", 20, True),
    ("Độc lập - Tự do - Hạnh phúc", 18, False),
    ("CĂN CƯỚC CÔNG DÂN", 26, True),
    ("Họ và tên / Full name:", 18, False),
    ("NGUYỄN VĂN AN", 28, True),
    ("Ngày sinh / Date of birth: 12/03/1990", 20, False),
    ("Giới tính / Sex: Nam   Quốc tịch: Việt Nam", 20, False),
    ("Quê quán / Place of origin: Xã Tân Hưng, Huyện Châu Thành, Tiền Giang", 18, False),
    ("Nơi thường trú / Place of residence: Phường Bến Nghé, Quận 1, TP Hồ Chí Minh", 18, False),
]
CARD_LICENSE = [
    ("GIẤY PHÉP LÁI XE / DRIVER'S LICENSE", 24, True),
    ("Số / No: 790123456789", 22, False),
    ("Họ tên / Name: Trần Thị Bích Ngọc", 22, False),
    ("Sinh ngày / Date of birth: 05/11/1988", 22, False),
    ("Nơi cư trú / Address: Quận Hải Châu, Đà Nẵng", 20, False),
    ("Hạng / Class: B2     Có giá trị đến / Expires: 05/11/2033", 20, False),
]


def make_card(spec, font_path, seed):
    rng = np.random.default_rng(seed)
    img = Image.new("L", (W, H), 232)
    d = ImageDraw.Draw(img)
    d.rectangle((40, 150, 260, 420), fill=140)                 # ô ảnh chân dung (khối xám)
    y = 40
    for text, size, _bold in spec:
        f = ImageFont.truetype(font_path, size)
        x = 300 if y > 120 else 80
        d.text((x, y), text, fill=30, font=f)
        y += int(size * 1.9) + 14
    a = np.array(img).astype(np.float32)
    a += rng.normal(0, 6, a.shape)
    a = np.clip(a, 0, 255).astype(np.uint8)
    skew = rng.uniform(-2.0, 2.0)
    M = cv2.getRotationMatrix2D((W / 2, H / 2), skew, 1.0)
    return cv2.warpAffine(a, M, (W, H), borderValue=232)


def main():
    codes = {0: None, 90: cv2.ROTATE_90_CLOCKWISE, 180: cv2.ROTATE_180, 270: cv2.ROTATE_90_COUNTERCLOCKWISE}
    # ảnh xoay r độ theo chiều KIM ĐỒNG HỒ thì phải xoay NGƯỢC chiều kim đồng hồ r độ để thẳng -> detect mong đợi r
    total = correct = declined = wrong = 0
    by_rot = {r: [0, 0, 0] for r in codes}
    for fname, fpath in list(FONTS.items())[:4]:
        for si, spec in enumerate((CARD_VI, CARD_LICENSE)):
            for seed in range(6):
                base = make_card(spec, fpath, seed * 10 + si)
                for rot, code in codes.items():
                    g = base if code is None else cv2.rotate(base, code)
                    deg, why = detect(g)
                    total += 1
                    if deg is None:
                        declined += 1; by_rot[rot][1] += 1
                    elif deg == rot:
                        correct += 1; by_rot[rot][0] += 1
                    else:
                        wrong += 1; by_rot[rot][2] += 1
                        print("SAI", fname, si, seed, "xoay", rot, "nhận", deg, why)
    print(f"TỔNG {total} ảnh thẻ giả: đúng {correct} ({100 * correct / total:.0f}%), từ chối {declined} ({100 * declined / total:.0f}%), SAI {wrong}")
    for r, (c, d, w) in by_rot.items():
        print(f"  xoay {r:3d}°: đúng {c}, từ chối {d}, sai {w}")
    ok = wrong == 0
    print("TAT CA DAT (không có lần nào sai)" if ok else "CO LOI: tự xoay nhầm trên ảnh thẻ")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
