"""Kotlin: `this` bị đổi nghĩa trong khối `X(...).apply { }` / `.run { }` (phiên 23, mục 4.57).
Lỗi thật làm đỏ CI #28: `PdfSignActivity.kt:270 Argument type mismatch: actual type is 'FrameLayout', but 'Context!' was expected` - tôi viết `Button(this)` BÊN TRONG
`FrameLayout(this).apply { ... }`; trong khối apply, `this` là cái FrameLayout chứ không còn là Activity. Cần viết `this@TenActivity`.
Bộ kiểm quét mọi `.kt`: với mỗi khối `<Kiểu>(...).apply {` / `.run {` mà bộ khởi tạo bắt đầu bằng tên kiểu viết hoa, tìm bên trong lời gọi truyền `this` TRẦN làm đối số
(`Tên(this)`, `Tên(this, ...)`, `f(x, this)`), kể cả trong lambda lồng nhau. `this@X` và `this.thuộc_tính` không bị báo. Khối `apply` của Intent / Bundle... cũng đổi `this`, nên cũng được soi.
`--selftest` kiểm chính logic (có ca tái hiện đúng lỗi #28 và các ca không được báo nhầm)."""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
HERE = os.path.dirname(os.path.abspath(__file__)); SRC = os.path.join(HERE, "..", "..", "app", "src", "main", "java")

from kotlin_strip import strip   # bộ quét một lượt dùng chung (mục 4.57)

START = re.compile(r"\b(?:[\w.]*\.)?([A-Z]\w*)\s*\((?:[^(){}\n]|\([^(){}\n]*\))*\)\s*\.(apply|run)\s*\{")   # tham số trong MỘT dòng, không chứa {} (tránh nuốt cả đoạn mã)
BARE = re.compile(r"(?<![@\w.])this(?![@\w.])")


def _wants_context(body, pos):
    """True nếu `this` (ở vị trí pos) là đối số của lời gọi có tên bắt đầu bằng chữ HOA (Button(this), Toast.makeText(this, ..), TagStore.all(this)): các hàm đó đòi Context.
    Lời gọi viết thường như container.removeView(this) / box.addView(this) truyền chính View nên hợp lệ."""
    depth = 0; i = pos - 1
    while i >= 0:                       # lùi tới dấu '(' mở của lời gọi chứa this
        c = body[i]
        if c == ")": depth += 1
        elif c == "(":
            if depth == 0: break
            depth -= 1
        i -= 1
    if i < 0: return False
    m = re.search(r"([\w.]+)\s*$", body[:i])
    if not m: return False
    callee = m.group(1)
    return any(seg[:1].isupper() for seg in callee.split("."))          # android.widget.Button, Toast.makeText, AlertDialog.Builder; không phải container.removeView

def scan(src):
    """-> [(dòng, kiểu khởi tạo, ngữ cảnh)]"""
    s = strip(src); out = []
    for m in START.finditer(s):
        i = m.end(); depth = 1
        while i < len(s) and depth:
            if s[i] == "{": depth += 1
            elif s[i] == "}": depth -= 1
            i += 1
        body = s[m.end():i - 1]
        for b in BARE.finditer(body):
            # chỉ tính khi `this` là ĐỐI SỐ của một lời gọi: ngay trước là '(' hoặc ',' (sau khoảng trắng) và ngay sau là ')' hoặc ','
            before = body[:b.start()].rstrip(); after = body[b.end():].lstrip()
            if before[-1:] in "(," and after[:1] in ")," and _wants_context(body, b.start()):
                line = s.count("\n", 0, m.end() + b.start()) + 1
                ctx = body[max(0, b.start() - 30):b.end() + 12].replace("\n", " ").strip()
                out.append((line, m.group(1), ctx))
    return out

def selftest():
    ok = True
    def case(name, src, want):
        nonlocal ok
        got = len(scan(src)); good = (got > 0) == want; ok &= good
        print(("ok   " if good else "LOI  ") + name + ("" if good else f"  (có {got})"))
    case("TÁI HIỆN lỗi #28: Button(this) trong FrameLayout(this).apply", "class A {\n  fun f() {\n    val frame = FrameLayout(this).apply {\n      val undo = android.widget.Button(this).apply { setText(1) }\n      addView(undo)\n    }\n  }\n}", True)
    case("đã sửa bằng this@A -> không báo", "class A {\n  fun f() {\n    val frame = FrameLayout(this).apply {\n      val undo = Button(this@A).apply { setText(1) }\n    }\n  }\n}", False)
    case("khối apply không dùng this làm đối số -> không báo", "class A {\n  fun f() {\n    val e = EditText(this).apply {\n      setHint(1)\n      setSingleLine()\n    }\n  }\n}", False)
    case("this.thuộc_tính hoặc this làm vế trái -> không báo", "class A {\n  fun f() {\n    val e = Foo(this).apply {\n      this.visibility = 1\n      this.setText(2)\n    }\n  }\n}", False)
    case("Intent(this, X) trong apply của View -> báo", "class A {\n  fun f() {\n    val v = TextView(this).apply {\n      setOnClickListener { startActivity(Intent(this, B::class.java)) }\n    }\n  }\n}", True)
    case("hàm viết thường nhận this (bar(1, this)) có thể là View -> không báo", "class A {\n  fun f() {\n    val v = Foo(this).apply {\n      x = bar(1, this)\n    }\n  }\n}", False)
    case("apply trên Intent không có this bên trong -> không báo", "class A {\n  fun f() {\n    val i = Intent(this, B::class.java).apply {\n      putExtra(\"a\", 1)\n    }\n  }\n}", False)
    case("this trong chuỗi / chú thích -> không báo", "class A {\n  fun f() {\n    val v = Foo(this).apply {\n      // Button(this)\n      x = \"Button(this)\"\n    }\n  }\n}", False)
    case("lồng hai tầng apply, this ở tầng trong -> báo", "class A {\n  fun f() {\n    val a = LinearLayout(this).apply {\n      val b = FrameLayout(this@A).apply {\n        addView(Button(this))\n      }\n    }\n  }\n}", True)
    case("container.removeView(this) trong ImageView.apply là hợp lệ -> không báo", "class A {\n  fun f(container: ViewGroup) {\n    val v = ImageView(this).apply {\n      container.removeView(this)\n    }\n  }\n}", False)
    case("box.addView(this) trong EditText.apply là hợp lệ -> không báo", "class A {\n  fun f(box: ViewGroup) {\n    val v = EditText(this).apply {\n      box.addView(this)\n    }\n  }\n}", False)
    case("Toast.makeText(this, ..) trong apply của View -> báo", "class A {\n  fun f() {\n    val v = Foo(this).apply {\n      Toast.makeText(this, 1, 0).show()\n    }\n  }\n}", True)
    case("TagStore.all(this) trong apply của View -> báo", "class A {\n  fun f() {\n    val v = Foo(this).apply {\n      val t = TagStore.all(this)\n    }\n  }\n}", True)
    case("ký tự '}' trong mã không làm lệch bộ đếm khối", "class A {\n  fun f() {\n    val v = Foo(this).apply { x = '}' }\n    val w = Button(this)\n    g(this)\n  }\n}", False)
    print(); print("TAT CA DAT" if ok else "CO LOI"); return 0 if ok else 1

def main():
    if "--selftest" in sys.argv: return selftest()
    bad = []; n = 0
    for dp, _, fs in os.walk(SRC):
        for f in fs:
            if not f.endswith(".kt"): continue
            n += 1
            for line, kind, ctx in scan(open(os.path.join(dp, f), encoding="utf-8").read()):
                bad.append(f"{f}:{line}: trong khối {kind}(...).apply/run có `{ctx}` - `this` là {kind}, không phải Activity; dùng this@TenActivity")
    for b in bad: print("LOI  " + b)
    print(f"đã quét {n} tệp .kt")
    print("TAT CA DAT" if not bad else f"CO {len(bad)} LOI"); return 1 if bad else 0
if __name__ == "__main__": sys.exit(main())
