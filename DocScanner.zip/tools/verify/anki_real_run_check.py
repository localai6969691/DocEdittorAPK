#!/usr/bin/env python3
"""Thẻ học Anki (`util/AnkiDeck.kt`; phiên 26, TECHNICAL_DOCS.md 4.86): mã Kotlin thật chạy bằng kotlinc, kết quả được NHẬP VÀO ANKI THẬT (thư viện `anki` của chính Anki, cùng lõi Rust với ứng dụng).

Mục 10.15 của PDF "Thiếu gì để bán app": xuất Anki (.apkg) / Quizlet / CSV cho flashcard. Phần SQLite trong app chạy qua `SQLiteDatabase.execSQL` (Android); ở đây CÙNG danh sách câu lệnh `AnkiDeck.statements`
chạy qua `sqlite3` của Python, rồi `AnkiDeck.pack` nén thành gói. Bộ kiểm đo bằng Anki, không phải bằng mô hình của dự án:
  A. NHẬN DIỆN THẺ: 30 ca viết tay (`::`, TAB, `=>`, Q/A một dòng và nhiều dòng, Hỏi/Đáp, Câu hỏi/Trả lời, "thuật ngữ: nghĩa", " - ", " – ", đánh số / gạch đầu dòng, trùng đầu thẻ, và những dòng KHÔNG được coi là thẻ:
     câu thường có dấu hai chấm, URL, giờ "10:30" là số, dòng quá dài), giới hạn 2 000 thẻ;
  B. TSV: Anki đọc phần đầu (`#separator`, `#html`, `#tags column`) đúng và `import_csv` ra ĐÚNG trường / thẻ, kể cả dấu TAB, xuống dòng, `<`, `&`, dấu nháy kép, tiếng Việt, emoji và đầu thẻ bắt đầu bằng `#`;
  C. .APKG: `import_anki_package` nhập đủ ghi chú và thẻ, đúng bộ bài (tên tiếng Việt), kiểu ghi chú "Basic (DocScanner)" với hai trường Front / Back, thẻ DocScanner, thẻ mới theo thứ tự, `fix_integrity` không báo lỗi,
     nhập LẠI cùng gói không nhân đôi, hai bộ bài dùng chung một kiểu ghi chú; mã kiểm tra trường và GUID khớp `anki.utils.field_checksum`.
THỬ ÂM TÍNH: 8 bản mã bị làm hỏng (cắt sai mã kiểm tra, GUID trùng nhau, không thoát `<`, thuật ngữ dài vô hạn, không có `media` trong gói, `due` sai thứ tự, và hai bản vá của phiên 26 đặt lại như cũ:
đầu thẻ `#` bị mất, "Q:" không đáp án thành thẻ) PHẢI bị bắt.
KHÔNG kiểm được: giao diện AnkiDroid / Anki desktop, `SQLiteDatabase.execSQL` của Android (phần mỏng nối trong `AnkiExporter.kt`). Chạy: python3 tools/verify/anki_real_run_check.py [--fast]   (--mutant=N, 1-8)"""
import base64, hashlib, os, random, re, sqlite3, subprocess, sys, tempfile, zipfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
import anki.lang  # noqa: E402
anki.lang.set_lang("en")
from anki.collection import Collection, ImportCsvRequest, ImportAnkiPackageRequest, ImportAnkiPackageOptions  # noqa: E402
from anki.utils import field_checksum  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="anki-")
HARNESS = os.path.join(HERE, "real_run", "AnkiHarness.kt")
def build(mutate=None, tag="base"): return tc.compile(["AnkiDeck.kt"], [HARNESS], os.path.join(WORK, "cls-" + tag), mutate)[0]
b = lambda s: base64.b64encode(s.encode()).decode(); u = lambda s: base64.b64decode(s).decode()
def hz(cls, *args):
    r = tc.run(cls, "AnkiHarnessKt", [str(a) for a in args])
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-800:])
    return r.stdout.strip("\n").split("\n") if r.stdout.strip() else []
def P(n): return os.path.join(WORK, n)

# ------------------------------------------------------------------------------------------------------------------------------ A. extraction
LONG_SENTENCE = "Đây là một câu bình thường có dấu hai chấm: phần trước dấu hai chấm này quá dài để làm thuật ngữ của một thẻ"
CASES = [
    ("Mitochondria :: powerhouse of the cell", [("Mitochondria", "powerhouse of the cell")]),
    ("Osmosis\tmovement of water", [("Osmosis", "movement of water")]),
    ("H2O => water", [("H2O", "water")]), ("Paris → capital of France", [("Paris", "capital of France")]),
    ("Q: What is DNA? A: Genetic material", [("What is DNA?", "Genetic material")]),
    ("Q: Capital of France?\nA: Paris\n\nQ: 2+2?\nA: 4", [("Capital of France?", "Paris"), ("2+2?", "4")]),
    ("Hỏi: Thủ đô của Việt Nam?\nĐáp: Hà Nội", [("Thủ đô của Việt Nam?", "Hà Nội")]),
    ("Câu hỏi: Ai viết Truyện Kiều?\nTrả lời: Nguyễn Du", [("Ai viết Truyện Kiều?", "Nguyễn Du")]),
    ("Question: Boiling point of water?\nAnswer: 100 C\nat sea level\n\nnext", [("Boiling point of water?", "100 C at sea level")]),
    ("Frage: Hauptstadt?\nAntwort: Berlin", [("Hauptstadt?", "Berlin")]),
    ("Photosynthesis: the process by which plants make food", [("Photosynthesis", "the process by which plants make food")]),
    ("ATP - adenosine triphosphate", [("ATP", "adenosine triphosphate")]), ("ATP – energy currency of the cell", [("ATP", "energy currency of the cell")]),
    ("1. Osmosis - movement of water", [("Osmosis", "movement of water")]), ("• Enzyme: protein that speeds up a reaction", [("Enzyme", "protein that speeds up a reaction")]),
    ("- Gen :: đơn vị di truyền", [("Gen", "đơn vị di truyền")]),
    ("Cat :: mèo\ncat :: con mèo\nDog :: chó", [("Cat", "mèo"), ("Dog", "chó")]),
    ("Term one :: a\n\n\nTerm two :: b", [("Term one", "a"), ("Term two", "b")]),
    (LONG_SENTENCE, []), ("Visit https://example.com/path for more", []), ("http://example.com", []), ("Time: 10:30", [("Time", "10:30")]),
    ("10: 20", []), ("Note.", []), ("Is this a question? yes it is", []), ("a - b", []), ("x" * 300 + " :: y", []),
    ("Word one two three four five six: too many words for a term here", []), ("", []), ("   \n\n  ", []),
    ("Q: Missing answer here\nnothing relevant\nstill nothing\nnope\nthis is far away", []),
]
def group_extract(cls):
    bad = []
    for text, want in CASES:
        got = [(u(l.split(" ")[0]), u(l.split(" ")[1])) for l in hz(cls, "cards", b(text))]
        if got != want: bad.append((text[:40], got, want))
    check(not bad, f"(A1) {len(CASES)} ca nhận diện thẻ đúng như đặc tả" + ("" if not bad else f": {bad[:3]}"))
    many = "\n".join(f"Term{i} :: meaning {i}" for i in range(2500)); n = len(hz(cls, "cards", b(many)))
    check(n == 2000, f"(A2) tối đa 2 000 thẻ: {n}")
    pages = "\n".join(["Alpha :: one", "Beta :: two", "Alpha :: dup", "Gamma: three"]); got = [u(l.split(" ")[0]) for l in hz(cls, "cards", b(pages))]
    check(got == ["Alpha", "Beta", "Gamma"], f"(A3) thứ tự giữ nguyên, trùng đầu thẻ bỏ: {got}")
    check(hz(cls, "split", b("a: b")) == ["-"] or True, "(A4) (thông tin)")

# ------------------------------------------------------------------------------------------------------------------------------ B. TSV
TRICKY = [("Term one", "Meaning <b>1</b>"), ("Line1\nLine2", "back & forth"), ("tab\there", "quote \"x\" and 'y'"), ("#hashtag first", "begins with a hash"), ("\"quoted front\"", "plain"),
          ("Vietnamese: Nguyễn Văn A", "đ ơ ư ă â ê ô"), ("emoji 😀", "ok 🎉"), ("a < b > c", "x &amp; y"), ("  spaced  ", "also  spaced  "), ("last", "line")]
def esc(s): return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\r\n", "\n").replace("\r", "\n").replace("\n", "<br>")
def write_cards(path, cards): open(path, "w").write("\n".join(f"{b(f)} {b(k)}" for f, k in cards) + "\n")

def group_tsv(cls):
    cf = P("tsv-cards.txt"); write_cards(cf, TRICKY); text = u(hz(cls, "tsv", cf)[-1]); p = P("deck.txt"); open(p, "w", encoding="utf-8").write(text)
    check(text.startswith("#separator:tab\n#html:true\n#tags column:3\n") and text.count("\n") == 3 + len(TRICKY), "(B1) đầu tệp + một dòng cho mỗi thẻ, không dòng thừa (TAB / xuống dòng trong trường không tách dòng)")
    col = Collection(P("csv.anki2")); meta = col.get_csv_metadata(p, None)
    check(meta.delimiter == 0 and meta.is_html and meta.tags_column == 3 and len(meta.column_labels) == 3, f"(B2) Anki đọc đúng phần đầu: tab, HTML, cột thẻ = 3, 3 cột (delimiter={meta.delimiter}, html={meta.is_html}, tags={meta.tags_column}, cột={len(meta.column_labels)})")
    meta.deck_id = 1; meta.global_notetype.id = col.models.by_name("Basic")["id"]; meta.global_notetype.field_columns[:] = [1, 2]
    log = col.import_csv(ImportCsvRequest(path=p, metadata=meta)); notes = [col.get_note(n) for n in col.find_notes("")]
    got = sorted((n.fields[0], n.fields[1], tuple(n.tags)) for n in notes); want = sorted((esc(f).replace("\t", " ").replace('"', "&quot;") if False else esc(f).replace("\t", " "), esc(k).replace("\t", " "), ("DocScanner",)) for f, k in TRICKY)
    # a leading '#' and a leading quote are protected by character references; compare after decoding them the way a card shows them
    import html as H
    norm = lambda t: sorted((H.unescape(x[0]).replace("<br>", "\n"), H.unescape(x[1]).replace("<br>", "\n"), x[2]) for x in t)
    wantn = sorted((f.replace("\t", " "), k.replace("\t", " "), ("DocScanner",)) for f, k in TRICKY)
    gotn = sorted((H.unescape(a.replace("<br>", "\n")), H.unescape(b_.replace("<br>", "\n")), t) for a, b_, t in got)
    check(len(log.log.new) == len(TRICKY) and len(notes) == len(TRICKY), f"(B3) import_csv của Anki nhập đủ {len(notes)}/{len(TRICKY)} thẻ (kể cả đầu thẻ '#hashtag' và '\"quoted\"')")
    check(gotn == wantn, "(B3) mọi trường đúng nội dung sau khi giải mã HTML (TAB -> khoảng trắng, xuống dòng, < & \", tiếng Việt, emoji)" + ("" if gotn == wantn else f": {[x for x in gotn if x not in wantn][:2]} vs {[x for x in wantn if x not in gotn][:2]}"))
    col.close()

# ------------------------------------------------------------------------------------------------------------------------------ C. apkg
def build_collection(cls, cards, deck, now_ms, tag):
    cf = P(f"{tag}-cards.txt"); write_cards(cf, cards); sf = P(f"{tag}-stmts.txt"); hz(cls, "stmts", cf, b(deck), now_ms, sf)
    db = P(f"{tag}.anki2")
    if os.path.exists(db): os.remove(db)
    con = sqlite3.connect(db)
    for line in open(sf).read().split("\n"):
        t = line.split("\t"); sql = u(t[0]); args = [int(a[2:]) if a.startswith("i:") else u(a[2:]) for a in t[1:]]; con.execute(sql, args)
    con.commit(); con.close(); apkg = P(f"{tag}.apkg"); hz(cls, "pack", db, apkg); return apkg

def group_apkg(cls):
    rnd = random.Random(8); words = ["tế bào", "ti thể", "DNA", "quang hợp", "enzym", "photosynthesis", "ATP", "gen", "protein", "ribosome"]
    cards = [(f"{rnd.choice(words)} #{i} <{i}> & \"q\"", f"Định nghĩa số {i}\nxuống dòng {rnd.randint(0, 99)} 😀") for i in range(300)] + TRICKY
    deck = "Sinh học — chương 1 (bản scan)"; apkg = build_collection(cls, cards, deck, 1_700_000_000_000, "pk")
    with zipfile.ZipFile(apkg) as z: names = sorted(z.namelist()); media = z.read("media") if "media" in names else None
    check(names == ["collection.anki2", "media"] and media == b"{}", f"(C1) gói .apkg: collection.anki2 + media '{{}}': {names}")
    col = Collection(P("imp.anki2")); log = col.import_anki_package(ImportAnkiPackageRequest(package_path=apkg, options=ImportAnkiPackageOptions()))
    n_notes, n_cards = col.note_count(), col.card_count()
    check(len(log.log.new) == len(cards) and n_notes == len(cards) and n_cards == len(cards), f"(C2) Anki nhập đủ {n_notes} ghi chú / {n_cards} thẻ (mong đợi {len(cards)})")
    decks = [d["name"] for d in col.decks.all()]
    check(deck in decks, f"(C3) bộ bài tên tiếng Việt '{deck}' có trong Anki: {decks}")
    did = col.decks.id(deck, create=False); in_deck = len(col.find_cards(f'deck:"{deck}"'))
    check(in_deck == len(cards), f"(C3) cả {in_deck} thẻ nằm trong bộ bài đó")
    nt = col.models.by_name("Basic (DocScanner)"); check(nt is not None and [f["name"] for f in nt["flds"]] == ["Front", "Back"] and len(nt["tmpls"]) == 1, "(C4) kiểu ghi chú 'Basic (DocScanner)': trường Front, Back, một mẫu thẻ")
    ids = col.find_notes(""); expect = {esc(f) + "\x1f" + esc(k) for f, k in cards}; seen = set()
    bad_tags = 0
    for nid in ids:
        n = col.get_note(nid); seen.add("\x1f".join(n.fields)); bad_tags += n.tags != ["DocScanner"]
    check(seen == expect, "(C5) mọi ghi chú có đúng hai trường (HTML đã thoát; xuống dòng -> <br>)" + ("" if seen == expect else f": thiếu {len(expect - seen)}, thừa {len(seen - expect)}"))
    check(bad_tags == 0, "(C5) mọi ghi chú có thẻ 'DocScanner'")
    ctypes = col.db.all("select type, queue from cards"); check(all(t == (0, 0) or tuple(t) == (0, 0) for t in ctypes), "(C6) mọi thẻ là thẻ MỚI chưa học (type 0, queue 0)")
    dues = col.db.list("select c.due from cards c join notes n on n.id=c.nid order by n.id"); check(dues == list(range(1, len(cards) + 1)), "(C6) thứ tự thẻ mới theo thứ tự trong tài liệu (due 1..N)")
    problems = col.fix_integrity(); txt = problems[0] if isinstance(problems, (tuple, list)) else str(problems)
    check(not re.search(r"(?i)invalid|missing|wrong|fixed|problem|error", txt.replace("Database rebuilt and optimized", "")), f"(C7) fix_integrity của Anki không báo lỗi: {txt.strip()[:80]!r}")
    log2 = col.import_anki_package(ImportAnkiPackageRequest(package_path=apkg, options=ImportAnkiPackageOptions()))
    check(col.note_count() == len(cards) and len(log2.log.new) == 0, f"(C8) nhập LẠI cùng gói: không nhân đôi (còn {col.note_count()} ghi chú, mới {len(log2.log.new)})")
    apkg2 = build_collection(cls, cards[:20], "Bộ bài thứ hai", 1_700_000_100_000, "pk2"); col.import_anki_package(ImportAnkiPackageRequest(package_path=apkg2, options=ImportAnkiPackageOptions()))
    models = [m["name"] for m in col.models.all() if m["name"].startswith("Basic (DocScanner)")]; check(models == ["Basic (DocScanner)"], f"(C9) hai bộ bài dùng chung MỘT kiểu ghi chú: {models}")
    check("Bộ bài thứ hai" in [d["name"] for d in col.decks.all()], "(C9) bộ bài thứ hai cũng có mặt")
    col.close()
    # checksum and guid against Anki's own helpers
    rnd = random.Random(3); bad = []
    for _ in range(120):
        s = "".join(rnd.choice("abcdé ĐđơưăâêôÂ<>&;#\"'1234 \n") for _ in range(rnd.randint(0, 40))); h = esc(s)
        if hz(cls, "csum", b(h))[-1] != str(field_checksum(h)): bad.append(s[:20])
        if len(bad) > 2: break
    check(not bad, "(C10) fieldChecksum khớp anki.utils.field_checksum trên 120 chuỗi ngẫu nhiên (dấu tiếng Việt, < > & thoát HTML, xuống dòng)" + ("" if not bad else f": sai {bad}"))
    gs = [hz(cls, "guid", b(f), b(k))[-1] for f, k in cards]; check(len(set(gs)) == len(cards) and all(re.fullmatch(r"[A-Za-z0-9!#$%&()*+,\-./:;<=>?@\[\]^_`{|}~]{1,11}", g) for g in gs) and hz(cls, "guid", b("a"), b("b")) == hz(cls, "guid", b("a"), b("b")), f"(C11) GUID duy nhất, đúng bộ ký tự base-91, ổn định: mẫu {gs[0]!r}")
    did1, did2 = hz(cls, "deckid", b("A"))[-1], hz(cls, "deckid", b("B"))[-1]; check(did1 != did2 and did1 != "1" and int(did1) > 1_700_000_000_000, f"(C12) deckId theo tên, khác nhau, không phải 1 (Default): {did1}, {did2}")

MUTANTS = [
    (1, "sha1(plainText(firstField)).take(4)", "sha1(plainText(firstField)).take(3)", "C"),
    (2, "var n = sha1(front + \"\\u001f\" + back).take(8)", "var n = sha1(\"x\").take(8)", "C"),
    (3, ".replace(\"<\", \"&lt;\").replace(\">\", \"&gt;\").replace(\"\\r\\n\"", ".replace(\">\", \"&gt;\").replace(\"\\r\\n\"", "C"),
    (4, "val plausibleTerm = term.length in 1..MAX_TERM_CHARS && words <= MAX_TERM_WORDS", "val plausibleTerm = term.length in 1..5000", "A"),
    (5, "z.putNextEntry(ZipEntry(\"media\")); z.write(\"{}\".toByteArray(Charsets.UTF_8)); z.closeEntry()", "", "C"),
    (6, "nid, did, nowSec, (i + 1).toLong()", "nid, did, nowSec, (cards.size - i).toLong()", "C"),
    (7, "return if (h.startsWith(\"#\")) \"&#35;\" + h.substring(1) else h", "return h", "B"),            # the fix of phiên 26 put back: a card whose front starts with '#' is lost
    (8, "if (q == null && ANSWER.find(line) == null) {", "if (true) {", "A"),                              # the fix of phiên 26 put back: an unanswered 'Q:' became a card
]
def run_group(cls, g):
    {"A": group_extract, "B": group_tsv, "C": group_apkg}[g](cls)

def main():
    args = sys.argv[1:]; fast = "--fast" in args; only = [int(a.split("=")[1]) for a in args if a.startswith("--mutant=")]
    if not only:
        cls = build()
        for g in "ABC": print(f"== nhóm {g}"); run_group(cls, g)
    if not fast:
        print("== THỬ ÂM TÍNH: mỗi bản mã bị làm hỏng PHẢI bị bắt")
        import contextlib, io
        for n, old, new, g in MUTANTS:
            if only and n not in only: continue
            before = len(fails); cls = build({"AnkiDeck.kt": (old, new)}, f"m{n}"); buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                try: run_group(cls, g)
                except SystemExit as e: print("LOI harness " + str(e)[:80])
                except Exception as e: print("LOI ngoại lệ " + repr(e)[:80])
            caught = [l for l in buf.getvalue().splitlines() if l.startswith("LOI")]; del fails[before:]
            check(len(caught) > 0, f"bản hỏng {n} ({(new.strip() or 'xoá')[:55]!r}) bị bắt bởi {len(caught)} phép kiểm")
    print("\nTAT CA DAT" if not fails else f"\n{len(fails)} LOI: " + "; ".join(fails[:4])); sys.exit(1 if fails else 0)

main()
