import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Ban Java chay duoc cua PdfRepair.diagnose (phien 18). Chay: java PdfRepairCheck.java <tep1> <tep2> ... -> moi tep mot dong chan doan. */
public class PdfRepairCheck {
    static final int HEADER_WINDOW = 1024, TAIL_WINDOW = 2048;
    static int indexOf(byte[] hay, String needle, int from, boolean last) {
        byte[] n = needle.getBytes(StandardCharsets.ISO_8859_1);
        if (n.length == 0 || hay.length < n.length) return -1;
        if (last) { for (int i = hay.length - n.length; i >= Math.max(from, 0); i--) if (match(hay, i, n)) return i; }
        else { for (int i = Math.max(from, 0); i <= hay.length - n.length; i++) if (match(hay, i, n)) return i; }
        return -1;
    }
    static boolean match(byte[] h, int i, byte[] n) { for (int j = 0; j < n.length; j++) if (h[i + j] != n[j]) return false; return true; }
    static boolean ws(byte b) { return b == 0x20 || b == 0x0A || b == 0x0D || b == 0x09 || b == 0x0C || b == 0; }
    static boolean digit(byte b) { return b >= '0' && b <= '9'; }
    static String diagnose(File f) throws IOException {
        long size = f.length();
        try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
            byte[] head = new byte[(int) Math.min(size, HEADER_WINDOW)]; raf.readFully(head);
            int tl = (int) Math.min(size, TAIL_WINDOW); byte[] tail = new byte[tl]; raf.seek(size - tl); raf.readFully(tail);
            int headerAt = indexOf(head, "%PDF-", 0, false); if (headerAt < 0) return "NO_HEADER";
            boolean eofMissing = indexOf(tail, "%%EOF", 0, false) < 0;
            int s = indexOf(tail, "startxref", 0, true); if (s < 0) return "NO_STARTXREF";
            int i = s + 9; while (i < tail.length && ws(tail[i])) i++;
            int ds = i; long offset = 0;
            while (i < tail.length && digit(tail[i]) && offset < Long.MAX_VALUE / 20) { offset = offset * 10 + (tail[i] - '0'); i++; }
            if (i == ds) return "NO_STARTXREF";
            offset += headerAt; if (offset <= 0 || offset >= size) return "BAD_XREF_OFFSET";
            raf.seek(offset); byte[] at = new byte[(int) Math.min(64, size - offset)]; raf.readFully(at);
            int k = 0; while (k < at.length && ws(at[k])) k++;
            String junk = eofMissing ? "NO_EOF" : headerAt > 0 ? "JUNK_BEFORE_HEADER" : "OK";
            if (at.length - k >= 4 && new String(at, k, 4, StandardCharsets.ISO_8859_1).equals("xref")) return junk;
            int p = k, groups = 0;
            while (groups < 2) { int st = p; while (p < at.length && digit(at[p])) p++; if (p == st) return "BAD_XREF_OFFSET"; while (p < at.length && ws(at[p])) p++; groups++; }
            return at.length - p >= 3 && new String(at, p, 3, StandardCharsets.ISO_8859_1).equals("obj") ? junk : "BAD_XREF_OFFSET";
        }
    }
    public static void main(String[] a) throws Exception { for (String p : Files.readAllLines(Paths.get(a[0]))) System.out.println(diagnose(new File(p))); }
}
