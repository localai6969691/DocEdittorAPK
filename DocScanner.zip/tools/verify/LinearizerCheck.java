import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/**
 * Ban Java chay duoc cua util/Linearizer.kt (phien 18, B12 tuyen tinh hoa): ISO 32000-1 Annex F - phan vung doi tuong, danh so lai, hai bang xref, tu dien tuyen tinh hoa va
 * luong goi y chinh. Chuyen the tu goi Go `linearize` (github.com/dobbo-ca/byblos, Apache-2.0; kiem chung voi qpdf), xem TECHNICAL_DOCS.md 4.42. KHONG biet gi ve cach doc PDF:
 * nhan do thi doi tuong + than doi tuong da tuan tu hoa (tham chieu la dau hieu \u0001<so>\u0002). Chay: java LinearizerCheck.java <tep mo ta> <tep ra>.
 */
public class LinearizerCheck {
    // ------------------------------------------------------------------ phan vung (layout.go)
    static class Graph {
        TreeMap<Integer, List<Integer>> refs = new TreeMap<>();
        List<Integer> pages = new ArrayList<>(), pageTree = new ArrayList<>(), openDoc = new ArrayList<>(), other = new ArrayList<>();
        int catalog, info, outlines; boolean useOutlines;
    }
    static class Plan {
        Map<Integer, Integer> renumber = new HashMap<>();
        List<Integer> part4 = new ArrayList<>(), part6 = new ArrayList<>(), part8 = new ArrayList<>(), part9 = new ArrayList<>(), outlines = new ArrayList<>();
        List<List<Integer>> part7 = new ArrayList<>(), pageShared = new ArrayList<>();
        int linDict, hint, catalog, info, size, nPages;
    }
    static Set<Integer> closure(Graph g, int start, Set<Integer> barrier) {
        Set<Integer> seen = new HashSet<>(); if (!g.refs.containsKey(start)) return seen;
        ArrayDeque<Integer> st = new ArrayDeque<>(); st.push(start);
        while (!st.isEmpty()) {
            int n = st.pop(); if (seen.contains(n) || !g.refs.containsKey(n)) continue;
            if (n != start && barrier.contains(n)) continue;
            seen.add(n); for (int r : g.refs.get(n)) st.push(r);
        }
        return seen;
    }
    static Set<Integer> closureOf(Graph g, List<Integer> seeds, Set<Integer> barrier) {
        Set<Integer> out = new HashSet<>();
        for (int s : seeds) { if (barrier.contains(s)) continue; out.addAll(closure(g, s, barrier)); }
        return out;
    }
    static List<Integer> lead(int first, List<Integer> ns) {
        List<Integer> r = new ArrayList<>(ns); Collections.sort(r);
        int i = r.indexOf(first); if (i > 0) { r.remove(i); r.add(0, first); } return r;
    }
    static List<Integer> leadAll(List<Integer> firsts, List<Integer> ns) {
        List<Integer> r = new ArrayList<>(ns); Collections.sort(r); List<Integer> head = new ArrayList<>();
        for (int f : firsts) { int i = r.indexOf(f); if (i >= 0) { head.add(f); r.remove(i); } }
        head.addAll(r); return head;
    }
    static Plan planLayout(Graph g) {
        if (g.pages.isEmpty()) throw new IllegalStateException("khong co trang");
        if (g.catalog == 0) throw new IllegalStateException("khong co catalog");
        Set<Integer> barrier = new HashSet<>(g.pages); barrier.addAll(g.pageTree);
        Set<Integer> firstPage = closure(g, g.pages.get(0), barrier);
        List<Set<Integer>> otherPages = new ArrayList<>(); otherPages.add(null);
        Map<Integer, Integer> pageCount = new HashMap<>();
        for (int i = 1; i < g.pages.size(); i++) { Set<Integer> c = closure(g, g.pages.get(i), barrier); otherPages.add(c); for (int n : c) pageCount.merge(n, 1, Integer::sum); }
        Set<Integer> openDoc = closureOf(g, g.openDoc, barrier), others = closureOf(g, g.other, barrier);
        Set<Integer> outlines = g.outlines != 0 ? closure(g, g.outlines, barrier) : new HashSet<>();
        Plan p = new Plan(); p.nPages = g.pages.size();
        List<List<Integer>> part7 = new ArrayList<>(); for (int i = 0; i < g.pages.size() - 1; i++) part7.add(new ArrayList<>());
        List<Integer> outlineGroup = new ArrayList<>();
        for (int n : g.refs.keySet()) {
            if (n == g.catalog) p.part4.add(n);
            else if (outlines.contains(n)) outlineGroup.add(n);
            else if (openDoc.contains(n)) p.part4.add(n);
            else if (firstPage.contains(n)) p.part6.add(n);
            else if (pageCount.getOrDefault(n, 0) == 1 && !others.contains(n)) { for (int i = 1; i < g.pages.size(); i++) if (otherPages.get(i).contains(n)) { part7.get(i - 1).add(n); break; } }
            else if (pageCount.getOrDefault(n, 0) > 1) p.part8.add(n);
            else p.part9.add(n);
        }
        p.part4 = lead(g.catalog, p.part4); p.part6 = lead(g.pages.get(0), p.part6);
        for (int i = 0; i < part7.size(); i++) part7.set(i, lead(g.pages.get(i + 1), part7.get(i)));
        p.part7 = part7; Collections.sort(p.part8); p.part9 = leadAll(g.pageTree, p.part9);
        outlineGroup = lead(g.outlines, outlineGroup);
        if (g.useOutlines) p.part6.addAll(outlineGroup); else p.part9.addAll(outlineGroup);
        int next = 1;
        for (List<Integer> grp : p.part7) for (int n : grp) p.renumber.put(n, next++);
        for (int n : p.part8) p.renumber.put(n, next++);
        for (int n : p.part9) p.renumber.put(n, next++);
        p.linDict = next++;
        for (int n : p.part4) p.renumber.put(n, next++);
        p.hint = next++;
        for (int n : p.part6) p.renumber.put(n, next++);
        p.size = next;
        if (p.renumber.size() != g.refs.size()) throw new IllegalStateException("phan vung " + p.renumber.size() + "/" + g.refs.size());
        Map<Integer, Integer> sharedIdx = new HashMap<>();
        for (int i = 0; i < p.part6.size(); i++) sharedIdx.put(p.part6.get(i), i);
        for (int i = 0; i < p.part8.size(); i++) sharedIdx.put(p.part8.get(i), p.part6.size() + i);
        p.pageShared.add(new ArrayList<>());
        for (int i = 1; i < g.pages.size(); i++) { List<Integer> ids = new ArrayList<>(); for (int n : otherPages.get(i)) if (sharedIdx.containsKey(n)) ids.add(sharedIdx.get(n)); Collections.sort(ids); p.pageShared.add(ids); }
        p.catalog = p.renumber.get(g.catalog); if (g.info != 0) p.info = p.renumber.get(g.info);
        p.part4 = map(p.renumber, p.part4); p.part6 = map(p.renumber, p.part6); for (int i = 0; i < p.part7.size(); i++) p.part7.set(i, map(p.renumber, p.part7.get(i)));
        p.part8 = map(p.renumber, p.part8); p.part9 = map(p.renumber, p.part9); p.outlines = map(p.renumber, outlineGroup);
        return p;
    }
    static List<Integer> map(Map<Integer, Integer> m, List<Integer> ns) { List<Integer> r = new ArrayList<>(); for (int n : ns) r.add(m.get(n)); return r; }

    // ------------------------------------------------------------------ luong goi y (hints.go)
    static class BitWriter {
        ByteArrayOutputStream out = new ByteArrayOutputStream(); long acc; int nAcc;
        void bits(int v, int n) { if (n <= 0) return; for (int i = n - 1; i >= 0; i--) { acc = (acc << 1) | ((v >> i) & 1); nAcc++; if (nAcc == 8) { out.write((int) acc); acc = 0; nAcc = 0; } } }
        void flush() { if (nAcc == 0) return; out.write((int) (acc << (8 - nAcc))); acc = 0; nAcc = 0; }
        void u32(int v) { flush(); out.write(v >>> 24); out.write(v >>> 16); out.write(v >>> 8); out.write(v); }
        void u16(int v) { flush(); out.write(v >>> 8); out.write(v); }
        int size() { return out.size(); }
    }
    static int nbits(int v) { int n = 0; while (v > 0) { n++; v >>= 1; } return n; }
    static class Hints { int[] pageN, pageLen; List<List<Integer>> pageShared = new ArrayList<>(); int firstPageOffset; int[] sharedLen; int nSharedFirstPage, firstSharedObj, firstSharedOffset;
        boolean hasOutline; int oFirst, oOffset, oN, oLen; }
    /** @return {payload, S, O} */
    static Object[] encodeHints(Hints h) {
        BitWriter w = new BitWriter(); int np = h.pageN.length;
        int minO = Integer.MAX_VALUE, maxO = 0, minL = Integer.MAX_VALUE, maxL = 0, maxS = 0;
        for (int i = 0; i < np; i++) { minO = Math.min(minO, h.pageN[i]); maxO = Math.max(maxO, h.pageN[i]); minL = Math.min(minL, h.pageLen[i]); maxL = Math.max(maxL, h.pageLen[i]); maxS = Math.max(maxS, h.pageShared.get(i).size()); }
        int nbO = nbits(maxO - minO), nbL = nbits(maxL - minL), nbS = nbits(maxS), nbI = nbits(h.sharedLen.length);
        w.u32(minO); w.u32(h.firstPageOffset); w.u16(nbO); w.u32(minL); w.u16(nbL); w.u32(0); w.u16(0); w.u32(minL); w.u16(nbL); w.u16(nbS); w.u16(nbI); w.u16(0); w.u16(4);
        for (int i = 0; i < np; i++) w.bits(h.pageN[i] - minO, nbO); w.flush();
        for (int i = 0; i < np; i++) w.bits(h.pageLen[i] - minL, nbL); w.flush();
        for (int i = 0; i < np; i++) w.bits(h.pageShared.get(i).size(), nbS); w.flush();
        for (int i = 0; i < np; i++) for (int id : h.pageShared.get(i)) w.bits(id, nbI); w.flush();
        w.flush(); w.flush();
        for (int i = 0; i < np; i++) w.bits(h.pageLen[i] - minL, nbL); w.flush();
        int s = w.size();
        int minG = 0, maxG = 0; for (int i = 0; i < h.sharedLen.length; i++) { if (i == 0 || h.sharedLen[i] < minG) minG = h.sharedLen[i]; if (h.sharedLen[i] > maxG) maxG = h.sharedLen[i]; }
        int nbG = nbits(maxG - minG);
        w.u32(h.firstSharedObj); w.u32(h.firstSharedOffset); w.u32(h.nSharedFirstPage); w.u32(h.sharedLen.length); w.u16(0); w.u32(minG); w.u16(nbG);
        for (int len : h.sharedLen) w.bits(len - minG, nbG); w.flush();
        for (int i = 0; i < h.sharedLen.length; i++) w.bits(0, 1); w.flush();
        w.flush();
        int o = 0;
        if (h.hasOutline) { o = w.size(); w.u32(h.oFirst); w.u32(h.oOffset); w.u32(h.oN); w.u32(h.oLen); }
        w.flush();
        return new Object[]{w.out.toByteArray(), s, o};
    }

    // ------------------------------------------------------------------ ghep tep (write.go)
    static final int LIN_SLOT = 201, PREV_SLOT = 21, XREF_ENTRY = 20;
    static class Buf { byte[] a = new byte[1 << 16]; int n;
        void add(byte[] b) { if (n + b.length > a.length) a = Arrays.copyOf(a, Math.max(a.length * 2, n + b.length)); System.arraycopy(b, 0, a, n, b.length); n += b.length; }
        void add(String s) { add(s.getBytes(StandardCharsets.ISO_8859_1)); }
        void rep(char c, int k) { byte[] b = new byte[k]; Arrays.fill(b, (byte) c); add(b); } }
    static byte[] render(String dict, byte[] stream, Map<Integer, Integer> renumber) {
        StringBuilder sb = new StringBuilder(); int i = 0;
        while (i < dict.length()) { char c = dict.charAt(i); if (c == 1) { int j = dict.indexOf((char) 2, i); int orig = Integer.parseInt(dict.substring(i + 1, j)); sb.append(renumber.get(orig)).append(" 0 R"); i = j + 1; } else { sb.append(c); i++; } }
        Buf b = new Buf(); b.add(sb.toString());
        if (stream != null) { b.add("\nstream\n"); b.add(stream); b.add("\nendstream"); }
        return Arrays.copyOf(b.a, b.n);
    }
    static byte[] write(Plan p, Map<Integer, byte[]> bodies, String version, byte[] id0, byte[] id1) throws IOException {
        Buf buf = new Buf(); Map<Integer, Integer> starts = new HashMap<>(), ends = new HashMap<>();
        java.util.function.IntConsumer emit = n -> { byte[] body = bodies.get(n); if (body == null) throw new IllegalStateException("thieu than " + n);
            starts.put(n, buf.n); buf.add(n + " 0 obj\n"); buf.add(body); buf.add("\nendobj\n"); ends.put(n, buf.n); };
        buf.add("%PDF-" + (version.isEmpty() ? "1.4" : version) + "\n"); buf.add(new byte[]{'%', (byte) 0xE2, (byte) 0xE3, (byte) 0xCF, (byte) 0xD3, '\n'});
        int linOff = buf.n; buf.rep(' ', LIN_SLOT); starts.put(p.linDict, linOff);
        List<Integer> first = new ArrayList<>(); first.add(p.linDict); first.addAll(p.part4); first.add(p.hint); first.addAll(p.part6);
        for (int i = 0; i < first.size(); i++) if (first.get(i) != p.linDict + i) throw new IllegalStateException("nhom dau khong lien tuc");
        int xref3 = buf.n; buf.add("xref\n" + first.get(0) + " " + first.size() + "\n");
        int[] frontEntry = new int[first.size()]; for (int i = 0; i < first.size(); i++) { frontEntry[i] = buf.n; buf.add("0000000000 00000 n \n"); }
        String idl = id0 == null ? "" : "[<" + hex(id0) + "><" + hex(id1 == null ? id0 : id1) + ">]";
        String trailer = "trailer\n<< /Size " + p.size + " /Root " + p.catalog + " 0 R" + (p.info != 0 ? " /Info " + p.info + " 0 R" : "") + " /Prev ";
        buf.add(trailer); int prevPos = buf.n; buf.rep(' ', PREV_SLOT);
        if (!idl.isEmpty()) buf.add(" /ID " + idl);
        buf.add(" >>\nstartxref\n0\n%%EOF\n");
        for (int n : p.part4) emit.accept(n);
        int hintOff = buf.n;
        for (int n : p.part6) emit.accept(n);
        int endFirst = buf.n;
        for (List<Integer> g : p.part7) for (int n : g) emit.accept(n);
        for (int n : p.part8) emit.accept(n);
        for (int n : p.part9) emit.accept(n);
        int secondGroup = p.linDict - 1; int xrefMain = buf.n;
        buf.add("xref\n0 " + (secondGroup + 1)); int spaceBeforeZero = buf.n; buf.add("\n"); buf.add("0000000000 65535 f \n");
        int[] mainEntry = new int[secondGroup]; for (int i = 0; i < secondGroup; i++) { mainEntry[i] = buf.n; buf.add("0000000000 00000 n \n"); }
        String t2 = "trailer\n<< /Size " + (secondGroup + 1) + (idl.isEmpty() ? "" : " /ID " + idl) + " >>\nstartxref\n" + xref3 + "\n"; buf.add(t2); buf.add("%%EOF\n");
        int preLen = buf.n;
        Hints h = new Hints(); h.firstPageOffset = hintOff; h.nSharedFirstPage = p.part6.size();
        int np = 1 + p.part7.size(); h.pageN = new int[np]; h.pageLen = new int[np];
        h.pageN[0] = p.part6.size(); h.pageLen[0] = endFirst - hintOff; h.pageShared.add(new ArrayList<>());
        for (int i = 0; i < p.part7.size(); i++) { List<Integer> g = p.part7.get(i); if (g.isEmpty()) throw new IllegalStateException("trang " + (i + 2) + " khong co doi tuong");
            h.pageN[i + 1] = g.size(); h.pageLen[i + 1] = ends.get(g.get(g.size() - 1)) - starts.get(g.get(0)); h.pageShared.add(p.pageShared.get(i + 1)); }
        List<Integer> sh = new ArrayList<>(); for (int n : p.part6) sh.add(ends.get(n) - starts.get(n)); for (int n : p.part8) sh.add(ends.get(n) - starts.get(n));
        h.sharedLen = sh.stream().mapToInt(Integer::intValue).toArray();
        if (!p.part8.isEmpty()) { h.firstSharedObj = p.part8.get(0); h.firstSharedOffset = starts.get(p.part8.get(0)); }
        if (!p.outlines.isEmpty()) { int end = 0; for (int n : p.outlines) end = Math.max(end, ends.get(n)); h.hasOutline = true; h.oFirst = p.outlines.get(0); h.oOffset = starts.get(p.outlines.get(0)); h.oN = p.outlines.size(); h.oLen = end - starts.get(p.outlines.get(0)); }
        Object[] enc = encodeHints(h); byte[] payload = (byte[]) enc[0];
        Deflater df = new Deflater(); df.setInput(payload); df.finish(); ByteArrayOutputStream z = new ByteArrayOutputStream(); byte[] tmp = new byte[8192]; while (!df.finished()) z.write(tmp, 0, df.deflate(tmp)); df.end();
        String dict = "<< /Filter /FlateDecode /S " + enc[1] + ((int) enc[2] != 0 ? " /O " + enc[2] : "") + " /Length " + z.size() + " >>";
        Buf hb = new Buf(); hb.add(p.hint + " 0 obj\n" + dict + "\nstream\n"); hb.add(z.toByteArray()); hb.add("\nendstream\nendobj\n");
        byte[] hintObj = Arrays.copyOf(hb.a, hb.n); int hintLen = hintObj.length;
        // vá TẠI CHỖ trong buf (toa do buf, khong dich), roi ghi ba doan: [0, hintOff) + luong goi y + [hintOff, preLen) - khong dung ban sao thu hai
        java.util.function.IntUnaryOperator shift = off -> off >= hintOff ? off + hintLen : off;
        String lin = p.linDict + " 0 obj\n<< /Linearized 1 /L " + (preLen + hintLen) + " /H [ " + hintOff + " " + hintLen + " ] /O " + p.part6.get(0) + " /E " + shift.applyAsInt(endFirst) + " /N " + p.nPages + " /T " + shift.applyAsInt(spaceBeforeZero) + " >>\nendobj\n";
        if (lin.length() > LIN_SLOT - 1) throw new IllegalStateException("tu dien tuyen tinh hoa qua dai");
        byte[] lb = lin.getBytes(StandardCharsets.ISO_8859_1); System.arraycopy(lb, 0, buf.a, linOff, lb.length); buf.a[linOff + LIN_SLOT - 1] = '\n';
        for (int i = 0; i < first.size(); i++) { int n = first.get(i); int off = n == p.hint ? hintOff : shift.applyAsInt(starts.get(n)); put(buf.a, frontEntry[i], off); }
        byte[] prev = Integer.toString(shift.applyAsInt(xrefMain)).getBytes(StandardCharsets.ISO_8859_1); if (prev.length > PREV_SLOT) throw new IllegalStateException("/Prev qua dai"); System.arraycopy(prev, 0, buf.a, prevPos, prev.length);
        for (int i = 0; i < secondGroup; i++) put(buf.a, mainEntry[i], shift.applyAsInt(starts.get(i + 1)));
        ByteArrayOutputStream out = new ByteArrayOutputStream(preLen + hintLen);
        out.write(buf.a, 0, hintOff); out.write(hintObj, 0, hintLen); out.write(buf.a, hintOff, preLen - hintOff);
        return out.toByteArray();
    }
    static void put(byte[] out, int pos, int off) { byte[] b = String.format("%010d", off).getBytes(StandardCharsets.ISO_8859_1); System.arraycopy(b, 0, out, pos, b.length); }
    static String hex(byte[] b) { StringBuilder sb = new StringBuilder(); for (byte x : b) sb.append(String.format("%02x", x)); return sb.toString(); }
    static byte[] unhex(String s) { byte[] b = new byte[s.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16); return b; }
    static List<Integer> ints(String[] t, int from) { List<Integer> r = new ArrayList<>(); for (int i = from; i < t.length; i++) if (!t[i].isEmpty() && !t[i].equals("-")) r.add(Integer.parseInt(t[i])); return r; }

    // ------------------------------------------------------------------ CLI: doc tep mo ta
    public static void main(String[] a) throws Exception {
        Graph g = new Graph(); String version = "1.4"; byte[] id0 = null, id1 = null; Map<Integer, String> dicts = new HashMap<>(); Map<Integer, byte[]> streams = new HashMap<>();
        for (String line : Files.readAllLines(Paths.get(a[0]), StandardCharsets.ISO_8859_1)) {
            String[] t = line.split(" ", -1);
            switch (t[0]) {
                case "VERSION": version = t[1]; break;
                case "ID": id0 = unhex(t[1]); id1 = unhex(t[2]); break;
                case "CATALOG": g.catalog = Integer.parseInt(t[1]); break;
                case "INFO": g.info = Integer.parseInt(t[1]); break;
                case "USEOUTLINES": g.useOutlines = t[1].equals("1"); break;
                case "OUTLINES": g.outlines = Integer.parseInt(t[1]); break;
                case "PAGES": g.pages = ints(t, 1); break;
                case "PAGETREE": g.pageTree = ints(t, 1); break;
                case "OPENDOC": g.openDoc = ints(t, 1); break;
                case "OTHER": g.other = ints(t, 1); break;
                case "OBJ": { int n = Integer.parseInt(t[1]); g.refs.put(n, ints(t[2].split(","), 0)); dicts.put(n, new String(unhex(t[3]), StandardCharsets.ISO_8859_1)); streams.put(n, t[4].equals("-") ? null : unhex(t[4])); break; }
                default: break;
            }
        }
        Plan p = planLayout(g); Map<Integer, byte[]> bodies = new HashMap<>();
        for (int n : g.refs.keySet()) bodies.put(p.renumber.get(n), render(dicts.get(n), streams.get(n), p.renumber));
        Files.write(Paths.get(a[1]), write(p, bodies, version, id0, id1));
    }
}
