"""Kiểm chứng PDF/A (phiên 17): SrgbIcc + PdfAXmp + các bước của PdfAConverter + dò điểm chặn.

A - ICC: byte do PdfACheck.java sinh (cùng logic SrgbIcc.kt). Cấu trúc đọc LẠI độc lập bằng struct (kích thước, 'acsp', phiên bản, bảng thẻ nằm trong tệp, căn 4 byte,
    XYZ, đường cong đơn điệu); rồi nạp bằng lcms (Pillow ImageCms) và so với sRGB dựng sẵn của lcms trên 20 000 màu ngẫu nhiên + dải xám: sai số <= 1 trên thang 0-255.
B - XMP: 9 bộ giá trị (chữ Việt, ký tự XML đặc biệt, ký tự điều khiển, emoji, không có tác giả, múi giờ +07:00 / -03:30 / +05:45 / UTC): gói PHẢI là XML hợp lệ,
    pdfaid:part=2, conformance=B, tiêu đề/tác giả/nhà sản xuất khớp (sau khi bỏ ký tự điều khiển), ngày XMP = ngày tính độc lập bằng datetime, ngày dạng Info = cùng thời điểm.
C - PDF mẫu: trang quét + lớp chữ Type3 vô hình -> make_pdfa; kiểm bằng công cụ độc lập: qpdf --check, XMP không có bộ lọc, OutputIntent GTS_PDFA1 + hồ sơ N=3 nạp được,
    Info = XMP từng trường, không có LZW/JavaScript/OpenAction, có /ID, phiên bản 1.7, pdftotext vẫn lấy được chữ vô hình. + veraPDF (--flavour 2b) NẾU có trên máy (CI luôn có).
D - dò điểm chặn (bản Python của PdfAPreflight.kt): PDF sạch -> không gì; mỗi điểm chặn (mã hoá, phiên bản > 1.7, phông chuẩn không nhúng, LZW, CMYK, tệp đính kèm, chú thích thiếu AP) bị bắt riêng;
    JavaScript/OpenAction/cờ chú thích là việc SỬA được và bị gỡ sau chuyển đổi. THỬ ÂM TÍNH: PDF ảnh quét KHÔNG qua chuyển đổi bị bộ kiểm C từ chối (thiếu XMP/OutputIntent).
Chạy: python3 pdfa_check.py   (cần java 11+, pikepdf, pillow, lxml, numpy, qpdf, pdftotext)
"""
import datetime, io, os, re, shutil, struct, subprocess, sys, unicodedata
sys.path.insert(0, os.path.dirname(__file__))
import numpy as np, pikepdf
from pikepdf import Name, Array, Dictionary, String
from lxml import etree
from PIL import Image, ImageCms
import pdfa_sample as S
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
    return cond

# ===================================================================== A. ICC
print("== A. hồ sơ ICC sRGB tự sinh ==")
icc = S.icc_bytes()
size, = struct.unpack(">I", icc[0:4])
check(size == len(icc), f"trường kích thước = độ dài thật ({len(icc)} byte)")
check(icc[8:12] == bytes([2, 0x10, 0, 0]) and icc[12:16] == b"mntr" and icc[16:20] == b"RGB " and icc[20:24] == b"XYZ " and icc[36:40] == b"acsp", "đầu: v2.1, màn hình (mntr), RGB, PCS XYZ, 'acsp'")
ill = struct.unpack(">iii", icc[68:80]); check(ill == (63190, 65536, 54061), f"nguồn sáng D50 = 0,9642 / 1 / 0,8249 (s15Fixed16 {ill})")
ntags, = struct.unpack(">I", icc[128:132]); tags = {}
for i in range(ntags):
    sig, off, sz = struct.unpack(">4sII", icc[132 + 12 * i:144 + 12 * i]); tags[sig.decode()] = (off, sz)
check(set(tags) == {"cprt", "desc", "wtpt", "rXYZ", "gXYZ", "bXYZ", "rTRC", "gTRC", "bTRC"}, f"9 thẻ bắt buộc của hồ sơ ma trận RGB: {sorted(tags)}")
check(all(o % 4 == 0 and o >= 132 + 12 * ntags and o + s <= len(icc) for o, s in tags.values()), "mọi thẻ nằm trong tệp, sau bảng thẻ, bắt đầu ở ranh giới 4 byte")
def xyz(tag): o, _ = tags[tag]; assert icc[o:o + 4] == b"XYZ "; return [v / 65536 for v in struct.unpack(">iii", icc[o + 8:o + 20])]
check(np.allclose(xyz("rXYZ"), [0.4360747, 0.2225045, 0.0139322], atol=1e-4) and np.allclose(xyz("wtpt"), [0.9642, 1.0, 0.8249], atol=1e-4), "toạ độ đỏ và điểm trắng đúng số sRGB-D50")
o, _ = tags["rTRC"]; n, = struct.unpack(">I", icc[o + 8:o + 12]); curve = np.array(struct.unpack(f">{n}H", icc[o + 12:o + 12 + 2 * n]))
check(n == 1024 and curve[0] == 0 and curve[-1] == 65535 and (np.diff(curve.astype(int)) >= 0).all(), "đường cong 1024 điểm: 0 -> 65535, không giảm")
check(tags["rTRC"] == tags["gTRC"] == tags["bTRC"], "ba đường cong dùng chung một khối dữ liệu (ICC cho phép)")
check(abs(curve[512] / 65535 - ((((512 / 1023) + 0.055) / 1.055) ** 2.4)) < 2e-4, "một điểm giữa đường cong khớp công thức sRGB")
prof = ImageCms.ImageCmsProfile(io.BytesIO(icc))
check("DocScanner" in ImageCms.getProfileDescription(prof), "lcms nạp được hồ sơ: " + ImageCms.getProfileDescription(prof).strip())
ref = ImageCms.createProfile("sRGB")
rng = np.random.default_rng(3)
pix = np.concatenate([rng.integers(0, 256, (20000, 3), dtype=np.uint8), np.stack([np.arange(256)] * 3, 1).astype(np.uint8)]).reshape(-1, 1, 3)
im = Image.fromarray(pix, "RGB")
for intent, name in ((ImageCms.Intent.RELATIVE_COLORIMETRIC, "tương đối"), (ImageCms.Intent.PERCEPTUAL, "cảm thụ")):
    t = ImageCms.buildTransform(prof, ref, "RGB", "RGB", renderingIntent=intent)
    out = np.array(ImageCms.applyTransform(im, t)).astype(int); err = np.abs(out - pix.astype(int))
    check(err.max() <= 1, f"so với sRGB dựng sẵn của lcms ({name}): sai số tối đa {err.max()}, trung bình {err.mean():.3f} trên {len(pix)} màu")
gray = np.array(ImageCms.applyTransform(Image.fromarray(np.stack([np.arange(256)] * 3, 1).astype(np.uint8).reshape(-1, 1, 3), "RGB"), ImageCms.buildTransform(prof, ref, "RGB", "RGB"))).reshape(-1, 3)
check((np.abs(gray - np.arange(256)[:, None]) <= 1).all() and (gray[:, 0] == gray[:, 1]).all() and (gray[:, 1] == gray[:, 2]).all(), "dải xám giữ xám (R=G=B) và không lệch quá 1")

# ===================================================================== B. XMP
print("== B. gói XMP ==")
def clean(s): return "".join(c for c in s if ord(c) in (9, 10, 13) or 0x20 <= ord(c) <= 0xD7FF or 0xE000 <= ord(c) <= 0xFFFD or ord(c) >= 0x10000)
CASES = [("Hợp đồng thuê nhà", "Nguyễn Văn An", "DocScanner", "DocScanner 17", 420), ("A & B < C > D \" ' E", "x<y>&z", "P&Q", "T\"1'", 0),
         ("ctrl\x01\x08ok\x0b\x0c", "au\x00thor", "pr\x1fod", "to\x7fol", -210), ("emoji 😀 và 𝒜", "Tác giả 😀", "DocScanner", "DocScanner", 345),
         ("", "", "DocScanner", "DocScanner", 420), ("Chỉ có tiêu đề", "", "DocScanner", "DocScanner", 0), ("x" * 3000, "y", "DocScanner", "DocScanner", 330),
         ("Giữa đêm", "Ban", "DocScanner", "DocScanner", -300), ("Múi +14", "Ban", "DocScanner", "DocScanner", 840)]
T1, T2 = 1_760_000_000_000, 1_760_600_000_000
for (title, author, prod, tool, off) in CASES:
    c_info, m_info, xmp = S.xmp_for(title, author, prod, tool, T1, T2, off)
    tag = f"{title[:14]!r} off={off}"
    try:
        root = etree.fromstring(re.sub(r"^<\?xpacket[^>]*\?>", "", xmp).rsplit("<?xpacket", 1)[0].encode("utf-8")); ok = True
    except Exception as e: ok = False; print(e)
    if not check(ok, f"{tag}: XML hợp lệ"): continue
    ns = {"rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#", "pdfaid": "http://www.aiim.org/pdfa/ns/id/", "dc": "http://purl.org/dc/elements/1.1/", "pdf": "http://ns.adobe.com/pdf/1.3/", "xmp": "http://ns.adobe.com/xap/1.0/"}
    g = lambda q: root.xpath(q, namespaces=ns)
    tz = datetime.timezone(datetime.timedelta(minutes=off))
    exp_c = datetime.datetime.fromtimestamp(T1 / 1000, tz).isoformat(timespec="seconds").replace("+00:00", "Z")
    exp_m = datetime.datetime.fromtimestamp(T2 / 1000, tz).isoformat(timespec="seconds").replace("+00:00", "Z")
    m = re.match(r"D:(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)(Z|[+-]\d\d'\d\d')$", m_info)
    info_dt = None
    if m:
        z = m.group(7); zone = datetime.timezone.utc if z == "Z" else datetime.timezone(datetime.timedelta(minutes=(1 if z[0] == "+" else -1) * (int(z[1:3]) * 60 + int(z[4:6]))))
        info_dt = datetime.datetime(*map(int, m.groups()[:6]), tzinfo=zone)
    check(g("string(//pdfaid:part)") == "2" and g("string(//pdfaid:conformance)") == "B" and g("string(//dc:title//rdf:li)") == clean(title) and g("string(//pdf:Producer)") == clean(prod) and g("string(//xmp:CreatorTool)") == clean(tool)
          and g("string(//xmp:CreateDate)") == exp_c and g("string(//xmp:ModifyDate)") == exp_m and info_dt == datetime.datetime.fromtimestamp(T2 / 1000, tz) and (author == "" and not g("//dc:creator") or g("string(//dc:creator//rdf:li)") == clean(author)),
          f"{tag}: PDF/A 2B, tiêu đề, tác giả, nhà sản xuất, ngày XMP và ngày Info (cùng thời điểm) đều đúng")
    check(xmp.startswith('<?xpacket begin="\ufeff"') and xmp.endswith('<?xpacket end="w"?>'), f"{tag}: bọc xpacket có BOM")

# ===================================================================== C. PDF mẫu
print("== C. PDF/A mẫu (bước của bộ chuyển đổi) ==")
work = S.TMP; src = os.path.join(work, "scan.pdf"); dst = os.path.join(work, "scan_pdfa.pdf")
S.build_scan_pdf(src); xmp_text = S.make_pdfa(src, dst)
def audit(path):
    """Kiểm PDF/A bằng công cụ độc lập; trả về danh sách lỗi."""
    bad = []
    if subprocess.run(["qpdf", "--check", path], capture_output=True).returncode != 0: bad.append("qpdf --check")
    pdf = pikepdf.open(path)
    md = pdf.Root.get("/Metadata")
    if md is None: return bad + ["thiếu Metadata"]
    if "/Filter" in md.stream_dict: bad.append("XMP có bộ lọc")
    xml = md.read_bytes().decode("utf-8")
    if "<pdfaid:part>2</pdfaid:part>" not in xml: bad.append("thiếu pdfaid:part=2")
    oi = pdf.Root.get("/OutputIntents")
    if not oi or str(oi[0].S) != "/GTS_PDFA1" or int(oi[0].DestOutputProfile.N) != 3: bad.append("OutputIntent")
    else:
        try: ImageCms.ImageCmsProfile(io.BytesIO(oi[0].DestOutputProfile.read_bytes()))
        except Exception: bad.append("hồ sơ ICC không nạp được")
    for obj in pdf.objects:
        if isinstance(obj, pikepdf.Stream) and "/Filter" in obj.stream_dict and "/LZWDecode" in str(obj.stream_dict.Filter): bad.append("LZW")
    if "/OpenAction" in pdf.Root or "/AA" in pdf.Root: bad.append("OpenAction/AA")
    if "/ID" not in pdf.trailer: bad.append("thiếu /ID")
    if float(str(pdf.pdf_version)) > 1.7: bad.append("phiên bản > 1.7")
    di = pdf.docinfo
    root = etree.fromstring(re.sub(r"^<\?xpacket[^>]*\?>", "", xml).rsplit("<?xpacket", 1)[0].encode("utf-8"))
    ns = {"dc": "http://purl.org/dc/elements/1.1/", "pdf": "http://ns.adobe.com/pdf/1.3/", "xmp": "http://ns.adobe.com/xap/1.0/"}
    if str(di.get("/Title", "")) != root.xpath("string(//dc:title//rdf:li)", namespaces={**ns, "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#"}): bad.append("Title Info != XMP")
    if str(di.get("/Producer", "")) != root.xpath("string(//pdf:Producer)", namespaces=ns): bad.append("Producer Info != XMP")
    return bad
bad = audit(dst); check(not bad, f"PDF/A mẫu qua kiểm độc lập (qpdf, XMP, OutputIntent+lcms, Info=XMP, không LZW/OpenAction, /ID, <=1.7) {bad}")
txt = subprocess.run(["pdftotext", dst, "-"], capture_output=True, text=True).stdout
check("Hop dong thue nha" in txt.replace("\n", " "), "lớp chữ vô hình vẫn chọn/lấy được sau chuyển đổi (pdftotext)")
neg = audit(src); check("thiếu Metadata" in neg, f"thử âm tính: PDF quét KHÔNG chuyển đổi bị từ chối ({neg})")
vera = shutil.which("verapdf")
if vera:
    r = subprocess.run([vera, "--flavour", "2b", dst], capture_output=True, text=True)
    check(r.stdout.startswith("PASS"), "veraPDF --flavour 2b: " + r.stdout.strip()[:120])
else:
    print("--   veraPDF không có trên máy này: bước kiểm chuẩn thật chạy trong CI (job `pdfa` của .github/workflows/android-build.yml)")

# ===================================================================== D. dò điểm chặn
print("== D. dò điểm chặn ==")
def preflight(pdf):
    """Bản Python của PdfAPreflight.kt: (điểm chặn, việc sẽ tự sửa)."""
    blockers, fixes = set(), set()
    if pdf.is_encrypted: blockers.add("encrypted")
    if float(str(pdf.pdf_version)) > 1.7: blockers.add("version")
    for obj in pdf.objects:
        if isinstance(obj, pikepdf.Stream):
            d = obj.stream_dict
            if "/Filter" in d and "/LZWDecode" in str(d.Filter): blockers.add("lzw")
            if "/Subtype" in d and str(d.Subtype) == "/Image" and "/ColorSpace" in d and str(d.ColorSpace) == "/DeviceCMYK": blockers.add("cmyk")
    for page in pdf.pages:
        fonts = page.get("/Resources", {}).get("/Font", {})
        for k in fonts.keys():
            f = fonts[k]
            if str(f.get("/Subtype")) == "/Type3": continue
            desc = f.get("/FontDescriptor")
            if str(f.get("/Subtype")) == "/Type0":
                df = f.DescendantFonts[0]; desc = df.get("/FontDescriptor")
            if desc is None or not any(x in desc for x in ("/FontFile", "/FontFile2", "/FontFile3")): blockers.add("font_not_embedded")
        for a in page.get("/Annots", []):
            if str(a.get("/Subtype")) not in ("/Link", "/Popup") and "/AP" not in a: blockers.add("annot_no_ap")
            if int(a.get("/F", 0)) & (2 | 32) or not int(a.get("/F", 0)) & 4: fixes.add("annot_flags")
    if "/EmbeddedFiles" in pdf.Root.get("/Names", {}): blockers.add("embedded_file")
    if "/JavaScript" in pdf.Root.get("/Names", {}): fixes.add("javascript")
    oa = pdf.Root.get("/OpenAction")
    if isinstance(oa, pikepdf.Dictionary) and "/S" in oa and str(oa.S) in ("/JavaScript", "/Launch"): fixes.add("openaction")
    if "/AA" in pdf.Root: fixes.add("openaction")
    return blockers, fixes
def variant(mutate, name):
    p = os.path.join(work, f"v_{name}.pdf"); S.build_scan_pdf(p, pages=1)
    pdf = pikepdf.open(p, allow_overwriting_input=True); mutate(pdf); pdf.save(p); return p
check(preflight(pikepdf.open(src)) == (set(), set()), "PDF quét sạch: không điểm chặn, không việc phải sửa")
def m_font(pdf): pdf.pages[0].Resources.Font.F2 = pdf.make_indirect(Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Helvetica))
def m_lzw(pdf): pdf.pages[0].Contents.Filter = Name.LZWDecode
def m_cmyk(pdf): pdf.pages[0].Resources.XObject.Im0.ColorSpace = Name.DeviceCMYK
def m_attach(pdf): pdf.Root.Names = Dictionary(EmbeddedFiles=Dictionary(Names=Array([])))
def m_annot_noap(pdf): pdf.pages[0].Annots = Array([pdf.make_indirect(Dictionary(Type=Name.Annot, Subtype=Name.Highlight, Rect=Array([0, 0, 10, 10]), F=4))])
def m_js(pdf): pdf.Root.OpenAction = Dictionary(S=Name.JavaScript, JS=String("app.alert(1)")); pdf.Root.AA = Dictionary()
def m_flags(pdf): pdf.pages[0].Annots = Array([pdf.make_indirect(Dictionary(Type=Name.Annot, Subtype=Name.Highlight, Rect=Array([0, 0, 10, 10]), F=2, AP=Dictionary(N=pdf.make_stream(b""))))])
for mut, name, want_b, want_f in ((m_font, "font", {"font_not_embedded"}, set()), (m_lzw, "lzw", {"lzw"}, set()), (m_cmyk, "cmyk", {"cmyk"}, set()), (m_attach, "attach", {"embedded_file"}, set()),
                                  (m_annot_noap, "noap", {"annot_no_ap"}, set()), (m_js, "js", set(), {"openaction"}), (m_flags, "flags", set(), {"annot_flags"})):
    b, f = preflight(pikepdf.open(variant(mut, name))); check(b == want_b and f == want_f, f"dò '{name}': điểm chặn {sorted(b)}, sửa được {sorted(f)}")
v20 = os.path.join(work, "v20.pdf"); S.build_scan_pdf(v20, pages=1); pv = pikepdf.open(v20, allow_overwriting_input=True); pv.save(v20, min_version="2.0")
check(preflight(pikepdf.open(v20))[0] == {"version"}, "dò 'version': PDF 2.0 bị chặn (PDF/A-2 chỉ tới 1.7)")
p = variant(m_js, "js2"); out = os.path.join(work, "js_fixed.pdf"); S.make_pdfa(p, out)
check(preflight(pikepdf.open(out)) == (set(), set()) and not audit(out), "sau chuyển đổi: JavaScript/OpenAction đã gỡ, không còn gì phải sửa, qua kiểm C")
p = variant(m_flags, "flags2"); out = os.path.join(work, "flags_fixed.pdf"); S.make_pdfa(p, out)
pdf_f = pikepdf.open(out); a = pdf_f.pages[0].Annots[0]; check(int(a.F) & 4 and not int(a.F) & (2 | 32), f"cờ chú thích sau chuyển đổi: Print bật, Hidden/NoView tắt (F={int(a.F)})")
print()
print("TAT CA DAT" if not FAILS else f"CO {len(FAILS)} LOI: " + "; ".join(FAILS[:5]))
sys.exit(1 if FAILS else 0)
