"""Kiểm chứng chữ ký số PDF (phiên 15): bộ dựng CMS/PKCS#7 của DerWriter.kt + CmsSigner.kt bằng bản Java song song (CmsCheck.java)
rồi để hai trình kiểm KHÁC NHAU xác nhận chữ ký: `pdfsig` (poppler) và `openssl cms -verify`.

Quy trình mô phỏng đúng cái PDFBox sẽ làm trên máy:
  1. PDF viết tay 1 trang; cập nhật tăng dần (incremental) thêm trường chữ ký (widget + AcroForm) với /Contents là khoảng trống 8 KB và /ByteRange;
  2. nội dung được ký = toàn bộ tệp TRỪ đoạn `<...>` của /Contents (đúng ByteRange);
  3. `java CmsCheck.java` dựng SignedData tách rời (SHA-256 + RSA PKCS#1 v1.5) bằng chính thuật toán của Kotlin, khoá lấy từ tệp;
  4. gắn vào /Contents, rồi pdfsig + openssl kiểm: phải "Signature is Valid" / "Verification successful";
  5. thử âm tính: sửa 1 byte trong vùng đã ký -> cả hai phải báo sai; sửa 1 byte trong chính khối chữ ký -> sai.
Thử với 2 loại chứng thư tự ký: v3 không có extension (giống chứng thư AndroidKeyStore tự sinh) và v1 (không có phần [0] version -> kiểm đường đi
của bộ đọc DER lấy issuer/serial).
Chạy: python3 digital_signature_check.py   (cần cryptography, pdfsig, openssl, java 11+)
"""
import datetime, os, re, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

HERE = os.path.dirname(os.path.abspath(__file__))
CAPACITY = 8192            # byte dành cho khối chữ ký, như PDFBox (mặc định 9472)


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    return cond


def base_pdf():
    objs = {}
    objs[1] = b"<< /Type /Catalog /Pages 2 0 R >>"
    objs[2] = b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>"
    objs[3] = b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 200] /Contents 4 0 R /Resources << >> >>"
    stream = b"0.9 0.2 0.2 rg 20 20 100 60 re f"
    objs[4] = b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream"
    out = bytearray(b"%PDF-1.7\n%\xe2\xe3\xcf\xd3\n")
    offsets = {}
    for n in sorted(objs):
        offsets[n] = len(out)
        out += b"%d 0 obj\n" % n + objs[n] + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n0 5\n0000000000 65535 f \n"
    for n in range(1, 5):
        out += b"%010d 00000 n \n" % offsets[n]
    out += b"trailer\n<< /Size 5 /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % xref
    return bytes(out), xref


def with_signature_placeholder(pdf, prev_xref):
    out = bytearray(pdf)
    offsets = {}

    def add(n, body):
        offsets[n] = len(out)
        out.extend(b"%d 0 obj\n" % n + body + b"\nendobj\n")
    add(1, b"<< /Type /Catalog /Pages 2 0 R /AcroForm << /Fields [6 0 R] /SigFlags 3 >> >>")
    add(3, b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 200] /Contents 4 0 R /Resources << >> /Annots [6 0 R] >>")
    add(5, b"<< /Type /Sig /Filter /Adobe.PPKLite /SubFilter /adbe.pkcs7.detached "
           b"/ByteRange [0 0000000000 0000000000 0000000000] /Contents <" + b"0" * (2 * CAPACITY) + b"> "
           b"/M (D:20261003120000Z) /Name (Test Signer) /Reason (Kiem thu) >>")
    add(6, b"<< /Type /Annot /Subtype /Widget /FT /Sig /Rect [0 0 0 0] /V 5 0 R /T (Signature1) /F 132 /P 3 0 R >>")
    xref = len(out)
    out += b"xref\n0 1\n0000000000 65535 f \n1 1\n%010d 00000 n \n3 1\n%010d 00000 n \n5 2\n%010d 00000 n \n%010d 00000 n \n" % (
        offsets[1], offsets[3], offsets[5], offsets[6])
    out += b"trailer\n<< /Size 7 /Root 1 0 R /Prev %d >>\nstartxref\n%d\n%%%%EOF\n" % (prev_xref, xref)
    return bytes(out)


def make_cert_v3(path_prefix):
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Người ký thử DocScanner")])   # có dấu: kiểm UTF8String
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(int.from_bytes(os.urandom(8), "big") | (1 << 62)).not_valid_before(now - datetime.timedelta(days=1))
            .not_valid_after(now + datetime.timedelta(days=3650)).sign(key, hashes.SHA256()))
    open(path_prefix + ".pk8", "wb").write(key.private_bytes(serialization.Encoding.DER, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    open(path_prefix + ".der", "wb").write(cert.public_bytes(serialization.Encoding.DER))
    return cert


def make_cert_v1(path_prefix):
    cfg = os.path.join(os.path.dirname(path_prefix), "v1.cnf")
    open(cfg, "w").write("[req]\ndistinguished_name=dn\nprompt=no\n[dn]\nCN=Chung thu v1\n")
    subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-config", cfg, "-days", "3650",
                    "-keyout", path_prefix + ".key.pem", "-out", path_prefix + ".pem"], check=True, capture_output=True)
    subprocess.run(["openssl", "x509", "-in", path_prefix + ".pem", "-outform", "DER", "-out", path_prefix + ".der"], check=True)
    subprocess.run(["openssl", "pkcs8", "-topk8", "-nocrypt", "-in", path_prefix + ".key.pem", "-outform", "DER", "-out", path_prefix + ".pk8"], check=True)
    txt = subprocess.run(["openssl", "x509", "-in", path_prefix + ".pem", "-noout", "-text"], capture_output=True, text=True).stdout
    return "Version: 1 (0x0)" in txt


def sign_pdf(unsigned, workdir, prefix):
    lt = unsigned.index(b"/Contents <") + len(b"/Contents ")
    gt = lt + 1 + 2 * CAPACITY
    assert unsigned[gt:gt + 1] == b">"
    a, b = lt, gt + 1
    br = b"/ByteRange [0 %010d %010d %010d]" % (a, b, len(unsigned) - b)
    data = bytearray(unsigned)
    i = data.index(b"/ByteRange [0 0000000000 0000000000 0000000000]")
    data[i:i + len(br)] = br
    content = bytes(data[:a]) + bytes(data[b:])
    cpath = os.path.join(workdir, "content.bin"); open(cpath, "wb").write(content)
    cms_path = os.path.join(workdir, "sig.der")
    r = subprocess.run(["java", os.path.join(HERE, "CmsCheck.java"), cpath, prefix + ".pk8", prefix + ".der", cms_path],
                       capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout, r.stderr); raise SystemExit("java thất bại")
    cms = open(cms_path, "rb").read()
    assert len(cms) <= CAPACITY, f"CMS {len(cms)} B vượt chỗ dành sẵn {CAPACITY} B"
    data[lt + 1:gt] = cms.hex().upper().encode().ljust(2 * CAPACITY, b"0")
    return bytes(data), content, cms_path, len(cms)


def pdfsig(path):
    r = subprocess.run(["pdfsig", path], capture_output=True, text=True)
    return r.stdout + r.stderr


def openssl_verify(cms_path, content_path):
    r = subprocess.run(["openssl", "cms", "-verify", "-inform", "DER", "-in", cms_path, "-content", content_path, "-binary", "-noverify", "-out", os.devnull],
                       capture_output=True, text=True)
    return r.returncode == 0, (r.stdout + r.stderr).strip()


def run_case(label, prefix, workdir, expect_v1=None):
    good = True
    base, prev = base_pdf()
    unsigned = with_signature_placeholder(base, prev)
    signed, content, cms_path, size = sign_pdf(unsigned, workdir, prefix)
    path = os.path.join(workdir, label + ".pdf"); open(path, "wb").write(signed)
    out = pdfsig(path)
    good &= check("Signature is Valid" in out, f"{label}: pdfsig báo chữ ký HỢP LỆ (CMS {size} B)")
    if "Signature is Valid" not in out:
        print(out)
    good &= check("Signature Type: adbe.pkcs7.detached" in out.replace("  ", " ") or "adbe.pkcs7.detached" in out, f"{label}: pdfsig nhận SubFilter adbe.pkcs7.detached")
    good &= check("SHA-256" in out, f"{label}: thuật toán băm SHA-256")
    ok, msg = openssl_verify(cms_path, os.path.join(workdir, "content.bin"))
    good &= check(ok, f"{label}: openssl cms -verify thành công ({msg[:50]})")
    # âm tính 1: sửa 1 byte trong vùng ĐÃ KÝ (đổi màu nội dung trang)
    tampered = bytearray(signed); k = tampered.index(b"0.9 0.2 0.2 rg"); tampered[k + 2] = ord("8")
    tp = os.path.join(workdir, label + "_tampered.pdf"); open(tp, "wb").write(bytes(tampered))
    out2 = pdfsig(tp)
    good &= check("Signature is Valid" not in out2 and ("Digest Mismatch" in out2 or "Invalid" in out2), f"{label}: sửa 1 byte vùng đã ký -> pdfsig báo KHÔNG hợp lệ")
    open(os.path.join(workdir, "content_t.bin"), "wb").write(bytes(tampered[:signed.index(b"/Contents <") + len(b"/Contents ")]) + bytes(tampered[signed.index(b"/Contents <") + len(b"/Contents ") + 1 + 2 * CAPACITY + 1:]))
    ok2, _ = openssl_verify(cms_path, os.path.join(workdir, "content_t.bin"))
    good &= check(not ok2, f"{label}: sửa 1 byte vùng đã ký -> openssl cũng báo sai")
    # âm tính 2: hỏng chính khối chữ ký (đổi byte giữa của chữ ký RSA, ở cuối CMS)
    broken = bytearray(signed); p = broken.index(b"/Contents <") + len(b"/Contents <") + 2 * (size - 40)
    broken[p] = ord("0") if broken[p] != ord("0") else ord("1")
    bp = os.path.join(workdir, label + "_broken.pdf"); open(bp, "wb").write(bytes(broken))
    out3 = pdfsig(bp)
    good &= check("Signature is Valid" not in out3, f"{label}: hỏng khối chữ ký -> pdfsig báo KHÔNG hợp lệ")
    return good


def main():
    good = True
    with tempfile.TemporaryDirectory(dir=OUT) as wd:
        v3 = os.path.join(wd, "v3"); make_cert_v3(v3)
        good &= run_case("cert_v3", v3, wd)
        v1 = os.path.join(wd, "v1")
        is_v1 = make_cert_v1(v1)
        good &= check(is_v1, "đã sinh được chứng thư X.509 phiên bản 1 (không có phần [0] version)")
        good &= run_case("cert_v1", v1, wd)
    print("TAT CA DAT" if good else "CO LOI")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
