import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Java twin of app/.../util/DocumentWebhook.kt (phiên 22, 4.49.12): payload, signature, pending and post, same code. stdin commands, text as hex UTF-8:
 *   payload <nameHex> <size> <millis>     -> JSON
 *   test <millis>                          -> JSON
 *   sig <bodyHex> <secretHex>              -> "sha256=..."
 *   pending <now> <recentMs> <limit> <seenNamesCsvHex|-> <name:millis,...hex>    -> names, one per line, "END"
 *   post <urlHex> <jsonHex> <secretHex|-> <timeoutMs>                       -> "true" / "false"
 */
public class WebhookCheck {
    static String iso(long m) { SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US); f.setTimeZone(TimeZone.getTimeZone("UTC")); return f.format(new Date(m)); }
    static String jsonString(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) { char c = s.charAt(i);
            if (c == '"') sb.append("\\\""); else if (c == '\\') sb.append("\\\\"); else if (c == '\n') sb.append("\\n"); else if (c == '\r') sb.append("\\r"); else if (c == '\t') sb.append("\\t");
            else if (c == '\b') sb.append("\\b"); else if (c == (char) 0x0C) sb.append("\\f"); else if (c < 0x20) { String h = Integer.toString(c, 16); while (h.length() < 4) h = "0" + h; sb.append("\\u").append(h); }
            else if (Character.isHighSurrogate(c) && i + 1 < s.length() && Character.isLowSurrogate(s.charAt(i + 1))) { sb.append(c).append(s.charAt(i + 1)); i++; }
            else if (Character.isSurrogate(c)) sb.append('\uFFFD'); else sb.append(c); }
        return sb.append('"').toString();
    }
    static String payload(String name, long size, long modified) {
        int dot = name.lastIndexOf('.'); String type = dot < 0 ? "" : name.substring(dot + 1).toLowerCase(Locale.ROOT);
        return "{\"event\":\"document_created\",\"app\":\"DocScanner\",\"name\":" + jsonString(name) + ",\"type\":" + jsonString(type) + ",\"sizeBytes\":" + size + ",\"modified\":\"" + iso(modified) + "\"}";
    }
    static String signature(byte[] body, String secret) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256"); mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8), "HmacSHA256")); StringBuilder sb = new StringBuilder("sha256=");
        for (byte b : mac.doFinal(body)) sb.append(String.format("%02x", b)); return sb.toString();
    }
    static boolean post(URL address, String json, String secret, int timeout) {
        byte[] body = json.getBytes(StandardCharsets.UTF_8); HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) address.openConnection(); c.setRequestMethod("POST"); c.setInstanceFollowRedirects(false); c.setConnectTimeout(timeout); c.setReadTimeout(timeout);
            c.setDoOutput(true); c.setFixedLengthStreamingMode(body.length); c.setRequestProperty("Content-Type", "application/json; charset=utf-8"); c.setRequestProperty("User-Agent", "DocScanner");
            if (!secret.isEmpty()) c.setRequestProperty("X-DocScanner-Signature", signature(body, secret));
            try (OutputStream o = c.getOutputStream()) { o.write(body); }
            int code = c.getResponseCode(); try (InputStream in = c.getInputStream()) { in.readAllBytes(); } catch (Exception e) { }
            return code >= 200 && code <= 299;
        } catch (Exception e) { return false; } finally { if (c != null) c.disconnect(); }
    }
    static String unhex(String h) { if (h.equals("-")) return ""; byte[] b = new byte[h.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return new String(b, StandardCharsets.UTF_8); }

    public static void main(String[] a) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.US_ASCII)); String line; PrintStream out = new PrintStream(System.out, true, "UTF-8");
        while ((line = r.readLine()) != null) {
            String[] f = line.split(" ");
            switch (f[0]) {
                case "payload": out.println(payload(unhex(f[1]), Long.parseLong(f[2]), Long.parseLong(f[3]))); break;
                case "test": out.println("{\"event\":\"test\",\"app\":\"DocScanner\",\"modified\":\"" + iso(Long.parseLong(f[1])) + "\"}"); break;
                case "sig": out.println(signature(unhex(f[1]).getBytes(StandardCharsets.UTF_8), unhex(f[2]))); break;
                case "pending": {
                    long now = Long.parseLong(f[1]), recent = Long.parseLong(f[2]); int limit = Integer.parseInt(f[3]);
                    Set<String> seen = new HashSet<>(); String sc = unhex(f[4]); if (!sc.isEmpty()) seen.addAll(Arrays.asList(sc.split("\n")));
                    List<Object[]> files = new ArrayList<>(); String fc = unhex(f[5]); if (!fc.isEmpty()) for (String e : fc.split("\n")) { int i = e.lastIndexOf(':'); files.add(new Object[]{e.substring(0, i), Long.parseLong(e.substring(i + 1))}); }
                    List<Object[]> keep = new ArrayList<>(); for (Object[] e : files) { long age = now - (Long) e[1]; if (!seen.contains(e[0]) && age >= 0 && age <= recent) keep.add(e); }
                    keep.sort(Comparator.comparingLong(e -> (Long) e[1])); for (int i = 0; i < Math.min(limit, keep.size()); i++) out.println(keep.get(i)[0]); out.println("END"); break; }
                case "post": out.println(post(new URL(unhex(f[1])), unhex(f[2]), unhex(f[3]), Integer.parseInt(f[4]))); break;
                default: throw new IllegalArgumentException(f[0]);
            }
        }
    }
}
