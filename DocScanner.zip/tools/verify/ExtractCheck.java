// Bản Java chạy được của InvoiceFields, ContactCard (+ phần EMAIL/PHONE của PiiDetector) - phiên 16, mục 4.30. Dùng bởi extract_check.py.
//   java ExtractCheck.java amount  <vào> <ra>   vào: mỗi dòng một chuỗi số; ra: giá trị chuẩn hoá hoặc "null"
//   java ExtractCheck.java invoice <vào> <ra>   vào: mỗi dòng một văn bản (\n, \\uXXXX); ra: "KIND=giá trị;..."
//   java ExtractCheck.java card    <vào> <ra>   ra: "name=..|title=..|company=..|phones=a,b|emails=..|websites=..|address=.." (đã mã hoá bằng \\uXXXX)
//   java ExtractCheck.java vcard   <vào> <ra.vcf>  vào: một dòng "name\ttitle\tcompany\tphones(|)\temails(|)\twebsites(|)\taddress" ; ra: vCard
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.Normalizer;
import java.util.*;
import java.util.regex.*;

public class ExtractCheck {
    // ---- PiiDetector (EMAIL, PHONE) ----
    static final Pattern EMAIL = Pattern.compile("[A-Za-z0-9._%+\\-]+@[A-Za-z0-9\\-]+(?:\\.[A-Za-z0-9\\-]+)*\\.[A-Za-z]{2,}");
    static final Pattern PHONE_MOBILE = Pattern.compile("(?<![\\d+])(?:\\+84|84|0)[ .\\-]?[35789](?:[ .\\-]?\\d){8}(?!\\d)");
    static final Pattern PHONE_LANDLINE = Pattern.compile("(?<![\\d+])0[ .\\-]?2(?:[ .\\-]?\\d){9}(?!\\d)");
    record Cand(int start, int end, boolean email, int priority) {}
    static String fold(String text) {
        StringBuilder sb = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == 'đ') sb.append('d'); else if (c == 'Đ') sb.append('D'); else sb.append(Normalizer.normalize(String.valueOf(c), Normalizer.Form.NFD).charAt(0));
        }
        return sb.toString();
    }
    static String foldLower(String text) { String f = fold(text); StringBuilder sb = new StringBuilder(); for (int i = 0; i < f.length(); i++) sb.append(Character.toLowerCase(f.charAt(i))); return sb.toString(); }
    static List<Cand> findEmailPhone(String text) {
        List<Cand> found = new ArrayList<>();
        Matcher m = EMAIL.matcher(text); while (m.find()) found.add(new Cand(m.start(), m.end(), true, 1));
        m = PHONE_MOBILE.matcher(text); while (m.find()) found.add(new Cand(m.start(), m.end(), false, 5));
        m = PHONE_LANDLINE.matcher(text); while (m.find()) found.add(new Cand(m.start(), m.end(), false, 5));
        found.sort(Comparator.comparingInt(Cand::priority).thenComparingInt(Cand::start).thenComparingInt(c -> -(c.end() - c.start())));
        List<Cand> accepted = new ArrayList<>();
        for (Cand c : found) { boolean overlap = false; for (Cand a : accepted) if (c.start() < a.end() && a.start() < c.end()) { overlap = true; break; } if (!overlap) accepted.add(c); }
        accepted.sort(Comparator.comparingInt(Cand::start));
        return accepted;
    }

    // ---- InvoiceFields ----
    static final Pattern TAX = Pattern.compile("(?:ma so thue|mst|tax code|tax id)[^0-9\\n]{0,25}(\\d{10}(?:-\\d{3})?|\\d{13})(?!\\d)");
    static final Pattern INVOICE_NO = Pattern.compile("(?:so hoa don|so hd|invoice no\\.?|invoice number|so \\(no\\.?\\))[^0-9\\n]{0,25}(\\d{1,10})(?!\\d)");
    static final Pattern SERIAL = Pattern.compile("(?:ky hieu(?: hoa don)?|serial)(?:\\s*\\([^)\\n]{0,20}\\))?[^a-z0-9\\n]{0,25}([0-9][a-z][0-9]{2}[a-z]{2,4}|[a-z]{2}/[0-9]{2}[a-z])");
    static final Pattern DATE_WORDS = Pattern.compile("ngay\\s*(\\d{1,2})\\s*thang\\s*(\\d{1,2})\\s*nam\\s*(\\d{4})");
    static final Pattern DATE_SLASH = Pattern.compile("(?<!\\d)(\\d{1,2})[/\\-.](\\d{1,2})[/\\-.](\\d{4})(?!\\d)");
    static final Pattern DATE_ISO = Pattern.compile("(?<!\\d)(\\d{4})-(\\d{2})-(\\d{2})(?!\\d)");
    static final Pattern VAT_RATE = Pattern.compile("(?:thue suat|vat rate|thue gtgt|vat)[^0-9\\n]{0,15}(\\d{1,2})\\s?%");
    static final Pattern PERCENT = Pattern.compile("\\d+(?:[.,]\\d+)?\\s?%");
    static final Pattern NUMBER = Pattern.compile("\\d{1,3}(?:[.,]\\d{3})+(?:[.,]\\d{1,2})?|\\d+(?:[.,]\\d{1,2})?");
    static final String[][] TOTAL_LABELS = {{"tong cong tien thanh toan", "tong tien thanh toan", "tong cong thanh toan", "tong thanh toan", "tien thanh toan", "total amount", "grand total", "amount due"}, {"tong cong"}};
    static final String[] VAT_AMOUNT_LABELS = {"tien thue gtgt", "tien thue", "thue gtgt", "vat amount"};
    static String iso(String year, String month, String day) {
        int y = Integer.parseInt(year), m = Integer.parseInt(month), d = Integer.parseInt(day);
        if (y < 1990 || y > 2100 || m < 1 || m > 12 || d < 1) return null;
        int[] days = {31, (y % 4 == 0 && (y % 100 != 0 || y % 400 == 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        if (d > days[m - 1]) return null;
        return String.format(Locale.ROOT, "%04d-%02d-%02d", y, m, d);
    }
    static String date(String low) {
        int bestAt = Integer.MAX_VALUE; String best = null;
        Matcher m = DATE_WORDS.matcher(low); while (m.find()) { String r = iso(m.group(3), m.group(2), m.group(1)); if (r != null && m.start() < bestAt) { bestAt = m.start(); best = r; } }
        m = DATE_SLASH.matcher(low); while (m.find()) { String r = iso(m.group(3), m.group(2), m.group(1)); if (r != null && m.start() < bestAt) { bestAt = m.start(); best = r; } }
        m = DATE_ISO.matcher(low); while (m.find()) { String r = iso(m.group(1), m.group(2), m.group(3)); if (r != null && m.start() < bestAt) { bestAt = m.start(); best = r; } }
        return best;
    }
    static String normalizeAmount(String token) {
        String t = token.strip();
        if (!t.matches("\\d{1,3}([.,]\\d{3})+([.,]\\d{1,2})?|\\d+([.,]\\d{1,2})?")) return null;
        int dots = 0, commas = 0; for (char c : t.toCharArray()) { if (c == '.') dots++; if (c == ',') commas++; }
        String intPart, frac = "";
        if (dots > 0 && commas > 0) {
            int last = Math.max(t.lastIndexOf('.'), t.lastIndexOf(','));
            intPart = digits(t.substring(0, last)); frac = t.substring(last + 1);
        } else if (dots + commas > 1) {
            char sep = dots > 0 ? '.' : ','; int last = t.lastIndexOf(sep); String tail = t.substring(last + 1);
            if (tail.length() <= 2) { intPart = digits(t.substring(0, last)); frac = tail; } else intPart = digits(t);
        } else if (dots + commas == 1) {
            int last = Math.max(t.lastIndexOf('.'), t.lastIndexOf(',')); String before = t.substring(0, last), after = t.substring(last + 1);
            if (after.length() == 3 && before.length() <= 3) intPart = before + after; else { intPart = before; frac = after; }
        } else intPart = t;
        String whole = intPart.replaceFirst("^0+", ""); if (whole.isEmpty()) whole = "0";
        String fraction = frac.replaceFirst("0+$", "");
        return fraction.isEmpty() ? whole : whole + "." + fraction;
    }
    static String digits(String s) { StringBuilder sb = new StringBuilder(); for (char c : s.toCharArray()) if (Character.isDigit(c)) sb.append(c); return sb.toString(); }
    static String amountAfterLabel(String low, List<int[]> lines, String[] labels, double minValue) {
        for (int i = 0; i < lines.size(); i++) {
            String line = low.substring(lines.get(i)[0], lines.get(i)[1]);
            int at = -1; String label = null;
            for (String l : labels) { int k = line.indexOf(l); if (k >= 0 && (at < 0 || k < at)) at = k; }
            if (at < 0) continue;
            for (String l : labels) if (line.indexOf(l) == at) { label = l; break; }
            List<String> numbers = new ArrayList<>(); Matcher m = NUMBER.matcher(PERCENT.matcher(line.substring(at + label.length())).replaceAll(" ")); while (m.find()) numbers.add(m.group());
            if (numbers.isEmpty() && i + 1 < lines.size()) { Matcher n = NUMBER.matcher(low.substring(lines.get(i + 1)[0], lines.get(i + 1)[1])); if (n.find()) numbers.add(n.group()); }
            for (int k = numbers.size() - 1; k >= 0; k--) { String normal = normalizeAmount(numbers.get(k)); if (normal == null) continue; if (Double.parseDouble(normal) >= minValue) return normal; }
        }
        return null;
    }
    static String invoice(String text) {
        String low = foldLower(text); List<String> out = new ArrayList<>();
        String d = date(low); if (d != null) out.add("DATE=" + d);
        Matcher m = INVOICE_NO.matcher(low); if (m.find()) out.add("INVOICE_NO=" + text.substring(m.start(1), m.end(1)));
        m = SERIAL.matcher(low); if (m.find()) out.add("SERIAL=" + text.substring(m.start(1), m.end(1)));
        m = TAX.matcher(low); while (m.find()) out.add("TAX_ID=" + text.substring(m.start(1), m.end(1)));
        List<int[]> lines = new ArrayList<>(); int start = 0;
        for (int i = 0; i <= low.length(); i++) if (i == low.length() || low.charAt(i) == '\n') { lines.add(new int[]{start, i}); start = i + 1; }
        for (String[] labels : TOTAL_LABELS) { String f = amountAfterLabel(low, lines, labels, 0.0); if (f != null) { out.add("TOTAL=" + f); break; } }
        m = VAT_RATE.matcher(low); if (m.find()) out.add("VAT_RATE=" + m.group(1));
        String v = amountAfterLabel(low, lines, VAT_AMOUNT_LABELS, 1000.0); if (v != null) out.add("VAT_AMOUNT=" + v);
        return String.join(";", out);
    }

    // ---- ContactCard ----
    static final String[] COMPANY = {"cong ty ", "tnhh", "co phan", "jsc", "corp", "ltd", "company", "inc.", "group", "tap doan", "doanh nghiep"};
    static final String[] TITLE = {"giam doc", "truong phong", "pho phong", "chuyen vien", "ky su", "chu tich", "luat su", "bac si", "ke toan", "manager", "director", "ceo", "cto", "cfo", "coo", "engineer", "developer", "consultant", "specialist", "president", "executive", "supervisor", "assistant"};
    static final String[] ADDRESS = {"duong ", "pho ", "quan ", "phuong ", "huyen ", "tp.", "thanh pho", "tinh ", "tang ", "toa nha", "street", "road", "ward", "district", "floor", "building"};
    static final Pattern FAX = Pattern.compile("\\bfax\\b");
    static final Pattern WEBSITE = Pattern.compile("(?:https?://)?(?:www\\.)?[a-z0-9][a-z0-9\\-]*(?:\\.[a-z0-9\\-]+)*\\.(?:com|vn|net|org|edu|gov|io|info|biz|asia)(?:/[^\\s,;]*)?");
    static final Pattern ADDRESS_NUMBER = Pattern.compile("^so \\d");
    static final Pattern LABEL_PREFIX = Pattern.compile("^(?:tel|dt|d/t|di dong|mobile|mob|phone|hotline|email|e-mail|mail|web|website|www|add|address|dia chi|fax)\\s*[:.]\\s*");
    static boolean hasDigit(String s) { for (char c : s.toCharArray()) if (Character.isDigit(c)) return true; return false; }
    static boolean containsAny(String s, String[] keys) { for (String k : keys) if (s.contains(k)) return true; return false; }
    static String[] card(String text) {
        List<String> lines = new ArrayList<>(); for (String l : text.split("\n", -1)) { String t = l.strip(); if (!t.isEmpty()) lines.add(t); }
        List<String> emails = new ArrayList<>(), phones = new ArrayList<>(), websites = new ArrayList<>(); boolean[] used = new boolean[lines.size()];
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i), folded = foldLower(line); StringBuilder rest = new StringBuilder(folded);
            for (Cand m : findEmailPhone(line)) {
                String value = line.substring(m.start(), m.end()).strip();
                if (m.email()) { if (!emails.contains(value)) emails.add(value); }
                else if (!phones.contains(value) && !FAX.matcher(folded.substring(Math.max(0, m.start() - 8), m.start())).find()) phones.add(value);
                for (int k = m.start(); k < m.end(); k++) rest.setCharAt(k, ' ');
                used[i] = true;
            }
            Matcher w = WEBSITE.matcher(rest.toString());
            while (w.find()) { if (w.group().contains("@")) continue; String printed = line.substring(w.start(), w.end()); if (!websites.contains(printed)) websites.add(printed); used[i] = true; }
        }
        String company = "", title = ""; List<String> addressLines = new ArrayList<>();
        for (int i = 0; i < lines.size(); i++) {
            if (used[i]) continue;
            String line = lines.get(i), folded = foldLower(line);
            if (company.isEmpty() && containsAny(folded, COMPANY)) { company = line; used[i] = true; }
            else if (title.isEmpty() && containsAny(folded, TITLE)) { title = line; used[i] = true; }
            else if ((containsAny(folded, ADDRESS) && (hasDigit(line) || line.contains(","))) || ADDRESS_NUMBER.matcher(folded).find()) {
                Matcher lm = LABEL_PREFIX.matcher(folded); addressLines.add(lm.find() ? line.substring(lm.end()) : line); used[i] = true;
            }
        }
        String name = "";
        for (int i = 0; i < lines.size(); i++) {
            String line = lines.get(i); if (used[i]) continue;
            boolean hasDigit = false; for (char c : line.toCharArray()) if (Character.isDigit(c)) hasDigit = true; if (hasDigit) continue;
            List<String> words = new ArrayList<>(); for (String x : line.split(" ", -1)) if (!x.isEmpty()) words.add(x);
            int letters = 0; for (char c : line.toCharArray()) if (Character.isLetter(c)) letters++;
            boolean allUpper = true; for (String x : words) if (!Character.isUpperCase(x.charAt(0))) allUpper = false;
            if (words.size() >= 2 && words.size() <= 5 && allUpper && letters >= 4) { name = line; break; }
        }
        return new String[]{name, title, company, String.join("\u0001", phones), String.join("\u0001", emails), String.join("\u0001", websites), String.join(", ", addressLines)};
    }
    static String escapeV(String v) { return v.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\r\n", "\\n").replace("\n", "\\n").replace("\r", "\\n"); }
    static String fold75(String line) {
        StringBuilder sb = new StringBuilder(); int bytes = 0, limit = 75;
        for (int i = 0; i < line.length(); ) {
            int cp = line.codePointAt(i); int len = Character.charCount(cp); int size = new String(Character.toChars(cp)).getBytes(StandardCharsets.UTF_8).length;
            if (bytes + size > limit) { sb.append("\r\n "); bytes = 1; limit = 75; }
            sb.appendCodePoint(cp); bytes += size; i += len;
        }
        return sb.toString();
    }
    static String vcard(String name, String title, String company, List<String> phones, List<String> emails, List<String> websites, String address) {
        List<String> lines = new ArrayList<>(); lines.add("BEGIN:VCARD"); lines.add("VERSION:3.0");
        List<String> words = new ArrayList<>(); for (String x : name.split(" ", -1)) if (!x.isEmpty()) words.add(x);
        String family = words.isEmpty() ? "" : words.get(0); String given = words.size() > 1 ? String.join(" ", words.subList(1, words.size())) : "";
        lines.add("N:" + escapeV(family) + ";" + escapeV(given) + ";;;");
        String fn = !name.isEmpty() ? name : !company.isEmpty() ? company : !emails.isEmpty() ? emails.get(0) : !phones.isEmpty() ? phones.get(0) : "";
        lines.add("FN:" + escapeV(fn));
        if (!company.isEmpty()) lines.add("ORG:" + escapeV(company));
        if (!title.isEmpty()) lines.add("TITLE:" + escapeV(title));
        for (String p : phones) lines.add("TEL;TYPE=VOICE:" + escapeV(p));
        for (String e : emails) lines.add("EMAIL;TYPE=INTERNET:" + escapeV(e));
        for (String w : websites) lines.add("URL:" + escapeV(w));
        if (!address.isEmpty()) lines.add("ADR;TYPE=WORK:;;" + escapeV(address) + ";;;;");
        lines.add("END:VCARD");
        StringBuilder sb = new StringBuilder(); for (String l : lines) sb.append(fold75(l)).append("\r\n"); return sb.toString();
    }

    static String unesc(String s) {
        StringBuilder o = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) { char d = s.charAt(i + 1);
                if (d == '\\') { o.append('\\'); i++; } else if (d == 'n') { o.append('\n'); i++; } else if (d == 'u') { o.append((char) Integer.parseInt(s.substring(i + 2, i + 6), 16)); i += 5; } else o.append(c);
            } else o.append(c);
        }
        return o.toString();
    }
    static String enc(String s) {
        StringBuilder o = new StringBuilder();
        for (int i = 0; i < s.length(); i++) { char c = s.charAt(i); if (c == '\\') o.append("\\\\"); else if (c == '\n') o.append("\\n"); else if (c >= 0x20 && c < 0x7F) o.append(c); else o.append(String.format("\\u%04x", (int) c)); }
        return o.toString();
    }
    public static void main(String[] a) throws Exception {
        List<String> out = new ArrayList<>();
        List<String> in = Files.readAllLines(Paths.get(a[1]), StandardCharsets.UTF_8);
        switch (a[0]) {
            case "amount": for (String l : in) { String r = normalizeAmount(unesc(l)); out.add(r == null ? "null" : r); } break;
            case "invoice": for (String l : in) out.add(enc(invoice(unesc(l)))); break;
            case "card": for (String l : in) { String[] c = card(unesc(l)); out.add("name=" + enc(c[0]) + "|title=" + enc(c[1]) + "|company=" + enc(c[2]) + "|phones=" + enc(c[3]) + "|emails=" + enc(c[4]) + "|websites=" + enc(c[5]) + "|address=" + enc(c[6])); } break;
            case "vcard": {
                StringBuilder sb = new StringBuilder();
                for (String l : in) {
                    String[] p = l.split("\t", -1);
                    List<String> phones = new ArrayList<>(), emails = new ArrayList<>(), webs = new ArrayList<>();
                    for (String x : p[3].split("\\|", -1)) if (!x.isEmpty()) phones.add(unesc(x));
                    for (String x : p[4].split("\\|", -1)) if (!x.isEmpty()) emails.add(unesc(x));
                    for (String x : p[5].split("\\|", -1)) if (!x.isEmpty()) webs.add(unesc(x));
                    sb.append(vcard(unesc(p[0]), unesc(p[1]), unesc(p[2]), phones, emails, webs, unesc(p[6])));
                }
                Files.write(Paths.get(a[2]), sb.toString().getBytes(StandardCharsets.UTF_8)); return;
            }
            default: throw new IllegalArgumentException(a[0]);
        }
        Files.write(Paths.get(a[2]), out, StandardCharsets.UTF_8);
    }
}
