"""Quyền mạng cục bộ của Android 17 (phiên 23, mục 4.53). Từ Android 17, app NHẮM targetSdk >= 37 mà gọi ra / nhận vào mạng LAN (kể cả NsdManager, TCP tới máy quét, ServerSocket)
phải khai và xin lúc chạy quyền `ACCESS_LOCAL_NETWORK`; thiếu thì kết nối chỉ báo timeout / EPERM, rất khó đoán nguyên nhân. App dưới 37 có INTERNET được cấp ngầm tạm thời
(developer.android.com/privacy-and-security/local-network-permission). Bộ kiểm này canh đúng một điều: **không ai nâng targetSdk lên 37 mà quên quyền này**.
  - targetSdk < 37  -> đạt, nhưng in danh sách tệp dùng mạng LAN để người nâng cấp biết phải sửa gì;
  - targetSdk >= 37 -> bắt buộc: `<uses-permission ACCESS_LOCAL_NETWORK>` trong manifest VÀ mã Kotlin có xin quyền lúc chạy (chuỗi ACCESS_LOCAL_NETWORK) nếu có tệp dùng LAN.
`--selftest` kiểm chính logic này trên dữ liệu giả (không cần dự án thật)."""
import os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
LAN = re.compile(r"NsdManager|ServerSocket|DatagramSocket|MulticastSocket")

def target_sdk(gradle):
    m = re.search(r"targetSdk\s*=?\s*(\d+)", gradle)
    if not m: raise SystemExit("LOI: không đọc được targetSdk trong app/build.gradle")
    return int(m.group(1))

def judge(target, manifest, kotlin):
    """kotlin = {tên tệp: nội dung}. -> (ok, [thông báo])"""
    lan = sorted(n for n, t in kotlin.items() if LAN.search(t) or n.startswith("Escl"))
    msgs = []
    if target < 37:
        msgs.append(f"targetSdk {target} < 37: chưa bị ép; {len(lan)} tệp dùng mạng LAN sẽ cần quyền khi nâng lên 37: {', '.join(lan) or '(không)'}")
        return True, msgs
    ok = True
    if "android.permission.ACCESS_LOCAL_NETWORK" not in manifest:
        ok = False; msgs.append("targetSdk >= 37 nhưng manifest KHÔNG khai ACCESS_LOCAL_NETWORK")
    asks = [n for n, t in kotlin.items() if "ACCESS_LOCAL_NETWORK" in t]
    if lan and not asks:
        ok = False; msgs.append("targetSdk >= 37, có tệp dùng LAN (" + ", ".join(lan) + ") nhưng không có mã xin quyền ACCESS_LOCAL_NETWORK lúc chạy")
    if ok: msgs.append(f"targetSdk {target}: quyền được khai và có mã xin ({', '.join(asks) or 'không cần'})")
    return ok, msgs

def selftest():
    good = True
    def case(name, got, want):
        nonlocal good
        ok = got == want; good &= ok; print(("ok   " if ok else "LOI  ") + name)
    perm = '<uses-permission android:name="android.permission.ACCESS_LOCAL_NETWORK"/>'
    kt_lan = {"EsclDiscovery.kt": "import android.net.nsd.NsdManager"}
    kt_ask = {"EsclDiscovery.kt": "NsdManager", "Main.kt": 'requestPermissions(arrayOf("android.permission.ACCESS_LOCAL_NETWORK"))'}
    case("36 không ép -> đạt", judge(36, "", kt_lan)[0], True)
    case("37 thiếu quyền trong manifest -> LỖI", judge(37, "", kt_ask)[0], False)
    case("37 có manifest nhưng không xin lúc chạy -> LỖI", judge(37, perm, kt_lan)[0], False)
    case("37 có cả hai -> đạt", judge(37, perm, kt_ask)[0], True)
    case("37 không có tệp LAN, chỉ cần manifest -> đạt", judge(37, perm, {"A.kt": "class A"})[0], True)
    case("40 cũng bị ép", judge(40, "", kt_lan)[0], False)
    case("tệp tên Escl* được coi là dùng LAN", "EsclClient.kt" in judge(36, "", {"EsclClient.kt": "URL(x)"})[1][0], True)
    case("đọc targetSdk dạng 'targetSdk 36' và 'targetSdk = 37'", (target_sdk("targetSdk 36"), target_sdk("targetSdk = 37")), (36, 37))
    try: target_sdk("x"); case("thiếu targetSdk phải báo lỗi", False, True)
    except SystemExit: case("thiếu targetSdk phải báo lỗi", True, True)
    print(); print("TAT CA DAT" if good else "CO LOI"); return 0 if good else 1

def main():
    if "--selftest" in sys.argv: return selftest()
    gradle = open(os.path.join(ROOT, "app", "build.gradle"), encoding="utf-8").read()
    manifest = open(os.path.join(ROOT, "app", "src", "main", "AndroidManifest.xml"), encoding="utf-8").read()
    kotlin = {}
    for dp, _, fs in os.walk(os.path.join(ROOT, "app", "src", "main", "java")):
        for f in fs:
            if f.endswith(".kt"): kotlin[f] = open(os.path.join(dp, f), encoding="utf-8").read()
    ok, msgs = judge(target_sdk(gradle), manifest, kotlin)
    for m in msgs: print(("ok   " if ok else "LOI  ") + m)
    print(); print("TAT CA DAT" if ok else "CO LOI"); return 0 if ok else 1
if __name__ == "__main__": sys.exit(main())
