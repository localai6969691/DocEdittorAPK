#!/usr/bin/env python3
"""ĐO (không phải kiểm tra đạt / không đạt): một phiên bản thứ hai của cùng một PDF chiếm thêm bao nhiêu byte nếu lưu theo MẢNH CHIA THEO NỘI DUNG (FastCDC) thay vì chép nguyên tệp (phiên 25,
TECHNICAL_DOCS.md 4.80).

Cách đo: dựng PDF gốc bằng reportlab (chữ + ảnh JPEG thật), rồi sửa nó bằng CHÍNH MÃ KOTLIN CỦA APP chạy thật qua PdfBox (nét bút `PdfInk`, sửa chữ `PdfTextEditor`, điền ô `PdfFormFiller`, che thông tin
`PdfRedactor` nếu có) - đúng cách trình đọc tạo "phiên bản sau" - rồi chia cả hai theo cùng thuật toán FastCDC (đúng tham số của `util/FileVersions.kt`: nhỏ nhất 16 KiB, trung bình 64 KiB, lớn nhất
256 KiB) và đếm byte của bản sau mà bản trước đã có. Kèm: tỉ lệ nén deflate của chính tệp (để so với "chỉ nén").
Chạy: python3 tools/verify/file_versions_dedup_measure.py   (mất vài phút: biên dịch Kotlin thật)"""
import hashlib, io, os, random, sys, tempfile, zlib
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
import pikepdf  # noqa: E402
from PIL import Image  # noqa: E402
from reportlab.lib.pagesizes import A4  # noqa: E402
from reportlab.pdfgen import canvas  # noqa: E402
from reportlab.lib.utils import ImageReader  # noqa: E402

M64 = (1 << 64) - 1
MIN, AVG, MAX = 16 * 1024, 64 * 1024, 256 * 1024
def gear_table():
    z, out = 0, []
    for _ in range(256):
        z = (z + 0x9E3779B97F4A7C15) & M64
        x = z
        x = ((x ^ (x >> 30)) * 0xBF58476D1CE4E5B9) & M64
        x = ((x ^ (x >> 27)) * 0x94D049BB133111EB) & M64
        out.append(x ^ (x >> 31))
    return out
GEAR = gear_table()
def spread(bits):
    m = 0
    for j in range(bits): m |= 1 << (63 - (j * 64 // bits))
    return m
MASK_S, MASK_L = spread(17), spread(15)
def chunks(data):
    out, off, n = [], 0, len(data)
    while off < n:
        remaining = n - off
        if remaining <= MIN: out.append(data[off:]); break
        limit = min(remaining, MAX); normal = min(AVG, limit); fp = 0; i = MIN; cut = limit
        while i < normal:
            fp = ((fp << 1) + GEAR[data[off + i]]) & M64
            if fp & MASK_S == 0: cut = i + 1; break
            i += 1
        else:
            while i < limit:
                fp = ((fp << 1) + GEAR[data[off + i]]) & M64
                if fp & MASK_L == 0: cut = i + 1; break
                i += 1
        out.append(data[off:off + cut]); off += cut
    return out
def sha(b): return hashlib.sha256(b).digest()

def extra_bytes(old, new):
    have = {sha(c) for c in chunks(old)}; cs = chunks(new)
    fresh = sum(len(c) for c in cs if sha(c) not in have)
    return fresh, len(cs)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="fvmeasure-")
DOUBLE = {"PdfVerify.kt": ("    fun opensAsPdf(file: File, expectedPages: Int): Boolean {",
    "    fun opensAsPdf(file: File, expectedPages: Int): Boolean {\n        return try {\n            if (!file.exists() || file.length() <= 0L) return false\n"
    "            com.tom_roush.pdfbox.pdmodel.PDDocument.load(file).use { d -> d.numberOfPages > 0 && (expectedPages <= 0 || d.numberOfPages == expectedPages) }\n        } catch (e: Exception) { false }\n    }")}
ink = tc.compile(["PdfInk.kt", "PdfPageGeometry.kt", "PdfStructureOptimizer.kt", "PdfVerify.kt"], [os.path.join(HERE, "real_run", "InkHarness.kt")], os.path.join(WORK, "ink"), None, DOUBLE)[0]
tex = tc.compile(["PdfTextEditor.kt", "PdfPageGeometry.kt", "PdfVerify.kt", "PdfFormFiller.kt", "PdfStructureOptimizer.kt"], [os.path.join(HERE, "real_run", "TextEditHarness.kt")], os.path.join(WORK, "tex"), None, DOUBLE)[0]

rnd = random.Random(7)
def photo(seed, w=1200, h=900):
    r = random.Random(seed); im = Image.new("RGB", (w, h))
    px = im.load(); base = [r.randrange(256) for _ in range(3)]
    for y in range(h):
        for x in range(w):
            n = r.randrange(-18, 19); px[x, y] = tuple(max(0, min(255, (base[k] + x * (k + 1) // 9 + y // (k + 2) + n) % 256)) for k in range(3))
    b = io.BytesIO(); im.save(b, "JPEG", quality=82); return b.getvalue()

def make_base(path, kind):
    c = canvas.Canvas(path, pagesize=A4)
    words = "the quick brown fox jumps over the lazy dog while measuring version sizes".split()
    for p in range(1, 21):
        c.setFont("Helvetica", 11)
        for ln in range(45): c.drawString(50, 800 - ln * 16, " ".join(rnd.choice(words) for _ in range(11)) + f" p{p} l{ln}")
        if kind == "photos" and p % 5 == 0:
            c.drawImage(ImageReader(io.BytesIO(photo(p))), 50, 100, 400, 300)
        if kind == "photos" and p == 1:
            c.drawString(60, 760, "Hello World")
        c.showPage()
    if kind == "text": pass
    c.save()

def kib(n): return f"{n / 1024:8.1f} KiB"
rows = []
for kind in ("text", "photos"):
    base = os.path.join(WORK, f"{kind}.pdf"); make_base(base, kind); old = open(base, "rb").read()
    edits = {}
    out = os.path.join(WORK, f"{kind}-ink.pdf")
    r = tc.run(ink, "InkHarnessKt", ["annotate", base, out, "2;0;#D91A1A;0.004;0.1,0.2 0.5,0.4 0.9,0.2"]); edits["một nét bút (PdfInk)"] = out if os.path.exists(out) else None
    out2 = os.path.join(WORK, f"{kind}-text.pdf")
    first = tc.run(tex, "TextEditHarnessKt", ["chunks", base, "1"]).stdout.splitlines()
    idx = int(first[0].split("|")[0]) if first else 0
    r = tc.run(tex, "TextEditHarnessKt", ["apply", base, out2, f"1:{idx}:EDITED LINE"]); edits["sửa một dòng chữ (PdfTextEditor)"] = out2 if os.path.exists(out2) else None
    out3 = os.path.join(WORK, f"{kind}-rewrite.pdf")
    with pikepdf.open(base) as pdf: pdf.save(out3)   # a plain re-save by another writer (how much does a full rewrite hurt?)
    edits["lưu lại bằng trình ghi khác (pikepdf)"] = out3
    for name, path in edits.items():
        if not path: rows.append((kind, name, None)); continue
        new = open(path, "rb").read(); fresh, n = extra_bytes(old, new)
        rows.append((kind, name, (len(old), len(new), fresh, n, len(zlib.compress(new, 6)))))

print(f"{'loại':7} {'cách sửa':42} {'gốc':>12} {'bản sau':>12} {'thêm (theo mảnh)':>18} {'= % bản sau':>11} {'chỉ nén':>12}")
for kind, name, v in rows:
    if v is None: print(f"{kind:7} {name:42} (không tạo được bản sau)"); continue
    a, b, fresh, n, z = v
    print(f"{kind:7} {name:42} {kib(a):>12} {kib(b):>12} {kib(fresh):>18} {100 * fresh / b:10.1f}% {kib(z):>12}")
