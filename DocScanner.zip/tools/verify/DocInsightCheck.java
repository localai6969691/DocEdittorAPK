import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.*;

/**
 * Bản Java song song, CÙNG THUẬT TOÁN, của util/DocInsight.kt (phiên 20, 4.48.3). Dùng bởi doc_insight_check.py. Lệnh qua stdin, mỗi dòng một lệnh (chữ đưa vào ở dạng hex UTF-8):
 *   CLS <hex bảng> <hex chữ> | TOK <hex> | KW <k> <hex chữ> <n> <hex khác>... | KWS <hex chữ> <n> <hex khác>... | SENT <hex> | CAND <hex> | SIM <hex> | RANK <hex> | SUM <m> <hex> | FOLD <hex>
 */
public class DocInsightCheck {
    static String hex(String s) { StringBuilder b = new StringBuilder(); for (byte x : s.getBytes(StandardCharsets.UTF_8)) b.append(String.format("%02x", x)); return b.toString(); }
    static String unhex(String h) { byte[] b = new byte[h.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return new String(b, StandardCharsets.UTF_8); }

    // ---- PiiDetector.fold / foldLower
    static String fold(String text) {
        StringBuilder sb = new StringBuilder(text.length());
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == '\u0111') sb.append('d'); else if (c == '\u0110') sb.append('D');
            else sb.append(Normalizer.normalize(String.valueOf(c), Normalizer.Form.NFD).charAt(0));
        }
        return sb.toString();
    }
    static String foldLower(String text) { String f = fold(text); char[] a = new char[f.length()]; for (int i = 0; i < a.length; i++) a[i] = Character.toLowerCase(f.charAt(i)); return new String(a); }
    static String collapseSpaces(String s) { return s.replaceAll("\\s+", " "); }
    static boolean isWs(char c) { return Character.isWhitespace(c) || Character.isSpaceChar(c); }
    static String ktTrim(String s) { int a = 0, b = s.length(); while (a < b && isWs(s.charAt(a))) a++; while (b > a && isWs(s.charAt(b - 1))) b--; return s.substring(a, b); }

    // ---- phân loại
    static final double MIN_SCORE = 5.0;
    static final int MAX_PER_PHRASE = 3, CLASSIFY_CHARS = 30000;

    static LinkedHashMap<String, List<Object[]>> parseTable(String table) {
        LinkedHashMap<String, List<Object[]>> out = new LinkedHashMap<>();
        for (String line : table.split("\r\n|\n|\r", -1)) {
            String t = ktTrim(line);
            if (t.isEmpty() || t.startsWith("#")) continue;
            String[] p = t.split(" ", 3);
            out.computeIfAbsent(p[0], k -> new ArrayList<>()).add(new Object[]{p[2], Double.parseDouble(p[1])});
        }
        return out;
    }

    static int countPhrase(String low, String phrase) {
        int n = 0, from = 0;
        while (true) {
            int i = low.indexOf(phrase, from);
            if (i < 0) break;
            int end = i + phrase.length();
            char before = i == 0 ? ' ' : low.charAt(i - 1);
            char after = end >= low.length() ? ' ' : low.charAt(end);
            if (!Character.isLetterOrDigit(before) && !Character.isLetterOrDigit(after)) n++;
            from = end;
        }
        return n;
    }

    static String classify(String text, LinkedHashMap<String, List<Object[]>> table) {
        String t = text.length() > CLASSIFY_CHARS ? text.substring(0, CLASSIFY_CHARS) : text;
        String low = collapseSpaces(foldLower(t));
        List<String> cats = new ArrayList<>(table.keySet());
        List<Object[]> scores = new ArrayList<>();
        for (String cat : cats) {
            double s = 0;
            for (Object[] e : table.get(cat)) s += (Double) e[1] * Math.min(countPhrase(low, (String) e[0]), MAX_PER_PHRASE);
            scores.add(new Object[]{cat, s, cats.indexOf(cat)});
        }
        scores.sort((a, b) -> { int c = Double.compare(-(Double) a[1], -(Double) b[1]); return c != 0 ? c : Integer.compare((Integer) a[2], (Integer) b[2]); });
        Object[] best = scores.get(0), second = scores.size() > 1 ? scores.get(1) : null;
        if ((Double) best[1] < MIN_SCORE) return "NONE|" + best[1];
        boolean close = second != null && (Double) second[1] >= 0.7 * (Double) best[1] && (Double) second[1] >= MIN_SCORE;
        return best[0] + "|" + best[1] + "|" + (close ? second[0] : "-") + "|" + (close ? second[1] : 0.0);
    }

    // ---- token
    static class Tok { String text; int start, end; boolean brk; Tok(String t, int s, int e, boolean b) { text = t; start = s; end = e; brk = b; } }

    static List<Tok> tokenize(String text) {
        String low = foldLower(text);
        List<Tok> out = new ArrayList<>();
        int i = 0, newlines = 0;
        boolean brk = true;
        while (i < low.length()) {
            char c = low.charAt(i);
            if (Character.isLetter(c)) {
                int j = i + 1;
                while (j < low.length() && Character.isLetter(low.charAt(j))) j++;
                out.add(new Tok(low.substring(i, j), i, j, brk));
                brk = false; newlines = 0; i = j;
            } else {
                if (c == '\n') { newlines++; if (newlines >= 2) brk = true; }
                else if (c != ' ' && c != '\t' && c != '\r' && c != '-' && c != '\'' && c != '\u2019') brk = true;
                i++;
            }
        }
        return out;
    }

    static final Set<String> STOP = new HashSet<>(Arrays.asList((
        "the and for are but not you all any can had her was one our out has have his how its may new now see two way who did get let put say she too use " +
        "that this with from they will would there their what about which when your said each than them then these those been being into over such only also more most some " +
        "were where while after before between because other should could shall under upon very " +
        "va cua la co cho trong mot cac nhung duoc den tu voi nay do khi khong nhu de da se ve tai theo nguoi nam ngay thang " +
        "cung nen hay hoac neu thi ma ra vao len xuong rat con cac moi tung bi boi lai nua con dang sau truoc cung nhieu it hon so chung toi ta ong ba anh chi dieu ten gom xa hoi chu nghia viet hanh phuc doc lap").split(" ")));

    interface Cand { void on(String key, int words, int start, int end); }

    static void eachCandidate(List<Tok> toks, Cand f) {
        for (int i = 0; i < toks.size(); i++) {
            Tok t = toks.get(i);
            if (t.text.length() >= 4 && !STOP.contains(t.text)) f.on(t.text, 1, t.start, t.end);
            if (i + 1 < toks.size()) {
                Tok u = toks.get(i + 1);
                if (!u.brk && t.text.length() >= 2 && u.text.length() >= 2 && !STOP.contains(t.text) && !STOP.contains(u.text)) f.on(t.text + " " + u.text, 2, t.start, u.end);
            }
        }
    }

    static Map<String, Integer> documentFrequency(List<String> others) {
        Map<String, Integer> df = new HashMap<>();
        for (String o : others) {
            Set<String> seen = new HashSet<>();
            eachCandidate(tokenize(o), (key, w, s, e) -> seen.add(key));
            for (String k : seen) df.merge(k, 1, Integer::sum);
        }
        return df;
    }

    static double idf(int n, int df) { return Math.log((1.0 + n) / (1.0 + df)) + 1.0; }
    static double termScore(int count, int words, int n, int df) { return (1.0 + Math.log(count)) * idf(n, df) * (words == 2 ? 1.5 : 1.0); }

    static class Term { String key; int words, start, end, count; Term(String k, int w, int s, int e) { key = k; words = w; start = s; end = e; } }
    static class Ranked { Term t; double score; Ranked(Term t, double s) { this.t = t; score = s; } }

    static List<Ranked> rankTerms(String text, List<String> others) {
        List<Tok> toks = tokenize(text);
        Map<String, Term> terms = new LinkedHashMap<>();
        eachCandidate(toks, (key, w, s, e) -> terms.computeIfAbsent(key, k -> new Term(k, w, s, e)).count++);
        Map<String, Integer> df = documentFrequency(others);
        int n = others.size() + 1;
        List<Ranked> ranked = new ArrayList<>();
        for (Term t : terms.values()) if (t.count >= 2) ranked.add(new Ranked(t, termScore(t.count, t.words, n, df.getOrDefault(t.key, 0) + 1)));
        ranked.sort((a, b) -> { int c = Double.compare(-a.score, -b.score); return c != 0 ? c : a.t.key.compareTo(b.t.key); });
        return ranked;
    }

    static List<String> keywords(String text, List<String> others, int k) {
        List<Tok> toks = tokenize(text);
        if (toks.size() < 8) return new ArrayList<>();
        List<Ranked> ranked = rankTerms(text, others);
        List<Term> chosen = new ArrayList<>();
        for (Ranked r : ranked) if (r.t.words == 2 && chosen.size() < Math.min(3, k)) chosen.add(r.t);
        Set<String> inPhrases = new HashSet<>();
        for (Term t : chosen) inPhrases.addAll(Arrays.asList(t.key.split(" ")));
        for (Ranked r : ranked) {
            if (chosen.size() >= k) break;
            if (r.t.words == 1 && !inPhrases.contains(r.t.key)) chosen.add(r.t);
        }
        List<String> out = new ArrayList<>();
        for (Term t : chosen) out.add(collapseSpaces(text.substring(t.start, t.end)).toLowerCase(Locale.ROOT));
        return out;
    }

    // ---- câu + TextRank
    static final int MIN_SENTENCE = 30, MAX_SENTENCE = 400, MAX_SENTENCES = 300;

    static List<String> sentences(String text) {
        List<String> paragraphs = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String line : text.split("\r\n|\n|\r", -1)) {
            String t = ktTrim(line);
            if (t.isEmpty()) { if (cur.length() > 0) { paragraphs.add(cur.toString()); cur.setLength(0); } }
            else { if (cur.length() > 0) cur.append(' '); cur.append(t); }
        }
        if (cur.length() > 0) paragraphs.add(cur.toString());
        List<String> out = new ArrayList<>();
        for (String p : paragraphs) {
            int start = 0;
            for (int i = 0; i < p.length(); i++) {
                char c = p.charAt(i);
                boolean cut;
                if (c == '.' || c == '!' || c == '?') cut = i + 1 >= p.length() || isWs(p.charAt(i + 1));
                else cut = c == '\u3002' || c == '\uFF01' || c == '\uFF1F';
                if (cut) { String s = ktTrim(collapseSpaces(p.substring(start, i + 1))); if (!s.isEmpty()) out.add(s); start = i + 1; }
            }
            String rest = ktTrim(collapseSpaces(p.substring(start)));
            if (!rest.isEmpty()) out.add(rest);
        }
        return out;
    }

    static int realWords(String s) { int n = 0; for (Tok t : tokenize(s)) if (t.text.length() >= 2 && !STOP.contains(t.text)) n++; return n; }

    static List<String> candidateSentences(String text) {
        List<String> out = new ArrayList<>();
        for (String s : sentences(text)) if (s.length() >= MIN_SENTENCE && s.length() <= MAX_SENTENCE && realWords(s) >= 4) out.add(s);
        return out.size() > MAX_SENTENCES ? new ArrayList<>(out.subList(0, MAX_SENTENCES)) : out;
    }

    static List<Map<String, Double>> sentenceVectors(List<String> sentences) {
        List<Map<String, Integer>> counts = new ArrayList<>();
        for (String s : sentences) { Map<String, Integer> m = new HashMap<>(); for (Tok t : tokenize(s)) if (t.text.length() >= 2 && !STOP.contains(t.text)) m.merge(t.text, 1, Integer::sum); counts.add(m); }
        Map<String, Integer> df = new HashMap<>();
        for (Map<String, Integer> m : counts) for (String w : m.keySet()) df.merge(w, 1, Integer::sum);
        int n = sentences.size();
        List<Map<String, Double>> out = new ArrayList<>();
        for (Map<String, Integer> m : counts) {
            Map<String, Double> v = new HashMap<>();
            double norm = 0;
            for (Map.Entry<String, Integer> e : m.entrySet()) { double x = e.getValue() * idf(n, df.getOrDefault(e.getKey(), 0)); v.put(e.getKey(), x); norm += x * x; }
            if (norm > 0) { double r = Math.sqrt(norm); for (String w : new ArrayList<>(v.keySet())) v.put(w, v.get(w) / r); }
            out.add(v);
        }
        return out;
    }

    static double cosine(Map<String, Double> a, Map<String, Double> b) {
        Map<String, Double> small = a.size() <= b.size() ? a : b, big = a.size() <= b.size() ? b : a;
        double s = 0;
        for (Map.Entry<String, Double> e : small.entrySet()) { Double y = big.get(e.getKey()); if (y != null) s += e.getValue() * y; }
        return s;
    }

    static double[] pageRank(double[][] w, double alpha) {
        int n = w.length;
        if (n == 0) return new double[0];
        double[] out = new double[n];
        for (int i = 0; i < n; i++) { double s = 0; for (double x : w[i]) s += x; out[i] = s; }
        double[] r = new double[n];
        Arrays.fill(r, 1.0 / n);
        for (int iter = 0; iter < 200; iter++) {
            double dangling = 0;
            for (int i = 0; i < n; i++) if (out[i] == 0.0) dangling += r[i];
            double[] next = new double[n];
            for (int j = 0; j < n; j++) {
                double s = 0;
                for (int i = 0; i < n; i++) if (out[i] > 0.0) s += r[i] * w[i][j] / out[i];
                next[j] = (1.0 - alpha) / n + alpha * (s + dangling / n);
            }
            double diff = 0;
            for (int i = 0; i < n; i++) diff += Math.abs(next[i] - r[i]);
            r = next;
            if (diff < 1e-10) break;
        }
        return r;
    }

    static double[][] similarity(List<String> cands) {
        List<Map<String, Double>> vec = sentenceVectors(cands);
        int n = cands.size();
        double[][] w = new double[n][n];
        for (int i = 0; i < n; i++) for (int j = i + 1; j < n; j++) { double c = cosine(vec.get(i), vec.get(j)); w[i][j] = c; w[j][i] = c; }
        return w;
    }

    static List<String> summary(String text, int m) {
        List<String> cands = candidateSentences(text);
        if (cands.size() <= m) return cands;
        double[] score = pageRank(similarity(cands), 0.85);
        Integer[] idx = new Integer[cands.size()];
        for (int i = 0; i < idx.length; i++) idx[i] = i;
        Arrays.sort(idx, (a, b) -> { int c = Double.compare(-score[a], -score[b]); return c != 0 ? c : Integer.compare(a, b); });
        List<Integer> top = new ArrayList<>(Arrays.asList(idx).subList(0, m));
        Collections.sort(top);
        List<String> out = new ArrayList<>();
        for (int i : top) out.add(cands.get(i));
        return out;
    }

    // ---- CLI
    public static void main(String[] a) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        StringBuilder res = new StringBuilder();
        String line;
        while ((line = in.readLine()) != null) {
            if (line.isEmpty()) continue;
            String[] p = line.split(" ", -1);
            res.append("== ").append(p[0]).append('\n');
            try {
                switch (p[0]) {
                    case "CLS": res.append(classify(unhex(p[2]), parseTable(unhex(p[1])))).append('\n'); break;
                    case "FOLD": res.append(hex(foldLower(unhex(p[1])))).append('\n'); break;
                    case "TOK": for (Tok t : tokenize(unhex(p[1]))) res.append("T|").append(hex(t.text)).append('|').append(t.start).append('|').append(t.end).append('|').append(t.brk ? 1 : 0).append('\n'); break;
                    case "KW": { List<String> others = new ArrayList<>(); int n = Integer.parseInt(p[3]); for (int i = 0; i < n; i++) others.add(unhex(p[4 + i])); for (String k : keywords(unhex(p[2]), others, Integer.parseInt(p[1]))) res.append("K|").append(hex(k)).append('\n'); break; }
                    case "KWS": { List<String> others = new ArrayList<>(); int n = Integer.parseInt(p[2]); for (int i = 0; i < n; i++) others.add(unhex(p[3 + i])); Map<String, Integer> df = documentFrequency(others); for (Ranked r : rankTerms(unhex(p[1]), others)) res.append("R|").append(hex(r.t.key)).append('|').append(r.t.count).append('|').append(r.score).append('|').append(df.getOrDefault(r.t.key, 0) + 1).append('\n'); break; }
                    case "SENT": for (String s : sentences(unhex(p[1]))) res.append("S|").append(hex(s)).append('\n'); break;
                    case "CAND": for (String s : candidateSentences(unhex(p[1]))) res.append("S|").append(hex(s)).append('\n'); break;
                    case "SIM": { double[][] w = similarity(candidateSentences(unhex(p[1]))); for (double[] row : w) { StringBuilder b = new StringBuilder("M"); for (double x : row) b.append('|').append(x); res.append(b).append('\n'); } break; }
                    case "RANK": { double[] r = pageRank(similarity(candidateSentences(unhex(p[1]))), 0.85); for (double x : r) res.append("P|").append(x).append('\n'); break; }
                    case "SUM": for (String s : summary(unhex(p[2]), Integer.parseInt(p[1]))) res.append("S|").append(hex(s)).append('\n'); break;
                    default: res.append("?\n");
                }
            } catch (Exception e) { res.append("ERR ").append(e).append('\n'); }
        }
        System.out.print(res);
    }
}
