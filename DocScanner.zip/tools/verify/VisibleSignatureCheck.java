import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.Deflater;

/**
 * Java twin of app/.../util/VisibleSignature.kt (phiên 22, 4.49.10): userRect, formMatrix, visualSize and templatePdf, same arithmetic (float) and same bytes.
 *   rect <llx> <lly> <urx> <ury> <rotation> [w h margin]            -> "llx lly urx ury"
 *   template <out.pdf> <llx> <lly> <urx> <ury> <rotation> <imgW> <imgH> <rgbFile> [w h margin]  -> writes the one-page template, prints the widget rectangle
 */
public class VisibleSignatureCheck {
    static final float W = 200f, H = 58f, M = 24f;
    static int rot(int r) { return ((r % 360) + 360) % 360; }

    static float[] userRect(float[] box, int rotation, float w, float h, float margin) {
        int r = rot(rotation); float bw = box[2] - box[0], bh = box[3] - box[1];
        float vw = (r == 90 || r == 270) ? bh : bw, vh = (r == 90 || r == 270) ? bw : bh;
        float s = 1f; float roomW = vw - 2 * margin, roomH = vh - 2 * margin; boolean roomy = roomW > 0 && roomH > 0;
        if (roomy) s = Math.min(1f, Math.min(roomW / w, roomH / h)); else if (vw > 0 && vh > 0) s = Math.min(1f, Math.min(vw / w, vh / h));
        float sw = w * s, sh = h * s; float x0 = vw - (roomy ? margin : 0f) - sw, y0 = vh - (roomy ? margin : 0f) - sh;
        float llx = Float.MAX_VALUE, lly = Float.MAX_VALUE, urx = -Float.MAX_VALUE, ury = -Float.MAX_VALUE;
        float[][] corners = {{x0, y0}, {x0 + sw, y0}, {x0, y0 + sh}, {x0 + sw, y0 + sh}};
        for (float[] c : corners) {
            float vx = c[0], vy = c[1], ux, uy;
            switch (r) { case 90: ux = vy; uy = vx; break; case 180: ux = bw - vx; uy = vy; break; case 270: ux = bw - vy; uy = bh - vx; break; default: ux = vx; uy = bh - vy; }
            llx = Math.min(llx, ux); lly = Math.min(lly, uy); urx = Math.max(urx, ux); ury = Math.max(ury, uy);
        }
        return new float[]{box[0] + llx, box[1] + lly, box[0] + urx, box[1] + ury};
    }
    static float[] visualSize(float[] rect, int rotation) { float w = rect[2] - rect[0], h = rect[3] - rect[1]; int r = rot(rotation); return (r == 90 || r == 270) ? new float[]{h, w} : new float[]{w, h}; }
    static float[] formMatrix(int rotation) {
        switch (rot(rotation)) { case 90: return new float[]{0, 1, -1, 0, 0, 0}; case 180: return new float[]{-1, 0, 0, -1, 0, 0}; case 270: return new float[]{0, -1, 1, 0, 0, 0}; default: return new float[]{1, 0, 0, 1, 0, 0}; }
    }
    static String num(float v) { String s = String.format(Locale.US, "%.3f", v); s = s.replaceAll("0+$", ""); if (s.endsWith(".")) s = s.substring(0, s.length() - 1); return (s.equals("-0") || s.isEmpty()) ? "0" : s; }
    static String nums(float[] a) { StringBuilder sb = new StringBuilder(); for (int i = 0; i < a.length; i++) sb.append(i > 0 ? " " : "").append(num(a[i])); return sb.toString(); }

    static byte[] templatePdf(float[] box, int rotation, float[] rect, int iw, int ih, byte[] rgb) throws IOException {
        float[] wh = visualSize(rect, rotation); float w = wh[0], h = wh[1];
        Deflater d = new Deflater(Deflater.BEST_COMPRESSION); ByteArrayOutputStream packed = new ByteArrayOutputStream();
        d.setInput(rgb); d.finish(); byte[] buf = new byte[16 * 1024]; while (!d.finished()) { int n = d.deflate(buf); packed.write(buf, 0, n); } d.end();
        byte[] image = packed.toByteArray(); byte[] content = ("q " + num(w) + " 0 0 " + num(h) + " 0 0 cm /Im0 Do Q").getBytes("US-ASCII");
        ByteArrayOutputStream out = new ByteArrayOutputStream(); List<Integer> offsets = new ArrayList<>();
        w(out, "%PDF-1.4\n%\u00E2\u00E3\u00CF\u00D3\n");
        offsets.add(out.size()); w(out, "1 0 obj\n<< /Type /Catalog /Pages 2 0 R /AcroForm << /Fields [4 0 R] /SigFlags 3 >> >>\nendobj\n");
        offsets.add(out.size()); w(out, "2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n");
        offsets.add(out.size()); w(out, "3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [" + nums(box) + "] /CropBox [" + nums(box) + "] /Rotate " + rot(rotation) + " /Resources << >> /Annots [4 0 R] >>\nendobj\n");
        offsets.add(out.size()); w(out, "4 0 obj\n<< /Type /Annot /Subtype /Widget /FT /Sig /T (Signature1) /Rect [" + nums(rect) + "] /F 132 /P 3 0 R /AP << /N 5 0 R >> >>\nendobj\n");
        offsets.add(out.size()); w(out, "5 0 obj\n<< /Type /XObject /Subtype /Form /FormType 1 /BBox [0 0 " + num(w) + " " + num(h) + "] /Matrix [" + nums(formMatrix(rotation)) + "] /Resources << /XObject << /Im0 6 0 R >> >> /Length " + content.length + " >>\nstream\n");
        out.write(content); w(out, "\nendstream\nendobj\n");
        offsets.add(out.size()); w(out, "6 0 obj\n<< /Type /XObject /Subtype /Image /Width " + iw + " /Height " + ih + " /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length " + image.length + " >>\nstream\n");
        out.write(image); w(out, "\nendstream\nendobj\n");
        int xref = out.size(); w(out, "xref\n0 7\n0000000000 65535 f \n");
        for (int o : offsets) w(out, String.format(Locale.US, "%010d 00000 n \n", o));
        w(out, "trailer\n<< /Size 7 /Root 1 0 R >>\nstartxref\n" + xref + "\n%%EOF\n");
        return out.toByteArray();
    }
    static void w(ByteArrayOutputStream o, String s) throws IOException { o.write(s.getBytes("ISO-8859-1")); }

    public static void main(String[] a) throws Exception {
        float[] box = {Float.parseFloat(a[a[0].equals("rect") ? 1 : 2]), Float.parseFloat(a[a[0].equals("rect") ? 2 : 3]), Float.parseFloat(a[a[0].equals("rect") ? 3 : 4]), Float.parseFloat(a[a[0].equals("rect") ? 4 : 5])};
        if (a[0].equals("rect")) {
            int rotation = Integer.parseInt(a[5]); float w = a.length > 6 ? Float.parseFloat(a[6]) : W, h = a.length > 7 ? Float.parseFloat(a[7]) : H, m = a.length > 8 ? Float.parseFloat(a[8]) : M;
            System.out.println(nums(userRect(box, rotation, w, h, m)));
        } else {
            int rotation = Integer.parseInt(a[6]); int iw = Integer.parseInt(a[7]), ih = Integer.parseInt(a[8]); byte[] rgb = Files.readAllBytes(Paths.get(a[9]));
            float w = a.length > 10 ? Float.parseFloat(a[10]) : W, h = a.length > 11 ? Float.parseFloat(a[11]) : H, m = a.length > 12 ? Float.parseFloat(a[12]) : M;
            float[] rect = userRect(box, rotation, w, h, m);
            Files.write(Paths.get(a[1]), templatePdf(box, rotation, rect, iw, ih, rgb));
            System.out.println(nums(rect));
        }
    }
}
