#!/usr/bin/env python3
"""Sửa chữ trong trình đọc CHẠY THẬT (`util/PdfTextEditor.kt`; phiên 25, TECHNICAL_DOCS.md 4.69): vị trí từng đoạn chữ (theo dõi cm / BT / Tm / Td / TD / T* / ' / " qua q-Q), chọn đoạn dưới ngón tay,
thử sửa trên bản nháp và ghi các sửa vào bản sao.

So vị trí với POPPLER (pdftotext -bbox, độc lập với mã): trang 600x800 xoay 0/90/180/270, có và không có CropBox lệch gốc; mỗi đoạn chữ phải nằm đúng chỗ poppler thấy chữ đó (x trong 2 pt,
tâm dọc trong nửa cỡ chữ). Rồi: chạm giữa chữ chọn đúng đoạn, chạm chỗ trống không chọn gì; sửa "Hello" -> "Howdy" đọc lại bằng pdftotext, các dòng khác còn nguyên; chữ ngoài bảng mã bị báo
MissingGlyphs (không ghi); sửa hai đoạn cùng trang; chỉ số ngoài phạm vi báo lỗi và KHÔNG tạo tệp.
THAY THẾ DUY NHẤT so với mã thật: `PdfVerify.opensAsPdf` (PdfRenderer của Android) -> kiểm bằng PdfBox. KHÔNG kiểm được: cảm ứng thật trên màn hình, phông nhúng tập con của máy thật.
Chạy: python3 tools/verify/text_edit_real_run_check.py"""
import os, re, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
import pikepdf  # noqa: E402
from pikepdf import Array, Dictionary, Name  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="tedit-")
DOUBLE = {"PdfVerify.kt": ("    fun opensAsPdf(file: File, expectedPages: Int): Boolean {",
    "    fun opensAsPdf(file: File, expectedPages: Int): Boolean {\n        return try {\n            if (!file.exists() || file.length() <= 0L) return false\n"
    "            com.tom_roush.pdfbox.pdmodel.PDDocument.load(file).use { d -> d.numberOfPages > 0 && (expectedPages <= 0 || d.numberOfPages == expectedPages) }\n        } catch (e: Exception) { false }\n    }")}
FILES = ["PdfTextEditor.kt", "PdfPageGeometry.kt", "PdfVerify.kt", "PdfFormFiller.kt", "PdfStructureOptimizer.kt"]
HARNESS = os.path.join(HERE, "real_run", "TextEditHarness.kt")
cls = tc.compile(FILES, [HARNESS], os.path.join(WORK, "cls"), None, DOUBLE)[0]
def run(*a):
    r = tc.run(cls, "TextEditHarnessKt", list(a))
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-1200:])
    return r.stdout
def sh(*c): return subprocess.run(c, capture_output=True, text=True)

# A page whose text is placed with every kind of positioning operator. Words are unique so each chunk can be matched with poppler's words.
CONTENT = b"""BT /F1 20 Tf 100 700 Td (Hello World) Tj ET
BT /F1 14 Tf 100 650 Td 16 TL (Alpha Bravo) Tj T* (Charlie Delta) Tj (Echo Foxtrot) ' ET
q 0.5 0 0 0.5 300 300 cm BT /F1 40 Tf 100 100 Td (Golf Hotel) Tj ET Q
BT /F1 18 Tf 1 0 0 1 100 400 Tm (India) Tj 120 0 Td (Juliet) Tj ET
BT /F1 16 Tf 100 350 Td [(Kilo) -300 (Lima)] TJ ET
BT /F1 16 Tf 50 Tz 100 300 Td (Mike November) Tj ET
BT /F1 16 Tf 100 250 Td 5 Ts (Oscar) Tj ET
"""
def make_pdf(path, rotate=0, crop=False):
    pdf = pikepdf.new(); font = pdf.make_indirect(Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Helvetica, Encoding=Name.WinAnsiEncoding))
    pdf.add_blank_page(page_size=(600, 800)); p = pdf.pages[0]
    p.Resources = Dictionary(Font=Dictionary(F1=font)); p.Contents = pdf.make_stream(CONTENT)
    if crop: p.CropBox = Array([30, 40, 570, 760])
    if rotate: p.Rotate = rotate
    pdf.save(path, compress_streams=False)

def poppler_words(pdf, cropbox, rotate=0):
    args = ["pdftotext", "-bbox"] + (["-cropbox"] if cropbox else []) + ["-f", "1", "-l", "1", pdf, "-"]
    out = sh(*args).stdout
    # poppler writes <page width height> of the UNROTATED page while the word boxes are in the rotated frame, so the displayed size comes from the page we made: 600x800 or the 540x720 CropBox, swapped for 90 / 270
    w, h = (540.0, 720.0) if cropbox else (600.0, 800.0)
    if rotate in (90, 270): w, h = h, w
    words = {m.group(5): tuple(map(float, m.groups()[:4])) for m in re.finditer(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">([^<]*)</word>', out)}
    return w, h, words

def our_chunks(pdf, page=1):
    res = []
    for line in run("chunks", pdf, str(page)).splitlines():
        i, box, text = line.split("|", 2); res.append((int(i), list(map(float, box.split())), text))
    return res

print("== A. vị trí đoạn chữ so với poppler: 4 hướng xoay x CropBox")
for rot in (0, 90, 180, 270):
    for crop in (False, True):
        pdf = os.path.join(WORK, f"p-{rot}-{int(crop)}.pdf"); make_pdf(pdf, rot, crop)
        w, h, words = poppler_words(pdf, crop, rot); chunks = our_chunks(pdf)
        bad = []
        if len(chunks) != 10: bad.append(f"{len(chunks)} đoạn (mong đợi đúng 10)")
        for _, box, text in chunks:
            ws = [words[t] for t in words if len(t) >= 3 and t in text]   # 'KiloLima' (a TJ) is two words for poppler
            if not ws: bad.append(f"poppler không thấy '{text}'"); continue
            px0, py0 = min(a[0] for a in ws), min(a[1] for a in ws); px1, py1 = max(a[2] for a in ws), max(a[3] for a in ws)
            ox0, oy0, ox1, oy1 = box[0] * w, box[1] * h, box[2] * w, box[3] * h
            size = max(py1 - py0, 4.0)
            if abs(ox0 - px0) > 2.5 or abs(ox1 - px1) > 2.5 or abs((oy0 + oy1) / 2 - (py0 + py1) / 2) > size * 0.5 or not (oy0 <= (py0 + py1) / 2 <= oy1):
                bad.append(f"'{text}' ta ({ox0:.1f},{oy0:.1f},{ox1:.1f},{oy1:.1f}) poppler ({px0:.1f},{py0:.1f},{px1:.1f},{py1:.1f})")
        check(not bad, f"xoay {rot} {'CropBox lệch' if crop else 'không CropBox'}: {len(chunks)} đoạn khớp poppler" + ("" if not bad else " :: " + "; ".join(bad[:3])))

print("== B. chọn đoạn dưới ngón tay")
pdf = os.path.join(WORK, "p-0-0.pdf"); chunks = our_chunks(pdf); by = {t: (i, b) for i, b, t in chunks}
i, b = by["Hello World"]; mid = ((b[0] + b[2]) / 2, (b[1] + b[3]) / 2)
check(run("pick", pdf, "1", str(mid[0]), str(mid[1])).strip() == str(i), "chạm giữa 'Hello World' chọn đúng đoạn")
check(run("pick", pdf, "1", "0.95", "0.97").strip() == "-1", "chạm chỗ trống không chọn gì")
i2, b2 = by["Alpha Bravo"]; check(run("pick", pdf, "1", str((b2[0] + b2[2]) / 2), str((b2[1] + b2[3]) / 2)).strip() == str(i2), "chạm giữa 'Alpha Bravo' (dòng nhỏ hơn, cách 'Hello World' 50 pt) chọn đúng đoạn")

print("== C. thử sửa, ghi vào bản sao")
iH = by["Hello World"][0]
check(run("trial", pdf, "1", str(iH), "Howdy World").strip() == "Success", "thử 'Howdy World' -> Success")
check(run("trial", pdf, "1", str(iH), "Xin chào Việt").strip().startswith("MissingGlyphs"), "chữ Việt ngoài bảng mã WinAnsi -> MissingGlyphs (không ghi)")
check(run("trial", pdf, "1", "999", "x").strip() == "ChunkNotFound", "chỉ số ngoài phạm vi -> ChunkNotFound")
out = os.path.join(WORK, "edited.pdf"); iA = by["Alpha Bravo"][0]
r = run("apply", pdf, out, f"1:{iH}:Howdy World|1:{iA}:Zulu Yankee").strip().splitlines()[-1]
check(r == "OK" and os.path.exists(out), f"ghi 2 sửa trên cùng trang: {r}")
txt = sh("pdftotext", "-layout", out, "-").stdout
check("Howdy World" in txt and "Zulu Yankee" in txt, "pdftotext đọc lại thấy chữ mới")
check("Hello World" not in txt and "Alpha Bravo" not in txt, "chữ cũ không còn")
check(all(w in txt for w in ("Charlie Delta", "Echo Foxtrot", "Golf Hotel", "India", "Juliet", "Kilo", "Lima", "Mike November", "Oscar")), "các dòng khác còn nguyên")
check(len(pikepdf.open(out).pages) == 1, "số trang không đổi")
bad = os.path.join(WORK, "bad.pdf"); r = run("apply", pdf, bad, "1:999:x").strip().splitlines()[-1]
check(r.startswith("ERR") and not os.path.exists(bad), f"chỉ số sai báo lỗi và KHÔNG tạo tệp: {r}")
# the edited copy keeps the places: the new text sits where the old one was
w, h, words = poppler_words(out, False); ow, oh, old = poppler_words(pdf, False)
check("Howdy" in words and abs(words["Howdy"][0] - old["Hello"][0]) < 1.5 and abs(words["Howdy"][1] - old["Hello"][1]) < 1.5, "chữ mới nằm đúng chỗ chữ cũ")

print("== E. điền ô biểu mẫu chạm tại chỗ (4.71): vị trí ô so với toán học độc lập, 4 hướng xoay x CropBox")
from reportlab.pdfgen import canvas as rl_canvas  # noqa: E402
FIELDS = {"nm": (100, 600, 200, 24), "ok": (120, 500, 18, 18), "ch": (100, 400, 150, 24)}   # x, y, w, h in user space of a 600x800 page
def make_form(path, rotate=0, crop=False):
    base = os.path.join(WORK, "form-base.pdf"); c = rl_canvas.Canvas(base, pagesize=(600, 800))
    c.acroForm.textfield(name="nm", x=100, y=600, width=200, height=24, value="Anna", borderStyle="solid")
    c.acroForm.checkbox(name="ok", x=120, y=500, size=18, checked=False)
    c.acroForm.choice(name="ch", x=100, y=400, width=150, height=24, value="B", options=["A", "B", "C"], fieldFlags="combo")
    c.showPage(); c.save(); pdf = pikepdf.open(base)
    if crop: pdf.pages[0].CropBox = Array([30, 40, 570, 760])
    if rotate: pdf.pages[0].Rotate = rotate
    pdf.save(path)
def expected_box(name, rot, crop):
    x, y, w, h = FIELDS[name]; llx, lly, W, H = (30, 40, 540, 720) if crop else (0, 0, 600, 800)
    xs = [x - llx, x + w - llx]; ys = [y - lly, y + h - lly]
    pts = []
    for px in xs:
        for py in ys:
            pts.append({0: (px, H - py), 90: (py, px), 180: (W - px, py), 270: (H - py, W - px)}[rot])   # from the top-left of the displayed page
    dw, dh = (H, W) if rot in (90, 270) else (W, H)
    return min(p[0] for p in pts) / dw, min(p[1] for p in pts) / dh, max(p[0] for p in pts) / dw, max(p[1] for p in pts) / dh, dw, dh
def our_fields(pdf):
    res = {}
    for line in run("fields", pdf, "1").splitlines():
        n, kind, value, box = line.split("|", 3); res[n] = (kind, value, list(map(float, box.split())))
    return res
for rot in (0, 90, 180, 270):
    for crop in (False, True):
        pdf = os.path.join(WORK, f"f-{rot}-{int(crop)}.pdf"); make_form(pdf, rot, crop); got = our_fields(pdf); bad = []
        if sorted(got) != ["ch", "nm", "ok"]: bad.append(f"ô thấy được: {sorted(got)}")
        for n in ("nm", "ok", "ch"):
            if n not in got: continue
            ex = expected_box(n, rot, crop); b = got[n][2]; dw, dh = ex[4], ex[5]
            if max(abs(b[0] - ex[0]) * dw, abs(b[1] - ex[1]) * dh, abs(b[2] - ex[2]) * dw, abs(b[3] - ex[3]) * dh) > 0.6: bad.append(f"{n}: ta {[round(v, 4) for v in b]} mong đợi {[round(v, 4) for v in ex[:4]]}")
        check(not bad, f"xoay {rot} {'CropBox lệch' if crop else 'không CropBox'}: 3 ô (chữ, hộp kiểm, chọn) đúng chỗ" + ("" if not bad else " :: " + "; ".join(bad[:2])))
pdf = os.path.join(WORK, "f-0-0.pdf"); got = our_fields(pdf)
check(got["nm"][0] == "TEXT" and got["nm"][1] == "Anna" and got["ok"][0] == "CHECKBOX" and got["ok"][1] == "false" and got["ch"][0] == "CHOICE" and got["ch"][1] == "B", "loại và giá trị hiện có của từng ô đúng")
b = got["nm"][2]; check(run("pickfield", pdf, "1", str((b[0] + b[2]) / 2), str((b[1] + b[3]) / 2)).strip() == "nm", "chạm giữa ô chữ chọn đúng ô")
check(run("pickfield", pdf, "1", "0.9", "0.9").strip() == "-", "chạm chỗ trống không chọn ô nào")
out = os.path.join(WORK, "filled.pdf"); r = run("fill", pdf, out, "nm=Bob|ok=true|ch=C").strip().splitlines()[-1]
check(r == "3" and os.path.exists(out), f"điền 3 ô vào bản sao: {r}")
filled_pdf = pikepdf.open(out); vals = {str(f.T): f for f in filled_pdf.Root.AcroForm.Fields}
check(str(vals["nm"].V) == "Bob" and str(vals["ch"].V) == "C" and str(vals["ok"].V) != "/Off", "pikepdf đọc lại: chữ 'Bob', chọn 'C', hộp kiểm đã tích")
txt = sh("pdftotext", out, "-").stdout
check("Bob" in txt, "chữ điền vào hiện ra trên trang (pdftotext thấy 'Bob')")
bad2 = os.path.join(WORK, "bad-form.pdf"); r = run("fill", os.path.join(WORK, "p-0-0.pdf"), bad2, "nm=x").strip().splitlines()[-1]
check(r.startswith("ERR") and not os.path.exists(bad2), f"PDF không có biểu mẫu: báo lỗi, không tạo tệp ({r})")

print("== D. thử âm tính: mã cố tình sai PHẢI bị bắt")
def golf_ok(cls_dir, rot):
    pdf = os.path.join(WORK, f"p-{rot}-0.pdf"); w, h, words = poppler_words(pdf, False, rot)
    r = tc.run(cls_dir, "TextEditHarnessKt", ["chunks", pdf, "1"]); good = True
    for line in r.stdout.splitlines():
        _, box, text = line.split("|", 2); b = list(map(float, box.split()))
        if text == "Golf Hotel":
            px0 = min(words[t][0] for t in ("Golf", "Hotel")); py0 = min(words[t][1] for t in ("Golf", "Hotel"))
            good = abs(b[0] * w - px0) <= 2.5 and abs(b[1] * h - py0) <= 12
    return good
MUTANTS = {"bỏ theo dõi `cm` (chữ trong khối q ... cm sai chỗ)": ("PdfTextEditor.kt", '"cm" -> numbersBefore(i, 6)?.let { state.ctm = multiply(it, state.ctm) }', '"cm" -> {}', 0),
           "bỏ đổi theo xoay trang (dùng toạ độ gốc)": ("PdfTextEditor.kt", "val dx = inv[0] * us[k] + inv[2] * vs[k] + inv[4]\n                val dy = inv[1] * us[k] + inv[3] * vs[k] + inv[5]", "val dx = us[k]\n                val dy = vs[k]", 90)}
def field_ok(cls_dir):
    pdf = os.path.join(WORK, "f-90-0.pdf"); ex = expected_box("nm", 90, False)
    r = tc.run(cls_dir, "TextEditHarnessKt", ["fields", pdf, "1"]).stdout.splitlines()
    for line in r:
        n, _, _, box = line.split("|", 3)
        if n == "nm":
            b = list(map(float, box.split())); return max(abs(b[0] - ex[0]) * ex[4], abs(b[1] - ex[1]) * ex[5]) <= 0.6
    return False
MUTANTS["bỏ lật trục dọc của ô biểu mẫu"] = ("PdfFormFiller.kt", "val fy = 1f - (inv[1] * us[k] + inv[3] * vs[k] + inv[5]) / h", "val fy = (inv[1] * us[k] + inv[3] * vs[k] + inv[5]) / h", -1)
for name, (f, old, new, rot) in MUTANTS.items():
    try:
        mdir = tc.compile(FILES, [HARNESS], os.path.join(WORK, "mut"), {f: (old, new)}, DOUBLE)[0]
        check(not (field_ok(mdir) if rot < 0 else golf_ok(mdir, rot)), f"mã sai bị bắt: {name}")
    except RuntimeError as e:
        check(False, f"mutant không biên dịch được: {name}: {str(e)[:120]}")

print()
print("TAT CA DAT" if not fails else f"{len(fails)} LOI")
sys.exit(1 if fails else 0)
