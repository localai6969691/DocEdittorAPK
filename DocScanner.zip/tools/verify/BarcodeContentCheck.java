// Bản Java chạy được của BarcodeContent (phiên 17): cùng logic, cùng thứ tự với app/.../util/BarcodeContent.kt.
// Dùng bởi barcode_content_check.py: java BarcodeContentCheck.java <tệp ca> <tệp ra>.
// Ca: mỗi dòng "<0|1 là mã sản phẩm>\t<chuỗi thô, \n viết thành \\n, \\ viết thành \\\\>". Ra: "KIND\tkhoá=giá trị\t..." (xuống dòng/tab trong giá trị viết thành \n / \t).
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class BarcodeContentCheck {
    static LinkedHashMap<String, String> semicolonFields(String raw, int from) {
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        int i = from;
        while (i < raw.length()) {
            int c = raw.indexOf(':', i);
            if (c < 0) break;
            String key = raw.substring(i, c).trim().toUpperCase(Locale.ROOT);
            i = c + 1;
            StringBuilder chars = new StringBuilder(); List<Boolean> esc = new ArrayList<>();
            while (i < raw.length()) {
                char ch = raw.charAt(i);
                if (ch == '\\' && i + 1 < raw.length()) { chars.append(raw.charAt(i + 1)); esc.add(true); i += 2; }
                else if (ch == ';') { i++; break; }
                else { chars.append(ch); esc.add(false); i++; }
            }
            String v = chars.toString();
            if (v.length() >= 2 && v.charAt(0) == '"' && !esc.get(0) && v.charAt(v.length() - 1) == '"' && !esc.get(esc.size() - 1)) v = v.substring(1, v.length() - 1);
            if (!key.isEmpty() && !out.containsKey(key)) out.put(key, v);
            if (i < raw.length() && raw.charAt(i) == ';') break;
        }
        return out;
    }
    static LinkedHashMap<String, String> vLines(String raw) {
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        for (String line : raw.split("\n", -1)) {
            String l = strip(line, "\r ");
            int c = l.indexOf(':');
            if (c <= 0) continue;
            String name = l.substring(0, c); int sc = name.indexOf(';'); if (sc >= 0) name = name.substring(0, sc);
            name = name.trim().toUpperCase(Locale.ROOT);
            if (name.equals("BEGIN") || name.equals("END") || name.equals("VERSION")) continue;
            if (!out.containsKey(name)) out.put(name, l.substring(c + 1).trim());
        }
        return out;
    }
    static String strip(String s, String chars) { int a = 0, e = s.length(); while (a < e && chars.indexOf(s.charAt(a)) >= 0) a++; while (e > a && chars.indexOf(s.charAt(e - 1)) >= 0) e--; return s.substring(a, e); }
    static int hex(char c) { if (c >= '0' && c <= '9') return c - '0'; if (c >= 'a' && c <= 'f') return c - 'a' + 10; if (c >= 'A' && c <= 'F') return c - 'A' + 10; return -1; }
    static String percentDecode(String s) {
        if (s.indexOf('%') < 0) return s;
        StringBuilder out = new StringBuilder(); ByteArrayOutputStream pending = new ByteArrayOutputStream();
        int i = 0;
        while (i < s.length()) {
            char ch = s.charAt(i);
            if (ch == '%' && i + 2 < s.length() && hex(s.charAt(i + 1)) >= 0 && hex(s.charAt(i + 2)) >= 0) { pending.write(hex(s.charAt(i + 1)) * 16 + hex(s.charAt(i + 2))); i += 3; }
            else { if (pending.size() > 0) { out.append(new String(pending.toByteArray(), StandardCharsets.UTF_8)); pending.reset(); } out.append(ch); i++; }
        }
        if (pending.size() > 0) out.append(new String(pending.toByteArray(), StandardCharsets.UTF_8));
        return out.toString();
    }
    static LinkedHashMap<String, String> queryMap(String q) {
        LinkedHashMap<String, String> out = new LinkedHashMap<>();
        for (String pair : q.split("&", -1)) {
            int e = pair.indexOf('=');
            if (e <= 0) continue;
            String k = percentDecode(pair.substring(0, e)).toLowerCase(Locale.ROOT);
            if (!out.containsKey(k)) out.put(k, percentDecode(pair.substring(e + 1)));
        }
        return out;
    }
    static boolean anyWhite(String s) { for (char c : s.toCharArray()) if (Character.isWhitespace(c)) return true; return false; }
    static String g(Map<String, String> m, String k) { String v = m.get(k); return v == null ? "" : v; }
    static boolean allDigits(String s) { if (s.isEmpty()) return false; for (char c : s.toCharArray()) if (c < '0' || c > '9') return false; return true; }

    static String parse(String rawInput, boolean product) {
        String raw = rawInput.trim(); String upper = raw.toUpperCase(Locale.ROOT);
        LinkedHashMap<String, String> f = new LinkedHashMap<>();
        if (raw.isEmpty()) return "TEXT";
        if (upper.startsWith("WIFI:")) {
            Map<String, String> m = semicolonFields(raw, 5);
            String ssid = g(m, "S");
            if (!ssid.isEmpty()) {
                String t = m.containsKey("T") ? m.get("T") : "nopass";
                String sec = t.isEmpty() ? "nopass" : (t.toUpperCase(Locale.ROOT).equals("NOPASS") ? "nopass" : t.toUpperCase(Locale.ROOT));
                f.put("ssid", ssid); f.put("password", g(m, "P")); f.put("security", sec); f.put("hidden", (m.containsKey("H") ? m.get("H") : "false").toLowerCase(Locale.ROOT));
                return fmt("WIFI", f);
            }
        } else if (upper.startsWith("MATMSG:")) {
            Map<String, String> m = semicolonFields(raw, 7);
            f.put("address", g(m, "TO")); f.put("subject", g(m, "SUB")); f.put("body", g(m, "BODY")); return fmt("EMAIL", f);
        } else if (upper.startsWith("MAILTO:")) {
            String rest = raw.substring(7); int q = rest.indexOf('?');
            String addr = percentDecode(q >= 0 ? rest.substring(0, q) : rest);
            Map<String, String> query = q >= 0 ? queryMap(rest.substring(q + 1)) : new HashMap<>();
            f.put("address", addr); f.put("subject", g(query, "subject")); f.put("body", g(query, "body")); return fmt("EMAIL", f);
        } else if (upper.startsWith("TEL:")) {
            f.put("number", percentDecode(raw.substring(4)).trim()); return fmt("PHONE", f);
        } else if (upper.startsWith("SMSTO:") || upper.startsWith("SMS:")) {
            String rest = raw.substring(raw.indexOf(':') + 1);
            if (upper.startsWith("SMS:") && rest.indexOf('?') >= 0) {
                int q = rest.indexOf('?'); Map<String, String> query = queryMap(rest.substring(q + 1));
                f.put("number", percentDecode(rest.substring(0, q))); f.put("body", g(query, "body")); return fmt("SMS", f);
            }
            int c = rest.indexOf(':');
            if (c >= 0) { f.put("number", rest.substring(0, c)); f.put("body", rest.substring(c + 1)); } else { f.put("number", rest); f.put("body", ""); }
            return fmt("SMS", f);
        } else if (upper.startsWith("GEO:")) {
            String rest = raw.substring(4); int q = rest.indexOf('?'); if (q >= 0) rest = rest.substring(0, q);
            String[] parts = rest.split(",", -1);
            try {
                double lat = Double.parseDouble(parts[0].trim()), lon = Double.parseDouble(parts[1].trim());
                if (lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180) { f.put("lat", parts[0].trim()); f.put("lon", parts[1].trim()); return fmt("GEO", f); }
            } catch (Exception e) { }
        } else if (upper.startsWith("MECARD:")) {
            Map<String, String> m = semicolonFields(raw, 7); String n = g(m, "N");
            String name = n.indexOf(',') >= 0 ? n.substring(n.indexOf(',') + 1).trim() + " " + n.substring(0, n.indexOf(',')).trim() : n;
            f.put("name", name.trim()); f.put("phone", g(m, "TEL")); f.put("email", g(m, "EMAIL")); f.put("org", g(m, "ORG")); return fmt("CONTACT", f);
        } else if (upper.startsWith("BEGIN:VCARD")) {
            Map<String, String> v = vLines(raw);
            String name;
            if (v.containsKey("FN")) name = v.get("FN");
            else if (v.containsKey("N")) { List<String> ps = new ArrayList<>(); for (String x : v.get("N").split(";", -1)) if (!x.isEmpty()) ps.add(x); Collections.reverse(ps); name = String.join(" ", ps); }
            else name = "";
            f.put("name", name); f.put("phone", g(v, "TEL")); f.put("email", g(v, "EMAIL")); f.put("org", g(v, "ORG")); return fmt("CONTACT", f);
        } else if (upper.startsWith("BEGIN:VEVENT") || upper.startsWith("BEGIN:VCALENDAR")) {
            Map<String, String> v = vLines(raw);
            f.put("summary", g(v, "SUMMARY")); f.put("start", g(v, "DTSTART")); f.put("end", g(v, "DTEND")); f.put("location", g(v, "LOCATION")); return fmt("EVENT", f);
        } else if (upper.startsWith("HTTP://") || upper.startsWith("HTTPS://")) {
            if (!anyWhite(raw)) { f.put("url", raw); return fmt("URL", f); }
        } else if (upper.startsWith("WWW.") && !anyWhite(raw) && raw.indexOf('.') >= 0) {
            f.put("url", "https://" + raw); return fmt("URL", f);
        }
        if (product && allDigits(raw)) {
            boolean isbn = raw.length() == 13 && (raw.startsWith("978") || raw.startsWith("979"));
            f.put("code", raw); f.put("isbn", isbn ? raw : ""); return fmt("PRODUCT", f);
        }
        f.put("text", raw); return fmt("TEXT", f);
    }
    static String esc(String v) { return v.replace("\\", "\\\\").replace("\n", "\\n").replace("\t", "\\t").replace("\r", "\\r"); }
    static String fmt(String kind, Map<String, String> f) { StringBuilder b = new StringBuilder(kind); for (Map.Entry<String, String> e : f.entrySet()) b.append("\t").append(e.getKey()).append("=").append(esc(e.getValue())); return b.toString(); }
    static String unesc(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) { char c = s.charAt(i); if (c == '\\' && i + 1 < s.length()) { char d = s.charAt(++i); b.append(d == 'n' ? '\n' : d == 't' ? '\t' : d == 'r' ? '\r' : d); } else b.append(c); }
        return b.toString();
    }
    public static void main(String[] a) throws Exception {
        List<String> in = Files.readAllLines(Paths.get(a[0]), StandardCharsets.UTF_8);
        StringBuilder out = new StringBuilder();
        for (String ln : in) { int t = ln.indexOf('\t'); out.append(parse(unesc(ln.substring(t + 1)), ln.charAt(0) == '1')).append("\n"); }
        Files.write(Paths.get(a[1]), out.toString().getBytes(StandardCharsets.UTF_8));
    }
}
