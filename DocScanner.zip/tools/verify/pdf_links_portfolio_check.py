"""Kiểm chứng PdfAutoLinks (tự tạo liên kết cho địa chỉ web / email) và PDF Portfolio của PdfStructureTools (phiên 18).

PdfAutoLinks.kt và PdfStructureTools.setPortfolio gọi PdfBox, KHÔNG chạy được ở đây. Bài kiểm này:
A - NHẬN DIỆN: LinkTokensCheck.java (bản Java của PdfAutoLinks.classify) so với bảng chân trị viết tay + 1 500 chuỗi ngẫu nhiên so với bản tham chiếu Python viết riêng;
B - HÌNH HỌC + HIỆU LỰC: dựng PDF chữ thật (Helvetica 12), lấy từ + ký tự bằng pdfplumber, dựng LẠI từng bước của addLinks bằng pikepdf, rồi đo bằng công cụ độc lập:
    pypdf (URI đúng từng ký tự, không dư không thiếu), poppler `pdftotext -bbox` (vùng bấm trùng hộp chữ thật: lệch trái <= 1,5 pt, phủ >= 70% chiều cao chữ), qpdf --check,
    chạy lần hai không thêm liên kết trùng, trang xoay (/Rotate 90) bị bỏ qua và được đếm;
C - PORTFOLIO: dựng lại setPortfolio; qpdf đạt, /Collection đúng khoá, tệp đính kèm còn nguyên (pdfdetach, pypdf), tắt thì gỡ sạch, bật khi chưa có tệp bị từ chối.
GIỚI HẠN (nói thẳng): không chứng minh lời gọi PdfBox (PDFTextStripper...) biên dịch / chạy đúng, và toạ độ TextPosition của PdfBox có thể lệch vài phần trăm so với pdfplumber
(bài kiểm đo bằng poppler với dung sai). Portfolio: chỉ kiểm cấu trúc - chưa mở bằng Acrobat.
Chạy: python3 pdf_links_portfolio_check.py   (cần pikepdf, pypdf, pdfplumber, poppler-utils, qpdf, java 11+)
"""
import os, random, re, shutil, subprocess, sys, tempfile
import pikepdf, pypdf, pdfplumber
from pikepdf import Array, Dictionary, Name, String
HERE = os.path.dirname(os.path.abspath(__file__)); FAILS = []
def check(c, w):
    print(("ok  " if c else "LOI"), w)
    if not c: FAILS.append(w)
tmp = tempfile.mkdtemp(prefix="linksport_"); P = lambda n: os.path.join(tmp, n)
def run(*a): return subprocess.run(list(a), capture_output=True, text=True)

# ---------------------------------------------------------------- A. nhận diện
URL = re.compile(r"^(https?://|www\.)[^\s<>\"]+$", re.I); EMAIL = re.compile(r"^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$")
LEAD = "([{<'\"“‘"; TRAIL = ".,;:!?)]}>'\"”’"
def ref_classify(w):
    s, e = 0, len(w)
    while s < e and w[s] in LEAD: s += 1
    while e > s and w[e - 1] in TRAIL: e -= 1
    if e <= s: return "-"
    t = w[s:e]
    if URL.match(t) and URL.fullmatch(t): return f"{s} {e} " + ("https://" + t if t.lower().startswith("www.") else t)
    if EMAIL.fullmatch(t): return f"{s} {e} mailto:{t}"
    return "-"
def java_classify(words):
    open(P("w.txt"), "w", encoding="utf-8").write("\n".join(words) + "\n")
    r = run("java", os.path.join(HERE, "LinkTokensCheck.java"), P("w.txt")); return r.stdout.rstrip("\n").split("\n")
TRUTH = [("https://example.com", "0 19 https://example.com"), ("(http://x.org/p).", "1 15 http://x.org/p"), ("www.test.vn.", "0 11 https://www.test.vn"), ("WWW.Test.VN,", "0 11 https://WWW.Test.VN"),
         ("ai@example.com.", "0 14 mailto:ai@example.com"), ("<ai@x.io>", "1 8 mailto:ai@x.io"), ("“https://a.b/c”", "1 14 https://a.b/c"), ("http://", "-"), ("www.", "-"), ("https://", "-"),
         ("xin", "-"), ("a@b", "-"), ("a@b.c", "-"), ("@example.com", "-"), ("ftp://x.org", "-"), ("example.com", "-"), ("...", "-"), ("", "-"), ("https://x.org/a?b=1&c=2", "0 23 https://x.org/a?b=1&c=2"),
         ("http://localhost:8080/x", "0 23 http://localhost:8080/x"), ("a.b@c-d.vn", "0 10 mailto:a.b@c-d.vn")]
got = java_classify([w for w, _ in TRUTH])
check(got == [e for _, e in TRUTH], f"{len(TRUTH)} từ viết tay (cắt dấu câu hai đầu, www -> https, email -> mailto, từ rỗng / giả) khớp bảng chân trị")
rnd = random.Random(7); pieces = ["http://", "https://", "www.", "a", "b.c", ".", ",", "(", ")", "@", "x.org", "/p", "?q=1", "<", ">", "“", "”", "mail", ".vn", "ai@", "-", "_", "%", "é"]
fuzz = ["".join(rnd.choice(pieces) for _ in range(rnd.randint(1, 7))) for _ in range(1500)]
check(java_classify(fuzz) == [ref_classify(w) for w in fuzz], "1 500 chuỗi ngẫu nhiên: bản Java khớp bản tham chiếu Python viết riêng")

# ---------------------------------------------------------------- B. hình học + hiệu lực
LINES = ["Truy cap https://example.com/a?b=1, hoac www.test.vn.", "Email: ai@example.com. Khong phai: example.com a@b http://", "(http://x.org/p) va <ai@x.io> xong", "van ban thuong khong co gi"]
H = 792
def text_pdf(rotate=0, with_existing=False):
    pdf = pikepdf.Pdf.new(); pdf.add_blank_page(page_size=(612, H)); pg = pdf.pages[0]
    pg.Resources = Dictionary(Font=Dictionary(F1=Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Helvetica)))
    pg.Contents = pdf.make_stream(("BT /F1 12 Tf " + " ".join(f"1 0 0 1 72 {700 - 30*i} Tm ({l.replace('(', chr(92)+'(').replace(')', chr(92)+')')}) Tj" for i, l in enumerate(LINES)) + " ET").encode())
    if rotate: pg.obj.Rotate = rotate
    return pdf
def mirror_add_links(path_in, path_out):
    """Phản chiếu PdfAutoLinks.addLinks: từng TỪ -> classify -> hộp chữ (x0..x1 của các ký tự đã cắt, đường cơ sở, 0,25 / 0,8 cỡ chữ) -> chú thích Link; bỏ qua trang xoay; không đè liên kết có sẵn."""
    pdf = pikepdf.open(path_in); added = 0; skipped = 0
    with pdfplumber.open(path_in) as pl:
        for pi, page in enumerate(pl.pages):
            if int(pdf.pages[pi].obj.get("/Rotate", 0)) % 360 != 0:
                # Kotlin: page.rotation % 360 != 0 -> bỏ qua trang; từ lấy bằng poppler (pdfplumber chỉ trả chữ thẳng đứng nên không thấy gì ở trang xoay)
                raw = run("pdftotext", "-raw", path_in, "-").stdout.split()
                if any(c != "-" for c in java_classify(raw)): skipped += 1
                continue
            words = page.extract_words(keep_blank_chars=False, use_text_flow=False, extra_attrs=["size"])
            cls = java_classify([w["text"] for w in words]) if words else []
            pgobj = pdf.pages[pi].obj; rot = int(pgobj.get("/Rotate", 0)) % 360
            for w, c in zip(words, cls):
                if c == "-": continue
                if rot != 0: skipped += 1; break
                st, en, uri = c.split(" ", 2); st, en = int(st), int(en)
                chars = [ch for ch in page.chars if abs(ch["x0"] - w["x0"]) >= -1 and w["x0"] - 0.01 <= ch["x0"] <= w["x1"] + 0.01 and abs(ch["top"] - w["top"]) < 3]
                chars = sorted(chars, key=lambda ch: ch["x0"])[st:en]
                x0 = min(ch["x0"] for ch in chars); x1 = max(ch["x1"] for ch in chars); base = chars[0]["matrix"][5]; fs = chars[0]["size"]
                rect = [x0, base - 0.25 * fs, x1, base + 0.8 * fs]
                existing = [a for a in pgobj.get("/Annots", []) if str(a.get("/Subtype")) == "/Link"]
                def overlaps(a):
                    r = [float(v) for v in a.Rect]; ix = min(r[2], rect[2]) - max(r[0], rect[0]); iy = min(r[3], rect[3]) - max(r[1], rect[1])
                    return ix > 0 and iy > 0 and ix * iy >= 0.5 * (rect[2] - rect[0]) * (rect[3] - rect[1])
                if any(overlaps(a) for a in existing): continue
                annot = pdf.make_indirect(Dictionary(Type=Name.Annot, Subtype=Name.Link, Rect=Array(rect), Border=Array([0, 0, 0]), A=Dictionary(S=Name.URI, URI=String(uri))))
                if "/Annots" not in pgobj: pgobj.Annots = Array()
                pgobj.Annots.append(annot); added += 1
    pdf.save(path_out); pdf.close(); return added, skipped
print("== B. hình học + hiệu lực ==")
tp = text_pdf(); tp.save(P("t.pdf")); tp.close()
added, skipped = mirror_add_links(P("t.pdf"), P("t_links.pdf"))
EXPECT_URIS = ["https://example.com/a?b=1", "https://www.test.vn", "mailto:ai@example.com", "http://x.org/p", "mailto:ai@x.io"]
rd = pypdf.PdfReader(P("t_links.pdf")); uris = [a.get_object()["/A"]["/URI"] for a in (rd.pages[0].get("/Annots") or [])]
check(sorted(uris) == sorted(EXPECT_URIS) and added == 5 and skipped == 0, f"pypdf: đúng 5 liên kết, URI chuẩn hoá đúng, không dư không thiếu: {uris}")
check(run("qpdf", "--check", P("t_links.pdf")).returncode in (0, 3) and run("pdftoppm", "-r", "30", "-png", "-singlefile", P("t_links.pdf"), P("v")).returncode == 0, "qpdf --check đạt, poppler vẽ được")
bb = run("pdftotext", "-bbox", P("t.pdf"), P("bbox.html")); html = open(P("bbox.html"), encoding="utf-8").read()
pwords = [(float(a), float(b), float(c), float(d), t) for a, b, c, d, t in re.findall(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(.*?)</word>', html)]
ok_geo = True; checked = 0
import html as htmlmod
for a in (rd.pages[0].get("/Annots") or []):
    a = a.get_object(); r = [float(v) for v in a["/Rect"]]; top, bot = H - r[3], H - r[1]; uri = a["/A"]["/URI"]
    key = uri.replace("mailto:", "").replace("https://www.", "www.") if "www.test" in uri else uri.replace("mailto:", "")
    cand = [w for w in pwords if htmlmod.unescape(w[4]).lstrip("(<“").startswith(key[:12])]
    if not cand: ok_geo = False; print("  không thấy từ poppler cho", uri); continue
    x0, y0, x1, y1, _ = cand[0]; checked += 1
    vov = max(0, min(bot, y1) - max(top, y0)) / (y1 - y0)
    lead = htmlmod.unescape(cand[0][4])[0] in "(<“"      # dấu câu đầu từ bị cắt khỏi vùng bấm: rộng tới ~7 pt ở cỡ 12
    left_ok = (x0 - 1.6 <= r[0] <= x0 + 9.0) if lead else abs(r[0] - x0) <= 1.6
    if not left_ok or r[2] > x1 + 1.6 or r[2] < x1 - 9 or vov < 0.7: ok_geo = False; print("  lệch:", uri, r, (x0, y0, x1, y1), round(vov, 2))
check(ok_geo and checked == 5, f"hộp bấm trùng hộp chữ do poppler đo ({checked}/5): lệch trái <= 1,6 pt, phủ >= 70% chiều cao chữ")
added2, _ = mirror_add_links(P("t_links.pdf"), P("t_links2.pdf"))
check(added2 == 0, "chạy lần hai: không thêm liên kết đè lên liên kết đã có (0 mới)")
tr = text_pdf(rotate=90); tr.save(P("rot.pdf")); tr.close()
a3, s3 = mirror_add_links(P("rot.pdf"), P("rot_out.pdf"))
check(a3 == 0 and s3 == 1 and run("qpdf", "--check", P("rot_out.pdf")).returncode in (0, 3), f"trang xoay /Rotate 90: bỏ qua và được đếm (thêm {a3}, bỏ qua {s3} trang) - không đoán toạ độ")

# ---------------------------------------------------------------- C. Portfolio
def embedded(pdf):
    names = pdf.Root.get("/Names"); return names is not None and "/EmbeddedFiles" in names
def mirror_set_portfolio(pdf, enable):
    """Phản chiếu PdfStructureTools.setPortfolio."""
    if enable:
        if not embedded(pdf): raise RuntimeError("no attachments")
        pdf.Root.Collection = Dictionary(Type=Name.Collection, View=Name.D)
    elif "/Collection" in pdf.Root: del pdf.Root["/Collection"]
print("== C. PDF Portfolio ==")
pdf = pikepdf.Pdf.new(); pdf.add_blank_page(page_size=(200, 200))
efs = []
for n, d in (("a.txt", b"AAA"), ("b.pdf", b"%PDF-fake")):
    st = pdf.make_stream(d); st.Type = Name.EmbeddedFile; efs.append((n, pdf.make_indirect(Dictionary(Type=Name.Filespec, F=String(n), UF=String(n), EF=Dictionary(F=st, UF=st)))))
pdf.Root.Names = Dictionary(EmbeddedFiles=Dictionary(Names=Array([x for n, f in efs for x in (String(n), f)])))
try: mirror_set_portfolio(pdf, True); refused = False
except RuntimeError: refused = False
none = pikepdf.Pdf.new(); none.add_blank_page(); 
try: mirror_set_portfolio(none, True); rejected = False
except RuntimeError: rejected = True
check(rejected, "bật Portfolio khi CHƯA có tệp đính kèm bị từ chối (Portfolio rỗng vô nghĩa)")
pdf.save(P("port.pdf")); pdf.close()
rp = pikepdf.open(P("port.pdf")); c = rp.Root.Collection
check(str(c.Type) == "/Collection" and str(c.View) == "/D" and "/Collection" in rp.Root, "Catalog có /Collection << /Type /Collection /View /D >>"); rp.close()
q = run("qpdf", "--check", P("port.pdf")); lst = run("pdfdetach", "-list", P("port.pdf")).stdout
check(q.returncode in (0, 3) and lst.startswith("2 embedded files") and set(pypdf.PdfReader(P("port.pdf")).attachments) == {"a.txt", "b.pdf"} and run("pdfinfo", P("port.pdf")).returncode == 0, "qpdf đạt; tệp đính kèm còn nguyên (pdfdetach, pypdf); poppler vẫn mở như PDF thường")
rp = pikepdf.open(P("port.pdf")); mirror_set_portfolio(rp, False); rp.save(P("port_off.pdf")); rp.close()
rp = pikepdf.open(P("port_off.pdf"))
check("/Collection" not in rp.Root and run("pdfdetach", "-list", P("port_off.pdf")).stdout.startswith("2 embedded files") and run("qpdf", "--check", P("port_off.pdf")).returncode in (0, 3), "tắt Portfolio: gỡ sạch /Collection, tệp đính kèm vẫn còn"); rp.close()

shutil.rmtree(tmp, ignore_errors=True)
print("\nTAT CA DAT" if not FAILS else f"\n{len(FAILS)} LOI"); sys.exit(1 if FAILS else 0)
