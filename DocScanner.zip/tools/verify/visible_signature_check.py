"""Dấu hiển thị của chữ ký số (phiên 22, mục 4.49.10): VisibleSignature.kt (bản Java VisibleSignatureCheck.java, cùng phép tính float và cùng byte PDF mẫu).
Điểm khó là TRANG XOAY: chú thích xoay theo trang, nên dấu phải ĐỌC XUÔI khi nhìn và nằm ở GÓC DƯỚI PHẢI THẤY ĐƯỢC. Bộ kiểm render bằng poppler (`pdftoppm`) trang mẫu (cùng CropBox + Rotate
với trang đích) rồi so điểm ảnh với kết quả mong đợi dựng ĐỘC LẬP (dán hình dấu xuôi vào góc dưới phải của ảnh trang đã xoay):
  1. 5 hộp trang x 4 góc xoay = 20 ca: hộp A4 dọc / ngang, gốc khác 0 (10,20), gốc ÂM (-50,-50), trang rất nhỏ (dấu phải thu nhỏ vừa trang): tương quan chéo chuẩn hoá (NCC) >= 0,97 trong vùng dấu (>= 0,85 khi dấu bị thu nhỏ vì trang nhỏ: poppler và PIL lấy mẫu lại khác nhau) VÀ hộp bao các điểm ảnh khác trắng trùng hộp mong đợi trong 2 điểm ảnh (không phụ thuộc cách lấy mẫu),
     và ngoài vùng dấu trang vẫn trắng;
  2. mẫu PDF hợp lệ: `qpdf --check`, pikepdf đọc được cấu trúc (AcroForm, widget Sig, F=132, Rect, AP/N, BBox, Matrix, ảnh), byte giống nhau giữa hai lần chạy (xác định);
  3. mô phỏng GHÉP vào PDF đích nhiều trang (trang cuối xoay, có nội dung): chép widget + AcroForm bằng pikepdf như PDFBox làm, render lại: dấu vẫn đúng chỗ, `qpdf --check` sạch;
  4. THỬ ÂM TÍNH: nếu dùng ma trận đơn vị cho trang xoay 90, hình bị nghiêng -> NCC thấp (bài kiểm có răng); và nếu đặt dấu ở góc dưới TRÁI thì NCC thấp.
Chạy: python3 visible_signature_check.py   (cần java, pikepdf, numpy, pillow, pdftoppm, qpdf; ~40 giây)
"""
import io, os, subprocess, sys, tempfile
import numpy as np
from PIL import Image
import pikepdf
from _common import OUT

HERE = os.path.dirname(os.path.abspath(__file__)); JAVA = os.path.join(HERE, "VisibleSignatureCheck.java")
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)
work = tempfile.mkdtemp(prefix="vs_", dir=OUT)

# hình dấu bất đối xứng 200x58: nửa trái đỏ có chữ F trắng, thanh xanh trên cùng bên phải, chấm vàng dưới cùng bên phải
IW, IH = 200, 58
img = np.full((IH, IW, 3), 255, np.uint8); img[:, :100] = (200, 40, 40)
img[6:52, 14:22] = 255; img[6:14, 14:60] = 255; img[24:32, 14:46] = 255                       # chữ F trắng
img[2:10, 110:196] = (30, 60, 200); img[46:54, 170:196] = (240, 200, 20)
Image.fromarray(img).save(os.path.join(work, "stamp.png")); rgb_path = os.path.join(work, "stamp.rgb"); open(rgb_path, "wb").write(img.tobytes())

def java(args):
    r = subprocess.run(["java", JAVA] + [str(x) for x in args], capture_output=True, text=True)
    if r.returncode != 0: raise RuntimeError(r.stderr[-800:])
    return r.stdout.strip()

def render(pdf, page=1, dpi=72):
    base = os.path.join(work, "r_" + os.path.basename(pdf).replace(".pdf", ""))
    subprocess.run(["pdftoppm", "-r", str(dpi), "-f", str(page), "-l", str(page), "-png", pdf, base], check=True, capture_output=True)
    f = [x for x in os.listdir(work) if x.startswith(os.path.basename(base)) and x.endswith(".png")][0]
    im = np.array(Image.open(os.path.join(work, f)).convert("L"), np.float32); os.remove(os.path.join(work, f)); return im

def expected(vw, vh, sw, sh, x0, y0, flip_x=False):
    """grayscale page (white) with the UPRIGHT stamp scaled to sw x sh pasted at visual (x0, y0); flip_x puts it at the bottom LEFT instead (negative control)"""
    canvas = np.full((vh, vw), 255, np.float32)
    st = np.array(Image.fromarray(img).convert("L").resize((max(1, round(sw)), max(1, round(sh))), Image.BILINEAR), np.float32)
    if flip_x: x0 = 24
    xi, yi = round(x0), round(y0); canvas[yi:yi + st.shape[0], xi:xi + st.shape[1]] = st[: vh - yi, : vw - xi]
    return canvas, (xi, yi, st.shape[1], st.shape[0])

def ncc(a, b):
    a = a - a.mean(); b = b - b.mean(); d = np.sqrt((a * a).sum() * (b * b).sum()); return float((a * b).sum() / d) if d else 0.0

boxes = [("a4_portrait", (0, 0, 595, 842)), ("a4_landscape", (0, 0, 842, 595)), ("origin_10_20", (10, 20, 410, 620)), ("negative_origin", (-50, -50, 350, 450)), ("tiny", (0, 0, 150, 100))]
bad = []; worst = 1.0
for name, box in boxes:
    for rotation in (0, 90, 180, 270):
        pdf = os.path.join(work, f"t_{name}_{rotation}.pdf")
        rect = [float(x) for x in java(["template", pdf, *box, rotation, IW, IH, rgb_path]).split()]
        bw, bh = box[2] - box[0], box[3] - box[1]; vw, vh = (bh, bw) if rotation in (90, 270) else (bw, bh)
        got = render(pdf)
        if got.shape != (vh, vw): bad.append((name, rotation, "kích thước trang", got.shape, (vh, vw))); continue
        # kích thước dấu mong đợi: thu nhỏ nếu trang nhỏ
        roomy = vw - 48 > 0 and vh - 48 > 0; s = min(1.0, (vw - 48) / 200, (vh - 48) / 58) if roomy else min(1.0, vw / 200, vh / 58)
        sw, sh = 200 * s, 58 * s; mg = 24 if roomy else 0
        exp, (xi, yi, ew, eh) = expected(vw, vh, sw, sh, vw - mg - sw, vh - mg - sh)
        region = (slice(max(0, yi - 2), yi + eh + 2), slice(max(0, xi - 2), xi + ew + 2))
        score = ncc(got[region], exp[region]); worst = min(worst, score)
        outside = got.copy(); outside[region] = 255
        def bbox(a):
            ys, xs = np.where(a < 250); return (xs.min(), ys.min(), xs.max(), ys.max()) if len(xs) else None
        gb, eb = bbox(got), bbox(exp)
        edge_ok = gb is not None and max(abs(int(g) - int(e)) for g, e in zip(gb, eb)) <= 2          # the stamp's pixels span the same box (independent of resampling)
        need = 0.97 if s >= 0.999 else 0.85                                                             # a stamp scaled down (tiny page) is resampled differently by poppler and PIL
        if score < need or not edge_ok or (outside < 250).sum() > 0.002 * outside.size: bad.append((name, rotation, round(score, 3), gb, eb, int((outside < 250).sum())))
check(not bad, f"20 ca (5 hộp trang x 4 góc xoay): dấu ĐỌC XUÔI và đúng GÓC DƯỚI PHẢI THẤY ĐƯỢC, NCC thấp nhất {worst:.3f}, ngoài vùng dấu trang vẫn trắng{'' if not bad else ' ' + str(bad[:3])}")

# 2. cấu trúc mẫu
pdf = os.path.join(work, "t_a4_portrait_90.pdf"); rect = [float(x) for x in java(["template", pdf, 0, 0, 595, 842, 90, IW, IH, rgb_path]).split()]
q = subprocess.run(["qpdf", "--check", pdf], capture_output=True, text=True)
check(q.returncode == 0 and "No syntax or stream encoding errors" in q.stdout, "mẫu: `qpdf --check` sạch")
with pikepdf.open(pdf) as p:
    page = p.pages[0]; w = page.Annots[0]; ap = w.AP.N
    ok = (str(w.Subtype) == "/Widget" and str(w.FT) == "/Sig" and int(w.F) == 132 and [round(float(x), 2) for x in w.Rect] == [round(x, 2) for x in rect] and int(page.Rotate) == 90
          and [float(x) for x in ap.Matrix] == [0, 1, -1, 0, 0, 0] and [round(float(x), 2) for x in ap.BBox] == [0, 0, 200, 58]
          and int(ap.Resources.XObject.Im0.Width) == IW and bool(p.Root.AcroForm.SigFlags == 3) and len(p.Root.AcroForm.Fields) == 1)
check(ok, f"mẫu: widget Sig, F=132, Rect {rect}, AP/N có BBox + Matrix [0 1 -1 0 0 0] cho trang xoay 90, ảnh {IW}x{IH}, AcroForm SigFlags 3")
pdf2 = os.path.join(work, "again.pdf"); java(["template", pdf2, 0, 0, 595, 842, 90, IW, IH, rgb_path])
check(open(pdf, "rb").read() == open(pdf2, "rb").read(), "mẫu: hai lần chạy cho CÙNG byte (xác định, không phụ thuộc giờ hay ngôn ngữ máy)")
r = subprocess.run(["java", "-Duser.language=vi", "-Duser.country=VN", JAVA, "template", os.path.join(work, "vi.pdf"), "0", "0", "595", "842", "90", str(IW), str(IH), rgb_path], capture_output=True, text=True)
check(r.returncode == 0 and open(os.path.join(work, "vi.pdf"), "rb").read() == open(pdf, "rb").read(), "mẫu: ngôn ngữ máy tiếng Việt (dấu phẩy thập phân) KHÔNG đổi byte nào")

# 3. mô phỏng ghép vào PDF đích nhiều trang
def merged(rotation, box, label):
    target = pikepdf.new(); 
    for i in range(3):
        target.add_blank_page(page_size=(box[2] - box[0], box[3] - box[1]))
    last = target.pages[-1]; last.MediaBox = pikepdf.Array(list(box)); last.CropBox = pikepdf.Array(list(box)); last.Rotate = rotation
    last.Contents = target.make_stream(b"0.9 0.9 0.9 rg 100 100 100 100 re f")
    tpl_pdf = os.path.join(work, f"m_tpl_{label}.pdf"); java(["template", tpl_pdf, *box, rotation, IW, IH, rgb_path])
    with pikepdf.open(tpl_pdf) as tpl:
        widget = target.copy_foreign(tpl.pages[0].Annots[0]); widget.P = last.obj
        last.Annots = pikepdf.Array([widget])
        target.Root.AcroForm = pikepdf.Dictionary(Fields=pikepdf.Array([widget]), SigFlags=3)
    out = os.path.join(work, f"merged_{label}.pdf"); target.save(out); return out
for rotation in (0, 90, 180, 270):
    box = (0, 0, 595, 842); out = merged(rotation, box, f"r{rotation}")
    bw, bh = 595, 842; vw, vh = (bh, bw) if rotation in (90, 270) else (bw, bh)
    got = render(out, page=3); exp, (xi, yi, ew, eh) = expected(vw, vh, 200, 58, vw - 24 - 200, vh - 24 - 58)
    region = (slice(yi - 2, yi + eh + 2), slice(xi - 2, xi + ew + 2)); score = ncc(got[region], exp[region])
    qc = subprocess.run(["qpdf", "--check", out], capture_output=True, text=True)
    check(score >= 0.97 and qc.returncode == 0, f"ghép vào PDF 3 trang (trang cuối xoay {rotation}, có nội dung): dấu đúng chỗ NCC {score:.3f}, qpdf sạch")

# 4. thử âm tính
pdf = os.path.join(work, "t_a4_portrait_90.pdf")
with pikepdf.open(pdf) as p:
    p.pages[0].Annots[0].AP.N.Matrix = pikepdf.Array([1, 0, 0, 1, 0, 0]); p.save(os.path.join(work, "neg_matrix.pdf"))
got = render(os.path.join(work, "neg_matrix.pdf")); exp, (xi, yi, ew, eh) = expected(842, 595, 200, 58, 842 - 24 - 200, 595 - 24 - 58)
region = (slice(yi - 2, yi + eh + 2), slice(xi - 2, xi + ew + 2))
check(ncc(got[region], exp[region]) < 0.6, f"ÂM TÍNH: ma trận đơn vị trên trang xoay 90 làm hình bị nghiêng (NCC {ncc(got[region], exp[region]):.3f} < 0,6): bài kiểm có răng")
pdf0 = os.path.join(work, "t_a4_portrait_0.pdf"); got = render(pdf0); exp, (xi, yi, ew, eh) = expected(595, 842, 200, 58, 595 - 24 - 200, 842 - 24 - 58, flip_x=True)
exp_right, _ = expected(595, 842, 200, 58, 595 - 24 - 200, 842 - 24 - 58)
check(ncc(got, exp_right) > ncc(got, exp) + 0.2, "ÂM TÍNH: dấu ở góc dưới PHẢI chứ không phải góc dưới TRÁI (phân biệt được hai vị trí)")

print(); print("TAT CA DAT" if not fails else f"{len(fails)} LOI: {fails}")
sys.exit(1 if fails else 0)
