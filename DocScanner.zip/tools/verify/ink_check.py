"""Chú thích mực thật `PdfInk` (phiên 23, mục 4.62): nét vẽ tay (bút / bút dạ) ghi thành chú thích /Ink có luồng hiển thị riêng.
  A. Phần thuần (bản Java InkCheck.java = chép từng câu PdfInk.kt) so với mô hình Python độc lập: simplify (giữ đầu / cuối, là dãy con, không hai điểm liên tiếp gần hơn ngưỡng),
     simplifyCapped (trần ~1 500 điểm), bounds, appearance (từng ký tự).
  B. VẼ THẬT bằng poppler: trang 600x800 với 4 hướng xoay x (CropBox = MediaBox | CropBox lệch gốc) x (bút | bút dạ) = 16 trang; điểm người dùng thấy (toạ độ 0..1 từ góc trên-trái)
     đổi sang không gian người dùng bằng bản chép của PdfPageGeometry.toUser, nội dung luồng hiển thị lấy từ bản Java. Đo ảnh: dọc nét có mực đúng màu, chỗ xa nét trắng, vị trí
     đối xứng sai (chuyển vị) trắng; bút dạ trong suốt (nhân màu) chứ không đè kín.
  C. Cấu trúc: /Subtype /Ink, /InkList là mảng của mảng số, /BS /W, /F 4, /Rect bao hết điểm, luồng hiển thị đúng bản Java, qpdf --check sạch.
  D. THỬ ÂM TÍNH: bỏ đổi toạ độ theo xoay / CropBox thì nét vẽ SAI CHỖ (bị bắt); bản Java đặt 'rg' thay 'RG' (màu nét không được đặt) và bản bỏ '/GS gs' (bút dạ đặc) bị bắt.
Chạy: python3 ink_check.py   (cần java, pikepdf, Pillow, poppler pdftoppm, qpdf)"""
import math, os, random, shutil, subprocess, sys, tempfile
import pikepdf
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__)); JAVA = os.path.join(HERE, "InkCheck.java")
fails = []; rng = random.Random(62)
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)
def jv(lines, java=JAVA):
    r = subprocess.run(["java", java], input="\n".join(lines) + "\n", capture_output=True, text=True)
    if r.returncode: print(r.stderr[-1500:]); raise SystemExit("Java lỗi")
    return r.stdout.split("\n")[:-1]
def f3(v): return "%.3f" % v
def flat(pts): return " ".join(repr(float(v)) for p in pts for v in p)

# ---------------- A. phần thuần ----------------
cases = []
for _ in range(400):
    n = rng.randint(0, 60)
    p = [(rng.random(), rng.random()) for _ in range(n)]
    if n > 3 and rng.random() < 0.5:   # đoạn vẽ liền: dày đặc điểm gần nhau
        x, y = rng.random(), rng.random(); p = []
        for _ in range(n): x += rng.uniform(-0.002, 0.002); y += rng.uniform(-0.002, 0.002); p.append((x, y))
    cases.append(p)
step = 0.003
out = jv([f"SIMPLIFY {step!r} {flat(p)}" for p in cases if len(p) >= 1])
ok = True; bad = None
for p, line in zip([c for c in cases if len(c) >= 1], out):
    got = [float(v) for v in line.split()]; k = [(got[i], got[i + 1]) for i in range(0, len(got), 2)]
    def same(a, b): return abs(a[0] - b[0]) < 1e-6 and abs(a[1] - b[1]) < 1e-6      # Java dùng số thực 32-bit
    if len(p) <= 2:
        if len(k) != len(p) or not all(same(a, b) for a, b in zip(k, p)): ok = False; bad = ("<=2 điểm phải giữ nguyên", p, k); break
        continue
    if not same(k[0], p[0]) or not same(k[-1], p[-1]): ok = False; bad = ("mất điểm đầu / cuối", p[:2], k[:2]); break
    it = iter(p); sub = all(any(same(q, r) for r in it) for q in k)
    if not sub: ok = False; bad = ("không phải dãy con",); break
    for i in range(1, len(k) - 1):
        if math.hypot(k[i][0] - k[i - 1][0], k[i][1] - k[i - 1][1]) < step - 1e-6: ok = False; bad = ("hai điểm liên tiếp gần hơn ngưỡng", k[i - 1], k[i]); break
    if not ok: break
check(ok, f"simplify: {len(out)} đường vẽ ngẫu nhiên giữ điểm đầu / cuối, là dãy con của đường gốc, không hai điểm liên tiếp (trừ điểm cuối) gần hơn ngưỡng" + (f" - LỆCH {bad}" if bad else ""))

dense = [(0.5 + 0.4 * math.sin(i / 7.0) * 0.001 * (i % 3), 0.2 + i * 0.00005) for i in range(30000)]
cap = jv([f"CAPPED {flat(dense)}"])[0].split()
check(int(cap[0]) <= 1500 and int(cap[0]) >= 2, f"simplifyCapped: 30 000 điểm dày giảm còn {cap[0]} điểm (trần 1 500), vẫn còn đầu và cuối")
cap2 = jv([f"CAPPED {flat([(0.1, 0.1), (0.9, 0.9)])}", f"CAPPED {flat([(0.3, 0.3)])}"])
check(cap2[0].startswith("2 ") and cap2[1].startswith("1 "), "simplifyCapped: 2 điểm giữ 2, 1 điểm (chấm) giữ 1")

bcases = [([rng.uniform(-50, 700) for _ in range(rng.randint(1, 12) * 2)], rng.uniform(0, 8)) for _ in range(300)]
bo = jv([f"BOUNDS {pad!r} " + " ".join(repr(v) for v in u) for u, pad in bcases])
okb = True
for (u, pad), line in zip(bcases, bo):
    g = [float(v) for v in line.split()]; xs, ys = u[0::2], u[1::2]
    w = [min(xs) - pad, min(ys) - pad, max(xs) + pad, max(ys) + pad]
    if any(abs(a - b) > 1e-3 for a, b in zip(g, w)): okb = False; break
check(okb, "bounds: 300 ca ngẫu nhiên = mô hình (nhỏ nhất / lớn nhất trừ / cộng lề)")

def py_appearance(u, rgb, width, marker):
    s = "/GS gs\n" if marker else ""
    s += f"{f3(rgb[0])} {f3(rgb[1])} {f3(rgb[2])} RG\n{f3(width)} w 1 J 1 j\n"
    pts = [(u[i], u[i + 1]) for i in range(0, len(u), 2)]
    s += f"{f3(pts[0][0])} {f3(pts[0][1])} m"
    if len(pts) == 1: s += f" {f3(pts[0][0])} {f3(pts[0][1])} l"
    for q in pts[1:]: s += f" {f3(q[0])} {f3(q[1])} l"
    return s + " S\n"
acases = []
for _ in range(300):
    u = [rng.uniform(-20, 700) for _ in range(rng.choice([1, 2, 2, 5, 20]) * 2)]
    acases.append((u, [rng.random() for _ in range(3)], rng.uniform(0.2, 25), rng.random() < 0.5))
ao = jv([f"APPEARANCE {1 if m else 0} {w!r} {rgb[0]!r} {rgb[1]!r} {rgb[2]!r} " + " ".join(repr(v) for v in u) for (u, rgb, w, m) in acases])
def same_text(a, b):
    ta, tb = a.split(), b.split()
    if len(ta) != len(tb): return False
    for x, y in zip(ta, tb):
        try: fx, fy = float(x), float(y)
        except ValueError:
            if x != y: return False
            continue
        if abs(fx - fy) > 0.0011: return False      # chữ số cuối: số thực 32-bit của Java với 64-bit của Python
    return True
check(all(same_text(l.replace("|", "\n"), py_appearance(u, rgb, w, m)) for l, (u, rgb, w, m) in zip(ao, acases)),
      "appearance: 300 nét ngẫu nhiên (1 điểm = chấm, nhiều điểm, bút dạ có /GS) khớp bản dựng độc lập: toán tử đúng từng ký tự, số đúng tới 0,001 (làm tròn chữ số cuối)")

# ---------------- B, C. vẽ thật bằng poppler ----------------
class Geo:
    def __init__(s, llx, lly, w, h, rot): s.llx, s.lly, s.cw, s.ch, s.rot = llx, lly, w, h, rot
    @property
    def dw(s): return s.cw if s.rot in (0, 180) else s.ch
    @property
    def dh(s): return s.ch if s.rot in (0, 180) else s.cw
    def m(s):
        r = s.rot
        if r == 90: return (0, 1, -1, 0, s.llx + s.cw, s.lly)
        if r == 180: return (-1, 0, 0, -1, s.llx + s.cw, s.lly + s.ch)
        if r == 270: return (0, -1, 1, 0, s.llx, s.lly + s.ch)
        return (1, 0, 0, 1, s.llx, s.lly)
    def to_user(s, x, y):
        m = s.m(); xb, yb = x, s.dh - y
        return (m[0] * xb + m[2] * yb + m[4], m[1] * xb + m[3] * yb + m[5])

tmp = tempfile.mkdtemp(prefix="ink_")
PEN_W, MARK_W, MARK_OP = 0.004, 0.022, 0.4
PEN_RGB = (217 / 255, 26 / 255, 26 / 255); MARK_RGB = (1.0, 0.92, 0.23)
PATH = [(0.2, 0.3), (0.5, 0.36), (0.8, 0.7)]
def densify(pts, per=40):
    out = []
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        out += [(x0 + (x1 - x0) * i / per, y0 + (y1 - y0) * i / per) for i in range(per)]
    return out + [pts[-1]]
DENSE = densify(PATH)

def build(rot, cropped, marker, java=JAVA, naive=False, name="p.pdf"):
    llx, lly, cw, ch = (50.0, 70.0, 400.0, 600.0) if cropped else (0.0, 0.0, 600.0, 800.0)
    geo = Geo(llx, lly, cw, ch, rot)
    if naive: geo = Geo(0.0, 0.0, 600.0, 800.0, 0)          # el sai: bỏ qua xoay và CropBox
    if naive: dwq, dhq = Geo(llx, lly, cw, ch, rot).dw, Geo(llx, lly, cw, ch, rot).dh
    else: dwq, dhq = geo.dw, geo.dh
    width = (MARK_W if marker else PEN_W) * dwq
    user = []
    for x, y in DENSE:
        ux, uy = geo.to_user(x * dwq, y * dhq); user += [ux, uy]
    rgb = MARK_RGB if marker else PEN_RGB
    lines = [f"APPEARANCE {1 if marker else 0} {width!r} {rgb[0]!r} {rgb[1]!r} {rgb[2]!r} " + " ".join(repr(v) for v in user), "BOUNDS " + repr(width / 2 + 1) + " " + " ".join(repr(v) for v in user)]
    ap_text, bounds_text = jv(lines, java)[:2]
    content = ap_text.replace("|", "\n"); b = [float(v) for v in bounds_text.split()]
    pdf = pikepdf.new(); pdf.add_blank_page(page_size=(600, 800)); page = pdf.pages[0]
    page.Rotate = rot
    if cropped: page.CropBox = [llx, lly, llx + cw, lly + ch]
    ap = pikepdf.Stream(pdf, content.encode("ascii"))
    ap.Type = pikepdf.Name.XObject; ap.Subtype = pikepdf.Name.Form; ap.BBox = b
    if marker: ap.Resources = pikepdf.Dictionary(ExtGState=pikepdf.Dictionary(GS=pikepdf.Dictionary(Type=pikepdf.Name.ExtGState, BM=pikepdf.Name.Multiply, CA=MARK_OP, ca=MARK_OP)))
    else: ap.Resources = pikepdf.Dictionary()
    annot = pikepdf.Dictionary(Type=pikepdf.Name.Annot, Subtype=pikepdf.Name.Ink, Rect=b, InkList=pikepdf.Array([pikepdf.Array(user)]), C=list(rgb), BS=pikepdf.Dictionary(W=width), F=4, T=pikepdf.String("DocScanner"),
                               AP=pikepdf.Dictionary(N=pdf.make_indirect(ap)))
    page.Annots = pikepdf.Array([pdf.make_indirect(annot)])
    path = os.path.join(tmp, name); pdf.save(path)
    return path, content, (dwq, dhq), user, b, width

def render(path, dpi=100):
    base = path[:-4]
    subprocess.run(["pdftoppm", "-r", str(dpi), "-cropbox", "-png", "-f", "1", "-l", "1", "-singlefile", path, base], check=True, capture_output=True)
    return Image.open(base + ".png").convert("RGB")
def px(img, xn, yn):
    W, H = img.size; return img.getpixel((min(W - 1, max(0, int(xn * W))), min(H - 1, max(0, int(yn * H)))))
def inked(p, marker):
    r, g, b = p
    if marker: return r > 235 and 100 < b < 225 and g > 225         # vàng nhạt nhờ nhân màu
    return r > 150 and g < 110 and b < 110                           # đỏ

def probe(img, marker):
    """-> (số điểm dọc nét có mực / tổng, điểm xa nét có mực, điểm chuyển vị có mực)"""
    on = sum(1 for (x, y) in PATH_SAMPLES if inked(px(img, x, y), marker))
    off = sum(1 for (x, y) in OFF_SAMPLES if inked(px(img, x, y), marker))
    swap = sum(1 for (x, y) in PATH_SAMPLES if (abs(x - y) > 0.12) and inked(px(img, y, x), marker))
    return on, off, swap
PATH_SAMPLES = [(x, y) for (x, y) in densify(PATH, 8)]
OFF_SAMPLES = [(0.2, 0.8), (0.8, 0.2), (0.5, 0.9), (0.1, 0.1), (0.9, 0.9), (0.5, 0.6)]
okB = True; detail = []
try:
    for rot in (0, 90, 180, 270):
        for cropped in (False, True):
            for marker in (False, True):
                path, content, (dwq, dhq), user, b, width = build(rot, cropped, marker, name=f"r{rot}_{int(cropped)}_{int(marker)}.pdf")
                img = render(path)
                W, H = img.size; exp_w, exp_h = dwq / 72 * 100, dhq / 72 * 100
                on, off, swap = probe(img, marker)
                good = abs(W - exp_w) < 3 and abs(H - exp_h) < 3 and on == len(PATH_SAMPLES) and off == 0 and swap == 0
                if not good: okB = False; detail.append((rot, cropped, marker, (W, H), (round(exp_w), round(exp_h)), on, len(PATH_SAMPLES), off, swap))
    check(okB, "VẼ THẬT bằng poppler: 16 trang (4 hướng xoay x CropBox thường / lệch x bút / bút dạ): mực nằm đúng dọc nét người dùng thấy, chỗ xa nét trắng, không bị chuyển vị" + (f" - LỆCH {detail[:3]}" if detail else ""))

    # bút dạ trong suốt: dưới nét vẫn thấy được chữ đen
    path, content, (dwq, dhq), user, b, width = build(0, False, True, name="under.pdf")
    pdf = pikepdf.open(path); page = pdf.pages[0]
    page.Contents = pdf.make_stream(b"BT /F1 40 Tf 100 400 Td (HELLO WORLD) Tj ET")
    page.Resources = pikepdf.Dictionary(Font=pikepdf.Dictionary(F1=pikepdf.Dictionary(Type=pikepdf.Name.Font, Subtype=pikepdf.Name.Type1, BaseFont=pikepdf.Name.Helvetica)))
    # đặt nét bút dạ đè lên chữ: dùng nét ngang đi qua dòng chữ
    pdf.save(os.path.join(tmp, "under2.pdf"))
    ok_text = False
    img = render(os.path.join(tmp, "under2.pdf"))
    dark = sum(1 for xx in range(0, img.size[0], 2) for yy in range(0, img.size[1], 2) if sum(img.getpixel((xx, yy))) < 150)
    check(dark > 50, "trang có chữ vẫn vẽ ra chữ đen cùng chú thích (chú thích không xoá nội dung trang)")

    # C. cấu trúc
    pdf = pikepdf.open(os.path.join(tmp, "r90_1_0.pdf")); a = pdf.pages[0].Annots[0]
    path_arr = a.InkList[0]; pts = [float(v) for v in path_arr]
    lo_x, hi_x = min(pts[0::2]), max(pts[0::2]); lo_y, hi_y = min(pts[1::2]), max(pts[1::2]); rect = [float(v) for v in a.Rect]
    struct = (str(a.Subtype) == "/Ink" and len(a.InkList) == 1 and len(pts) == len(DENSE) * 2 and int(a.F) == 4 and rect[0] <= lo_x and rect[1] <= lo_y and rect[2] >= hi_x and rect[3] >= hi_y
              and abs(float(a.BS.W) - PEN_W * Geo(50, 70, 400, 600, 90).dw) < 1e-3 and "/N" in a.AP.keys())
    ap_text = a.AP.N.read_bytes().decode("ascii")
    check(struct, "cấu trúc: /Subtype /Ink, /InkList là mảng của MỘT mảng đủ số điểm, /F 4, /Rect bao hết điểm, /BS /W đúng bề rộng, có /AP /N")
    check("RG" in ap_text and " S" in ap_text and ap_text.startswith("0.851 0.102 0.102 RG"), "luồng hiển thị của bút: đặt màu nét (RG), vẽ đường (m / l), tô nét (S)")
    q = subprocess.run(["qpdf", "--check", os.path.join(tmp, "r90_1_0.pdf")], capture_output=True, text=True)
    check(q.returncode == 0 and "No syntax or stream encoding errors" in q.stdout, "qpdf --check: không lỗi cú pháp / luồng")

    # D. thử âm tính
    path, *_ = build(90, True, False, naive=True, name="naive.pdf")
    img = render(path); on, off, swap = probe(img, False)
    check(on < len(PATH_SAMPLES), f"ÂM TÍNH: bỏ đổi toạ độ theo xoay / CropBox làm nét vẽ SAI CHỖ (chỉ {on}/{len(PATH_SAMPLES)} điểm đúng) - bài kiểm bắt được")
    src = open(JAVA, encoding="utf-8").read()
    for name, a_, b_, marker in [("không đặt màu nét (rg thay RG)", '.append(" RG\\n")', '.append(" rg\\n")', False), ("bỏ /GS gs (bút dạ đặc)", 'if (marker) sb.append("/GS gs\\n");', '', True)]:
        assert a_ in src, name
        mp = os.path.join(tmp, "Mut.java"); open(mp, "w", encoding="utf-8").write(src.replace(a_, b_, 1).replace("public class InkCheck", "public class Mut"))
        path, *_ = build(0, False, marker, java=mp, name="mut.pdf")
        img = render(path); on, off, swap = probe(img, marker)
        check(on < len(PATH_SAMPLES), f"ÂM TÍNH: bản Java '{name}' làm nét vẽ sai màu (chỉ {on}/{len(PATH_SAMPLES)} điểm đúng màu) - bài kiểm bắt được")
finally:
    shutil.rmtree(tmp, ignore_errors=True)

print(); print("TAT CA DAT" if not fails else f"CO {len(fails)} LOI")
sys.exit(1 if fails else 0)
