#!/usr/bin/env python3
"""Hàng đợi tuần tự, phân loại lỗi + thử lại, cảnh báo pin / nhiệt độ (phiên 24, TECHNICAL_DOCS.md 4.63; PDF F4, 2.9, 2.10, 2.11, 2.15, 2.16).

`BatchQueueCheck.java` chép từng câu `util/BatchQueue.kt` (TaskFailures, BatchQueue) và các hàm THUẦN của `util/DeviceLoad.kt`. Ở đây:
  1. phân loại lỗi: 30 thông điệp THẬT của Android / Linux / PdfBox với đáp án viết tay (hết dung lượng -> DISK_FULL; tệp bận -> TRANSIENT; sai mật khẩu,
     hỏng, hết bộ nhớ -> PERMANENT) + 4 000 chuỗi nguyên nhân ngẫu nhiên so với MÔ HÌNH độc lập (cấu trúc khác: bảng ưu tiên, không dùng cùng vòng lặp);
  2. lịch thử lại: 400 / 800 / 1600 ms, trần 3 000 ms, tối đa 3 lần, chỉ lỗi TRANSIENT được thử lại;
  3. hàng đợi: 4 000 kịch bản ngẫu nhiên so với mô hình; BẤT BIẾN: sáu số đếm luôn cộng đúng bằng tổng, mỗi tệp được bắt đầu tối đa một lần, sau stop không còn
     next(), tệp đang chạy vẫn kết thúc được sau stop, kết thúc hai lần hoặc chỉ số lạ bị bỏ qua;
  4. pin / nhiệt: toàn bộ biên (5 / 6 / 15 / 16 %, nhiệt 2 / 3 / 4, đang sạc, không rõ), percentOf, isCharging, tạm im lặng 10 phút;
  5. THỬ ÂM TÍNH: bản Java bị làm hỏng (ưu tiên sai, đảo biên, quên reset chỉ số...) phải bị bắt.
KHÔNG kiểm được ở đây: đọc pin / nhiệt thật của Android, hộp thoại, vòng lặp coroutine trong MainActivity (cần máy thật) - xem 4.63.
Chạy: python3 batch_queue_check.py (cần java 11+)"""
import os, random, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__)); JAVA = os.path.join(HERE, "BatchQueueCheck.java")
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)
def jv(lines, java=JAVA):
    r = subprocess.run(["java", java], input="\n".join(lines) + "\n", capture_output=True, text=True)
    if r.returncode: print(r.stderr[-1500:]); raise SystemExit("Java lỗi")
    return r.stdout.split("\n")[:-1]

# ---------- 1. phân loại lỗi: đáp án viết tay ----------
HAND = [
    ("java.io.IOException@write failed: ENOSPC (No space left on device)", "DISK_FULL"),
    ("java.io.IOException@No space left on device", "DISK_FULL"),
    ("java.io.FileNotFoundException@/storage/emulated/0/x.pdf: open failed: EDQUOT (Disk quota exceeded)", "DISK_FULL"),
    ("java.io.IOException@Not enough space on the disk", "DISK_FULL"),
    ("android.system.ErrnoException@write failed: ENOSPC;java.io.IOException@~null~", "DISK_FULL"),
    ("java.io.IOException@copy failed;java.io.IOException@write failed: ENOSPC (No space left on device)", "DISK_FULL"),
    ("java.io.FileNotFoundException@/x.pdf: open failed: EBUSY (Device or resource busy)", "TRANSIENT"),
    ("java.io.IOException@Text file busy", "TRANSIENT"),
    ("java.io.IOException@The process cannot access the file because it is being used by another process", "TRANSIENT"),
    ("java.io.IOException@read failed: EAGAIN (Try again)", "TRANSIENT"),
    ("java.io.IOException@Resource temporarily unavailable", "TRANSIENT"),
    ("android.os.DeadObjectException@~null~", "TRANSIENT"),
    ("java.io.InterruptedIOException@~null~", "TRANSIENT"),
    ("java.io.IOException@read failed: EINTR (Interrupted system call)", "TRANSIENT"),
    ("java.io.IOException@read failed: ESTALE (Stale file handle)", "TRANSIENT"),
    ("java.lang.RuntimeException@wrapper;java.io.IOException@open failed: EBUSY (Device or resource busy)", "TRANSIENT"),
    ("com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException@Cannot decrypt PDF, the password is incorrect", "PERMANENT"),
    ("java.io.IOException@Error: End-of-File, expected line", "PERMANENT"),
    ("java.io.IOException@Missing root object specification in trailer", "PERMANENT"),
    ("java.lang.OutOfMemoryError@Failed to allocate a 33554448 byte allocation", "PERMANENT"),
    ("java.lang.IllegalArgumentException@~null~", "PERMANENT"),
    ("java.lang.NullPointerException@~null~", "PERMANENT"),
    ("java.io.FileNotFoundException@/x.pdf: open failed: ENOENT (No such file or directory)", "PERMANENT"),
    ("java.io.FileNotFoundException@/x.pdf: open failed: EACCES (Permission denied)", "PERMANENT"),
    # InvalidPasswordException vượt TRANSIENT: một lỗi sai mật khẩu bọc 'busy' không được thử lại
    ("com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException@Cannot decrypt, file busy;java.io.IOException@EBUSY", "PERMANENT"),
    # DISK_FULL vượt PERMANENT
    ("java.lang.OutOfMemoryError@No space left on device", "DISK_FULL"),
    ("java.io.IOException@~null~", "PERMANENT"),
    ("java.io.IOException@ENOSPC", "DISK_FULL"),
    ("java.io.IOException@EBUSY", "TRANSIENT"),
    ("java.io.IOException@Device busy-ish but not flagged", "PERMANENT"),   # 'busy' đứng một mình KHÔNG phải dấu hiệu (chỉ 'resource busy', 'text file busy', EBUSY)
]
got = jv(["C " + c for c, _ in HAND])
for (c, want), g in zip(HAND, got):
    check(g == want, f"phân loại '{c[:78]}' -> {want}" + ("" if g == want else f" (Java: {g})"))

# ---------- mô hình độc lập (bảng ưu tiên) ----------
def model_classify(chain):
    disk = ("enospc", "no space left", "not enough space", "disk full", "edquot", "quota exceeded")
    trans_m = ("ebusy", "text file busy", "resource busy", "being used by another", "eagain", "try again", "temporarily unavailable", "eintr", "interrupted system call", "estale", "stale file")
    trans_c = ("deadobjectexception", "interruptedioexception"); perm_c = ("invalidpasswordexception", "outofmemoryerror")
    msgs = [(m or "").lower() for _, m in chain]; cls = [c.lower() for c, _ in chain]
    verdicts = []
    if any(k in m for m in msgs for k in disk): return "DISK_FULL"
    if any(k in c for c in cls for k in perm_c): return "PERMANENT"
    if any(k in c for c in cls for k in trans_c) or any(k in m for m in msgs for k in trans_m): return "TRANSIENT"
    return "PERMANENT"
rnd = random.Random(24)
CLASSES = ["java.io.IOException", "java.io.FileNotFoundException", "java.lang.RuntimeException", "android.os.DeadObjectException", "java.io.InterruptedIOException",
           "com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException", "java.lang.OutOfMemoryError", "java.lang.IllegalStateException", "kotlinx.coroutines.JobCancellationException"]
MSGS = ["~null~", "EBUSY", "open failed: EBUSY (Device or resource busy)", "ENOSPC", "No space left on device", "Text File Busy", "plain failure", "corrupt xref", "EAGAIN try again",
        "Resource temporarily unavailable", "EINTR", "Interrupted system call", "quota exceeded", "being used by another process", "ESTALE", "disk full", "password incorrect", "busy"]
chains = []
for _ in range(4000):
    chains.append([(rnd.choice(CLASSES), rnd.choice(MSGS)) for _ in range(rnd.randint(1, 4))])
got = jv(["C " + ";".join(f"{c}@{m}" for c, m in ch) for ch in chains])
bad = [(ch, g, model_classify([(c, None if m == "~null~" else m) for c, m in ch])) for ch, g in zip(chains, got)
       if g != model_classify([(c, None if m == "~null~" else m) for c, m in ch])]
check(not bad, f"4 000 chuỗi nguyên nhân ngẫu nhiên khớp mô hình độc lập {bad[:1]}")

# ---------- 2. lịch thử lại ----------
rows = jv([f"D {n}" for n in range(-2, 13)])
want = {}
for n in range(-2, 13):
    d = min(3000, 400 * (2 ** min(10, max(0, n - 1))))
    want[n] = f"{d} {'true' if n < 3 else 'false'} false false"
check(all(r == want[n] for n, r in zip(range(-2, 13), rows)), "độ trễ 400 / 800 / 1600 ms rồi trần 3 000; chỉ TRANSIENT và chỉ khi lần thử < 3 mới thử lại")
check(rows[3] == "400 true false false" and rows[4] == "800 true false false" and rows[5] == "1600 false false false", "lần 1 -> chờ 400 ms, lần 2 -> 800 ms, lần 3 -> bỏ cuộc (3 lần tổng cộng)")
check(rows[-1].split()[0] == "3000", "độ trễ không vượt trần 3 000 ms kể cả lần thử rất lớn")

# ---------- 3. hàng đợi ----------
def model_queue(total, ops):
    st = ["Q"] * max(0, total); stopped = False; got = []
    for op in ops:
        if op == "N":
            idx = -1
            if not stopped:
                for i, s in enumerate(st):
                    if s == "Q": st[i] = "R"; idx = i; break
            got.append(str(idx))
        elif op == "X":
            stopped = True; st = ["X" if s == "Q" else s for s in st]
        else:
            i = int(op[1:]); to = {"D": "D", "F": "F", "S": "S"}[op[0]]
            if 0 <= i < len(st) and st[i] == "R": st[i] = to
    return ",".join(got) + "|" + ",".join(str(st.count(k)) for k in "QRDFSX")
scripts = []
for _ in range(4000):
    total = rnd.choice([0, 1, 2, 3, 5, 8, 12]); ops = []
    for _ in range(rnd.randint(0, 40)):
        r = rnd.random()
        if r < .40: ops.append("N")
        elif r < .78: ops.append(rnd.choice("DFS") + str(rnd.randint(-1, max(total, 1))))
        elif r < .84: ops.append("X")
        else: ops.append(rnd.choice("DFS") + str(rnd.randint(0, max(total - 1, 0))))
    scripts.append((total, ops))
got = jv([f"Q {t} {' '.join(o)}" for t, o in scripts])
bad = [(s, g, model_queue(*s)) for s, g in zip(scripts, got) if g != model_queue(*s)]
check(not bad, f"4 000 kịch bản hàng đợi khớp mô hình độc lập {bad[:1]}")
inv_ok = True
for (t, o), g in zip(scripts, got):
    counts = [int(x) for x in g.split("|")[1].split(",")]
    started = [x for x in g.split("|")[0].split(",") if x and x != "-1"]
    if sum(counts) != max(0, t) or len(started) != len(set(started)): inv_ok = False; print("   vi phạm bất biến:", t, o, g); break
check(inv_ok, "BẤT BIẾN: sáu số đếm luôn cộng đúng bằng tổng; mỗi tệp được bắt đầu tối đa một lần")
# kịch bản có đáp án viết tay
H = lambda s: jv(["Q " + s])[0]
check(H("3 N D0 N D1 N D2 N") == "0,1,2,-1|0,0,3,0,0,0", "chạy tuần tự 0,1,2 rồi hết việc -> next() = -1")
check(H("3 N N X D0 F1 N") == "0,1,-1|0,0,1,1,0,1", "stop giữa chừng: tệp thứ 3 chưa bắt đầu bị STOPPED, hai tệp đang chạy vẫn kết thúc, không còn next()")
check(H("2 N D0 D0 F0") == "0|1,0,1,0,0,0", "kết thúc hai lần / đổi trạng thái sau khi xong bị bỏ qua")
check(H("2 D0 F1 S5 D-1 N") == "0|1,1,0,0,0,0", "chưa bắt đầu thì không kết thúc được; chỉ số lạ bị bỏ qua")
check(H("0 N X N") == "-1,-1|0,0,0,0,0,0", "hàng đợi rỗng an toàn")
check(H("4 X N") == "-1|0,0,0,0,0,4", "stop ngay từ đầu: cả bốn tệp STOPPED")
check(H("3 N S0 N F1 N D2") == "0,1,2|0,0,1,1,1,0", "đủ ba kiểu kết thúc: done / failed / skipped")
check(H("2 N X X D0") == "0|0,0,1,0,0,1", "stop gọi hai lần không đổi gì thêm")

# ---------- 4. pin / nhiệt ----------
cases = []
for pct in [-1, 0, 4, 5, 6, 14, 15, 16, 50, 100]:
    for chg in (0, 1):
        for th in [-1, 0, 1, 2, 3, 4, 5, 6]:
            cases.append((pct, chg, th))
def model_advice(p, c, th):
    if th >= 4: return "VERY_HOT"
    if th == 3: return "HOT"
    if not c and 0 <= p <= 5: return "BATTERY_CRITICAL"
    if not c and 5 < p <= 15: return "BATTERY_LOW"
    return "NONE"
got = jv([f"A {p} {c} {t}" for p, c, t in cases])
bad = [(k, g, model_advice(*k)) for k, g in zip(cases, got) if g != model_advice(*k)]
check(not bad, f"{len(cases)} tổ hợp pin x sạc x nhiệt khớp mô hình {bad[:1]}")
def A(p, c, t): return jv([f"A {p} {c} {t}"])[0]
check(A(15, 0, -1) == "BATTERY_LOW" and A(16, 0, -1) == "NONE", "biên pin yếu: 15 % cảnh báo, 16 % không")
check(A(5, 0, -1) == "BATTERY_CRITICAL" and A(6, 0, -1) == "BATTERY_LOW", "biên pin cạn: 5 % nghiêm trọng, 6 % chỉ yếu")
check(A(3, 1, -1) == "NONE" and A(-1, 0, -1) == "NONE", "đang sạc thì không cảnh báo pin; không rõ mức pin thì im lặng (không chặn người dùng)")
check(A(100, 1, 2) == "NONE" and A(100, 1, 3) == "HOT" and A(100, 1, 4) == "VERY_HOT", "nhiệt: MODERATE (2) là bình thường, SEVERE (3) nóng, CRITICAL (4) rất nóng - kể cả khi đang sạc")
check(A(3, 0, 3) == "HOT" and A(3, 0, 4) == "VERY_HOT", "máy nóng được nói trước pin yếu")
check(A(80, 0, -1) == "NONE", "pin 80 %, không rõ nhiệt -> không hỏi")
P = lambda l, s: jv([f"P {l} {s}"])[0]
check([P(50, 100), P(1, 3), P(2, 3), P(100, 100), P(7, 5), P(-1, 100), P(10, 0), P(10, -5), P(0, 100)] == ["50", "33", "66", "100", "100", "-1", "-1", "-1", "0"], "percentOf: làm tròn xuống, chặn 0..100, thiếu số liệu -> -1")
G = lambda p, s: jv([f"G {p} {s}"])[0]
check([G(0, 3), G(0, 4), G(0, 1), G(1, 3), G(2, 3), G(4, 3), G(0, 2), G(0, 5)] == ["0", "0", "0", "1", "1", "1", "1", "1"], "isCharging: cắm điện (plugged != 0) hoặc trạng thái CHARGING / FULL là đang sạc; xả (3), không sạc (4), không rõ (1) thì không")
K = lambda a, n, u, s: jv([f"K {a} {n} {u} {s}"])[0]
check(K("NONE", 5, 100, "NONE") == "0", "không có gì để cảnh báo thì không hỏi")
check(K("HOT", 5, 100, "HOT") == "0", "đã chọn 'Vẫn tiếp tục' với đúng cảnh báo này, trong 10 phút: không hỏi lại")
check(K("HOT", 100, 100, "HOT") == "1" and K("HOT", 101, 100, "HOT") == "1", "hết thời gian tạm im lặng: hỏi lại")
check(K("VERY_HOT", 5, 100, "HOT") == "1" and K("BATTERY_LOW", 5, 100, "HOT") == "1", "cảnh báo KHÁC (nặng hơn hay lý do khác) thì hỏi lại dù đang tạm im lặng")
check(K("HOT", 5, 0, "NONE") == "1", "lần đầu tiên: hỏi")

# ---------- 5. thử âm tính ----------
src = open(JAVA, encoding="utf-8").read()
def mutant(a, b):
    assert a in src, a
    d = tempfile.mkdtemp(); p = os.path.join(d, "Mut.java")
    open(p, "w", encoding="utf-8").write(src.replace(a, b, 1).replace("public class BatchQueueCheck", "public class Mut")); return p
MUT = [
    ("quên ưu tiên DISK_FULL (lỗi quyền riêng đứng trước)", 'for (String[] link : chain) { String m = (link[1] == null ? "" : link[1]).toLowerCase(); if (anyContains(m, DISK_FULL_MARKERS)) return "DISK_FULL"; }', ""),
    ("InvalidPassword không còn PERMANENT", '"invalidpasswordexception", "outofmemoryerror"', '"outofmemoryerror"'),
    ("thử lại cả lỗi PERMANENT", 'return kind.equals("TRANSIENT") && attempt < MAX_ATTEMPTS;', 'return attempt < MAX_ATTEMPTS;'),
    ("thử lại thêm một lần", "attempt < MAX_ATTEMPTS; }", "attempt <= MAX_ATTEMPTS; }"),
    ("không chặn trần độ trễ", "return Math.min(MAX_DELAY_MS, BASE_DELAY_MS << shift);", "return BASE_DELAY_MS << shift;"),
    # (đột biến "bỏ kiểm tra stopped trong next()" là TƯƠNG ĐƯƠNG - stop() đã chuyển mọi tệp QUEUED sang STOPPED nên next() không còn gì để lấy; cờ chỉ là lớp phòng thủ thứ hai - nên không đưa vào)
    ("next() lấy tệp CUỐI chưa chạy thay vì tệp đầu", "for (int i = 0; i < st.length; i++) if (st[i] == 0) { st[i] = 1; return i; } return -1; }", "for (int i = st.length - 1; i >= 0; i--) if (st[i] == 0) { st[i] = 1; return i; } return -1; }"),
    ("stop không huỷ tệp chưa bắt đầu", "void stop() { stopped = true; for (int i = 0; i < st.length; i++) if (st[i] == 0) st[i] = 5; }", "void stop() { stopped = true; }"),
    ("kết thúc được cả tệp chưa chạy", "if (i >= 0 && i < st.length && st[i] == 1) st[i] = to;", "if (i >= 0 && i < st.length) st[i] = to;"),
    ("biên pin yếu lệch (< thay vì <=)", "percent <= BATTERY_LOW_PERCENT) return \"BATTERY_LOW\"", "percent < BATTERY_LOW_PERCENT) return \"BATTERY_LOW\""),
    ("cảnh báo cả khi đang sạc", 'if (!charging && percent >= 0 && percent <= BATTERY_CRITICAL_PERCENT)', 'if (percent >= 0 && percent <= BATTERY_CRITICAL_PERCENT)'),
    ("MODERATE (2) cũng bị cảnh báo", "static final int BATTERY_LOW_PERCENT = 15, BATTERY_CRITICAL_PERCENT = 5, THERMAL_HOT = 3,", "static final int BATTERY_LOW_PERCENT = 15, BATTERY_CRITICAL_PERCENT = 5, THERMAL_HOT = 2,"),
    ("percentOf không chặn 100", "return Math.max(0, Math.min(100, p));", "return Math.max(0, p);"),
    ("isCharging bỏ trạng thái FULL", "status == 2 || status == 5", "status == 2"),
    ("tạm im lặng áp cho mọi cảnh báo", "&& !(now < snoozedUntil && advice.equals(snoozedAdvice));", "&& !(now < snoozedUntil);"),
]
probe = ["C java.io.IOException@ENOSPC", "C java.lang.OutOfMemoryError@No space left on device", "C com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException@x;java.io.IOException@EBUSY",
         "C java.lang.IllegalStateException@boom", "D 1", "D 2", "D 3", "D 9", "Q 3 N N X D0 F1 N", "Q 2 N D0 D0", "Q 3 D1 N", "A 15 0 -1", "A 5 0 -1", "A 3 1 -1", "A 90 0 2", "A 90 0 3",
         "P 150 100", "P 7 5", "G 0 5", "G 0 2", "K HOT 5 100 VERY_HOT", "K HOT 5 100 HOT", "K BATTERY_LOW 5 100 HOT", "A 16 0 -1", "A 6 0 -1"]
base = jv(probe)
for name, a, b in MUT:
    m = jv(probe, mutant(a, b))
    check(m != base, f"ÂM TÍNH: bản Java '{name}' bị bắt")
print("\nTAT CA DAT" if not fails else f"\n{len(fails)} LOI"); sys.exit(1 if fails else 0)
