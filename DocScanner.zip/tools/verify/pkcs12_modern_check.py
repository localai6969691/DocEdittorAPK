"""Pkcs12Modern (phiên 22, mục 4.49.8): bộ đọc .p12 dự phòng cho tệp mà KeyStore("PKCS12") của Android từ chối với thông báo "sai mật khẩu" (OpenSSL 3: PBES2 / AES-256 + MAC SHA-256).
Bản Java Pkcs12ModernCheck.java KHÔNG dùng KeyStore (JDK từ chối mật khẩu ngoài ASCII) nên kiểm được với MỌI mật khẩu. Tệp do `cryptography` và `openssl pkcs12 -export` (CLI) tạo, đối chứng bằng chính khoá
và chứng thư gốc: khoá PKCS#8 giải ra GIỐNG HỆT từng byte, chuỗi chứng thư đúng thứ tự người ký -> trung gian -> gốc dù trong tệp bị xáo trộn.
Phủ: AES-128 / 192 / 256-CBC, PRF của PBKDF2 SHA-1 / 256 / 384 / 512, MAC SHA-1 / 256 / 384 / 512, 3DES kiểu cũ + MAC SHA-1 / SHA-256, số vòng lặp 1 / 2048 / 10000,
mật khẩu rỗng / ASCII / tiếng Việt NFC + NFD / emoji / Nga / Hán, khoá RSA 2048 + EC P-256 / P-384, 1 - 3 chứng thư.
Từ chối: sai mật khẩu (WRONG_PASSWORD, kể cả mật khẩu gần giống), tệp bị cắt / sửa 1 byte / rác (MALFORMED hoặc WRONG_PASSWORD, KHÔNG BAO GIỜ ra khoá sai), RC2-40 (UNSUPPORTED, hệ thống đọc).
Chạy: python3 pkcs12_modern_check.py   (cần java, cryptography, openssl; ~1-2 phút)
"""
import datetime, os, random, subprocess, sys, tempfile, unicodedata
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, ec
from cryptography.hazmat.primitives.serialization import pkcs12
from cryptography.x509.oid import NameOID

HERE = os.path.dirname(os.path.abspath(__file__)); JAVA = os.path.join(HERE, "Pkcs12ModernCheck.java")
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)
now = datetime.datetime.now(datetime.timezone.utc)
def nm(cn): return x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])
def mk(subject, key, issuer, ikey, ca):
    return (x509.CertificateBuilder().subject_name(subject).issuer_name(issuer).public_key(key.public_key()).serial_number(random.getrandbits(60) | 1)
            .not_valid_before(now - datetime.timedelta(days=1)).not_valid_after(now + datetime.timedelta(days=365)).add_extension(x509.BasicConstraints(ca=ca, path_length=None), critical=True).sign(ikey, hashes.SHA256()))
rk = rsa.generate_private_key(65537, 2048); root = mk(nm("Root"), rk, nm("Root"), rk, True)
mk_ = rsa.generate_private_key(65537, 2048); mid = mk_ and mk(nm("Mid"), mk_, root.subject, rk, True)
leaf_rsa_k = rsa.generate_private_key(65537, 2048); leaf_rsa = mk(nm("Leaf RSA"), leaf_rsa_k, mid.subject, mk_, False)
leaf_p256_k = ec.generate_private_key(ec.SECP256R1()); leaf_p256 = mk(nm("Leaf P256"), leaf_p256_k, mid.subject, mk_, False)
leaf_p384_k = ec.generate_private_key(ec.SECP384R1()); leaf_p384 = mk(nm("Leaf P384"), leaf_p384_k, mid.subject, mk_, False)
work = tempfile.mkdtemp(prefix="p12m_", dir=OUT)
def pkcs8(k): return k.private_bytes(serialization.Encoding.DER, serialization.PrivateFormat.PKCS8, serialization.NoEncryption())
def der(c): return c.public_bytes(serialization.Encoding.DER)

def run(path, pw):
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", JAVA, path, pw.encode("utf-8").hex(), os.path.join(work, "out")], capture_output=True, text=True)
    if r.returncode != 0: raise RuntimeError(r.stderr[-800:])
    return r.stdout.strip()
def got_chain(n): return [open(os.path.join(work, f"out.{i}.der"), "rb").read() for i in range(n)]

def build(label, key, leaf, cas, encryption, pw, shuffle=False):
    cas = list(cas)
    if shuffle: random.shuffle(cas)
    data = pkcs12.serialize_key_and_certificates(b"s", key, leaf, cas, encryption)
    p = os.path.join(work, label + ".p12"); open(p, "wb").write(data); return p
def pbes2(alg, mac, rounds=2048, pwb=None):
    return lambda pw: serialization.PrivateFormat.PKCS12.encryption_builder().kdf_rounds(rounds).key_cert_algorithm(alg).hmac_hash(mac).build(pw.encode("utf-8"))
AES256, TDES = pkcs12.PBES.PBESv2SHA256AndAES256CBC, pkcs12.PBES.PBESv1SHA1And3KeyTripleDESCBC
PW = {"ascii": "matkhau123", "vn_nfc": "Mật khẩu Đặng-Ấn 123", "vn_nfd": unicodedata.normalize("NFD", "Mật khẩu Đặng-Ấn 123"), "emoji": "pw🔐ok", "ru": "пароль123", "zh": "密码测试123"}

# ---------- 1. đọc đúng, giống hệt khoá và chứng thư ----------
cases = []
for pwn, pw in PW.items():
    cases.append((f"aes256_sha256_{pwn}", leaf_rsa_k, leaf_rsa, [mid, root], pbes2(AES256, hashes.SHA256(), 2048), pw))
for mac in (hashes.SHA1(), hashes.SHA384(), hashes.SHA512()):
    cases.append((f"aes256_{mac.name}", leaf_rsa_k, leaf_rsa, [mid, root], pbes2(AES256, mac, 10000), "matkhau123"))
cases += [("3des_sha1", leaf_rsa_k, leaf_rsa, [mid, root], pbes2(TDES, hashes.SHA1(), 2048), "Mật khẩu Đặng 1"), ("3des_sha256_mac", leaf_rsa_k, leaf_rsa, [mid, root], pbes2(TDES, hashes.SHA256(), 2048), "Mật khẩu Đặng 2"),
          ("3des_sha1_1iter", leaf_rsa_k, leaf_rsa, [mid, root], pbes2(TDES, hashes.SHA1(), 1), "abc"),
          ("ec256_aes", leaf_p256_k, leaf_p256, [mid, root], pbes2(AES256, hashes.SHA256(), 2048), "пароль"), ("ec384_3des", leaf_p384_k, leaf_p384, [mid], pbes2(TDES, hashes.SHA256(), 2048), "密码"),
          ("single_cert", leaf_rsa_k, leaf_rsa, [], pbes2(AES256, hashes.SHA256(), 2048), "x"), ("shuffled", leaf_rsa_k, leaf_rsa, [mid, root], pbes2(AES256, hashes.SHA256(), 2048), "x")]
for label, key, leaf, cas, enc, pw in cases:
    p = build(label, key, leaf, cas, enc(pw), pw, shuffle=(label == "shuffled"))
    out = run(p, pw); want = [der(leaf)] + [der(c) for c in ([mid, root] if len(cas) >= 2 else cas)]
    ok = out == f"OK {len(want)}" and open(os.path.join(work, "out.pk8"), "rb").read() == pkcs8(key) and got_chain(len(want)) == want
    check(ok, f"đọc {label}: {out}; khoá PKCS#8 và chuỗi chứng thư GIỐNG HỆT bản gốc")

# openssl CLI (đa dạng cách mã hoá hơn thư viện): các tổ hợp -keypbe / -certpbe / -macalg / -iter
pem_dir = work
open(os.path.join(pem_dir, "k.pem"), "wb").write(leaf_rsa_k.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
open(os.path.join(pem_dir, "chain.pem"), "wb").write(b"".join(c.public_bytes(serialization.Encoding.PEM) for c in (leaf_rsa, mid, root)))
for label, flags in [("cli_aes128", ["-keypbe", "AES-128-CBC", "-certpbe", "AES-128-CBC", "-macalg", "sha256", "-iter", "5"]),
                     ("cli_aes192_sha512", ["-keypbe", "AES-192-CBC", "-certpbe", "AES-192-CBC", "-macalg", "sha512", "-iter", "100"]),
                     ("cli_default", []), ("cli_3des_sha384", ["-keypbe", "PBE-SHA1-3DES", "-certpbe", "PBE-SHA1-3DES", "-macalg", "sha384"])]:
    pw = "Mật khẩu CLI đ"; outp = os.path.join(work, label + ".p12")
    r = subprocess.run(["openssl", "pkcs12", "-export", "-inkey", os.path.join(work, "k.pem"), "-in", os.path.join(work, "chain.pem"), "-out", outp, "-passout", "pass:" + pw] + flags, capture_output=True, text=True)
    if r.returncode != 0: check(False, f"openssl không tạo được {label}: {r.stderr[:100]}"); continue
    out = run(outp, pw)
    check(out == "OK 3" and open(os.path.join(work, "out.pk8"), "rb").read() == pkcs8(leaf_rsa_k) and got_chain(3) == [der(leaf_rsa), der(mid), der(root)], f"đọc tệp `openssl pkcs12 -export {' '.join(flags)}`: {out}")

# mật khẩu RỖNG (thư viện từ chối tạo, nên dùng openssl CLI)
for label, flags in [("cli_empty_pw_default", []), ("cli_empty_pw_3des", ["-keypbe", "PBE-SHA1-3DES", "-certpbe", "PBE-SHA1-3DES", "-macalg", "sha1"])]:
    outp = os.path.join(work, label + ".p12")
    r = subprocess.run(["openssl", "pkcs12", "-export", "-inkey", os.path.join(work, "k.pem"), "-in", os.path.join(work, "chain.pem"), "-out", outp, "-passout", "pass:"] + flags, capture_output=True, text=True)
    out = run(outp, "") if r.returncode == 0 else "openssl: " + r.stderr[:60]
    check(out == "OK 3" and open(os.path.join(work, "out.pk8"), "rb").read() == pkcs8(leaf_rsa_k), f"mật khẩu RỖNG ({label}): {out}")

# ---------- 2. từ chối ----------
p = os.path.join(work, "aes256_sha256_vn_nfc.p12"); good = PW["vn_nfc"]
for label, pw in [("sai hẳn", "sai-mat-khau"), ("gần giống (thiếu 1 ký tự)", good[:-1]), ("gần giống (đổi 1 ký tự)", good[:-1] + "4"), ("rỗng", ""), ("NFD của mật khẩu NFC (BC không chuẩn hoá)", PW["vn_nfd"])]:
    out = run(p, pw); check(out == "ERR WRONG_PASSWORD", f"từ chối mật khẩu {label}: {out}")
raw = open(p, "rb").read()
rnd = random.Random(5); results = {}
wrong_key = []
def classify(data, tag):
    q = os.path.join(work, "mut.p12"); open(q, "wb").write(data); out = run(q, good)
    if out.startswith("OK"):
        same = open(os.path.join(work, "out.pk8"), "rb").read() == pkcs8(leaf_rsa_k) and got_chain(int(out.split()[1])) == [der(leaf_rsa), der(mid), der(root)]
        if not same: wrong_key.append((tag, out))
        out = "OK (khoá và chuỗi giống hệt gốc: bit lật nằm ở trường MAC không bao phủ)"
    results.setdefault(tag, []).append(out); return out
for _ in range(25):
    b = bytearray(raw); i = rnd.randrange(len(b)); b[i] ^= 1 << rnd.randrange(8); classify(bytes(b), "bitflip")
for cut in (10, 100, len(raw) // 2, len(raw) - 5): classify(raw[:cut], "truncated")
classify(os.urandom(300), "random"); classify(b"", "empty")
for tag, outs in results.items():
    ok = all(o.startswith("OK (khoá") or o in ("ERR WRONG_PASSWORD", "ERR MALFORMED", "ERR UNSUPPORTED") for o in outs) and not wrong_key
    check(ok, f"tệp hỏng ({tag}, {len(outs)} ca): KHÔNG BAO GIỜ trả khoá, chỉ lỗi có tên {sorted(set(outs))}")
check(not wrong_key, "KHÔNG có tệp hỏng nào cho ra khoá hoặc chuỗi SAI (đọc được thì phải giống hệt bản gốc)")
# `openssl pkcs12 -export -legacy` mặc định mã hoá chứng thư bằng RC2-40: bộ đọc này không hỗ trợ -> UNSUPPORTED (bộ đọc của hệ thống lo)
lg = os.path.join(work, "legacy_default.p12")
subprocess.run(["openssl", "pkcs12", "-export", "-legacy", "-inkey", os.path.join(work, "k.pem"), "-in", os.path.join(work, "chain.pem"), "-out", lg, "-passout", "pass:Mật khẩu"], check=True, capture_output=True)
out = run(lg, "Mật khẩu"); check(out == "ERR UNSUPPORTED", f"`openssl pkcs12 -export -legacy` (RC2-40 cho chứng thư): {out} - hệ thống đọc loại này, bộ dự phòng từ chối đúng")
# RC2-40 do openssl -legacy tạo: bộ đọc này không hỗ trợ -> UNSUPPORTED (hệ thống đọc)
rc2 = os.path.join(work, "rc2.p12")
r = subprocess.run(["openssl", "pkcs12", "-export", "-legacy", "-keypbe", "PBE-SHA1-RC2-40", "-certpbe", "PBE-SHA1-RC2-40", "-macalg", "sha1", "-inkey", os.path.join(work, "k.pem"), "-in", os.path.join(work, "chain.pem"), "-out", rc2, "-passout", "pass:x"], capture_output=True, text=True)
if r.returncode == 0: out = run(rc2, "x"); check(out == "ERR UNSUPPORTED", f"RC2-40: {out} (hệ thống đọc loại này, bộ đọc dự phòng từ chối đúng)")
else: print("BO QUA RC2-40:", r.stderr[:80])

print(); print("TAT CA DAT" if not fails else f"{len(fails)} LOI: {fails}")
sys.exit(1 if fails else 0)
