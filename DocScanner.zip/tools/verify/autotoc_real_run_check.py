#!/usr/bin/env python3
"""Tự tạo mục lục CHẠY THẬT (`util/PdfAutoToc.kt` + `PdfBookmarks.saveWithOutline`; phiên 25, TECHNICAL_DOCS.md 4.70): popup "tạo mục lục tự động?" của trình đọc gọi đúng các hàm này.

Sách mẫu dựng bằng reportlab (có chữ Việt bằng DejaVu): trang bìa với tựa lớn, một trang MỤC LỤC IN SẴN (dòng có dấu chấm dẫn + số trang), 4 chương (tiêu đề cỡ 20 đậm, có chương tựa dài
xuống 2 dòng), mỗi chương 2-3 mục (cỡ 14 đậm đánh số "1.2 ..."), tiểu mục cỡ 12 đậm đánh số "1.2.3 ...", đầu trang lặp "Sach mau" + số trang ở chân, thân 10 pt. Mong đợi lấy từ CHÍNH
bộ dựng sách (trang thật của từng tiêu đề, do reportlab ghi lại) chứ không từ mã: đúng tiêu đề, đúng cấp 1/2/3, đúng trang, KHÔNG có tựa bìa, dòng mục lục in sẵn, đầu trang lặp, số trang.
Rồi: bản sao có outline mở được bằng pikepdf, đúng số mục, mỗi mục trỏ đúng trang; PDF chỉ ảnh (không text) -> NO_TEXT; văn bản thuần không tiêu đề -> NO_HEADINGS; slide có quá nhiều dòng
chữ lớn -> NO_HEADINGS (không bịa mục lục); tệp hỏng -> UNREADABLE.
THAY THẾ DUY NHẤT: `PdfVerify.opensAsPdf` (PdfRenderer của Android) -> kiểm bằng PdfBox. KHÔNG kiểm được: sách thật của người dùng (mỗi nhà xuất bản dàn trang một kiểu), PDF quét có OCR sẵn.
Chạy: python3 tools/verify/autotoc_real_run_check.py"""
import os, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
import pikepdf  # noqa: E402
from reportlab.lib.pagesizes import A4  # noqa: E402
from reportlab.lib.styles import ParagraphStyle  # noqa: E402
from reportlab.pdfbase import pdfmetrics  # noqa: E402
from reportlab.pdfbase.ttfonts import TTFont  # noqa: E402
from reportlab.platypus import BaseDocTemplate, Frame, PageBreak, PageTemplate, Paragraph, Spacer  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="autotoc-")
DOUBLE = {"PdfVerify.kt": ("    fun opensAsPdf(file: File, expectedPages: Int): Boolean {",
    "    fun opensAsPdf(file: File, expectedPages: Int): Boolean {\n        return try {\n            if (!file.exists() || file.length() <= 0L) return false\n"
    "            com.tom_roush.pdfbox.pdmodel.PDDocument.load(file).use { d -> d.numberOfPages > 0 && (expectedPages <= 0 || d.numberOfPages == expectedPages) }\n        } catch (e: Exception) { false }\n    }")}
FILES = ["PdfAutoToc.kt", "PdfBookmarks.kt", "PdfStructureOptimizer.kt", "PdfVerify.kt"]
HARNESS = os.path.join(HERE, "real_run", "AutoTocHarness.kt"); STUBS = os.path.join(HERE, "real_run", "UtilStubs.kt")
cls = tc.compile(FILES, [HARNESS, STUBS], os.path.join(WORK, "cls"), None, DOUBLE)[0]
def run(*a):
    r = tc.run(cls, "AutoTocHarnessKt", list(a))
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-1200:])
    return r.stdout.splitlines()

FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"; BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
pdfmetrics.registerFont(TTFont("DV", FONT)); pdfmetrics.registerFont(TTFont("DVB", BOLD))
body = ParagraphStyle("body", fontName="DV", fontSize=10, leading=14)
h1 = ParagraphStyle("h1", fontName="DVB", fontSize=20, leading=26, spaceAfter=10)
h2 = ParagraphStyle("h2", fontName="DVB", fontSize=14, leading=18, spaceBefore=10, spaceAfter=6)
h3 = ParagraphStyle("h3", fontName="DVB", fontSize=12, leading=16, spaceBefore=6, spaceAfter=4)
boldbody = ParagraphStyle("boldbody", fontName="DVB", fontSize=10, leading=14)   # bold at body size and NOT numbered: a lead-in, not a heading
cover = ParagraphStyle("cover", fontName="DVB", fontSize=30, leading=36)
LOREM = ("Đây là một đoạn văn thân bài dài để lấp đầy trang, viết bằng tiếng Việt có dấu. The quick brown fox jumps over the lazy dog while the engineers measure the heading sizes. " * 4)

class Book(BaseDocTemplate):
    def __init__(self, path):
        super().__init__(path, pagesize=A4, leftMargin=60, rightMargin=60, topMargin=70, bottomMargin=60)
        self.found = []
        self.addPageTemplates([PageTemplate(id="p", frames=[Frame(60, 60, A4[0] - 120, A4[1] - 130)], onPage=self.decorate)])
    def decorate(self, canvas, doc):
        canvas.setFont("DVB", 15); canvas.drawString(60, A4[1] - 40, "Sach mau - ban nhap")   # as big as a section title: only its repetition on every page keeps it out; canvas.drawRightString(A4[0] - 60, 30, f"Trang {doc.page}")
    def afterFlowable(self, fl):
        name = getattr(fl, "_level", None)
        if name: self.found.append((fl._level, fl.getPlainText(), self.page - 1))

def make_book(path):
    story = [Spacer(1, 200), Paragraph("Sách mẫu", cover), Paragraph("Một cuốn sách để thử mục lục", body), PageBreak()]
    for line in ("Chương 1 ........ 3", "Chương 2 ........ 6", "1.1 Mở đầu ........ 3"):   # a PRINTED contents page: must not become entries
        story.append(Paragraph(line, h2))   # set as big as a section title: only the dotted leader and the page number keep it out
    story.append(PageBreak())
    titles = [("Chương 1: Giới thiệu", ["1.1 Mục tiêu", "1.2 Phạm vi"]),
              ("Chương 2: Một tiêu đề chương rất dài để nó phải xuống dòng thứ hai trên trang giấy", ["2.1 Phương pháp", "2.2 Dữ liệu", "2.3 Kết quả"]),
              ("Chương 3: Phân tích", ["3.1 Mô hình", "3.2 Đánh giá"]), ("Chương 4: Kết luận", ["4.1 Tổng kết"])]
    for ti, (c, secs) in enumerate(titles):
        p = Paragraph(c, h1); p._level = 1; story.append(p)
        for _ in range(3): story.append(Paragraph(LOREM, body))
        story.append(Paragraph(["Lưu ý về an toàn khi dùng", "Cảnh báo về nhiệt độ cao", "Gợi ý cho người mới bắt đầu", "Nhắc lại điều cần nhớ nhất"][ti], boldbody))   # different words each time, so only the missing "numbered" rule keeps them out
        for si, s in enumerate(secs):
            p = Paragraph(s, h2); p._level = 2; story.append(p)
            for _ in range(5): story.append(Paragraph(LOREM, body))
            if ti == 0 and si == 0:
                p = Paragraph("1.1.1 Chi tiết nhỏ", h3); p._level = 3; story.append(p)
                for _ in range(2): story.append(Paragraph(LOREM, body))
        story.append(PageBreak())
    d = Book(path); d.build(story); return d.found

book = os.path.join(WORK, "book.pdf"); expected = make_book(book)
print("== A. sách mẫu có chữ Việt: tiêu đề, cấp, trang")
res = run("detect", book); status, got = res[0], [tuple(l.split("|", 2)) for l in res[1:]]
got = [(int(l), t, int(p)) for l, p, t in got]
norm = lambda s: " ".join(s.split())
exp = [(l, norm(t), p) for l, t, p in expected]
check(status == "FOUND", f"trạng thái {status}")
check(len(pikepdf.open(book).pages) >= 8, f"sách có {len(pikepdf.open(book).pages)} trang")
check([(l, norm(t), p) for l, t, p in got] == exp, "đúng từng tiêu đề, cấp, trang" + ("" if [(l, norm(t), p) for l, t, p in got] == exp else f"\n  mong đợi {exp}\n  nhận     {got}"))
check(not any("Sách mẫu" in t or "........" in t or "Sach mau" in t or t.startswith("Trang") for _, t, _ in got), "không có tựa bìa, dòng mục lục in sẵn, đầu trang lặp, số trang")
check(any(l == 3 for l, _, _ in got) and any("rất dài" in t and "thứ hai" in t for _, t, _ in got), "tiêu đề dài xuống 2 dòng thành MỘT mục; có cả cấp 3")

print("== B. ghi outline vào bản sao")
out = os.path.join(WORK, "book-toc.pdf"); n = run("make", book, out)[0]
check(n == str(len(exp)) and os.path.exists(out), f"ghi {n} mục")
pdf = pikepdf.open(out); pages = list(pdf.pages)
with pdf.open_outline() as ol:
    flat = []
    def walk(items, lvl):
        for it in items:
            dest = it.destination
            page_no = next((i for i, p in enumerate(pages) if p.objgen == dest[0].objgen), -1) if dest else -1
            flat.append((lvl, str(it.title), page_no)); walk(it.children, lvl + 1)
    walk(ol.root, 1)
check([(l, norm(t), p) for l, t, p in flat] == exp, "pikepdf đọc lại outline: đúng tiêu đề, cấp và trang đích")
txt = subprocess.run(["pdftotext", "-f", "5", "-l", "5", out, "-"], capture_output=True, text=True).stdout
check("quick brown fox" in txt, "văn bản trang giữ nguyên (không bị chuyển thành ảnh)")

print("== C. những PDF KHÔNG nên có mục lục")
def simple(path, draw):
    from reportlab.pdfgen import canvas
    c = canvas.Canvas(path, pagesize=A4); draw(c); c.save()
def scan_like(c):
    for _ in range(4): c.rect(100, 100, 300, 400, fill=1); c.showPage()
def plain(c):
    for _ in range(6):
        c.setFont("DV", 10)
        for i in range(40): c.drawString(60, 780 - i * 18, "Just ordinary body text with no headings at all, line after line of it.")
        c.showPage()
def slides(c):
    for _ in range(4):
        c.setFont("DVB", 28)
        for i in range(20): c.drawString(60, 800 - i * 36, f"Big line number {i} here")
        c.setFont("DV", 10); c.drawString(60, 40, "small footnote text for the body size reference " * 3); c.showPage()
for name, draw, want in (("chỉ ảnh/hình (không text)", scan_like, "NO_TEXT"), ("văn bản thuần không tiêu đề", plain, "NO_HEADINGS"), ("slide nhiều dòng chữ lớn", slides, "NO_HEADINGS")):
    path = os.path.join(WORK, "c.pdf"); simple(path, draw); got = run("detect", path)[0]
    check(got == want, f"{name} -> {got} (mong đợi {want})")
junk = os.path.join(WORK, "junk.pdf"); open(junk, "wb").write(b"this is not a pdf at all")
check(run("detect", junk)[0] == "UNREADABLE", "tệp hỏng -> UNREADABLE")

print("== D. thử âm tính: mã cố tình sai PHẢI bị bắt")
def fails_with(old, new):
    try: mdir = tc.compile(FILES, [HARNESS, STUBS], os.path.join(WORK, "mut"), {"PdfAutoToc.kt": (old, new)}, DOUBLE)[0]
    except RuntimeError as e: return "mutant không biên dịch: " + str(e)[:100]
    r = tc.run(mdir, "AutoTocHarnessKt", ["detect", book]).stdout.splitlines()
    return [(int(l), norm(t), int(p)) for l, p, t in (x.split("|", 2) for x in r[1:])] != exp
ONLY = next((int(a.split("=")[1]) for a in sys.argv if a.startswith("--mutant=")), None)   # run one mutant alone (each one recompiles, ~1 min)
MUTANTS = (("không loại đầu trang lặp", "if ((pagesOf[key(l.text)]?.size ?: 0) >= repeatedAt) continue", ""),
                       ("không loại dòng mục lục in sẵn", "PAGE_NUMBER.matches(text) || CONTENTS_LINE.matches(text)", "PAGE_NUMBER.matches(text)"),
                       ("không gộp tiêu đề xuống dòng", "if (wrapped && prev != null) {", "if (wrapped && prev != null && l.size < 0f) {"),
                       ("coi mọi dòng đậm là tiêu đề (không cần đánh số)", "return l.bold && l.size >= body * 0.95f && NUMBERED.containsMatchIn(text)", "return l.bold && l.size >= body * 0.95f"))
for number, (name, old, new) in enumerate(MUTANTS, 1):
    if ONLY is not None and number != ONLY: continue
    r = fails_with(old, new); check(r is True, f"mã sai bị bắt: {name}" + ("" if r is True else f" ({r})"))

print()
print("TAT CA DAT" if not fails else f"{len(fails)} LOI")
sys.exit(1 if fails else 0)
