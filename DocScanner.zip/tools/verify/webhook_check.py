"""DocumentWebhook (phiên 22, mục 4.49.12): bản Java WebhookCheck.java (cùng mã với DocumentWebhook.kt) chạy với MÁY CHỦ THỬ CỤC BỘ do script dựng.
  1. nội dung JSON: parse bằng json.loads, đủ trường, tên có dấu / nháy / xuống dòng / emoji, loại tệp, kích thước, giờ UTC ISO đúng;
  2. chữ ký: `X-DocScanner-Signature: sha256=<hex>` = HMAC-SHA256 của ĐÚNG byte thân tin (tính lại độc lập bằng hmac của Python, bí mật có dấu / emoji);
  3. gửi: máy chủ nhận phương thức POST, Content-Type JSON UTF-8, Content-Length đúng; 2xx = đã giao; 3xx KHÔNG được theo (không gửi thân tin sang nơi khác), 4xx / 5xx, treo quá hạn,
     cổng đóng = không giao; không bí mật thì KHÔNG có tiêu đề chữ ký;
  4. pending: chỉ tài liệu chưa thấy, còn mới (trong 24 giờ), cũ nhất trước, tối đa N mỗi lượt; tài liệu có giờ ở tương lai bị bỏ; so với tính lại độc lập;
  THỬ ÂM TÍNH: sửa 1 byte thân tin làm chữ ký không còn khớp; bí mật sai cho chữ ký khác.
Chạy: python3 webhook_check.py   (cần java; ~20 giây)
"""
import hashlib, hmac, json, os, random, subprocess, sys, threading, time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
HERE = os.path.dirname(os.path.abspath(__file__)); JAVA = os.path.join(HERE, "WebhookCheck.java")
ENV = dict(os.environ, LC_ALL="C.UTF-8")
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)
def h(s): return "-" if s == "" else s.encode("utf-8").hex()
def run(lines):
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", JAVA], input=("\n".join(lines) + "\n").encode("ascii"), capture_output=True, env=ENV)
    if r.returncode != 0: raise RuntimeError(r.stderr.decode()[-800:])
    return r.stdout.decode("utf-8").split("\n")[:-1]

# ---------- 1. nội dung ----------
names = ["scan_20261102_101500.pdf", "Hợp đồng \"A\"\nB.pdf", "báo cáo 🙂.EPUB", "noext", "a\\b.docx", ".hidden", "x" * 200 + ".md"]
now = 1_793_600_000_000
out = run([f"payload {h(n)} {i * 1000 + 7} {now + i * 86_400_000}" for i, n in enumerate(names)])
bad = []
for i, (n, line) in enumerate(zip(names, out)):
    d = json.loads(line)
    ext = n.rsplit(".", 1)[-1].lower() if "." in n else ""
    want = {"event": "document_created", "app": "DocScanner", "name": n, "type": ext, "sizeBytes": i * 1000 + 7, "modified": datetime.fromtimestamp((now + i * 86_400_000) / 1000, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
    if d != want: bad.append((n, d))
check(not bad, f"nội dung JSON: {len(names)} tên (dấu, nháy, xuống dòng, emoji, gạch chéo ngược, không đuôi, đuôi hoa) -> json.loads đúng từng trường, giờ UTC ISO{'' if not bad else ' ' + str(bad[:1])}")
t = json.loads(run([f"test {now}"])[0]); check(t["event"] == "test" and t["app"] == "DocScanner", "tin thử: event = test")

# ---------- 2. chữ ký ----------
secrets = ["s3cret", "Bí mật 🔐 đặc biệt", "x" * 200, "a"]
bodies = ["{}", json.dumps({"name": "Hợp đồng"}, ensure_ascii=False), "x" * 5000]
out = run([f"sig {h(b)} {h(s)}" for b in bodies for s in secrets]); k = 0; bad = []
for b in bodies:
    for s in secrets:
        want = "sha256=" + hmac.new(s.encode(), b.encode(), hashlib.sha256).hexdigest()
        if out[k] != want: bad.append((b[:10], s[:10]))
        k += 1
check(not bad, f"chữ ký: {k} tổ hợp (bí mật có dấu / emoji / dài 200 ký tự) = hmac của Python trên đúng byte UTF-8")
sig1 = run([f"sig {h('abc')} {h('k')}"])[0]; sig2 = run([f"sig {h('abd')} {h('k')}"])[0]; sig3 = run([f"sig {h('abc')} {h('k2')}"])[0]
check(len({sig1, sig2, sig3}) == 3, "ÂM TÍNH: sửa 1 byte thân tin, hoặc bí mật sai -> chữ ký KHÁC (bên nhận phát hiện được)")

# ---------- 3. gửi qua máy chủ cục bộ ----------
received = []
class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def do_POST(self):
        n = int(self.headers.get("Content-Length", "0")); body = self.rfile.read(n)
        received.append(dict(path=self.path, method="POST", ctype=self.headers.get("Content-Type"), sig=self.headers.get("X-DocScanner-Signature"), body=body, length=n))
        p = self.path
        if p == "/ok": self.reply(200, b"{}")
        elif p == "/created": self.reply(201, b"")
        elif p == "/nocontent": self.reply(204, b"")
        elif p == "/redirect": self.send_response(302); self.send_header("Location", "/ok"); self.send_header("Content-Length", "0"); self.end_headers()
        elif p == "/bad": self.reply(400, b"no")
        elif p == "/boom": self.reply(500, b"no")
        elif p == "/hang": time.sleep(3); self.reply(200, b"{}")
        else: self.reply(404, b"")
    def do_GET(self): received.append(dict(path=self.path, method="GET")); self.reply(200, b"")
    def reply(self, code, body):
        try: self.send_response(code); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError): pass
srv = ThreadingHTTPServer(("127.0.0.1", 0), H); port = srv.server_address[1]; threading.Thread(target=srv.serve_forever, daemon=True).start()
base = f"http://127.0.0.1:{port}"
body_json = json.dumps({"event": "document_created", "name": "Hợp đồng 🙂.pdf"}, ensure_ascii=False)
cases = [("/ok", "k1", "true"), ("/created", "", "true"), ("/nocontent", "Bí mật", "true"), ("/redirect", "k", "false"), ("/bad", "k", "false"), ("/boom", "k", "false"), ("/hang", "k", "false"), ("/missing", "k", "false")]
out = run([f"post {h(base + p)} {h(body_json)} {h(s)} 1000" for p, s, _ in cases])
check(out == [w for _, _, w in cases], f"gửi: 200 / 201 / 204 = đã giao; 302 KHÔNG được theo, 400, 500, treo quá hạn 1 s, 404 = chưa giao ({out})")
by_path = {}
for r in received:
    by_path.setdefault(r["path"], []).append(r)
check(len(by_path.get("/ok", [])) == 1, "gửi: bị chuyển hướng 302 nhưng /ok chỉ nhận ĐÚNG một lần (từ ca /ok; ca /redirect không bị theo sang /ok)")
first = by_path["/ok"][0]
check(first["method"] == "POST" and first["ctype"] == "application/json; charset=utf-8" and first["length"] == len(body_json.encode("utf-8")) and first["body"].decode("utf-8") == body_json, "gửi: POST, Content-Type JSON UTF-8, Content-Length đúng, thân tin nguyên vẹn (tiếng Việt + emoji)")
check(first["sig"] == "sha256=" + hmac.new(b"k1", body_json.encode("utf-8"), hashlib.sha256).hexdigest(), "gửi: tiêu đề chữ ký = hmac độc lập tính trên thân tin nhận được")
check(by_path["/created"][0]["sig"] is None, "gửi: KHÔNG có bí mật thì KHÔNG có tiêu đề chữ ký")
srv.shutdown()
closed = run([f"post {h('http://127.0.0.1:9/x')} {h('{}')} - 1000"])[0]
check(closed == "false", "gửi: cổng đóng -> false, không ném lỗi")

# ---------- 4. pending ----------
rnd = random.Random(2212); DAY = 86_400_000; bad = []
def ref(seen, files, now, recent, limit):
    ok = [(n, m) for n, m in files if n not in seen and 0 <= now - m <= recent]; ok.sort(key=lambda e: e[1]); return [n for n, _ in ok[:limit]]
trials = []
for trial in range(200):
    files = [(f"f{i}.pdf", now + rnd.randrange(-3 * DAY, DAY // 2)) for i in range(rnd.randrange(0, 40))]
    seen = {n for n, _ in files if rnd.random() < 0.3}; limit = rnd.choice([1, 5, 20]); recent = rnd.choice([DAY, 2 * DAY])
    trials.append((seen, files, recent, limit))
out = run([f"pending {now} {recent} {limit} {h(chr(10).join(sorted(seen)))} {h(chr(10).join(f'{n}:{m}' for n, m in files))}" for seen, files, recent, limit in trials])   # one JVM for all
groups = []; cur = []
for line in out:
    if line == "END": groups.append(cur); cur = []
    else: cur.append(line)
for trial, ((seen, files, recent, limit), got) in enumerate(zip(trials, groups)):
    if got != ref(seen, files, now, recent, limit): bad.append(trial)
bad = bad if len(groups) == len(trials) else bad + ["số nhóm"]
check(not bad, "pending: 200 bộ ngẫu nhiên = tính lại độc lập (chưa thấy + còn mới + cũ nhất trước + giới hạn mỗi lượt; giờ ở tương lai bị bỏ)")

print(); print("TAT CA DAT" if not fails else f"{len(fails)} LOI: {fails}")
sys.exit(1 if fails else 0)
