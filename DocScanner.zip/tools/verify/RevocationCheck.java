import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/**
 * Java twin of app/.../util/Revocation.kt (phiên 23, 4.51), copied statement by statement. stdin, one command per line, bytes as hex:
 *   FIELDS c            serial / issuer / subject / key-bits / extensions (hex or "-"), one per line
 *   URLS c              "O <url>" per OCSP address, "C <url>" per CRL address, then END
 *   CERTID c i          hex of the CertID, or NONE
 *   REQ id              hex of the OCSPRequest
 *   PARSE r id          "status certStatus answersThis"
 *   SELF c              true / false
 *   ISSUER c p1,p2,..   index in the pool of the issuer, or -1
 *   CMSCERTS cms        count, then one hex line per certificate
 *   CRL d               true / false
 *   MAP POST|GET url r  registers the answer the fake network gives for that address (url as hex of ASCII); "FAIL" instead of r = IOException
 *   COLLECT c1,c2,..    "needed covered nCerts nOcsp nCrl", then the OCSP hex lines, then the CRL hex lines
 */
public class RevocationCheck {
    static final String OID_AIA = "1.3.6.1.5.5.7.1.1", OID_CDP = "2.5.29.31", OID_OCSP = "1.3.6.1.5.5.7.48.1";
    static final int CERT_GOOD = 0, CERT_REVOKED = 1, CERT_UNKNOWN = 2;

    // ---- DerWriter ----
    static byte[] concat(byte[]... parts) { int n = 0; for (byte[] p : parts) n += p.length; byte[] r = new byte[n]; int o = 0; for (byte[] p : parts) { System.arraycopy(p, 0, r, o, p.length); o += p.length; } return r; }
    static byte[] lengthBytes(int n) {
        if (n < 128) return new byte[]{(byte) n};
        if (n < 256) return new byte[]{(byte) 0x81, (byte) n};
        if (n < 65536) return new byte[]{(byte) 0x82, (byte) (n >> 8), (byte) n};
        return new byte[]{(byte) 0x83, (byte) (n >> 16), (byte) (n >> 8), (byte) n};
    }
    static byte[] tlv(int tag, byte[] content) { return concat(new byte[]{(byte) tag}, lengthBytes(content.length), content); }
    static byte[] sequence(byte[]... parts) { return tlv(0x30, concat(parts)); }
    static byte[] octetString(byte[] b) { return tlv(0x04, b); }
    static byte[] nullValue() { return new byte[]{0x05, 0x00}; }
    static byte[] sha1Oid() { return new byte[]{0x06, 0x05, 0x2B, 0x0E, 0x03, 0x02, 0x1A}; }
    static int[] header(byte[] d, int off) {
        int tag = d[off] & 0xFF, first = d[off + 1] & 0xFF;
        if (first < 128) return new int[]{tag, 2, first};
        int count = first & 0x7F, len = 0;
        for (int i = 0; i < count; i++) len = (len << 8) | (d[off + 2 + i] & 0xFF);
        return new int[]{tag, 2 + count, len};
    }

    // ---- elements (Kotlin throws IndexOutOfBoundsException; Java throws ArrayIndexOutOfBounds - a subclass - and the same guards) ----
    static class El { int tag, start, contentStart, end; El(int t, int s, int c, int e) { tag = t; start = s; contentStart = c; end = e; } }
    static El el(byte[] d, int off) {
        if (off < 0 || off + 2 > d.length) throw new IndexOutOfBoundsException("element outside the data");
        int[] h = header(d, off);
        int contentStart = off + h[1];
        long end = (long) contentStart + (long) h[2];
        if (h[2] < 0 || end > d.length) throw new IndexOutOfBoundsException("element longer than the data");
        return new El(h[0], off, contentStart, (int) end);
    }
    static List<El> children(byte[] d, El e) {
        List<El> out = new ArrayList<>(); int p = e.contentStart;
        while (p < e.end) { El c = el(d, p); if (c.end > e.end) throw new IndexOutOfBoundsException("child longer than its parent"); out.add(c); p = c.end; }
        return out;
    }
    static byte[] slice(byte[] d, El e) { return Arrays.copyOfRange(d, e.start, e.end); }
    static String oidString(byte[] d, El e) {
        StringBuilder sb = new StringBuilder(); long value = 0; boolean first = true;
        for (int i = e.contentStart; i < e.end; i++) {
            int b = d[i] & 0xFF; value = (value << 7) | (b & 0x7F);
            if ((b & 0x80) == 0) {
                if (first) { long a = value < 40 ? 0 : (value < 80 ? 1 : 2); sb.append(a).append('.').append(value - a * 40); first = false; }
                else sb.append('.').append(value);
                value = 0;
            }
        }
        return sb.toString();
    }
    static byte[] sha1(byte[] b) throws Exception { return MessageDigest.getInstance("SHA-1").digest(b); }

    // ---- certificate fields ----
    static class CertFields { byte[] serial, issuer, subject, publicKeyBits, extensions; }
    static CertFields fields(byte[] cert) {
        try {
            El outer = el(cert, 0); El tbs = el(cert, outer.contentStart);
            int p = tbs.contentStart; El e = el(cert, p);
            if (e.tag == 0xA0) { p = e.end; e = el(cert, p); }
            CertFields f = new CertFields();
            f.serial = slice(cert, e); p = e.end;
            e = el(cert, p); p = e.end;
            e = el(cert, p); f.issuer = slice(cert, e); p = e.end;
            e = el(cert, p); p = e.end;
            e = el(cert, p); f.subject = slice(cert, e); p = e.end;
            e = el(cert, p);
            List<El> spki = children(cert, e);
            El bits = spki.get(1);
            f.publicKeyBits = Arrays.copyOfRange(cert, bits.contentStart + 1, bits.end);
            p = e.end; f.extensions = null;
            while (p < tbs.end) { El x = el(cert, p); if (x.tag == 0xA3) { f.extensions = slice(cert, el(cert, x.contentStart)); break; } p = x.end; }
            return f;
        } catch (RuntimeException ex) { return null; }
    }
    static void addUrl(List<String> list, String url) { if ((url.startsWith("http://") || url.startsWith("https://")) && !list.contains(url)) list.add(url); }
    static List<List<String>> urlsOf(byte[] cert) {
        List<String> ocsp = new ArrayList<>(), crl = new ArrayList<>();
        try {
            CertFields cf = fields(cert);
            if (cf == null || cf.extensions == null) return Arrays.asList(ocsp, crl);
            byte[] ext = cf.extensions; El root = el(ext, 0);
            for (El x : children(ext, root)) {
                List<El> parts = children(ext, x);
                if (parts.size() < 2) continue;
                String id = oidString(ext, parts.get(0)); El octets = parts.get(parts.size() - 1);
                if (octets.tag != 0x04) continue;
                byte[] inner = Arrays.copyOfRange(ext, octets.contentStart, octets.end); El top = el(inner, 0);
                if (id.equals(OID_AIA)) {
                    for (El ad : children(inner, top)) {
                        List<El> adParts = children(inner, ad);
                        if (adParts.size() == 2 && oidString(inner, adParts.get(0)).equals(OID_OCSP) && adParts.get(1).tag == 0x86)
                            addUrl(ocsp, new String(inner, adParts.get(1).contentStart, adParts.get(1).end - adParts.get(1).contentStart, StandardCharsets.US_ASCII));
                    }
                } else if (id.equals(OID_CDP)) {
                    for (El dp : children(inner, top)) for (El field : children(inner, dp)) {
                        if (field.tag != 0xA0) continue;
                        for (El name : children(inner, field)) {
                            if (name.tag != 0xA0) continue;
                            for (El gn : children(inner, name)) if (gn.tag == 0x86) addUrl(crl, new String(inner, gn.contentStart, gn.end - gn.contentStart, StandardCharsets.US_ASCII));
                        }
                    }
                }
            }
        } catch (RuntimeException ex) { /* keep what was found */ }
        return Arrays.asList(ocsp, crl);
    }

    // ---- OCSP ----
    static byte[] certId(byte[] cert, byte[] issuer) throws Exception {
        CertFields c = fields(cert), i = fields(issuer);
        if (c == null || i == null) return null;
        return sequence(sequence(sha1Oid(), nullValue()), octetString(sha1(c.issuer)), octetString(sha1(i.publicKeyBits)), c.serial);
    }
    static byte[] buildOcspRequest(byte[] certId) { return sequence(sequence(sequence(sequence(certId)))); }
    static int[] parseOcspResponse(byte[] d, byte[] certId) {
        try {
            El top = el(d, 0);
            if (top.tag != 0x30) return new int[]{-1, -1, 0};
            List<El> parts = children(d, top);
            if (parts.isEmpty() || parts.get(0).tag != 0x0A || parts.get(0).end - parts.get(0).contentStart != 1) return new int[]{-1, -1, 0};
            int status = d[parts.get(0).contentStart] & 0xFF;
            if (status != 0) return new int[]{status, -1, 0};
            if (parts.size() < 2 || parts.get(1).tag != 0xA0) return new int[]{-1, -1, 0};
            List<El> responseBytes = children(d, el(d, parts.get(1).contentStart));
            if (responseBytes.size() < 2 || responseBytes.get(1).tag != 0x04) return new int[]{-1, -1, 0};
            byte[] basic = Arrays.copyOfRange(d, responseBytes.get(1).contentStart, responseBytes.get(1).end);
            El basicEl = el(basic, 0);
            List<El> tbs = children(basic, el(basic, basicEl.contentStart));
            int idx = 0;
            if (tbs.get(idx).tag == 0xA0) idx++;
            idx++; idx++;
            List<El> singles = children(basic, tbs.get(idx));
            int firstStatus = -1;
            for (El s : singles) {
                List<El> f = children(basic, s);
                if (f.size() < 3) continue;
                int t = f.get(1).tag; int st = t == 0x80 ? CERT_GOOD : (t == 0xA1 ? CERT_REVOKED : (t == 0x82 ? CERT_UNKNOWN : -1));
                if (firstStatus == -1) firstStatus = st;
                if (Arrays.equals(slice(basic, f.get(0)), certId)) return new int[]{0, st, 1};
            }
            return new int[]{0, firstStatus, 0};
        } catch (RuntimeException ex) { return new int[]{-1, -1, 0}; }
    }

    // ---- chain ----
    static boolean isSelfIssued(byte[] cert) { CertFields f = fields(cert); return f != null && Arrays.equals(f.issuer, f.subject); }
    static byte[] issuerOf(byte[] cert, List<byte[]> pool) {
        CertFields f = fields(cert); if (f == null) return null;
        if (Arrays.equals(f.issuer, f.subject)) return null;
        for (byte[] c : pool) { CertFields g = fields(c); if (g == null) continue; if (Arrays.equals(g.subject, f.issuer) && !Arrays.equals(c, cert)) return c; }
        return null;
    }
    static List<byte[]> cmsCertificates(byte[] cms) {
        List<byte[]> out = new ArrayList<>();
        try {
            List<El> content = children(cms, el(cms, 0));
            if (content.size() < 2) return out;
            El signedData = el(cms, content.get(1).contentStart);
            for (El p : children(cms, signedData)) { if (p.tag == 0xA0) { for (El c : children(cms, p)) if (c.tag == 0x30) out.add(slice(cms, c)); break; } }
        } catch (RuntimeException ex) { /* what was read */ }
        return out;
    }
    static boolean looksLikeCrl(byte[] d) {
        try { El top = el(d, 0); return top.tag == 0x30 && top.end == d.length && children(d, top).size() == 3; } catch (RuntimeException ex) { return false; }
    }

    // ---- collect ----
    static Map<String, byte[]> post = new HashMap<>(), get = new HashMap<>();
    static byte[] fetch(Map<String, byte[]> m, String url) throws IOException { byte[] r = m.get(url); if (r == null) throw new IOException("no answer"); return r; }
    static void addUnique(List<byte[]> list, byte[] item) { for (byte[] x : list) if (Arrays.equals(x, item)) return; list.add(item); }
    static Object[] collect(List<byte[]> chain) throws Exception {
        List<byte[]> certs = new ArrayList<>(), ocsps = new ArrayList<>(), crls = new ArrayList<>(); int needed = 0, covered = 0;
        for (byte[] cert : chain) {
            addUnique(certs, cert);
            if (isSelfIssued(cert)) continue;
            needed++;
            List<List<String>> urls = urlsOf(cert); boolean done = false;
            byte[] issuer = issuerOf(cert, chain); byte[] id = issuer != null ? certId(cert, issuer) : null;
            if (id != null) {
                byte[] request = buildOcspRequest(id);
                for (String u : urls.get(0)) {
                    byte[] reply; try { reply = fetch(post, u); } catch (IOException e) { continue; }
                    int[] a = parseOcspResponse(reply, id);
                    if (a[0] == 0 && a[2] == 1 && a[1] == CERT_GOOD) { addUnique(ocsps, reply); done = true; break; }
                }
            }
            if (!done) {
                for (String u : urls.get(1)) {
                    byte[] reply; try { reply = fetch(get, u); } catch (IOException e) { continue; }
                    if (looksLikeCrl(reply)) { addUnique(crls, reply); done = true; break; }
                }
            }
            if (done) covered++;
        }
        return new Object[]{certs, ocsps, crls, needed, covered};
    }

    // ---- driver ----
    static byte[] unhex(String h) { if (h.equals("-")) return new byte[0]; byte[] b = new byte[h.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return b; }
    static String hex(byte[] b) { if (b == null) return "-"; StringBuilder sb = new StringBuilder(); for (byte x : b) sb.append(String.format("%02x", x & 0xFF)); return sb.toString(); }
    static List<byte[]> list(String csv) { List<byte[]> out = new ArrayList<>(); if (csv.equals("-")) return out; for (String s : csv.split(",")) out.add(unhex(s)); return out; }

    public static void main(String[] a) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.US_ASCII)); String line;
        PrintStream out = new PrintStream(System.out, false, "UTF-8");
        while ((line = r.readLine()) != null) {
            String[] t = line.trim().split(" ");
            switch (t[0]) {
                case "FIELDS": { CertFields f = fields(unhex(t[1])); if (f == null) { out.println("NONE"); break; } out.println(hex(f.serial)); out.println(hex(f.issuer)); out.println(hex(f.subject)); out.println(hex(f.publicKeyBits)); out.println(hex(f.extensions)); break; }
                case "URLS": { List<List<String>> u = urlsOf(unhex(t[1])); for (String s : u.get(0)) out.println("O " + s); for (String s : u.get(1)) out.println("C " + s); out.println("END"); break; }
                case "CERTID": out.println(hex(certId(unhex(t[1]), unhex(t[2])))); break;
                case "REQ": out.println(hex(buildOcspRequest(unhex(t[1])))); break;
                case "PARSE": { int[] p = parseOcspResponse(unhex(t[1]), unhex(t[2])); out.println(p[0] + " " + p[1] + " " + p[2]); break; }
                case "SELF": out.println(isSelfIssued(unhex(t[1]))); break;
                case "ISSUER": { List<byte[]> pool = list(t[2]); byte[] i = issuerOf(unhex(t[1]), pool); int idx = -1; for (int k = 0; k < pool.size(); k++) if (i != null && Arrays.equals(pool.get(k), i)) { idx = k; break; } out.println(idx); break; }
                case "CMSCERTS": { List<byte[]> c = cmsCertificates(unhex(t[1])); out.println(c.size()); for (byte[] x : c) out.println(hex(x)); break; }
                case "CRL": out.println(looksLikeCrl(unhex(t[1]))); break;
                case "MAP": { String url = new String(unhex(t[2]), StandardCharsets.US_ASCII); Map<String, byte[]> m = t[1].equals("POST") ? post : get; if (t[3].equals("FAIL")) m.remove(url); else m.put(url, unhex(t[3])); break; }
                case "COLLECT": {
                    Object[] c = collect(list(t[1]));
                    @SuppressWarnings("unchecked") List<byte[]> certs = (List<byte[]>) c[0], ocsps = (List<byte[]>) c[1], crls = (List<byte[]>) c[2];
                    out.println(c[3] + " " + c[4] + " " + certs.size() + " " + ocsps.size() + " " + crls.size());
                    for (byte[] x : ocsps) out.println(hex(x)); for (byte[] x : crls) out.println(hex(x));
                    break;
                }
                default: break;
            }
        }
        out.flush();
    }
}
