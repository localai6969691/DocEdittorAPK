"""Kotlin: 'EXPOSES' - hàm / thuộc tính KHÔNG private lộ một kiểu private (phiên 23, mục 4.54).
Lỗi thật đã làm đỏ CI chạy #21: `PdfAutoLinks.kt:102 'internal' function exposes its 'private-in-class' parameter type 'Found'`. Trình biên dịch Kotlin coi đó là LỖI,
mà `kotlin_lint_check.py` (chỉ soi ngoặc / cú pháp kiểu Java / API mới) không thấy. Bộ kiểm này quét mọi tệp .kt:
  1. tìm các kiểu khai báo `private class|data class|object|interface|enum class|sealed class X` (kể cả lồng trong class / object);
  2. tìm các `fun` / `val` / `var` KHÔNG private (public, internal, protected, hay không ghi) có tên kiểu đó trong CHỮ KÝ (tham số, kiểu trả về, kiểu thuộc tính).
Chỉ so tên trong CÙNG TỆP (kiểu private của tệp này không thể bị tệp khác thấy). Kiểu trùng tên với kiểu công khai khác trong cùng tệp thì bỏ qua để khỏi báo nhầm.
`--selftest` kiểm chính logic (có ca đúng và ca sai, cả ca không được báo nhầm)."""
import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
HERE = os.path.dirname(os.path.abspath(__file__)); SRC = os.path.join(HERE, "..", "..", "app", "src", "main", "java")
PRIV = re.compile(r"^\s*(?:private|private\s+(?:data|sealed|enum|inner|abstract|open))\s+(?:data\s+|sealed\s+|enum\s+|inner\s+|abstract\s+|open\s+)?(?:class|object|interface)\s+(\w+)", re.M)
PRIV2 = re.compile(r"^\s*private\s+(?:data\s+|sealed\s+|enum\s+|inner\s+|abstract\s+|open\s+)*(?:class|object|interface)\s+(\w+)", re.M)
PUBTYPE = re.compile(r"^\s*(?:(?:public|internal|protected)\s+)?(?:(?:data|sealed|enum|inner|abstract|open)\s+)*(?:class|object|interface)\s+(\w+)", re.M)
DECL = re.compile(r"^(\s*)((?:(?:public|internal|protected|override|open|abstract|final|inline|suspend|operator|infix|tailrec|external|lateinit|const)\s+)*)(fun|val|var)\s+(?:<[^>]*>\s*)?([^\n{=]*)", re.M)

from kotlin_strip import strip   # bộ quét một lượt dùng chung (mục 4.57)

def _header(s, brace_pos):
    """Phần đầu của khối mở ở brace_pos: dòng chứa `{` cộng các dòng trước đó cho tới khi ngoặc tròn cân bằng (khai báo lớp có tham số xuống dòng)."""
    ls = s.rfind("\n", 0, brace_pos) + 1
    h = s[ls:brace_pos]
    while h.count(")") > h.count("("):
        prev_end = ls - 1
        if prev_end <= 0: break
        ls = s.rfind("\n", 0, prev_end) + 1
        h = s[ls:prev_end] + " " + h
    return h

def _members_not_private(s, positions):
    """-> {vị trí: True nếu khai báo ở vị trí đó là THÀNH VIÊN (mọi khối bao quanh đều là class/object/interface) và KHÔNG có khối private nào bao quanh}"""
    want = sorted(set(positions)); res = {}; stack = []; wi = 0
    for i, ch in enumerate(s):
        while wi < len(want) and want[wi] == i:
            res[i] = all(k == "type" for k, _ in stack) and not any(pv for _, pv in stack); wi += 1
        if ch == "{":
            h = _header(s, i)
            is_type = re.search(r"\b(?:class|object|interface)\b", h) and not re.search(r"\bfun\b|->", h)
            stack.append(("type" if is_type else "other", bool(is_type and re.search(r"\bprivate\b", h))))
        elif ch == "}" and stack:
            stack.pop()
    return res

def scan(src):
    """-> [(dòng, tên kiểu private, chữ ký)]  Chỉ tính thành viên của lớp / đối tượng KHÔNG private (hoặc khai báo cấp tệp); biến cục bộ và thành viên của lớp private thì bỏ."""
    s = strip(src)
    privs = set(PRIV2.findall(s))
    privs -= set(PUBTYPE.findall(s))
    out = []
    if not privs: return out
    matches = list(DECL.finditer(s))
    member = _members_not_private(s, [m.start() for m in matches])
    for m in matches:
        if not member.get(m.start(), False): continue
        mods = m.group(2) or ""
        line_start = s.rfind("\n", 0, m.start()) + 1
        prefix = s[line_start:m.start(3)]
        if re.search(r"\bprivate\b", prefix) or re.search(r"\bprivate\b", mods): continue
        sig = m.group(4)
        for t in privs:
            if re.search(r"(?<![\w.])" + re.escape(t) + r"(?!\w)", sig):
                out.append((s.count("\n", 0, m.start()) + 1, t, sig.strip()))
    return out

def selftest():
    ok = True
    def case(name, src, want):
        nonlocal ok
        got = [t for _, t, _ in scan(src)]; good = got == want; ok &= good
        print(("ok   " if good else "LOI  ") + name + ("" if good else f"  (có {got}, muốn {want})"))
    base = "object A {\n    private class Found(val x: Int)\n"
    case("TÁI HIỆN lỗi #21: internal fun lộ tham số private", base + "    internal fun overlaps(r: Int?, f: Found): Boolean { return true }\n}", ["Found"])
    case("fun không ghi phạm vi (public) lộ tham số private", base + "    fun go(f: Found) {}\n}", ["Found"])
    case("fun lộ kiểu TRẢ VỀ private", base + "    fun make(): Found = Found(1)\n}", ["Found"])
    case("val public có kiểu private", base + "    val last: Found? = null\n}", ["Found"])
    case("private fun dùng kiểu private -> hợp lệ", base + "    private fun go(f: Found) {}\n}", [])
    case("kiểu private chỉ dùng trong thân hàm -> hợp lệ", base + "    fun count(): Int { val l = ArrayList<Found>(); return l.size }\n}", [])
    case("tên kiểu nằm trong chuỗi / chú thích -> không báo", base + '    fun x(s: String) = "Found a"  // Found\n}', [])
    case("tên chứa tên kiểu (FoundIt) -> không báo nhầm", base + "    fun go(f: FoundIt) {}\n}", [])
    case("hàm có tên chứa Found trong tên hàm không tính", base + "    fun onFound(a: Int) {}\n}", [])
    case("kiểu cùng tên nhưng công khai cùng tệp -> bỏ qua", "class Found\nobject A {\n    private class Found(val x: Int)\n    fun go(f: Found) {}\n}", [])
    case("private data class + internal fun", "object B {\n    private data class P(val a: Int)\n    internal fun f(p: P) {}\n}", ["P"])
    case("hàm có generic lộ kiểu private", base + "    fun <T> g(list: List<Found>, t: T) {}\n}", ["Found"])
    case("BIẾN CỤC BỘ trong hàm có kiểu private -> không báo (báo nhầm ở EpubTools / TesseractOcr / OfficeImport)", base + "    fun run() {\n        var f: Found? = null\n        val g: Found? = null\n    }\n}", [])
    case("thành viên của lớp PRIVATE có kiểu private khác -> hợp lệ (Pkcs12Modern.Node.children)", "object C {\n    private class Node(val a: Int) {\n        val children: List<Node> get() = emptyList()\n        fun f(n: Node) {}\n    }\n}", [])
    case("khai báo lớp có tham số xuống dòng vẫn nhận ra là private", "object C {\n    private class Node(val a: Int,\n                       val b: Int) {\n        fun f(n: Node) {}\n    }\n}", [])
    case("thành viên của lớp CÔNG KHAI lộ kiểu private cấp tệp", "private class Hidden(val a: Int)\nclass Open {\n    fun f(h: Hidden) {}\n}", ["Hidden"])
    case("companion object công khai lộ kiểu private của lớp bao -> LỖI (đúng với trình biên dịch)", "class K {\n    private class P(val a: Int)\n    companion object {\n        fun f(p: P) {}\n    }\n}", ["P"])
    case("hàm cấp tệp internal lộ kiểu private cấp tệp", "private class Hidden(val a: Int)\ninternal fun f(h: Hidden) {}", ["Hidden"])
    case("lambda / if trong hàm không làm lệch việc theo dõi khối", base + "    fun run(l: List<Int>) {\n        l.forEach { x -> if (x > 0) { val f: Found? = null } }\n    }\n    fun bad(f: Found) {}\n}", ["Found"])
    print(); print("TAT CA DAT" if ok else "CO LOI"); return 0 if ok else 1

def main():
    if "--selftest" in sys.argv: return selftest()
    bad = []; n = 0
    for dp, _, fs in os.walk(SRC):
        for f in fs:
            if not f.endswith(".kt"): continue
            n += 1; p = os.path.join(dp, f)
            for line, t, sig in scan(open(p, encoding="utf-8").read()):
                bad.append(f"{f}:{line}: '{sig[:80]}' lộ kiểu private '{t}'")
    for b in bad: print("LOI  " + b)
    print(f"đã quét {n} tệp .kt")
    print("TAT CA DAT" if not bad else f"CO {len(bad)} LOI"); return 1 if bad else 0
if __name__ == "__main__": sys.exit(main())
