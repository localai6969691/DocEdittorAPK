"""Kiểm DocInsight (phân loại, gợi ý thẻ TF-IDF, tóm tắt TextRank; phiên 20, 4.48.3) qua bản Java song song `DocInsightCheck.java`.

  A. fold      : `foldLower` của Java = `unicodedata` của Python trên mọi ký tự Latin / Việt / Hy Lạp / Cyrillic (cùng độ dài).
  B. phân loại : 37 văn bản viết tay theo khuôn tài liệu thật (không lấy từ bảng cụm từ) + 6 văn bản KHÔNG thuộc loại nào; biến thể: bỏ dấu + chữ thường, nhiễu OCR 2 %, nửa đầu,
                 xuống dòng giữa câu. Bảng cụm từ được TRÍCH TỪ MÃ KOTLIN để kiểm đúng bảng thật. Đo tỉ lệ đúng, in ra, và đặt ngưỡng.
  C. thẻ       : điểm TF-IDF của MỌI ứng viên = (1 + ln đếm) x IDF của scikit-learn (smooth) x 1,5 cho cụm hai từ; df khớp; chọn cụm hai từ trước rồi từ đơn;
                 chữ hiện ra là chữ GỐC (có dấu) cắt đúng chỗ; cụm hai từ không vượt dấu câu.
  D. câu       : tách câu (xuống dòng giữa câu, dòng trống, số thập phân, 。).
  E. tóm tắt   : ma trận cosin = scikit-learn (TfidfVectorizer, cùng token), điểm PageRank = networkx.pagerank (có nút cô lập), tập câu chọn khớp.
  F. thử âm tính: 6 bản Java cố ý hỏng phải bị bắt.
Chạy: python3 doc_insight_check.py   (cần java, scikit-learn, networkx, numpy; ~1 phút)
"""
import math, os, random, re, shutil, subprocess, sys, tempfile, unicodedata
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import OUT
from doc_insight_corpus import DOCS, NEGATIVES, POOL
import numpy as np
import networkx as nx
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer, TfidfVectorizer

HERE = os.path.dirname(os.path.abspath(__file__))
JAVA = os.path.join(HERE, "DocInsightCheck.java")
KT = os.path.join(HERE, "..", "..", "app", "src", "main", "java", "com", "example", "docscanner", "util", "DocInsight.kt")
KT_TEXT = open(KT, encoding="utf-8").read()
FAIL = []
rnd = random.Random(20261022)
hx = lambda s: s.encode("utf-8").hex()
unhx = lambda h: bytes.fromhex(h).decode("utf-8")


def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: FAIL.append(msg)
    return ok


def jv(cmds, java=JAVA):
    r = subprocess.run(["java", java], input="\n".join(cmds) + "\n", capture_output=True, text=True)
    if r.returncode:
        print(r.stdout[-1500:], r.stderr[-2000:]); sys.exit(1)
    secs, cur = [], None
    for line in r.stdout.split("\n"):
        if line.startswith("== "): cur = []; secs.append(cur)
        elif cur is not None and line != "": cur.append(line)
    assert len(secs) == len(cmds), (len(secs), len(cmds))
    return secs


TABLE = re.search(r'internal val TABLE = """\n(.*?)\n""".trimIndent\(\)', KT_TEXT, re.S).group(1)
STOP = set("".join(re.findall(r'"([^"\n]*)"', re.search(r"private val STOP: Set<String> = \((.*?)\)\.split", KT_TEXT, re.S).group(1))).split(" "))
STOP.discard("")


def classify(texts, table=TABLE, java=JAVA):
    out = jv([f"CLS {hx(table)} {hx(t)}" for t in texts], java)
    res = []
    for s in out:
        p = s[0].split("|")
        res.append((None if p[0] == "NONE" else p[0], float(p[1]), None if len(p) < 3 or p[2] == "-" else p[2]))
    return res


def strip_accents(s):
    return "".join(("d" if c == "đ" else "D" if c == "Đ" else unicodedata.normalize("NFD", c)[0]) for c in s).lower()


def noisy(s, p=0.02):
    out = []
    for c in s:
        r = rnd.random()
        if c.isalpha() and r < p: out.append(rnd.choice("abcdefghijklmnopqrstuvwxyz"))
        elif c.isalpha() and r < 1.5 * p: continue
        else: out.append(c)
    return "".join(out)


def wrapped(s, width=34):
    """Ngắt dòng giữa câu như OCR / PDF: mỗi dòng tối đa `width` ký tự theo từ."""
    out = []
    for line in s.split("\n"):
        cur = ""
        for w in line.split(" "):
            if cur and len(cur) + 1 + len(w) > width: out.append(cur); cur = w
            else: cur = (cur + " " + w).strip()
        out.append(cur)
    return "\n".join(out)


def main():
    tmp = tempfile.mkdtemp(dir=OUT)
    try:
        part_a(); part_b(); part_c(); part_d(); part_e(tmp); part_f(tmp)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("TAT CA DAT" if not FAIL else f"CO LOI ({len(FAIL)})")
    return 1 if FAIL else 0


def py_fold_lower(s):
    out = []
    for c in s:
        b = "d" if c == "đ" else "D" if c == "Đ" else unicodedata.normalize("NFD", c)[0]
        l = b.lower()
        out.append(l if len(l) == 1 else b)
    return "".join(out)


def part_a():
    print("== A. fold")
    chars = [chr(c) for c in list(range(0x20, 0x250)) + list(range(0x1E00, 0x1F00)) + list(range(0x370, 0x400)) + list(range(0x400, 0x460)) if chr(c).isprintable()]
    s = "".join(chars)
    got = unhx(jv([f"FOLD {hx(s)}"])[0][0])
    exp = py_fold_lower(s)
    bad = [(a, b) for a, b in zip(got, exp) if a != b]
    check(len(got) == len(s) and not bad, f"foldLower: {len(s)} ký tự Latin / Việt / Hy Lạp / Cyrillic, cùng độ dài, = unicodedata của Python ({len(bad)} lệch {bad[:4]})")
    viet = "Hợp đồng thuê nhà ĐƯỜNG Nguyễn Văn Ân"
    check(unhx(jv([f"FOLD {hx(viet)}"])[0][0]) == "hop dong thue nha duong nguyen van an", "foldLower: 'Hợp đồng ... ĐƯỜNG Nguyễn' -> không dấu, chữ thường")


def part_b():
    print("== B. phân loại")
    cats = list(DOCS)
    items = [(c, t) for c in cats for t in DOCS[c]]
    check(len(items) == 37 and len(NEGATIVES) == 6, f"kho mẫu: {len(items)} văn bản có loại + {len(NEGATIVES)} văn bản không thuộc loại nào")
    variants = {
        "nguyên văn": lambda t: t,
        "bỏ dấu + chữ thường": strip_accents,
        "nhiễu OCR 2 %": noisy,
        "nửa đầu": lambda t: t[:max(40, len(t) // 2)],
        "xuống dòng giữa câu": wrapped,
    }
    thresholds = {"nguyên văn": 0.97, "bỏ dấu + chữ thường": 0.97, "nhiễu OCR 2 %": 0.8, "nửa đầu": 0.6, "xuống dòng giữa câu": 0.97}
    for name, fn in variants.items():
        res = classify([fn(t) for _, t in items])
        ok = sum(1 for (c, _), (g, _, _) in zip(items, res) if g == c)
        wrong = [(c, g) for (c, _), (g, _, _) in zip(items, res) if g != c]
        check(ok / len(items) >= thresholds[name], f"phân loại [{name}]: đúng {ok}/{len(items)} = {100 * ok / len(items):.0f} % (ngưỡng {100 * thresholds[name]:.0f} %); sai: {wrong[:5]}")
    neg = classify(NEGATIVES)
    nn = sum(1 for g, _, _ in neg if g is None)
    check(nn == len(NEGATIVES), f"6 văn bản không thuộc loại nào -> không gán loại: {nn}/6 ({[g for g, _, _ in neg]})")
    # ca có hai loại gần nhau: hợp đồng lao động có điều khoản về 'hóa đơn' không bị coi là hóa đơn
    mixed = DOCS["CONTRACT"][0] + "\nBên B thanh toán theo hóa đơn do Bên A xuất hàng tháng. Mỗi hóa đơn ghi rõ thuế suất."
    check(classify([mixed])[0][0] == "CONTRACT", "hợp đồng nhắc 'hóa đơn' vài lần vẫn là hợp đồng")
    # từ nguyên: "ben a" trong "Reuben and" không tính (chỉ tính cả từ)
    reuben = "Reuben and Reuben as Reuben at the station, Reuben and his dog."
    check(classify([reuben])[0][0] is None, "cụm chỉ tính khi là cả từ: 'Reuben a...' không phải 'Bên A'")
    # bảng thật: mỗi dòng đọc được, trọng số dương
    rows = [l.split(" ", 2) for l in TABLE.split("\n") if l.strip()]
    check(all(float(r[1]) > 0 and r[2] == r[2].lower() and strip_accents(r[2]) == r[2] for r in rows) and len(rows) > 150, f"bảng cụm từ trong mã Kotlin: {len(rows)} dòng, đều không dấu + chữ thường + trọng số > 0")


TOKCACHE = {}


def prefetch(texts):
    """Một lượt gọi Java cho nhiều văn bản (mỗi lần khởi động JVM mất ~1 giây)."""
    todo = [t for t in dict.fromkeys(texts) if t not in TOKCACHE]
    if not todo: return
    for t, out in zip(todo, jv([f"TOK {hx(t)}" for t in todo])):
        TOKCACHE[t] = [(unhx(p[1]), int(p[2]), int(p[3]), p[4] == "1") for p in (l.split("|") for l in out)]


def tokens_of(text):
    prefetch([text])
    return TOKCACHE[text]


def py_candidates(toks):
    """Cài đặt LẠI bằng Python của quy tắc ứng viên (đơn từ >= 4 chữ, cụm hai từ không có dấu ngắt giữa)."""
    out = []
    for i, (w, s, e, brk) in enumerate(toks):
        if len(w) >= 4 and w not in STOP: out.append((w, 1, s, e))
        if i + 1 < len(toks):
            u = toks[i + 1]
            if not u[3] and len(w) >= 2 and len(u[0]) >= 2 and w not in STOP and u[0] not in STOP: out.append((w + " " + u[0], 2, s, u[2]))
    return out


def part_c():
    print("== C. gợi ý thẻ (TF-IDF)")
    items = [t for c in DOCS for t in DOCS[c]]
    targets = [items[i] for i in (0, 4, 8, 12, 16, 20, 24, 28, 32, 1, 9, 21)]
    prefetch(items + ["\n".join([t] * 3) for t in targets])
    maxdiff = 0.0; nterms = 0; dfbad = 0; selbad = 0; surfbad = 0; ranked_bad = 0
    for tgt in targets:
        text = "\n".join([tgt] * 3)
        others = [t for t in items if t != tgt]
        out = jv([f"KWS {hx(text)} {len(others)} " + " ".join(hx(o) for o in others), f"KW 5 {hx(text)} {len(others)} " + " ".join(hx(o) for o in others)])
        rows = [l.split("|") for l in out[0]]
        java = {unhx(r[1]): (int(r[2]), float(r[3]), int(r[4])) for r in rows}
        # kho tài liệu theo ứng viên của CHÍNH Python (từ token Java) -> IDF của scikit-learn
        docs_c = [[c[0] for c in py_candidates(tokens_of(d))] for d in [text] + others]
        cv = CountVectorizer(analyzer=lambda d: d)
        X = cv.fit_transform(docs_c)
        tf = TfidfTransformer(smooth_idf=True, norm=None, sublinear_tf=False).fit(X)
        vocab = cv.vocabulary_
        counts = {}
        for w, _, _, _ in py_candidates(tokens_of(text)): counts[w] = counts.get(w, 0) + 1
        for key, (cnt, score, df) in java.items():
            idf = tf.idf_[vocab[key]]
            exp = (1 + math.log(counts[key])) * idf * (1.5 if " " in key else 1.0)
            maxdiff = max(maxdiff, abs(exp - score)); nterms += 1
            if cnt != counts[key]: dfbad += 1
            if df != int((X[:, vocab[key]] > 0).sum()): dfbad += 1
        if {k for k, c in counts.items() if c >= 2} != set(java): ranked_bad += 1
        # chọn: tối đa 3 cụm hai từ (điểm cao nhất), rồi từ đơn không nằm trong cụm đã chọn
        order = [unhx(r[1]) for r in rows]
        want = [k for k in order if " " in k][:3]
        inp = {w for k in want for w in k.split(" ")}
        want += [k for k in order if " " not in k and k not in inp][:5 - len(want)]
        got_kw = [unhx(l.split("|")[1]) for l in out[1]]
        # chữ hiện ra: lấy từ văn bản GỐC (có dấu), chữ thường, khoảng trắng gọn
        toks = tokens_of(text)
        surf = []
        for k in want:
            first = next(c for c in py_candidates(toks) if c[0] == k)
            surf.append(re.sub(r"\s+", " ", text[first[2]:first[3]]).lower())
        if got_kw != surf: selbad += 1
    check(nterms > 300 and maxdiff < 1e-9, f"điểm TF-IDF của {nterms} ứng viên (12 tài liệu) = (1 + ln đếm) x IDF scikit-learn (smooth) x 1,5 cụm hai từ: lệch lớn nhất {maxdiff:.2e}")
    check(dfbad == 0 and ranked_bad == 0, f"số lần xuất hiện và df khớp ({dfbad} lệch); tập ứng viên (>= 2 lần) khớp ({ranked_bad} tài liệu lệch)")
    check(selbad == 0, f"lựa chọn thẻ (cụm hai từ trước, rồi từ đơn không nằm trong cụm) và chữ GỐC có dấu khớp ở {12 - selbad}/12 tài liệu")
    # ví dụ thật để xem
    ex = DOCS["CONTRACT"][0]
    kws = [unhx(l.split("|")[1]) for l in jv([f"KW 5 {hx(chr(10).join([ex] * 3))} 0"])[0]]
    print("   ví dụ (hợp đồng thuê nhà x3, không có kho khác):", kws)
    check(len(kws) == 5 and all(k == k.lower() for k in kws), "ví dụ: 5 thẻ, chữ thường, giữ dấu")
    # cụm hai từ không vượt dấu câu; ít từ thì không gợi ý
    t = "hợp đồng. thuê nhà, hợp đồng. thuê nhà, hợp đồng. thuê nhà, giá cả, giá cả, giá cả"
    got = [unhx(l.split("|")[1]) for l in jv([f"KW 5 {hx(t)} 0"])[0]]
    check("đồng thuê" not in got and "hợp đồng" in got, f"cụm hai từ không vượt dấu chấm / phẩy: {got}")
    check(jv([f"KW 5 {hx('ngắn quá ít từ')} 0"])[0] == [], "văn bản dưới 8 từ: không gợi ý")


def part_d():
    print("== D. tách câu")
    cases = [
        ("dòng bị ngắt giữa câu được nối", "Chi phí thuê nhà là khoản chi\nlớn nhất trong tháng. Gia đình\nnên tiết kiệm.", ["Chi phí thuê nhà là khoản chi lớn nhất trong tháng.", "Gia đình nên tiết kiệm."]),
        ("dòng trống kết thúc đoạn", "Tiêu đề không có dấu chấm\n\nCâu thứ nhất. Câu thứ hai!", ["Tiêu đề không có dấu chấm", "Câu thứ nhất.", "Câu thứ hai!"]),
        ("số thập phân và tên viết tắt không cắt giữa số", "Giá là 3.5 triệu đồng. Hẹn gặp lại?", ["Giá là 3.5 triệu đồng.", "Hẹn gặp lại?"]),
        ("dấu 。 ！ ？ không cần khoảng trắng", "今日は晴れです。明日は雨？はい！", ["今日は晴れです。", "明日は雨？", "はい！"]),
        ("khoảng trắng thừa", "  A   b  c.   D   e.  ", ["A b c.", "D e."]),
        ("rỗng", "  \n \n", []),
    ]
    out = jv([f"SENT {hx(t)}" for _, t, _ in cases])
    for (name, _, exp), o in zip(cases, out):
        check([unhx(l.split("|")[1]) for l in o] == exp, f"tách câu - {name}")


def sentences_docs():
    docs = []
    for _ in range(20):
        k = rnd.randint(8, 18)
        docs.append(" ".join(rnd.sample(POOL, k)))
    return docs


def part_e(tmp):
    print("== E. tóm tắt (TextRank)")
    docs = sentences_docs()
    out = jv([c for d in docs for c in (f"CAND {hx(d)}", f"SIM {hx(d)}", f"RANK {hx(d)}", f"SUM 3 {hx(d)}")])
    maxsim = 0.0; maxrank = 0.0; selbad = 0; dangling_docs = 0; total = 0
    prefetch([unhx(l.split("|")[1]) for i in range(len(docs)) for l in out[4 * i]])
    for i, d in enumerate(docs):
        cand = [unhx(l.split("|")[1]) for l in out[4 * i]]
        sim = np.array([[float(x) for x in l.split("|")[1:]] for l in out[4 * i + 1]])
        rank = np.array([float(l.split("|")[1]) for l in out[4 * i + 2]])
        summ = [unhx(l.split("|")[1]) for l in out[4 * i + 3]]
        n = len(cand)
        if n <= 3: continue
        total += 1
        prefetch(cand)
        # cosin: scikit-learn, cùng token (đơn từ >= 2 chữ, không phải từ dừng)
        toks = [[w for w, _, _, _ in tokens_of(s) if len(w) >= 2 and w not in STOP] for s in cand]
        tv = TfidfVectorizer(analyzer=lambda i_: toks[i_], smooth_idf=True, norm="l2")
        X = tv.fit_transform(range(n)).toarray()
        ref = X @ X.T
        np.fill_diagonal(ref, 0.0)
        maxsim = max(maxsim, float(np.abs(ref - sim).max()))
        # PageRank: networkx trên đúng đồ thị đó (nút cô lập = nút treo)
        G = nx.Graph(); G.add_nodes_from(range(n))
        for a in range(n):
            for b in range(a + 1, n):
                if sim[a, b] > 0: G.add_edge(a, b, weight=float(sim[a, b]))
        if any(G.degree(v) == 0 for v in G): dangling_docs += 1
        pr = nx.pagerank(G, alpha=0.85, weight="weight", tol=1e-14, max_iter=100000)
        refrank = np.array([pr[v] for v in range(n)])
        maxrank = max(maxrank, float(np.abs(refrank - rank).max()))
        order = sorted(range(n), key=lambda v: (-refrank[v], v))[:3]
        if [cand[v] for v in sorted(order)] != summ: selbad += 1
    check(total >= 15 and maxsim < 1e-9, f"ma trận cosin TF-IDF của {total} tài liệu = scikit-learn TfidfVectorizer (smooth, L2): lệch lớn nhất {maxsim:.2e}")
    check(maxrank < 1e-8, f"điểm PageRank (alpha 0,85) = networkx.pagerank: lệch lớn nhất {maxrank:.2e}; {dangling_docs} tài liệu có nút cô lập (nút treo)")
    check(selbad == 0, f"3 câu được chọn (theo thứ tự xuất hiện) = chọn theo điểm networkx ở {total - selbad}/{total} tài liệu")
    check(dangling_docs >= 3, f"bộ dữ liệu có {dangling_docs} tài liệu với nút cô lập (không kiểm chay phần nút treo)")
    # ít câu: trả hết; câu quá ngắn / quá dài bị loại
    short = "Ngắn quá. Câu này đủ dài để làm câu ứng viên trong bản tóm tắt tài liệu của người dùng."
    r = [unhx(l.split("|")[1]) for l in jv([f"SUM 3 {hx(short)}"])[0]]
    check(r == ["Câu này đủ dài để làm câu ứng viên trong bản tóm tắt tài liệu của người dùng."], "câu dưới 30 ký tự bị loại; ít hơn 3 ứng viên thì trả hết")
    # ví dụ để xem
    ex = docs[0]
    print("   ví dụ tóm tắt:", [unhx(l.split("|")[1])[:70] + "…" for l in jv([f"SUM 3 {hx(ex)}"])[0]])


def part_f(tmp):
    print("== F. thử âm tính")
    src = open(JAVA, encoding="utf-8").read()
    n = [0]

    def make(old, new):
        assert src.count(old) == 1, old
        n[0] += 1
        name = f"DocInsightM{n[0]}"
        path = os.path.join(tmp, name + ".java")
        open(path, "w", encoding="utf-8").write(src.replace(old, new).replace("DocInsightCheck", name))
        return path

    reuben = "Reuben and Reuben as Reuben at the station, Reuben and his dog."
    j = make("if (!Character.isLetterOrDigit(before) && !Character.isLetterOrDigit(after)) n++;", "n++;")
    check(classify([reuben], java=j)[0][0] == "CONTRACT", "bản hỏng 'cụm không cần là cả từ' bị bắt (coi 'Reuben as' là Bên A)")
    # IDF hằng số
    docs = [t for c in DOCS for t in DOCS[c]]
    tgt = "\n".join([docs[0]] * 3); others = docs[1:]
    j = make("static double idf(int n, int df) { return Math.log((1.0 + n) / (1.0 + df)) + 1.0; }", "static double idf(int n, int df) { return 1.0; }")
    def kws_scores(java):
        out = jv([f"KWS {hx(tgt)} {len(others)} " + " ".join(hx(o) for o in others)], java)[0]
        return {unhx(l.split("|")[1]): float(l.split("|")[3]) for l in out}
    a, b = kws_scores(JAVA), kws_scores(j)
    check(max(abs(a[k] - b[k]) for k in a) > 0.1, "bản hỏng 'không dùng IDF' cho điểm TF-IDF khác hẳn (bài kiểm C bắt được)")
    # PageRank không xử lý nút treo
    d = " ".join(POOL[:7] + POOL[15:18] + POOL[-3:])
    j = make("next[j] = (1.0 - alpha) / n + alpha * (s + dangling / n);", "next[j] = (1.0 - alpha) / n + alpha * s;")
    r0 = [float(l.split("|")[1]) for l in jv([f"RANK {hx(d)}"])[0]]
    r1 = [float(l.split("|")[1]) for l in jv([f"RANK {hx(d)}"], j)[0]]
    check(max(abs(x - y) for x, y in zip(r0, r1)) > 1e-4, "bản hỏng 'bỏ nút treo' cho điểm PageRank khác networkx (bài kiểm E bắt được)")
    # tách câu không nối dòng
    j = make("else { if (cur.length() > 0) cur.append(' '); cur.append(t); }", "else { if (cur.length() > 0) { paragraphs.add(cur.toString()); cur.setLength(0); } cur.append(t); }")
    t = "Chi phí thuê nhà là khoản chi\nlớn nhất trong tháng."
    got = [unhx(l.split("|")[1]) for l in jv([f"SENT {hx(t)}"], j)[0]]
    check(got != ["Chi phí thuê nhà là khoản chi lớn nhất trong tháng."], "bản hỏng 'không nối dòng bị ngắt giữa câu' bị bắt")
    # không gấp dấu
    j = make("else sb.append(Normalizer.normalize(String.valueOf(c), Normalizer.Form.NFD).charAt(0));", "else sb.append(c);")
    check(unhx(jv([f"FOLD {hx('Hợp đồng')}"], j)[0][0]) != "hop dong", "bản hỏng 'không gấp dấu' bị bắt")
    # cụm hai từ vượt dấu câu
    j = make("if (!u.brk && t.text.length() >= 2", "if (t.text.length() >= 2")
    t = "hợp đồng. thuê nhà, hợp đồng. thuê nhà, hợp đồng. thuê nhà, giá cả, giá cả, giá cả"
    got = [unhx(l.split("|")[1]) for l in jv([f"KW 5 {hx(t)} 0"], j)[0]]
    check(any(k.startswith("đồng") and "thuê" in k for k in got), f"bản hỏng 'cụm hai từ vượt dấu câu' bị bắt ({got[:3]})")


if __name__ == "__main__":
    sys.exit(main())
