// Bản Java song song (chạy được trên máy tính) của app/.../util/TextWrapper.kt (phiên 16): cùng thuật toán chọn điểm ngắt dòng.
// Khác DUY NHẤT: nguồn các điểm được phép ngắt - trên Android là android.icu.text.BreakIterator (ICU, UAX #14), ở đây là java.text.BreakIterator.
// Dùng bởi tools/verify/text_wrap_check.py:  java WrapCheck.java <bảng độ rộng ký tự> <các đoạn, mỗi đoạn một dòng> <độ rộng tối đa> <ra> <ra: các điểm ngắt>
// Bảng độ rộng: mỗi dòng "<code point thập phân>\t<độ rộng>" (do Python đo bằng phông thật). Ra: "<chỉ số đoạn>\t<dòng>"; ra thứ hai: "<chỉ số đoạn>\t<các điểm ngắt cách nhau bằng dấu phẩy>" (để Python kiểm mỗi chỗ ngắt có hợp lệ không).
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.text.BreakIterator;
import java.util.*;

public class WrapCheck {
    interface Measure { float width(int start, int end); }

    static List<String> wrap(String text, float maxWidth, int[] boundaries, Measure measure) {
        int n = text.length();
        List<String> lines = new ArrayList<>();
        int[] bs = boundaries;
        if (!(boundaries.length > 0 && boundaries[boundaries.length - 1] == n)) {
            bs = Arrays.copyOf(boundaries, boundaries.length + 1);
            bs[bs.length - 1] = n;
        }
        int start = skipWhitespace(text, 0);
        int bi = 0;
        while (start < n) {
            while (bi < bs.length && bs[bi] <= start) bi++;
            int best = -1;
            int j = bi;
            while (j < bs.length) {
                int b = bs[j];
                int end = trimEnd(text, start, b);
                if (end > start && measure.width(start, end) > maxWidth) break;
                best = b;
                j++;
            }
            if (best < 0) best = splitInside(text, start, bs[bi], maxWidth, measure);
            int lineEnd = trimEnd(text, start, best);
            if (lineEnd > start) lines.add(text.substring(start, lineEnd));
            start = skipWhitespace(text, best);
        }
        return lines;
    }

    static int splitInside(String text, int start, int limit, float maxWidth, Measure measure) {
        int k = start;
        while (k < limit) {
            int next = k + Character.charCount(text.codePointAt(k));
            while (next < limit && isCombining(text.codePointAt(next))) next += Character.charCount(text.codePointAt(next));
            if (k > start && measure.width(start, trimEnd(text, start, next)) > maxWidth) break;
            k = next;
        }
        return k;
    }

    static boolean isCombining(int cp) {
        int t = Character.getType(cp);
        return t == Character.NON_SPACING_MARK || t == Character.ENCLOSING_MARK || t == Character.COMBINING_SPACING_MARK;
    }

    static int skipWhitespace(String text, int from) {
        int i = from;
        while (i < text.length() && Character.isWhitespace(text.charAt(i))) i++;
        return i;
    }

    static int trimEnd(String text, int start, int end) {
        int e = end;
        while (e > start && Character.isWhitespace(text.charAt(e - 1))) e--;
        return e;
    }

    static int[] lineBreakOffsets(String text) {
        BreakIterator it = BreakIterator.getLineInstance(Locale.ROOT);
        it.setText(text);
        List<Integer> out = new ArrayList<>();
        for (int b = it.next(); b != BreakIterator.DONE; b = it.next()) out.add(b);
        int[] a = new int[out.size()];
        for (int i = 0; i < a.length; i++) a[i] = out.get(i);
        return a;
    }

    public static void main(String[] args) throws Exception {
        Map<Integer, Float> table = new HashMap<>();
        for (String l : Files.readAllLines(Paths.get(args[0]), StandardCharsets.UTF_8)) {
            if (l.isEmpty()) continue;
            String[] p = l.split("\t");
            table.put(Integer.parseInt(p[0]), Float.parseFloat(p[1]));
        }
        float max = Float.parseFloat(args[2]);
        List<String> paras = Files.readAllLines(Paths.get(args[1]), StandardCharsets.UTF_8);
        try (PrintWriter out = new PrintWriter(Files.newBufferedWriter(Paths.get(args[3]), StandardCharsets.UTF_8));
             PrintWriter bout = new PrintWriter(Files.newBufferedWriter(Paths.get(args[4]), StandardCharsets.UTF_8))) {
            for (int pi = 0; pi < paras.size(); pi++) {
                final String text = paras.get(pi);
                Measure m = (s, e) -> {
                    float w = 0;
                    for (int i = s; i < e; ) {
                        int cp = text.codePointAt(i);
                        Float cw = table.get(cp);
                        if (cw == null) throw new IllegalStateException("thiếu độ rộng cho U+" + Integer.toHexString(cp));
                        w += cw;
                        i += Character.charCount(cp);
                    }
                    return w;
                };
                int[] bounds = lineBreakOffsets(text);
                StringBuilder bsb = new StringBuilder();
                for (int i = 0; i < bounds.length; i++) bsb.append(i == 0 ? "" : ",").append(bounds[i]);
                bout.println(pi + "\t" + bsb);
                for (String line : wrap(text, max, bounds, m)) out.println(pi + "\t" + line);
            }
        }
    }
}
