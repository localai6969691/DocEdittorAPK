"""Kiểm chứng "Chỉnh tay" + "Khử đốm" (phiên 17, mục 4.31).

PHẦN A - Khử đốm (Despeckle.kt <-> ManualAdjustCheck.java). Trang A4 150 dpi DỰNG từ chữ tiếng Việt có đủ dấu thanh (phông DejaVu) cộng bụi
có đáp án chuẩn: (1) bụi nằm trên giấy trắng xa chữ PHẢI bị xoá hết; (2) mọi điểm ảnh của chữ (kể cả dấu thanh, chấm i, dấu chấm) PHẢI còn nguyên
ở mọi mức 1..3; (3) bụi sát chữ phải được GIỮ (bảo vệ); (4) mức 0 không đổi gì; (5) bản Java = bản tham chiếu độc lập (scipy.ndimage.label + dilate
vuông) từng điểm ảnh. THỬ ÂM TÍNH: cách "ngây thơ" (xoá mọi mảnh nhỏ, không xét khoảng cách tới chữ) phải làm mất dấu thanh - nếu không, bài kiểm
không phân biệt được cách an toàn với cách phá chữ.
PHẦN B - các phép số của ManualAdjust (đối chiếu OpenCV-Python/numpy): đồng nhất, điểm giữa 128 đứng yên khi chỉ đổi tương phản, độ sáng đơn điệu,
bão hòa -100 = xám, làm nét tăng độ gắt cạnh và không đổi vùng phẳng, alpha giữ 255.
Chạy: python3 manual_adjust_check.py   (cần java 11+, scipy, opencv-python, pillow)
"""
import os, struct, subprocess, sys, random
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont
from scipy import ndimage
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
HERE = os.path.dirname(os.path.abspath(__file__))
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
    return cond

# ---- hằng số phản chiếu Despeckle.kt / ManualAdjust.kt (doc_sync_check so khớp) ----
REF_EDGE = 1500; LEVEL_AREA = [0, 6, 16, 36]; GAP_FACTOR = 0.8; INK_DIFF = 40.0

def max_area(level, edge):
    l = max(0, min(3, level))
    if l == 0: return 0
    s = edge / REF_EDGE
    return max(1, int(np.floor(LEVEL_AREA[l] * s * s + 0.5)))

def ink_mask(gray):
    """Giống ManualAdjust.despeckleInPlace: mực = tối hơn mức giấy cục bộ (giãn xám elip) hơn INK_DIFF."""
    edge = max(gray.shape)
    r = max(3, edge // 250)
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1))
    bg = cv2.dilate(gray, k)
    diff = cv2.subtract(bg, gray)
    return (diff > INK_DIFF).astype(np.uint8)

def reference_specks(ink, level):
    """Bản tham chiếu ĐỘC LẬP: scipy label 8-liên thông, giãn vuông bằng scipy, không dùng mã Java."""
    edge = max(ink.shape)
    ma = max_area(level, edge)
    if ma <= 0: return np.zeros_like(ink)
    lab, n = ndimage.label(ink, structure=np.ones((3, 3)))
    areas = np.bincount(lab.ravel(), minlength=n + 1)
    objs = ndimage.find_objects(lab)
    heights = [0] + [(o[0].stop - o[0].start) for o in objs]
    big = [i for i in range(1, n + 1) if areas[i] > ma]
    glyph = max(8.0, edge / 100.0) if not big else float(sorted(heights[i] for i in big)[len(big) // 2])
    gap = max(2, int(np.floor(GAP_FACTOR * glyph + 0.5)))
    bigmask = np.isin(lab, big).astype(np.uint8) if big else np.zeros_like(ink)
    near = ndimage.maximum_filter(bigmask, size=2 * gap + 1, mode="constant", cval=0)
    prot = set(np.unique(lab[(near > 0) & (lab > 0)]).tolist())
    out = np.zeros_like(ink)
    for i in range(1, n + 1):
        if areas[i] <= ma and i not in prot: out[lab == i] = 1
    return out

def run_java(ink, level):
    h, w = ink.shape
    fin = os.path.join(OUT, "ma_in.bin"); fout = os.path.join(OUT, "ma_out.bin")
    with open(fin, "wb") as f:
        f.write(struct.pack(">iiii", w, h, level, max(w, h))); f.write(ink.astype(np.uint8).tobytes())
    subprocess.run(["java", os.path.join(HERE, "ManualAdjustCheck.java"), fin, fout], check=True)
    return np.frombuffer(open(fout, "rb").read(), dtype=np.uint8).reshape(h, w)

TEXT = ["Cộng hoà xã hội chủ nghĩa Việt Nam, độc lập – tự do – hạnh phúc.",
        "Hợp đồng thuê nhà số 12/2026: bên A giao nhà, bên B nhận nhà ngày 05/10.",
        "Nguyễn Thị Thuỳ Dương, Trần Quốc Việt; điện thoại: 0912 345 678 (di động).",
        "Điều 3. Thời hạn: 12 tháng, kể từ ngày ký; giá thuê: 7.500.000 đồng/tháng.",
        "Ghi chú: ảnh chụp bằng điện thoại, có đủ ý, ổ, ẩ, ữ, ự, ặ, ẫ, ỵ, ỷ, ỹ."]

def page(seed):
    rnd = random.Random(seed)
    W, H = 1240, 1754
    img = Image.new("L", (W, H), 255)
    d = ImageDraw.Draw(img)
    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 26)
    y = 160
    for para in range(9):
        for ln in range(rnd.randint(2, 4)):
            d.text((120, y), TEXT[(para + ln) % len(TEXT)], font=font, fill=0); y += 44
        y += 70
    return np.array(img)

def sprinkle(clean, rnd, gap, n=220):
    """Thêm bụi 1-2 px. Trả về (ảnh, bụi xa chữ, bụi sát chữ) với toạ độ."""
    ink0 = (clean < 128).astype(np.uint8)
    dist = ndimage.distance_transform_edt(1 - ink0)
    img = clean.copy(); far, near = [], []
    h, w = clean.shape
    tries = 0
    while (len(far) < n or len(near) < 40) and tries < 20000:
        tries += 1
        x, y = rnd.randrange(8, w - 8), rnd.randrange(8, h - 8)
        d = dist[y, x]
        kind = "far" if d > 1.4 * gap else ("near" if 4 <= d <= 0.5 * gap else None)
        if kind is None or (kind == "far" and len(far) >= n) or (kind == "near" and len(near) >= 40): continue
        sz = rnd.choice([1, 1, 2])
        img[y:y + sz, x:x + sz] = 20
        (far if kind == "far" else near).append((x, y, sz))
    return img, far, near

def naive(ink, level):
    """Cách KHÔNG an toàn: xoá mọi mảnh nhỏ bất kể gần chữ hay không."""
    edge = max(ink.shape); ma = max_area(level, edge)
    lab, n = ndimage.label(ink, structure=np.ones((3, 3)))
    areas = np.bincount(lab.ravel(), minlength=n + 1)
    small = np.where(areas <= ma)[0]; small = small[small > 0]
    return np.isin(lab, small).astype(np.uint8)

print("== A. khử đốm ==")
clean = page(1)
ink_clean = ink_mask(clean)
lab_c, n_c = ndimage.label(ink_clean, structure=np.ones((3, 3)))
areas_c = np.bincount(lab_c.ravel())[1:]
check(n_c > 800, f"trang chữ dựng có {n_c} mảnh mực (đủ dấu thanh, chấm i)")
tone_like = int(((areas_c > 1) & (areas_c <= max_area(3, 1754))).sum())
check(tone_like > 30, f"có {tone_like} mảnh nhỏ thật của chữ (dấu thanh, chấm i, dấu chấm) nằm trong dải khử đốm mức 3")
rnd = random.Random(7)
glyph_h = sorted(o[0].stop - o[0].start for o in ndimage.find_objects(lab_c))[len(areas_c) // 2]
for level in (1, 2, 3):
    ma = max_area(level, 1754)
    big_h = [o[0].stop - o[0].start for o, a in zip(ndimage.find_objects(lab_c), areas_c) if a > ma]
    gap = max(2, int(np.floor(GAP_FACTOR * sorted(big_h)[len(big_h) // 2] + 0.5)))
    noisy, far, near = sprinkle(clean, random.Random(level), gap)
    ink = ink_mask(noisy)
    got = run_java(ink, level)
    ref = reference_specks(ink, level)
    check(np.array_equal(got, ref), f"mức {level}: bản Java = bản tham chiếu scipy từng điểm ảnh ({int(got.sum())} điểm ảnh đốm)")
    removed_far = sum(1 for (x, y, s) in far if got[y:y + s, x:x + s].any())
    check(removed_far == len(far), f"mức {level}: {removed_far}/{len(far)} bụi xa chữ bị xoá")
    kept_near = sum(1 for (x, y, s) in near if not got[y:y + s, x:x + s].any())
    check(kept_near == len(near), f"mức {level}: {kept_near}/{len(near)} bụi sát chữ được giữ (bảo vệ)")
    touched = int((got.astype(bool) & ink_clean.astype(bool)).sum())
    check(touched == 0, f"mức {level}: 0 điểm ảnh chữ thật bị xoá (kể cả dấu thanh)")
    if level == 3:
        nv = naive(ink, level)
        lost = int((nv.astype(bool) & ink_clean.astype(bool)).sum())
        check(lost > 0, f"thử âm tính: cách ngây thơ làm mất {lost} điểm ảnh chữ (dấu thanh/chấm) - bài kiểm bắt được cách phá chữ")
check(not run_java(ink_mask(noisy), 0).any(), "mức 0: không xoá gì")
empty = np.zeros((300, 200), np.uint8)
check(not run_java(empty, 3).any(), "trang trống: không lỗi, không đốm")
only_dust = np.zeros((1000, 1500), np.uint8); only_dust[50, 50] = 1; only_dust[200:202, 100:102] = 1   # 1500 px = cạnh tham chiếu: ngưỡng mức 3 = 36 điểm ảnh
check(run_java(only_dust, 3).sum() == 5, "trang chỉ có bụi (không có chữ): bụi bị xoá, không lỗi chia cho 0")

print("== B. ManualAdjust: phép số ==")
def alpha(c): return 1.0 + min(c, 100) / 50.0 if c >= 0 else 1.0 + max(c, -100) / 100.0
def beta(b, a): return 128.0 - 128.0 * a + max(-100, min(100, b)) * 1.28
def adjust(rgb, b=0, c=0, s=0, k=0):
    out = rgb.copy()
    if b or c:
        a = alpha(c); out = cv2.convertScaleAbs(out, alpha=a, beta=beta(b, a))
    if s:
        hsv = cv2.cvtColor(out, cv2.COLOR_RGB2HSV); hsv[..., 1] = cv2.convertScaleAbs(hsv[..., 1], alpha=1.0 + max(-100, min(100, s)) / 100.0)
        out = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
    if k:
        edge = max(out.shape[:2]); sig = max(0.8, edge / 1500.0); am = k / 50.0
        out = cv2.addWeighted(out, 1 + am, cv2.GaussianBlur(out, (0, 0), sig), -am, 0)
    return out
rng = np.random.default_rng(3)
img = rng.integers(0, 256, (200, 300, 3), dtype=np.uint8)
check(np.array_equal(adjust(img), img), "tất cả thanh = 0: ảnh không đổi")
grey = np.full((10, 10, 3), 128, np.uint8)
check(all(np.array_equal(adjust(grey, c=c), grey) for c in (-100, -40, 40, 100)), "chỉ đổi tương phản: điểm giữa 128 đứng yên")
m = [adjust(img, b=b).mean() for b in (-100, -50, 0, 50, 100)]
check(all(m[i] < m[i + 1] for i in range(4)), "độ sáng đơn điệu: " + " < ".join(f"{v:.0f}" for v in m))
col = np.zeros((20, 20, 3), np.uint8); col[..., 0] = 200; col[..., 1] = 60; col[..., 2] = 40
g = adjust(col, s=-100)
check((g[..., 0] == g[..., 1]).all() and (g[..., 1] == g[..., 2]).all(), "bão hòa -100 cho ảnh xám (R=G=B)")
s_of = lambda a: cv2.cvtColor(a, cv2.COLOR_RGB2HSV)[..., 1].mean()
check(s_of(adjust(col, s=50)) > s_of(col) > s_of(adjust(col, s=-50)), "bão hòa tăng/giảm đúng chiều")
step = np.zeros((100, 200, 3), np.uint8); step[:, 100:] = 200
sh = adjust(step, k=100)
gm = lambda a: np.abs(np.diff(a[50, :, 0].astype(int))).max()
check(sh[50, 20, 0] == 0 and sh[50, 180, 0] == 200 and gm(sh) >= gm(step), "làm nét: vùng phẳng không đổi, cạnh không mềm đi")
check(sh[50, 96, 0] < 0 + 1 or sh[50, 103, 0] > 200 - 1, "làm nét tạo quầng nhẹ ở cạnh (đúng bản chất unsharp mask)")
check(alpha(0) == 1.0 and alpha(100) == 3.0 and alpha(-100) == 0.0 and alpha(-50) == 0.5, "hệ số tương phản: 1, 3, 0, 0.5")
print()
print("TAT CA DAT" if not FAILS else f"CO {len(FAILS)} LOI: " + "; ".join(FAILS))
sys.exit(1 if FAILS else 0)
