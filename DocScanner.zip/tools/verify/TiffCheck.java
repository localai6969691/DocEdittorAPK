// Bản Java chạy được của TiffWriter (phiên 19, mục 4.47.4): cùng bố cục tệp, cùng thứ tự ghi với app/.../util/TiffWriter.kt. Dùng bởi tiff_check.py.
//   java TiffCheck.java <tệp mô tả trang> <tệp TIFF ra>
// mỗi dòng mô tả một trang: "<G4|GRAY|RGB>\t<rộng>\t<cao>\t<dpi>\t<dữ liệu hex>"  (G4: luồng Group 4 đã mã hoá; GRAY / RGB: mẫu thô)
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.zip.Deflater;

public class TiffCheck {
    static byte[] le(long v, int n) { byte[] b = new byte[n]; for (int i = 0; i < n; i++) b[i] = (byte) ((v >> (8 * i)) & 0xFF); return b; }
    static void writeLe(ByteArrayOutputStream o, long v, int n) { byte[] b = le(v, n); o.write(b, 0, b.length); }
    static byte[] predictor(byte[] raw, int width, int height, int samples) {
        byte[] out = raw.clone(); int rowBytes = width * samples;
        for (int y = 0; y < height; y++) { int base = y * rowBytes; for (int i = rowBytes - 1; i >= samples; i--) out[base + i] = (byte) (raw[base + i] - raw[base + i - samples]); }
        return out;
    }
    static byte[] deflate(byte[] data) { Deflater d = new Deflater(6); d.setInput(data); d.finish(); ByteArrayOutputStream o = new ByteArrayOutputStream(); byte[] buf = new byte[65536]; while (!d.finished()) { int n = d.deflate(buf); o.write(buf, 0, n); } d.end(); return o.toByteArray(); }

    static RandomAccessFile raf; static long lastNextPointerAt = 4;
    static long alignedEnd() throws IOException { long end = raf.length(); if (end % 2 == 1) { raf.seek(end); raf.write(0); end++; } return end; }

    static void add(String kind, int width, int height, int dpi, byte[] data) throws IOException {
        byte[] strip = kind.equals("G4") ? data : deflate(predictor(data, width, height, kind.equals("RGB") ? 3 : 1));
        int samples = kind.equals("RGB") ? 3 : 1;
        if (!kind.equals("G4") && data.length != width * height * samples) throw new IllegalArgumentException("raw size");
        long stripAt = alignedEnd(); raf.seek(stripAt); raf.write(strip);
        long extraBase = alignedEnd();
        List<long[]> entries = new ArrayList<>();
        int entryCount = kind.equals("G4") ? 13 : 14; long ifdSize = 2L + entryCount * 12 + 4, extraStart = extraBase + ifdSize;
        int bits = kind.equals("G4") ? 1 : 8; int photometric = kind.equals("G4") ? 1 : (kind.equals("GRAY") ? 1 : 2); int compression = kind.equals("G4") ? 4 : 8;
        ByteArrayOutputStream extraBytes = new ByteArrayOutputStream(); long bitsValue = bits; int bitsCount = 1;
        if (samples == 3) { bitsCount = 3; bitsValue = extraStart + extraBytes.size(); for (int i = 0; i < 3; i++) { extraBytes.write(bits & 0xFF); extraBytes.write(0); } }
        long xResAt = extraStart + extraBytes.size();
        for (int i = 0; i < 2; i++) { writeLe(extraBytes, dpi, 4); writeLe(extraBytes, 1, 4); }
        long yResAt = xResAt + 8;
        entries.add(new long[]{256, 4, 1, width}); entries.add(new long[]{257, 4, 1, height}); entries.add(new long[]{258, 3, bitsCount, bitsValue}); entries.add(new long[]{259, 3, 1, compression});
        entries.add(new long[]{262, 3, 1, photometric}); entries.add(new long[]{273, 4, 1, stripAt}); entries.add(new long[]{277, 3, 1, samples}); entries.add(new long[]{278, 4, 1, height});
        entries.add(new long[]{279, 4, 1, strip.length}); entries.add(new long[]{282, 5, 1, xResAt}); entries.add(new long[]{283, 5, 1, yResAt}); entries.add(new long[]{284, 3, 1, 1});
        entries.add(new long[]{296, 3, 1, 2}); if (!kind.equals("G4")) entries.add(new long[]{317, 3, 1, 2});
        ByteArrayOutputStream ifd = new ByteArrayOutputStream(); writeLe(ifd, entries.size(), 2);
        for (long[] e : entries) { writeLe(ifd, e[0], 2); writeLe(ifd, e[1], 2); writeLe(ifd, e[2], 4); if (e[1] == 3 && e[2] == 1) { writeLe(ifd, e[3], 2); writeLe(ifd, 0, 2); } else writeLe(ifd, e[3], 4); }
        writeLe(ifd, 0, 4);
        if (entries.size() != entryCount || ifd.size() != ifdSize) throw new IllegalStateException("IFD size");
        raf.seek(extraBase); raf.write(ifd.toByteArray()); raf.write(extraBytes.toByteArray());
        raf.seek(lastNextPointerAt); raf.write(le(extraBase, 4));
        lastNextPointerAt = extraBase + 2 + entries.size() * 12L;
    }
    static byte[] unhex(String h) { byte[] b = new byte[h.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return b; }
    public static void main(String[] a) throws Exception {
        raf = new RandomAccessFile(a[1], "rw"); raf.setLength(0);
        raf.write(new byte[]{'I', 'I', 42, 0, 0, 0, 0, 0});
        for (String ln : Files.readAllLines(Paths.get(a[0]), StandardCharsets.UTF_8)) {
            if (ln.isEmpty()) continue; String[] p = ln.split("\t", -1);
            add(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]), unhex(p[4]));
        }
        raf.close();
    }
}
