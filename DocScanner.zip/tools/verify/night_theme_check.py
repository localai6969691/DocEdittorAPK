"""Kiểm chứng giao diện tối (phiên 16): values-night/colors.xml + values-night/themes.xml.

Vấn đề: theme gốc là Theme.Material3.DayNight nhưng KHÔNG có màu ban đêm. Trên máy bật chế độ tối, widget không đặt màu chữ (EditText, hộp thoại) chuyển sang chữ
SÁNG trong khi nền cửa sổ vẫn là @color/background (sáng) - chữ trắng trên nền sáng. Cách sửa: bảng màu ban đêm + theme ban đêm cùng tên (chỉ thắng khi máy ở chế độ tối,
nên giao diện ban ngày không đổi).
Kiểm: (1) mọi tên màu của values/ có trong values-night/ (thiếu = rơi về màu sáng); (2) theme ban đêm có đủ mọi mục của theme ban ngày + 4 mục mới; (3) tỉ lệ tương phản WCAG:
chữ chính / chữ phụ trên nền và trên mặt phẳng >= 4,5 (AA chữ nhỏ), chữ trắng trên màu chính >= 4,5, chữ đỏ báo lỗi trên nền >= 3 (chữ lớn/biểu tượng), màu chính tách khỏi nền tối;
(4) BAN NGÀY cũng đạt: trước phiên 16 chữ phụ #757575 trên nền #F5F5F5 chỉ 4,23 (< 4,5) và bị dùng 63 lần; (5) mọi layout chỉ dùng tên màu có trong cả hai bảng.
Thử âm tính: tự tính lại với màu cũ #757575 phải bị bắt.
"""
import os, re, sys, glob
import xml.etree.ElementTree as ET
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
RES = os.path.join(ROOT, "app/src/main/res")
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
    return cond
def colors(path):
    return {c.get("name"): c.text.strip() for c in ET.parse(path).getroot().findall("color")}
day, night = colors(f"{RES}/values/colors.xml"), colors(f"{RES}/values-night/colors.xml")
def lum(h):
    h = h.lstrip("#"); h = h[-6:]
    r, g, b = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)
def ratio(a, b):
    la, lb = lum(a), lum(b)
    return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)

check(set(day) <= set(night), f"mọi màu của values/ có trong values-night/ (thiếu: {sorted(set(day) - set(night))})")
def theme_items(path, name):
    for st in ET.parse(path).getroot().findall("style"):
        if st.get("name") == name:
            return st.get("parent"), {i.get("name") for i in st.findall("item")}
    return None, set()
dp, di = theme_items(f"{RES}/values/themes.xml", "Theme.DocScanner")
np_, ni = theme_items(f"{RES}/values-night/themes.xml", "Theme.DocScanner")
check(dp == np_ and dp is not None, f"theme ban đêm cùng theme cha với ban ngày ({dp})")
check(di <= ni, f"theme ban đêm có đủ mọi mục của ban ngày (thiếu: {sorted(di - ni)})")
need = {"android:colorBackground", "android:textColorPrimary", "android:textColorSecondary", "colorSurface", "colorOnSurface"}
check(need <= ni, f"theme ban đêm đặt màu cho widget không có màu riêng (thiếu: {sorted(need - ni)})")

for label, pal in (("ĐÊM", night), ("NGÀY", day)):
    bg, sf = pal["background"], pal["surface"]
    check(ratio(pal["text_primary"], bg) >= 7, f"{label}: chữ chính / nền = {ratio(pal['text_primary'], bg):.2f} (>= 7, WCAG AAA)")
    check(ratio(pal["text_primary"], sf) >= 7, f"{label}: chữ chính / mặt phẳng = {ratio(pal['text_primary'], sf):.2f} (>= 7, WCAG AAA)")
    check(ratio(pal["text_secondary"], bg) >= 7, f"{label}: chữ phụ / nền = {ratio(pal['text_secondary'], bg):.2f} (>= 7, WCAG AAA)")
    check(ratio(pal["text_secondary"], sf) >= 7, f"{label}: chữ phụ / mặt phẳng = {ratio(pal['text_secondary'], sf):.2f} (>= 7, WCAG AAA)")
    check(ratio(pal["on_primary"], pal["primary"]) >= 4.5, f"{label}: chữ trắng / màu chính = {ratio(pal['on_primary'], pal['primary']):.2f} (>= 4.5)")
    check(ratio(pal["danger"], bg) >= 3, f"{label}: màu báo lỗi / nền = {ratio(pal['danger'], bg):.2f} (>= 3)")
check(ratio(night["primary"], night["background"]) >= 1.5, f"ĐÊM: màu chính tách khỏi nền tối ({ratio(night['primary'], night['background']):.2f} >= 1.5)")
check(ratio(night["on_primary"], night["primary_dark"]) >= 4.5, "ĐÊM: chữ trắng trên thanh trạng thái (primary_dark) đọc được")

used = set()
for f in glob.glob(f"{RES}/layout/*.xml") + glob.glob(f"{RES}/drawable/*.xml"):
    used |= set(re.findall(r"@color/([a-z_0-9]+)", open(f, encoding="utf-8").read()))
check(used <= set(day) and used <= set(night), f"mọi @color/ mà layout/drawable dùng có trong cả hai bảng (thiếu: {sorted(used - set(day) - set(night))})")
# thử âm tính: màu chữ phụ cũ không đạt
check(ratio("#757575", "#F5F5F5") < 7, f"thử âm tính: #757575 trên #F5F5F5 = {ratio('#757575', '#F5F5F5'):.2f} < 4.5 — bài kiểm này phát hiện được lỗi cũ")
print("\nTAT CA DAT" if not FAILS else f"\nCO {len(FAILS)} LOI")
sys.exit(1 if FAILS else 0)
