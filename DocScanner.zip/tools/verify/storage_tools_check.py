"""Kiểm chứng StorageTools (phiên 18): báo cáo dung lượng, tìm tài liệu trùng, ghi đè trước khi xoá.

StorageToolsCheck.java là bản Java chạy được của util/StorageTools.kt. Mọi kết quả được so với bản tham chiếu ĐỘC LẬP viết bằng Python (os.walk + hashlib):
A - tìm trùng: cây thư mục dựng ngẫu nhiên (nhóm trùng nhiều cỡ từ 1 byte đến 300 KB, tệp CÙNG cỡ + CÙNG 64 KB đầu nhưng khác phần cuối, tệp cùng cỡ khác nội dung,
    tệp rỗng, tệp .part, thư mục lồng nhau); 60 cây ngẫu nhiên khớp tham chiếu. THỬ ÂM TÍNH: bản chỉ so 64 KB đầu gộp nhầm các tệp gần giống và bị bắt.
B - báo cáo: tổng số tệp/byte, từng loại, 5 tệp lớn nhất (đồng hạng xếp theo tên) khớp tham chiếu.
B2 - tệp .txt nằm cạnh .pdf cùng tên (lớp chữ OCR) bị loại khỏi cả báo cáo lẫn tìm trùng.
C - ghi đè: sau overwrite độ dài không đổi và không còn đoạn 16 byte nào của nội dung cũ; wipe thì tệp biến mất; tệp không có / thư mục trả false.
Chạy: python3 storage_tools_check.py   (cần java 11+)
"""
import hashlib, os, random, shutil, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
FAILS = []
def check(c, w):
    print(("ok  " if c else "LOI"), w)
    if not c: FAILS.append(w)
def java(*a):
    r = subprocess.run(["java", os.path.join(HERE, "StorageToolsCheck.java"), *map(str, a)], capture_output=True, text=True)
    if r.returncode != 0: print(r.stderr[-800:])
    return r.stdout.rstrip("\n").split("\n") if r.stdout.strip() else []
tmp = tempfile.mkdtemp(prefix="storage_")
def files_of(root):
    out = []
    for d, _, fs in os.walk(root):
        for f in fs:
            q = os.path.join(d, f)
            if f.endswith(".part"): continue
            if f.lower().endswith(".txt") and os.path.isfile(q[:-4] + ".pdf"): continue   # lớp chữ OCR đi cùng PDF
            out.append(q)
    return out
def ref_groups(root):
    by = {}
    for p in files_of(root):
        if os.path.getsize(p) == 0: continue
        h = hashlib.sha256(open(p, "rb").read()).hexdigest(); by.setdefault(h, []).append(p)
    return sorted(sorted(g) for g in by.values() if len(g) >= 2)
def build_tree(root, rnd):
    os.makedirs(root)
    n = 0
    def put(rel, data, mtime=None):
        nonlocal n
        p = os.path.join(root, rel); os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "wb").write(data)
        t = mtime if mtime is not None else 1_700_000_000 + rnd.randint(0, 10_000); os.utime(p, (t, t)); n += 1
    sizes = [1, 2, 7, 100, 4096, 65535, 65536, 65537, 70_000, 300_000]
    for gi in range(rnd.randint(2, 6)):
        data = rnd.randbytes(rnd.choice(sizes))
        for k in range(rnd.randint(2, 4)): put(f"{rnd.choice(['a','b/c','b/d/e'])}/dup{gi}_{k}.{rnd.choice(['pdf','epub','txt'])}", data)
    big = rnd.randbytes(100_000)                       # gần giống: cùng cỡ, cùng 64 KB đầu, khác cuối
    put("near/x.pdf", big); put("near/y.pdf", big[:-1] + bytes([big[-1] ^ 1])); put("near/z.pdf", big)
    sz = rnd.choice(sizes); put("same/p.bin", rnd.randbytes(sz)); put("same/q.bin", rnd.randbytes(sz))   # cùng cỡ, khác nội dung
    put("empty/e1.txt", b""); put("empty/e2.txt", b"")
    put("skip/a.pdf.part", b"partial"); put("skip/b.pdf.part", b"partial")
    put("solo/one.docx", rnd.randbytes(33))
    sc = rnd.randbytes(500); put("sc/a.pdf", sc); put("sc/a.txt", sc)              # .txt cạnh .pdf cùng tên = lớp chữ OCR, KHÔNG phải bản trùng
    put("sc/alone.txt", sc)                                                          # .txt không có .pdf cùng tên là tài liệu thật (cùng byte với a.pdf -> hai tệp này là một nhóm trùng)
    return n
rnd = random.Random(2026)
bad = 0; neg_caught = 0
roots = []
for t in range(60):
    root = os.path.join(tmp, f"t{t}"); build_tree(root, rnd); roots.append(root)
open(os.path.join(tmp, "roots.txt"), "w").write("\n".join(roots) + "\n")
def batch(mode):
    r = subprocess.run(["java", os.path.join(HERE, "StorageToolsCheck.java"), "dupbatch", os.path.join(tmp, "roots.txt"), mode], capture_output=True, text=True)
    if r.returncode != 0: print(r.stderr[-800:])
    out, cur = [], []
    for l in r.stdout.split("\n")[:-1]:
        if l == "===": out.append(sorted(sorted(x.split("\t")) for x in cur)); cur = []
        else: cur.append(l)
    return out
full_res, head_res = batch("full"), batch("head")
for t, root in enumerate(roots):
    if full_res[t] != ref_groups(root): bad += 1; print("  khác ở cây", t)
    if head_res[t] != ref_groups(root): neg_caught += 1
check(bad == 0, "tìm trùng: 60 cây ngẫu nhiên khớp tham chiếu độc lập (hashlib toàn bộ nội dung)")
check(neg_caught == 60, f"thử âm tính: bản chỉ so 64 KB đầu gộp nhầm tệp gần giống ở {neg_caught}/60 cây (bị bắt)")
# thứ tự trong nhóm: cũ nhất đứng đầu
root = os.path.join(tmp, "ord"); os.makedirs(root)
for name, t in (("new.pdf", 300), ("old.pdf", 100), ("mid.pdf", 200)):
    p = os.path.join(root, name); open(p, "wb").write(b"same bytes"); os.utime(p, (1_700_000_000 + t,) * 2)
g = java("dup", root)[0].split("\t")
check([os.path.basename(x) for x in g] == ["old.pdf", "mid.pdf", "new.pdf"], "trong nhóm trùng: bản CŨ NHẤT đứng đầu (giữ lại), các bản mới hơn là ứng viên xoá")
check(java("dup", os.path.join(tmp, "khong_co")) == [], "thư mục không tồn tại -> không có nhóm, không lỗi")

root = os.path.join(tmp, "t0")
rep = java("report", root, 5)
fs = files_of(root); total = sum(os.path.getsize(p) for p in fs)
check(rep[0] == f"total\t{len(fs)}\t{total}", f"báo cáo: tổng {len(fs)} tệp / {total} byte khớp os.walk")
cat = {}
ext2cat = {"pdf": "pdf", "epub": "epub", "txt": "text", "md": "text", "html": "text", "htm": "text", "docx": "office", "xlsx": "office", "pptx": "office", "jpg": "image", "jpeg": "image", "png": "image", "webp": "image"}
for p in fs:
    c = ext2cat.get(p.rsplit(".", 1)[-1].lower(), "other") if "." in os.path.basename(p) else "other"
    s = cat.setdefault(c, [0, 0]); s[0] += 1; s[1] += os.path.getsize(p)
got = {l.split("\t")[1]: [int(l.split("\t")[2]), int(l.split("\t")[3])] for l in rep if l.startswith("cat\t")}
check(got == cat and sum(v[1] for v in got.values()) == total, f"báo cáo: từng loại khớp ({sorted(cat)}), cộng lại đúng tổng")
top = sorted(fs, key=lambda p: (-os.path.getsize(p), os.path.basename(p)))[:5]
check([l.split("\t")[1] for l in rep if l.startswith("top\t")] == [os.path.basename(p) for p in top], "báo cáo: 5 tệp lớn nhất đúng thứ tự (đồng hạng theo tên)")

print("== C. ghi đè / xoá sạch ==")
p = os.path.join(tmp, "secret.bin"); orig = random.Random(5).randbytes(200_000) + b"MAT-KHAU-SIEU-NHAY-1234567890" * 40
open(p, "wb").write(orig)
check(java("overwrite", p) == ["true"], "overwrite báo thành công")
after = open(p, "rb").read()
check(len(after) == len(orig), "độ dài tệp không đổi sau khi ghi đè")
windows = {orig[i:i + 16] for i in range(0, len(orig) - 16, 7)}
check(not any(w in after for w in list(windows)[:4000]) and b"MAT-KHAU" not in after, "không còn đoạn 16 byte nào của nội dung cũ (kể cả chuỗi nhạy cảm)")
open(p, "wb").write(orig)
check(java("wipe", p) == ["true"] and not os.path.exists(p), "wipe: tệp biến mất")
check(java("wipe", os.path.join(tmp, "khong_co.bin")) == ["false"], "wipe tệp không có -> false")
os.makedirs(os.path.join(tmp, "thumuc")); check(java("wipe", os.path.join(tmp, "thumuc")) == ["true"] , "wipe thư mục rỗng: xoá được thư mục rỗng (không ghi đè)")
e = os.path.join(tmp, "empty.bin"); open(e, "wb").close(); check(java("wipe", e) == ["true"] and not os.path.exists(e), "tệp rỗng: xoá được")

print("== D. xoá cả thư mục (chế độ riêng tư) ==")
root = os.path.join(tmp, "priv"); os.makedirs(os.path.join(root, "documents", "sub", "deeper")); os.makedirs(os.path.join(root, "projects", "p1"))
made = []
for rel in ["documents/a.pdf", "documents/a.txt", "documents/sub/b.epub", "documents/sub/deeper/c.bin", "projects/p1/page1.jpg", "projects/p1/page2.jpg", "top.txt"]:
    pth = os.path.join(root, rel); open(pth, "wb").write(random.Random(len(rel)).randbytes(1000 + len(rel))); made.append(pth)
open(os.path.join(root, "documents", "empty.bin"), "wb").close(); made.append(os.path.join(root, "documents", "empty.bin"))
check(java("wipetree", root) == [str(len(made))] and not os.path.exists(root), f"wipeTree: xoá {len(made)} tệp ở nhiều tầng (kể cả tệp rỗng) và biến mất cả thư mục gốc lẫn thư mục con")
check(java("wipetree", os.path.join(tmp, "khong_co")) == ["0"], "wipeTree thư mục không có -> 0, không lỗi")
single = os.path.join(tmp, "one.bin"); open(single, "wb").write(b"x" * 10)
check(java("wipetree", single) == ["1"] and not os.path.exists(single), "wipeTree trên một tệp lẻ: xoá tệp đó")
shutil.rmtree(tmp, ignore_errors=True)
print("\nTAT CA DAT" if not FAILS else f"\n{len(FAILS)} LOI"); sys.exit(1 if FAILS else 0)
