"""PAdES-B-LT: cập nhật tăng dần thêm /DSS sau chữ ký (`PdfLtv.kt`; phiên 23, 4.51) kiểm bằng PDF ký THẬT + `pdfsig` + `qpdf` + `pikepdf`.
Đây là kiểm CẤU TRÚC của bản cập nhật mà `PdfLtv.kt` nhờ PdfBox ghi (`setItem(DSS)` + `setNeedToBeUpdated` + `saveIncremental`): bản cập nhật được dựng tay theo đúng cấu trúc đó
(catalog ghi lại có /DSS, các luồng DER, từ điển /DSS có /Certs /OCSPs /CRLs). KHÔNG chạy PdfBox (xem 4.51 "CHƯA kiểm").
  A. PDF ký thật (CMS của CmsCheck.java): `pdfsig` báo hợp lệ TRƯỚC; sau khi nối /DSS vẫn HỢP LỆ; byte của tệp gốc còn nguyên ở đầu tệp mới; /Contents không đổi.
  B. `qpdf --check` không lỗi; pikepdf đọc được /Root/DSS với đúng số phần tử và đúng byte DER của từng luồng.
  C. Chứng nhận DocMDP mức 1 (không cho sửa): bản cập nhật chỉ có /DSS vẫn được pdfsig chấp nhận như chữ ký hợp lệ.
  D. Ghi LẦN HAI (chữ ký thứ hai rồi DSS thứ hai): DSS mới phải mang theo các mục cũ (quy tắc của đặc tả: DSS mới thay DSS cũ), cả hai chữ ký còn hợp lệ.
  E. Đối chứng: ghi lại CẢ TỆP bằng pikepdf (không tăng dần) làm chữ ký MẤT hiệu lực - đó là lý do phải dùng saveIncremental.
Chạy: python3 ltv_pdf_check.py   (cần pdfsig, qpdf, pikepdf, cryptography, java)"""
import os, shutil, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from signed_pdf_lib import Chain, make_cert, real_cms, pdfsig, append_update
import pikepdf

FAIL = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: FAIL.append(msg)
    return ok

def stream_obj(b): return b"<< /Length %d >>\nstream\n" % len(b) + b + b"\nendstream"

def add_dss(chain, certs, ocsps, crls, old=None):
    """Nối một bản cập nhật /DSS vào chain.pdf. `old` = (certs, ocsps, crls) đã có trong DSS trước đó (được mang theo)."""
    if old:
        certs = old[0] + [c for c in certs if c not in old[0]]; ocsps = old[1] + [c for c in ocsps if c not in old[1]]; crls = old[2] + [c for c in crls if c not in old[2]]
    n = chain.size; objs = {}; refs = {"Certs": [], "OCSPs": [], "CRLs": []}
    for key, blobs in (("Certs", certs), ("OCSPs", ocsps), ("CRLs", crls)):
        for b in blobs:
            objs[n] = stream_obj(b); refs[key].append(n); n += 1
    dss_id = n; n += 1
    parts = [b"/Type /DSS"]
    for key in ("Certs", "OCSPs", "CRLs"):
        if refs[key]: parts.append(b"/" + key.encode() + b" [" + b" ".join(b"%d 0 R" % r for r in refs[key]) + b"]")
    objs[dss_id] = b"<< " + b" ".join(parts) + b" >>"
    fields = b" ".join(b"%d 0 R" % f for f in chain.fields)
    perms = chain.perms if getattr(chain, "perms", None) else b""
    objs[1] = b"<< /Type /Catalog /Pages 2 0 R /AcroForm << /Fields [" + fields + b"] /SigFlags 3 >>" + perms + b" /DSS %d 0 R >>" % dss_id
    new, xref, _ = append_update(chain.pdf, chain.xref, objs, n)
    chain.pdf, chain.xref, chain.size = new, xref, n
    return (certs, ocsps, crls)

def valid(text, count=1):
    return text.count("Signature is Valid") >= count and "Signature is Invalid" not in text and "invalid" not in text.lower().replace("not invalid", "")

tmp = tempfile.mkdtemp(prefix="ltv_")
try:
    make_cert(tmp + "/c")
    cert_der = open(tmp + "/c.der", "rb").read()
    ocsp_fake = b"\x30\x0b\x0a\x01\x00\xa0\x06\x30\x04\x06\x02\x2a\x03" + os.urandom(40)        # el contenido no importa para la estructura
    crl_fake = b"\x30\x82\x00\x10" + os.urandom(16)

    # ---- A, B ----
    c = Chain(); c.add_signature(); c.fill(real_cms(c, tmp, tmp + "/c"))
    open(tmp + "/signed.pdf", "wb").write(c.pdf); before = pdfsig(tmp + "/signed.pdf")
    check(valid(before), "A. PDF ký thật: pdfsig báo HỢP LỆ trước khi nối /DSS")
    orig = c.pdf
    state = add_dss(c, [cert_der, os.urandom(300)], [ocsp_fake], [crl_fake])
    open(tmp + "/ltv.pdf", "wb").write(c.pdf); after = pdfsig(tmp + "/ltv.pdf")
    check(valid(after), "A. sau khi nối /DSS (cập nhật tăng dần) pdfsig VẪN báo hợp lệ")
    check(c.pdf[:len(orig)] == orig, f"A. {len(orig)} byte của tệp đã ký còn NGUYÊN ở đầu tệp mới (chỉ nối thêm {len(c.pdf) - len(orig)} byte)")
    q = subprocess.run(["qpdf", "--check", tmp + "/ltv.pdf"], capture_output=True, text=True)
    check(q.returncode == 0 and "No syntax or stream encoding errors" in q.stdout, "B. qpdf --check: không lỗi cú pháp / luồng")
    with pikepdf.open(tmp + "/ltv.pdf") as pdf:
        dss = pdf.Root.DSS
        ok = (len(dss.Certs) == 2 and len(dss.OCSPs) == 1 and len(dss.CRLs) == 1 and dss.Type == "/DSS"
              and bytes(dss.Certs[0].read_bytes()) == cert_der and bytes(dss.OCSPs[0].read_bytes()) == ocsp_fake and bytes(dss.CRLs[0].read_bytes()) == crl_fake)
        check(ok, "B. pikepdf đọc /Root/DSS: 2 chứng thư, 1 OCSP, 1 CRL, mỗi luồng đúng từng byte")
        check("/AcroForm" in pdf.Root and len(pdf.Root.AcroForm.Fields) == 1, "B. phần còn lại của catalog (AcroForm / ô chữ ký) giữ nguyên")

    # ---- C: DocMDP mức 1 ----
    c1 = Chain(); c1.add_signature(certify=1); c1.fill(real_cms(c1, tmp, tmp + "/c", "c1.bin"))
    c1.perms = b" /Perms << /DocMDP %d 0 R >>" % (c1.size - 2)
    open(tmp + "/m1.pdf", "wb").write(c1.pdf); b1 = pdfsig(tmp + "/m1.pdf")
    add_dss(c1, [cert_der], [ocsp_fake], [])
    open(tmp + "/m1ltv.pdf", "wb").write(c1.pdf); a1 = pdfsig(tmp + "/m1ltv.pdf")
    check(valid(b1) and valid(a1), "C. chứng nhận DocMDP mức 1: chữ ký hợp lệ trước và SAU khi nối /DSS")
    print("     (pdfsig sau DSS:", " | ".join(l.strip() for l in a1.splitlines() if "Signature is" in l or "modif" in l.lower() or "Total document" in l)[:240], ")")

    # ---- D: ghi lần hai ----
    c2 = Chain(); c2.add_signature(); c2.fill(real_cms(c2, tmp, tmp + "/c", "d1.bin"))
    st = add_dss(c2, [cert_der], [ocsp_fake], [])
    c2.add_signature(); c2.fill(real_cms(c2, tmp, tmp + "/c", "d2.bin"))
    extra_ocsp = b"\x30\x03\x0a\x01\x00" + os.urandom(20)
    add_dss(c2, [cert_der], [extra_ocsp], [crl_fake], old=st)
    open(tmp + "/two.pdf", "wb").write(c2.pdf); t = pdfsig(tmp + "/two.pdf")
    with pikepdf.open(tmp + "/two.pdf") as pdf:
        d = pdf.Root.DSS
        keep = len(d.Certs) == 1 and len(d.OCSPs) == 2 and bytes(d.OCSPs[0].read_bytes()) == ocsp_fake and bytes(d.OCSPs[1].read_bytes()) == extra_ocsp and len(d.CRLs) == 1
    check(keep, "D. DSS thứ hai mang theo mục cũ (cùng chứng thư không lặp) và thêm mục mới: 1 chứng thư, 2 OCSP, 1 CRL")
    check("Signature #1" in t and "Signature #2" in t and t.count("Signature is Valid") == 2, "D. cả hai chữ ký còn hợp lệ sau DSS thứ hai")

    # ---- E: đối chứng ghi lại cả tệp ----
    with pikepdf.open(tmp + "/signed.pdf") as pdf:
        pdf.save(tmp + "/rewritten.pdf")
    r = pdfsig(tmp + "/rewritten.pdf")
    check("Signature is Valid" not in r, "E. ĐỐI CHỨNG: ghi lại cả tệp bằng pikepdf làm chữ ký MẤT hiệu lực (nên phải dùng cập nhật tăng dần)")
finally:
    shutil.rmtree(tmp, ignore_errors=True)
print()
print("TAT CA DAT" if not FAIL else f"CO {len(FAIL)} LOI")
sys.exit(1 if FAIL else 0)
