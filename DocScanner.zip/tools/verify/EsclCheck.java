// Bản Java chạy được của EsclProtocol + EsclClient (phiên 17): cùng logic, cùng thứ tự với app/.../util/EsclProtocol.kt và EsclClient.kt.
// Dùng bởi escl_check.py.  java EsclCheck.java pure <tệp ca> | scan <base> <thư mục ra> <dpi> <nguồn> <màu> <retryMs> <maxWaitMs>
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import javax.xml.parsers.DocumentBuilderFactory;

public class EsclCheck {
    static final String NS_SCAN = "http://schemas.hp.com/imaging/escl/2011/05/03", NS_PWG = "http://www.pwg.org/schemas/2010/12/sm";
    static final int A4W = 2480, A4H = 3508;
    static class Settings { String source, color, format; int dpi, w, h; boolean duplex; }
    static class Caps { String make; List<Integer> res; boolean platen, feeder; List<String> formats; int platenW, platenH, feederW, feederH; boolean duplex; int feederDW, feederDH; }

    static String settingsXml(Settings s) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<scan:ScanSettings xmlns:pwg=\"" + NS_PWG + "\" xmlns:scan=\"" + NS_SCAN + "\">\n  <pwg:Version>2.0</pwg:Version>\n  <pwg:ScanRegions>\n    <pwg:ScanRegion>\n"
            + "      <pwg:ContentRegionUnits>escl:ThreeHundredthsOfInches</pwg:ContentRegionUnits>\n      <pwg:XOffset>0</pwg:XOffset>\n      <pwg:YOffset>0</pwg:YOffset>\n"
            + "      <pwg:Width>" + s.w + "</pwg:Width>\n      <pwg:Height>" + s.h + "</pwg:Height>\n    </pwg:ScanRegion>\n  </pwg:ScanRegions>\n"
            + "  <pwg:InputSource>" + s.source + "</pwg:InputSource>\n  <scan:ColorMode>" + s.color + "</scan:ColorMode>\n  <scan:XResolution>" + s.dpi + "</scan:XResolution>\n  <scan:YResolution>" + s.dpi + "</scan:YResolution>\n"
            + (s.duplex ? "  <scan:Duplex>true</scan:Duplex>\n" : "")
            + "  <pwg:DocumentFormat>" + s.format + "</pwg:DocumentFormat>\n</scan:ScanSettings>\n";
    }
    static List<String> texts(org.w3c.dom.Document d, String local) {
        org.w3c.dom.NodeList n = d.getElementsByTagNameNS("*", local); List<String> out = new ArrayList<>();
        for (int i = 0; i < n.getLength(); i++) out.add(n.item(i).getTextContent().trim()); return out;
    }
    static Integer toInt(String s) { try { return Integer.parseInt(s); } catch (Exception e) { return null; } }
    static Caps parseCaps(String xml) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance(); f.setNamespaceAware(true);
        org.w3c.dom.Document d = f.newDocumentBuilder().parse(new ByteArrayInputStream(xml.getBytes(StandardCharsets.UTF_8)));
        Caps c = new Caps();
        List<String> mm = texts(d, "MakeAndModel"); c.make = !mm.isEmpty() ? mm.get(0) : (texts(d, "Make").isEmpty() ? "" : texts(d, "Make").get(0));
        TreeSet<Integer> rs = new TreeSet<>();
        for (String t : texts(d, "XResolution")) { Integer v = toInt(t); if (v != null && v >= 50 && v <= 2400) rs.add(v); }
        for (String t : texts(d, "Resolution")) { Integer v = toInt(t); if (v != null && v >= 50 && v <= 2400) rs.add(v); }
        c.res = new ArrayList<>(rs);
        c.formats = new ArrayList<>(); for (String t : texts(d, "DocumentFormat")) if (t.contains("/") && !c.formats.contains(t)) c.formats.add(t);
        c.platen = d.getElementsByTagNameNS("*", "Platen").getLength() > 0; c.feeder = d.getElementsByTagNameNS("*", "Adf").getLength() > 0;
        c.platenW = area(d, "Platen", "MaxWidth", A4W); c.platenH = area(d, "Platen", "MaxHeight", A4H);
        String simplex = d.getElementsByTagNameNS("*", "AdfSimplexInputCaps").getLength() > 0 ? "AdfSimplexInputCaps" : "Adf";
        c.feederW = area(d, simplex, "MaxWidth", A4W); c.feederH = area(d, simplex, "MaxHeight", A4H);
        c.duplex = d.getElementsByTagNameNS("*", "AdfDuplexInputCaps").getLength() > 0; c.feederDW = area(d, "AdfDuplexInputCaps", "MaxWidth", c.feederW); c.feederDH = area(d, "AdfDuplexInputCaps", "MaxHeight", c.feederH); return c;
    }
    static int area(org.w3c.dom.Document d, String container, String local, int fallback) {
        org.w3c.dom.NodeList cs = d.getElementsByTagNameNS("*", container); if (cs.getLength() == 0) return fallback;
        org.w3c.dom.NodeList n = ((org.w3c.dom.Element) cs.item(0)).getElementsByTagNameNS("*", local); if (n.getLength() == 0) return fallback;
        Integer v = toInt(n.item(0).getTextContent().trim()); return v != null ? v : fallback;
    }
    static Settings fit(Caps c, String source, String color, int dpi) { return fit(c, source, color, dpi, false); }
    static Settings fit(Caps c, String source, String color, int dpi, boolean duplex) {
        Settings s = new Settings();
        if (source.equals("Feeder") && c.feeder) s.source = "Feeder"; else if (source.equals("Platen") && c.platen) s.source = "Platen"; else if (c.platen) s.source = "Platen"; else s.source = "Feeder";
        if (c.res.isEmpty()) s.dpi = dpi; else { int best = c.res.get(0); for (int r : c.res) if (Math.abs(r - dpi) < Math.abs(best - dpi)) best = r; s.dpi = best; }
        s.format = (c.formats.isEmpty() || c.formats.contains("image/jpeg")) ? "image/jpeg" : c.formats.get(0);
        s.color = color; boolean fd = s.source.equals("Feeder"); s.duplex = duplex && fd && c.duplex;
        s.w = Math.min(A4W, fd ? (s.duplex ? c.feederDW : c.feederW) : c.platenW); s.h = Math.min(A4H, fd ? (s.duplex ? c.feederDH : c.feederH) : c.platenH); return s;
    }
    static String resolveLocation(String post, String loc) {
        if (loc == null || loc.trim().isEmpty()) return null;
        try { URI u = new URI(post).resolve(loc.trim()); if (u.getScheme() == null || u.getHost() == null) return null; String t = u.toString(); while (t.endsWith("/")) t = t.substring(0, t.length() - 1); return t; } catch (Exception e) { return null; }
    }
    static String baseUrl(String input) {
        String t = input.trim(); if (t.isEmpty()) return null; for (char ch : t.toCharArray()) if (Character.isWhitespace(ch)) return null;
        if (t.startsWith("http://") || t.startsWith("HTTP://")) t = t.substring(7);
        if (t.contains("://")) return null;
        int slash = t.indexOf('/'); String path = slash >= 0 ? trimSlash(t.substring(slash)) : ""; String hp = slash >= 0 ? t.substring(0, slash) : t;
        String host; int port = 80;
        if (hp.startsWith("[")) {
            int close = hp.indexOf(']'); if (close < 0) return null; host = hp.substring(0, close + 1); String rest = hp.substring(close + 1);
            if (!rest.isEmpty()) { if (!rest.startsWith(":")) return null; Integer p = toInt(rest.substring(1)); if (p == null) return null; port = p; }
        } else { int c = hp.lastIndexOf(':'); if (c >= 0) { host = hp.substring(0, c); Integer p = toInt(hp.substring(c + 1)); if (p == null) return null; port = p; } else host = hp; }
        if (host.isEmpty() || port < 1 || port > 65535) return null;
        if (!host.startsWith("[")) for (char ch : host.toCharArray()) if (!(Character.isLetterOrDigit(ch) || ch == '.' || ch == '-')) return null;
        return "http://" + host + ":" + port + "/" + (path.isEmpty() ? "eSCL" : path);
    }
    static String trimSlash(String s) { int a = 0, e = s.length(); while (a < e && s.charAt(a) == '/') a++; while (e > a && s.charAt(e - 1) == '/') e--; return s.substring(a, e); }
    static boolean isPrivate(InetAddress a) {
        byte[] b = a.getAddress();
        if (a instanceof Inet4Address) { int b0 = b[0] & 0xFF, b1 = b[1] & 0xFF; return b0 == 10 || b0 == 127 || (b0 == 172 && b1 >= 16 && b1 <= 31) || (b0 == 192 && b1 == 168) || (b0 == 169 && b1 == 254); }
        if (a instanceof Inet6Address) { int b0 = b[0] & 0xFF, b1 = b[1] & 0xFF; boolean lo = b[15] == 1; for (int i = 0; i < 15; i++) if (b[i] != 0) lo = false; return lo || (b0 == 0xFE && (b1 & 0xC0) == 0x80) || (b0 & 0xFE) == 0xFC; }
        return false;
    }

    // ---- client ----
    static class EsclException extends IOException { String code; EsclException(String c, String m) { super(m); code = c; } }
    static class Resp { int code; String location; byte[] body; }
    static long retryDelay, maxWait;
    static void checkLocal(String url) throws IOException {
        String host = new URL(url).getHost(); if (host.startsWith("[")) host = host.substring(1); if (host.endsWith("]")) host = host.substring(0, host.length() - 1);
        InetAddress[] all; try { all = InetAddress.getAllByName(host); } catch (Exception e) { throw new EsclException("unreachable", "cannot resolve " + host); }
        if (all.length == 0) throw new EsclException("not_local", host);
        for (InetAddress a : all) if (!isPrivate(a)) throw new EsclException("not_local", host + " is not on the local network");
    }
    static Resp call(String method, String url, byte[] body, String ct) throws IOException {
        checkLocal(url);
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod(method); c.setConnectTimeout(8000); c.setReadTimeout(120000); c.setInstanceFollowRedirects(false);
            if (body != null) { c.setDoOutput(true); if (ct != null) c.setRequestProperty("Content-Type", ct); try (OutputStream o = c.getOutputStream()) { o.write(body); } }
            int code = c.getResponseCode(); InputStream st = (code >= 200 && code <= 299) ? c.getInputStream() : c.getErrorStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            if (st != null) try (InputStream s = st) { byte[] buf = new byte[65536]; int n; while ((n = s.read(buf)) >= 0) { out.write(buf, 0, n); if (out.size() > 120L * 1024 * 1024) throw new EsclException("too_big", "response too large"); } }
            Resp r = new Resp(); r.code = code; r.location = c.getHeaderField("Location"); r.body = out.toByteArray(); return r;
        } finally { c.disconnect(); }
    }
    static int scan(String base, Settings s, int maxPages, List<byte[]> pages) throws Exception {
        String postUrl = base + "/ScanJobs";
        Resp post = call("POST", postUrl, settingsXml(s).getBytes(StandardCharsets.UTF_8), "text/xml");
        if (post.code == 503) throw new EsclException("busy", "scanner is busy");
        if (post.code != 201 && post.code != 200 && post.code != 202) throw new EsclException("http_" + post.code, "job refused");
        String job = resolveLocation(postUrl, post.location); if (job == null) throw new EsclException("no_location", "no Location header");
        checkLocal(job);
        int n = 0;
        try {
            long waited = 0;
            while (n < maxPages) {
                Resp r = call("GET", job + "/NextDocument", null, null);
                if (r.code == 200) { pages.add(r.body); n++; waited = 0; }
                else if (r.code == 404) { if (n == 0) throw new EsclException("no_pages", "scanner returned no page"); break; }
                else if (r.code == 503) { if (waited >= maxWait) throw new EsclException("busy", "scanner stayed busy"); Thread.sleep(retryDelay); waited += retryDelay; }
                else throw new EsclException("http_" + r.code, "page request returned " + r.code);
            }
        } finally { try { call("DELETE", job, null, null); } catch (Exception e) { } }
        return n;
    }
    static byte[] unhex(String h) { byte[] b = new byte[h.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return b; }

    public static void main(String[] a) throws Exception {
        if (a[0].equals("pure")) {
            for (String ln : Files.readAllLines(Paths.get(a[1]), StandardCharsets.UTF_8)) {
                String[] p = ln.split("\t", -1);
                switch (p[0]) {
                    case "base": { String r = baseUrl(p[1]); System.out.println(r == null ? "NULL" : r); break; }
                    case "loc": { String r = resolveLocation(p[1], p[2].equals("<null>") ? null : p[2]); System.out.println(r == null ? "NULL" : r); break; }
                    case "priv": System.out.println(isPrivate(InetAddress.getByName(p[1]))); break;
                    case "caps": { Caps c = parseCaps(new String(unhex(p[1]), StandardCharsets.UTF_8)); System.out.println(c.make + "|" + c.res + "|" + c.platen + "|" + c.feeder + "|" + c.formats + "|" + c.platenW + "x" + c.platenH + "|" + c.feederW + "x" + c.feederH); break; }
                    case "fit": { Caps c = parseCaps(new String(unhex(p[1]), StandardCharsets.UTF_8)); Settings s = fit(c, p[2], p[3], Integer.parseInt(p[4])); System.out.println(s.source + "|" + s.dpi + "|" + s.format + "|" + s.w + "|" + s.h); break; }
                    case "caps2": { Caps c = parseCaps(new String(unhex(p[1]), StandardCharsets.UTF_8)); System.out.println(c.duplex + "|" + c.feederW + "x" + c.feederH + "|" + c.feederDW + "x" + c.feederDH); break; }
                    case "fitd": { Caps c = parseCaps(new String(unhex(p[1]), StandardCharsets.UTF_8)); Settings s = fit(c, p[2], p[3], Integer.parseInt(p[4]), p[5].equals("1")); System.out.println(s.source + "|" + s.dpi + "|" + s.w + "|" + s.h + "|" + s.duplex); break; }
                    case "xmld": { Settings s = new Settings(); s.source = p[1]; s.color = p[2]; s.dpi = Integer.parseInt(p[3]); s.format = p[4]; s.w = Integer.parseInt(p[5]); s.h = Integer.parseInt(p[6]); s.duplex = p[7].equals("1"); System.out.println(settingsXml(s).replace("\n", "\\n")); break; }
                    case "xml": { Settings s = new Settings(); s.source = p[1]; s.color = p[2]; s.dpi = Integer.parseInt(p[3]); s.format = p[4]; s.w = Integer.parseInt(p[5]); s.h = Integer.parseInt(p[6]); System.out.println(settingsXml(s).replace("\n", "\\n")); break; }
                }
            }
            return;
        }
        retryDelay = Long.parseLong(a[6]); maxWait = Long.parseLong(a[7]);
        try {
            Settings s = fit(parseCaps(new String(call("GET", a[1] + "/ScannerCapabilities", null, null).body, StandardCharsets.UTF_8)), a[4], a[5], Integer.parseInt(a[3]), a.length > 8 && a[8].equals("duplex"));
            List<byte[]> pages = new ArrayList<>(); int n = scan(a[1], s, 100, pages);
            for (int i = 0; i < pages.size(); i++) Files.write(Paths.get(a[2], "page_" + i + ".bin"), pages.get(i));
            System.out.println("OK " + n + " " + s.source + " " + s.dpi);
        } catch (EsclException e) { System.out.println("ERR " + e.code); }
    }
}
