import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Java twin of app/.../util/LinkImport.kt (phiên 22, 4.49.4): same rules, same order, same HttpURLConnection code. Run by link_import_check.py.
 * stdin: one command per line, fields separated by TAB, every text field written as hex UTF-8 (so tabs / newlines / accents survive):
 *   parse  <input> <allowCleartext 0|1>                 -> the normalised URL or "null"
 *   redir  <base> <location> <allowCleartext>           -> the next URL or "null"
 *   sniff  <hexBytes>                                   -> extension or "null"
 *   name   <url> <contentDisposition|-> <ext>           -> file name
 *   disp   <contentDisposition>                         -> proposed name or "null"
 *   dl     <url> <destPath> <maxBytes>                  -> "OK ext name size" or "ERR REASON" (cleartext allowed: the test server is http)
 */
public class LinkImportCheck {
    static final long MAX_BYTES = 100L * 1024 * 1024; static final int MAX_REDIRECTS = 5, MAX_URL_CHARS = 2048, SNIFF_BYTES = 1100, NAME_MAX_CHARS = 80;
    static class LinkException extends IOException { final String reason; LinkException(String r, String m) { super(m == null ? r : m); reason = r; } }

    // ---- ZipPack.entryNames (single name) ----
    static final String FORBID = ":*?\"<>|";
    static String entryName(String raw) {
        String s = raw.substring(raw.lastIndexOf('/') + 1); s = s.substring(s.lastIndexOf('\\') + 1);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) { char c = s.charAt(i); sb.append((c < 32 || FORBID.indexOf(c) >= 0) ? '_' : c); }
        String base = sb.toString().trim();
        while (base.startsWith(".")) base = base.substring(1);
        while (base.endsWith(".")) base = base.substring(0, base.length() - 1);
        return base.isEmpty() ? "file" : base;
    }

    static String encodeIllegal(String s) {
        StringBuilder sb = new StringBuilder(); int i = 0;
        while (i < s.length()) {
            int cp = s.codePointAt(i); i += Character.charCount(cp);
            boolean keep = cp >= 0x21 && cp <= 0x7E && cp != '"' && cp != '<' && cp != '>' && cp != '\\' && cp != '^' && cp != '`' && cp != '{' && cp != '|' && cp != '}';
            if (keep) sb.append((char) cp);
            else for (byte b : new String(Character.toChars(cp)).getBytes(StandardCharsets.UTF_8)) sb.append('%').append("0123456789ABCDEF".charAt((b >> 4) & 15)).append("0123456789ABCDEF".charAt(b & 15));
        }
        return sb.toString();
    }

    static URL parse(String input, boolean allowCleartext) {
        String text = input.trim();
        if (text.isEmpty() || text.length() > MAX_URL_CHARS) return null;
        String lower = text.toLowerCase(Locale.ROOT); int prefixLen;
        if (lower.startsWith("https://")) prefixLen = 8; else if (allowCleartext && lower.startsWith("http://")) prefixLen = 7; else return null;
        String rest = text.substring(prefixLen); int cut = -1;
        for (int i = 0; i < rest.length(); i++) { char c = rest.charAt(i); if (c == '/' || c == '?' || c == '#') { cut = i; break; } }
        String authority = cut < 0 ? rest : rest.substring(0, cut), tail = cut < 0 ? "" : rest.substring(cut);
        if (authority.isEmpty()) return null;
        for (int i = 0; i < authority.length(); i++) { char c = authority.charAt(i); if (c <= 32 || c == '@' || c == '\\') return null; }
        String hostPort = authority; int colon = hostPort.lastIndexOf(':');
        boolean digits = colon > 0 && colon + 1 < hostPort.length() || colon > 0 && colon + 1 == hostPort.length();
        String after = colon >= 0 ? hostPort.substring(colon + 1) : "";
        boolean allDigits = true; for (int i = 0; i < after.length(); i++) if (!Character.isDigit(after.charAt(i))) allDigits = false;
        String host = (colon > 0 && allDigits && !hostPort.endsWith("]")) ? hostPort.substring(0, colon) : hostPort;
        String port = host.length() != hostPort.length() ? hostPort.substring(colon) : "";
        if (host.isEmpty()) return null;
        String asciiHost;
        try { asciiHost = host.startsWith("[") ? host : IDN.toASCII(host, IDN.ALLOW_UNASSIGNED); } catch (IllegalArgumentException e) { return null; }
        if (asciiHost.isEmpty()) return null;
        for (int i = 0; i < asciiHost.length(); i++) if (asciiHost.charAt(i) <= 32) return null;
        for (int i = 0; i < tail.length(); i++) { char c = tail.charAt(i); if (c < 32 || c == 127) return null; }
        try {
            URI uri = new URI(text.substring(0, prefixLen).toLowerCase(Locale.ROOT) + asciiHost + port + encodeIllegal(tail));
            if (uri.getHost() == null || uri.getHost().isEmpty() || uri.getUserInfo() != null) return null;
            return uri.toURL();
        } catch (Exception e) { return null; }
    }

    static URL resolveRedirect(URL base, String location, boolean allowCleartext) {
        String loc = location.trim(); if (loc.isEmpty()) return null;
        String target;
        try {
            if (loc.startsWith("?")) { String b = base.toString(); int h = b.indexOf('#'); if (h >= 0) b = b.substring(0, h); int q = b.indexOf('?'); if (q >= 0) b = b.substring(0, q); target = b + encodeIllegal(loc); }
            else target = new URI(base.toString()).resolve(new URI(encodeIllegal(loc))).toString();
        } catch (Exception e) { return null; }
        URL next = parse(target, allowCleartext); if (next == null) return null;
        if (base.getProtocol().equalsIgnoreCase("https") && !next.getProtocol().equalsIgnoreCase("https")) return null;
        return next;
    }

    static String sniff(byte[] head, int length) {
        int n = Math.min(length, head.length);
        java.util.function.IntUnaryOperator at = i -> i < n ? head[i] & 0xFF : -1;
        if (at.applyAsInt(0) == 0xFF && at.applyAsInt(1) == 0xD8 && at.applyAsInt(2) == 0xFF) return "jpg";
        if (at.applyAsInt(0) == 0x89 && at.applyAsInt(1) == 0x50 && at.applyAsInt(2) == 0x4E && at.applyAsInt(3) == 0x47 && at.applyAsInt(4) == 0x0D && at.applyAsInt(5) == 0x0A && at.applyAsInt(6) == 0x1A && at.applyAsInt(7) == 0x0A) return "png";
        if (at.applyAsInt(0) == 'R' && at.applyAsInt(1) == 'I' && at.applyAsInt(2) == 'F' && at.applyAsInt(3) == 'F' && at.applyAsInt(8) == 'W' && at.applyAsInt(9) == 'E' && at.applyAsInt(10) == 'B' && at.applyAsInt(11) == 'P') return "webp";
        int limit = Math.min(n, 1024 + 5);
        for (int i = 0; i <= limit - 5; i++)
            if (at.applyAsInt(i) == '%' && at.applyAsInt(i + 1) == 'P' && at.applyAsInt(i + 2) == 'D' && at.applyAsInt(i + 3) == 'F' && at.applyAsInt(i + 4) == '-') return "pdf";
        return null;
    }

    static String percentDecode(String s, String charset) { try { return URLDecoder.decode(s.replace("+", "%2B"), charset); } catch (Exception e) { return null; } }

    static String dispositionName(String header) {
        if (header == null || header.trim().isEmpty()) return null;
        String plain = null, extended = null;
        List<String> parts = new ArrayList<>(); StringBuilder cur = new StringBuilder(); boolean quoted = false;
        for (int i = 0; i < header.length(); i++) { char c = header.charAt(i); if (c == '"') quoted = !quoted; if (c == ';' && !quoted) { parts.add(cur.toString()); cur.setLength(0); } else cur.append(c); }
        parts.add(cur.toString());
        for (int k = 1; k < parts.size(); k++) {
            String part = parts.get(k); int eq = part.indexOf('='); if (eq < 0) continue;
            String key = part.substring(0, eq).trim().toLowerCase(Locale.ROOT), value = part.substring(eq + 1).trim();
            if (key.equals("filename*")) {
                int first = value.indexOf('\''), second = first >= 0 ? value.indexOf('\'', first + 1) : -1;
                if (first > 0 && second > first) {
                    String cs = value.substring(0, first).toLowerCase(Locale.ROOT); String charset = cs.equals("utf-8") ? "UTF-8" : cs.equals("iso-8859-1") ? "ISO-8859-1" : null;
                    if (charset != null) extended = percentDecode(value.substring(second + 1), charset);
                }
            } else if (key.equals("filename")) {
                if (value.length() >= 2 && value.startsWith("\"") && value.endsWith("\"")) value = value.substring(1, value.length() - 1).replace("\\\"", "\"").replace("\\\\", "\\");
                plain = value;
            }
        }
        String r = extended != null ? extended : plain;
        return (r != null && !r.trim().isEmpty()) ? r : null;
    }

    static final Set<String> OWN_EXT = new HashSet<>(Arrays.asList("pdf", "jpg", "jpeg", "png", "webp", "php", "html", "htm", "asp", "aspx", "jsp", "download"));
    static String fileName(URL url, String contentDisposition, String extension) {
        String proposed = dispositionName(contentDisposition);
        if (proposed == null) { String seg = url.getPath().substring(url.getPath().lastIndexOf('/') + 1); proposed = percentDecode(seg, "UTF-8"); }
        if (proposed == null) proposed = "";
        String base = entryName(proposed);
        if (proposed.trim().isEmpty()) base = "download";
        int dot = base.lastIndexOf('.');
        if (dot > 0 && OWN_EXT.contains(base.substring(dot + 1).toLowerCase(Locale.ROOT))) base = base.substring(0, dot);
        if (base.codePointCount(0, base.length()) > NAME_MAX_CHARS) base = base.substring(0, base.offsetByCodePoints(0, NAME_MAX_CHARS)).trim();
        if (base.isEmpty()) base = "download";
        return base + "." + extension;
    }

    static String[] fetch(URL first, File dest, long maxBytes, boolean allowCleartext) throws IOException {
        URL current = first; int hops = 0;
        while (true) {
            HttpURLConnection c = (HttpURLConnection) current.openConnection();
            c.setInstanceFollowRedirects(false); c.setConnectTimeout(15_000); c.setReadTimeout(30_000);
            c.setRequestProperty("Accept", "application/pdf,image/*;q=0.9,*/*;q=0.5");
            try {
                int code = c.getResponseCode();
                if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
                    if (++hops > MAX_REDIRECTS) throw new LinkException("FAILED", "too many redirects");
                    String loc = c.getHeaderField("Location");
                    current = resolveRedirect(current, loc == null ? "" : loc, allowCleartext);
                    if (current == null) throw new LinkException("FAILED", "bad redirect");
                    continue;
                }
                if (code != 200) throw new LinkException("FAILED", "HTTP " + code);
                if (c.getContentLengthLong() > maxBytes) throw new LinkException("TOO_BIG", null);
                String disposition = c.getHeaderField("Content-Disposition");
                long declared = c.getContentLengthLong();
                try (InputStream input = c.getInputStream()) {
                    byte[] head = new byte[SNIFF_BYTES]; int have = 0;
                    while (have < head.length) { int r = input.read(head, have, head.length - have); if (r < 0) break; have += r; }
                    String ext = sniff(head, have); if (ext == null) throw new LinkException("UNSUPPORTED", null);
                    long total = have; if (total > maxBytes) throw new LinkException("TOO_BIG", null);
                    try (FileOutputStream out = new FileOutputStream(dest)) {
                        out.write(head, 0, have); byte[] buf = new byte[64 * 1024]; int r;
                        while ((r = input.read(buf)) >= 0) { total += r; if (total > maxBytes) throw new LinkException("TOO_BIG", null); out.write(buf, 0, r); }
                    }
                    if (declared >= 0 && total != declared) throw new LinkException("FAILED", "truncated");
                    return new String[]{ext, fileName(current, disposition, ext)};
                }
            } finally { c.disconnect(); }
        }
    }

    static String unhex(String h) { if (h.equals("-")) return null; byte[] b = new byte[h.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return new String(b, StandardCharsets.UTF_8); }

    public static void main(String[] a) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.US_ASCII)); String line;
        PrintStream out = new PrintStream(System.out, true, "UTF-8");
        while ((line = r.readLine()) != null) {
            String[] f = line.split("\t", -1); String res;
            switch (f[0]) {
                case "parse": { URL u = parse(unhex(f[1]), f[2].equals("1")); res = u == null ? "null" : u.toString(); break; }
                case "redir": { URL u = resolveRedirect(new URL(unhex(f[1])), unhex(f[2]), f[3].equals("1")); res = u == null ? "null" : u.toString(); break; }
                case "sniff": { byte[] b = new byte[f[1].length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(f[1].substring(2 * i, 2 * i + 2), 16); String e = sniff(b, b.length); res = e == null ? "null" : e; break; }
                case "name": res = fileName(new URL(unhex(f[1])), unhex(f[2]), unhex(f[3])); break;
                case "disp": { String d = dispositionName(unhex(f[1])); res = d == null ? "null" : d; break; }
                case "dl": {
                    File dest = new File(unhex(f[2]));
                    try { String[] d = fetch(new URL(unhex(f[1])), dest, Long.parseLong(f[3]), true); res = "OK\t" + d[0] + "\t" + d[1] + "\t" + dest.length(); }
                    catch (LinkException e) { dest.delete(); res = "ERR\t" + e.reason; }
                    catch (Exception e) { dest.delete(); res = "ERR\tFAILED"; }
                    break;
                }
                default: throw new IllegalArgumentException(f[0]);
            }
            out.println(res);
        }
    }
}
