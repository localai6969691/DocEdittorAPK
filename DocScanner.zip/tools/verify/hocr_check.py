"""Checks util/HocrParser.kt (through its runnable mirror HocrCheck.java) against REAL Tesseract hOCR and hand-made edge cases.

Real input: images drawn with PIL and read by the `tesseract` command line (English data is enough: the parser never looks at the
language, only at the hOCR structure, which is identical for Russian). Reference: an independent parser built on Python's html.parser.
Needs: python3 + Pillow + tesseract + java 11+. When tesseract or Pillow is missing the real-output half is skipped, and said so.
Run: python3 hocr_check.py
"""
import os, shutil, subprocess, sys, tempfile
from html.parser import HTMLParser

HERE = os.path.dirname(os.path.abspath(__file__))
MIN_CONF = 20
fails = 0


def check(ok, msg):
    global fails
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok:
        fails += 1


class Ref(HTMLParser):
    """Independent reference: html.parser decodes entities itself; nesting is handled by a depth counter."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.pars = []; self.par = None; self.line = None
        self.word = None; self.depth = 0; self.buf = []

    def _close_line(self):
        if self.line:
            self.par.append(self.line)
        self.line = None

    def _close_par(self):
        self._close_line()
        if self.par:
            self.pars.append(self.par)
        self.par = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs); cls = a.get("class", ""); title = a.get("title", "")
        if self.par is None:
            self.par = []
        if self.word is not None:
            self.depth += 1
            return
        if tag == "p" and cls == "ocr_par":
            self._close_par()
        elif tag == "span" and cls == "ocr_line":
            self._close_line(); self.line = []
        elif tag == "span" and cls == "ocrx_word":
            self.word = title; self.depth = 1; self.buf = []

    def handle_endtag(self, tag):
        if self.word is None:
            return
        self.depth -= 1
        if self.depth == 0:
            title = self.word; self.word = None
            text = "".join(self.buf).strip()
            import re
            bb = re.search(r"bbox\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)", title)
            wc = re.search(r"x_wconf\s+(\d+)", title)
            conf = int(wc.group(1)) if wc else 100
            if not bb or not text or conf < MIN_CONF:
                return
            if self.line is None:
                self.line = []
            self.line.append((int(bb.group(1)), int(bb.group(2)), int(bb.group(3)), int(bb.group(4)), conf, text))

    def handle_data(self, data):
        if self.word is not None:
            self.buf.append(data)

    def result(self):
        self._close_par()
        flat = []
        for p, par in enumerate(self.pars):
            for l, line in enumerate(par):
                for w in line:
                    flat.append("P%d L%d %d %d %d %d %d %s" % ((p, l) + w[:5] + (w[5].replace("\\", "\\\\").replace("\n", "\\n").replace("\t", "\\t"),)))
        return flat


def java_parse(hocr_text):
    with tempfile.NamedTemporaryFile("w", suffix=".hocr", delete=False, encoding="utf-8") as f:
        f.write(hocr_text); p = f.name
    r = subprocess.run(["java", os.path.join(HERE, "HocrCheck.java"), p], capture_output=True, text=True, encoding="utf-8")
    os.unlink(p)
    if r.returncode != 0:
        print(r.stderr[:500])
    return [l for l in r.stdout.split("\n") if l]


def ref_parse(hocr_text):
    r = Ref(); r.feed(hocr_text); r.close()
    return r.result()


def page(body):
    return "<div class='ocr_page' id='page_1' title='image \"x.png\"; bbox 0 0 1000 800; ppageno 0'>" + body + "</div>"


def par(lines):
    return "<div class='ocr_carea' id='block_1_1' title=\"bbox 0 0 10 10\"><p class='ocr_par' id='par_1_1' lang='rus' title=\"bbox 0 0 10 10\">" + "".join(lines) + "</p></div>"


def line(words, bbox="10 10 500 50"):
    return "<span class='ocr_line' id='line_1_1' title=\"bbox %s; baseline 0 -7; x_size 30\">" % bbox + " ".join(words) + "</span>"


def word(text, bbox="10 10 90 50", conf=95):
    return "<span class='ocrx_word' id='word_1_1' title='bbox %s; x_wconf %d'>%s</span>" % (bbox, conf, text)


def compare(name, hocr_text, expect_words=None):
    j, r = java_parse(hocr_text), ref_parse(hocr_text)
    check(j == r, "%s: Java mirror == Python reference (%d words)" % (name, len(r)))
    if j != r:
        for x, y in zip(j, r):
            if x != y:
                print("   java:", x, "\n   py  :", y); break
        print("   counts", len(j), len(r))
    if expect_words is not None:
        got = [w.split(" ", 7)[-1] for w in r]
        check(got == expect_words, "%s: expected words %r, got %r" % (name, expect_words, got))


# ---- hand-made cases (Cyrillic, entities, nesting, confidence, paragraphs) ----
compare("cyrillic words", page(par([line([word("Привет"), word("мир", "100 10 160 50")])])), ["Привет", "мир"])
compare("entities", page(par([line([word("A &amp; B"), word("5 &lt; 7", "100 10 160 50"), word("&#1087;&#x43F;", "170 10 230 50"), word("&amp;lt;", "240 10 300 50"), word("it&#39;s", "310 10 370 50"), word("&quot;q&quot;", "380 10 440 50")])])),
        ["A & B", "5 < 7", "пп", "&lt;", "it's", '"q"'])
compare("nested strong/em", page(par([line([word("<strong>Жир</strong>ный"), word("<em><strong>ab</strong></em>", "100 10 160 50")])])), ["Жирный", "ab"])
compare("low confidence dropped", page(par([line([word("good", conf=90), word("noise", "100 10 160 50", conf=5), word("edge", "170 10 230 50", conf=20)])])), ["good", "edge"])
compare("no x_wconf", page(par([line(["<span class='ocrx_word' id='w' title='bbox 1 2 3 4'>tok</span>"])])), ["tok"])
compare("empty word skipped", page(par([line([word("   "), word("x", "100 10 160 50")])])), ["x"])
compare("two paragraphs, two lines", page(par([line([word("a")], "0 0 9 9"), line([word("b")], "0 20 9 29")]) + par([line([word("c")], "0 50 9 59")])), ["a", "b", "c"])
compare("single quotes everywhere", "<p class=\"ocr_par\" title=\"bbox 0 0 1 1\"><span class=\"ocr_line\" title=\"bbox 0 0 1 1\"><span class=\"ocrx_word\" title=\"bbox 1 2 3 4; x_wconf 80\">q</span></span></p>", ["q"])
compare("empty input", "", [])
compare("no words", page(par([line([])])), [])

# ---- REAL Tesseract output ----
if not shutil.which("tesseract"):
    print("SKIP the real-output half: the `tesseract` command is not installed")
else:
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        print("SKIP the real-output half: Pillow is not installed"); Image = None
    if Image:
        font_dir = "/usr/share/fonts/truetype/dejavu/"
        if not os.path.isdir(font_dir):
            print("SKIP the real-output half: DejaVu fonts not found")
        else:
            tmp = tempfile.mkdtemp()
            samples = {
                "mixed": [("Invoice 2026 & Receipts", "DejaVuSans-Bold.ttf"), ("The quick brown fox jumps over", "DejaVuSans.ttf"), ("the lazy dog while 5 < 7 and 9 > 3.", "DejaVuSans.ttf")],
                "two blocks": [("First block of plain text here", "DejaVuSans.ttf"), ("", ""), ("Second block after a gap below", "DejaVuSerif.ttf"), ("and one more line of it.", "DejaVuSerif.ttf")],
                "quotes": [("He said \"hello\" and it's fine", "DejaVuSans.ttf"), ("Total: 1,234.50 EUR (VAT 20%)", "DejaVuSans.ttf")],
            }
            for name, rows in samples.items():
                img = Image.new("RGB", (1500, 900), "white"); d = ImageDraw.Draw(img); y = 40
                for text, fname in rows:
                    if not text:
                        y += 90; continue
                    d.text((60, y), text, fill="black", font=ImageFont.truetype(font_dir + fname, 44)); y += 80
                png = os.path.join(tmp, name.replace(" ", "_") + ".png"); img.save(png)
                subprocess.run(["tesseract", png, png[:-4], "-l", "eng", "hocr"], capture_output=True)
                hp = png[:-4] + ".hocr"
                if not os.path.exists(hp):
                    check(False, "real %s: tesseract produced no hOCR" % name); continue
                text = open(hp, encoding="utf-8").read()
                compare("real Tesseract output '%s'" % name, text)
                words = ref_parse(text)
                check(len(words) >= 5, "real '%s': at least 5 words read (%d)" % (name, len(words)))
            shutil.rmtree(tmp, ignore_errors=True)

print("\n" + ("TAT CA DAT" if fails == 0 else "%d LOI" % fails))
sys.exit(1 if fails else 0)
