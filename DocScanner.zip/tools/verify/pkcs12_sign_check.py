"""Chứng thư số từ tệp .p12 / .pfx (phiên 22, mục 4.49.8): Pkcs12Import.kt (bản Java Pkcs12ImportCheck.java) + CmsSigner.kt với CHUỖI chứng thư và khoá EC
(bản Java CmsCheck.java). Bộ kiểm dựng một hệ thống CA thật bằng `cryptography` (gốc -> trung gian -> người ký), đóng gói .p12 bằng hai kiểu mã hoá
(AES / PBES2 của OpenSSL 3 và 3DES kiểu cũ mà các nhà cung cấp chứng thư số vẫn dùng), rồi:
  1. đọc .p12: RSA 2048 / RSA 3072 / EC P-256 / EC P-384, hai kiểu mã hoá, mật khẩu ASCII; chuỗi 3 chứng thư (người ký -> trung gian -> gốc) đọc đủ.
     GIỚI HẠN CỦA MÔI TRƯỜNG KIỂM (đã đo, không phải đoán): JDK từ chối mật khẩu NGOÀI ASCII cho PKCS#12 ("Password is not ASCII"; tệp do OpenSSL tạo với mật khẩu "café"
     cũng không đọc được), trong khi OpenSSL và `cryptography` đọc được. Android dùng BouncyCastle (BMPString đầy đủ Unicode) nên KHÔNG chịu giới hạn này, nhưng
     bản Java không chứng minh được điều đó: với mật khẩu có dấu bộ kiểm chỉ xác nhận tệp HỢP LỆ bằng OpenSSL và ghi rõ là chưa kiểm phía Android;
  2. TỪ CHỐI đúng lý do: sai mật khẩu, tệp rác, tệp chỉ có chứng thư (không khoá), hết hạn, chưa tới hạn, khoá RSA 1024, khoá không khớp chứng thư;
  3. ký một PDF bằng khoá đó (chuỗi nhúng vào CMS) rồi hai trình kiểm KHÁC NHAU xác nhận: `pdfsig` (toàn vẹn) và `openssl cms -verify -CAfile gốc` KHÔNG kèm
     -untrusted: chỉ qua được nếu chuỗi trung gian nằm TRONG chữ ký; EC dùng ECDSA (identifier KHÔNG có tham số NULL);
  4. THỬ ÂM TÍNH: cùng chữ ký nhưng KHÔNG nhúng chuỗi -> openssl không dựng được đường tới gốc (chứng minh việc nhúng chuỗi có tác dụng); sửa 1 byte vùng đã ký -> sai.
Chạy: python3 pkcs12_sign_check.py   (cần cryptography, openssl, pdfsig, java; ~1 phút)
"""
import datetime, os, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
from digital_signature_check import base_pdf, with_signature_placeholder, pdfsig, CAPACITY
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, ec
from cryptography.hazmat.primitives.serialization import pkcs12
from cryptography.x509.oid import NameOID

HERE = os.path.dirname(os.path.abspath(__file__))
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

now = datetime.datetime.now(datetime.timezone.utc)
def name(cn): return x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn), x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Thử nghiệm DocScanner")])
def cert(subject, subject_key, issuer_name, issuer_key, ca, days=3650, start=None):
    b = (x509.CertificateBuilder().subject_name(subject).issuer_name(issuer_name).public_key(subject_key.public_key())
         .serial_number(int.from_bytes(os.urandom(8), "big") | 1 << 62).not_valid_before(start or now - datetime.timedelta(days=1))
         .not_valid_after((start or now) + datetime.timedelta(days=days))
         .add_extension(x509.BasicConstraints(ca=ca, path_length=None), critical=True)
         .add_extension(x509.KeyUsage(digital_signature=not ca, content_commitment=not ca, key_encipherment=False, data_encipherment=False, key_agreement=False,
                                      key_cert_sign=ca, crl_sign=ca, encipher_only=False, decipher_only=False), critical=True))
    return b.sign(issuer_key, hashes.SHA256())

root_key = rsa.generate_private_key(65537, 2048); root = cert(name("Gốc thử nghiệm"), root_key, name("Gốc thử nghiệm"), root_key, True)
mid_key = rsa.generate_private_key(65537, 2048); mid = cert(name("Trung gian thử nghiệm"), mid_key, root.subject, root_key, True)
def leaf_rsa(bits): k = rsa.generate_private_key(65537, bits); return k, cert(name("Người ký RSA"), k, mid.subject, mid_key, False)
def leaf_ec(curve): k = ec.generate_private_key(curve); return k, cert(name("Người ký EC"), k, mid.subject, mid_key, False)

work = tempfile.mkdtemp(prefix="p12_", dir=OUT)
open(os.path.join(work, "root.pem"), "wb").write(root.public_bytes(serialization.Encoding.PEM))
PW_ASCII, PW_ASCII2, PW_VN = "matkhau123", "Mk-Dac_biet!#42 xyz", "Mật khẩu Đặng-Ấn 🔐 123"
def enc_modern(pw): return serialization.BestAvailableEncryption(pw.encode("utf-8"))
def enc_legacy(pw):
    return (serialization.PrivateFormat.PKCS12.encryption_builder().kdf_rounds(2048).key_cert_algorithm(pkcs12.PBES.PBESv1SHA1And3KeyTripleDESCBC)
            .hmac_hash(hashes.SHA1()).build(pw.encode("utf-8")))
def write_p12(fname, key, c, cas, enc):
    data = pkcs12.serialize_key_and_certificates(b"signer", key, c, cas, enc)
    p = os.path.join(work, fname); open(p, "wb").write(data); return p

def read(p12, pw, now_ms=None, prefix="out"):
    r = subprocess.run(["java", os.path.join(HERE, "Pkcs12ImportCheck.java"), p12, pw.encode("utf-8").hex(), str(now_ms or int(now.timestamp() * 1000)), os.path.join(work, prefix)],
                       capture_output=True, text=True)
    if r.returncode != 0: raise RuntimeError(r.stderr[-1500:])
    return r.stdout.strip()

# ---------- 1. đọc ----------
k2048, c2048 = leaf_rsa(2048); k3072, c3072 = leaf_rsa(3072); kp256, cp256 = leaf_ec(ec.SECP256R1()); kp384, cp384 = leaf_ec(ec.SECP384R1())
cases = [("rsa2048_modern_ascii", k2048, c2048, enc_modern, PW_ASCII, "RSA"), ("rsa2048_legacy_ascii", k2048, c2048, enc_legacy, PW_ASCII2, "RSA"),
         ("rsa3072_modern_ascii", k3072, c3072, enc_modern, PW_ASCII2, "RSA"), ("ec256_modern_ascii", kp256, cp256, enc_modern, PW_ASCII, "EC"),
         ("ec256_legacy_ascii", kp256, cp256, enc_legacy, PW_ASCII2, "EC"), ("ec384_modern_ascii", kp384, cp384, enc_modern, PW_ASCII, "EC")]
files = {}
for label, k, c, enc, pw, alg in cases:
    p = write_p12(label + ".p12", k, c, [mid, root], enc(pw)); files[label] = (p, pw, alg)
    out = read(p, pw, prefix=label)
    check(out == f"OK {alg} 3", f"đọc {label}: {out} (chuỗi người ký -> trung gian -> gốc)")

# mật khẩu có dấu: tệp phải HỢP LỆ (OpenSSL đọc được); phía JDK/Android xem ghi chú ở đầu tệp
for kind, enc in (("modern", enc_modern), ("legacy", enc_legacy)):
    pv = write_p12(f"vn_{kind}.p12", k2048, c2048, [mid, root], enc(PW_VN))
    r = subprocess.run(["openssl", "pkcs12", "-in", pv, "-passin", "pass:" + PW_VN, "-nokeys", "-noout"] + (["-legacy"] if kind == "legacy" else []), capture_output=True, text=True)
    check(r.returncode == 0, f"mật khẩu tiếng Việt + emoji ({kind}): tệp .p12 HỢP LỆ theo OpenSSL (phía Android/BouncyCastle: CHƯA kiểm; JDK không đọc được)")

# ---------- 2. từ chối ----------
def expect(label, p, pw, reason, now_ms=None):
    out = read(p, pw, now_ms)
    check(out == f"ERR {reason}", f"từ chối {label}: {out}")
p, pw, _ = files["rsa2048_modern_ascii"]
expect("sai mật khẩu", p, "sai-mat-khau", "BAD_FILE_OR_PASSWORD")
junk = os.path.join(work, "junk.p12"); open(junk, "wb").write(os.urandom(500)); expect("tệp rác", junk, "x", "BAD_FILE_OR_PASSWORD")
certs_only = os.path.join(work, "certs_only.p12"); open(certs_only, "wb").write(pkcs12.serialize_key_and_certificates(None, None, None, [root, mid], enc_modern("x")))
expect("tệp chỉ có chứng thư (không khoá)", certs_only, "x", "NO_KEY")
exp = cert(name("Hết hạn"), k2048, mid.subject, mid_key, False, days=30, start=now - datetime.timedelta(days=400))
expect("chứng thư hết hạn", write_p12("expired.p12", k2048, exp, [mid, root], enc_modern("x")), "x", "EXPIRED")
fut = cert(name("Chưa tới hạn"), k2048, mid.subject, mid_key, False, days=30, start=now + datetime.timedelta(days=100))
expect("chứng thư chưa tới hạn", write_p12("future.p12", k2048, fut, [mid, root], enc_modern("x")), "x", "NOT_YET_VALID")
k1024 = rsa.generate_private_key(65537, 1024); c1024 = cert(name("Yếu"), k1024, mid.subject, mid_key, False)
expect("khoá RSA 1024 bit", write_p12("weak.p12", k1024, c1024, [mid, root], enc_modern("x")), "x", "WEAK_KEY")
open(os.path.join(work, "k3072.pk8"), "wb").write(k3072.private_bytes(serialization.Encoding.DER, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
open(os.path.join(work, "c2048.der"), "wb").write(c2048.public_bytes(serialization.Encoding.DER))
subprocess.run(["java", os.path.join(HERE, "Pkcs12ImportCheck.java"), "mismatch", os.path.join(work, "mismatch.p12"), "x", os.path.join(work, "k3072.pk8"), os.path.join(work, "c2048.der")], check=True, capture_output=True)
expect("khoá không khớp chứng thư", os.path.join(work, "mismatch.p12"), "x", "KEY_MISMATCH")
expect("đọc lại sau khi chứng thư hết hạn (đồng hồ giả lập +11 năm)", p, PW_ASCII, "EXPIRED", int((now + datetime.timedelta(days=4000)).timestamp() * 1000))

# ---------- 3. ký bằng chuỗi + hai trình kiểm ----------
def sign_with(prefix, alg, embed_chain):
    base, prev = base_pdf(); unsigned = with_signature_placeholder(base, prev)
    lt = unsigned.index(b"/Contents <") + len(b"/Contents "); gt = lt + 1 + 2 * CAPACITY; a, b = lt, gt + 1
    br = b"/ByteRange [0 %010d %010d %010d]" % (a, b, len(unsigned) - b)
    data = bytearray(unsigned); i = data.index(b"/ByteRange [0 0000000000 0000000000 0000000000]"); data[i:i + len(br)] = br
    content = bytes(data[:a]) + bytes(data[b:]); cpath = os.path.join(work, prefix + "_content.bin"); open(cpath, "wb").write(content)
    cms_path = os.path.join(work, prefix + ("_sig.der" if embed_chain else "_sig_nochain.der"))
    extra = [os.path.join(work, f"{prefix}.{n}.der") for n in (1, 2)] if embed_chain else []
    r = subprocess.run(["java", os.path.join(HERE, "CmsCheck.java"), cpath, os.path.join(work, prefix + ".pk8"), os.path.join(work, prefix + ".0.der"), cms_path,
                        str(int(now.timestamp() * 1000)), "-", alg] + extra, capture_output=True, text=True)
    if r.returncode != 0: raise RuntimeError(r.stderr[-1500:])
    cms = open(cms_path, "rb").read(); assert len(cms) <= CAPACITY, len(cms)
    data[lt + 1:gt] = cms.hex().upper().encode().ljust(2 * CAPACITY, b"0")
    pdf = os.path.join(work, prefix + (".pdf" if embed_chain else "_nochain.pdf")); open(pdf, "wb").write(bytes(data)); return pdf, cms_path, cpath, bytes(data)

def openssl_chain(cms_path, content_path):
    r = subprocess.run(["openssl", "cms", "-verify", "-inform", "DER", "-in", cms_path, "-content", content_path, "-binary", "-CAfile", os.path.join(work, "root.pem"),
                        "-purpose", "any", "-out", os.devnull], capture_output=True, text=True)
    return r.returncode == 0, (r.stdout + r.stderr).strip()

for label in ("rsa2048_modern_ascii", "rsa3072_modern_ascii", "ec256_modern_ascii", "ec384_modern_ascii"):
    alg = files[label][2]
    pdf, cms_path, cpath, raw = sign_with(label, alg, True)
    out = pdfsig(pdf)
    check("Signature is Valid" in out, f"{label}: pdfsig báo chữ ký HỢP LỆ (toàn vẹn) với {'ECDSA' if alg == 'EC' else 'RSA'}")
    ok, msg = openssl_chain(cms_path, cpath)
    check(ok, f"{label}: `openssl cms -verify -CAfile gốc` (KHÔNG -untrusted) thành công: chuỗi nằm TRONG chữ ký ({msg[:40]})")
    if label == "rsa2048_modern_ascii":
        pdf2, cms2, cp2, _ = sign_with(label, alg, False)
        ok2, msg2 = openssl_chain(cms2, cp2)
        check(not ok2, f"ÂM TÍNH: cùng chữ ký KHÔNG nhúng chuỗi -> openssl không dựng được đường tới gốc ({msg2[:60]})")
        check(os.path.getsize(cms_path) > os.path.getsize(cms2) + 800, "chuỗi nhúng làm CMS lớn hơn (2 chứng thư thêm)")
        t = bytearray(raw); k = t.index(b"0.9 0.2 0.2 rg"); t[k + 2] = ord("8"); tp = os.path.join(work, "tampered.pdf"); open(tp, "wb").write(bytes(t))
        check("Signature is Valid" not in pdfsig(tp), "ÂM TÍNH: sửa 1 byte vùng đã ký -> pdfsig báo KHÔNG hợp lệ")

# ---------- 4b. kho tin cậy THẬT (NSS, thư viện xác thực chứng thư của Firefox / poppler) ----------
import shutil
if shutil.which("certutil"):
    def nss_db(name, trust_root):
        d = os.path.join(work, name); os.makedirs(d, exist_ok=True)
        subprocess.run(["certutil", "-N", "-d", "sql:" + d, "--empty-password"], check=True, capture_output=True)
        if trust_root: subprocess.run(["certutil", "-A", "-d", "sql:" + d, "-n", "testroot", "-t", "CT,C,C", "-i", os.path.join(work, "root.pem")], check=True, capture_output=True)
        return "sql:" + d
    def verdict(db, pdf):
        o = subprocess.run(["pdfsig", "-nssdir", db, pdf], capture_output=True, text=True).stdout
        return [l.split(":", 1)[1].strip() for l in o.split("\n") if "Certificate Validation" in l][:1], "Signature is Valid" in o
    trusted, empty = nss_db("nss_trusted", True), nss_db("nss_empty", False)
    for label in ("rsa2048_modern_ascii", "ec256_modern_ascii"):
        v, valid = verdict(trusted, os.path.join(work, label + ".pdf"))
        check(valid and v == ["Certificate is Trusted."], f"NSS (kho tin cậy có gốc thử nghiệm) + {label}: chữ ký hợp lệ và chứng thư người ký ĐƯỢC TIN qua chuỗi nhúng ({v})")
    v, valid = verdict(trusted, os.path.join(work, "rsa2048_modern_ascii_nochain.pdf"))
    check(valid and v == ["Certificate issuer is unknown."], f"ÂM TÍNH: cùng gốc được tin nhưng KHÔNG nhúng chuỗi -> NSS không nối được tới gốc ({v})")
    v, valid = verdict(empty, os.path.join(work, "rsa2048_modern_ascii.pdf"))
    check(valid and v != ["Certificate is Trusted."], f"ÂM TÍNH: kho tin cậy rỗng -> không được tin dù chữ ký toàn vẹn ({v})")
else:
    print("BO QUA: không có certutil (NSS)")

# ---------- 5. tên người ký (commonName) ----------
tricky = ["Nguyễn Văn A", "Công ty A, B", 'Tên "kép"', "A+B", "A;B", "<x>", "a\\b", "Ünïcödé 😀", "Trần Thị Bé (Kế toán)", "O'Brien"]
bad = []
for cn in tricky:
    nm = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn), x509.NameAttribute(NameOID.ORGANIZATION_NAME, "Cty X, Y"), x509.NameAttribute(NameOID.COUNTRY_NAME, "VN")])
    kk = rsa.generate_private_key(65537, 2048); cc = cert(nm, kk, nm, kk, False)
    pp = write_p12("cn.p12", kk, cc, None, enc_modern("abc12345"))
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", os.path.join(HERE, "Pkcs12ImportCheck.java"), "subject", pp, "abc12345".encode().hex()], capture_output=True, text=True)
    full, got = (bytes.fromhex(x).decode("utf-8") for x in r.stdout.split())
    if got != cn: bad.append((cn, full, got))
check(not bad, f"commonName: {len(tricky)} tên có dấu phẩy, nháy, +, ;, <>, gạch chéo ngược, emoji -> lấy ĐÚNG CN từ chuỗi RFC 2253 do JDK sinh (so với CN gốc của cryptography){'' if not bad else ' ' + str(bad[:2])}")

print(); print("TAT CA DAT" if not fails else f"{len(fails)} LOI: {fails}")
sys.exit(1 if fails else 0)
