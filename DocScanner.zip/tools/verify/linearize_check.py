"""Kiểm chứng Linearizer (phiên 18, B12 tuyến tính hoá / Fast Web View) - ISO 32000-1 Annex F.

LinearizerCheck.java là bản Java chạy được của util/Linearizer.kt (chuyển thể từ gói Go `linearize` của dự án byblos, Apache-2.0, đã kiểm với qpdf - xem TECHNICAL_DOCS.md 4.42).
Phía "bộ chuyển đổi" (đọc PDF -> đồ thị đối tượng + thân đối tượng tuần tự hoá) ở đây viết bằng pikepdf, PHẢN CHIẾU từng bước PdfLinearizer.kt (PdfBox).
Bộ kiểm ĐỘC LẬP: `qpdf --check-linearization` (chính bộ kiểm tuyến tính hoá của qpdf: thứ tự các phần, từ điển tham số, nội dung từng bảng gợi ý), `qpdf --check`,
pikepdf.is_linearized, và NỘI DUNG: poppler vẽ từng trang của tệp vào và tệp ra rồi so TỪNG ĐIỂM ẢNH + pdftotext.
Kho PDF: ảnh quét nhiều trang (Pillow), phông + ảnh dùng chung giữa các trang, 1 trang, mục lục (có / không PageMode UseOutlines), tài nguyên kế thừa từ nút Pages,
luồng đối tượng (PDF 1.5), AcroForm + OpenAction, Info có / không, ID có / không, 60 trang, và PDF thật do LibreOffice dựng.
THỬ ÂM TÍNH: cố ý làm hỏng /L, hỏng luồng gợi ý, đổi thứ tự -> qpdf phải từ chối (chứng minh bộ kiểm không "luôn đạt").
Chạy: python3 linearize_check.py   (cần pikepdf, Pillow, python-docx, poppler-utils, qpdf, java 11+; LibreOffice nếu có)
"""
import io, os, random, re, shutil, subprocess, sys, tempfile, zlib
from decimal import Decimal
import pikepdf
from pikepdf import Array, Dictionary, Name, String
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__)); FAILS = []
def check(c, w):
    print(("ok  " if c else "LOI"), w)
    if not c: FAILS.append(w)
tmp = tempfile.mkdtemp(prefix="lin_"); P = lambda n: os.path.join(tmp, n)
def run(*a): return subprocess.run(list(a), capture_output=True, text=True)

# ============================================================ bộ chuyển đổi (phản chiếu PdfLinearizer.kt)
INHERIT = ("/Resources", "/MediaBox", "/CropBox", "/Rotate")
def push_inherited(pdf):
    for page in pdf.pages:
        o = page.obj
        for key in INHERIT:
            if key in o: continue
            node = o.get("/Parent")
            while node is not None:
                if key in node: o[key] = node[key]; break
                node = node.get("/Parent")
def esc_name(s):
    out = []
    for b in s[1:].encode("utf-8"):
        c = chr(b)
        out.append(c if 0x21 <= b <= 0x7E and c not in "#()<>[]{}/%" else "#%02X" % b)
    return "/" + "".join(out)
def ser(v):
    if isinstance(v, bool): return "true" if v else "false"
    if v is None: return "null"
    if isinstance(v, int): return str(v)
    if isinstance(v, (Decimal, float)): return format(Decimal(v), "f")
    if v.is_indirect: return "\x01%d\x02" % v.objgen[0]
    if isinstance(v, pikepdf.Name): return esc_name(str(v))
    if isinstance(v, pikepdf.String): return "<" + bytes(v).hex() + ">"
    if isinstance(v, pikepdf.Array): return "[" + " ".join(ser(x) for x in v) + "]"
    if isinstance(v, (pikepdf.Dictionary, pikepdf.Stream)): return "<<" + "".join(esc_name(k) + " " + ser(x) for k, x in v.items() if k != "/Length") + ">>"
    raise TypeError(type(v))
def children(v):
    """Các đối tượng GIÁN TIẾP mà v (một đối tượng trực tiếp hoặc gián tiếp) tham chiếu tới, theo thứ tự xuất hiện."""
    out = []
    def walk(x, top):
        if isinstance(x, (bool, int, float, Decimal)) or x is None: return
        if x.is_indirect and not top: out.append(x); return
        if isinstance(x, pikepdf.Array):
            for y in x: walk(y, False)
        elif isinstance(x, (pikepdf.Dictionary, pikepdf.Stream)):
            for k, y in x.items(): walk(y, False)
    walk(v, True); return out
def is_ref(x): return not isinstance(x, (bool, int, float, Decimal)) and x is not None and x.is_indirect
def direct_targets(x):
    """Số hiệu các đối tượng gián tiếp mà GIÁ TRỊ x trỏ tới: chính nó nếu là tham chiếu, ngược lại các tham chiếu nằm trong x (không đi sâu vào đối tượng gián tiếp)."""
    return [x.objgen[0]] if is_ref(x) else [c.objgen[0] for c in children(x)]
def build_description(pdf, path):
    push_inherited(pdf)
    root = pdf.Root; info = pdf.trailer.get("/Info"); pages = [p.obj for p in pdf.pages]; page_nums = {p.objgen[0] for p in pages}
    # đồ thị: mọi đối tượng với tới được từ Root / Info; cạnh /Parent và /Thumb của TRANG không dùng để phân vùng (nhưng đối tượng vẫn được ghi)
    seen = {}; order = []; stack = [root] + ([info] if info is not None else [])
    while stack:
        o = stack.pop(0)
        n = o.objgen[0]
        if n in seen: continue
        seen[n] = o; order.append(n)
        for c in children(o): stack.append(c)
    refs = {}
    for n, o in seen.items():
        cs = []
        if n in page_nums:
            for k, y in o.items():
                if k in ("/Parent", "/Thumb"): continue
                cs += direct_targets(y)
        else:
            cs = [c.objgen[0] for c in children(o)]
        refs[n] = [c for c in dict.fromkeys(cs) if c in seen]
    # cây trang
    tree = []; q = [root.Pages]
    while q:
        nd = q.pop(0); tree.append(nd.objgen[0])
        for k in nd.get("/Kids", []):
            if str(k.get("/Type")) == "/Pages": q.append(k)
    open_keys = ("/ViewerPreferences", "/PageMode", "/Threads", "/OpenAction", "/AcroForm")
    seeds = direct_targets
    opendoc = []; other = []; outlines = 0; use_outlines = str(root.get("/PageMode", "")) == "/UseOutlines"
    for k, v in root.items():
        if k in open_keys: opendoc += seeds(v)
        elif k == "/Outlines": outlines = v.objgen[0] if v.is_indirect else 0
        elif k == "/Pages": pass
        else: other += seeds(v)
    if info is not None and info.is_indirect: other.append(info.objgen[0])
    lines = [f"VERSION {pdf.pdf_version}"]
    idv = pdf.trailer.get("/ID")
    if idv is not None: lines.append("ID " + bytes(idv[0]).hex() + " " + bytes(idv[1]).hex())
    lines += [f"CATALOG {root.objgen[0]}", f"INFO {info.objgen[0] if info is not None and info.is_indirect else 0}", f"USEOUTLINES {int(use_outlines)}", f"OUTLINES {outlines}",
              "PAGES " + " ".join(str(p.objgen[0]) for p in pages), "PAGETREE " + " ".join(map(str, tree)), "OPENDOC " + " ".join(map(str, dict.fromkeys(opendoc))), "OTHER " + " ".join(map(str, dict.fromkeys(other)))]
    for n in sorted(seen):
        o = seen[n]
        if isinstance(o, pikepdf.Stream):
            raw = o.read_raw_bytes(); d = "<<" + "".join(esc_name(k) + " " + ser(x) for k, x in o.items() if k != "/Length") + " /Length %d>>" % len(raw); st = raw.hex() if raw else "00"
            if not raw: d = d.replace("/Length 0", "/Length 0"); st = "-"      # luồng rỗng: không có dữ liệu
            lines.append(f"OBJ {n} {','.join(map(str, refs[n])) or '-'} {d.encode('latin-1').hex()} {st if raw else 'E'}")
        else:
            lines.append(f"OBJ {n} {','.join(map(str, refs[n])) or '-'} {ser_top(o).encode('latin-1').hex()} -")
    open(path, "w", encoding="latin-1").write("\n".join(lines) + "\n")
def ser_top(o):
    if isinstance(o, pikepdf.Array): return "[" + " ".join(ser(x) for x in o) + "]"
    if isinstance(o, pikepdf.Dictionary): return "<<" + "".join(esc_name(k) + " " + ser(x) for k, x in o.items()) + ">>"
    if isinstance(o, pikepdf.Name): return esc_name(str(o))
    if isinstance(o, pikepdf.String): return "<" + bytes(o).hex() + ">"
    return ser(o)
def linearize(in_pdf, out_pdf):
    pdf = pikepdf.open(in_pdf); build_description(pdf, P("desc.txt")); pdf.close()
    r = run("java", os.path.join(HERE, "LinearizerCheck.java"), P("desc.txt"), out_pdf)
    if r.returncode != 0: print(r.stderr[-1200:])
    return r.returncode == 0

# ============================================================ kho PDF
rnd = random.Random(18)
def noise_img(w, h, seed):
    r = random.Random(seed); im = Image.new("RGB", (w, h)); px = im.load()
    for y in range(h):
        for x in range(w): px[x, y] = (r.randrange(256), (x * 3 + seed) % 256, (y * 5) % 256)
    return im
def corpus():
    c = {}
    ims = [noise_img(120, 160, i) for i in range(5)]; ims[0].save(P("scan5.pdf"), "PDF", save_all=True, append_images=ims[1:], resolution=72); c["ảnh quét 5 trang (Pillow)"] = P("scan5.pdf")
    ims[0].save(P("scan1.pdf"), "PDF", resolution=72); c["1 trang"] = P("scan1.pdf")
    def text_page(pdf, shared_font, img, i, with_img):
        page = pdf.add_blank_page(page_size=(300, 200)); body = f"BT /F1 14 Tf 20 150 Td (Trang {i + 1} noi dung) Tj ET"
        res = Dictionary(Font=Dictionary(F1=shared_font))
        if with_img is not None: res.XObject = Dictionary(Im1=with_img); body += " q 80 0 0 60 20 40 cm /Im1 Do Q"
        page.Resources = res; page.Contents = pdf.make_stream(body.encode()); return page
    pdf = pikepdf.Pdf.new(); font = pdf.make_indirect(Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Helvetica))
    img = pdf.make_stream(noise_img(40, 30, 99).tobytes()); img.Type = Name.XObject; img.Subtype = Name.Image; img.Width = 40; img.Height = 30; img.ColorSpace = Name.DeviceRGB; img.BitsPerComponent = 8
    img2 = pdf.make_stream(noise_img(30, 30, 7).tobytes()); img2.Type = Name.XObject; img2.Subtype = Name.Image; img2.Width = 30; img2.Height = 30; img2.ColorSpace = Name.DeviceRGB; img2.BitsPerComponent = 8
    for i in range(6): text_page(pdf, font, None, i, img if i in (0, 2) else img2 if i in (1, 3, 4) else None)
    pdf.docinfo = pdf.make_indirect(Dictionary(Title=String("Tài liệu thử"))); pdf.save(P("shared.pdf")); c["6 trang, phông + 2 ảnh dùng chung (cả trang đầu và trang sau), Info"] = P("shared.pdf")
    pdf = pikepdf.Pdf.new(); font = pdf.make_indirect(Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Courier))
    pages = [text_page(pdf, font, None, i, None) for i in range(4)]
    items = []
    for i, p in enumerate(pages): items.append(pdf.make_indirect(Dictionary(Title=String(f"Mục {i+1}"), Dest=Array([p.obj, Name.Fit]))))
    outline = pdf.make_indirect(Dictionary(Type=Name.Outlines)); 
    for it in items: it.Parent = outline
    for a, b in zip(items, items[1:]): a.Next = b; b.Prev = a
    outline.First = items[0]; outline.Last = items[-1]; outline.Count = len(items); pdf.Root.Outlines = outline
    pdf.save(P("outl_off.pdf")); c["mục lục (4 mục), PageMode mặc định"] = P("outl_off.pdf")
    pdf.Root.PageMode = Name.UseOutlines; pdf.save(P("outl_on.pdf")); c["mục lục + PageMode UseOutlines"] = P("outl_on.pdf")
    pdf = pikepdf.Pdf.new(); font = pdf.make_indirect(Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name("/Times-Roman")))
    for i in range(3):
        pg = pdf.add_blank_page(page_size=(250, 150)); pg.Contents = pdf.make_stream(f"BT /F1 12 Tf 10 100 Td (Ke thua {i+1}) Tj ET".encode())
    pdf.Root.Pages.Resources = Dictionary(Font=Dictionary(F1=font)); pdf.Root.Pages.MediaBox = Array([0, 0, 250, 150])
    for pg in pdf.pages:
        for k in ("/Resources", "/MediaBox"):
            if k in pg.obj: del pg.obj[k]
    pdf.save(P("inherit.pdf")); c["tài nguyên + MediaBox kế thừa từ nút Pages"] = P("inherit.pdf")
    pdf = pikepdf.Pdf.new(); font = pdf.make_indirect(Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Helvetica))
    for i in range(5): text_page(pdf, font, None, i, None)
    pdf.Root.OpenAction = Array([pdf.pages[1].obj, Name.Fit]); pdf.Root.AcroForm = pdf.make_indirect(Dictionary(Fields=Array(), DA=String("/Helv 0 Tf 0 g")))
    pdf.save(P("objstm.pdf"), object_stream_mode=pikepdf.ObjectStreamMode.generate, compress_streams=True); c["luồng đối tượng (PDF 1.5) + OpenAction + AcroForm"] = P("objstm.pdf")
    pdf = pikepdf.Pdf.new(); font = pdf.make_indirect(Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Helvetica))
    for i in range(60): text_page(pdf, font, None, i, None)
    pdf.save(P("p60.pdf")); c["60 trang (độ rộng bit lớn hơn)"] = P("p60.pdf")
    return c
CORPUS = corpus()
# PDF thật từ LibreOffice
if shutil.which("soffice"):
    try:
        import docx
        d = docx.Document()
        for i in range(120): d.add_paragraph(f"Đoạn {i}: " + "văn bản tiếng Việt thử tuyến tính hoá. " * 8)
        t = d.add_table(rows=6, cols=4)
        for r in range(6):
            for k in range(4): t.cell(r, k).text = f"ô {r},{k}"
        d.save(P("doc.docx")); r = run("soffice", "--headless", "--convert-to", "pdf", "--outdir", tmp, P("doc.docx"))
        if os.path.exists(P("doc.pdf")): CORPUS["PDF thật do LibreOffice dựng (nhiều trang, phông nhúng)"] = P("doc.pdf")
    except Exception as e: print("  (bỏ qua LibreOffice:", e, ")")

def render_all(path, tag):
    d = P("r_" + tag); os.makedirs(d, exist_ok=True); run("pdftoppm", "-r", "20", "-png", path, os.path.join(d, "p"))
    return [open(os.path.join(d, f), "rb").read() for f in sorted(os.listdir(d))]
def pages_of(path): return len(pikepdf.open(path).pages)

print("== đúng theo bộ kiểm tuyến tính hoá của qpdf ==")
OUTS = {}
for name, src in CORPUS.items():
    out = P("lin_" + str(len(OUTS)) + ".pdf"); ok = linearize(src, out); OUTS[name] = (src, out, ok)
    if not ok: check(False, f"{name}: bộ tuyến tính hoá chạy được"); continue
    lc = run("qpdf", "--check-linearization", out); chk = run("qpdf", "--check", out)
    good = lc.returncode == 0 and "no linearization errors" in (lc.stdout + lc.stderr).lower()
    check(good and chk.returncode in (0, 3) and pikepdf.open(out).is_linearized, f"{name}: qpdf --check-linearization đạt; is_linearized; --check đạt" + ("" if good else "\n" + (lc.stdout + lc.stderr)[:600]))
    same_pages = pages_of(out) == pages_of(src)
    ra, rb = render_all(src, f"a{len(OUTS)}"), render_all(out, f"b{len(OUTS)}")
    ta, tb = run("pdftotext", src, "-").stdout, run("pdftotext", out, "-").stdout
    check(same_pages and ra == rb and len(ra) == pages_of(src) and ta == tb, f"{name}: {pages_of(src)} trang, poppler vẽ GIỐNG TỪNG ĐIỂM ẢNH và cùng văn bản với tệp gốc")
print("== thử âm tính (bộ kiểm không được 'luôn đạt') ==")
src, out, _ = OUTS["ảnh quét 5 trang (Pillow)"]; data = open(out, "rb").read()
m = re.search(rb"/L (\d+)", data); bad = data[:m.start(1)] + str(int(m.group(1)) + 1).encode() + data[m.end(1):]
open(P("bad_L.pdf"), "wb").write(bad); r = run("qpdf", "--check-linearization", P("bad_L.pdf"))
check("no linearization errors" not in (r.stdout + r.stderr).lower() and not pikepdf.open(P("bad_L.pdf")).is_linearized, "đổi /L (độ dài tệp) thêm 1 -> qpdf KHÔNG còn coi là tuyến tính hoá (nó đối chiếu /L với độ dài thật; ở tệp đạt thì /L khớp từng byte)")
s = data.index(b"/Filter /FlateDecode /S"); a0 = data.index(b"stream\n", s) + 7; flip = bytearray(data); flip[a0 + 3] ^= 0xFF
open(P("bad_hint.pdf"), "wb").write(bytes(flip)); r = run("qpdf", "--check-linearization", P("bad_hint.pdf"))
check(r.returncode != 0 or "no linearization errors" not in (r.stdout + r.stderr).lower(), "lật một byte trong luồng gợi ý -> qpdf TỪ CHỐI (bảng gợi ý được so với dữ liệu thật)")
q = pikepdf.open(src); q.save(P("plain.pdf")); r = run("qpdf", "--check-linearization", P("plain.pdf"))
check("not linearized" in (r.stdout + r.stderr).lower() or not pikepdf.open(P("plain.pdf")).is_linearized, "tệp chưa tuyến tính hoá được qpdf nhận ra là CHƯA tuyến tính hoá (không báo đạt nhầm)")
shutil.rmtree(tmp, ignore_errors=True)
print("\nTAT CA DAT" if not FAILS else f"\n{len(FAILS)} LOI"); sys.exit(1 if FAILS else 0)
