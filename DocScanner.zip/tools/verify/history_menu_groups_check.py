"""Menu nhấn giữ một tệp ở Lịch sử, chia nhóm (phiên 23, mục 4.55): mọi hành động trong `showHistoryItemMenu` phải có mặt trong `HISTORY_ACTION_GROUPS` (nếu quên, hành động mới
âm thầm rơi vào nhóm "Công cụ cho tài liệu"), mỗi mục trong bảng phải còn là một hành động thật (không để mục chết khi gỡ tính năng), nhóm nằm trong 0..4, cả 5 nhóm đều có ít nhất
một hành động, và các chuỗi tên nhóm / hành động đều có trong strings.xml.
PHẦN HAI (4.60): danh sách công cụ của nút Sửa trong trình đọc PDF (`showPdfTools`) phải khớp bảng `READER_TOOL_GROUPS`: mọi công cụ có nhóm, không mục chết, đủ 6 nhóm, đủ chuỗi,
và mọi hàm mà nó gọi phải tồn tại trong MainActivity.  `--selftest` kiểm chính logic này."""
import os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..", "app", "src", "main")

def parse(kt):
    a = kt.index("private fun showHistoryItemMenu(file: File) {")
    b = kt.index("private val FLAT_MENU_MAX")
    actions = re.findall(r"actions\.add\(getString\(R\.string\.(\w+)\)", kt[a:b])
    m = re.search(r"HISTORY_ACTION_GROUPS: Map<Int, Int> = mapOf\((.*?)\n    \)", kt, re.S)
    if not m: raise SystemExit("LOI: không thấy HISTORY_ACTION_GROUPS")
    groups = {k: int(v) for k, v in re.findall(r"R\.string\.(\w+) to (\d+)", m.group(1))}
    return actions, groups

def judge(actions, groups, strings):
    errs = []
    for k in sorted(set(actions) - set(groups)): errs.append(f"hành động '{k}' chưa được gán nhóm")
    for k in sorted(set(groups) - set(actions)): errs.append(f"'{k}' có trong bảng nhóm nhưng không còn là hành động nào")
    for k, g in groups.items():
        if not 0 <= g <= 4: errs.append(f"'{k}' ở nhóm {g} ngoài 0..4")
    for g in range(5):
        if g not in groups.values(): errs.append(f"nhóm {g} không có hành động nào")
    for k in list(actions) + ["history_group_organize", "history_group_read", "history_group_convert", "history_group_tools", "history_group_extract"]:
        if k not in strings: errs.append(f"chuỗi '{k}' không có trong strings.xml")
    return errs

def parse_reader(kt):
    a = kt.index("private fun showPdfTools(")
    b = kt.index("/** What a tap on a history file does:")
    body = kt[a:b]
    keys = re.findall(r"tools\.add\(getString\(R\.string\.(\w+)\)", body)
    m = re.search(r"READER_TOOL_GROUPS: Map<Int, Int> = mapOf\((.*?)\n    \)", kt, re.S)
    if not m: raise SystemExit("LOI: không thấy READER_TOOL_GROUPS")
    groups = {k: int(v) for k, v in re.findall(r"R\.string\.(\w+) to (\d+)", m.group(1))}
    calls = sorted(set(re.findall(r"\{ (?:askOcrScript \{ )?(\w+)\(", body)) - {"startActivity", "openPdfIn"})
    declared = set(re.findall(r"private fun (\w+)\(", kt))
    return keys, groups, calls, declared

def judge_reader(keys, groups, calls, declared, strings, group_names):
    errs = []
    if len(keys) != len(set(keys)): errs.append("showPdfTools thêm trùng một công cụ: " + ", ".join(sorted({k for k in keys if keys.count(k) > 1})))
    for k in sorted(set(keys) - set(groups)): errs.append(f"công cụ '{k}' của trình đọc chưa được gán nhóm")
    for k in sorted(set(groups) - set(keys)): errs.append(f"'{k}' có trong READER_TOOL_GROUPS nhưng showPdfTools không thêm")
    for g in range(6):
        if g not in groups.values(): errs.append(f"nhóm {g} của trình đọc không có công cụ nào")
    for k, g in groups.items():
        if not 0 <= g <= 5: errs.append(f"'{k}' ở nhóm {g} ngoài 0..5")
    for k in list(keys) + list(group_names):
        if k not in strings: errs.append(f"chuỗi '{k}' không có trong strings.xml")
    for c in calls:
        if c not in declared: errs.append(f"showPdfTools gọi {c}() nhưng MainActivity không có hàm đó")
    return errs

def selftest():
    ok = True
    base_a = ["a", "b", "c", "d", "e"]; base_g = {"a": 0, "b": 1, "c": 2, "d": 3, "e": 4}
    names = {"history_group_organize", "history_group_read", "history_group_convert", "history_group_tools", "history_group_extract"}
    def case(name, errs, want):
        nonlocal ok
        good = bool(errs) == want; ok &= good; print(("ok   " if good else "LOI  ") + name)
    case("đủ và hợp lệ -> không lỗi", judge(base_a, base_g, set(base_a) | names), False)
    case("hành động mới chưa có nhóm -> LỖI", judge(base_a + ["f"], base_g, set(base_a + ["f"]) | names), True)
    case("mục chết trong bảng -> LỖI", judge(base_a, {**base_g, "z": 1}, set(base_a) | names), True)
    case("nhóm ngoài 0..4 -> LỖI", judge(base_a, {**base_g, "e": 7}, set(base_a) | names), True)
    case("một nhóm trống -> LỖI", judge(base_a[:4], {k: v for k, v in base_g.items() if k != "e"}, set(base_a) | names), True)
    case("thiếu chuỗi -> LỖI", judge(base_a, base_g, set(base_a)), True)
    rg = {"a": 0, "b": 1, "c": 2, "d": 3, "e": 4, "f": 5}; rk = list(rg)
    gn = ["tool_group_edit", "tool_group_secure", "history_group_tools", "history_group_convert", "history_group_read", "history_group_extract"]
    st = set(rk) | set(gn); decl = {"f1", "f2"}
    def rcase(name, errs, want):
        nonlocal ok
        good = bool(errs) == want; ok &= good; print(("ok   " if good else "LOI  ") + name)
    rcase("trình đọc: đủ và hợp lệ -> không lỗi", judge_reader(rk, rg, ["f1"], decl, st, gn), False)
    rcase("trình đọc: công cụ mới chưa có nhóm -> LỖI", judge_reader(rk + ["z"], rg, [], decl, st | {"z"}, gn), True)
    rcase("trình đọc: mục chết trong bảng -> LỖI", judge_reader(rk, {**rg, "z": 1}, [], decl, st, gn), True)
    rcase("trình đọc: thêm trùng một công cụ -> LỖI", judge_reader(rk + ["a"], rg, [], decl, st, gn), True)
    rcase("trình đọc: một nhóm trống -> LỖI", judge_reader(rk[:5], {k: v for k, v in rg.items() if k != "f"}, [], decl, st, gn), True)
    rcase("trình đọc: gọi hàm không tồn tại -> LỖI", judge_reader(rk, rg, ["ghost"], decl, st, gn), True)
    rcase("trình đọc: thiếu chuỗi -> LỖI", judge_reader(rk, rg, [], decl, set(rk), gn), True)
    print(); print("TAT CA DAT" if ok else "CO LOI"); return 0 if ok else 1

def main():
    if "--selftest" in sys.argv: return selftest()
    kt = open(os.path.join(ROOT, "java", "com", "example", "docscanner", "MainActivity.kt"), encoding="utf-8").read()
    strings = set(re.findall(r'<string name="(\w+)"', open(os.path.join(ROOT, "res", "values", "strings.xml"), encoding="utf-8").read()))
    actions, groups = parse(kt)
    errs = judge(actions, groups, strings)
    for e in errs: print("LOI  " + e)
    per = [sum(1 for v in groups.values() if v == g) for g in range(5)]
    print(f"{len(actions)} hành động, chia nhóm (tổ chức / đọc / chuyển đổi / công cụ / trích xuất): {per}")
    keys, rgroups, calls, declared = parse_reader(kt)
    gnames = ["tool_group_edit", "tool_group_secure", "history_group_tools", "history_group_convert", "history_group_read", "history_group_extract"]
    rerrs = judge_reader(keys, rgroups, calls, declared, strings, gnames)
    for e in rerrs: print("LOI  " + e)
    rper = [sum(1 for v in rgroups.values() if v == g) for g in range(6)]
    print(f"trình đọc PDF: {len(keys)} công cụ, chia nhóm (sửa / ký / tài liệu / chuyển đổi / đọc / trích xuất): {rper}; gọi {len(calls)} hàm đều có trong MainActivity")
    errs = errs + rerrs
    print("TAT CA DAT" if not errs else f"CO {len(errs)} LOI"); return 1 if errs else 0
if __name__ == "__main__": sys.exit(main())
