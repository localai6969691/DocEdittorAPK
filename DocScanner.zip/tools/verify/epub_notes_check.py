"""EpubNotes (phiên 23, mục 4.50): tô sáng, đánh dấu trang và vị trí đọc của MỘT cuốn EPUB (PDF C5 / C6).
Bản Java EpubNotesCheck.java (cùng thuật toán với EpubNotes.kt) so với MỘT MÔ HÌNH ĐỐI CHỨNG ĐỘC LẬP viết bằng Python theo cách khác hẳn:
mỗi đoạn là một MẶT NẠ từng đơn vị UTF-16 (True = đang tô sáng), nên "gộp vùng chồng / kề nhau" và "cắt / tách đôi khi xoá" là hệ quả tự nhiên chứ không
phải một bản chép lại thuật toán khoảng. Kiểm:
  - dấu vân tay: CRC-32 + đếm đoạn = bản đối chứng (zlib + struct) trên 300 cuốn ngẫu nhiên (có emoji, cặp thay thế lẻ); đổi một chữ / dời một đoạn / dời ranh giới chương /
    đổi chỗ hai chương / thêm đoạn rỗng đều đổi dấu vân tay;
  - tô sáng: 700 phiên ngẫu nhiên x tới 25 thao tác (thêm / xoá vùng / xoá cả vùng) trên văn bản có NBSP, tab, xuống dòng, U+2003, U+2028, U+0085 (KHÔNG phải khoảng trắng của Java), emoji,
    dấu tách rời, cặp thay thế lẻ; sau MỖI thao tác danh sách = các đoạn liên tục của mặt nạ, theo thứ tự đọc; không bao giờ cắt đôi emoji; vùng toàn khoảng trắng không thêm gì;
  - trần 5 000 ghi chú: thêm vùng rời thứ 5 001 bị từ chối, vùng gộp vào vùng có sẵn vẫn được; đánh dấu trang cũng bị chặn ở trần;
  - dấu trang: bật / tắt, thứ tự đọc (400 phiên);
  - mã hoá: văn bản đúng định dạng khai báo (bản dựng độc lập), đọc lại đúng; 900 tệp bị phá ngẫu nhiên (xoá / nhân đôi dòng, đổi ký tự, cắt cụt, số âm, số thừa / thiếu, CRLF, dòng rác,
    chương ngoài sách, chỉ số tràn) KHÔNG làm Java lỗi và cho đúng kết quả của bản đọc độc lập; sai dấu vân tay -> STALE + rỗng; thiếu / sai dòng đầu -> rỗng;
  - trích đoạn (snippet) và "Chép ghi chú" (render) = bản độc lập;
  - TỆP THẬT: lưu -> đọc lại, không để lại .tmp, tên tệp an toàn; sách đã đổi -> tệp cũ được đổi tên thành .stale (không xoá), tệp mới trống; tệp không có -> rỗng;
  - THỬ ÂM TÍNH (bài kiểm có răng): vân tay ghép chuỗi không độ dài bị trùng ("ab","c") = ("a","bc"); không gộp vùng kề nhau để lại hai mảnh; cắt không né cặp thay thế tạo nửa emoji;
    mô hình không cắt khoảng trắng đầu / cuối cho kết quả khác.
Chạy: python3 epub_notes_check.py   (cần java; ~40 giây)
"""
import os, random, re, struct, subprocess, sys, tempfile, unicodedata, zlib

HERE = os.path.dirname(os.path.abspath(__file__)); JAVA = os.path.join(HERE, "EpubNotesCheck.java")
ENV = dict(os.environ, LC_ALL="C.UTF-8")
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

def hexs(s):
    b = s.encode("utf-16-le", "surrogatepass")
    return "".join(f"{int.from_bytes(b[i:i+2], 'little'):04x}" for i in range(0, len(b), 2))
def unhexs(h):
    return b"".join(int(h[i:i+4], 16).to_bytes(2, "little") for i in range(0, len(h), 4)).decode("utf-16-le", "surrogatepass")
def units(s):
    b = s.encode("utf-16-le", "surrogatepass")
    return [int.from_bytes(b[i:i+2], "little") for i in range(0, len(b), 2)]

def run_java(lines):
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", JAVA], input=("\n".join(lines) + "\n").encode("ascii"), capture_output=True, env=ENV)
    if r.returncode != 0: raise RuntimeError(r.stderr.decode(errors="replace")[-2500:])
    return r.stdout.decode("utf-8").split("\n")

def book_cmds(book, titles=None):
    out = ["BOOK"]
    for i, ch in enumerate(book):
        out.append("C")
        if titles: out.append("T " + hexs(titles[i]))
        for p in ch: out.append("P " + hexs(p))
    return out

# ---------------- MÔ HÌNH ĐỐI CHỨNG ----------------
def is_space_unit(u):
    if u in (9, 10, 11, 12, 13, 28, 29, 30, 31): return True
    return unicodedata.category(chr(u)) in ("Zs", "Zl", "Zp")     # gồm NBSP, U+2003, U+2028; KHÔNG gồm U+0085

def from_units(us):
    return b"".join(x.to_bytes(2, "little") for x in us).decode("utf-16-le", "surrogatepass")

def is_hi(u): return 0xD800 <= u <= 0xDBFF
def is_lo(u): return 0xDC00 <= u <= 0xDFFF

def ref_snap(u, s, e):
    n = len(u); s = max(0, min(s, n)); e = max(0, min(e, n))
    if 0 < s < n and is_lo(u[s]) and is_hi(u[s - 1]): s -= 1
    if 0 < e < n and is_lo(u[e]) and is_hi(u[e - 1]): e += 1
    return s, e

class Model:
    def __init__(self, book): self.book = book; self.mask = {}; self.marks = set(); self.last = None
    def m(self, c, p):
        k = (c, p)
        if k not in self.mask: self.mask[k] = [False] * len(units(self.book[c][p]))
        return self.mask[k]
    def add(self, c, p, s, e, trim=True, snap=True):
        u = units(self.book[c][p]); a, b = min(s, e), max(s, e)
        a, b = ref_snap(u, a, b) if snap else (max(0, min(a, len(u))), max(0, min(b, len(u))))
        if trim:
            while a < b and is_space_unit(u[a]): a += 1
            while b > a and is_space_unit(u[b - 1]): b -= 1
        if a >= b: return
        if len(self.runs()) >= 5000 and not self.touches(c, p, a, b): return
        mk = self.m(c, p)
        for i in range(a, b): mk[i] = True
    def touches(self, c, p, a, b):
        mk = self.m(c, p)
        return any(mk[i] for i in range(max(0, a - 1), min(len(mk), b + 1)))
    def erase(self, c, p, s, e):
        u = units(self.book[c][p]); a, b = ref_snap(u, min(s, e), max(s, e))
        mk = self.m(c, p)
        for i in range(a, b): mk[i] = False
    def runs(self):
        out = []
        for (c, p) in sorted(self.mask):
            mk = self.mask[(c, p)]; i = 0
            while i < len(mk):
                if mk[i]:
                    j = i
                    while j < len(mk) and mk[j]: j += 1
                    out.append((c, p, i, j)); i = j
                else: i += 1
        return out
    def remove_whole(self, c, p, s, e):
        if (c, p, s, e) in self.runs():
            mk = self.m(c, p)
            for i in range(s, e): mk[i] = False
    def toggle(self, c, p):
        if (c, p) in self.marks: self.marks.discard((c, p))
        elif len(self.marks) < 5000: self.marks.add((c, p))
    def dump(self):
        out = [f"H {c} {p} {s} {e}" for (c, p, s, e) in self.runs()]
        out += [f"B {c} {p}" for (c, p) in sorted(self.marks)]
        if self.last: out.append(f"L {self.last[0]} {self.last[1]}")
        return out

def ref_fp(book):
    crc = 0; n = 0
    for ch in book:
        crc = zlib.crc32(b"\x01" + struct.pack(">i", len(ch)), crc)
        for p in ch:
            b = p.encode("utf-8", "replace")
            crc = zlib.crc32(struct.pack(">i", len(b)) + b, crc); n += 1
    return f"{crc:08x}-{n}"

HEADER = "DOCSCANNER-EPUB-NOTES 1"
def ref_encode(fp, model):
    out = [HEADER, "F " + fp]
    if model.last: out.append(f"L {model.last[0]} {model.last[1]}")
    out += [f"B {c} {p}" for (c, p) in sorted(model.marks)]
    out += [f"H {c} {p} {s} {e}" for (c, p, s, e) in model.runs()]
    return "\n".join(out) + "\n"

def ref_trim(s):
    u = units(s); a, b = 0, len(u)
    while a < b and is_space_unit(u[a]): a += 1
    while b > a and is_space_unit(u[b - 1]): b -= 1
    return from_units(u[a:b])

def ref_int(tok):
    if not re.fullmatch(r"[+-]?\d+", tok): return None
    try: v = int(tok)
    except ValueError: return None
    return v if -2**31 <= v < 2**31 else None

def ref_ints(parts, count):
    if len(parts) != 1 + count: return None
    r = []
    for t in parts[1:]:
        v = ref_int(t)
        if v is None or v < 0: return None
        r.append(v)
    return r

def ref_decode(text, book, fp):
    """-> ('EMPTY'|'STALE'|'OK', Model)"""
    lines = text.split("\n")
    if ref_trim(lines[0]) != HEADER: return "EMPTY", Model(book)
    fpl = None
    for l in lines:
        if l.startswith("F "): fpl = ref_trim(l[2:]); break
    if fpl is None: return "EMPTY", Model(book)
    if fpl != fp: return "STALE", Model(book)
    m = Model(book)
    for raw in lines[1:]:
        line = ref_trim(raw)
        if len(line) < 3: continue
        parts = line.split(" ")
        if parts[0] == "L":
            v = ref_ints(parts, 2)
            if v and v[0] < len(book) and v[1] < len(book[v[0]]): m.last = (v[0], v[1])
        elif parts[0] == "B":
            v = ref_ints(parts, 2)
            if v and v[0] < len(book) and v[1] < len(book[v[0]]): m.marks.add((v[0], v[1]))
        elif parts[0] == "H":
            v = ref_ints(parts, 4)
            if v and v[0] < len(book) and v[1] < len(book[v[0]]):
                n = len(units(book[v[0]][v[1]])); e = min(v[3], n)
                if v[2] < e: m.add(v[0], v[1], v[2], e)
    return "OK", m

def ref_snippet(text, mx):
    u = units(text); out = []; last_space = True
    for x in u:
        if is_space_unit(x):
            if not last_space: out.append(32)
            last_space = True
        else: out.append(x); last_space = False
    while out and is_space_unit(out[0]): out.pop(0)
    while out and is_space_unit(out[-1]): out.pop()
    if len(out) <= mx: return from_units(out)
    cut = mx
    if cut > 0 and is_lo(out[cut]) and is_hi(out[cut - 1]): cut -= 1
    out = out[:cut]
    while out and is_space_unit(out[-1]): out.pop()
    return from_units(out) + "\u2026"

def ref_render(book, titles, m):
    def label(n, t): return f"Ch{n}:{ref_trim(t)}"
    out = ["HEAD"]
    if m.marks:
        out += ["", "BM"]
        for (c, p) in sorted(m.marks): out.append("\u2022 " + label(c + 1, titles[c]) + ": " + ref_snippet(book[c][p], 120))
    runs = m.runs()
    if runs:
        out += ["", "HL"]
        for (c, p, s, e) in runs:
            seg = from_units(units(book[c][p])[s:e])
            out.append("\u2022 " + label(c + 1, titles[c]) + ": " + ref_snippet(seg, 400))
    return "\n".join(out) + "\n"

# ---------------- dữ liệu ngẫu nhiên ----------------
ALPHA = ["a", "b", "c", "word", "Nguyễn", " ", " ", " ", "\u00a0", "\t", "\n", "\u2003", "\u2028", "\u0085", "\x1f", "😀", "e\u0301", "\ud800", "đ", "中", "-", "."]
def rand_text(rng, lo=0, hi=22):
    return "".join(rng.choice(ALPHA) for _ in range(rng.randint(lo, hi)))
def rand_book(rng):
    return [[rand_text(rng) for _ in range(rng.randint(1, 4))] for _ in range(rng.randint(1, 3))]

# ===================================================================================================
rng = random.Random(23)

# ---- 1. dấu vân tay ----
books = [rand_book(rng) for _ in range(300)]
cmds = []
for b in books: cmds += book_cmds(b) + ["FP"]
out = [l for l in run_java(cmds) if l]
check(len(out) == len(books) and all(o == ref_fp(b) for o, b in zip(out, books)), f"dấu vân tay: {len(books)} cuốn ngẫu nhiên khớp bản CRC-32 độc lập (zlib + struct), cả cặp thay thế lẻ")

base = [["Alpha", "Beta"], ["Gamma"]]
variants = {
    "đổi một chữ": [["Alphb", "Beta"], ["Gamma"]],
    "dời một đoạn sang chương sau": [["Alpha"], ["Beta", "Gamma"]],
    "đổi chỗ hai chương": [["Gamma"], ["Alpha", "Beta"]],
    "thêm đoạn rỗng": [["Alpha", "Beta", ""], ["Gamma"]],
    "đảo hai đoạn": [["Beta", "Alpha"], ["Gamma"]],
    "gộp chương": [["Alpha", "Beta", "Gamma"]],
}
cmds = book_cmds(base) + ["FP"]
for v in variants.values(): cmds += book_cmds(v) + ["FP"]
out = [l for l in run_java(cmds) if l]
check(len(set(out)) == len(out), "dấu vân tay: " + ", ".join(variants) + " đều cho giá trị KHÁC gốc và khác nhau")

# ---- 2. tô sáng ngẫu nhiên so với mô hình mặt nạ ----
def session(rng):
    book = rand_book(rng); m = Model(book); cmds = book_cmds(book); expect = []
    for _ in range(rng.randint(1, 25)):
        c = rng.randrange(len(book)); p = rng.randrange(len(book[c])); n = len(units(book[c][p]))
        a = rng.randint(-2, n + 2); b = rng.randint(-2, n + 2)
        kind = rng.choice(["add", "add", "add", "erase", "remove"])
        if kind == "add": cmds.append(f"ADD {c} {p} {a} {b}"); m.add(c, p, a, b)
        elif kind == "erase": cmds.append(f"ERASE {c} {p} {a} {b}"); m.erase(c, p, a, b)
        else:
            runs = m.runs()
            if runs:
                (c, p, s, e) = rng.choice(runs); cmds.append(f"REMOVE {c} {p} {s} {e}"); m.remove_whole(c, p, s, e)
            else: cmds.append("REMOVE 0 0 0 1")
        cmds.append("DUMP"); expect.append(m.dump())
    return cmds, expect, book

cmds = []; expects = []; sessions = []
for _ in range(700):
    c, e, bk = session(rng); cmds += c; expects += e; sessions.append(bk)
raw = run_java(cmds)
blocks = []; cur = []
for l in raw:
    if l == "END": blocks.append(cur); cur = []
    elif l: cur.append(l)
bad = [i for i, (x, y) in enumerate(zip(blocks, expects)) if x != y]
check(len(blocks) == len(expects) and not bad, f"tô sáng: {len(expects)} trạng thái sau từng thao tác (700 phiên) = các đoạn liên tục của mặt nạ" + (f" - LỆCH ở {bad[:3]}: {blocks[bad[0]]} vs {expects[bad[0]]}" if bad else ""))

def one(book, ops):
    cmds = book_cmds(book)
    for op in ops: cmds.append(op)
    cmds.append("DUMP")
    r = run_java(cmds); return [l for l in r if l and l != "END"]

check(one([["abcdef"]], ["ADD 0 0 0 3", "ADD 0 0 3 6"]) == ["H 0 0 0 6"], "ví dụ: [0,3) rồi [3,6) (kề nhau) -> MỘT vùng [0,6)")
check(one([["abcdefghij"]], ["ADD 0 0 2 5", "ADD 0 0 4 9"]) == ["H 0 0 2 9"], "ví dụ: [2,5) và [4,9) chồng nhau -> [2,9)")
check(one([["abcdefghij"]], ["ADD 0 0 6 8", "ADD 0 0 1 3"]) == ["H 0 0 1 3", "H 0 0 6 8"], "ví dụ: hai vùng rời giữ nguyên và xếp theo thứ tự đọc")
check(one([["  word  "]], ["ADD 0 0 0 8"]) == ["H 0 0 2 6"], "ví dụ: chọn cả khoảng trắng hai đầu -> chỉ tô \"word\"")
check(one([[" \u00a0\t\n "]], ["ADD 0 0 0 5"]) == [], "ví dụ: vùng chọn toàn khoảng trắng (có NBSP) không thêm gì")
check(one([["abcdefghij"]], ["ADD 0 0 1 9", "ERASE 0 0 4 6"]) == ["H 0 0 1 4", "H 0 0 6 9"], "ví dụ: xoá giữa một vùng -> tách đôi")
check(one([["abcdefghij"]], ["ADD 0 0 1 9", "ERASE 0 0 0 5"]) == ["H 0 0 5 9"], "ví dụ: xoá phủ đầu vùng -> cắt đầu")
check(one([["abcdefghij"]], ["ADD 0 0 1 9", "ERASE 0 0 0 20"]) == [], "ví dụ: xoá phủ cả vùng (chỉ số ngoài đoạn bị kẹp) -> hết")
check(one([["a\U0001F600b"]], ["ADD 0 0 2 4"]) == ["H 0 0 1 4"], "ví dụ: chọn bắt đầu giữa emoji -> lùi về đầu emoji (không cắt đôi)")
check(one([["a\U0001F600b"]], ["ADD 0 0 0 2"]) == ["H 0 0 0 3"], "ví dụ: chọn kết thúc giữa emoji -> tiến tới cuối emoji")
check(one([["abc", "def"], ["ghi"]], ["TOG 1 0", "TOG 0 1", "TOG 0 0", "TOG 0 1"]) == ["B 0 0", "B 1 0"], "ví dụ: dấu trang bật / tắt, xếp theo thứ tự đọc")

# ---- 3. trần ----
book = [["a" * 20100]]
cmds = book_cmds(book)
for i in range(5001): cmds.append(f"ADD 0 0 {4*i} {4*i+1}")       # mỗi vùng 1 chữ, cách nhau (4*i .. ) rời nhau
cmds.append("ADD 0 0 1 3")        # chạm vào vùng đầu tiên [0,1) -> gộp, được phép dù đã đủ trần
cmds.append("DUMP")
raw = [l for l in run_java(cmds) if l and l != "END"]
check(len(raw) == 5000 and raw[0] == "H 0 0 0 3", f"trần: 5 001 vùng rời -> giữ 5 000; vùng chạm vùng có sẵn vẫn được gộp (có {len(raw)}, đầu = {raw[0] if raw else None})")
cmds = book_cmds([["x"] * 5100])
for i in range(5001): cmds.append(f"TOG 0 {i}")
cmds.append("TOG 0 0"); cmds.append("TOG 0 5001"); cmds.append("DUMP")
raw = [l for l in run_java(cmds) if l and l != "END"]
check(len(raw) == 5000 and "B 0 0" not in raw and "B 0 5001" in raw, f"trần: dấu trang thứ 5 001 bị từ chối; bỏ một dấu cũ thì dấu mới thêm được (có {len(raw)})")

# ---- 4. dấu trang ngẫu nhiên ----
cmds = []; expects = []
for _ in range(400):
    book = [["p"] * rng.randint(1, 5) for _ in range(rng.randint(1, 4))]; m = Model(book); cmds += book_cmds(book)
    for _ in range(rng.randint(1, 20)):
        c = rng.randrange(len(book)); p = rng.randrange(len(book[c])); cmds += [f"TOG {c} {p}", "DUMP"]; m.toggle(c, p); expects.append(m.dump())
raw = run_java(cmds); blocks = []; cur = []
for l in raw:
    if l == "END": blocks.append(cur); cur = []
    elif l: cur.append(l)
check(blocks == expects, f"dấu trang: {len(expects)} trạng thái sau bật / tắt = tập có thứ tự (400 phiên)")

# ---- 5. mã hoá, giải mã, phá hoại ----
def build_state(rng):
    book = rand_book(rng); m = Model(book); cmds = book_cmds(book)
    for _ in range(rng.randint(0, 12)):
        c = rng.randrange(len(book)); p = rng.randrange(len(book[c])); n = len(units(book[c][p]))
        if rng.random() < 0.6: a, b = rng.randint(0, n), rng.randint(0, n); cmds.append(f"ADD {c} {p} {a} {b}"); m.add(c, p, a, b)
        else: cmds.append(f"TOG {c} {p}"); m.toggle(c, p)
    if rng.random() < 0.6:
        c = rng.randrange(len(book)); p = rng.randrange(len(book[c])); cmds.append(f"LAST {c} {p}"); m.last = (c, p)
    return book, m, cmds

cases = [build_state(rng) for _ in range(300)]
cmds = []
for book, m, c in cases: cmds += c + ["ENC"]
out = [l for l in run_java(cmds) if l]
check(len(out) == len(cases) and all(unhexs(o) == ref_encode(ref_fp(b), m) for o, (b, m, _) in zip(out, cases)), "mã hoá: 300 trạng thái -> đúng văn bản khai báo (dòng đầu, F, L, B, H) theo bản dựng độc lập")

cmds = []; expect = []
for book, m, c in cases:
    text = ref_encode(ref_fp(book), m)
    cmds += c + ["DEC " + hexs(text), "DUMP"]; expect.append(("OK", m.dump()))
raw = run_java(cmds); res = []; i = 0
while i < len(raw):
    if raw[i] in ("OK", "STALE"):
        status = raw[i]; i += 1; d = []
        while raw[i] != "END": d.append(raw[i]); i += 1
        res.append((status, d))
    i += 1
check(res == expect, "vòng đi - về: 300 trạng thái mã hoá rồi giải mã = trạng thái cũ (cả L, B, H)")

def mutate(rng, text):
    ls = text.split("\n"); k = rng.choice(["dropline", "dupline", "char", "truncate", "garbage", "neg", "extra", "crlf", "badfp", "nohead", "bigint", "chapter", "plus", "spaces"])
    if k == "dropline" and len(ls) > 1: del ls[rng.randrange(len(ls))]
    elif k == "dupline": i = rng.randrange(len(ls)); ls.insert(i, ls[i])
    elif k == "char":
        t = "\n".join(ls)
        if t:
            i = rng.randrange(len(t)); t = t[:i] + rng.choice("0123456789 -+HBLFx\r\n\t#") + t[i + 1:]
        return t
    elif k == "truncate": return text[: rng.randint(0, len(text))]
    elif k == "garbage": ls.insert(rng.randrange(len(ls) + 1), rng.choice(["???", "H", "H 1 2", "B x y", "L -1 0", "Z 1 2 3 4", "  ", "H 0 0 5 1", "F"]))
    elif k == "neg": ls = [re.sub(r"\b(\d+)\b", lambda mm: "-" + mm.group(1) if rng.random() < 0.3 else mm.group(1), l) if l[:1] in "BHL" else l for l in ls]
    elif k == "extra": ls = [(l + " 7") if l[:1] in "BHL" and rng.random() < 0.4 else l for l in ls]
    elif k == "crlf": return "\r\n".join(ls)
    elif k == "badfp": ls = [("F 00000000-0" if l.startswith("F ") else l) for l in ls]
    elif k == "nohead": ls = ls[1:]
    elif k == "bigint": ls.append("H 0 0 0 99999999999999999999"); ls.append("B 4294967296 0"); ls.append("B 2147483648 0")
    elif k == "chapter": ls.append("B 99 0"); ls.append("H 0 99 0 3"); ls.append("L 0 99")
    elif k == "plus": ls.append("B +0 +0"); ls.append("H 0 0 +0 -0"); ls.append("B 0 -0")
    elif k == "spaces": ls = [l.replace(" ", "  ", 1) if l[:1] in "BHL" and rng.random() < 0.4 else l for l in ls]
    return "\n".join(ls)

cmds = []; expect = []
for _ in range(900):
    book, m, c = rng.choice(cases)
    text = mutate(rng, ref_encode(ref_fp(book), m))
    status, model = ref_decode(text, book, ref_fp(book))
    cmds += book_cmds(book) + ["DEC " + hexs(text), "DUMP"]
    expect.append(("OK" if status != "STALE" else "STALE", model.dump()))
raw = run_java(cmds); res = []; i = 0
while i < len(raw):
    if raw[i] in ("OK", "STALE"):
        status = raw[i]; i += 1; d = []
        while raw[i] != "END": d.append(raw[i]); i += 1
        res.append((status, d))
    i += 1
badi = [i for i, (x, y) in enumerate(zip(res, expect)) if x != y]
check(len(res) == len(expect) and not badi, "tệp bị phá: 900 tệp ngẫu nhiên (xoá / nhân đôi dòng, đổi ký tự, cắt cụt, số âm / thừa / tràn, CRLF, chương ngoài sách) không làm lỗi và = bản đọc độc lập" + (f" - LỆCH {badi[:3]}" if badi else ""))

st = one([["abc"]], ["DEC " + hexs(HEADER + "\nF 12345678-1\nH 0 0 0 2\n")])
check(st == ["STALE"], "sai dấu vân tay -> báo STALE và rỗng")
st = one([["abc"]], ["DEC " + hexs("X\nF " + ref_fp([["abc"]]) + "\nH 0 0 0 2\n")])
check(st == ["OK"], "dòng đầu sai -> rỗng, không báo cũ")
st = one([["abc"]], ["DEC " + hexs(HEADER + "\nH 0 0 0 2\n")])
check(st == ["OK"], "thiếu dòng F -> rỗng, không báo cũ")

# ---- 6. trích đoạn và chép ghi chú ----
cmds = []; expect = []
for _ in range(500):
    t = rand_text(rng, 0, 40); mx = rng.choice([0, 1, 2, 3, 5, 8, 20, 120])
    cmds.append(f"SNIP {mx} " + hexs(t)); expect.append(ref_snippet(t, mx))
out = run_java(cmds)[:-1]
out = [unhexs(l) if l else "" for l in out]
check(out == expect, "trích đoạn: 500 chuỗi ngẫu nhiên (cắt không làm đôi emoji, gộp khoảng trắng, dấu …) = bản độc lập")

cmds = []; expect = []
for _ in range(150):
    book = rand_book(rng); titles = [rand_text(rng, 0, 8) for _ in book]; m = Model(book); cmds += book_cmds(book, titles)
    for _ in range(rng.randint(0, 8)):
        c = rng.randrange(len(book)); p = rng.randrange(len(book[c])); n = len(units(book[c][p]))
        if rng.random() < 0.6: a, b = rng.randint(0, n), rng.randint(0, n); cmds.append(f"ADD {c} {p} {a} {b}"); m.add(c, p, a, b)
        else: cmds.append(f"TOG {c} {p}"); m.toggle(c, p)
    cmds.append("RENDER"); expect.append(ref_render(book, titles, m))
out = [unhexs(l) for l in run_java(cmds) if l]
check(out == expect, "Chép ghi chú: 150 cuốn (nhãn chương, trích đoạn dấu trang, chữ được tô; mục rỗng bị bỏ) = bản độc lập")

# ---- 7. tệp thật ----
with tempfile.TemporaryDirectory() as d:
    book = [["Hello world", "Second para"], ["Third"]]
    cmds = book_cmds(book) + ["ADD 0 0 0 5", "TOG 0 1", "LAST 0 1", "FILE " + d]
    raw = run_java(cmds)
    saved = [l for l in raw if l.startswith("SAVED")][0].split(" ", 4)
    check(saved[1:4] == ["true", "true", "true"] and saved[4] == "My_ Book_x.epub.notes", f"tệp thật: lưu / đọc lại / lưu lại thành công, không còn .tmp, tên an toàn ({saved[4] if len(saved) > 4 else '?'})")
    i = raw.index([l for l in raw if l.startswith("SAVED")][0]); d1 = []
    j = i + 1
    while raw[j] != "END": d1.append(raw[j]); j += 1
    check(d1 == ["H 0 0 0 5", "B 0 1", "L 0 1"], "tệp thật: đọc lại đúng tô sáng, dấu trang, vị trí đọc")
    stale = [l for l in raw if l.startswith("STALE")][0]
    check(stale == "STALE true 0 false true", f"sách đã đổi: tệp cũ được đổi thành .stale (không xoá), notes rỗng ({stale})")
    miss = [l for l in raw if l.startswith("MISSING")][0]
    check(miss == "MISSING false 0", "tệp không có -> rỗng, không báo cũ")
    names = sorted(os.listdir(d))
    check(names == ["My_ Book_x.epub.notes.stale"], f"thư mục sau thử: chỉ còn tệp .stale ({names})")
    txt = open(os.path.join(d, names[0]), encoding="utf-8").read()
    check(txt.startswith(HEADER) and "H 0 0 0 5" in txt and "B 0 1" in txt and "L 0 1" in txt, "tệp .stale giữ nguyên nội dung cũ (dòng đầu, tô sáng, dấu trang, vị trí đọc)")

# ---- 8. THỬ ÂM TÍNH ----
def naive_fp(book): return zlib.crc32("".join("".join(ch) for ch in book).encode("utf-8"))
check(naive_fp([["ab", "c"]]) == naive_fp([["a", "bc"]]) and ref_fp([["ab", "c"]]) != ref_fp([["a", "bc"]]),
      "ÂM TÍNH: vân tay ghép chuỗi không độ dài / ranh giới trùng nhau cho (\"ab\",\"c\") và (\"a\",\"bc\"); bản thật phân biệt được")
r = one([["abcdef"]], ["ADD 0 0 0 3", "ADD 0 0 3 6"])
naive = [(0, 3), (3, 6)]
check(r == ["H 0 0 0 6"] and len(naive) == 2, "ÂM TÍNH: không gộp vùng kề nhau để lại hai mảnh liền nhau (bản thật gộp)")
mn = Model([["a\U0001F600b"]]); mn.add(0, 0, 2, 4, snap=False)
check(mn.dump() != one([["a\U0001F600b"]], ["ADD 0 0 2 4"]), "ÂM TÍNH: cắt không né cặp thay thế tạo nửa emoji (mô hình không-snap khác bản thật)")
mn = Model([["  word  "]]); mn.add(0, 0, 0, 8, trim=False)
check(mn.dump() != one([["  word  "]], ["ADD 0 0 0 8"]), "ÂM TÍNH: không cắt khoảng trắng hai đầu cho vùng tô dài hơn (bản thật cắt)")
nel = one([["a\u0085b"]], ["ADD 0 0 0 3"])
check(nel == ["H 0 0 0 3"], "U+0085 không phải khoảng trắng (như Character.isWhitespace của Java): vùng tô giữ nguyên, không bị tách")

print()
print("TAT CA DAT" if not fails else f"{len(fails)} LOI")
sys.exit(1 if fails else 0)
