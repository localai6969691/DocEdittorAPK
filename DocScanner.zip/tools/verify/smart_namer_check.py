"""Kiểm chứng SmartNamer (phiên 15): gợi ý tên tệp từ văn bản OCR trang đầu, làm sạch tên, tên không trùng.

Bản Python song song của app/.../util/SmartNamer.kt (sanitize, fromText, uniqueName) + HistoryFilter.normalize.
Chạy: python3 smart_namer_check.py
"""
import re, sys, unicodedata, tempfile, os

MAX_LENGTH = 60
TITLE_SCAN_LINES = 20
FORBIDDEN = set('\\/:*?"<>|\n\r\t')
BOILERPLATE = ["cong hoa xa hoi chu nghia", "doc lap", "hanh phuc", "socialist republic", "independence", "freedom"]
TITLE_STARTS = ["hop dong", "bien ban", "don xin", "don de nghi", "don ", "giay ", "hoa don", "quyet dinh", "thong bao",
                "bao cao", "to trinh", "cong van", "phieu ", "chung nhan", "giay phep", "de nghi", "cam ket", "uy quyen",
                "thu moi", "so yeu ly lich", "ly lich", "ke hoach", "bang ", "invoice", "contract", "receipt", "agreement",
                "certificate", "report", "minutes", "statement"]


def normalize(text):
    d = unicodedata.normalize("NFD", text.lower())
    return "".join(c for c in d if unicodedata.category(c) != "Mn").replace("đ", "d")


def sanitize(raw):
    replaced = "".join(" " if c in FORBIDDEN else c for c in raw)
    collapsed = re.sub(r"\s+", " ", replaced).strip().strip(".").strip()
    return collapsed[:MAX_LENGTH].strip().strip(".").strip()


def looks_like_text(line):
    letters = sum(c.isalpha() for c in line)
    non_space = sum(not c.isspace() for c in line)
    return letters >= 4 and letters * 2 >= non_space


def clean_line(line):
    line = line.strip()
    i = 0
    while i < len(line) and not line[i].isalnum():
        i += 1
    return line[i:].strip()


def from_text(text):
    lines = [clean_line(l) for l in text.splitlines()]
    lines = [l for l in lines if l]
    cands = []
    for l in lines[:TITLE_SCAN_LINES]:
        n = normalize(l)
        if looks_like_text(l) and not any(b in n for b in BOILERPLATE):
            cands.append(l)
    titled = next((l for l in cands if any((normalize(l) + " ").startswith(t) for t in TITLE_STARTS) and sum(c.isalpha() for c in l) >= 5), None)
    chosen = titled or (cands[0] if cands else None)
    if chosen is None:
        return None
    name = sanitize(chosen)
    return name or None


def derived_base(original, suffix):
    stem = sanitize(original.rsplit(".", 1)[0] if "." in original else original) or "document"
    return sanitize(stem[:MAX_LENGTH - len(suffix) - 1] + "_" + suffix)


def unique_name(exists, base, ext):
    e = f".{ext}" if ext else ""
    cand, n = base + e, 2
    while exists(cand):
        cand = f"{base} ({n}){e}"; n += 1
    return cand


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    return cond


def main():
    good = True
    good &= check(sanitize('Hợp đồng: thuê/nhà *2026*?') == "Hợp đồng thuê nhà 2026", "sanitize bỏ ký tự cấm, gộp dấu cách")
    good &= check(sanitize("...  ten  ") == "ten", "sanitize bỏ dấu chấm và dấu cách ở hai đầu")
    good &= check(sanitize("a" * 100) == "a" * 60, "sanitize cắt ở 60 ký tự")
    good &= check(sanitize("///") == "", "toàn ký tự cấm -> rỗng")
    good &= check(len(sanitize("Từ " * 40)) <= 60 and not sanitize("Từ " * 40).endswith(" "), "cắt xong không để dấu cách thừa ở cuối")

    vn_header = "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM\nĐộc lập - Tự do - Hạnh phúc\n-----------\nHỢP ĐỒNG THUÊ NHÀ\nSố: 01/2026/HĐTN\nHôm nay, ngày 3 tháng 10 năm 2026"
    good &= check(from_text(vn_header) == "HỢP ĐỒNG THUÊ NHÀ", "bỏ phần quốc hiệu, lấy tiêu đề 'HỢP ĐỒNG THUÊ NHÀ'")
    good &= check(from_text("Công ty ABC\nĐịa chỉ: 12 Lê Lợi\nBIÊN BẢN BÀN GIAO\nNgày 3/10") == "BIÊN BẢN BÀN GIAO", "tiêu đề nằm sau tên công ty vẫn được chọn nhờ từ khoá")
    good &= check(from_text("• Hóa đơn bán hàng\nMã số thuế 0101") == "Hóa đơn bán hàng", "bỏ dấu đầu dòng, nhận 'Hóa đơn'")
    good &= check(from_text("12/10/2026\n0123456789\n-----\nKính gửi Ông Nam\nNội dung chi tiết") == "Kính gửi Ông Nam", "không có từ khoá: lấy dòng chữ đầu tiên (bỏ ngày, mã số, gạch)")
    good &= check(from_text("Invoice #4821\nBill to: ACME") == "Invoice #4821", "tiếng Anh: 'Invoice' (dấu # là hợp lệ trong tên tệp nên được giữ)")
    good &= check(from_text("") is None and from_text("123 456\n---\n789") is None, "không có dòng giống chữ -> None")
    good &= check(from_text("wo\nxyz\nab") is None, "mọi dòng quá ngắn (<4 chữ cái) -> None")
    good &= check(from_text("wo\nhello\nxyz") == "hello", "dòng quá ngắn bị bỏ, lấy dòng đủ dài đầu tiên")
    good &= check(from_text("Giấy khai sinh").startswith("Giấy khai sinh"), "'Giấy ...' là tiêu đề")
    long_title = "HỢP ĐỒNG " + "RẤT DÀI " * 20
    r = from_text(long_title)
    good &= check(r is not None and len(r) <= 60 and r.startswith("HỢP ĐỒNG"), "tiêu đề dài bị cắt còn ≤ 60 ký tự")
    deep = "\n".join(["dòng thường"] * 25 + ["HỢP ĐỒNG Ở DÒNG 26"])
    good &= check(from_text(deep) == "dòng thường", "chỉ xét 20 dòng đầu: tiêu đề ở dòng 26 bị bỏ qua, lấy dòng chữ đầu tiên")
    good &= check(from_text("Số: 01\nCỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM\nĐơn xin nghỉ việc") == "Đơn xin nghỉ việc", "quốc hiệu giữa chừng vẫn bị bỏ")

    good &= check(derived_base("Hợp đồng.pdf", "numbered") == "Hợp đồng_numbered", "derivedBase: bỏ đuôi, thêm hậu tố")
    good &= check(derived_base("a.b.c.pdf", "2up") == "a.b.c_2up", "derivedBase: chỉ bỏ đuôi cuối")
    good &= check(derived_base("noext", "clean") == "noext_clean", "derivedBase: tên không có đuôi")
    good &= check(derived_base(".pdf", "x") == "document_x" or derived_base(".pdf", "x") == "_x" or True, "derivedBase: tên chỉ có đuôi không gây lỗi")
    good &= check(derived_base("///.pdf", "locked") == "document_locked", "derivedBase: tên toàn ký tự cấm -> 'document'")
    long = derived_base("x" * 100 + ".pdf", "watermark")
    good &= check(len(long) <= 60 and long.endswith("_watermark"), "derivedBase: tên dài vẫn ≤ 60 và giữ hậu tố")
    taken = {"a.pdf", "a (2).pdf"}
    good &= check(unique_name(lambda n: n in taken, "a", "pdf") == "a (3).pdf", "trùng tên: a (3).pdf")
    good &= check(unique_name(lambda n: n in taken, "b", "pdf") == "b.pdf", "không trùng: giữ nguyên")
    with tempfile.TemporaryDirectory() as d:
        open(os.path.join(d, "x.pdf"), "w").close()
        good &= check(unique_name(lambda n: os.path.exists(os.path.join(d, n)), "x", "pdf") == "x (2).pdf", "kiểm trên đĩa thật")
    print("TAT CA DAT" if good else "CO LOI")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
