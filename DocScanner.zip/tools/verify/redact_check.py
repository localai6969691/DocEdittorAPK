"""Kiểm chứng PdfRedactor (phiên 15): che thông tin VĨNH VIỄN bằng cách dựng trang thành ảnh có hộp đen đã "nung" vào.

Mô hình Python từng bước giống PdfRedactor.kt (dùng poppler thay cho PdfRenderer, PIL/pikepdf thay cho PdfBox):
  1. phần thuần pixelRect: làm tròn RA NGOÀI, kẹp trong ảnh, đảo toạ độ ngược được, ít nhất 1 điểm ảnh;
  2. đối chứng "che giả": vẽ hình chữ nhật đen đè lên chữ THẬT trong PDF -> pdftotext VẪN trích được chữ bí mật (đó là lý do không dùng cách này);
  3. che thật: lấy hộp của chữ bí mật từ `pdftotext -bbox`, đổi sang tỉ lệ trang, dựng trang ở 200 dpi, tô đen, thay trang bằng ảnh, giữ nguyên các trang khác:
       - pdftotext KHÔNG còn thấy chữ bí mật ở bất kỳ trang nào; không còn chuỗi bí mật trong BẤT KỲ đối tượng/luồng nào của tệp mới (kể cả sau giải nén);
       - các trang không che vẫn còn lớp chữ nguyên vẹn; số trang và khổ trang không đổi;
       - vùng chữ bí mật trong ảnh dựng lại của tệp mới đen kín (>= 99%), còn phần chữ không che vẫn thấy được (trang không bị đen hết).
Chạy: python3 redact_check.py   (cần reportlab, pikepdf, numpy, pillow, pdftoppm, pdftotext)
"""
import math, os, re, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import numpy as np
from PIL import Image
import pikepdf
from reportlab.pdfgen import canvas

W, H = 595.276, 841.89
SECRET = "BIMAT"
NUMBER = "0123456789"


def pixel_rect(f, w, h):
    l = min(max(math.floor(min(f[0], f[2]) * w), 0), w - 1)
    t = min(max(math.floor(min(f[1], f[3]) * h), 0), h - 1)
    r = min(max(math.ceil(max(f[0], f[2]) * w), l + 1), w)
    b = min(max(math.ceil(max(f[1], f[3]) * h), t + 1), h)
    return [l, t, r, b]


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    return cond


def make_source(path):
    c = canvas.Canvas(path, pagesize=(W, H))
    for n in (1, 2, 3):
        c.setFont("Helvetica", 14)
        c.drawString(72, 760, f"Trang {n}: noi dung binh thuong cua van ban")
        c.drawString(72, 700, f"Dong khac o trang {n}")
        if n == 2:
            c.drawString(72, 600, f"So CCCD: {SECRET} {NUMBER}")
            c.drawString(72, 560, "Dia chi: khong che dong nay")
        c.showPage()
    c.save()


def words(path, page):
    out = subprocess.run(["pdftotext", "-f", str(page), "-l", str(page), "-bbox", path, "-"], capture_output=True, text=True).stdout
    res = []
    for m in re.finditer(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">([^<]*)</word>', out):
        res.append((float(m.group(1)), float(m.group(2)), float(m.group(3)), float(m.group(4)), m.group(5)))
    return res


def text_of(path, page=None):
    cmd = ["pdftotext"] + (["-f", str(page), "-l", str(page)] if page else []) + [path, "-"]
    return subprocess.run(cmd, capture_output=True, text=True).stdout


def all_object_bytes(path):
    """Mọi luồng và chuỗi của mọi đối tượng, đã giải nén: để tìm chữ bí mật ở bất kỳ đâu trong tệp."""
    chunks = []
    with pikepdf.open(path) as pdf:
        for obj in pdf.objects:
            try:
                if isinstance(obj, pikepdf.Stream):
                    chunks.append(obj.read_bytes())
                chunks.append(repr(obj).encode("utf-8", "ignore"))
            except Exception:
                pass
    return b"\n".join(chunks)


def main():
    good = True
    # 1. phần thuần
    good &= check(pixel_rect([0.1, 0.2, 0.3, 0.4], 1000, 2000) == [100, 400, 300, 800], "pixelRect: ví dụ tay")
    good &= check(pixel_rect([0.1004, 0.2004, 0.3004, 0.4004], 1000, 2000) == [100, 400, 301, 801], "pixelRect: làm tròn RA NGOÀI (l,t xuống; r,b lên) - không bao giờ để hở mép")
    good &= check(pixel_rect([0.3, 0.4, 0.1, 0.2], 1000, 2000) == [100, 400, 300, 800], "pixelRect: toạ độ ngược (kéo từ phải sang trái) vẫn đúng")
    good &= check(pixel_rect([-0.5, -0.5, 2.0, 2.0], 100, 200) == [0, 0, 100, 200], "pixelRect: tràn ngoài trang bị kẹp")
    good &= check(pixel_rect([0.5, 0.5, 0.5, 0.5], 100, 200) == [50, 100, 51, 101], "pixelRect: hộp rỗng thành ít nhất 1 điểm ảnh")
    good &= check(pixel_rect([1.0, 1.0, 1.0, 1.0], 100, 200) == [99, 199, 100, 200], "pixelRect: sát mép phải-dưới vẫn có 1 điểm ảnh trong ảnh")

    with tempfile.TemporaryDirectory(dir=OUT) as wd:
        src = os.path.join(wd, "src.pdf"); make_source(src)
        good &= check(SECRET in text_of(src, 2) and SECRET not in text_of(src, 1), "PDF nguồn: chữ bí mật chỉ ở trang 2")
        ws = {w[4]: w for w in words(src, 2)}
        secret_box = (min(ws[SECRET][0], ws[NUMBER][0]), min(ws[SECRET][1], ws[NUMBER][1]), max(ws[SECRET][2], ws[NUMBER][2]), max(ws[SECRET][3], ws[NUMBER][3]))
        frac = [secret_box[0] / W, secret_box[1] / H, secret_box[2] / W, secret_box[3] / H]

        # 2. che giả
        fake = os.path.join(wd, "fake.pdf")
        with pikepdf.open(src) as pdf:
            pg = pdf.pages[1]
            x0, y0, x1, y1 = secret_box[0], H - secret_box[3], secret_box[2], H - secret_box[1]
            ops = f"q 0 g {x0} {y0} {x1 - x0} {y1 - y0} re f Q\n".encode()
            pg.Contents = pdf.make_stream(pg.Contents.read_bytes() + b"\n" + ops) if not isinstance(pg.Contents, pikepdf.Array) else pdf.make_stream(b"\n".join(c.read_bytes() for c in pg.Contents) + b"\n" + ops)
            pdf.save(fake)
        good &= check(SECRET in text_of(fake, 2), "ĐỐI CHỨNG che giả (hộp đen đè lên chữ thật): pdftotext VẪN trích được chữ bí mật")

        # 3. che thật
        px_w = int(W * 200 / 72)
        base = os.path.join(wd, "p2")
        subprocess.run(["pdftoppm", "-f", "2", "-l", "2", "-scale-to-x", str(px_w), "-scale-to-y", "-1", "-png", "-singlefile", src, base], check=True)
        img = Image.open(base + ".png").convert("RGB")
        arr = np.array(img)
        l, t, r, b = pixel_rect(frac, arr.shape[1], arr.shape[0])
        arr[t:b, l:r] = 0
        page_png = os.path.join(wd, "p2_redacted.pdf")
        Image.fromarray(arr).save(page_png, "PDF", resolution=arr.shape[1] / W * 72)
        out = os.path.join(wd, "redacted.pdf")
        with pikepdf.open(src) as original, pikepdf.open(page_png) as replacement:
            result = pikepdf.new()
            result.pages.append(original.pages[0])
            result.pages.append(replacement.pages[0])
            result.pages.append(original.pages[2])
            result.save(out)
        good &= check(SECRET not in text_of(out) and NUMBER not in text_of(out), "che thật: pdftotext KHÔNG còn chữ bí mật ở bất kỳ trang nào")
        good &= check(SECRET.encode() not in all_object_bytes(out) and NUMBER.encode() not in all_object_bytes(out), "che thật: chuỗi bí mật không còn trong BẤT KỲ đối tượng/luồng nào của tệp (đã giải nén)")
        good &= check("Trang 1" in text_of(out, 1) and "Trang 3" in text_of(out, 3), "các trang không che giữ nguyên lớp chữ")
        good &= check(text_of(out, 2).strip() == "", "trang đã che thành ảnh: không còn lớp chữ (đúng như đã báo cho người dùng)")
        with pikepdf.open(out) as pdf:
            sizes = [(round(float(p.MediaBox[2]), 1), round(float(p.MediaBox[3]), 1)) for p in pdf.pages]
        good &= check(len(sizes) == 3 and all(abs(s[0] - round(W, 1)) <= 1.5 and abs(s[1] - round(H, 1)) <= 1.5 for s in sizes), f"số trang và khổ trang giữ nguyên {sizes}")
        chk = os.path.join(wd, "chk")
        subprocess.run(["pdftoppm", "-f", "2", "-l", "2", "-r", "72", "-png", "-singlefile", out, chk], check=True)
        got = np.array(Image.open(chk + ".png").convert("L")).astype(int)
        # vùng BÊN TRONG hộp (làm tròn vào trong): các điểm ảnh ở mép hộp ở độ phân giải 72 dpi chỉ phủ một phần nên không tính
        region = got[math.ceil(secret_box[1]):math.floor(secret_box[3]), math.ceil(secret_box[0]):math.floor(secret_box[2])]
        good &= check((region < 40).mean() >= 0.99, f"vùng chữ bí mật trong tệp mới đen kín: {100 * (region < 40).mean():.1f}%")
        other = got[int(H - 566 - 12):int(H - 566 + 6), 72:300]     # dòng "Dia chi" không che (y gốc dưới 560)
        good &= check((got < 100).mean() < 0.2 and (other < 100).sum() > 20, "phần chữ không che vẫn thấy được, trang không bị đen hết")
    print("TAT CA DAT" if good else "CO LOI")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
