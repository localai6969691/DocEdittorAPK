// Bản Java chạy được của DocumentImport (phiên 19, mục 4.47.2): cùng thuật toán, cùng thứ tự với app/.../util/DocumentImport.kt. Dùng bởi doc_import_check.py.
//   java DocImportCheck.java <tệp ca> <tệp ra>
// Mỗi ca một dòng, các trường ngăn bằng TAB, nội dung là hex UTF-8:  MD\t<hex> | HTML\t<hex> | DOCX\t<hex của document.xml> | CSV\t<mã ký tự ngăn>\t<hex> | DET\t<hex> | CH\t<tên dự phòng hex>\t<các khối>
// Ra mỗi ca một dòng. Khối: "kind|level|marker hex|text hex" ngăn bằng ";" ; CSV: ô hex ngăn "," , hàng ngăn ";" ; DET: mã ký tự ; CH: "tiêu đề hex:đoạn hex,đoạn hex;..."
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class DocImportCheck {
    static class Block { String kind, text, marker; int level; Block(String k, int l, String t, String m) { kind = k; level = l; text = t; marker = m; } Block(String k, int l, String t) { this(k, l, t, ""); } }

    // ---- tiện ích giống Kotlin
    static boolean isWs(char c) { return Character.isWhitespace(c) || Character.isSpaceChar(c); }   // Char.isWhitespace của Kotlin (JVM)
    static String ktTrim(String s) { int a = 0, b = s.length(); while (a < b && isWs(s.charAt(a))) a++; while (b > a && isWs(s.charAt(b - 1))) b--; return s.substring(a, b); }
    static boolean isBlank(String s) { for (int i = 0; i < s.length(); i++) if (!isWs(s.charAt(i))) return false; return true; }
    static String trimChar(String s, char ch) { int a = 0, b = s.length(); while (a < b && s.charAt(a) == ch) a++; while (b > a && s.charAt(b - 1) == ch) b--; return s.substring(a, b); }
    static String ktTrimStart(String s) { int a = 0; while (a < s.length() && isWs(s.charAt(a))) a++; return s.substring(a); }
    static String trimEnd(String s) { int b = s.length(); while (b > 0 && isWs(s.charAt(b - 1))) b--; return s.substring(0, b); }
    static List<String> ktLines(String s) { return Arrays.asList(s.split("\r\n|\n|\r", -1)); }
    static String removePrefix(String s, String p) { return s.startsWith(p) ? s.substring(p.length()) : s; }
    static String join(List<String> l, String sep) { return String.join(sep, l); }
    static String hex(String s) { StringBuilder b = new StringBuilder(); for (byte x : s.getBytes(StandardCharsets.UTF_8)) b.append(String.format("%02x", x & 0xff)); return b.toString(); }
    static String unhex(String h) { byte[] b = new byte[h.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return new String(b, StandardCharsets.UTF_8); }
    interface Fn { String f(Matcher m); }
    static String replaceAll(Pattern p, String s, Fn fn) { Matcher m = p.matcher(s); StringBuilder sb = new StringBuilder(); int last = 0; while (m.find()) { sb.append(s, last, m.start()).append(fn.f(m)); last = m.end(); } sb.append(s.substring(last)); return sb.toString(); }
    static String replaceAll(Pattern p, String s, String rep) { return replaceAll(p, s, m -> rep); }

    static final String HTML4_ENTITIES = "AElig:198,Aacute:193,Acirc:194,Agrave:192,Alpha:913,Aring:197,Atilde:195,Auml:196,Beta:914,Ccedil:199,Chi:935,Dagger:8225,Delta:916,ETH:208,Eacute:201,Ecirc:202,Egrave:200,Epsilon:917,Eta:919,Euml:203,Gamma:915,Iacute:205,Icirc:206,Igrave:204,Iota:921,Iuml:207,Kappa:922,Lambda:923,Mu:924,Ntilde:209,Nu:925,OElig:338,Oacute:211,Ocirc:212,Ograve:210,Omega:937,Omicron:927,Oslash:216,Otilde:213,Ouml:214,Phi:934,Pi:928,Prime:8243,Psi:936,Rho:929,Scaron:352,Sigma:931,THORN:222,Tau:932,Theta:920,Uacute:218,Ucirc:219,Ugrave:217,Upsilon:933,Uuml:220,Xi:926,Yacute:221,Yuml:376,Zeta:918,aacute:225,acirc:226,acute:180,aelig:230,agrave:224,alefsym:8501,alpha:945,amp:38,and:8743,ang:8736,aring:229,asymp:8776,atilde:227,auml:228,bdquo:8222,beta:946,brvbar:166,bull:8226,cap:8745,ccedil:231,cedil:184,cent:162,chi:967,circ:710,clubs:9827,cong:8773,copy:169,crarr:8629,cup:8746,curren:164,dArr:8659,dagger:8224,darr:8595,deg:176,delta:948,diams:9830,divide:247,eacute:233,ecirc:234,egrave:232,empty:8709,emsp:8195,ensp:8194,epsilon:949,equiv:8801,eta:951,eth:240,euml:235,euro:8364,exist:8707,fnof:402,forall:8704,frac12:189,frac14:188,frac34:190,frasl:8260,gamma:947,ge:8805,gt:62,hArr:8660,harr:8596,hearts:9829,hellip:8230,iacute:237,icirc:238,iexcl:161,igrave:236,image:8465,infin:8734,int:8747,iota:953,iquest:191,isin:8712,iuml:239,kappa:954,lArr:8656,lambda:955,lang:10216,laquo:171,larr:8592,lceil:8968,ldquo:8220,le:8804,lfloor:8970,lowast:8727,loz:9674,lrm:8206,lsaquo:8249,lsquo:8216,lt:60,macr:175,mdash:8212,micro:181,middot:183,minus:8722,mu:956,nabla:8711,nbsp:160,ndash:8211,ne:8800,ni:8715,not:172,notin:8713,nsub:8836,ntilde:241,nu:957,oacute:243,ocirc:244,oelig:339,ograve:242,oline:8254,omega:969,omicron:959,oplus:8853,or:8744,ordf:170,ordm:186,oslash:248,otilde:245,otimes:8855,ouml:246,para:182,part:8706,permil:8240,perp:8869,phi:966,pi:960,piv:982,plusmn:177,pound:163,prime:8242,prod:8719,prop:8733,psi:968,quot:34,rArr:8658,radic:8730,rang:10217,raquo:187,rarr:8594,rceil:8969,rdquo:8221,real:8476,reg:174,rfloor:8971,rho:961,rlm:8207,rsaquo:8250,rsquo:8217,sbquo:8218,scaron:353,sdot:8901,sect:167,shy:173,sigma:963,sigmaf:962,sim:8764,spades:9824,sub:8834,sube:8838,sum:8721,sup:8835,sup1:185,sup2:178,sup3:179,supe:8839,szlig:223,tau:964,there4:8756,theta:952,thetasym:977,thinsp:8201,thorn:254,tilde:732,times:215,trade:8482,uArr:8657,uacute:250,uarr:8593,ucirc:251,ugrave:249,uml:168,upsih:978,upsilon:965,uuml:252,weierp:8472,xi:958,yacute:253,yen:165,yuml:255,zeta:950,zwj:8205,zwnj:8204";
    static final Map<String, String> NAMED = new HashMap<>();
    static { for (String pair : HTML4_ENTITIES.split(",")) { int i = pair.indexOf(':'); NAMED.put(pair.substring(0, i), new String(Character.toChars(Integer.parseInt(pair.substring(i + 1))))); } NAMED.put("apos", "'"); }
    static final Pattern ENTITY = Pattern.compile("&(#[0-9]{1,7}|#[xX][0-9A-Fa-f]{1,6}|[A-Za-z][A-Za-z0-9]{1,7});");
    static String cp1252(int cp) { String s = new String(new byte[]{(byte) cp}, java.nio.charset.Charset.forName("windows-1252")); return s.equals("\uFFFD") ? new String(Character.toChars(cp)) : s; }
    static String decodeEntities(String s) {
        if (s.indexOf('&') < 0) return s;
        return replaceAll(ENTITY, s, m -> {
            String body = m.group(1);
            if (body.charAt(0) == '#') {
                int cp; try { cp = (body.charAt(1) == 'x' || body.charAt(1) == 'X') ? Integer.parseInt(body.substring(2), 16) : Integer.parseInt(body.substring(1)); } catch (NumberFormatException e) { cp = -1; }
                if (cp >= 0x80 && cp <= 0x9F) return cp1252(cp); return (cp >= 1 && cp <= 0x10FFFF && !(cp >= 0xD800 && cp <= 0xDFFF)) ? new String(Character.toChars(cp)) : m.group(0);
            }
            String v = NAMED.get(body); return v != null ? v : m.group(0);
        });
    }
    static final Pattern WS = Pattern.compile("[ \\t\\u00A0\\r\\n]+");
    static String collapse(String s) { return ktTrim(replaceAll(WS, s, " ")); }

    // ---- mã hoá văn bản
    static final Pattern CHARSET_META = Pattern.compile("charset\\s*=\\s*[\"']?([A-Za-z0-9_:.-]+)", Pattern.CASE_INSENSITIVE);
    static String decodeText(byte[] bytes, boolean sniff) {
        int n = bytes.length;
        if (n >= 3 && (bytes[0] & 0xFF) == 0xEF && (bytes[1] & 0xFF) == 0xBB && (bytes[2] & 0xFF) == 0xBF) return new String(bytes, 3, n - 3, StandardCharsets.UTF_8);
        if (n >= 2 && (bytes[0] & 0xFF) == 0xFF && (bytes[1] & 0xFF) == 0xFE) return new String(bytes, 2, n - 2, StandardCharsets.UTF_16LE);
        if (n >= 2 && (bytes[0] & 0xFF) == 0xFE && (bytes[1] & 0xFF) == 0xFF) return new String(bytes, 2, n - 2, StandardCharsets.UTF_16BE);
        if (sniff) {
            String head = new String(bytes, 0, Math.min(n, 2048), StandardCharsets.ISO_8859_1); Matcher m = CHARSET_META.matcher(head);
            if (m.find()) { try { return new String(bytes, java.nio.charset.Charset.forName(m.group(1))); } catch (Exception e) { /* tiếp tục */ } }
        }
        try { return StandardCharsets.UTF_8.newDecoder().onMalformedInput(java.nio.charset.CodingErrorAction.REPORT).onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT).decode(java.nio.ByteBuffer.wrap(bytes)).toString(); }
        catch (java.nio.charset.CharacterCodingException e) { return new String(bytes, java.nio.charset.Charset.forName("windows-1252")); }
    }
    static byte[] unhexBytes(String h) { byte[] b = new byte[h.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return b; }

    // ---- Markdown
    static final Pattern FENCE = Pattern.compile("^ {0,3}(`{3,}|~{3,})[ \\t]*([^`]*)$");
    static final Pattern ATX = Pattern.compile("^ {0,3}(#{1,6})(?:[ \\t]+(.*?))?(?:[ \\t]+#+)?[ \\t]*$");
    static final Pattern SETEXT = Pattern.compile("^ {0,3}(=+|-+)[ \\t]*$");
    static final Pattern HRULE = Pattern.compile("^ {0,3}([-*_])(?:[ \\t]*\\1){2,}[ \\t]*$");
    static final Pattern LIST_ITEM = Pattern.compile("^( *)([-+*]|[0-9]{1,9}[.)])([ \\t]+)(.*)$");
    static final Pattern TABLE_SEP = Pattern.compile("^ *\\|? *:?-+:? *(?:\\| *:?-+:? *)*\\|? *$");
    static final Pattern QUOTE = Pattern.compile("^ {0,3}>[ >]*");
    static final Pattern IMAGE = Pattern.compile("!\\[([^\\]]*)\\]\\([^)]*\\)");
    static final Pattern LINK = Pattern.compile("\\[([^\\]]*)\\]\\([^)]*\\)");
    static final Pattern REFLINK = Pattern.compile("\\[([^\\]]+)\\]\\[[^\\]]*\\]");
    static final Pattern AUTOLINK = Pattern.compile("<((?:https?://|mailto:)[^>\\s]+)>");
    static final Pattern CODESPAN = Pattern.compile("(`+)([^`]|[^`].*?[^`])\\1(?!`)");
    static final Pattern STRONG_STAR = Pattern.compile("\\*\\*(?=\\S)(.+?)(?<=\\S)\\*\\*");
    static final Pattern STRONG_US = Pattern.compile("(?<![A-Za-z0-9_])__(?=\\S)(.+?)(?<=\\S)__(?![A-Za-z0-9_])");
    static final Pattern EM_STAR = Pattern.compile("\\*(?=[^\\s*])([^*]+?)(?<=[^\\s*])\\*");
    static final Pattern EM_US = Pattern.compile("(?<![A-Za-z0-9_])_(?=[^\\s_])([^_]+?)(?<=[^\\s_])_(?![A-Za-z0-9_])");
    static final Pattern STRIKE = Pattern.compile("~~(?=\\S)(.+?)(?<=\\S)~~");
    static final Pattern HTML_TAG = Pattern.compile("</?[A-Za-z][^>]*>");
    static final Pattern ESCAPED = Pattern.compile("\\\\([!-/:-@\\[-`{-~])");
    static final Pattern FRONT_MATTER_KEY = Pattern.compile("^[A-Za-z0-9_-]+:");
    static final Pattern HARD_BREAK = Pattern.compile("(?: {2,}|\\\\)\\n");

    static String mdInline(String raw) {
        List<String> code = new ArrayList<>();
        String s = replaceAll(CODESPAN, raw, m -> { code.add(ktTrim(m.group(2))); return "\u0000" + (code.size() - 1) + "\u0000"; });
        s = replaceAll(ESCAPED, s, m -> String.valueOf((char) (0xE000 + m.group(1).charAt(0)))); s = replaceAll(IMAGE, s, m -> m.group(1)); s = replaceAll(LINK, s, m -> m.group(1)); s = replaceAll(REFLINK, s, m -> m.group(1)); s = replaceAll(AUTOLINK, s, m -> m.group(1));
        s = replaceAll(STRONG_STAR, s, m -> m.group(1)); s = replaceAll(STRONG_US, s, m -> m.group(1)); s = replaceAll(EM_STAR, s, m -> m.group(1)); s = replaceAll(EM_US, s, m -> m.group(1)); s = replaceAll(STRIKE, s, m -> m.group(1));
        s = replaceAll(HTML_TAG, s, ""); s = decodeEntities(s); { StringBuilder rb = new StringBuilder(); for (int q = 0; q < s.length(); q++) { char c = s.charAt(q); rb.append(c >= 0xE021 && c <= 0xE07E ? (char) (c - 0xE000) : c); } s = rb.toString(); }
        for (int i = 0; i < code.size(); i++) s = s.replace("\u0000" + i + "\u0000", code.get(i));
        return s;
    }
    static String mdText(List<String> lines) {
        String joined = join(lines, "\n");
        String withBreaks = replaceAll(HARD_BREAK, joined + "\n", "\u0001"); if (withBreaks.endsWith("\n")) withBreaks = withBreaks.substring(0, withBreaks.length() - 1);
        String t = replaceAll(WS, mdInline(withBreaks), " ").replace("\u0001", "\n");
        List<String> ls = new ArrayList<>(); for (String l : ktLines(t)) ls.add(ktTrim(l));
        return ktTrim(join(ls, "\n"));
    }
    static boolean isTableRow(String line) { return line.indexOf('|') >= 0; }
    static List<String> splitRow(String line) {
        String t = ktTrim(line); if (t.startsWith("|")) t = t.substring(1);
        if (t.endsWith("|") && !t.endsWith("\\|")) t = t.substring(0, t.length() - 1);
        List<String> cells = new ArrayList<>(); StringBuilder sb = new StringBuilder(); int i = 0;
        while (i < t.length()) {
            char c = t.charAt(i);
            if (c == '\\' && i + 1 < t.length() && t.charAt(i + 1) == '|') { sb.append('|'); i += 2; continue; }
            if (c == '|') { cells.add(sb.toString()); sb.setLength(0); } else sb.append(c);
            i++;
        }
        cells.add(sb.toString());
        List<String> r = new ArrayList<>(); for (String c : cells) r.add(collapse(mdInline(c))); return r;
    }
    static String rowText(String line) { return join(splitRow(line), " | "); }

    static List<Block> blocksFromMarkdown(String source) {
        String text = removePrefix(source, "\uFEFF").replace("\r\n", "\n").replace('\r', '\n');
        if (text.startsWith("---\n") && FRONT_MATTER_KEY.matcher(text.substring(4).split("\n", -1)[0]).find()) { int end = text.indexOf("\n---\n", 3); if (end > 0) text = text.substring(end + 5); }
        String[] lines = text.split("\n", -1);
        List<Block> out = new ArrayList<>(); List<String> para = new ArrayList<>();
        StringBuilder itemText = null; int itemLevel = 0; String itemMarker = ""; List<Integer> offsets = new ArrayList<>();
        boolean afterBlank = false; int i = 0;
        while (i < lines.length) {
            String line = lines[i];
            if (isBlank(line)) { // flushAll
                if (itemText != null) { out.add(new Block("LI", itemLevel, mdText(Arrays.asList(itemText.toString())), itemMarker)); itemText = null; }
                if (!para.isEmpty()) { String t = mdText(para); if (!t.isEmpty()) out.add(new Block("P", 0, t)); para.clear(); }
                afterBlank = true; i++; continue;
            }
            boolean wasBlank = afterBlank; afterBlank = false;
            Matcher fence = FENCE.matcher(line);
            if (fence.find()) {
                flushAll(out, para, itemText, itemLevel, itemMarker); itemText = null; offsets.clear();
                String mark = fence.group(1); List<String> body = new ArrayList<>(); i++;
                while (i < lines.length) { String t = ktTrim(lines[i]); boolean allSame = true; for (int k = 0; k < t.length(); k++) if (t.charAt(k) != mark.charAt(0)) { allSame = false; break; } if (t.length() >= mark.length() && allSame) break; body.add(lines[i]); i++; }
                i++;
                String code = trimEnd(join(body, "\n")); if (!code.isEmpty()) out.add(new Block("CODE", 0, code));
                continue;
            }
            Matcher atx = ATX.matcher(line);
            if (atx.find()) { flushAll(out, para, itemText, itemLevel, itemMarker); itemText = null; offsets.clear(); String g2 = atx.group(2) == null ? "" : atx.group(2); out.add(new Block("H", atx.group(1).length(), collapse(mdInline(g2)))); i++; continue; }
            Matcher setext = SETEXT.matcher(line);
            if (setext.find() && !para.isEmpty() && itemText == null) { String t = mdText(para); para.clear(); if (!t.isEmpty()) out.add(new Block("H", setext.group(1).charAt(0) == '=' ? 1 : 2, collapse(t))); i++; continue; }
            if (HRULE.matcher(line).find()) { flushAll(out, para, itemText, itemLevel, itemMarker); itemText = null; offsets.clear(); i++; continue; }
            if (isTableRow(line) && i + 1 < lines.length && TABLE_SEP.matcher(lines[i + 1]).matches() && lines[i + 1].indexOf('-') >= 0 && lines[i + 1].indexOf('|') >= 0) {
                flushAll(out, para, itemText, itemLevel, itemMarker); itemText = null; offsets.clear();
                out.add(new Block("ROW", 0, rowText(line))); i += 2;
                while (i < lines.length && !isBlank(lines[i]) && isTableRow(lines[i])) { out.add(new Block("ROW", 0, rowText(lines[i]))); i++; }
                continue;
            }
            Matcher li = LIST_ITEM.matcher(line);
            boolean isLi = li.find();
            if (isLi && !(!para.isEmpty() && itemText == null && Character.isDigit(li.group(2).charAt(0)) && !li.group(2).startsWith("1"))) {
                if (itemText != null) { out.add(new Block("LI", itemLevel, mdText(Arrays.asList(itemText.toString())), itemMarker)); itemText = null; }
                if (!para.isEmpty()) { String t = mdText(para); if (!t.isEmpty()) out.add(new Block("P", 0, t)); para.clear(); }
                int indent = li.group(1).length(); String marker = li.group(2);
                int contentOffset = indent + marker.length() + Math.min(li.group(3).length(), 4);
                while (!offsets.isEmpty() && indent < offsets.get(offsets.size() - 1)) offsets.remove(offsets.size() - 1);
                offsets.add(contentOffset); itemLevel = offsets.size();
                itemMarker = Character.isDigit(marker.charAt(0)) ? marker : "\u2022"; itemText = new StringBuilder(li.group(4));
                i++; continue;
            }
            if (QUOTE.matcher(line).find()) {
                if (itemText != null) { out.add(new Block("LI", itemLevel, mdText(Arrays.asList(itemText.toString())), itemMarker)); itemText = null; }
                offsets.clear(); para.add(ktTrimStart(QUOTE.matcher(line).replaceFirst(""))); i++; continue;
            }
            if (itemText != null && !wasBlank) { itemText.append('\n').append(ktTrimStart(line)); i++; continue; }
            if (wasBlank) offsets.clear();
            if (itemText != null) { out.add(new Block("LI", itemLevel, mdText(Arrays.asList(itemText.toString())), itemMarker)); itemText = null; }
            para.add(ktTrimStart(line)); i++;
        }
        flushAll(out, para, itemText, itemLevel, itemMarker);
        return out;
    }
    static void flushAll(List<Block> out, List<String> para, StringBuilder itemText, int itemLevel, String itemMarker) {
        if (itemText != null) out.add(new Block("LI", itemLevel, mdText(Arrays.asList(itemText.toString())), itemMarker));
        if (!para.isEmpty()) { String t = mdText(para); if (!t.isEmpty()) out.add(new Block("P", 0, t)); para.clear(); }
    }

    // ---- HTML
    static final Pattern COMMENT = Pattern.compile("<!--.*?-->", Pattern.DOTALL);
    static final Pattern SKIPPED = Pattern.compile("<(script|style|head|noscript|template)\\b[^>]*>.*?</\\1\\s*>", Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
    static final Pattern TAG = Pattern.compile("<(/?)([A-Za-z][A-Za-z0-9]*)\\b[^>]*?(/?)>");
    static final Pattern HEADING = Pattern.compile("h([1-6])");
    static final Set<String> FLOW = new HashSet<>(Arrays.asList("p", "div", "section", "article", "header", "footer", "blockquote", "figure", "figcaption", "main", "nav", "aside", "address", "dd", "dt", "dl", "form", "fieldset", "hr", "body", "html", "caption"));
    static class HtmlState { StringBuilder buf = new StringBuilder(); String ctx = "P"; int ctxLevel = 0; String liMarker = ""; boolean inPre = false, inCell = false; List<Block> out = new ArrayList<>(); }
    static void hflush(HtmlState s) {
        if (s.inCell) { s.buf.append(' '); return; }
        String t = s.ctx.equals("CODE") ? trimChar(s.buf.toString(), '\n') : ktTrim(collapse(s.buf.toString().replace("\u0001", " \u0001 ")).replace(" \u0001 ", "\n").replace("\u0001", "\n"));
        if (!t.isEmpty()) s.out.add(new Block(s.ctx, s.ctxLevel, t, s.ctx.equals("LI") ? s.liMarker : ""));
        s.buf.setLength(0);
        if (!s.inPre) { s.ctx = "P"; s.ctxLevel = 0; }
    }
    static List<Block> blocksFromHtml(String source) {
        String html = replaceAll(SKIPPED, replaceAll(COMMENT, source, ""), "");
        HtmlState s = new HtmlState(); List<int[]> lists = new ArrayList<>(); List<String> row = null; int pos = 0;
        Matcher m = TAG.matcher(html);
        while (m.find()) {
            if (m.start() > pos) s.buf.append(decodeEntities(html.substring(pos, m.start())));
            pos = m.end();
            boolean closing = m.group(1).equals("/"); String name = m.group(2).toLowerCase();
            Matcher hm = HEADING.matcher(name); boolean heading = hm.matches();
            if (heading) { hflush(s); if (!closing) { s.ctx = "H"; s.ctxLevel = Integer.parseInt(hm.group(1)); } }
            else if (name.equals("br")) s.buf.append(s.inPre ? "\n" : "\u0001");
            else if (name.equals("pre")) { hflush(s); if (!closing) { s.ctx = "CODE"; s.inPre = true; } else { s.ctx = "CODE"; hflush(s); s.inPre = false; s.ctx = "P"; } }
            else if (name.equals("ul") || name.equals("ol")) { hflush(s); if (!closing) lists.add(new int[]{name.equals("ol") ? 1 : 0, 0}); else if (!lists.isEmpty()) lists.remove(lists.size() - 1); }
            else if (name.equals("li")) { hflush(s); if (!closing) { int[] l = lists.isEmpty() ? null : lists.get(lists.size() - 1); if (l != null) l[1]++; s.ctx = "LI"; s.ctxLevel = Math.max(lists.size(), 1); s.liMarker = (l != null && l[0] == 1) ? l[1] + "." : "\u2022"; } }
            else if (name.equals("tr")) { if (!closing) { hflush(s); row = new ArrayList<>(); } else { boolean any = false; if (row != null) for (String c : row) if (!c.isEmpty()) any = true; if (row != null && any) s.out.add(new Block("ROW", 0, join(row, " | "))); row = null; s.buf.setLength(0); s.inCell = false; } }
            else if (name.equals("td") || name.equals("th")) { if (!closing) { hflush(s); s.buf.setLength(0); s.inCell = true; } else { if (row != null) row.add(collapse(s.buf.toString().replace("\u0001", " "))); s.buf.setLength(0); s.inCell = false; } }
            else if (name.equals("table")) { hflush(s); row = null; s.inCell = false; }
            else if (FLOW.contains(name)) hflush(s);
        }
        if (pos < html.length()) s.buf.append(decodeEntities(html.substring(pos)));
        hflush(s);
        return s.out;
    }

    // ---- DOCX
    static final Pattern DOCX_ITEM = Pattern.compile("<w:tbl>.*?</w:tbl>|<w:p[ >].*?</w:p>", Pattern.DOTALL);
    static final Pattern DOCX_ROW = Pattern.compile("<w:tr[ >].*?</w:tr>", Pattern.DOTALL);
    static final Pattern DOCX_CELL = Pattern.compile("<w:tc>.*?</w:tc>|<w:tc [^>]*>.*?</w:tc>", Pattern.DOTALL);
    static final Pattern DOCX_PARA = Pattern.compile("<w:p[ >].*?</w:p>", Pattern.DOTALL);
    static final Pattern DOCX_RUN = Pattern.compile("<w:t(?: [^>]*)?>(.*?)</w:t>|<w:tab/>|<w:br(?: [^>]*)?/>|<w:cr/>|<w:noBreakHyphen/>", Pattern.DOTALL);
    static final Pattern DOCX_STYLE = Pattern.compile("<w:pStyle w:val=\"([^\"]+)\"");
    static final Pattern DOCX_ILVL = Pattern.compile("<w:ilvl w:val=\"([0-9]+)\"");
    static final Pattern DOCX_HEADING = Pattern.compile("(?i)^heading([1-9])$");
    static final Pattern DOCX_STYLE_DEPTH = Pattern.compile("([1-9])$");
    static String docxParaText(String p) {
        StringBuilder sb = new StringBuilder(); Matcher m = DOCX_RUN.matcher(p);
        while (m.find()) { String v = m.group(0); if (v.startsWith("<w:tab")) sb.append(' '); else if (v.startsWith("<w:br") || v.startsWith("<w:cr")) sb.append('\n'); else if (v.startsWith("<w:noBreakHyphen")) sb.append('-'); else sb.append(decodeEntities(m.group(1))); }
        return sb.toString();
    }
    static boolean startsWithIgnoreCase(String s, String p) { return s.regionMatches(true, 0, p, 0, p.length()); }
    static List<Block> blocksFromDocxXml(String xml) {
        List<Block> out = new ArrayList<>(); Matcher it = DOCX_ITEM.matcher(xml);
        while (it.find()) {
            String v = it.group();
            if (v.startsWith("<w:tbl>")) {
                Matcher r = DOCX_ROW.matcher(v);
                while (r.find()) {
                    List<String> cells = new ArrayList<>(); Matcher c = DOCX_CELL.matcher(r.group());
                    while (c.find()) { List<String> ps = new ArrayList<>(); Matcher pm = DOCX_PARA.matcher(c.group()); while (pm.find()) ps.add(docxParaText(pm.group())); cells.add(collapse(join(ps, " "))); }
                    boolean any = false; for (String x : cells) if (!x.isEmpty()) any = true;
                    if (any) out.add(new Block("ROW", 0, join(cells, " | ")));
                }
                continue;
            }
            List<String> ls = new ArrayList<>(); for (String l : ktLines(docxParaText(v))) ls.add(collapse(l));
            String text = ktTrim(join(ls, "\n")); if (text.isEmpty()) continue;
            Matcher sm = DOCX_STYLE.matcher(v); String style = sm.find() ? sm.group(1) : "";
            Matcher hm = DOCX_HEADING.matcher(style);
            if (style.equalsIgnoreCase("Title")) out.add(new Block("H", 1, collapse(text)));
            else if (hm.find()) out.add(new Block("H", Integer.parseInt(hm.group(1)), collapse(text)));
            else if (v.contains("<w:numPr>") || startsWithIgnoreCase(style, "ListBullet") || startsWithIgnoreCase(style, "ListNumber") || style.equalsIgnoreCase("ListParagraph")) {
                Matcher lm = DOCX_ILVL.matcher(v); Matcher dm = DOCX_STYLE_DEPTH.matcher(style); int lvl = lm.find() ? Integer.parseInt(lm.group(1)) + 1 : (dm.find() ? Integer.parseInt(dm.group(1)) : 1);
                out.add(new Block("LI", lvl, text, startsWithIgnoreCase(style, "ListNumber") ? "#" : "\u2022"));
            } else out.add(new Block("P", 0, text));
        }
        return out;
    }

    // ---- CSV
    static List<List<String>> parseCsv(String source, char delimiter) {
        String text = removePrefix(source, "\uFEFF"); List<List<String>> rows = new ArrayList<>(); List<String> row = new ArrayList<>(); StringBuilder field = new StringBuilder();
        boolean quoted = false, fieldStarted = false; int i = 0;
        while (i < text.length()) {
            char c = text.charAt(i);
            if (quoted) { if (c == '"') { if (i + 1 < text.length() && text.charAt(i + 1) == '"') { field.append('"'); i++; } else quoted = false; } else field.append(c); }
            else if (c == '"' && !fieldStarted) { quoted = true; fieldStarted = true; }
            else if (c == delimiter) { row.add(field.toString()); field.setLength(0); fieldStarted = false; }
            else if (c == '\n') { boolean blank = row.isEmpty() && field.length() == 0 && !fieldStarted; row.add(field.toString()); field.setLength(0); fieldStarted = false; if (!blank) rows.add(row); row = new ArrayList<>(); }
            else if (c == '\r') { boolean blank = row.isEmpty() && field.length() == 0 && !fieldStarted; row.add(field.toString()); field.setLength(0); fieldStarted = false; if (!blank) rows.add(row); row = new ArrayList<>(); if (i + 1 < text.length() && text.charAt(i + 1) == '\n') i++; }
            else { field.append(c); fieldStarted = true; }
            i++;
        }
        if (fieldStarted || field.length() > 0 || !row.isEmpty()) { row.add(field.toString()); rows.add(row); }
        return rows;
    }
    static char detectDelimiter(String text) {
        String[] all = removePrefix(text, "\uFEFF").split("\n", -1); StringBuilder hb = new StringBuilder();
        for (int i = 0; i < Math.min(30, all.length); i++) { if (i > 0) hb.append('\n'); hb.append(all[i]); }
        String head = hb.toString(); char best = ','; int bestScore = 0;
        for (char d : new char[]{',', ';', '\t', '|'}) {
            List<List<String>> rows = new ArrayList<>();
            for (List<String> r : parseCsv(head, d)) if (r.size() > 1 || (r.size() == 1 && !r.get(0).isEmpty())) rows.add(r);
            if (rows.isEmpty()) continue;
            Map<Integer, Integer> counts = new HashMap<>(); for (List<String> r : rows) counts.merge(r.size(), 1, Integer::sum);
            int mk = -1, mv = -1; for (Map.Entry<Integer, Integer> e : counts.entrySet()) if (e.getValue() > mv || (e.getValue() == mv && e.getKey() > mk)) { mk = e.getKey(); mv = e.getValue(); }
            int score = mk > 1 ? mv * 1000 + mk : 0;
            if (score > bestScore) { bestScore = score; best = d; }
        }
        return best;
    }

    // ---- khối -> chương
    static List<Object[]> chapters(List<Block> blocks, String fallbackTitle) {
        List<Object[]> out = new ArrayList<>(); String title = null; List<String> paras = new ArrayList<>(); int counter = 0;
        for (Block b : blocks) {
            if (b.kind.equals("H") && b.level <= 2) { if (title != null || !paras.isEmpty()) out.add(new Object[]{title != null ? title : fallbackTitle, paras}); paras = new ArrayList<>(); title = b.text; counter = 0; }
            else if (b.kind.equals("LI")) { StringBuilder ind = new StringBuilder(); for (int k = 0; k < Math.max(b.level - 1, 0); k++) ind.append("  "); paras.add(ind + (b.marker.equals("#") ? (++counter) + "." : b.marker) + " " + b.text); }
            else paras.add(b.text);
        }
        if (title != null || !paras.isEmpty()) out.add(new Object[]{title != null ? title : fallbackTitle, paras});
        return out;
    }

    // ---- TableLayout (app/.../util/TablePdfBuilder.kt)
    static float[] columnWidths(float[] natural, float available, float minWidth) {
        int n = natural.length; if (n == 0) return new float[0];
        float total = 0; for (float x : natural) total += x;
        if (total <= available) return natural.clone();
        float[] base = new float[n]; float sumBase = 0; for (int i = 0; i < n; i++) { base[i] = Math.min(natural[i], minWidth); sumBase += base[i]; }
        float[] r = new float[n];
        if (sumBase >= available) { for (int i = 0; i < n; i++) r[i] = base[i] * available / sumBase; return r; }
        float extra = available - sumBase, sumNeed = total - sumBase;
        for (int i = 0; i < n; i++) r[i] = base[i] + (natural[i] - base[i]) * extra / sumNeed;
        return r;
    }

    static String blocksOut(List<Block> bs) { StringBuilder o = new StringBuilder(); for (Block b : bs) o.append(b.kind).append('|').append(b.level).append('|').append(hex(b.marker)).append('|').append(hex(b.text)).append(';'); return o.toString(); }
    @SuppressWarnings("unchecked")
    public static void main(String[] a) throws Exception {
        StringBuilder res = new StringBuilder();
        for (String ln : Files.readAllLines(Paths.get(a[0]), StandardCharsets.UTF_8)) {
            if (ln.isEmpty()) continue; String[] p = ln.split("\t", -1); String o = "";
            switch (p[0]) {
                case "MD": o = blocksOut(blocksFromMarkdown(unhex(p[1]))); break;
                case "HTML": o = blocksOut(blocksFromHtml(unhex(p[1]))); break;
                case "DOCX": o = blocksOut(blocksFromDocxXml(unhex(p[1]))); break;
                case "CSV": { StringBuilder sb = new StringBuilder(); for (List<String> r : parseCsv(unhex(p[2]), (char) Integer.parseInt(p[1]))) { sb.append('#'); for (int k = 0; k < r.size(); k++) { if (k > 0) sb.append(','); sb.append(hex(r.get(k))); } sb.append(';'); } o = sb.toString(); break; }
                case "DEC": o = hex(decodeText(unhexBytes(p[2]), p[1].equals("1"))); break;
                case "TL": { String[] f = p[3].isEmpty() ? new String[0] : p[3].split(","); float[] nat = new float[f.length]; for (int k = 0; k < f.length; k++) nat[k] = Float.parseFloat(f[k]);
                    float[] w = columnWidths(nat, Float.parseFloat(p[1]), Float.parseFloat(p[2])); StringBuilder sb = new StringBuilder(); for (int k = 0; k < w.length; k++) { if (k > 0) sb.append(','); sb.append(Float.toString(w[k])); } o = sb.toString(); break; }
                case "ENT": o = hex(decodeEntities(unhex(p[1]))); break;
                case "DET": o = String.valueOf((int) detectDelimiter(unhex(p[1]))); break;
                case "CH": {
                    List<Block> bs = new ArrayList<>(); for (int i = 2; i < p.length; i++) { if (p[i].isEmpty()) continue; String[] f = p[i].split("\\|", -1); bs.add(new Block(f[0], Integer.parseInt(f[1]), unhex(f[3]), unhex(f[2]))); }
                    StringBuilder sb = new StringBuilder(); for (Object[] ch : chapters(bs, unhex(p[1]))) { sb.append(hex((String) ch[0])).append(':'); List<String> ps = (List<String>) ch[1]; for (int k = 0; k < ps.size(); k++) { if (k > 0) sb.append(','); sb.append(hex(ps.get(k))); } sb.append(';'); } o = sb.toString(); break; }
            }
            res.append(o).append("\n");
        }
        Files.write(Paths.get(a[1]), res.toString().getBytes(StandardCharsets.UTF_8));
    }
}
