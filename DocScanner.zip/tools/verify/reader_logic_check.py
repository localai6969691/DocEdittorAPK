"""Trình đọc PDF (và nhận dạng tệp đến): toán phóng to (`ZoomMath.kt`) và nhớ trang đọc (`PdfReadingPositions.kt`) (phiên 23, mục 4.59). Bản Java `ReaderLogicCheck.java` chép từng câu; ở đây so với MÔ HÌNH ĐỘC LẬP
viết bằng Python và, quan trọng hơn, kiểm các BẤT BIẾN của phép phóng to (chứ không chỉ so số):
  - phóng to quanh ngón tay: điểm nội dung dưới ngón tay KHÔNG dịch (theo x chính xác khi chưa bị kẹp; theo y sai tối đa 0,5 px nhờ làm tròn);
  - độ dịch ngang luôn nằm trong [width*(1-scale), 0] (không lộ lề trống); scale luôn trong [1, 4]; đặt scale = hiện tại thì không đổi gì;
  - phóng rồi thu lại đúng về scale 1 thì độ dịch về 0; lề đệm phía dưới bằng 0 ở scale 1 và tăng theo scale (để cuối tài liệu còn cuộn tới được);
  - nhớ trang: đặt / lấy, bản mới nhất lên cuối, tối đa 100 mục (bỏ mục CŨ nhất), dòng hỏng bị bỏ, khoá có tab / xuống dòng được chuẩn hoá, số âm bị bỏ.
Cả hai bài đều có THỬ ÂM TÍNH (bản Java bị làm hỏng phải bị bắt). Chạy: python3 reader_logic_check.py (cần java; ~10 giây)"""
import math, os, random, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__)); JAVA = os.path.join(HERE, "ReaderLogicCheck.java")
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)
def jv(lines, java=JAVA):
    r = subprocess.run(["java", java], input="\n".join(lines) + "\n", capture_output=True, text=True)
    if r.returncode: print(r.stderr[-1500:]); raise SystemExit("Java lỗi")
    return r.stdout.split("\n")[:-1]
def hx(s):
    b = s.encode("utf-16-le", "surrogatepass"); return "".join(f"{int.from_bytes(b[i:i+2],'little'):04x}" for i in range(0, len(b), 2))
def unhx(h): return b"".join(int(h[i:i+4], 16).to_bytes(2, "little") for i in range(0, len(h), 4)).decode("utf-16-le", "surrogatepass")

rng = random.Random(59)
# ---------------- 1. phóng to ----------------
W, H = 1080.0, 1920.0
cases = []
for _ in range(2000):
    s0 = rng.choice([1.0, 1.0, rng.uniform(1, 4)])
    ox0 = rng.uniform(W * (1 - s0), 0.0) if s0 > 1 else 0.0
    target = rng.uniform(0.3, 6.0); fx = rng.uniform(0, W); fy = rng.uniform(0, H)
    cases.append((s0, ox0, target, fx, fy))
out = jv([f"ZOOM {s0!r} {ox0!r} {W} {t!r} {fx!r} {fy!r}" for (s0, ox0, t, fx, fy) in cases])
bad = []
for (s0, ox0, t, fx, fy), line in zip(cases, out):
    s1, ox1, dy = line.split(); s1 = float(s1); ox1 = float(ox1); dy = int(dy)
    exp_s = min(max(t, 1.0), 4.0)
    if abs(s1 - exp_s) > 1e-4 * exp_s: bad.append(("scale", s0, t, s1, exp_s)); continue
    if not (W * (1 - s1) - 1e-2 <= ox1 <= 1e-2): bad.append(("offset ngoài khoảng", s0, ox0, t, ox1, s1)); continue
    if abs(s1 - s0) < 1e-6:
        if abs(ox1 - ox0) > 1e-3 or dy != 0: bad.append(("scale không đổi nhưng trạng thái đổi", s0, ox0, ox1, dy)); continue
    # bất biến x: điểm nội dung dưới ngón tay không dịch, nếu offset KHÔNG bị kẹp
    unclamped = fx - (fx - ox0) * (s1 / s0)
    if W * (1 - s1) <= unclamped <= 0:
        c0 = (fx - ox0) / s0; c1 = (fx - ox1) / s1
        if abs(c0 - c1) > 1e-2: bad.append(("điểm x dịch", c0, c1, s0, s1)); continue
    # bất biến y: scrollY + fy/scale không đổi (sai <= 0,5 px do làm tròn)
    y0 = 1000.0 + fy / s0; y1 = 1000.0 + dy + fy / s1
    if abs(y0 - y1) > 0.51: bad.append(("điểm y dịch", y0, y1, dy, fy, s0, s1))
check(not bad, f"phóng to: {len(cases)} ca ngẫu nhiên giữ đúng bất biến (điểm dưới ngón tay, khoảng độ dịch, scale 1..4)" + (f" - LỆCH {bad[:2]}" if bad else ""))

# phóng rồi thu lại đúng về 1 -> độ dịch về 0 (hai lô, vì lệnh thứ hai cần kết quả của lệnh thứ nhất)
ups = [(rng.uniform(0, W), rng.uniform(0, H), rng.uniform(1.2, 4.0)) for _ in range(300)]
first = jv([f"ZOOM 1.0 0.0 {W} {up!r} {fx!r} {fy!r}" for (fx, fy, up) in ups])
back = jv([f"ZOOM {f.split()[0]} {f.split()[1]} {W} 1.0 {fx!r} {fy!r}" for f, (fx, fy, up) in zip(first, ups)])
ok = all(float(l.split()[0]) == 1.0 and abs(float(l.split()[1])) <= 1e-3 for l in back)
check(ok, "phóng rồi thu lại đúng về 1: scale = 1 và độ dịch ngang = 0 (không còn lề lệch)")

pads = jv([f"PAD {H} {s!r}" for s in (1.0, 1.5, 2.0, 3.0, 4.0)])
want = [int(H * (1 - 1 / s)) for s in (1.0, 1.5, 2.0, 3.0, 4.0)]
check(all(abs(int(p) - w) <= 1 for p, w in zip(pads, want)) and int(pads[0]) == 0 and [int(p) for p in pads] == sorted(int(p) for p in pads), f"lề đệm phía dưới: 0 ở scale 1, tăng theo scale, sai số <= 1 px so với số thực 64-bit (Kotlin dùng Float) ({pads})")
cx = jv([f"CONTENTX {x!r} {o!r} {s!r}" for (x, o, s) in [(540.0, 0.0, 1.0), (540.0, -540.0, 2.0), (0.0, -300.0, 2.0)]])
check([float(v) for v in cx] == [540.0, 540.0, 150.0], f"toạ độ màn hình -> nội dung ({cx})")

# thử âm tính: bản Java sai công thức độ dịch hoặc dấu của cuộn phải bị bắt
src = open(JAVA, encoding="utf-8").read()
def mutant(a, b, name):
    assert a in src, name
    d = tempfile.mkdtemp(); p = os.path.join(d, "Mut.java"); open(p, "w", encoding="utf-8").write(src.replace(a, b, 1).replace("public class ReaderLogicCheck", "public class Mut"))
    return p
for name, a_, b_ in [("bỏ kẹp độ dịch ngang", "float ox = clampX(fx - (fx - offsetX) * (s / scale), width, s);", "float ox = fx - (fx - offsetX) * (s / scale);"),
                     ("đổi dấu độ cuộn dọc", "int dy = Math.round(fy / scale - fy / s);", "int dy = Math.round(fy / s - fy / scale);"),
                     ("quên nhân tỉ lệ scale", "float ox = clampX(fx - (fx - offsetX) * (s / scale), width, s);", "float ox = clampX(fx - (fx - offsetX), width, s);")]:
    p = mutant(a_, b_, name); caught = False
    sub = cases[:600]
    outm = jv([f"ZOOM {s0!r} {ox0!r} {W} {t!r} {fx!r} {fy!r}" for (s0, ox0, t, fx, fy) in sub], p)
    for (s0, ox0, t, fx, fy), line in zip(sub, outm):
        s1, ox1, dy = float(line.split()[0]), float(line.split()[1]), int(line.split()[2])
        if not (W * (1 - s1) - 1e-2 <= ox1 <= 1e-2): caught = True; break
        if abs(s1 - s0) > 1e-6:
            y0 = 1000.0 + fy / s0; y1 = 1000.0 + dy + fy / s1
            if abs(y0 - y1) > 0.51: caught = True; break
            un = fx - (fx - ox0) * (s1 / s0)
            if W * (1 - s1) <= un <= 0 and abs((fx - ox0) / s0 - (fx - ox1) / s1) > 1e-2: caught = True; break
    check(caught, f"ÂM TÍNH phóng to: bản Java '{name}' bị bắt")

# ---------------- 2. nhớ trang ----------------
class Model:
    def __init__(self): self.d = []                     # danh sách (khoá, trang) cũ -> mới
    def clean(self, s): return "".join(" " if c in "\t\n\r" else c for c in s)
    def put(self, k, p):
        k = self.clean(k); self.d = [(a, b) for (a, b) in self.d if a != k] + [(k, max(p, 0))]
        while len(self.d) > 100: self.d.pop(0)
    def get(self, k): return next((b for (a, b) in self.d if a == self.clean(k)), -1)
    def text(self): return "".join(f"{b}\t{a}\n" for a, b in self.d)

names = ["a.pdf", "Hoá đơn 1.pdf", "tab\there.pdf", "new\nline.pdf", "😀.pdf", "x|y.pdf", ""]
def cleank(name, length): return "".join(" " if c in "\t\n\r" else c for c in name) + "|" + str(length)
plan = []
for _ in range(1500):
    name = rng.choice(names) + (str(rng.randrange(150)) if rng.random() < 0.8 else ""); length = rng.randrange(1, 10**7)
    plan.append((name, length))
keys = jv([f"KEY {hx(n)} {l}" for (n, l) in plan])
check(all(unhx(k) == cleank(n, l) for k, (n, l) in zip(keys, plan)), "khoá = tên (tab / xuống dòng -> dấu cách) + '|' + độ dài, 1 500 tên ngẫu nhiên")
m = Model(); cmds = ["RESET"]; expect = []
for (n, l), kh in zip(plan, keys):
    k = cleank(n, l)
    if rng.random() < 0.6:
        page = rng.randrange(0, 5000); m.put(k, page); cmds.append(f"SPUT {kh} {page}"); expect.append(None)
    else:
        cmds.append(f"SGET {kh}"); expect.append(m.get(k))
cmds.append("STEXT")
out = jv(cmds)
gets = [int(x) for x in out[:-1]]; final = unhx(out[-1]) if out[-1] else ""
want_gets = [e for e in expect if e is not None]
check(gets == want_gets and final == m.text(), "nhớ trang: 1 500 thao tác đặt / lấy ngẫu nhiên = mô hình độc lập (mới nhất ở cuối, trùng khoá thì thay), văn bản cuối đúng từng byte")

# trần 100
cmds = ["RESET"] + [f"SPUT {hx(f'book{i}.pdf|{i}')} {i}" for i in range(130)] + ["STEXT"] + [f"SGET {hx(f'book{i}.pdf|{i}')}" for i in (0, 29, 30, 129)]
out = jv(cmds); txt = unhx(out[0])
check(txt.count("\n") == 100 and [int(x) for x in out[1:]] == [-1, -1, 30, 129], "trần 100 mục: 130 PDF -> giữ 100 cái MỚI NHẤT, bỏ 30 cái cũ nhất")

# dòng hỏng, số âm, đọc lại không ném lỗi
garbage = "\n".join(["", "abc", "\t", "5\t", "-3\tneg.pdf|1", "x\tbad.pdf|2", "7\tgood.pdf|3", "7\tgood.pdf|3", "+4\tplus.pdf|4", "99999999999\thuge.pdf|5", "12\tlast.pdf|6", "tab\tonly"]) + "\n"
probe = ["neg.pdf|1", "bad.pdf|2", "good.pdf|3", "plus.pdf|4", "huge.pdf|5", "last.pdf|6"]
got = dict(zip(probe, [int(x) for x in jv([f"GET {hx(garbage)} {hx(n)}" for n in probe])]))
check(got == {"neg.pdf|1": -1, "bad.pdf|2": -1, "good.pdf|3": 7, "plus.pdf|4": 4, "huge.pdf|5": -1, "last.pdf|6": 12}, f"dòng hỏng / số âm / quá lớn bị bỏ, dòng tốt đọc được ({got})")
check(int(jv([f"GET {hx('')} {hx('x|1')}"])[0]) == -1, "chưa có dữ liệu -> -1")

# thử âm tính nhớ trang
for name, a_, b_ in [("không bỏ mục cũ nhất", "while (map.size() > MAX_ENTRIES) map.remove(map.keySet().iterator().next());", ""),
                     ("không đưa lên cuối khi trùng khoá", "map.remove(k); map.put(k, Math.max(page, 0));", "map.put(k, Math.max(page, 0));"),
                     ("nhận số âm", "if (page == null || page < 0) continue;", "if (page == null) continue;")]:
    p = mutant(a_, b_, name)
    out = jv(["RESET"] + [f"SPUT {hx(f'b{i}|1')} {i}" for i in range(130)] + ["STEXT"], p)
    caught = unhx(out[-1]).count("\n") != 100
    two = jv([f"PUT {hx(chr(49) + chr(9) + 'A|1' + chr(10) + chr(50) + chr(9) + 'B|1' + chr(10))} {hx('A|1')} 9"], p)[0]
    if unhx(two) != "2\tB|1\n9\tA|1\n": caught = True
    if int(jv([f"GET {hx('-3' + chr(9) + 'neg|1' + chr(10))} {hx('neg|1')}"], p)[0]) != -1: caught = True
    check(caught, f"ÂM TÍNH nhớ trang: bản Java '{name}' bị bắt")

# ---------------- 3. nhận dạng nội dung bằng chữ ký đầu tệp (IncomingFile.sniffType) ----------------
import io, zipfile
def real_files():
    out = {}
    import pikepdf
    buf = io.BytesIO(); pdf = pikepdf.new(); pdf.add_blank_page(); pdf.save(buf); out["pdf thật (pikepdf)"] = (buf.getvalue(), "application/pdf")
    from PIL import Image
    for fmt, mime in (("JPEG", "image/jpeg"), ("PNG", "image/png"), ("WEBP", "image/webp")):
        b = io.BytesIO(); Image.new("RGB", (8, 8), (200, 30, 30)).save(b, fmt); out[f"ảnh {fmt} thật (Pillow)"] = (b.getvalue(), mime)
    z = io.BytesIO()
    with zipfile.ZipFile(z, "w") as zf: zf.writestr("a.txt", "x")
    out["zip thật"] = (z.getvalue(), "application/zip")
    out["PDF có BOM UTF-8 đứng trước"] = (b"\xef\xbb\xbf" + out["pdf thật (pikepdf)"][0], "application/pdf")
    out["PDF có dòng trống đứng trước"] = (b"\n\n" + out["pdf thật (pikepdf)"][0], "application/pdf")
    out["văn bản thường"] = (b"hello world, this is text", None)
    out["tệp rỗng"] = (b"", None)
    out["1 byte"] = (b"%", None)
    out["'%PDF' thiếu dấu '-'"] = (b"%PDF1.7 junk junk", None)
    out["PDF đứng sau 5 byte rác (quá xa)"] = (b"xxxxx%PDF-1.7", None)
    out["RIFF nhưng là WAV"] = (b"RIFF\x24\x00\x00\x00WAVEfmt ", None)
    out["HTML"] = (b"<!DOCTYPE html><html>", None)
    return out
rf = real_files(); names = list(rf)
res = jv([f"SNIFF {rf[n][0][:16].hex() or '-'}" for n in names])
bad = [(n, r, rf[n][1]) for n, r in zip(names, res) if (None if r == "-" else r) != rf[n][1]]
check(not bad, f"nhận dạng bằng chữ ký đầu tệp: {len(names)} tệp thật (PDF, JPEG, PNG, WEBP, zip, PDF có BOM / dòng trống, và các tệp KHÔNG được nhận nhầm) đúng" + (f" - LỆCH {bad}" if bad else ""))
# chỉ cần 16 byte đầu: kết quả không đổi khi đọc nhiều hơn
res_full = jv([f"SNIFF {rf[n][0][:4096].hex() or '-'}" for n in names])
check(res_full == res, "chỉ cần 16 byte đầu: đọc nhiều hơn không đổi kết quả (MainActivity chỉ đọc 16 byte)")
rnd_bytes = [os.urandom(rng.randint(0, 40)) for _ in range(600)]
rr = jv([f"SNIFF {b.hex() or '-'}" for b in rnd_bytes])
def py_sniff(h):
    for off in range(5):
        if h[off:off + 5] == b"%PDF-": return "application/pdf"
    if h[:3] == b"\xff\xd8\xff": return "image/jpeg"
    if h[:8] == b"\x89PNG\r\n\x1a\n": return "image/png"
    if h[:4] == b"RIFF" and h[8:12] == b"WEBP": return "image/webp"
    if h[:4] == b"PK\x03\x04": return "application/zip"
    return None
check(all((None if r == "-" else r) == py_sniff(b) for r, b in zip(rr, rnd_bytes)), "600 chuỗi byte ngẫu nhiên = mô hình Python độc lập (không ném lỗi với chuỗi ngắn / rỗng)")
tricky = [b"%PDF-", b"x%PDF-", b"xxxx%PDF-", b"%PDF-"[:4], b"\xff\xd8", b"\xff\xd8\xff", b"RIFF\0\0\0\0WEBP", b"RIFF\0\0\0\0WEB", b"PK\x03\x04", b"PK\x03"]
rt = jv([f"SNIFF {b.hex()}" for b in tricky])
check(all((None if r == "-" else r) == py_sniff(b) for r, b in zip(rt, tricky)), "các biên: chữ ký cụt, chữ ký ở vị trí 4 / 5, WEBP cụt")
mp = mutant('for (int offset = 0; offset <= 4; offset++) if (at(head, offset, 0x25, 0x50, 0x44, 0x46, 0x2D)) return "application/pdf";', 'if (at(head, 0, 0x25, 0x50, 0x44, 0x46, 0x2D)) return "application/pdf";', "chỉ nhận PDF ở vị trí 0")
rm = jv([f"SNIFF {rf['PDF có BOM UTF-8 đứng trước'][0][:16].hex()}"], mp)[0]
check(rm == "-", "ÂM TÍNH: bản Java chỉ tìm '%PDF-' ở vị trí 0 bỏ lỡ PDF có BOM (bài kiểm bắt được)")
mp = mutant('at(head, 0, 0x52, 0x49, 0x46, 0x46) && at(head, 8, 0x57, 0x45, 0x42, 0x50)', 'at(head, 0, 0x52, 0x49, 0x46, 0x46)', "RIFF = webp")
rm = jv([f"SNIFF {rf['RIFF nhưng là WAV'][0][:16].hex()}"], mp)[0]
check(rm == "image/webp", "ÂM TÍNH: bản Java coi mọi RIFF là WEBP nhận nhầm tệp WAV (bài kiểm bắt được)")

# ---------------- 4. chỉnh sửa trong trình đọc (ReaderEdits.frame / stampBox) ----------------
def nums(line): return None if line == "-" else [float(v) for v in line.split()]
fcases = []
for _ in range(2500):
    w = rng.choice([360.0, 1080.0, 1500.0, 733.0]); h = w * rng.uniform(1.0, 1.6)
    ax, ay, bx, by = rng.uniform(-50, w + 50), rng.uniform(-50, h + 50), rng.uniform(-50, w + 50), rng.uniform(-50, h + 50)
    if rng.random() < 0.25: bx, by = ax + rng.uniform(-3, 3), ay + rng.uniform(-3, 3)     # chạm / kéo rất ngắn
    fcases.append((ax, ay, bx, by, w, h))
fout = jv([f"FRAME {a!r} {b!r} {c!r} {d!r} {w!r} {h!r}" for (a, b, c, d, w, h) in fcases])
ok = True; bad = None
for (ax, ay, bx, by, w, h), line in zip(fcases, fout):
    got = nums(line)
    x0, x1 = max(0.0, min(1.0, min(ax, bx) / w)), max(0.0, min(1.0, max(ax, bx) / w)); y0, y1 = max(0.0, min(1.0, min(ay, by) / h)), max(0.0, min(1.0, max(ay, by) / h))
    want = None if (x1 - x0 < 0.01 or y1 - y0 < 0.01) else [x0, y0, x1, y1]
    if (got is None) != (want is None): ok = False; bad = (ax, ay, bx, by, w, h, got, want); break
    if got is not None:
        if any(abs(g - v) > 1e-4 for g, v in zip(got, want)): ok = False; bad = (got, want); break
        if not (0 <= got[0] < got[2] <= 1 and 0 <= got[1] < got[3] <= 1): ok = False; bad = ("ngoài trang / sai thứ tự", got); break
check(ok, f"khung kéo: {len(fcases)} ca ngẫu nhiên (mọi hướng kéo, ra ngoài trang, chỉ chạm) = mô hình độc lập; luôn trong [0,1], góc đúng thứ tự, kéo < 1% là chạm bị bỏ" + (f" - LỆCH {bad}" if bad else ""))
sw = jv([f"FRAME {ax!r} {ay!r} {bx!r} {by!r} {w!r} {h!r}" for (ax, ay, bx, by, w, h) in fcases[:500]])
sw2 = jv([f"FRAME {bx!r} {by!r} {ax!r} {ay!r} {w!r} {h!r}" for (ax, ay, bx, by, w, h) in fcases[:500]])
check(sw == sw2, "khung kéo: đổi chỗ điểm đầu và điểm cuối cho CÙNG kết quả (kéo từ phải sang trái, từ dưới lên đều đúng)")
check(jv(["FRAME 0 0 10 10 0 100", "FRAME 0 0 10 10 100 0"]) == ["-", "-"], "khung kéo: view chưa có kích thước -> không có khung (không chia cho 0)")

scases = []
for _ in range(2500):
    w = rng.choice([360.0, 1080.0, 1500.0]); h = w * rng.uniform(1.0, 1.6)
    scases.append((rng.uniform(-30, w + 30), rng.uniform(-30, h + 30), w, h, rng.uniform(0.0, 1.2), rng.choice([rng.uniform(0.2, 9.0), 0.001, 0.0, 30.0])))
sout = jv([f"STAMPBOX {x!r} {y!r} {w!r} {h!r} {wf!r} {asp!r}" for (x, y, w, h, wf, asp) in scases])
ok = True; bad = None
for (x, y, w, h, wf, asp), line in zip(scases, sout):
    got = nums(line)
    if asp <= 0.01:
        if got is not None: ok = False; bad = ("tỉ lệ vô nghĩa phải bị từ chối", asp, got); break
        continue
    if got is None: ok = False; bad = ("bị từ chối sai", x, y, w, h, wf, asp); break
    x0, y0, x1, y1 = got
    if not (-1e-5 <= x0 < x1 <= 1 + 1e-5 and -1e-5 <= y0 < y1 <= 1 + 1e-5): ok = False; bad = ("ngoài trang", got); break
    px_aspect = (x1 - x0) * w / ((y1 - y0) * h)
    if abs(px_aspect - asp) > 1e-3 * max(1.0, asp): ok = False; bad = ("sai tỉ lệ ảnh con dấu", px_aspect, asp, got); break
    wf_c = min(max(wf, 0.05), 0.9); bh = (wf_c * w / asp) / h
    if bh <= 1.0 and abs((x1 - x0) - wf_c) > 1e-4: ok = False; bad = ("sai bề rộng", x1 - x0, wf_c); break
    cx = min(max(x / w, 0), 1); cy = min(max(y / h, 0), 1)
    if x0 > 1e-5 and x1 < 1 - 1e-5 and abs((x0 + x1) / 2 - cx) > 1e-4: ok = False; bad = ("lệch tâm x khi không bị kẹp", got, cx); break
    if y0 > 1e-5 and y1 < 1 - 1e-5 and abs((y0 + y1) / 2 - cy) > 1e-4: ok = False; bad = ("lệch tâm y khi không bị kẹp", got, cy); break
check(ok, f"hộp con dấu chữ: {len(scases)} ca ngẫu nhiên giữ trong trang, ĐÚNG tỉ lệ ảnh, đúng bề rộng (trừ khi quá cao), đúng tâm chạm (trừ khi sát mép); tỉ lệ vô nghĩa bị từ chối" + (f" - LỆCH {bad}" if bad else ""))

for name, a_, b_ in [("khung: không kẹp vào trang", "float x0 = coerce(Math.min(ax, bx) / width, 0f, 1f), x1 = coerce(Math.max(ax, bx) / width, 0f, 1f);", "float x0 = Math.min(ax, bx) / width, x1 = Math.max(ax, bx) / width;"),
                     ("khung: bỏ ngưỡng chạm", "if (x1 - x0 < MIN_SIDE || y1 - y0 < MIN_SIDE) return \"-\";", ""),
                     ("con dấu: không đẩy vào trong", "float x0 = coerce(cx - bw / 2f, 0f, 1f - bw), y0 = coerce(cy - bh / 2f, 0f, 1f - bh);", "float x0 = cx - bw / 2f, y0 = cy - bh / 2f;"),
                     ("con dấu: tỉ lệ sai", "float bh = (bw * width / aspect) / height;", "float bh = (bw / aspect);")]:
    p_ = mutant(a_, b_, name); caught = False
    om = jv([f"FRAME {a!r} {b!r} {c!r} {d!r} {w!r} {h!r}" for (a, b, c, d, w, h) in fcases[:600]], p_)
    for (ax, ay, bx, by, w, h), line in zip(fcases[:600], om):
        g = nums(line); x0, x1 = max(0.0, min(1.0, min(ax, bx) / w)), max(0.0, min(1.0, max(ax, bx) / w)); y0, y1 = max(0.0, min(1.0, min(ay, by) / h)), max(0.0, min(1.0, max(ay, by) / h))
        wnt = None if (x1 - x0 < 0.01 or y1 - y0 < 0.01) else [x0, y0, x1, y1]
        if (g is None) != (wnt is None) or (g is not None and any(abs(u - v) > 1e-4 for u, v in zip(g, wnt))): caught = True; break
    if not caught:
        om = jv([f"STAMPBOX {x!r} {y!r} {w!r} {h!r} {wf!r} {asp!r}" for (x, y, w, h, wf, asp) in scases[:600]], p_)
        for (x, y, w, h, wf, asp), line in zip(scases[:600], om):
            g = nums(line)
            if asp <= 0.01: continue
            if g is None or not (-1e-5 <= g[0] < g[2] <= 1 + 1e-5 and -1e-5 <= g[1] < g[3] <= 1 + 1e-5) or abs((g[2] - g[0]) * w / ((g[3] - g[1]) * h) - asp) > 1e-3 * max(1.0, asp): caught = True; break
    check(caught, f"ÂM TÍNH chỉnh sửa: bản Java '{name}' bị bắt")

print(); print("TAT CA DAT" if not fails else f"CO {len(fails)} LOI")
sys.exit(1 if fails else 0)
