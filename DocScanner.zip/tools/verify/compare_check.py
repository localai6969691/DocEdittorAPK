"""Kiểm chứng PdfComparer (phiên 15): so sánh hai PDF bằng ảnh - căn chỉnh, so sánh có dung sai, ghép trang chèn/xoá.

Dùng compare_align_model.py (numpy, từng bước giống PdfComparer.kt). Sau phản hồi "sao không tra cứu khắc phục hạn chế", phiên bản đầu (so điểm ảnh
thẳng, không căn chỉnh) bị thay bằng: dịch chuyển toàn trang -> căn chỉnh AFFINE kim tự tháp (1/8, 1/4, 1/2) -> tinh chỉnh ±1 px theo ô -> so sánh dung sai cửa sổ 3x3; và ghép trang bằng
quy hoạch động trên chữ ký trang. Các phần kiểm:
  1. phép so cơ bản (không dịch): giống hệt, nhiễu, chấm lẻ, một/hai vùng, gộp chữ gần nhau, mép góc, chạm chéo;
  2. ĐỘ BỀN: trang bị dịch (9,-6), (18,12), (-17,15) -> 0 hộp; xoay tới 3°, co tới 3%, và kết hợp xoay+co+dịch -> hộp phủ < 3% trang (không căn chỉnh: 55-67%);
  3. ĐỘ NHẠY: đổi một chữ số (1 -> 7) và xoá một cụm chữ vẫn được khoanh, kể cả khi trang bị dịch hoặc xoay 0,3°;
  4. GHÉP TRANG: bản mới chèn một trang, xoá một trang, sửa một đoạn, cả tài liệu bị dịch+xoay nhẹ -> ghép đúng, trang chèn/xoá nhận ra;
  5. hai PDF thật dựng bằng poppler (thêm một ô đỏ -> đúng một hộp; dựng lại cùng PDF -> không hộp).
Chạy: python3 compare_check.py   (cần numpy, pillow, opencv-python, pikepdf, pdftoppm)
"""
import os, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import numpy as np
import cv2
from PIL import Image, ImageDraw, ImageFont
import pikepdf
from pikepdf import Dictionary
import compare_align_model as M

FONT = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
WORDS = ["hop", "dong", "thue", "nha", "ben", "a", "b", "dieu", "khoan", "thanh", "toan", "gia", "tri", "so", "luong", "hang", "hoa", "ngay", "thang", "nam", "cong", "ty", "dia", "chi"]


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    return cond


def covers(box, x, y, w, h):
    bx, by, bw, bh = box
    return bx <= x and by <= y and bx + bw >= x + w and by + bh >= y + h


def text_page(seed, w=800, h=1131, lines=40, total=None):
    rng = np.random.default_rng(seed)
    img = Image.new("L", (w, h), 255); d = ImageDraw.Draw(img); f = ImageFont.truetype(FONT, 17)
    y = 60
    for _ in range(lines):
        n = int(rng.integers(4, 13)); t = " ".join(rng.choice(WORDS, size=n))
        d.text((60 + int(rng.integers(0, 40)), y), t, fill=20, font=f); y += 24
    d.text((60, 1040), f"Tong tien: {total or '1,250,000'} VND", fill=20, font=f)
    return np.array(img)


def warp(a, rot=0.0, sc=1.0, dx=0, dy=0):
    h, w = a.shape
    m = cv2.getRotationMatrix2D((w / 2, h / 2), rot, sc); m[0, 2] += dx; m[1, 2] += dy
    return cv2.warpAffine(a, m, (w, h), flags=cv2.INTER_LINEAR, borderValue=255)


def plain_boxes(a, b):
    """Bản KHÔNG căn chỉnh (so điểm ảnh thẳng, như phiên bản đầu): để chứng minh mức cải thiện."""
    mask = np.abs(a.astype(int) - b.astype(int)) > M.THRESHOLD
    return M.boxes_from_mask(mask)


def area_fraction(boxes, shape):
    return sum(w * h for _, _, w, h in boxes) / float(shape[0] * shape[1])


def main():
    good = True
    W, H = 320, 400
    base = np.full((H, W), 255, dtype=np.uint8)
    base[40:60, 40:200] = 0; base[300:320, 100:260] = 0
    basic = M.compare_pages_unaligned

    # ---- 1. phép so cơ bản ----
    good &= check(basic(base, base.copy()) == [], "hai trang giống hệt: không có hộp")
    noisy = np.clip(base.astype(int) + np.random.RandomState(1).randint(-20, 21, base.shape), 0, 255).astype(np.uint8)
    good &= check(basic(base, noisy) == [], "nhiễu ±20 mức sáng: không có hộp")
    speck = base.copy(); speck[200, 200] = 0; speck[203, 207] = 0; speck[190, 150] = 0
    good &= check(basic(base, speck) == [], "ba điểm lẻ 1x1 (bụi máy quét): bị bỏ qua")
    speck2 = base.copy(); speck2[200:206, 200:206] = 0
    good &= check(len(basic(base, speck2)) == 1, "chấm 6x6: được tính là thay đổi")
    one = base.copy(); one[100:140, 60:180] = 0
    b = basic(base, one)
    good &= check(len(b) == 1 and covers(b[0], 60, 100, 120, 40), f"một vùng đổi: đúng 1 hộp trùm vùng đó {b}")
    two = base.copy(); two[100:120, 20:60] = 0; two[250:280, 220:300] = 0
    b = basic(base, two)
    good &= check(len(b) == 2, f"hai vùng xa nhau: 2 hộp riêng {b}")
    word = base.copy()
    for k in range(5):
        word[200:216, 60 + 26 * k:60 + 26 * k + 16] = 0
    good &= check(len(basic(base, word)) == 1, "các chữ cách nhau nhỏ gộp thành 1 hộp")
    far = base.copy(); far[100:116, 20:36] = 0; far[100:116, 200:216] = 0
    good &= check(len(basic(base, far)) == 2, "hai vùng cách nhau nhiều khối: không gộp")
    edge = base.copy(); edge[H - 10:H, W - 10:W] = 0
    b = basic(base, edge)
    good &= check(len(b) == 1 and b[0][0] + b[0][2] <= W and b[0][1] + b[0][3] <= H, f"vùng đổi sát mép: hộp không tràn ảnh {b}")
    diag = base.copy(); diag[100:116, 100:116] = 0; diag[116:132, 116:132] = 0
    good &= check(len(basic(base, diag)) == 1, "hai khối chạm chéo gộp một vùng")

    # ---- 2. độ bền ----
    a = text_page(1)
    for name, bb in [("dịch (9,-6)", warp(a, dx=9, dy=-6)), ("dịch (18,12)", warp(a, dx=18, dy=12)), ("dịch (-17,15)", warp(a, dx=-17, dy=15))]:
        boxes = M.compare_pages(a, bb)
        good &= check(boxes == [], f"trang bị {name}: sau căn chỉnh không còn hộp (không căn chỉnh: {len(plain_boxes(a, bb))} hộp, {100 * area_fraction(plain_boxes(a, bb), a.shape):.0f}% diện tích)")
    for seed in (1, 2, 3):
        a2 = text_page(seed)
        for name, bb in [("xoay 0,3°", warp(a2, rot=0.3)), ("xoay 1°", warp(a2, rot=1.0)), ("xoay 2°", warp(a2, rot=2.0)), ("xoay 3°", warp(a2, rot=3.0)),
                         ("co 2%", warp(a2, sc=1.02)), ("co 3%", warp(a2, sc=1.03)), ("xoay 1,5° + co 2%", warp(a2, rot=1.5, sc=1.02)),
                         ("xoay 2° + dịch (12,-9)", warp(a2, rot=2.0, dx=12, dy=-9))]:
            boxes = M.compare_pages(a2, bb)
            frac = area_fraction(boxes, a2.shape); frac0 = area_fraction(plain_boxes(a2, bb), a2.shape)
            good &= check(frac < 0.03, f"trang {seed} {name}: hộp phủ {100 * frac:.1f}% trang (không căn chỉnh: {100 * frac0:.0f}%)")

    # ---- 3. độ nhạy ----
    a_amt = text_page(1, total="1,250,000"); b_amt = text_page(1, total="7,250,000")
    for name, tf in [("không dịch", lambda x: x), ("dịch (18,12)", lambda x: warp(x, dx=18, dy=12)), ("xoay 2°", lambda x: warp(x, rot=2.0)),
                     ("co 3%", lambda x: warp(x, sc=1.03)), ("xoay 1,5° + co 2% + dịch", lambda x: warp(x, rot=1.5, sc=1.02, dx=10, dy=-8))]:
        boxes = M.compare_pages(a_amt, tf(b_amt))
        near = [x for x in boxes if x[1] <= 1062 and x[1] + x[3] >= 1040 and x[0] <= 200 and x[0] + x[2] >= 100]
        good &= check(len(near) >= 1, f"đổi số tiền 1→7 [{name}]: có hộp trùm chỗ đổi ({len(boxes)} hộp tổng)")
    erased = a.copy(); erased[60 + 24 * 10 - 2:60 + 24 * 10 + 20, 60:200] = 255
    for name, tf in [("không dịch", lambda x: x), ("dịch (18,12)", lambda x: warp(x, dx=18, dy=12)), ("xoay 2°", lambda x: warp(x, rot=2.0)),
                     ("co 3%", lambda x: warp(x, sc=1.03))]:
        boxes = M.compare_pages(a, tf(erased))
        near = [x for x in boxes if x[1] <= 60 + 24 * 10 + 20 and x[1] + x[3] >= 60 + 24 * 10 - 2 and x[0] <= 200 and x[0] + x[2] >= 60]
        good &= check(len(near) >= 1, f"xoá một cụm chữ [{name}]: có hộp trùm chỗ đổi ({len(boxes)} hộp tổng)")
    other = text_page(2)
    boxes = M.compare_pages(a, other)
    good &= check(area_fraction(boxes, a.shape) > 0.4, f"hai trang HOÀN TOÀN khác nhau: hộp phủ {100 * area_fraction(boxes, a.shape):.0f}% trang")
    boxes = M.compare_pages(a, warp(other, rot=2.0))
    good &= check(area_fraction(boxes, a.shape) > 0.4, f"hai trang hoàn toàn khác nhau, trang mới còn xoay 2°: hộp phủ {100 * area_fraction(boxes, a.shape):.0f}% (căn chỉnh không 'làm khớp bừa')")

    # ---- 4. ghép trang ----
    P = [text_page(s, total=f"{s},000") for s in range(1, 9)]
    old = [P[0], P[1], P[2], P[3], P[4], P[5]]
    edited = P[4].copy(); edited[300:340, 100:500] = 255
    new = [warp(p, rot=0.3, dx=7, dy=-5) for p in [P[0], P[1], P[6], P[2], edited, P[5]]]
    sigs = M.normalized_signatures([M.raw_signature(p) for p in old + new])
    pairs = M.align_pages(sigs[:6], sigs[6:])
    good &= check([(i + 1, j + 1) for i, j in pairs] == [(1, 1), (2, 2), (3, 4), (5, 5), (6, 6)],
                  f"chèn 1 trang, xoá 1 trang, sửa 1 trang, tài liệu dịch+xoay: ghép {[(i + 1, j + 1) for i, j in pairs]} (trang 3 mới là trang chèn, trang 4 cũ bị xoá)")
    sig_same = M.normalized_signatures([M.raw_signature(p) for p in old + old])
    good &= check(M.align_pages(sig_same[:6], sig_same[6:]) == [(i, i) for i in range(6)], "hai bản giống nhau: ghép 1-1 theo thứ tự")
    only_one = M.normalized_signatures([M.raw_signature(P[0]), M.raw_signature(P[1])])
    good &= check(M.align_pages([only_one[0]], [only_one[1]]) == [], "hai tài liệu một trang hoàn toàn khác nhau: không ghép (một xoá, một thêm)")
    reorder = M.normalized_signatures([M.raw_signature(p) for p in [P[0], P[1], P[2]] + [P[0], P[2], P[1]]])
    good &= check(len(M.align_pages(reorder[:3], reorder[3:])) == 2, "đổi thứ tự hai trang: ghép tối đa theo thứ tự (2 cặp), phần còn lại tính là xoá/thêm")

    # ---- 5. poppler ----
    def make(path, rects):
        ops = "".join(f"{r} {g} {bb} rg {x} {y} {w} {hh} re f\n" for (x, y, w, hh, r, g, bb) in rects)
        pdf = pikepdf.new(); pg = pdf.add_blank_page(page_size=(400, 500)); pg.Resources = Dictionary(); pg.Contents = pdf.make_stream(ops.encode()); pdf.save(path)
        subprocess.run(["pdftoppm", "-scale-to-x", "800", "-scale-to-y", "-1", "-png", "-singlefile", path, path[:-4]], check=True)
        return np.array(Image.open(path[:-4] + ".png").convert("L"))
    common = [(40, 400, 300, 30, 0, 0, 0), (40, 100, 120, 80, 0, 0, 1)]
    pa = make(os.path.join(OUT, "cmp_a.pdf"), common)
    pb = make(os.path.join(OUT, "cmp_b.pdf"), common + [(250, 250, 100, 60, 1, 0, 0)])
    boxes = M.compare_pages(pa, pb)
    ex, ey = 250 * 2, (500 - 250 - 60) * 2
    good &= check(len(boxes) == 1 and covers(boxes[0], ex, ey, 200, 120), f"poppler: thêm một ô đỏ -> 1 hộp trùm đúng ô đó {boxes}")
    good &= check(M.compare_pages(pa, make(os.path.join(OUT, "cmp_c.pdf"), common)) == [], "poppler: dựng lại cùng PDF -> không hộp")
    print("TAT CA DAT" if good else "CO LOI")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
