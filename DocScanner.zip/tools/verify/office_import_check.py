"""Kiểm bộ nhập ODT / RTF / PPTX / XLSX (`OfficeImport.kt`, `RtfImport.kt`; phiên 20, 4.48.2) qua bản Java song song `OfficeImportCheck.java`.

Nguyên tắc: tệp đầu vào do công cụ THẬT tạo (LibreOffice, pandoc, python-pptx, openpyxl), đáp án lấy từ ĐỘC LẬP với bộ đọc:
  A. ODT  : (1) 24 tài liệu python-docx ngẫu nhiên -> LibreOffice -> ODT và pandoc -> ODT, đáp án = chính nội dung đã dựng; (2) pandoc đọc lại ODT (cấu trúc);
            (3) 9 ca XML viết tay (danh sách lồng nhau đánh số/gạch đầu dòng, bảng lồng, ghi chú cuối trang / thay đổi đã theo dõi / mục lục bị bỏ, khung văn bản...).
  B. RTF  : (1) cùng 24 tài liệu -> LibreOffice -> RTF và pandoc -> RTF; (2) văn bản xuất bởi LibreOffice (`--convert-to txt`) và pandoc đọc RTF; (3) 14 ca viết tay:
            `\\'hh` cp1252 / cp1258 / cp1251 / Shift-JIS (hai byte), `\\uN` + `\\ucN`, cặp thay thế (emoji), kiểu tiêu đề, danh sách, bảng, `\\binN`, nhóm bị bỏ...
  C. PPTX : python-pptx tạo (tiêu đề, nội dung nhiều cấp, hộp chữ, bảng, nhóm, thứ tự slide KHÁC số trong tên tệp, ô số trang) + vòng LibreOffice pptx->odp->pptx;
            đáp án = python-pptx đọc lại; `mc:Fallback` không nhân đôi.
  D. XLSX : openpyxl tạo (chuỗi, số, ngày, giờ, bool, lỗi, phần trăm, nghìn, tiền tệ, hệ 1904, trang ẩn, ô thưa, văn bản giàu định dạng, furigana) ; đáp án = openpyxl + CSV "như hiển
            thị" của LibreOffice; mọi số ngày 1..80000 so với `datetime`.
  E. Thử âm tính: các bản Java cố ý hỏng phải bị bài kiểm bắt.
Chạy: python3 office_import_check.py   (cần java, soffice, pandoc, python-docx, python-pptx, openpyxl; ~3-5 phút)
"""
import copy, datetime, json, os, random, re, shutil, subprocess, sys, tempfile, zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import OUT

HERE = os.path.dirname(os.path.abspath(__file__))
JAVA = os.path.join(HERE, "OfficeImportCheck.java")
FAIL = []
ART = {}   # đường dẫn các tệp đã dựng, để phần E (thử âm tính) dùng lại
rnd = random.Random(20261022)
hx = lambda s: s.encode("utf-8").hex()
unhx = lambda h: bytes.fromhex(h).decode("utf-8")
norm = lambda s: re.sub(r"\s+", " ", s.replace("\u00a0", " ")).strip()


def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok:
        FAIL.append(msg)
    return ok


def run_java(cmds, java_file=JAVA):
    r = subprocess.run(["java", java_file], input="\n".join(cmds) + "\n", capture_output=True, text=True)
    if r.returncode:
        print(r.stdout[-1500:], r.stderr[-2500:]); sys.exit(1)
    secs, cur = [], None
    for line in r.stdout.split("\n"):
        if line.startswith("== "):
            cur = []; secs.append(cur)
        elif cur is not None and line != "":
            cur.append(line)
    assert len(secs) == len(cmds), (len(secs), len(cmds))
    return secs


def blocks(lines):
    out = []
    for l in lines:
        if l.startswith("B|"):
            _, k, lv, m, t = l.split("|")
            out.append((k, int(lv), unhx(m), unhx(t)))
        elif l.startswith("ERR"):
            out.append(("ERR", 0, "", l))
    return out


def sheets(lines):
    out = []
    for l in lines:
        if l.startswith("S|"):
            out.append([unhx(l[2:]), []])
        elif l.startswith("R|"):
            out[-1][1].append([unhx(c) if c else "" for c in l[2:].split(",")])
        elif l.startswith("ERR"):
            out.append(["ERR", [[l]]])
    return out


def key(b):
    return (b[0], b[1], b[2], norm(b[3]))


def lo_convert(files, fmt, outdir, timeout=900):
    os.makedirs(outdir, exist_ok=True)
    subprocess.run(["soffice", "--headless", "--convert-to", fmt, "--outdir", outdir] + files, capture_output=True, timeout=timeout)


def work():
    return tempfile.mkdtemp(dir=OUT)


# =========================================================================== tài liệu python-docx ngẫu nhiên (đáp án = nội dung đã dựng)
import docx
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

WORDS = ["alpha", "Beta", "gamma", "Tiếng", "Việt", "ăâêôơư", "Đường", "日本語", "テスト", "中文", "한국어", "naïve", "café", "Ünïcode", "€100", "½", "—", "“quoted”",
         "it's", "R&D", "a<b", "x>y", "5%", "😀", "Ω", "ß", "mot", "hai", "ba"]


def numid_of(d, style):
    el = d.styles[style].element.find(".//" + qn("w:numId"))
    return el.get(qn("w:val"))


HAS_TITLE = {}
TITLE_FIRST = {}


def ensure_levels(d, style):
    """Mẫu python-docx chỉ định nghĩa cấp 0 của danh sách; thêm cấp 1-2 (cùng kiểu số / gạch đầu dòng) để cấp lồng nhau có nghĩa."""
    nid = numid_of(d, style)
    num = d.part.numbering_part.element
    aid = [n.find(qn("w:abstractNumId")).get(qn("w:val")) for n in num.findall(qn("w:num")) if n.get(qn("w:numId")) == nid][0]
    a = [x for x in num.findall(qn("w:abstractNum")) if x.get(qn("w:abstractNumId")) == aid][0]
    lvls = a.findall(qn("w:lvl"))
    fmt = lvls[0].find(qn("w:numFmt")).get(qn("w:val"))
    for il in (1, 2):
        if not any(l.get(qn("w:ilvl")) == str(il) for l in lvls):
            c = copy.deepcopy(lvls[0]); c.set(qn("w:ilvl"), str(il))
            if fmt != "bullet":
                c.find(qn("w:lvlText")).set(qn("w:val"), f"%{il + 1}.")
            ppr = c.find(qn("w:pPr"))
            ind = ppr.find(qn("w:ind")) if ppr is not None else None
            if ind is not None:
                ind.set(qn("w:left"), str(720 * (il + 1)))
            a.findall(qn("w:lvl"))[-1].addnext(c)


def make_doc(path):
    d = docx.Document()
    ref = []
    HAS_TITLE[path] = False
    TITLE_FIRST[path] = False
    ensure_levels(d, "List Bullet"); ensure_levels(d, "List Number")
    bullet_id, number_id = numid_of(d, "List Bullet"), numid_of(d, "List Number")
    w = lambda: " ".join(rnd.choice(WORDS) for _ in range(rnd.randint(1, 5)))
    for _ in range(rnd.randint(3, 9)):
        k = rnd.random()
        if k < .10:
            t = w(); d.add_heading(t, 0); ref.append(("H", 1, "", t)); HAS_TITLE[path] = t; TITLE_FIRST[path] = TITLE_FIRST[path] or len(ref) == 1
        elif k < .28:
            n = rnd.randint(1, 4); t = w(); d.add_heading(t, n); ref.append(("H", n, "", t))
        elif k < .48:
            p = d.add_paragraph(); t1, t2 = w(), w(); p.add_run(t1).bold = True; p.add_run(" " + t2)
            if rnd.random() < .25: p.add_run("\tTab")
            if rnd.random() < .25:
                r = p.add_run(); r.add_break(); r.add_text("dòng hai")
            ref.append(("P", 0, "", p.text.replace("\n", "\n")))
        elif k < .72:
            numbered = rnd.random() < .5
            style, nid = ("List Number", number_id) if numbered else ("List Bullet", bullet_id)
            for _ in range(rnd.randint(1, 4)):
                t = w(); p = d.add_paragraph(t, style=style); il = rnd.choice([0, 0, 1, 2])
                if il:
                    pPr = p._p.get_or_add_pPr(); numPr = OxmlElement("w:numPr")
                    a = OxmlElement("w:ilvl"); a.set(qn("w:val"), str(il)); b = OxmlElement("w:numId"); b.set(qn("w:val"), nid)
                    numPr.append(a); numPr.append(b); pPr.append(numPr)
                ref.append(("LI", il + 1, "#" if numbered else "\u2022", t))
        elif k < .90:
            rows, cols = rnd.randint(1, 3), rnd.randint(2, 3); tb = d.add_table(rows=rows, cols=cols)
            for r in tb.rows:
                cells = []
                for c in r.cells:
                    t = w(); c.text = t; cells.append(t)
                ref.append(("ROW", 0, "", " | ".join(cells)))
        else:
            d.add_paragraph("")
    d.save(path)
    return [x for x in ref if norm(x[3])]


def tokens(s):
    return [t for t in re.findall(r"\w+", s, re.UNICODE) if not t.isdigit()]


def main():
    tmp = work()
    try:
        part_a_b(tmp)
        run_rtf_cases()
        part_c(tmp)
        part_d(tmp)
        part_e(tmp)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("TAT CA DAT" if not FAIL else f"CO LOI ({len(FAIL)})")
    return 1 if FAIL else 0


# =========================================================================== A + B
ODF = ('xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" '
       'xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" '
       'xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0"')


def odt_xml(body, auto=""):
    return (f'<?xml version="1.0" encoding="UTF-8"?><office:document-content {ODF}><office:automatic-styles>{auto}</office:automatic-styles>'
            f'<office:body><office:text>{body}</office:text></office:body></office:document-content>')


def ast_text(inl):
    o = []
    for x in inl:
        t = x["t"]
        if t == "Str": o.append(x["c"])
        elif t in ("Space", "SoftBreak"): o.append(" ")
        elif t == "LineBreak": o.append("\n")
        elif t == "Code": o.append(x["c"][1])
        elif t in ("Emph", "Strong", "Strikeout", "Underline", "Superscript", "Subscript", "SmallCaps", "Quoted"): o.append(ast_text(x["c"] if t != "Quoted" else x["c"][1]))
        elif t in ("Link", "Image", "Span"): o.append(ast_text(x["c"][1]))
    return "".join(o)


def ast_blocks(bs, depth=0, out=None):
    out = [] if out is None else out
    for b in bs:
        t = b["t"]
        if t == "Header": out.append(("H", min(b["c"][0], 6), ast_text(b["c"][2])))
        elif t in ("Para", "Plain"): out.append(("P", 0, ast_text(b["c"])))
        elif t == "BlockQuote": ast_blocks(b["c"], depth, out)
        elif t in ("BulletList", "OrderedList"):
            items = b["c"] if t == "BulletList" else b["c"][1]
            for it in items:
                first = True
                for sub in it:
                    if sub["t"] in ("Para", "Plain") and first: out.append(("LI", depth + 1, ast_text(sub["c"]))); first = False
                    elif sub["t"] in ("Para", "Plain"): out.append(("P", 0, ast_text(sub["c"])))
                    elif sub["t"] in ("BulletList", "OrderedList"): ast_blocks([sub], depth + 1, out)
        elif t == "Table":
            c = b["c"]; head = c[3][1]; bodies = c[4]
            rows = list(head) + [r for bd in bodies for r in bd[3]]
            for r in rows:
                cells = [ast_text([i for blk in cell[4] for i in (blk["c"] if blk["t"] in ("Para", "Plain") else [])]) for cell in r[1]]
                out.append(("ROW", 0, " | ".join(norm(x) for x in cells)))
    return [x for x in out if not (x[0] in ("P", "H") and not norm(x[2]))]


def part_a_b(tmp):
    print("== A/B. tài liệu python-docx ngẫu nhiên -> LibreOffice / pandoc -> ODT, RTF")
    N = 24
    ddir = os.path.join(tmp, "docx"); os.makedirs(ddir)
    refs, files = [], []
    for i in range(N):
        p = os.path.join(ddir, f"d{i:02d}.docx"); refs.append(make_doc(p)); files.append(p)
    lo_convert(files, "odt", os.path.join(tmp, "lo_odt"))
    lo_convert(files, "rtf", os.path.join(tmp, "lo_rtf"))
    pdir = os.path.join(tmp, "pd"); os.makedirs(pdir)
    for p in files:
        base = os.path.basename(p)[:-5]
        for ext in ("odt", "rtf"):
            subprocess.run(["pandoc", p, "-o", os.path.join(pdir, f"{base}.{ext}")], capture_output=True)
    sets = {"LibreOffice ODT": ("ODT", "lo_odt", "odt"), "pandoc ODT": ("ODT", "pd", "odt"), "LibreOffice RTF": ("RTF", "lo_rtf", "rtf"), "pandoc RTF": ("RTF", "pd", "rtf")}
    results = {}
    nli = sum(1 for r in refs for x in r if x[0] == "LI"); nh = sum(1 for r in refs for x in r if x[0] == "H"); nt = sum(1 for r in refs for x in r if x[0] == "ROW")
    nested = sum(1 for r in refs for x in r if x[0] == "LI" and x[1] >= 2)
    for label, (cmd, sub, ext) in sets.items():
        paths = [os.path.join(tmp, sub, f"d{i:02d}.{ext}") for i in range(N)]
        got = run_java([f"{cmd} {p}" for p in paths])
        results[label] = (paths, [blocks(g) for g in got])
        bad = []
        for i, (mine, ref) in enumerate(zip(results[label][1], refs)):
            if label.startswith("pandoc"):   # pandoc viết lại cấu trúc khi chuyển đổi: yêu cầu NỘI DUNG (các từ theo thứ tự)
                title = HAS_TITLE[files[i]] if (label == "pandoc RTF" and TITLE_FIRST[files[i]]) else False   # bộ ghi RTF của pandoc bỏ đoạn Title ĐẦU TÀI LIỆU (siêu dữ liệu); bộ ghi ODT thì viết nó
                m, e = tokens(" ".join(b[3] for b in mine)), tokens(" ".join(b[3] for b in ref if not (title and b[3] == title)))
            else:
                m, e = [key(b) for b in mine], [key(b) for b in ref]
            if m != e: bad.append((i, m, e))
        what = "chuỗi từ = nội dung đã dựng" if label.startswith("pandoc") else "khối (loại, cấp, dấu danh sách, chữ) = nội dung đã dựng"
        check(not bad, f"{label}: {what} ở {N - len(bad)}/{N} tài liệu ({nh} tiêu đề, {nli} mục danh sách, trong đó {nested} từ cấp 2, {nt} hàng bảng)")
        for i, m, e in bad[:2]:
            print(f"   --- {label} d{i:02d}")
            for k, (a, b) in enumerate(zip(m + [None] * 40, e + [None] * 40)):
                if a != b:
                    print("   mine:", a, "\n   ref :", b)
                    if os.environ.get("DEBUG_OFFICE"):
                        print("   ctx mine:", m[max(0, k - 3):k + 4], "\n   ctx ref :", e[max(0, k - 3):k + 4]); shutil.copy(paths[i], f"/tmp/fail_{label.replace(' ', '_')}_{i}.{ext}")
                    break

    # pandoc đọc lại ODT (cấu trúc: loại, cấp, chữ; không tính bảng - pandoc làm mất chữ trong ô khi đọc ODT - và bỏ tài liệu có Title: pandoc coi đó là siêu dữ liệu)
    for label in ("LibreOffice ODT", "pandoc ODT"):
        paths, mine_all = results[label]
        same = tot = 0
        for i, (p, mine) in enumerate(zip(paths, mine_all)):
            if HAS_TITLE[files[i]]:
                continue
            r = subprocess.run(["pandoc", "-f", "odt", "-t", "json", p], capture_output=True, text=True)
            pb = [(k, l, norm(t)) for k, l, t in ast_blocks(json.loads(r.stdout)["blocks"]) if k != "ROW"]
            mm = [(b[0], b[1], norm(b[3])) for b in mine if b[0] != "ROW"]
            tot += 1; same += (mm == pb)
            if mm != pb and tot - same <= 2:
                for a, b in zip(mm + [None] * 40, pb + [None] * 40):
                    if a != b: print(f"   pandoc d{i:02d} mine:", a, "\n   pandoc:", b); break
        check(same == tot and tot >= 10, f"{label}: pandoc đọc lại ODT, cấu trúc (loại, cấp, chữ) khớp bộ đọc ở {same}/{tot} tài liệu không có Title")

    # văn bản RTF: LibreOffice xuất txt, pandoc đọc RTF -> cùng chuỗi từ (bỏ số thứ tự do LibreOffice thêm vào danh sách đánh số)
    lo_convert([os.path.join(tmp, "lo_rtf", f"d{i:02d}.rtf") for i in range(N)], "txt:Text", os.path.join(tmp, "lo_txt"))
    ok_lo = ok_pd = 0
    for i, mine in enumerate(results["LibreOffice RTF"][1]):
        mine_tok = tokens(" ".join(b[3] for b in mine))
        lo_tok = tokens(open(os.path.join(tmp, "lo_txt", f"d{i:02d}.txt"), encoding="utf-8-sig", errors="replace").read())
        ok_lo += (mine_tok == lo_tok)
        if mine_tok != lo_tok and N - ok_lo <= 2: print("   txt lệch:", mine_tok[:12], lo_tok[:12])
        pr = subprocess.run(["pandoc", "-f", "rtf", "-t", "plain", "--wrap=none", os.path.join(tmp, "lo_rtf", f"d{i:02d}.rtf")], capture_output=True, text=True)
        ok_pd += (mine_tok == tokens(pr.stdout))
    check(ok_lo == N, f"RTF: chuỗi từ = bản `txt` do chính LibreOffice xuất ở {ok_lo}/{N} tài liệu (độc lập với bộ đọc)")
    check(ok_pd >= N - 3, f"RTF: chuỗi từ = `pandoc -f rtf` ở {ok_pd}/{N} tài liệu")

    # ---- ODT viết tay
    print("== A3. ODT viết tay")
    LN = '<text:list-style style:name="LN"><text:list-level-style-number text:level="1"/><text:list-level-style-bullet text:level="2"/></text:list-style>'
    cases = [
        ("tiêu đề + Title + thực thể", odt_xml('<text:h text:outline-level="2">A &amp; B &lt;c&gt; &#233; &apos;x&apos;</text:h><text:p text:style-name="Title">Ti</text:p><text:h text:outline-level="9">deep</text:h>'),
         [("H", 2, "", "A & B <c> é 'x'"), ("H", 1, "", "Ti"), ("H", 6, "", "deep")]),
        ("khoảng trắng / tab / xuống dòng", odt_xml('<text:p>a<text:s text:c="3"/>b<text:tab/>c<text:line-break/>d   e</text:p>'), [("P", 0, "", "a b c\nd e")]),
        ("danh sách lồng nhau (đánh số rồi gạch đầu dòng), đoạn tiếp nối", odt_xml('<text:list text:style-name="LN"><text:list-item><text:p>one</text:p><text:list><text:list-item><text:p>sub</text:p></text:list-item></text:list></text:list-item><text:list-item><text:p>two</text:p><text:p>cont</text:p></text:list-item></text:list>', LN),
         [("LI", 1, "#", "one"), ("LI", 2, "\u2022", "sub"), ("LI", 1, "#", "two"), ("P", 0, "", "cont")]),
        ("bảng: ô gộp, hàng trống, bảng lồng, nhiều đoạn trong ô", odt_xml('<table:table><table:table-row><table:table-cell><text:p>A</text:p></table:table-cell><table:table-cell><text:p>B1</text:p><text:p>B2</text:p></table:table-cell><table:covered-table-cell/></table:table-row>'
                                                                      '<table:table-row><table:table-cell><text:p/></table:table-cell></table:table-row>'
                                                                      '<table:table-row><table:table-cell><table:table><table:table-row><table:table-cell><text:p>in</text:p></table:table-cell></table:table-row></table:table><text:p>out</text:p></table:table-cell><table:table-cell><text:p>Z</text:p></table:table-cell></table:table-row></table:table><text:p>after</text:p>'),
         [("ROW", 0, "", "A | B1 B2"), ("ROW", 0, "", "in out | Z"), ("P", 0, "", "after")]),
        ("bị bỏ: thay đổi đã theo dõi, chú thích cuối trang, ghi chú, mục lục", odt_xml('<text:tracked-changes><text:changed-region><text:deletion><text:p>DELETED</text:p></text:deletion></text:changed-region></text:tracked-changes>'
                                                                                '<text:p>keep<text:note><text:note-citation>1</text:note-citation><text:note-body><text:p>FOOT</text:p></text:note-body></text:note>this<office:annotation><text:p>COMMENT</text:p></office:annotation></text:p>'
                                                                                '<text:table-of-content><text:index-body><text:p>TOC LINE</text:p></text:index-body></text:table-of-content><text:p>end</text:p>'),
         [("P", 0, "", "keepthis"), ("P", 0, "", "end")]),
        ("khung văn bản trong đoạn", odt_xml('<text:p>before<draw:frame><draw:text-box><text:p>in box</text:p></draw:text-box></draw:frame>after</text:p>'), [("P", 0, "", "in box"), ("P", 0, "", "beforeafter")]),
        ("danh sách không có kiểu -> gạch đầu dòng", odt_xml('<text:list><text:list-item><text:p>x</text:p></text:list-item></text:list>'), [("LI", 1, "\u2022", "x")]),
        ("CDATA, chú thích XML, thẻ tự đóng", odt_xml('<!-- c --><text:p>a<![CDATA[ <&> ]]>b<text:span/></text:p>'), [("P", 0, "", "a <&> b")]),
        ("XML hỏng (thiếu thẻ đóng) không làm sập", odt_xml('<text:p>ok</text:p><text:p>cut'), [("P", 0, "", "ok")]),
    ]
    got = run_java([f"ODTXML {hx(x)}" for _, x, _ in cases])
    for (name, _, exp), g in zip(cases, got):
        check([key(b) for b in blocks(g)] == [key(b) for b in exp], f"ODT viết tay - {name}")
    return results


# =========================================================================== RTF viết tay
def rtf_cases():
    jp = "あい".encode("cp932").hex()
    jp_esc = "".join("\\'" + jp[i:i + 2] for i in range(0, len(jp), 2))
    ru_esc = "".join("\\'%02x" % b for b in "Привет".encode("cp1251"))
    vi = "ăâêôơưđ".encode("cp1258"); vi_esc = "".join("\\'%02x" % b for b in vi)
    return [
        ("cp1252 + \\u kèm dự phòng", r"{\rtf1\ansi\ansicpg1252\deff0{\fonttbl{\f0 Arial;}}\pard caf\'e9 \u8212? dash\par}", [("P", 0, "", "café — dash")]),
        ("\\uc0 không bỏ ký tự", r"{\rtf1\ansi\uc0\u8364 100\par}", [("P", 0, "", "€100")]),
        ("\\uc2 bỏ hai ký tự", r"{\rtf1\ansi\uc2\u8364\'80\'80 ok\par}", [("P", 0, "", "€ ok")]),
        ("cặp thay thế (emoji)", r"{\rtf1\ansi\u-10179?\u-8704? x\par}", [("P", 0, "", "😀 x")]),
        ("Shift-JIS hai byte", r"{\rtf1\ansi\ansicpg932{\fonttbl{\f0\fcharset128 MS Mincho;}}\f0 " + jp_esc + r"\par}", [("P", 0, "", "あい")]),
        ("cp1258 tiếng Việt", r"{\rtf1\ansi\ansicpg1258 " + vi_esc + r"\par}", [("P", 0, "", "ăâêôơưđ")]),
        ("phông Cyrillic theo nhóm", r"{\rtf1\ansi\ansicpg1252{\fonttbl{\f0 Arial;}{\f1\fcharset204 Arial;}}{\f1 " + ru_esc + r"} caf\'e9\par}", [("P", 0, "", "Привет café")]),
        ("nhóm bị bỏ: generator, info, header, footnote, pict + \\bin", r"{\rtf1\ansi{\*\generator X;}{\info{\title T}}{\header HHH\par}a{\footnote FFF}{\pict\wmetafile8\bin5 {}{}x}b{\*\unknown zzz}c\par}", [("P", 0, "", "abc")]),
        ("kiểu tiêu đề, outlinelevel", r"{\rtf1\ansi{\stylesheet{\s0 Normal;}{\s1 heading 1;}{\s2 Heading 2;}{\s9 Title;}}\pard\s1 H1\par\pard\s2 H2\par\pard\s9 T\par\pard\s0\outlinelevel2 L3\par\pard\plain\par}",
         [("H", 1, "", "H1"), ("H", 2, "", "H2"), ("H", 1, "", "T"), ("H", 3, "", "L3")]),
        ("danh sách: {\\listtext}, {\\*\\listtext}, {\\pntext}, \\ilvl", r"{\rtf1\ansi\pard{\listtext\pard 1.\tab}one\par\pard{\*\listtext\pard \u8226\'95\tab}\ilvl1 two\par\pard{\pntext\pard\f3\'b7\tab}three\par}",
         [("LI", 1, "#", "one"), ("LI", 2, "\u2022", "two"), ("LI", 1, "\u2022", "three")]),
        ("bảng", r"{\rtf1\ansi\trowd\cellx1000\cellx2000\pard\intbl A\cell B\cell\row\trowd\cellx1000\cellx2000\pard\intbl C\par D\cell \cell\row\trowd\cellx1000\pard\intbl \cell\row\pard after\par}",
         [("ROW", 0, "", "A | B"), ("ROW", 0, "", "C D |"), ("P", 0, "", "after")]),
        ("trường: giữ kết quả, bỏ mã", r'{\rtf1\ansi{\field{\*\fldinst HYPERLINK "http://x"}{\fldrslt link text}} end\par}', [("P", 0, "", "link text end")]),
        ("ký hiệu: \\line \\tab \\~ \\emdash \\lquote \\\\ \\{ \\}", r"{\rtf1\ansi a\line b\tab c\~d\emdash\lquote x\rquote\ldblquote y\rdblquote\\ \{ \}\par}", [("P", 0, "", "a\nb c d—‘x’“y”\\ { }")]),
        ("ngoặc không cân bằng / cụt", r"{\rtf1\ansi {abc", [("P", 0, "", "abc")]),
    ]


def run_rtf_cases():
    print("== B3. RTF viết tay")
    cases = rtf_cases()
    got = run_java([f"RTFHEX {s.encode('latin-1').hex()}" for _, s, _ in cases])
    for (name, _, exp), g in zip(cases, got):
        mine = [key(b) for b in blocks(g)]
        check(mine == [key(b) for b in exp], f"RTF viết tay - {name}")
        if mine != [key(b) for b in exp]:
            print("   mine:", mine, "\n   ref :", [key(b) for b in exp])


# =========================================================================== C, D, E: nối ở các phần sau
# =========================================================================== C. PPTX
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE, PP_PLACEHOLDER
from pptx.util import Inches
from lxml import etree

A_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
P_NS = "http://schemas.openxmlformats.org/presentationml/2006/main"
TITLE_TYPES = (PP_PLACEHOLDER.TITLE, PP_PLACEHOLDER.CENTER_TITLE)
SKIP_TYPES = (PP_PLACEHOLDER.SLIDE_NUMBER, PP_PLACEHOLDER.DATE, PP_PLACEHOLDER.FOOTER, PP_PLACEHOLDER.HEADER)


def para_text(p):
    return p.text.replace("\v", "\n").replace("\x0b", "\n")


def bullet_of(p):
    pPr = p._p.find(f"{{{A_NS}}}pPr")
    if pPr is not None:
        for ch in pPr:
            tag = etree.QName(ch).localname
            if tag == "buNone": return 0
            if tag == "buChar": return 1
            if tag == "buAutoNum": return 2
    return -1


def py_blocks(path):
    """Đáp án ĐỘC LẬP: python-pptx đọc tệp (thứ tự slide theo presentation.xml, quan hệ, vùng tên XML) rồi áp các quy tắc văn bản đã ghi ở 4.48.2."""
    prs = Presentation(path)
    out = []
    for pos, slide in enumerate(prs.slides, 1):
        title, body = None, []

        def walk(shapes):
            nonlocal title
            for sh in shapes:
                if sh.shape_type == MSO_SHAPE_TYPE.GROUP:
                    walk(sh.shapes); continue
                ph = sh.placeholder_format.type if sh.is_placeholder else None
                if getattr(sh, "has_table", False) and sh.has_table:
                    for r in sh.table.rows:
                        cells = []
                        for c in r.cells:
                            if c.is_spanned: continue
                            cells.append(norm(" ".join(para_text(p) for p in c.text_frame.paragraphs if norm(para_text(p)))))
                        if any(cells): body.append(("ROW", 0, "", " | ".join(cells)))
                    continue
                if not getattr(sh, "has_text_frame", False) or not sh.has_text_frame:
                    continue
                paras = [(p.level, bullet_of(p), norm(para_text(p))) for p in sh.text_frame.paragraphs]
                paras = [x for x in paras if x[2]]
                if sh.is_placeholder and ph in TITLE_TYPES:
                    j = norm(" ".join(t for _, _, t in paras))
                    if j: title = j if title is None else title + " " + j
                elif sh.is_placeholder and ph in SKIP_TYPES:
                    continue
                else:
                    body_ph = sh.is_placeholder and ph != PP_PLACEHOLDER.SUBTITLE
                    for lvl, bu, t in paras:
                        li = (bu != 0) if body_ph else (bu > 0)
                        body.append(("LI", lvl + 1, "#" if bu == 2 else "\u2022", t) if li else ("P", 0, "", t))
        walk(slide.shapes)
        if title is None and not body: continue
        out.append(("H", 2, "", title if title is not None else f"Slide {pos}"))
        out += body
    return out


def make_pptx(path):
    prs = Presentation()
    W = lambda: " ".join(rnd.choice(WORDS) for _ in range(rnd.randint(1, 4)))
    n = rnd.randint(3, 6)
    for _ in range(n):
        kind = rnd.choice(["content", "content", "titleslide", "titleonly", "blank", "group"])
        if kind == "content":
            s = prs.slides.add_slide(prs.slide_layouts[1])
            if rnd.random() < .85: s.shapes.title.text = W()
            tf = s.placeholders[1].text_frame
            first = True
            for _ in range(rnd.randint(1, 4)):
                p = tf.paragraphs[0] if first else tf.add_paragraph(); first = False
                p.text = W(); p.level = rnd.choice([0, 0, 1, 2])
                if rnd.random() < .15: p.add_line_break(); r = p.add_run(); r.text = "dòng hai"
                if rnd.random() < .12:
                    pPr = p._p.get_or_add_pPr(); etree.SubElement(pPr, f"{{{A_NS}}}buNone")
            if rnd.random() < .4:
                tb = s.shapes.add_textbox(Inches(1), Inches(6), Inches(4), Inches(1)); tb.text_frame.text = W()
        elif kind == "titleslide":
            s = prs.slides.add_slide(prs.slide_layouts[0]); s.shapes.title.text = W(); s.placeholders[1].text_frame.text = W()
        elif kind == "titleonly":
            s = prs.slides.add_slide(prs.slide_layouts[5]); s.shapes.title.text = W()
            rows, cols = rnd.randint(1, 3), rnd.randint(2, 3)
            tb = s.shapes.add_table(rows, cols, Inches(1), Inches(2), Inches(6), Inches(1.5)).table
            for r in range(rows):
                for c in range(cols): tb.cell(r, c).text = W()
        elif kind == "blank":
            s = prs.slides.add_slide(prs.slide_layouts[6])
            for k in range(rnd.randint(1, 3)):
                tb = s.shapes.add_textbox(Inches(1), Inches(1 + k), Inches(4), Inches(.5)); tb.text_frame.text = W()
        else:
            s = prs.slides.add_slide(prs.slide_layouts[6])
            g = s.shapes.add_group_shape()
            for k in range(2):
                tb = g.shapes.add_textbox(Inches(1), Inches(1 + k), Inches(4), Inches(.5)); tb.text_frame.text = W()
        if rnd.random() < .5:   # ô số trang / chân trang phải bị bỏ qua
            sp = etree.fromstring(f'<p:sp xmlns:p="{P_NS}" xmlns:a="{A_NS}"><p:nvSpPr><p:cNvPr id="99" name="Slide Number"/><p:cNvSpPr/><p:nvPr><p:ph type="sldNum" sz="quarter" idx="12"/></p:nvPr></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:p><a:fld id="{{B6F15528-21DE-4FAA-801E-634DDDAF4B2B}}" type="slidenum"><a:t>7</a:t></a:fld></a:p></p:txBody></p:sp>')
            s.shapes._spTree.append(sp)
    lst = prs.slides._sldIdLst
    ids = list(lst)
    rnd.shuffle(ids)                       # thứ tự trình chiếu KHÁC số trong tên tệp slideN.xml
    for el in ids: lst.remove(el)
    for el in ids: lst.append(el)
    prs.save(path)


def part_c(tmp):
    print("== C. PPTX: python-pptx tạo (thứ tự slide xáo trộn) + vòng LibreOffice pptx->odp->pptx; đáp án = python-pptx đọc lại")
    N = 24
    d = os.path.join(tmp, "pptx"); os.makedirs(d)
    files = []
    for i in range(N):
        p = os.path.join(d, f"s{i:02d}.pptx"); make_pptx(p); files.append(p)
    # mc:AlternateContent: PowerPoint ghi bản Choice + bản Fallback cùng một hình
    base = os.path.join(d, "mc_base.pptx")
    bp = Presentation(); bs = bp.slides.add_slide(bp.slide_layouts[1]); bs.shapes.title.text = "T"; bs.placeholders[1].text_frame.text = "B"; bp.save(base)
    zin = zipfile.ZipFile(base); mcp = os.path.join(d, "mc.pptx")
    with zipfile.ZipFile(mcp, "w", zipfile.ZIP_DEFLATED) as zout:
        for it in zin.infolist():
            data = zin.read(it.filename)
            if it.filename == "ppt/slides/slide1.xml":
                x = data.decode("utf-8")
                sp = ('<mc:AlternateContent xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006"><mc:Choice Requires="p14"><p:sp><p:nvSpPr><p:cNvPr id="50" name="A"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:p><a:r><a:t>MCTEXT</a:t></a:r></a:p></p:txBody></p:sp></mc:Choice>'
                      '<mc:Fallback><p:sp><p:nvSpPr><p:cNvPr id="51" name="B"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr><p:spPr/><p:txBody><a:bodyPr/><a:p><a:r><a:t>MCTEXT</a:t></a:r></a:p></p:txBody></p:sp></mc:Fallback></mc:AlternateContent>')
                x = x.replace("</p:spTree>", sp + "</p:spTree>"); data = x.encode("utf-8")
            zout.writestr(it, data)
    ART.update(pptx_files=files + [os.path.join(tmp, "pptx_lo", f"s{i:02d}.pptx") for i in range(8)], mc=mcp)
    lo_convert(files[:8], "odp", os.path.join(tmp, "pptx_odp"))
    lo_convert([os.path.join(tmp, "pptx_odp", f"s{i:02d}.odp") for i in range(8)], "pptx", os.path.join(tmp, "pptx_lo"))
    allf = files + [mcp] + [os.path.join(tmp, "pptx_lo", f"s{i:02d}.pptx") for i in range(8)]
    names = [f"python-pptx s{i:02d}" for i in range(N)] + ["mc:AlternateContent"] + [f"LibreOffice s{i:02d}" for i in range(8)]
    got = run_java([f"PPTX {p}" for p in allf])
    bad = []; nh = nli = nrow = 0
    for name, p, g in zip(names, allf, got):
        mine = [key(b) for b in blocks(g)]; ref = [key(b) for b in py_blocks(p)]
        nh += sum(1 for b in ref if b[0] == "H"); nli += sum(1 for b in ref if b[0] == "LI" and b[1] >= 2); nrow += sum(1 for b in ref if b[0] == "ROW")
        if name == "mc:AlternateContent":
            exp = [key(b) for b in py_blocks(base)] + [("P", 0, "", "MCTEXT")]
            check(sum(1 for b in mine if b[3] == "MCTEXT") == 1 and mine == exp, "PPTX: mc:AlternateContent - hình chỉ xuất hiện MỘT lần (bản Fallback bị bỏ), phần còn lại giữ nguyên")
            continue
        if mine != ref: bad.append((name, mine, ref))
    check(not bad, f"PPTX: khối (loại, cấp, dấu, chữ) = python-pptx đọc lại ở {len(allf) - 1 - len(bad)}/{len(allf) - 1} tệp ({nh} tiêu đề slide, {nli} mục nội dung từ cấp 2, {nrow} hàng bảng; thứ tự slide đã xáo trộn)")
    for name, m, r in bad[:2]:
        print("   ---", name)
        for a, b in zip(m + [None] * 40, r + [None] * 40):
            if a != b: print("   mine:", a, "\n   ref :", b); break
    # thứ tự trình chiếu: ít nhất một tệp có thứ tự khác số trong tên tệp
    shuffled = 0
    for p in files:
        z = zipfile.ZipFile(p); pres = z.read("ppt/presentation.xml").decode(); rels = z.read("ppt/_rels/presentation.xml.rels").decode()
        order = [re.search(r'Id="%s"[^>]*Target="([^"]+)"|Target="([^"]+)"[^>]*Id="%s"' % (rid, rid), rels) for rid in re.findall(r'<p:sldId [^>]*r:id="([^"]+)"', pres)]
        nums = [int(re.search(r"slide(\d+)", (m.group(1) or m.group(2))).group(1)) for m in order]
        shuffled += nums != sorted(nums)
    check(shuffled >= 15, f"bộ dữ liệu có thứ tự trình chiếu khác số tên tệp ở {shuffled}/{N} tệp (không kiểm chay)")
    return allf, names


# =========================================================================== D. XLSX
import csv, io
import openpyxl
from openpyxl.cell.rich_text import CellRichText, TextBlock
from openpyxl.cell.text import InlineFont
from openpyxl.utils.datetime import CALENDAR_MAC_1904, CALENDAR_WINDOWS_1900, from_excel

D = datetime.date
DT = datetime.datetime
T = datetime.time
# (giá trị, mã định dạng, nguồn đáp án, đáp án nếu nguồn = "exp")  -- "lo" = CSV "như hiển thị" của LibreOffice
CASES = [
    ("Hello", None, "exp", "Hello"),
    ("Tiếng Việt 日本語 😀", None, "exp", "Tiếng Việt 日本語 😀"),
    ("a & b < c > d \"q\" 'x'", None, "exp", "a & b < c > d \"q\" 'x'"),
    ("line1\nline2", None, "exp", "line1\nline2"),
    ("  leading and trailing  ", None, "exp", "  leading and trailing  "),
    (True, None, "exp", "TRUE"), (False, None, "exp", "FALSE"),
    ("#DIV/0!", None, "exp", "#DIV/0!"),
    (0, None, "lo", None), (1, None, "lo", None), (-7, None, "lo", None), (3.5, None, "lo", None), (0.1, None, "lo", None), (1 / 3, None, "lo", None),
    (123456789012345, None, "lo", None), (1234567890123456789, None, "lo", None), (1e-10, None, "lo", None), (0.1 + 0.2, None, "lo", None), (-0.000123, None, "lo", None),
    (D(2024, 2, 29), "yyyy-mm-dd", "exp", "2024-02-29"), (DT(2024, 5, 1, 13, 45, 30), "yyyy-mm-dd hh:mm:ss", "exp", "2024-05-01 13:45:30"),
    (DT(2024, 5, 1, 13, 45), "yyyy-mm-dd hh:mm", "exp", "2024-05-01 13:45"), (D(1900, 1, 15), "yyyy-mm-dd", "exp", "1900-01-15"), (D(1900, 3, 1), "yyyy-mm-dd", "exp", "1900-03-01"),
    (D(2099, 12, 31), "yyyy-mm-dd", "exp", "2099-12-31"), (T(8, 5, 0), "hh:mm:ss", "exp", "08:05:00"), (T(23, 59, 59), "hh:mm:ss", "exp", "23:59:59"), (T(8, 5, 0), "hh:mm", "exp", "08:05"),
    (D(2024, 3, 9), "d/m/yyyy", "exp", "2024-03-09"), (D(2024, 3, 9), "mm-dd-yy", "exp", "2024-03-09"), (D(2024, 3, 9), "dddd, mmmm d, yyyy", "exp", "2024-03-09"),
    (1234567.891, "#,##0.00", "lo", None), (-1234.5, "#,##0.00", "lo", None), (0, "#,##0.00", "lo", None), (0.256, "0.0%", "lo", None), (0.256, "0%", "lo", None),
    (1.005, "0.00", "lo", None), (2.675, "0.00", "lo", None), (0.5, "0", "lo", None), (1.5, "0", "lo", None), (2.5, "0", "lo", None), (-0.5, "0", "lo", None),
    (42, "00000", "lo", None), (3.14159, "0.000", "lo", None), (0.5, "#.##", "lo", None), (1234.5, "#,##0;(#,##0)", "lo", None), (-1234.5, "#,##0;(#,##0)", "lo", None),
    (1234.5, '#,##0.00 "VND"', "lo", None), (1234.5, '"$"#,##0.00', "lo", None), (1234.5, "$#,##0.00", "lo", None), (-1234.5, "#,##0.00;[Red]-#,##0.00", "lo", None),
    (1234567, "#,##0", "lo", None), (999.9996, "0.000", "lo", None), (0.000123, "0.00%", "lo", None), (12, "0.0", "lo", None), (12.3456, "0.0##", "lo", None),
    (1e6, "#,##0", "lo", None), (5, "0.00_);(0.00)", "lo", None), (1234.5, "0.00E+00", "exp", "1234.5"), (0.75, "# ?/?", "exp", "0.75"), (12345678.9, "#,##0.00,", "exp", "12345678.9"),
]
CASES_1904 = [c for c in CASES if isinstance(c[0], (D, DT, T)) and (not isinstance(c[0], (D, DT)) or c[0].year >= 1904)]


def build_main(path, cases, epoch1904=False):
    wb = openpyxl.Workbook()
    if epoch1904:
        wb.epoch = CALENDAR_MAC_1904
    ws = wb.active; ws.title = "Data"
    for i, (v, fmt, _, _) in enumerate(cases, 1):
        c = ws.cell(row=i, column=1, value=v)
        if fmt: c.number_format = fmt
    if not epoch1904:
        h = wb.create_sheet("Hidden"); h["A1"] = "HIDDEN"; h.sheet_state = "hidden"
        wb.create_sheet("Empty")
        sp = wb.create_sheet("Sparse"); sp["A1"] = "a"; sp["C3"] = "c"; sp["AB5"] = "ab"; sp["B7"] = ""; sp["A9"] = "end"
        ri = wb.create_sheet("Rich"); ri["A1"] = CellRichText("Hello ", TextBlock(InlineFont(b=True), "bold"), " world"); ri["B2"] = "x"
        fo = wb.create_sheet("Formula")
        for i, (f, fmt) in enumerate([("=1+2", None), ('="a"&"b"', None), ("=1/0", None), ("=TRUE()", None), ("=DATE(2024,2,29)", "yyyy-mm-dd"), ("=1/3", None), ("=A1&B1", None)], 1):
            c = fo.cell(row=i, column=1, value=f)
            if fmt: c.number_format = fmt
        fo["A9"] = "x"; fo["B9"] = "y"
    wb.save(path)


def lo_csv(xlsx, outdir):
    """CSV "như hiển thị" của LibreOffice cho MỌI trang: {tên trang: [[ô...]...]}."""
    os.makedirs(outdir, exist_ok=True)
    filt = 'csv:Text - txt - csv (StarCalc):44,34,76,1,,0,false,true,true,false,false,-1'   # token 9 = lưu ô NHƯ HIỂN THỊ, token 12 = -1: mọi trang
    subprocess.run(["soffice", "--headless", "--convert-to", filt, "--outdir", outdir, xlsx], capture_output=True, timeout=600)
    base = os.path.basename(xlsx)[:-5]
    out = {}
    for f in os.listdir(outdir):
        if f.startswith(base + "-") and f.endswith(".csv"):
            name = f[len(base) + 1:-4]
            out[name] = list(csv.reader(io.StringIO(open(os.path.join(outdir, f), encoding="utf-8").read())))
    return out


def trim_rows(rows):
    out = []
    for r in rows:
        last = len(r)
        while last and r[last - 1] == "": last -= 1
        if last: out.append(r[:last])
    return out


def rows_of(sh_list, name):
    for n, r in sh_list:
        if n == name: return r
    return None


def part_d(tmp):
    print("== D. XLSX: openpyxl + LibreOffice tạo; đáp án = CSV 'như hiển thị' của LibreOffice, openpyxl, datetime")
    d = os.path.join(tmp, "xlsx"); os.makedirs(d)
    main = os.path.join(d, "main.xlsx"); build_main(main, CASES)
    m1904 = os.path.join(d, "mac1904.xlsx"); build_main(m1904, CASES_1904, True)
    lo_convert([main], "xlsx", os.path.join(d, "lo"))
    lo_main = os.path.join(d, "lo", "main.xlsx")
    ART.update(main=main, lo_main=lo_main)
    ref_csv = lo_csv(main, os.path.join(d, "csv"))
    got = run_java([f"XLSX {main}", f"XLSX {lo_main}", f"XLSX {m1904}"])
    for label, g in (("openpyxl", got[0]), ("LibreOffice xlsx->xlsx", got[1])):
        sh = [(n, r) for n, r in sheets(g)]
        names = [n for n, _ in sh]
        check(names == (["Data", "Sparse", "Rich", "Formula"]), f"XLSX ({label}): trang hiện = {names} (trang ẩn và trang trống bị bỏ, đúng thứ tự)")
        data = rows_of(sh, "Data")
        bad = []
        lo_rows = ref_csv["Data"]
        for i, (v, fmt, mode, exp) in enumerate(CASES):
            mine = data[i][0] if i < len(data) and data[i] else ""
            if v == 0 and fmt is None: mine = (data[i][0] if i < len(data) and data[i] else "0")
            want = exp if mode == "exp" else (lo_rows[i][0] if i < len(lo_rows) and lo_rows[i] else "")
            if label.startswith("Libre") and mode == "exp" and fmt in ("d/m/yyyy", "mm-dd-yy", "dddd, mmmm d, yyyy"):
                pass
            if mine != want and not (mode == "lo" and "E" in mine and re.sub(r"E([+-])0+([0-9])", r"E\1\2", want) == mine):   # LibreOffice in E+018, Excel / bộ đọc E+18
                bad.append((v, fmt, mine, want))
        nl = sum(1 for c in CASES if c[2] == "lo")
        check(not bad, f"XLSX ({label}): {len(CASES) - len(bad)}/{len(CASES)} ô đúng (chuỗi Unicode, số 15 chữ số, bool, lỗi, ngày / giờ ISO, {nl} ô theo định dạng số so với LibreOffice)")
        for b in bad[:6]:
            print("   lệch:", b)
    # ô thưa, văn bản giàu định dạng, công thức
    sp = rows_of(sheets(got[0]), "Sparse")
    # (B7 là chuỗi rỗng, hàng 2, 4, 6, 8 trống: các hàng này bị bỏ; vị trí cột được giữ)
    exp_sp = [["a"], ["", "", "c"], [""] * 27 + ["ab"], ["end"]]
    check(sp == exp_sp, "XLSX: ô thưa - cột giữ đúng chỗ (AB5 là cột 28), hàng trống bị bỏ")
    check(rows_of(sheets(got[0]), "Rich") == [["Hello bold world"], ["", "x"]], "XLSX: văn bản giàu định dạng (nhiều đoạn chữ) nối đúng")
    fo = rows_of(sheets(got[1]), "Formula")          # tệp do LibreOffice lưu: có giá trị đã tính
    want_fo = trim_rows(ref_csv["Formula"])
    check(fo == want_fo, f"XLSX: công thức - đọc KẾT QUẢ đã lưu (tệp của LibreOffice) = CSV của LibreOffice ({fo[:7]})")
    ro = rows_of(sheets(got[0]), "Formula")
    check(ro == [["x", "y"]], "XLSX: công thức chưa có giá trị lưu (openpyxl) cho ô rỗng, không sập (chỉ còn hàng có chữ)")
    # hệ ngày 1904
    s1904 = rows_of(sheets(got[2]), "Data")
    bad = [(c[0], c[3], s1904[i][0] if i < len(s1904) else None) for i, c in enumerate(CASES_1904) if (s1904[i][0] if i < len(s1904) else None) != c[3]]
    check(not bad and len(CASES_1904) >= 8, f"XLSX: hệ ngày 1904 - {len(CASES_1904) - len(bad)}/{len(CASES_1904)} ô ngày / giờ đúng ({bad[:2]})")

    # XML viết tay: inlineStr, t="str", lỗi, bool, tiền tố x:, furigana
    base = os.path.join(d, "tiny.xlsx"); wb = openpyxl.Workbook(); wb.active["A1"] = "漢字"; wb.active["A2"] = "second"; wb.save(base)
    def patched(name, fn_sheet=None, fn_sst=None):
        out = os.path.join(d, name)
        with zipfile.ZipFile(base) as zin, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
            for it in zin.infolist():
                data = zin.read(it.filename)
                if it.filename == "xl/worksheets/sheet1.xml" and fn_sheet: data = fn_sheet(data.decode("utf-8")).encode("utf-8")
                if it.filename == "xl/sharedStrings.xml" and fn_sst: data = fn_sst(data.decode("utf-8")).encode("utf-8")
                zout.writestr(it, data)
        return out
    cells = ('<row r="1"><c r="A1" t="inlineStr"><is><t>inline</t></is></c><c r="B1" t="str"><f>1+1</f><v>two</v></c><c r="C1" t="e"><v>#N/A</v></c><c r="D1" t="b"><v>1</v></c>'
             '<c r="E1"><v>12</v></c><c r="F1" t="inlineStr"><is><r><t xml:space="preserve">rich </t></r><r><t>inline</t></r><rPh sb="0" eb="1"><t>FURI</t></rPh></is></c></row>')
    p_inline = patched("inline.xlsx", lambda x: re.sub(r"<sheetData>.*</sheetData>", "<sheetData>" + cells + "</sheetData>", x, flags=re.S))
    pref = cells.replace("<row", "<x:row").replace("</row>", "</x:row>").replace("<c ", "<x:c ").replace("</c>", "</x:c>").replace("<v>", "<x:v>").replace("</v>", "</x:v>").replace("<is>", "<x:is>").replace("</is>", "</x:is>").replace("<t>", "<x:t>").replace("</t>", "</x:t>").replace("<t ", "<x:t ").replace("<r>", "<x:r>").replace("</r>", "</x:r>").replace("<rPh ", "<x:rPh ").replace("</rPh>", "</x:rPh>").replace("<f>", "<x:f>").replace("</f>", "</x:f>")
    p_prefix = patched("prefix.xlsx", lambda x: re.sub(r"<sheetData>.*</sheetData>", '<x:sheetData xmlns:x="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' + pref + "</x:sheetData>", x, flags=re.S))
    # furigana: openpyxl ghi chuỗi dạng inlineStr, nên dựng một sharedStrings.xml thật (kèm quan hệ + content-type) có <rPh>
    p_furi = os.path.join(d, "furi.xlsx")
    with zipfile.ZipFile(base) as zin, zipfile.ZipFile(p_furi, "w", zipfile.ZIP_DEFLATED) as zout:
        for it in zin.infolist():
            data = zin.read(it.filename)
            if it.filename == "xl/worksheets/sheet1.xml":
                data = re.sub(r"<sheetData>.*</sheetData>", '<sheetData><row r="1"><c r="A1" t="s"><v>0</v></c></row><row r="2"><c r="A2" t="s"><v>1</v></c></row></sheetData>', data.decode("utf-8"), flags=re.S).encode("utf-8")
            if it.filename == "xl/_rels/workbook.xml.rels":
                data = data.decode("utf-8").replace("</Relationships>", '<Relationship Id="rIdSS" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/></Relationships>').encode("utf-8")
            if it.filename == "[Content_Types].xml":
                data = data.decode("utf-8").replace("</Types>", '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/></Types>').encode("utf-8")
            zout.writestr(it, data)
        zout.writestr("xl/sharedStrings.xml", '<?xml version="1.0" encoding="UTF-8"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="2" uniqueCount="2"><si><t>漢字</t><rPh sb="0" eb="2"><t>かんじ</t></rPh><phoneticPr fontId="1"/></si><si><r><t>sec</t></r><r><rPr><b/></rPr><t>ond</t></r></si></sst>')
    ART.update(inline=p_inline, furi=p_furi)
    g = run_java([f"XLSX {p_inline}", f"XLSX {p_prefix}", f"XLSX {p_furi}"])
    want = [["inline", "two", "#N/A", "TRUE", "12", "rich inline"]]
    check(rows_of(sheets(g[0]), "Sheet") == want, "XLSX viết tay: inlineStr, t=\"str\", lỗi, bool, số, chữ giàu định dạng có furigana (rPh bị bỏ)")
    check(rows_of(sheets(g[1]), "Sheet") == want, "XLSX viết tay: phần tử có tiền tố vùng tên (x:row, x:c ...) vẫn đọc đúng")
    check(rows_of(sheets(g[2]), "Sheet") == [["漢字"], ["second"]], "XLSX viết tay: furigana (rPh) trong sharedStrings không lẫn vào chữ")

    # TOÀN BỘ số ngày: 1900 (có lỗi năm nhuận 1900) và 1904, so với openpyxl.from_excel
    out = run_java(["DATES 1 80000 0", "DATES 0 80000 1"])
    mine1900, mine1904 = out[0], out[1]
    bad1900 = [n for n in range(1, 80001) if n != 60 and mine1900[n - 1] != from_excel(n, CALENDAR_WINDOWS_1900).strftime("%Y-%m-%d")]
    bad1904 = [n for n in range(1, 80001) if mine1904[n] != from_excel(n, CALENDAR_MAC_1904).strftime("%Y-%m-%d")]
    check(not bad1900 and mine1900[59] == "1900-02-29", f"XLSX: 79.999 số ngày hệ 1900 (1..80000, trừ 60 = '1900-02-29' không có thật) = openpyxl.from_excel ({len(bad1900)} lệch {bad1900[:3]})")
    check(not bad1904 and mine1904[0] == "1904-01-01", f"XLSX: 80.001 số ngày hệ 1904 (0..80000; from_excel(0) của openpyxl trả về GIỜ nên 0 = 1904-01-01 kiểm riêng) = openpyxl ({len(bad1904)} lệch {bad1904[:3]})")
    # giờ trong ngày: đáp án = giờ / phút / giây đã chọn (không phải thuật toán của bộ đọc)
    cmds, wants = [], []
    for _ in range(300):
        days, h, mi, se = rnd.randint(1, 80000), rnd.randint(0, 23), rnd.randint(0, 59), rnd.randint(0, 59)
        if days == 60: days = 61
        serial = days + (h * 3600 + mi * 60 + se) / 86400
        cmds.append(f"SER {serial!r} {hx('yyyy-mm-dd hh:mm:ss')} 0")
        wants.append(from_excel(days, CALENDAR_WINDOWS_1900).strftime("%Y-%m-%d") + f" {h:02d}:{mi:02d}:{se:02d}")
    got = [x[0] for x in run_java(cmds)]
    check(got == wants, f"XLSX: 300 số ngày có phần thập phân -> 'yyyy-mm-dd hh:mm:ss' đúng giờ / phút / giây đã chọn ({sum(a != b for a, b in zip(got, wants))} lệch)")
    # mã định dạng -> loại
    cls = {"yyyy-mm-dd": "D---", "hh:mm:ss": "-TS-", "h:mm": "-T--", "[h]:mm:ss": "-TSE", "General": "NONE", "0.00": "NONE", "#,##0.00": "NONE", '#,##0 "d"': "NONE", "0.0%": "NONE",
           "mmm-yy": "D---", "mm:ss": "-TS-", "m/d/yy h:mm": "DT--", '[$-409]d-mmm-yy;@': "D---", "[Red]0.00": "NONE", '0.00" h"': "NONE", "0.00E+00": "NONE", "@": "NONE", "dd/mm/yyyy hh:mm:ss": "DTS-"}
    res = [x[0] for x in run_java([f"CLS {hx(c)}" for c in cls])]
    badc = [(c, r, e) for (c, e), r in zip(cls.items(), res) if r != e]
    check(not badc, f"XLSX: nhận diện mã định dạng ngày / giờ ({len(cls)} mã gồm 'm' là tháng hay phút, chữ nằm trong dấu nháy, [Red], [$-409]) ({badc[:2]})")
    return main


# =========================================================================== E. thử âm tính
def part_e(tmp):
    print("== E. thử âm tính: bản Java cố ý hỏng phải bị bài kiểm bắt")
    src = open(JAVA, encoding="utf-8").read()
    mdir = os.path.join(tmp, "mut"); os.makedirs(mdir)

    def make(old, new):
        assert src.count(old) == 1, old
        path = os.path.join(mdir, f"M{len(os.listdir(mdir))}.java")
        open(path, "w", encoding="utf-8").write(src.replace(old, new).replace("public class OfficeImportCheck", "public class " + os.path.basename(path)[:-5]).replace("OfficeImportCheck", os.path.basename(path)[:-5]))
        return path

    pptx_files = ART["pptx_files"]

    def probe_pptx_order(j):
        got = run_java([f"PPTX {p}" for p in pptx_files], j)
        return sum(1 for p, g in zip(pptx_files, got) if [key(b) for b in blocks(g)] != [key(b) for b in py_blocks(p)])

    def probe_mc(j):
        g = run_java([f"PPTX {ART['mc']}"], j)[0]
        return sum(1 for b in blocks(g) if b[3] == "MCTEXT") != 1

    def probe_rtf(j):
        cases = rtf_cases()
        got = run_java([f"RTFHEX {s.encode('latin-1').hex()}" for _, s, _ in cases], j)
        return sum(1 for (_, _, exp), g in zip(cases, got) if [key(b) for b in blocks(g)] != [key(b) for b in exp])

    def probe_dates(j):
        out = run_java(["DATES 1 120 0"], j)[0]
        return sum(1 for n in range(1, 121) if n != 60 and out[n - 1] != from_excel(n, CALENDAR_WINDOWS_1900).strftime("%Y-%m-%d"))

    def probe_furi(j):
        return rows_of(sheets(run_java([f"XLSX {ART['furi']}"], j)[0]), "Sheet") != [["漢字"], ["second"]]

    def probe_styles(j):
        data = rows_of(sheets(run_java([f"XLSX {ART['main']}"], j)[0]), "Data")
        return sum(1 for i, (v, fmt, mode, exp) in enumerate(CASES) if mode == "exp" and isinstance(v, (D, DT, T)) and data[i][0] != exp)

    def probe_odt(j):
        x = odt_xml('<text:p>keep<text:note><text:note-citation>1</text:note-citation><text:note-body><text:p>FOOT</text:p></text:note-body></text:note>this</text:p>')
        return [key(b) for b in blocks(run_java([f"ODTXML {hx(x)}"], j)[0])] != [("P", 0, "", "keepthis")]

    muts = [
        ("PPTX: sắp slide theo số trong tên tệp thay vì p:sldIdLst", "if (slides.isEmpty()) {", "if (true) { slides.clear();", probe_pptx_order),
        ("PPTX: không bỏ mc:Fallback", 'if (name.equals("mc:Fallback")) { st[0] = 1; return; }', "", probe_mc),
        ("RTF: không bỏ ký tự dự phòng sau \\uN (\\ucN)", "pendingSkip = cur.uc;", "pendingSkip = 0;", probe_rtf),
        ("RTF: \\'hh luôn giải mã bằng windows-1252", "return charsetForCodePage(cp);\n        }\n\n        void emit", 'return Charset.forName("windows-1252");\n        }\n\n        void emit', probe_rtf),
        ("XLSX: lỗi năm nhuận 1900 (bỏ phân biệt serial < 60)", "(days < 60 ? days - 25568 : days - 25569)", "days - 25569", probe_dates),
        ("XLSX: không bỏ furigana (rPh)", "if (f[0] && f[1] && phonetic[0] == 0) sb.append(t);", "if (f[0] && f[1]) sb.append(t);", probe_furi),
        ("XLSX: bỏ qua kiểu ô (ngày hiện ra là số)", "DateFmt d = st[1] >= 0 && st[1] < dates.size() ? dates.get(st[1]) : null;", "DateFmt d = null;", probe_styles),
        ("ODT: chữ trong phần tử bị bỏ (chú thích cuối trang) rò vào đoạn", "void text(String t) { if (skip[0] == 0 && !paras.isEmpty())", "void text(String t) { if (!paras.isEmpty())", probe_odt),
    ]
    for name, old, new, probe in muts:
        path = make(old, new)
        n = probe(path)
        check(bool(n), f"bản hỏng '{name}' bị bắt ({n if not isinstance(n, bool) else 'có'} ca lệch)")


if __name__ == "__main__":
    sys.exit(main())
