"""Kiểm chứng hình học của công cụ trang (phiên 16): cắt lề, vừa khổ giấy, kích thước giấy ở 200 DPI.

PageToolsCheck.java là bản Java chạy được của PageEditorTools.cropRect / fitRect / Paper.portraitPixels. Kiểm TÍNH CHẤT (không phải so với chính nó):
- cropRect: hình chữ nhật còn lại nằm TRONG ảnh, rộng/cao >= 1, đúng bằng phần trăm đã cắt (sai số 1 px do làm tròn xuống), phần trăm âm hoặc > 45 bị kẹp;
- fitRect: nằm trong khung, giữ nguyên tỉ lệ (sai số 0,1%), chạm ít nhất một cặp cạnh đối diện của khung, được căn giữa;
- kích thước giấy: A4/A5/A3/Letter/Legal ở 200 DPI khớp bảng tính độc lập từ kích thước ISO 216 / ANSI (mm -> inch -> px) và A4 = 1654 x 2339.
Thử âm tính: một bản cắt KHÔNG kẹp phần trăm (cho cắt 60% mỗi cạnh) bị bắt - nếu không, người dùng gõ 60 sẽ ra ảnh 1 px.
Chạy: python3 page_tools_check.py   (cần java 11+)
"""
import os, random, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
HERE = os.path.dirname(os.path.abspath(__file__))
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
    return cond
def run(lines, tag):
    cin, cout = os.path.join(OUT, f"pt_{tag}.in"), os.path.join(OUT, f"pt_{tag}.out")
    open(cin, "w", encoding="utf-8").write("\n".join(lines) + "\n")
    r = subprocess.run(["java", os.path.join(HERE, "PageToolsCheck.java"), cin, cout], capture_output=True, text=True)
    if r.returncode != 0: sys.exit("Java lỗi:\n" + r.stdout + r.stderr)
    return [l.split("\t") for l in open(cout, encoding="utf-8").read().split("\n")[:len(lines)]]

rng = random.Random(1610)
# ---- crop ----
cases = []
for _ in range(3000):
    w, h = rng.randint(1, 3000), rng.randint(1, 4000)
    p = [rng.choice([-5, 0, 0, 3, 5, 10, 12.5, 25, 45, 46, 60, 100, rng.uniform(0, 50)]) for _ in range(4)]
    cases.append((w, h, p))
res = run([f"crop\t{w}\t{h}\t" + "\t".join(str(x) for x in p) for w, h, p in cases], "crop")
bad = []
for (w, h, p), r in zip(cases, res):
    l, t, rr, b = map(int, r)
    if not (0 <= l < rr <= w and 0 <= t < b <= h): bad.append(("ngoài ảnh", w, h, p, r)); continue
    if rr - l < 1 or b - t < 1: bad.append(("rỗng", w, h, p, r)); continue
    pc = [min(45, max(0, x)) for x in p]
    exp_l, exp_t = int(w * pc[0] / 100), int(h * pc[1] / 100)
    exp_w = max(1, w - exp_l - int(w * pc[2] / 100)); exp_h = max(1, h - exp_t - int(h * pc[3] / 100))
    if (l, t, rr - l, b - t) != (exp_l, exp_t, exp_w, exp_h): bad.append(("sai số", w, h, p, r, (exp_l, exp_t, exp_w, exp_h)))
check(not bad, f"cropRect: 3000 ca ngẫu nhiên (kể cả % âm, > 45, ảnh 1 px) — trong ảnh, >= 1 px, đúng phần trăm" + (f" — lỗi {bad[:2]}" if bad else ""))
# 10% mỗi cạnh của 1000 x 2000 -> 800 x 1600
r = run(["crop\t1000\t2000\t10\t10\t10\t10"], "crop1")[0]
check(list(map(int, r)) == [100, 200, 900, 1800], f"cropRect: cắt 10% mỗi cạnh của 1000x2000 = (100,200)-(900,1800) (được {r})")

# ---- fit ----
fcases = [(rng.randint(1, 5000), rng.randint(1, 5000), rng.choice([1654, 2339, 1700, 2200, 100]), rng.choice([2339, 1654, 2200, 3307, 100])) for _ in range(3000)]
res = run([f"fit\t{a}\t{b}\t{c}\t{d}" for a, b, c, d in fcases], "fit")
bad = []
for (sw, sh, cw, ch), r in zip(fcases, res):
    x0, y0, x1, y1 = map(float, r)
    eps = 1e-3 * max(cw, ch)
    if x0 < -eps or y0 < -eps or x1 > cw + eps or y1 > ch + eps: bad.append(("ra ngoài khung", sw, sh, cw, ch, r)); continue
    w, h = x1 - x0, y1 - y0
    if abs((w / h) - (sw / sh)) > 0.001 * (sw / sh) + 1e-6: bad.append(("sai tỉ lệ", sw, sh, cw, ch, r)); continue
    touches = abs(w - cw) < eps or abs(h - ch) < eps
    if not touches: bad.append(("không chạm cạnh nào", sw, sh, cw, ch, r)); continue
    if abs((x0 + x1) / 2 - cw / 2) > eps or abs((y0 + y1) / 2 - ch / 2) > eps: bad.append(("lệch tâm", sw, sh, cw, ch, r))
check(not bad, "fitRect: 3000 ca ngẫu nhiên — trong khung, giữ tỉ lệ, chạm cạnh khung, căn giữa" + (f" — lỗi {bad[:2]}" if bad else ""))

# ---- paper ----
PAPERS = {"A4": (210, 297), "A5": (148, 210), "A3": (297, 420), "LETTER": (215.9, 279.4), "LEGAL": (215.9, 355.6)}
res = run([f"paper\t{w}\t{h}" for w, h in PAPERS.values()], "paper")
ok = True
for (name, (wmm, hmm)), r in zip(PAPERS.items(), res):
    exp = (round(wmm / 25.4 * 200), round(hmm / 25.4 * 200))
    if tuple(map(int, r)) != exp: ok = False; print("   lệch", name, r, exp)
check(ok, "kích thước giấy ở 200 DPI khớp bảng tính độc lập (mm -> inch -> px)")
check(tuple(map(int, res[0])) == (1654, 2339), f"A4 ở 200 DPI = 1654 x 2339 (được {res[0]})")
check(tuple(map(int, res[3])) == (1700, 2200), f"Letter ở 200 DPI = 1700 x 2200 (được {res[3]})")

# ---- thử âm tính: cắt không kẹp phần trăm ----
src = open(os.path.join(HERE, "PageToolsCheck.java"), encoding="utf-8").read()
naive = src.replace("static float pct(float v) { return Math.min(45f, Math.max(0f, v)); }", "static float pct(float v) { return v; }")
assert naive != src
tmp = os.path.join(OUT, "PageToolsCheck.java"); open(tmp, "w", encoding="utf-8").write(naive)
cin, cout = os.path.join(OUT, "pt_neg.in"), os.path.join(OUT, "pt_neg.out")
open(cin, "w").write("crop\t1000\t2000\t60\t60\t60\t60\n")
subprocess.run(["java", tmp, cin, cout], check=True)
naive_rect = tuple(map(int, open(cout).read().split()))
real_rect = tuple(map(int, run(["crop\t1000\t2000\t60\t60\t60\t60"], "neg2")[0]))
check(naive_rect[2] - naive_rect[0] <= 1 and real_rect == (450, 900, 550, 1100),
      f"thử âm tính: bản KHÔNG kẹp cắt 60% mỗi cạnh ra ảnh {naive_rect[2] - naive_rect[0]}x{naive_rect[3] - naive_rect[1]} px (vô nghĩa); bản thật kẹp về 45% = {real_rect}")
print("\nTAT CA DAT" if not FAILS else f"\nCO {len(FAILS)} LOI")
sys.exit(1 if FAILS else 0)
