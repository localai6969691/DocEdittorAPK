"""Kiểm chứng hướng khắc phục "điền biểu mẫu vào PDF đã ký số làm mất chữ ký" (phiên 15).

Hạn chế cũ: PdfFormFiller.fill ghi lại CẢ tệp (PdfStructureOptimizer.save) nên chữ ký số cũ không còn khớp. Tra cứu: PDFBox hỗ trợ cập nhật
TĂNG DẦN cho biểu mẫu (PDFBOX-2859): đánh dấu các đối tượng đã đổi bằng setNeedToBeUpdated(true) rồi saveIncremental - byte gốc không đổi, bản sửa nối vào cuối.
Script này kiểm CÁI Ý với hai trình độc lập, bằng PDF thật có chữ ký (dùng bộ dựng CMS Java đã kiểm chứng):
  A. PDF có ô văn bản + chữ ký số hợp lệ ban đầu (pdfsig: "Signature is Valid");
  B. nối thêm một bản cập nhật tăng dần chỉ đổi /V của ô và bật /NeedAppearances (đúng cái PdfFormFiller làm ở chế độ đã-ký)
     -> chữ ký VẪN toàn vẹn (pdfsig: "Signature is Valid") và pdfsig ghi nhận có bản sửa sau chữ ký ("Not total document signed");
        giá trị mới đọc ra được; ô hiện chữ trong poppler;
  C. đối chứng: ghi lại cả tệp bằng pikepdf (giống ghi đầy đủ) -> chữ ký KHÔNG còn hợp lệ.
Chạy: python3 signed_form_check.py   (cần cryptography, pikepdf, numpy, pillow, pdfsig, pdftoppm, java 11+)
"""
import os, re, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import numpy as np
from PIL import Image
import pikepdf
import digital_signature_check as D

FIELD_RECT = (20, 150, 180, 175)


def base_with_field():
    objs = {
        1: b"<< /Type /Catalog /Pages 2 0 R >>",
        2: b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        3: b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 200] /Contents 4 0 R /Resources << >> >>",
    }
    stream = b"0.9 0.9 0.9 rg 0 0 200 200 re f"
    objs[4] = b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream"
    out = bytearray(b"%PDF-1.7\n%\xe2\xe3\xcf\xd3\n"); offs = {}
    for n in sorted(objs):
        offs[n] = len(out); out += b"%d 0 obj\n" % n + objs[n] + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n0 5\n0000000000 65535 f \n" + b"".join(b"%010d 00000 n \n" % offs[n] for n in range(1, 5))
    out += b"trailer\n<< /Size 5 /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % xref
    return bytes(out), xref


FIELD_OBJ = (b"<< /Type /Annot /Subtype /Widget /FT /Tx /T (ho_ten) /Rect [%d %d %d %d] /V (%s) /DA (/Helv 12 Tf 0 g) /P 3 0 R /F 4 >>")


def update_with_sig_and_field(pdf, prev):
    out = bytearray(pdf); offs = {}

    def add(n, body):
        offs[n] = len(out); out.extend(b"%d 0 obj\n" % n + body + b"\nendobj\n")
    helv = b"/DR << /Font << /Helv << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> >> >>"
    add(1, b"<< /Type /Catalog /Pages 2 0 R /AcroForm << /Fields [6 0 R 7 0 R] /SigFlags 3 " + helv + b" >> >>")
    add(3, b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 200] /Contents 4 0 R /Resources << >> /Annots [6 0 R 7 0 R] >>")
    add(5, b"<< /Type /Sig /Filter /Adobe.PPKLite /SubFilter /adbe.pkcs7.detached /ByteRange [0 0000000000 0000000000 0000000000] /Contents <"
           + b"0" * (2 * D.CAPACITY) + b"> /M (D:20261003120000Z) /Name (Test) >>")
    add(6, b"<< /Type /Annot /Subtype /Widget /FT /Sig /Rect [0 0 0 0] /V 5 0 R /T (Signature1) /F 132 /P 3 0 R >>")
    add(7, FIELD_OBJ % (FIELD_RECT[0], FIELD_RECT[1], FIELD_RECT[2], FIELD_RECT[3], b""))
    xref = len(out)
    out += b"xref\n0 1\n0000000000 65535 f \n1 1\n%010d 00000 n \n3 1\n%010d 00000 n \n5 3\n%010d 00000 n \n%010d 00000 n \n%010d 00000 n \n" % (
        offs[1], offs[3], offs[5], offs[6], offs[7])
    out += b"trailer\n<< /Size 8 /Root 1 0 R /Prev %d >>\nstartxref\n%d\n%%%%EOF\n" % (prev, xref)
    return bytes(out)


def last_startxref(data):
    return int(re.findall(rb"startxref\s+(\d+)\s+%%EOF", data)[-1])


def append_fill_revision(signed, value):
    """Cập nhật tăng dần: viết lại đối tượng 7 (ô) với /V mới và đối tượng 1 (catalog) với /NeedAppearances true; xref mới có /Prev."""
    out = bytearray(signed); offs = {}

    def add(n, body):
        offs[n] = len(out); out.extend(b"\n%d 0 obj\n" % n + body + b"\nendobj\n")
    helv = b"/DR << /Font << /Helv << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> >> >>"
    add(1, b"<< /Type /Catalog /Pages 2 0 R /AcroForm << /Fields [6 0 R 7 0 R] /SigFlags 3 /NeedAppearances true " + helv + b" >> >>")
    add(7, FIELD_OBJ % (FIELD_RECT[0], FIELD_RECT[1], FIELD_RECT[2], FIELD_RECT[3], value))
    prev = last_startxref(signed)
    xref = len(out) + 1
    out += b"\nxref\n0 1\n0000000000 65535 f \n1 1\n%010d 00000 n \n7 1\n%010d 00000 n \n" % (offs[1] + 1, offs[7] + 1)
    out += b"trailer\n<< /Size 8 /Root 1 0 R /Prev %d >>\nstartxref\n%d\n%%%%EOF\n" % (prev, xref)
    return bytes(out)


def ink(path, rect):
    base = path[:-4]
    subprocess.run(["pdftoppm", "-r", "72", "-png", "-singlefile", path, base], check=True, capture_output=True)
    img = np.array(Image.open(base + ".png").convert("L")).astype(int)
    h = img.shape[0]; x0, y0, x1, y1 = rect
    return int((img[h - y1:h - y0, x0:x1] < 100).sum())


def main():
    good = True
    with tempfile.TemporaryDirectory(dir=OUT) as wd:
        prefix = os.path.join(wd, "k"); D.make_cert_v3(prefix)
        base, prev = base_with_field()
        unsigned = update_with_sig_and_field(base, prev)
        signed, content, cms_path, size = D.sign_pdf(unsigned, wd, prefix)
        sp = os.path.join(wd, "signed.pdf"); open(sp, "wb").write(signed)
        out0 = D.pdfsig(sp)
        good &= D.check("Signature is Valid" in out0, "A: PDF có ô văn bản + chữ ký số: pdfsig báo HỢP LỆ")
        good &= D.check(ink(sp, FIELD_RECT) == 0, "A: ô văn bản đang trống")

        filled = append_fill_revision(signed, b"Nguyen Van A")
        fp = os.path.join(wd, "filled_incremental.pdf"); open(fp, "wb").write(filled)
        out1 = D.pdfsig(fp)
        good &= D.check("Signature is Valid" in out1, "B: sau khi NỐI bản cập nhật điền ô: chữ ký VẪN toàn vẹn (pdfsig: Signature is Valid)")
        if "Signature is Valid" not in out1:
            print(out1)
        good &= D.check("Not total document signed" in out1 or "Total document signed" not in out1,
                        "B: pdfsig ghi nhận có thay đổi SAU chữ ký (không còn 'Total document signed') - trung thực: chữ ký bảo vệ bản gốc, không bảo vệ bản đã điền")
        with pikepdf.open(fp) as pdf:
            val = [str(f.get("/V", "")) for f in pdf.Root.AcroForm.Fields if str(f.get("/T")) == "ho_ten"]
            good &= D.check(val == ["Nguyen Van A"] and bool(pdf.Root.AcroForm.NeedAppearances), f"B: giá trị mới đọc ra được {val} và cờ NeedAppearances bật")
        good &= D.check(ink(fp, FIELD_RECT) > 30, f"B: poppler vẽ chữ trong ô (mực={ink(fp, FIELD_RECT)})")
        good &= D.check(filled[:len(signed)] == signed, "B: toàn bộ byte của tệp đã ký vẫn nằm NGUYÊN ở đầu tệp mới (chỉ nối thêm phía sau)")

        rp = os.path.join(wd, "filled_rewrite.pdf")
        with pikepdf.open(fp) as pdf:
            pdf.save(rp)
        out2 = D.pdfsig(rp)
        good &= D.check("Signature is Valid" not in out2, "C: đối chứng — GHI LẠI CẢ TỆP (như PdfStructureOptimizer.save) làm chữ ký KHÔNG còn hợp lệ")
    print("TAT CA DAT" if good else "CO LOI")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
