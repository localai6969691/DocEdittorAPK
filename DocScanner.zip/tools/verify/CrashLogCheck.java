// Bản Java chạy được của CrashLog.describe (phiên 16): cùng logic. Dùng bởi crash_log_check.py: java CrashLogCheck.java
// In ra, mỗi ca một khối: "=== <tên ca>" rồi nội dung describe().
import java.io.FileNotFoundException;
import java.util.*;

public class CrashLogCheck {
    static final String HIDDEN_MESSAGE = "(message hidden: it may contain a file path)";

    static String describe(Throwable error, int maxFrames) {
        StringBuilder sb = new StringBuilder();
        Throwable current = error;
        int depth = 0;
        while (current != null && depth < 6) {
            sb.append(depth == 0 ? "" : "Caused by: ").append(current.getClass().getName());
            String message = current.getMessage();
            if (message != null && !message.isBlank()) {
                sb.append(": ").append((message.indexOf('/') >= 0 || message.indexOf('\\') >= 0) ? HIDDEN_MESSAGE : message.substring(0, Math.min(300, message.length())));
            }
            sb.append('\n');
            StackTraceElement[] st = current.getStackTrace();
            for (int i = 0; i < Math.min(maxFrames, st.length); i++) sb.append("    at ").append(st[i].toString()).append('\n');
            current = current.getCause() == current ? null : current.getCause();
            depth++;
        }
        return sb.toString();
    }

    static Throwable deep(int n) {
        Throwable t = new IllegalStateException("level 0");
        for (int i = 1; i < n; i++) t = new RuntimeException("level " + i, t);
        return t;
    }

    static Throwable recurse(int n) {
        if (n == 0) return new StackOverflowError("deep stack");
        return recurse(n - 1);
    }

    public static void main(String[] a) {
        Map<String, Throwable> cases = new LinkedHashMap<>();
        cases.put("plain", new IndexOutOfBoundsException("Index 5 out of bounds for length 3"));
        cases.put("unix-path", new FileNotFoundException("/storage/emulated/0/Documents/Hợp đồng CCCD 0123456789.pdf: open failed: ENOENT"));
        cases.put("windows-path", new RuntimeException("C:\\Users\\An\\Hồ sơ bệnh án.pdf không đọc được"));
        cases.put("null-message", new NullPointerException());
        cases.put("blank-message", new RuntimeException("   "));
        cases.put("long-message", new RuntimeException("x".repeat(1000)));
        cases.put("cause-with-path", new RuntimeException("wrapper ok", new FileNotFoundException("/data/user/0/app/files/Sổ hộ khẩu.jpg")));
        cases.put("deep-chain", deep(10));
        cases.put("many-frames", recurse(200));
        for (Map.Entry<String, Throwable> e : cases.entrySet()) {
            System.out.println("=== " + e.getKey());
            System.out.print(describe(e.getValue(), 25));
        }
    }
}
