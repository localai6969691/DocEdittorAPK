"""Kiểm chứng trích trường hoá đơn VN và danh thiếp -> liên hệ (phiên 16, mục 4.30): InvoiceFields, ContactCard (+ vCard 3.0).

ExtractCheck.java là bản Java chạy được, viết lại từng dòng từ Kotlin. Đáp án KHÔNG lấy từ chính mã đó:
- Số tiền: sinh từ GIÁ TRỊ đã biết rồi in theo 3 kiểu (1.234.567,5 / 1,234,567.5 / 1234567.5); đáp án = chính giá trị.
- Hoá đơn: DỰNG từ các giá trị đã biết (ngày 3 kiểu, số hoá đơn, ký hiệu có/không "(Serial)", 1-2 MST, tổng tiền, thuế suất, tiền thuế) với nhãn viết hoa / thường / không dấu,
  xen các dòng nhiễu (hàng hoá, điện thoại, số tài khoản, ngày thanh toán SAU ngày hoá đơn): trích đúng và chỉ đúng các trường đó. Giả định ghi rõ: ngày hoá đơn là ngày hợp lệ ĐẦU TIÊN.
- Danh thiếp: DỰNG từ họ tên, chức danh, công ty, 1-2 số điện thoại (+ một số fax mồi nhử, cả khi fax chung dòng), email, website, địa chỉ 1-2 dòng, thứ tự dòng xáo trộn.
- vCard: đọc lại bằng bộ đọc RFC 2426 viết ĐỘC LẬP ở đây (gỡ gấp dòng, tách tham số, bỏ escape, tách ADR theo dấu ; không escape); mọi dòng <= 75 byte, kết thúc CRLF,
  không cắt đôi ký tự UTF-8; giá trị chứa ; , \\ xuống dòng đi qua nguyên vẹn.
- 6 ĐỘT BIẾN cố ý làm hỏng bản Java, mỗi cái phải làm bài kiểm tương ứng đỏ.
Chạy: python3 extract_check.py   (cần java 11+)
"""
import os, random, re, subprocess, sys, unicodedata
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
HERE = os.path.dirname(os.path.abspath(__file__))
JAVA = os.path.join(HERE, "ExtractCheck.java")
FAILS = []
def check(cond, what, quiet=False):
    if not quiet: print(("ok  " if cond else "LOI"), what)
    if not cond and not quiet: FAILS.append(what)
    return cond
def enc(s):
    out = []
    for ch in s:
        o = ord(ch)
        if ch == "\\": out.append("\\\\")
        elif ch == "\n": out.append("\\n")
        elif 0x20 <= o < 0x7F: out.append(ch)
        else:
            b = ch.encode("utf-16-be", "surrogatepass")
            for i in range(0, len(b), 2): out.append("\\u%02x%02x" % (b[i], b[i + 1]))
    return "".join(out)
def dec(s):
    out, i = [], 0
    while i < len(s):
        if s[i] == "\\" and i + 1 < len(s):
            if s[i + 1] == "\\": out.append("\\"); i += 2
            elif s[i + 1] == "n": out.append("\n"); i += 2
            elif s[i + 1] == "u": out.append(chr(int(s[i + 2:i + 6], 16))); i += 6
            else: out.append(s[i]); i += 1
        else: out.append(s[i]); i += 1
    s2 = "".join(out)
    return s2.encode("utf-16", "surrogatepass").decode("utf-16")
def run(java_path, mode, lines, tag):
    cin, cout = os.path.join(OUT, f"xt_{tag}.in"), os.path.join(OUT, f"xt_{tag}.out")
    with open(cin, "w", encoding="utf-8") as f: f.write("\n".join(lines) + "\n")
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", java_path, mode, cin, cout], capture_output=True, text=True)
    if r.returncode != 0: sys.exit("Java lỗi:\n" + r.stdout + r.stderr)
    return cout
def strip_accents(s): return "".join("d" if c == "đ" else "D" if c == "Đ" else unicodedata.normalize("NFD", c)[0] for c in s)
def variant(rng, label): return rng.choice([label, label.upper(), label.lower(), strip_accents(label), strip_accents(label).upper()])

# ===================================================================== số tiền
def fmt_amount(rng):
    v = rng.choice([rng.randint(0, 999), rng.randint(1000, 999999), rng.randint(10 ** 6, 10 ** 12)])
    dec = rng.choice(["", "", "", "5", "25", "50", "07", "00"])
    style = rng.choice(["vn", "en", "plain"])
    if style == "plain": thousands, point = "", rng.choice([".", ","])
    elif style == "vn": thousands, point = ".", ","
    else: thousands, point = ",", "."
    ip = f"{v:,}".replace(",", thousands) if thousands else str(v)
    token = ip + (point + dec if dec else "")
    if style == "plain" and dec and v >= 1000 and False: pass
    frac = dec.rstrip("0")
    return token, (str(v) + ("." + frac if frac else ""))
def amount_suite(java_path, quiet=False):
    rng = random.Random(1640)
    cases = [fmt_amount(rng) for _ in range(3000)]
    bad_tokens = ["1.2.3.4", "abc", "", "1,2,3", "12.3456", "--5", "1 234", "٣٤"]
    cout = run(java_path, "amount", [enc(t) for t, _ in cases] + [enc(t) for t in bad_tokens], "amt")
    got = open(cout, encoding="utf-8").read().split("\n")
    bad = [(t, e, g) for (t, e), g in zip(cases, got) if g != e]
    ok = check(not bad, "số tiền: 3000 giá trị in theo kiểu VN / EN / liền, có hoặc không phần thập phân: ra đúng giá trị" + (f" — sai {len(bad)}, vd {bad[:3]}" if bad else ""), quiet)
    nulls = got[len(cases):len(cases) + len(bad_tokens)]
    ok &= check(all(g == "null" for g in nulls), f"số tiền: chuỗi không phải số tiền -> null ({nulls})", quiet)
    return ok

# ===================================================================== hoá đơn
def money_text(rng, v):
    style = rng.choice(["vn", "en", "plain"])
    t = f"{v:,}".replace(",", "." if style == "vn" else ",") if style != "plain" else str(v)
    return t + rng.choice(["", " đ", " VNĐ", " đồng", " ₫"])
def build_invoice(rng):
    lines, exp = [], []
    lines.append(rng.choice(["CÔNG TY TNHH THƯƠNG MẠI ABC", "Công ty Cổ phần XYZ", "HÓA ĐƠN GIÁ TRỊ GIA TĂNG", "(VAT INVOICE)"]))
    lines.append("HÓA ĐƠN GIÁ TRỊ GIA TĂNG")
    y, m = rng.randint(2019, 2026), rng.randint(1, 12)
    d = rng.randint(1, 28 if m == 2 else 30)
    kind = rng.choice(["words", "slash", "iso"])
    if kind == "words": lines.append(variant(rng, "Ngày") + f" {d:02d} " + variant(rng, "tháng") + f" {m:02d} " + variant(rng, "năm") + f" {y}")
    elif kind == "slash": lines.append(variant(rng, "Ngày (Date)") + f": {d:02d}/{m:02d}/{y}")
    else: lines.append(f"Date: {y}-{m:02d}-{d:02d}")
    exp.append(f"DATE={y:04d}-{m:02d}-{d:02d}")
    serial = rng.choice([f"{rng.randint(1, 9)}{rng.choice('CKTM')}{rng.randint(20, 26)}{''.join(rng.choice('TAB') for _ in range(rng.randint(2, 3)))}", f"{rng.choice('ABCD')}{rng.choice('ABCD')}/{rng.randint(15, 22)}E"])
    has_serial = rng.random() < 0.8
    if has_serial:
        lines.append(variant(rng, rng.choice(["Ký hiệu", "Ký hiệu (Serial)", "Ký hiệu (Series)", "Ký hiệu hóa đơn", "Ký hiệu hóa đơn (Series)", "Serial"])) + rng.choice([": ", " : ", ":", " "]) + serial)
    num = "".join(rng.choice("0123456789") for _ in range(rng.randint(1, 8)))
    has_no = rng.random() < 0.85
    if has_no:
        lines.append(variant(rng, rng.choice(["Số hóa đơn", "Số hóa đơn (Invoice No.)", "Số HĐ", "Invoice No.", "Số (No.)"])) + rng.choice([": ", " : ", ":", " "]) + num)
    taxes = [rng.choice(["%010d" % rng.randint(0, 10 ** 10 - 1), "%010d-%03d" % (rng.randint(0, 10 ** 10 - 1), rng.randint(0, 999)), "%013d" % rng.randint(0, 10 ** 13 - 1)]) for _ in range(rng.randint(0, 2))]
    for t in taxes:
        lines.append(rng.choice(["Đơn vị bán hàng: Công ty ABC", "Địa chỉ: Số 12 Nguyễn Huệ, Quận 1", "Điện thoại: 0912 345 678"]))
        lines.append(variant(rng, rng.choice(["Mã số thuế", "MST", "Tax code", "Mã số thuế (Tax code)"])) + rng.choice([": ", " : ", ":", " "]) + t)
    for _ in range(rng.randint(0, 3)):
        lines.append(f"{rng.randint(1, 9)} | Dịch vụ {rng.randint(1, 99)} | {rng.randint(1, 20)} | {money_text(rng, rng.randint(10 ** 4, 10 ** 8))} | {money_text(rng, rng.randint(10 ** 4, 10 ** 9))}")
    lines.append("Số tài khoản: " + "".join(rng.choice("0123456789") for _ in range(rng.randint(9, 14))))
    lines.append("Hình thức thanh toán: TM/CK")
    # khối tiền: tiền hàng, thuế, tổng
    subtotal = rng.randint(10 ** 5, 10 ** 9)
    rate = rng.choice([5, 8, 10])
    vat = subtotal * rate // 100
    total = subtotal + vat
    lines.append(variant(rng, "Cộng tiền hàng") + ": " + money_text(rng, subtotal))
    layout = rng.choice(["A", "B", "C"])
    rate_text = None
    if layout == "A":
        lines.append(variant(rng, "Thuế suất GTGT") + f": {rate}%"); lines.append(variant(rng, "Tiền thuế GTGT") + ": " + money_text(rng, vat))
        rate_exp, vat_exp = str(rate), str(vat)
    elif layout == "B":
        lines.append(variant(rng, "Thuế GTGT") + f" ({rate}%): " + money_text(rng, vat)); rate_exp, vat_exp = str(rate), str(vat)
    else:
        lines.append(variant(rng, "Thuế suất") + f": {rate}%"); rate_exp, vat_exp = str(rate), None
    # tổng thanh toán
    label = variant(rng, rng.choice(["Tổng cộng tiền thanh toán", "Tổng tiền thanh toán", "Tổng cộng thanh toán", "Total amount", "Grand total", "Tổng cộng tiền thanh toán (Total amount)"]))
    if rng.random() < 0.35: label = label + f" (đã gồm VAT {rate}%)"          # sau nhãn có SỐ khác (thuế suất) trước số tiền: phải lấy số CUỐI
    r3 = rng.random()
    if r3 < 0.2: lines.append(label + ":"); lines.append(money_text(rng, total))
    elif r3 < 0.4: lines.append(label + ": " + money_text(rng, subtotal) + " | " + money_text(rng, vat) + " | " + money_text(rng, total))   # hàng tổng của bảng thuế: tiền hàng | thuế | tổng -> lấy số CUỐI
    else: lines.append(label + rng.choice([": ", " : ", ":"]) + money_text(rng, total))
    lines.append("Số tiền bằng chữ: ...")
    lines.append(rng.choice(["Ngày thanh toán: 31/12/2026", "Hạn thanh toán: 15/01/2027", "Người mua hàng ký tên"]))   # sau ngày hoá đơn
    # kết quả mong đợi theo THỨ TỰ trích: DATE, INVOICE_NO, SERIAL, TAX_ID..., TOTAL, VAT_RATE, VAT_AMOUNT
    out = [exp[0]]
    if has_no: out.append(f"INVOICE_NO={num}")
    if has_serial: out.append(f"SERIAL={serial}")
    for t in taxes: out.append(f"TAX_ID={t}")
    out.append(f"TOTAL={total}"); out.append(f"VAT_RATE={rate_exp}")
    if vat_exp is not None and vat >= 1000: out.append(f"VAT_AMOUNT={vat_exp}")
    return "\n".join(lines), ";".join(out)
def invoice_suite(java_path, quiet=False):
    rng = random.Random(1641)
    cases = [build_invoice(rng) for _ in range(1500)]
    cout = run(java_path, "invoice", [enc(t) for t, _ in cases], "inv")
    got = [dec(l) for l in open(cout, encoding="utf-8").read().split("\n")[:len(cases)]]
    bad = [(i, e, g) for i, ((t, e), g) in enumerate(zip(cases, got)) if g != e]
    ok = check(not bad, "hoá đơn: 1500 hoá đơn dựng từ giá trị đã biết (nhãn hoa/thường/không dấu, ngày 3 kiểu, số liền/trên dòng kế, dòng nhiễu): trích đúng và chỉ đúng" + (f" — sai {len(bad)}, vd #{bad[0][0]}: mong đợi {bad[0][1]} | được {bad[0][2]}\n{cases[bad[0][0]][0]}" if bad else ""), quiet)
    hand = [
        ("Ngày 05 tháng 10 năm 2026\nKý hiệu (Serial): 1C25TAA\nSố hóa đơn (Invoice No.): 0000123\nMã số thuế: 0101234567\nTổng cộng tiền thanh toán: 12.345.678", "DATE=2026-10-05;INVOICE_NO=0000123;SERIAL=1C25TAA;TAX_ID=0101234567;TOTAL=12345678"),
        ("Ngày 31 tháng 02 năm 2026\nNgày 01/03/2026", "DATE=2026-03-01"),
        ("Điện thoại: 0912 345 678\nSố tài khoản: 0123456789\nTổng cộng: 1.000", "TOTAL=1000"),
        ("", ""),
    ]
    cout = run(java_path, "invoice", [enc(t) for t, _ in hand], "invh")
    gh = [dec(l) for l in open(cout, encoding="utf-8").read().split("\n")[:len(hand)]]
    bad = [(t[:30], e, g) for (t, e), g in zip(hand, gh) if g != e]
    ok &= check(not bad, "hoá đơn: 4 ca viết tay (ngày 31/02 không hợp lệ bị bỏ qua, số điện thoại / STK không bị coi là MST) " + (f" — sai {bad}" if bad else ""), quiet)
    return ok

# ===================================================================== danh thiếp
FAM = ["Nguyễn", "Trần", "Lê", "Phạm", "Hoàng", "Vũ", "Đặng", "Bùi", "Đỗ"]
MID = ["Văn", "Thị", "Minh", "Quang", "Hồng", "Đức", "Thanh", "Quân"]
GIVEN = ["An", "Bình", "Cường", "Dũng", "Hà", "Hải", "Lan", "Mai", "Nam", "Phúc", "Quân", "Trang", "Việt", "Tú Vân"]
TITLES = ["Giám đốc kinh doanh", "Trưởng phòng Marketing", "Sales Manager", "Kỹ sư phần mềm", "Chuyên viên tư vấn", "CEO", "Technical Director", "Phó giám đốc"]
STREETS = ["Nguyễn Huệ", "Láng Hạ", "Điện Biên Phủ", "Lê Lợi"]
CITIES = ["TP. Hồ Chí Minh", "Hà Nội", "Đà Nẵng"]
def phone_text(rng):
    kind = rng.choice(["m1", "m2", "m3", "land"])
    d = "".join(rng.choice("0123456789") for _ in range(8))
    first = rng.choice("35789")
    if kind == "m1": return f"0{first}{d[:2]} {d[2:5]} {d[5:]}"
    if kind == "m2": return f"0{first}{d[:2]}.{d[2:5]}.{d[5:]}"
    if kind == "m3": return f"+84 {first}{d[:2]} {d[2:5]} {d[5:]}"
    return f"028 {d[:4]} {d[4:]}"
def build_card(rng):
    name = rng.choice(FAM) + " " + rng.choice(["", rng.choice(MID) + " ", ""]) + rng.choice(GIVEN)
    name = name.replace("  ", " ")
    if rng.random() < 0.3: name = name.upper()
    title = rng.choice(TITLES) if rng.random() < 0.9 else ""
    company = rng.choice(["Công ty TNHH Thương mại ABC", "Công ty Cổ phần Phần mềm XYZ", "ABC JSC", "XYZ Group", "Tập đoàn Hoàng Gia"])
    phones = [phone_text(rng) for _ in range(rng.randint(1, 2))]
    while len(set(phones)) < len(phones): phones = [phone_text(rng) for _ in range(len(phones))]
    emails = ["".join(rng.choice("abcdefghij") for _ in range(rng.randint(3, 8))) + rng.choice(["", ".", "_"]) + "".join(rng.choice("klmnop") for _ in range(2)) + "@" + rng.choice(["abc.com.vn", "xyz.vn", "mail.example.com"]) for _ in range(rng.randint(1, 2))]
    web = rng.choice(["www.abc.com.vn", "https://xyz.vn/lien-he", "www.AbcCorp.vn", "xyz.com"])
    addr = [f"Số {rng.randint(1, 300)} {rng.choice(STREETS)}, {rng.choice(['Quận', 'Phường'])} {rng.randint(1, 12)}, {rng.choice(CITIES)}"]
    if rng.random() < 0.4: addr.append(f"Tầng {rng.randint(2, 20)}, Tòa nhà {rng.choice(['A', 'B', 'Sunrise'])}, Đường {rng.choice(STREETS)}")
    lines = []
    for p in phones: lines.append(rng.choice(["Tel: ", "Mobile: ", "ĐT: ", "Hotline: ", ""]) + p)
    if rng.random() < 0.5: lines.append("Fax: " + phone_text(rng))
    elif rng.random() < 0.4: lines[0] = lines[0] + " | Fax: " + phone_text(rng)
    for e in emails: lines.append(rng.choice(["Email: ", "E-mail: ", ""]) + e)
    lines.append(rng.choice(["Website: ", "Web: ", ""]) + web)
    addr_lines = []
    for k, a in enumerate(addr): addr_lines.append((rng.choice(["Địa chỉ: ", "Add: ", ""]) if k == 0 else "") + a)
    expected_address = ", ".join(addr)
    blocks = [[name], [company], lines, addr_lines] + ([[title]] if title else [])
    order = list(range(len(blocks))); rng.shuffle(order)
    text_lines = [l for i in order for l in blocks[i]]
    return "\n".join(text_lines), dict(name=name, title=title, company=company, phones=phones, emails=emails, websites=[web], address=expected_address)
def parse_card_line(line):
    f = {}
    for part in line.split("|"):
        k, _, v = part.partition("=")
        f[k] = dec(v)
    return {"name": f["name"], "title": f["title"], "company": f["company"], "phones": [x for x in f["phones"].split("\u0001") if x],
            "emails": [x for x in f["emails"].split("\u0001") if x], "websites": [x for x in f["websites"].split("\u0001") if x], "address": f["address"]}
def card_suite(java_path, quiet=False):
    rng = random.Random(1642)
    cases = [build_card(rng) for _ in range(1200)]
    cout = run(java_path, "card", [enc(t) for t, _ in cases], "card")
    got = [parse_card_line(l) for l in open(cout, encoding="utf-8").read().split("\n")[:len(cases)]]
    bad = []
    for i, ((t, e), g) in enumerate(zip(cases, got)):
        diffs = [k for k in e if (set(g[k]) != set(e[k]) if isinstance(e[k], list) else g[k] != e[k])]
        if diffs: bad.append((i, diffs, {k: (e[k], g[k]) for k in diffs}))
    return check(not bad, "danh thiếp: 1200 danh thiếp dựng từ giá trị đã biết (thứ tự dòng xáo trộn; fax mồi nhử, cả fax chung dòng; tên có 'Quân', 'Tú Vân'; website có chữ HOA): trích đúng tên, chức danh, công ty, điện thoại, email, website, địa chỉ" +
                 (f" — sai {len(bad)}, vd #{bad[0][0]}: {bad[0][2]}\n{cases[bad[0][0]][0]}" if bad else ""), quiet)

# ===================================================================== vCard (bộ đọc RFC 2426 độc lập)
def read_vcard(raw):
    assert raw.endswith(b"\r\n"), "không kết thúc bằng CRLF"
    physical = raw.split(b"\r\n")[:-1]
    for pl in physical:
        if len(pl) > 75: raise AssertionError(f"dòng dài {len(pl)} byte > 75")
        pl.decode("utf-8")    # nghiêm ngặt: một ký tự bị cắt đôi sẽ lỗi ở đây
    text = raw.decode("utf-8").replace("\r\n ", "").replace("\r\n\t", "")
    cards, cur = [], None
    for line in text.split("\r\n"):
        if not line: continue
        name_params, _, value = line.partition(":")
        name = name_params.split(";")[0].upper(); params = name_params.split(";")[1:]
        if name == "BEGIN": cur = {"props": []}; continue
        if name == "END": cards.append(cur); cur = None; continue
        cur["props"].append((name, params, value))
    return cards
def split_unescaped(value, sep=";"):
    parts, cur, i = [], [], 0
    while i < len(value):
        if value[i] == "\\" and i + 1 < len(value): cur.append(value[i:i + 2]); i += 2
        elif value[i] == sep: parts.append("".join(cur)); cur = []; i += 1
        else: cur.append(value[i]); i += 1
    parts.append("".join(cur)); return parts
def unescape(v):
    out, i = [], 0
    while i < len(v):
        if v[i] == "\\" and i + 1 < len(v): out.append("\n" if v[i + 1] in "nN" else v[i + 1]); i += 2
        else: out.append(v[i]); i += 1
    return "".join(out)
def vcard_suite(java_path, quiet=False):
    rng = random.Random(1643)
    ok = True
    long_addr = "Tầng 12, Tòa nhà Đại Phát, " + "Đường Nguyễn Văn Cừ nối dài, " * 8 + "Quận Long Biên"
    contacts = [
        dict(name="Nguyễn Văn An", title="Giám đốc", company="Công ty TNHH ABC", phones=["0912 345 678"], emails=["an@abc.vn"], websites=["www.abc.vn"], address="Số 12 Nguyễn Huệ, Quận 1, TP. HCM"),
        dict(name="O'Neil; Jr, \\ Test", title="Dev; lead, QA", company="A\\B; C, D", phones=["+84 912 345 678", "028 3822 1234"], emails=["a@b.vn", "c@d.vn"], websites=["https://x.vn/a;b,c"], address="Dòng 1; có ; dấu, phẩy\nDòng 2"),
        dict(name="", title="", company="Công ty Chỉ Có Tên", phones=[], emails=[], websites=[], address=""),
        dict(name="", title="", company="", phones=["0912 345 678"], emails=[], websites=[], address=""),
        dict(name="Trần Thị Bích Ngọc", title="", company="", phones=[], emails=["ngoc@x.vn"], websites=[], address=long_addr),
        dict(name="Lê " + "Nguyễn " * 30 + "Văn", title="Đ" * 100, company="Ư" * 120, phones=[], emails=[], websites=[], address="ắ" * 90),
    ]
    for _ in range(300):
        txt, c = build_card(rng); contacts.append(c)
    lines = ["\t".join([enc(c["name"]), enc(c["title"]), enc(c["company"]), "|".join(enc(x) for x in c["phones"]), "|".join(enc(x) for x in c["emails"]), "|".join(enc(x) for x in c["websites"]), enc(c["address"])]) for c in contacts]
    cout = run(java_path, "vcard", lines, "vc")
    raw = open(cout, "rb").read()
    try:
        cards = read_vcard(raw)
    except AssertionError as e:
        return check(False, f"vCard: không hợp lệ theo RFC 2426 — {e}", quiet)
    ok &= check(len(cards) == len(contacts), f"vCard: {len(cards)} thẻ đọc lại được bằng bộ đọc độc lập (mọi dòng <= 75 byte, CRLF, không cắt đôi ký tự UTF-8)", quiet)
    bad = []
    for i, (c, card) in enumerate(zip(contacts, cards)):
        props = card["props"]
        get = lambda n: [(p, v) for nm, p, v in props if nm == n]
        names = [x for x in c["name"].split(" ") if x]
        fam, giv = (names[0] if names else ""), (" ".join(names[1:]) if len(names) > 1 else "")
        n = split_unescaped(get("N")[0][1]) if get("N") else None
        fn_exp = c["name"] or c["company"] or (c["emails"][0] if c["emails"] else (c["phones"][0] if c["phones"] else ""))
        checks = [
            props[0][0] == "VERSION" and props[0][2] == "3.0",
            n is not None and len(n) == 5 and unescape(n[0]) == fam and unescape(n[1]) == giv,
            [unescape(v) for _, v in get("FN")] == [fn_exp],
            [unescape(v) for _, v in get("ORG")] == ([c["company"]] if c["company"] else []),
            [unescape(v) for _, v in get("TITLE")] == ([c["title"]] if c["title"] else []),
            [unescape(v) for _, v in get("TEL")] == c["phones"],
            [unescape(v) for _, v in get("EMAIL")] == c["emails"],
            [unescape(v) for _, v in get("URL")] == c["websites"],
        ]
        adr = get("ADR")
        if c["address"]:
            parts = split_unescaped(adr[0][1]) if adr else []
            checks.append(len(parts) == 7 and unescape(parts[2]) == c["address"] and parts[0] == "" and parts[1] == "")
        else:
            checks.append(not adr)
        if not all(checks): bad.append((i, checks, c["name"][:20]))
    ok &= check(not bad, "vCard: mọi trường đọc lại bằng bộ đọc độc lập đúng (họ/tên, FN, ORG, TITLE, TEL, EMAIL, URL, ADR; ; , \\ và xuống dòng nguyên vẹn; giá trị dài bị gấp dòng giữa ký tự tiếng Việt)" + (f" — sai {len(bad)}: {bad[:2]}" if bad else ""), quiet)
    return ok

# ===================================================================== đột biến
SRC = open(JAVA, encoding="utf-8").read()
def mutated(old, new):
    assert SRC.count(old) == 1, ("đột biến không tìm thấy đúng 1 chỗ", old[:70], SRC.count(old))
    path = os.path.join(OUT, "ExtractCheckMut.java")
    open(path, "w", encoding="utf-8").write(SRC.replace(old, new, 1).replace("public class ExtractCheck", "public class ExtractCheckMut"))
    return path
def main():
    for title, suite in (("số tiền", amount_suite), ("hoá đơn", invoice_suite), ("danh thiếp", card_suite), ("vCard", vcard_suite)):
        print("==", title, "=="); suite(JAVA)
    print("== đột biến (mỗi cái phải làm bài kiểm tương ứng đỏ) ==")
    muts = [
        ("số có đúng 3 chữ số sau MỘT dấu phân cách coi là thập phân ('1.234' thành 1.234)", ("if (after.length() == 3 && before.length() <= 3) intPart = before + after; else { intPart = before; frac = after; }", "intPart = before; frac = after;"), amount_suite),
        ("tổng tiền lấy số ĐẦU tiên trên dòng thay vì số CUỐI", ("for (int k = numbers.size() - 1; k >= 0; k--) { String normal = normalizeAmount(numbers.get(k));", "for (int k = 0; k < numbers.size(); k++) { String normal = normalizeAmount(numbers.get(k));"), invoice_suite),
        ("bỏ nhánh '(Serial)' giữa 'Ký hiệu' và giá trị", ("(?:\\\\s*\\\\([^)\\\\n]{0,20}\\\\))?[^a-z0-9\\\\n]{0,25}([0-9][a-z]", "[^a-z0-9\\\\n]{0,25}([0-9][a-z]"), invoice_suite),
        ("số sau chữ 'Fax' vẫn bị coi là điện thoại", ("&& !FAX.matcher(folded.substring(Math.max(0, m.start() - 8), m.start())).find())", ")"), card_suite),
        ("dòng chứa 'quan ' (tên 'Lê Quân Việt') bị coi là địa chỉ dù không có số / dấu phẩy", ("(containsAny(folded, ADDRESS) && (hasDigit(line) || line.contains(\",\")))", "containsAny(folded, ADDRESS)"), card_suite),
        ("vCard không escape dấu phẩy / chấm phẩy", ('static String escapeV(String v) { return v.replace("\\\\", "\\\\\\\\").replace(";", "\\\\;").replace(",", "\\\\,")', 'static String escapeV(String v) { return v.replace("\\\\", "\\\\\\\\")'), vcard_suite),
        ("gấp dòng đếm KÝ TỰ thay vì BYTE (dòng vượt 75 byte với chữ tiếng Việt)", ("int size = new String(Character.toChars(cp)).getBytes(StandardCharsets.UTF_8).length;", "int size = 1;"), vcard_suite),
    ]
    for label, (old, new), suite in muts:
        path = mutated(old, new)
        try:
            caught = not suite(path, quiet=True)
        except AssertionError:
            caught = True
        check(caught, f"đột biến bị bắt: {label}")
    print("\nTAT CA DAT" if not FAILS else f"\nCO {len(FAILS)} LOI")
    sys.exit(1 if FAILS else 0)
if __name__ == "__main__":
    main()
