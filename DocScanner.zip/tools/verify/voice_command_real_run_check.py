#!/usr/bin/env python3
"""Lệnh giọng nói cho cả màn chính CHẠY THẬT (`util/VoiceCommand.kt`; phiên 27, TECHNICAL_DOCS.md 4.87; mục I2 của PDF).

Hệ thống nhận giọng nói trả về một câu ("mở nén pdf", "open compress PDF", "abrir comprimir pdf"); `toQuery` bỏ từ lệnh ở đầu / lời lịch sự ở cuối, `pick` chọn ĐÚNG MỘT công cụ hoặc từ chối
(null) khi không rõ: điểm khớp tên phải >= 60 và hơn hẳn công cụ thứ hai, còn không thì app chỉ điền chữ vào ô tìm để người dùng tự chọn (không tự bấm nhầm).
Mong đợi viết TAY từ đặc tả, không cài lại logic. Phần xếp hạng dùng lại `CommandPalette` (đã kiểm ở command_palette_real_run_check.py).
KHÔNG kiểm được: bộ nhận giọng của hệ thống, hộp thoại, độ chính xác nhận giọng thật ở 12 ngôn ngữ (người bản ngữ thử); mới có từ lệnh cho en / vi / fr / de / es / pt / id / ru (ja, ko, zh, hi: chỉ khớp tên công cụ).
Chạy: python3 tools/verify/voice_command_real_run_check.py"""
import os, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="voice-")
HARNESS = os.path.join(HERE, "real_run", "VoiceCommandHarness.kt")
FILES = ["VoiceCommand.kt", "CommandPalette.kt"]
cls = tc.compile(FILES, [HARNESS], os.path.join(WORK, "cls"), None, None)[0]
def run(c, args, lines):
    r = tc.run(c, "VoiceCommandHarnessKt", args, stdin="\n".join(lines) + "\n")
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-1200:])
    out = r.stdout.split("\n"); return out[:-1] if out and out[-1] == "" else out
NAMES = ["Quét tài liệu", "Ký tài liệu PDF", "Ghép PDF", "Chia tách PDF", "Đổi sang Word", "Nén PDF", "OCR – nhận dạng chữ", "Đặt mật khẩu"]
def pick(c, heard, names=NAMES): return run(c, ["pick"], [heard] + names)[0]

print("== A. bỏ từ lệnh")
Q = [("open compress PDF", "compress PDF"), ("Open the PDF merge please", "PDF merge"), ("go to the scan", "scan"), ("Mở nén PDF", "nén PDF"), ("mở công cụ nén pdf", "nén pdf"),
     ("Mở nén PDF nhé", "nén PDF"), ("cho tôi mở nén pdf", "nén pdf"), ("Mở nén pdf đi", "nén pdf"), ("abrir comprimir pdf por favor", "comprimir pdf"), ("ouvre fusionner pdf", "fusionner pdf"),
     ("öffne PDF teilen bitte", "PDF teilen"), ("buka gabung pdf", "gabung pdf"), ("открой сканер", "сканер"),
     ("Nén PDF", "Nén PDF"), ("mở", "-"), ("open", "-"), ("open open scan", "scan"), ("   Mở   nén   PDF  ", "nén PDF"), ("openpdf", "openpdf"), ("scanner", "scanner")]
# 'открой' is Cyrillic: fold keeps it, so it is NOT a command word here -> kept (the romanised spelling is what the list has); say so honestly
Q = [(h, w) for h, w in Q if h != "открой сканер"] + [("открой сканер", "открой сканер")]
got = run(cls, ["query"], [h for h, _ in Q])
for (h, want), g in zip(Q, got): check(g == want, f"'{h}' -> '{g}' (mong đợi '{want}')")

print("== B. chọn công cụ")
P = [("mở nén pdf", "5"), ("mở ghép pdf", "2"), ("open word", "4"), ("mở ký", "1"), ("đặt mật khẩu", "7"), ("mở ocr", "6"), ("mở quét tài liệu", "0"), ("MỞ CHIA TÁCH PDF", "3"),
     ("open pdf", "-"), ("mở tài liệu", "-"), ("xyz", "-"), ("mở", "-"), ("", "-"), ("mở pf", "-"), ("mở sgw", "-"), ("mở nen", "5")]
for h, want in P:
    g = pick(cls, h); check(g == want, f"'{h}' -> {g} (mong đợi {want}: " + ("không rõ -> chỉ điền ô tìm)" if want == "-" else NAMES[int(want)] + ")"))
check(pick(cls, "open scan", ["Scan", "Scanner"]) == "0", "'open scan': nguyên tên (100) hơn đầu tên (90)")
check(pick(cls, "open pdf", ["PDF", "Pdf"]) == "-", "hai tên giống hệt nhau -> không chọn bừa")

print("== C. thử âm tính")
def probe(c):
    return (pick(c, "mở nén pdf") == "5" and pick(c, "open pdf") == "-" and pick(c, "mở tài liệu") == "-" and pick(c, "mở pf") == "-" and pick(c, "mở sgw") == "-"
            and run(c, ["query"], ["mở công cụ nén pdf"])[0] == "nén pdf" and run(c, ["query"], ["mở nén pdf nhé"])[0] == "nén pdf")
check(probe(cls), "đối chứng: mã gốc đạt phép thử")
for name, old, new in (("chấp nhận khớp mờ (ngưỡng 20)", "const val MIN_SCORE = 60", "const val MIN_SCORE = 20"),
                       ("chọn bừa khi hai công cụ điểm bằng nhau", "if (scored.size > 1 && scored[0].second == scored[1].second) return null", ""),
                       ("không bỏ 'mở công cụ' nguyên cụm (chỉ bỏ 'mở')", '"mo cong cu", ', ""),
                       ("không bỏ lời lịch sự cuối câu", 'if (folded.endsWith(" $w")) {', 'if (false) {'),
                       ("không bỏ từ lệnh đầu câu", 'if (folded.startsWith("$w ")) {', 'if (false) {')):
    try:
        mdir = tc.compile(FILES, [HARNESS], os.path.join(WORK, "mut"), {"VoiceCommand.kt": (old, new)}, None)[0]
        check(not probe(mdir), f"mã sai bị bắt: {name}")
    except RuntimeError as e:
        check(False, f"mutant không biên dịch được: {str(e)[:110]}")

print()
print("TAT CA DAT" if not fails else f"{len(fails)} LOI")
sys.exit(1 if fails else 0)
