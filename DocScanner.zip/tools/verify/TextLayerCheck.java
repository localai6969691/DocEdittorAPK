import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Bản Java song song CÙNG THUẬT TOÁN của util/TextLayerWords.kt (phiên 20, 4.48.7). Lệnh stdin, mỗi dòng: pageW pageH n x1 base1 w1 h1 x2 base2 w2 h2 ... -> "l t r b" hoặc "NULL". */
public class TextLayerCheck {
    static final float ASCENT = 0.95f, DESCENT = 0.25f, MIN_SIZE = 0.0005f;
    static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }
    static String wordBox(float[][] g, float pw, float ph) {
        if (g.length == 0 || pw <= 0f || ph <= 0f) return "NULL";
        float l = Float.MAX_VALUE, t = Float.MAX_VALUE, r = -Float.MAX_VALUE, b = -Float.MAX_VALUE;
        for (float[] q : g) {
            float x = q[0], base = q[1], w = q[2], size = q[3];
            if (Float.isNaN(w) || Float.isNaN(size) || Float.isNaN(x) || Float.isNaN(base)) continue;
            l = Math.min(l, Math.min(x, x + w)); r = Math.max(r, Math.max(x, x + w));
            t = Math.min(t, base - ASCENT * size); b = Math.max(b, base + DESCENT * size);
        }
        if (l == Float.MAX_VALUE) return "NULL";
        float[] box = {clamp(l / pw), clamp(t / ph), clamp(r / pw), clamp(b / ph)};
        if (box[2] - box[0] < MIN_SIZE || box[3] - box[1] < MIN_SIZE) return "NULL";
        return box[0] + " " + box[1] + " " + box[2] + " " + box[3];
    }
    public static void main(String[] a) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8)); String line;
        while ((line = in.readLine()) != null) {
            if (line.isEmpty()) continue; String[] p = line.split(" ");
            int n = Integer.parseInt(p[2]); float[][] g = new float[n][4];
            for (int i = 0; i < n; i++) for (int k = 0; k < 4; k++) g[i][k] = Float.parseFloat(p[3 + 4 * i + k]);
            System.out.println(wordBox(g, Float.parseFloat(p[0]), Float.parseFloat(p[1])));
        }
    }
}
