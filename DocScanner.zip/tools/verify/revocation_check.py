"""Dữ liệu thu hồi chứng thư cho PAdES-B-LT (`Revocation.kt`; phiên 23, mục 4.51) kiểm bằng `openssl` THẬT và `cryptography`.
Bản Java `RevocationCheck.java` là bản chép từng câu của Revocation.kt. PKI thử: gốc -> trung gian -> chứng thư cuối (RSA 2048), có AIA / CDP.

  A. Trường chứng thư: serial / issuer / subject / bit khoá công khai / extensions = `cryptography` (cả chứng thư có và không có extensions).
  B. URL: OCSP (AIA) và CRL (CDP) = `cryptography`; địa chỉ ldap:// và địa chỉ không phải http(s) bị loại; chứng thư tự ký / không extensions -> rỗng.
  C. Yêu cầu OCSP: CertID và OCSPRequest KHỚP TỪNG BYTE với `openssl ocsp -issuer -cert -reqout -no_nonce`.
  D. Máy chủ `openssl ocsp -port` THẬT: yêu cầu của bản Java được trả lời; bản Java đọc: good / revoked / unknown đúng; trả lời cho chứng thư KHÁC -> không phải câu trả lời cho chứng thư này;
     trạng thái lỗi (yêu cầu méo) -> status khác 0; byte rác -> -1; `openssl ocsp -respin -resp_text` đồng ý với trạng thái.
  E. CMS: `openssl cms -sign -certfile` -> `cmsCertificates` ra đúng tập chứng thư (= `cryptography`); CMS không có chứng thư -> rỗng.
  F. Chuỗi: issuerOf / isSelfIssued đúng; chứng thư gốc không có issuer.
  G. collect (mạng giả, trả lời thật): OCSP good -> dùng OCSP; OCSP lỗi -> CRL; OCSP "revoked" KHÔNG được nhúng; câu trả lời của chứng thư khác không được nhúng; không cái nào -> không phủ;
     chuỗi lặp chứng thư không nhúng lặp; gốc tự ký không cần dữ liệu thu hồi.
  H. Bền vững: byte ngẫu nhiên và MỌI bản cắt cụt của chứng thư / trả lời OCSP / CMS / CRL thật không làm Java ném lỗi.
  I. THỬ ÂM TÍNH: bản Java băm cả SubjectPublicKeyInfo thay vì chỉ bit khoá / bỏ kiểm certID / nhận "revoked" như "good" bị bắt.
Chạy: python3 revocation_check.py   (cần java, openssl, cryptography)"""
import datetime, os, random, shutil, socket, subprocess, sys, tempfile, time, urllib.request
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID, AuthorityInformationAccessOID
from cryptography.hazmat.primitives.serialization import pkcs7

HERE = os.path.dirname(os.path.abspath(__file__)); JAVA = os.path.join(HERE, "RevocationCheck.java")
FAIL = []; rnd = random.Random(2310)
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: FAIL.append(msg)
    return ok

def jv(lines, java=JAVA):
    r = subprocess.run(["java", java], input="\n".join(lines) + "\n", capture_output=True, text=True)
    if r.returncode: print(r.stderr[-2000:]); raise SystemExit("Java lỗi")
    return r.stdout.split("\n")
def H(b): return b.hex() if b else "-"
def DER(c): return c.public_bytes(serialization.Encoding.DER)
def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p

def tlv(d, o):
    first = d[o + 1]
    if first < 128: return d[o], 2, first
    n = first & 0x7F
    return d[o], 2 + n, int.from_bytes(d[o + 2:o + 2 + n], "big")
def spki_bits(cert):
    d = cert.public_key().public_bytes(serialization.Encoding.DER, serialization.PublicFormat.SubjectPublicKeyInfo)
    t, h, l = tlv(d, 0); p = h
    t, h2, l2 = tlv(d, p); p += h2 + l2             # AlgorithmIdentifier
    t, h3, l3 = tlv(d, p)                             # BIT STRING
    return d[p + h3 + 1:p + h3 + l3]
def der_int(n):
    b = n.to_bytes((n.bit_length() + 8) // 8, "big")
    return bytes([2, len(b)]) + b if len(b) < 128 else bytes([2, 0x81, len(b)]) + b

# ---------------- PKI ----------------
tmp = tempfile.mkdtemp(prefix="revo_")
now = datetime.datetime.now(datetime.timezone.utc)
P_OCSP = free_port()
def key(): return rsa.generate_private_key(public_exponent=65537, key_size=2048)
def name(cn): return x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])
def build(subject, issuer, k, issuer_key, serial, ca, aia_ocsp=None, cdp=None):
    b = (x509.CertificateBuilder().subject_name(name(subject)).issuer_name(name(issuer)).public_key(k.public_key())
         .serial_number(serial).not_valid_before(now - datetime.timedelta(days=1)).not_valid_after(now + datetime.timedelta(days=365)))
    b = b.add_extension(x509.BasicConstraints(ca=ca, path_length=None), critical=True)
    if aia_ocsp:
        b = b.add_extension(x509.AuthorityInformationAccess([x509.AccessDescription(AuthorityInformationAccessOID.OCSP, x509.UniformResourceIdentifier(u)) for u in aia_ocsp]
            + [x509.AccessDescription(AuthorityInformationAccessOID.CA_ISSUERS, x509.UniformResourceIdentifier("http://ca.example.test/ca.crt"))]), critical=False)
    if cdp:
        b = b.add_extension(x509.CRLDistributionPoints([x509.DistributionPoint(full_name=[x509.UniformResourceIdentifier(u) for u in cdp], relative_name=None, reasons=None, crl_issuer=None)]), critical=False)
    return b.sign(issuer_key, hashes.SHA256())

k_root, k_int, k_leaf, k_rev, k_unk = key(), key(), key(), key(), key()
root = build("Gốc thử", "Gốc thử", k_root, k_root, 1, True)
inter = build("Trung gian thử", "Gốc thử", k_int, k_root, 2, True, cdp=["ldap://x.example.test/cn=a", "http://127.0.0.1:9/root.crl", "ftp://nope/x.crl"])
leaf = build("Người ký thử", "Trung gian thử", k_leaf, k_int, 0x1234ABCD, False, aia_ocsp=["http://127.0.0.1:%d/" % P_OCSP, "http://127.0.0.1:%d/second" % P_OCSP], cdp=["http://127.0.0.1:9/int.crl"])
revoked = build("Đã thu hồi", "Trung gian thử", k_rev, k_int, 0x2222, False, aia_ocsp=["http://127.0.0.1:%d/" % P_OCSP])
unknown = build("Không có trong sổ", "Trung gian thử", k_unk, k_int, 0x3333, False, aia_ocsp=["http://127.0.0.1:%d/" % P_OCSP])
for n, c in [("root", root), ("inter", inter), ("leaf", leaf), ("revoked", revoked), ("unknown", unknown)]:
    open(f"{tmp}/{n}.pem", "wb").write(c.public_bytes(serialization.Encoding.PEM)); open(f"{tmp}/{n}.der", "wb").write(DER(c))
open(f"{tmp}/inter.key", "wb").write(k_int.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
open(f"{tmp}/leaf.key", "wb").write(k_leaf.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
exp = (now + datetime.timedelta(days=300)).strftime("%y%m%d%H%M%SZ"); rev = (now - datetime.timedelta(hours=3)).strftime("%y%m%d%H%M%SZ")
# serial trong sổ phải có số chữ số chẵn
def fixed(n): s = "%X" % n; return s if len(s) % 2 == 0 else "0" + s
open(f"{tmp}/index.txt", "w").write(f"V\t{exp}\t\t{fixed(leaf.serial_number)}\tunknown\t/CN=leaf\nR\t{exp}\t{rev}\t{fixed(revoked.serial_number)}\tunknown\t/CN=revoked\n")

resp = subprocess.Popen(["openssl", "ocsp", "-index", f"{tmp}/index.txt", "-port", str(P_OCSP), "-rsigner", f"{tmp}/inter.pem", "-rkey", f"{tmp}/inter.key", "-CA", f"{tmp}/inter.pem", "-ndays", "7"],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
time.sleep(1.5)                                              # KHÔNG mở kết nối dò cổng: responder của openssl đơn luồng và bị treo bởi kết nối rỗng
if resp.poll() is not None: raise SystemExit("openssl ocsp không khởi động được")

NOPROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))   # máy chủ ở 127.0.0.1: không đi qua proxy của môi trường
def post(req, url=None):
    r = urllib.request.Request(url or f"http://127.0.0.1:{P_OCSP}/", data=req, headers={"Content-Type": "application/ocsp-request"})
    try: return NOPROXY.open(r, timeout=5).read()
    except Exception as e:
        print("  (POST lỗi:", repr(e)[:150], ")"); return b""

try:
    certs = {"root": root, "inter": inter, "leaf": leaf, "revoked": revoked, "unknown": unknown}
    # ---- A ----
    ok = True
    out = jv([f"FIELDS {DER(c).hex()}" for c in certs.values()])
    i = 0
    for n, c in certs.items():
        got = out[i:i + 5]; i += 5
        exts = c.tbs_certificate_bytes
        want = [der_int(c.serial_number).hex(), c.issuer.public_bytes().hex(), c.subject.public_bytes().hex(), spki_bits(c).hex()]
        if got[:4] != want or got[4] == "-": ok = False; print("  lệch ở", n, [g[:40] for g in got], [w[:40] for w in want])
    check(ok, "A. serial / issuer / subject / bit khoá / extensions của 5 chứng thư = cryptography")
    # chứng thư không extensions (v3 trống) và chứng thư gốc tự ký
    plain = (x509.CertificateBuilder().subject_name(name("Trơn")).issuer_name(name("Trơn")).public_key(k_leaf.public_key()).serial_number(77)
             .not_valid_before(now).not_valid_after(now + datetime.timedelta(days=5)).sign(k_leaf, hashes.SHA256()))
    out = jv([f"FIELDS {DER(plain).hex()}", f"URLS {DER(plain).hex()}"])
    check(out[4] == "-" and out[5] == "END", "A/B. chứng thư không extensions: trường đọc được, extensions = không có, URL rỗng")

    # ---- B ----
    def want_urls(c):
        o, k = [], []
        try:
            aia = c.extensions.get_extension_for_class(x509.AuthorityInformationAccess).value
            o = [d.access_location.value for d in aia if d.access_method == AuthorityInformationAccessOID.OCSP]
        except x509.ExtensionNotFound: pass
        try:
            for dp in c.extensions.get_extension_for_class(x509.CRLDistributionPoints).value:
                k += [n.value for n in (dp.full_name or [])]
        except x509.ExtensionNotFound: pass
        return [u for u in o if u.startswith("http")], [u for u in k if u.startswith("http")]
    ok = True
    for n, c in certs.items():
        out = jv([f"URLS {DER(c).hex()}"])
        got_o = [l[2:] for l in out if l.startswith("O ")]; got_c = [l[2:] for l in out if l.startswith("C ")]
        w_o, w_c = want_urls(c)
        if got_o != w_o or got_c != w_c: ok = False; print("  URL lệch ở", n, got_o, got_c, w_o, w_c)
    check(ok, "B. URL OCSP (AIA) và CRL (CDP) của 5 chứng thư = cryptography; ldap:// và ftp:// bị loại; caIssuers không lẫn vào OCSP")
    out = jv([f"URLS {DER(leaf).hex()}"])
    check(sum(1 for l in out if l.startswith("O ")) == 2, "B. hai địa chỉ OCSP giữ đúng thứ tự khai trong chứng thư")

    # ---- C ----
    out = jv([f"CERTID {DER(leaf).hex()} {DER(inter).hex()}"]); cid = out[0]
    jreq = jv([f"REQ {cid}"])[0]
    subprocess.run(["openssl", "ocsp", "-issuer", f"{tmp}/inter.pem", "-cert", f"{tmp}/leaf.pem", "-reqout", f"{tmp}/ref.req", "-no_nonce"], capture_output=True, check=True)
    ref = open(f"{tmp}/ref.req", "rb").read()
    check(bytes.fromhex(jreq) == ref, f"C. OCSPRequest của Java KHỚP TỪNG BYTE với `openssl ocsp -reqout -no_nonce` ({len(ref)} byte)")
    txt = subprocess.run(["openssl", "ocsp", "-reqin", f"{tmp}/ref.req", "-text", "-noverify"], capture_output=True, text=True).stdout
    check("Serial Number: %X" % leaf.serial_number in txt or ("%X" % leaf.serial_number) in txt.replace("0x", ""), "C. openssl đọc yêu cầu của Java và thấy đúng số serial")
    cids = {}
    for n in ("leaf", "revoked", "unknown"):
        cids[n] = jv([f"CERTID {DER(certs[n]).hex()} {DER(inter).hex()}"])[0]
    check(len(set(cids.values())) == 3, "C. ba chứng thư khác nhau -> ba CertID khác nhau")
    check(jv([f"CERTID {DER(leaf).hex()} 00"])[0] == "-" or jv([f"CERTID {DER(leaf).hex()} 00"])[0] == "", "C. issuer hỏng -> không có CertID (không ném lỗi)")

    # ---- D ----
    reqs = {n: bytes.fromhex(jv([f"REQ {cids[n]}"])[0]) for n in cids}
    resps = {n: post(reqs[n]) for n in reqs}
    check(all(len(r) > 50 for r in resps.values()), "D. máy chủ `openssl ocsp` thật trả lời cả 3 yêu cầu do Java dựng")
    exp_status = {"leaf": 0, "revoked": 1, "unknown": 2}
    out = jv([f"PARSE {(resps[n].hex() or '00')} {cids[n]}" for n in cids])
    ok = all(o == f"0 {exp_status[n]} 1" for o, n in zip(out, cids))
    check(ok, f"D. Java đọc đúng: leaf=good(0), revoked=revoked(1), unknown=unknown(2), đều trả lời đúng chứng thư ({out[:3]})")
    for n in ("leaf", "revoked"):
        open(f"{tmp}/r.der", "wb").write(resps[n])
        t = subprocess.run(["openssl", "ocsp", "-respin", f"{tmp}/r.der", "-resp_text", "-noverify"], capture_output=True, text=True).stdout
        want = "good" if n == "leaf" else "revoked"
        if not check(f"Cert Status: {want}" in t, f"D. `openssl ocsp -respin -resp_text` cũng nói {want} cho {n}"): break
    out = jv([f"PARSE {resps['leaf'].hex()} {cids['revoked']}", f"PARSE {resps['leaf'].hex()} {cids['unknown']}"])
    check(out[:2] == ["0 0 0", "0 0 0"], f"D. trả lời của chứng thư KHÁC không được coi là trả lời cho chứng thư này ({out})")
    # trạng thái lỗi của OCSPResponse (RFC 6960: 1 malformedRequest, 2 internalError, 3 tryLater, 5 sigRequired, 6 unauthorized); openssl không trả lời yêu cầu méo nên dựng tay
    out = jv([f"PARSE 30030a01{c:02x} {cids['leaf']}" for c in (1, 2, 3, 5, 6)])
    check([o.split()[0] for o in out[:5]] == ["1", "2", "3", "5", "6"] and all(o.split()[1:] == ["-1", "0"] for o in out[:5]), f"D. OCSPResponse trạng thái lỗi 1/2/3/5/6 -> Java trả đúng mã, không có câu trả lời ({out[:5]})")
    out = jv([f"PARSE {os.urandom(60).hex()} {cids['leaf']}", "PARSE 3000 " + cids["leaf"], "PARSE 00 " + cids["leaf"]])
    check(out[:3] == ["-1 -1 0"] * 3, "D. byte rác / SEQUENCE rỗng / một byte -> -1 (không ném lỗi)")

    # ---- E ----
    open(f"{tmp}/msg.txt", "wb").write(b"noi dung")
    open(f"{tmp}/chain.pem", "wb").write(open(f"{tmp}/inter.pem", "rb").read() + open(f"{tmp}/root.pem", "rb").read())
    subprocess.run(["openssl", "cms", "-sign", "-binary", "-in", f"{tmp}/msg.txt", "-signer", f"{tmp}/leaf.pem", "-inkey", f"{tmp}/leaf.key", "-certfile", f"{tmp}/chain.pem",
                    "-outform", "DER", "-out", f"{tmp}/s.cms", "-nodetach"], capture_output=True, check=True)
    cms = open(f"{tmp}/s.cms", "rb").read()
    out = jv([f"CMSCERTS {cms.hex()}"]); n = int(out[0]); got = set(out[1:1 + n])
    check(got == {DER(c).hex() for c in (leaf, inter, root)} and n == 3, f"E. cmsCertificates ra đúng 3 chứng thư (signer + trung gian + gốc), mỗi cái nguyên byte ({n})")
    subprocess.run(["openssl", "cms", "-sign", "-binary", "-in", f"{tmp}/msg.txt", "-signer", f"{tmp}/leaf.pem", "-inkey", f"{tmp}/leaf.key", "-nocerts", "-outform", "DER", "-out", f"{tmp}/n.cms"], capture_output=True, check=True)
    out = jv([f"CMSCERTS {open(tmp + '/n.cms', 'rb').read().hex()}", "CMSCERTS 3000", "CMSCERTS " + os.urandom(40).hex()])
    check(out[0] == "0" and out[1] == "0" and out[2] == "0", "E. CMS không có chứng thư / rỗng / rác -> 0 chứng thư")

    # ---- F ----
    pool = [DER(c).hex() for c in (root, inter, leaf)]
    out = jv([f"ISSUER {pool[2]} {','.join(pool)}", f"ISSUER {pool[1]} {','.join(pool)}", f"ISSUER {pool[0]} {','.join(pool)}", f"ISSUER {pool[2]} {pool[0]}", f"SELF {pool[0]}", f"SELF {pool[2]}"])
    check(out[:6] == ["1", "0", "-1", "-1", "true", "false"], f"F. issuer của leaf = trung gian (1), của trung gian = gốc (0), gốc không có issuer, thiếu trung gian -> -1; SELF đúng ({out[:6]})")

    # ---- G ----
    crl_int = (x509.CertificateRevocationListBuilder().issuer_name(name("Gốc thử")).last_update(now).next_update(now + datetime.timedelta(days=7)).sign(k_root, hashes.SHA256()))
    crl_der = crl_int.public_bytes(serialization.Encoding.DER)
    chain = ",".join([pool[2], pool[1], pool[0]])
    def collect(maps, ch=chain):
        cmds = []
        for kind, url, val in maps: cmds.append(f"MAP {kind} {url.encode().hex()} {val}")
        cmds.append(f"COLLECT {ch}")
        out = jv(cmds); head = out[0].split(); return [int(x) for x in head], out[1:1 + int(head[3]) + int(head[4])]
    u_leaf = "http://127.0.0.1:%d/" % P_OCSP; u_root_crl = "http://127.0.0.1:9/root.crl"; u_int_crl = "http://127.0.0.1:9/int.crl"
    (needed, covered, nc, no, nk), blobs = collect([("POST", u_leaf, resps["leaf"].hex()), ("GET", u_root_crl, crl_der.hex())])
    check((needed, covered, nc, no, nk) == (2, 2, 3, 1, 1) and blobs[0] == resps["leaf"].hex() and blobs[1] == crl_der.hex(),
          f"G. OCSP good cho leaf + CRL cho trung gian: cần 2, phủ 2, 3 chứng thư, 1 OCSP, 1 CRL, nguyên byte ({needed},{covered},{nc},{no},{nk})")
    (needed, covered, nc, no, nk), blobs = collect([("GET", u_int_crl, crl_der.hex()), ("GET", u_root_crl, crl_der.hex())])
    check((needed, covered, no, nk) == (2, 2, 0, 1), f"G. OCSP không trả lời -> rơi sang CRL (và hai CRL giống nhau chỉ nhúng 1 bản) ({needed},{covered},{no},{nk})")
    (needed, covered, nc, no, nk), _ = collect([("POST", u_leaf, resps["revoked"].hex()), ("GET", u_root_crl, crl_der.hex())])
    check((needed, covered, no) == (2, 1, 0), f"G. trả lời OCSP của chứng thư KHÁC (đã thu hồi) không được nhúng; không CRL cho leaf -> không phủ ({needed},{covered},{no})")
    revoked_for_leaf_chain = ",".join([DER(revoked).hex(), pool[1], pool[0]])
    (needed, covered, nc, no, nk), _ = collect([("POST", u_leaf, resps["revoked"].hex()), ("GET", u_root_crl, crl_der.hex())], revoked_for_leaf_chain)
    check((needed, covered, no) == (2, 1, 0), f"G. OCSP báo REVOKED: KHÔNG nhúng như bằng chứng hợp lệ ({needed},{covered},{no})")
    (needed, covered, nc, no, nk), _ = collect([("POST", u_leaf, "FAIL")])
    check((needed, covered, no, nk) == (2, 0, 0, 0), f"G. mạng không trả lời gì: cần 2, phủ 0 ({needed},{covered})")
    (needed, covered, nc, no, nk), _ = collect([("POST", u_leaf, resps["leaf"].hex()), ("GET", u_root_crl, crl_der.hex())], ",".join([pool[2], pool[2], pool[1], pool[0], pool[0]]))
    check(nc == 3 and no == 1 and nk == 1, f"G. chuỗi lặp chứng thư không nhúng lặp: {nc} chứng thư, {no} OCSP, {nk} CRL")
    (needed, covered, nc, no, nk), _ = collect([("GET", u_root_crl, "3000")], pool[0])
    check((needed, covered, nc) == (0, 0, 1), "G. chỉ có gốc tự ký: không cần dữ liệu thu hồi")
    (needed, covered, nc, no, nk), _ = collect([("POST", u_leaf, resps["leaf"].hex())], pool[2])
    check((needed, covered, nc) == (1, 0, 1), "G. thiếu chứng thư trung gian trong chuỗi -> không dựng được CertID -> không phủ (không đoán)")
    pem_crl = crl_int.public_bytes(serialization.Encoding.PEM).hex()
    (needed, covered, nc, no, nk), _ = collect([("GET", u_root_crl, pem_crl), ("GET", u_int_crl, pem_crl)])
    check(nk == 0 and covered == 0, "G. CRL dạng PEM (không phải DER) bị từ chối")

    # ---- H ----
    blobs = [DER(leaf), resps["leaf"], cms, crl_der]
    cmds = []
    for b in blobs:
        step = max(1, len(b) // 60)
        for n in list(range(0, len(b), step)) + [len(b) - 1]:
            h = b[:n].hex() or "00"
            cmds += [f"FIELDS {h}", f"URLS {h}", f"PARSE {h} {cids['leaf']}", f"CMSCERTS {h}", f"CRL {h}", f"CERTID {h} {DER(inter).hex()}", f"SELF {h}"]
    for _ in range(200):
        h = os.urandom(rnd.randint(1, 300)).hex()
        cmds += [f"FIELDS {h}", f"URLS {h}", f"PARSE {h} {cids['leaf']}", f"CMSCERTS {h}", f"CRL {h}"]
    for b in blobs[:3]:       # đổi từng byte một vài chỗ
        for _ in range(60):
            m = bytearray(b); m[rnd.randrange(len(m))] = rnd.randrange(256); h = bytes(m).hex()
            cmds += [f"FIELDS {h}", f"URLS {h}", f"PARSE {h} {cids['leaf']}", f"CMSCERTS {h}"]
    r = subprocess.run(["java", JAVA], input="\n".join(cmds) + "\n", capture_output=True, text=True)
    check(r.returncode == 0 and "Exception" not in r.stderr, f"H. {len(cmds)} lệnh trên byte rác / bản cắt cụt / bản bị đổi byte của chứng thư, OCSP, CMS, CRL thật: không ném lỗi")
    h = DER(leaf).hex()
    check(jv([f"FIELDS {h[:200]}"])[0] == "NONE", "H. chứng thư cụt -> NONE")

    # ---- I. thử âm tính ----
    import re
    src = open(JAVA, encoding="utf-8").read()
    muts = {
        "băm cả SubjectPublicKeyInfo thay vì bit khoá": ("sha1(i.publicKeyBits)", "sha1(i.subject)"),
        "bỏ kiểm certID trong trả lời": ("if (Arrays.equals(slice(basic, f.get(0)), certId)) return new int[]{0, st, 1};", "if (true) return new int[]{0, st, 1};"),
        "nhận revoked như good": ("a[1] == CERT_GOOD", "a[1] >= 0"),
        "không bỏ gốc tự ký": ("if (isSelfIssued(cert)) continue;", ""),
    }
    for name_, (a, b) in muts.items():
        assert a in src, name_
        mp = os.path.join(tmp, "Mut.java"); open(mp, "w", encoding="utf-8").write(src.replace(a, b, 1).replace("public class RevocationCheck", "public class Mut"))
        pass_all = True
        try:
            jreq2 = jv([f"CERTID {DER(leaf).hex()} {DER(inter).hex()}"], mp)[0]
            req2 = jv([f"REQ {jreq2}"], mp)[0]
            bad_req = bytes.fromhex(req2) != ref
            p1 = jv([f"PARSE {resps['leaf'].hex()} {cids['revoked']}"], mp)[0]
            p2 = jv([f"PARSE {resps['revoked'].hex()} {cids['revoked']}"], mp)[0]
            caught = bad_req or p1 != "0 0 0" or p2 != "0 1 1"
            out3 = jv([f"MAP POST {u_leaf.encode().hex()} {resps['revoked'].hex()}", f"MAP GET {u_root_crl.encode().hex()} {crl_der.hex()}", f"COLLECT {revoked_for_leaf_chain}"], mp)
            h3 = out3[0].split()
            caught = caught or (h3[1], h3[3]) != ("1", "0")          # bản đúng: phủ 1 (chỉ trung gian), 0 OCSP
            if name_.startswith("không bỏ gốc"):
                out2 = jv([f"MAP GET {u_root_crl.encode().hex()} {crl_der.hex()}", f"COLLECT {pool[0]}"], mp)
                caught = out2[0].split()[0] != "0"
        except SystemExit:
            caught = True
        check(caught, f"I. ÂM TÍNH: bản Java '{name_}' bị bắt")
finally:
    resp.terminate(); shutil.rmtree(tmp, ignore_errors=True)

print()
print("TAT CA DAT" if not FAIL else f"CO {len(FAIL)} LOI")
sys.exit(1 if FAIL else 0)
