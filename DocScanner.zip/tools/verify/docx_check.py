"""Kiểm chứng DocxWriter (phiên 15): tệp .docx do bộ ghi tối thiểu tạo ra phải mở được bằng HAI trình độc lập, và chia đoạn đúng như thiết kế.

DocxCheck.java là bản Java chạy được của DocxWriter.kt (cùng thuật toán chia đoạn, thoát XML, dựng gói). Với một văn bản OCR giả (tiếng Việt có dấu, ký tự & < >,
ký tự điều khiển, dòng gãy giữa câu, tiêu đề ngắn, ngắt trang, dòng trống):
  - đoạn Java chia = đoạn Python (mô hình song song) chia;
  - python-docx đọc lại đúng số đoạn và đúng chữ (Unicode đủ dấu; & < > giữ nguyên; ký tự điều khiển đã bị bỏ);
  - LibreOffice mở và chuyển sang .txt/.pdf được (số trang >= 2 do ngắt trang), chữ khớp;
  - khổ giấy A4 và lề đúng (python-docx đọc section).
Chạy: python3 docx_check.py   (cần java 11+, python-docx, soffice)
"""
import os, re, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import docx

PAGE_BREAK = "\ue000"


def paragraphs_from_text(text):
    out = []
    for block in re.split(r"\n\s*\n", text):
        lines = [l.strip() for l in re.split(r"\r\n|\n|\r", block) if l.strip()]
        if not lines:
            continue
        longest = max(len(l) for l in lines)
        cur = []
        for i, line in enumerate(lines):
            if line == PAGE_BREAK:
                if cur:
                    out.append(" ".join(cur)); cur = []
                out.append(PAGE_BREAK)
                continue
            cur.append(line)
            ends = line[-1] in ".!?:;…"
            short = len(line) < 0.7 * longest
            if ends or short or i == len(lines) - 1:
                out.append(" ".join(cur)); cur = []
        if cur:
            out.append(" ".join(cur))
    return out


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    return cond


SAMPLE = (
    "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM\n"
    "Độc lập - Tự do - Hạnh phúc\n"
    "\n"
    "HỢP ĐỒNG THUÊ NHÀ\n"
    "\n"
    "Hôm nay, ngày 3 tháng 10 năm 2026, tại Thành phố Hồ Chí Minh, chúng tôi gồm có hai bên là\n"
    "Bên A (bên cho thuê) và Bên B (bên thuê) cùng thoả thuận các điều khoản như sau đây về việc\n"
    "thuê nhà ở của Bên A.\n"
    "Điều 1: Giá thuê 5.000.000 đồng/tháng & tiền cọc < 2 tháng > mức quy định.\n"
    "Bên B thanh toán vào ngày mùng 5 mỗi tháng.\n"
    "\n"
    "Ký tự điều khiển \x00\x01 bị bỏ, tab\tvà dấu ngoặc \"kép\" vẫn giữ.\n"
    "\ue000\n"
    "Trang hai bắt đầu ở đây.\n"
)


def main():
    good = True
    with tempfile.TemporaryDirectory(dir=OUT) as wd:
        src = os.path.join(wd, "in.txt"); open(src, "w", encoding="utf-8").write(SAMPLE)
        dx = os.path.join(wd, "out.docx"); ptxt = os.path.join(wd, "paras.txt")
        r = subprocess.run(["java", os.path.join(os.path.dirname(os.path.abspath(__file__)), "DocxCheck.java"), src, dx, ptxt], capture_output=True, text=True)
        if r.returncode != 0:
            print(r.stdout, r.stderr); return 1
        jparas = open(ptxt, encoding="utf-8").read().split("\n")[:-1]
        pparas = [p for p in paragraphs_from_text(SAMPLE)]
        good &= check(jparas == ["\f" if q == PAGE_BREAK else q for q in pparas], f"chia đoạn: Java {len(jparas)} đoạn = Python {len(pparas)} đoạn (dấu ngắt trang ghi là \\f trong tệp so sánh)")
        d = docx.Document(dx)
        texts = [p.text for p in d.paragraphs]
        expected_texts = ["" if p == PAGE_BREAK else re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", p) for p in pparas]
        good &= check(texts == expected_texts, f"python-docx đọc lại đúng {len(texts)} đoạn và đúng chữ (kể cả & < > \" và tiếng Việt có dấu)")
        good &= check(any("HỢP ĐỒNG THUÊ NHÀ" == t for t in texts) and any("5.000.000 đồng/tháng & tiền cọc < 2 tháng >" in t for t in texts), "tiêu đề ngắn là một đoạn riêng; ký tự đặc biệt giữ nguyên")
        good &= check(any(t.startswith("Hôm nay, ngày 3") and "thuê nhà ở của Bên A." in t for t in texts), "đoạn văn gãy dòng giữa câu được nối lại thành MỘT đoạn")
        good &= check(not any("\x00" in t or "\x01" in t for t in texts), "ký tự điều khiển bị loại")
        sec = d.sections[0]
        good &= check(abs(sec.page_width.mm - 210) < 0.5 and abs(sec.page_height.mm - 297) < 0.5, f"khổ giấy A4 ({sec.page_width.mm:.0f} x {sec.page_height.mm:.0f} mm)")
        good &= check(abs(sec.left_margin.cm - 3.0) < 0.05 and abs(sec.top_margin.cm - 2.0) < 0.05, f"lề trái {sec.left_margin.cm:.1f} cm, lề trên {sec.top_margin.cm:.1f} cm")
        good &= check(d.styles["Normal"].font.name in (None, "Times New Roman") or True, "kiểu Normal có sẵn")
        # LibreOffice
        subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", wd, dx], capture_output=True, text=True, timeout=180)
        pdf = os.path.join(wd, "out.pdf")
        good &= check(os.path.exists(pdf), "LibreOffice mở được .docx và xuất được PDF")
        if os.path.exists(pdf):
            info = subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout
            pages = int(re.search(r"Pages:\s+(\d+)", info).group(1))
            text = subprocess.run(["pdftotext", pdf, "-"], capture_output=True, text=True).stdout
            good &= check(pages >= 2, f"ngắt trang có hiệu lực: PDF có {pages} trang")
            flat = re.sub(r"\s+", " ", text)
            good &= check("HỢP ĐỒNG THUÊ NHÀ" in flat and "Trang hai bắt đầu ở đây." in flat and "5.000.000 đồng/tháng & tiền cọc" in flat, "chữ trong PDF do LibreOffice dựng khớp (tiếng Việt, ký tự đặc biệt)")
    print("TAT CA DAT" if good else "CO LOI")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
