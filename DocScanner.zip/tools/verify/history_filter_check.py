"""Kiểm chứng HistoryFilter (phiên 15): tìm kiếm không phân biệt hoa-thường và DẤU tiếng Việt, sắp xếp, yêu thích lên đầu.

Bản Python song song của app/.../util/HistoryFilter.kt (normalize, matches, arrange): cùng cách chuẩn hoá
(lowercase -> NFD -> bỏ dấu kết hợp \\p{Mn} -> 'đ' thành 'd'), cùng AND nhiều từ, cùng sắp xếp ổn định rồi tách nhóm yêu thích.
Java `Normalizer.NFD` và Python `unicodedata.normalize('NFD')` cùng chuẩn Unicode nên kết quả trùng nhau.
Chạy: python3 history_filter_check.py
"""
import re, sys, unicodedata


def normalize(text):
    d = unicodedata.normalize("NFD", text.lower())
    d = "".join(c for c in d if unicodedata.category(c) != "Mn")
    return d.replace("đ", "d")


def matches(name, query):
    words = [w for w in re.split(r"\s+", normalize(query)) if w]
    if not words:
        return True
    hay = normalize(name)
    return all(w in hay for w in words)


MAX_TAG_LENGTH = 60


def clean_tag(raw):
    replaced = "".join(" " if c in ',;"\\' or ord(c) < 32 or 0x7f <= ord(c) < 0xa0 else c for c in raw)
    spaced = re.sub(r"\s+", " ", replaced).strip()
    path = "/".join(p.strip() for p in spaced.split("/") if p.strip())          # "Work / / Invoices/" -> "Work/Invoices"
    return path[:MAX_TAG_LENGTH].strip().rstrip("/").strip()


def canonical(tag, existing):
    key = normalize(tag)
    return next((e for e in existing if normalize(e) == key), tag)


def segments(tag):
    return [p.strip() for p in tag.split("/") if p.strip()]


def tag_matches(tag, flt):
    """TagTree.matches: the tag is the folder itself or lies below it (Work/Invoices is below Work; Workshop is not)."""
    want = [normalize(p) for p in segments(flt)]
    have = [normalize(p) for p in segments(tag)]
    return bool(want) and len(have) >= len(want) and have[:len(want)] == want


def tag_rows(tags_by_file):
    """TagTree.rows (port): [(path, label, depth, count)] parents before children, A to Z on the normalised segments."""
    folders = {}
    for f in sorted(tags_by_file):
        for tag in sorted(tags_by_file[f]):
            parts = segments(tag)
            for i in range(1, len(parts) + 1):
                shown = parts[:i]
                folders.setdefault(tuple(normalize(p) for p in shown), (shown, set()))[1].add(f)
    return [("/".join(folders[k][0]), folders[k][0][-1], len(folders[k][0]), len(folders[k][1])) for k in sorted(folders)]


def arrange(items, query, sort, tag_filter=None, content=None):
    """items: list of dict(name, modified, size, fav, tags) -> danh sách đã lọc/sắp xếp (sorted của Python cũng ổn định như Kotlin)."""
    fk = normalize(tag_filter) if tag_filter else None
    words = [w for w in re.split(r"\s+", normalize(query)) if w]

    def found(i):
        if not words:
            return True
        name_tags = normalize(i["name"] + " " + " ".join(i.get("tags", ())))
        body = content(i) if content else None          # đã chuẩn hoá sẵn (ContentIndex), KHÔNG chuẩn hoá lại
        return all(w in name_tags or (body is not None and w in body) for w in words)
    kept = [i for i in items if (fk is None or any(tag_matches(t, tag_filter) for t in i.get("tags", ()))) and found(i)]
    if sort == "NEWEST":
        kept = sorted(kept, key=lambda i: -i["modified"])
    elif sort == "NAME":
        kept = sorted(kept, key=lambda i: (normalize(i["name"]), i["name"]))
    elif sort == "LARGEST":
        kept = sorted(kept, key=lambda i: -i["size"])
    return [i for i in kept if i["fav"]] + [i for i in kept if not i["fav"]]


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    return cond


def tree_checks():
    """TagTree: bản port + ĐỐI CHỨNG ĐỘC LẬP (vét cạn: với mỗi đường dẫn thư mục có thể có, đếm tài liệu bằng cách so từng thẻ) trên dữ liệu ngẫu nhiên có dấu, hoa / thường, dấu / thừa."""
    import random
    ok = True
    rnd = random.Random(2209)
    words = ["Công việc", "cong viec", "CÔNG VIỆC", "Hoá đơn", "hoa don", "Hợp đồng", "Nhà", "nha", "Work", "work", "Workshop", "2026", "Thuế", "A", "b"]
    def rand_tag():
        parts = [rnd.choice(words) for _ in range(rnd.choice([1, 1, 2, 3]))]
        raw = rnd.choice([" / ", "/", " /", "/ "]).join(parts)
        return clean_tag(raw)
    ref_bad = []
    for trial in range(300):
        files = {f"f{i}.pdf": {t for t in (rand_tag() for _ in range(rnd.choice([0, 1, 2, 4]))) if t} for i in range(rnd.randrange(0, 12))}
        rows = tag_rows(files)
        # reference: every prefix that exists, counted by brute force
        prefixes = set()
        for tags in files.values():
            for t in tags:
                parts = [normalize(p) for p in segments(t)]
                for i in range(1, len(parts) + 1): prefixes.add(tuple(parts[:i]))
        if [tuple(normalize(p) for p in r[0].split("/")) for r in rows] != sorted(prefixes): ref_bad.append(("folders", trial)); continue
        for path, label, depth, count in rows:
            want = [normalize(p) for p in path.split("/")]
            brute = sum(1 for tags in files.values() if any([normalize(p) for p in segments(t)][:len(want)] == want for t in tags))
            if brute != count or depth != len(want) or label != path.split("/")[-1]: ref_bad.append((path, count, brute))
        # filtering through arrange() equals "the document has a tag at or below the folder"
        if rows:
            flt = rnd.choice(rows)[0]
            items = [dict(name=n, modified=1, size=1, fav=False, tags=tuple(t)) for n, t in files.items()]
            got = {i["name"] for i in arrange(items, "", "NEWEST", flt)}
            want_set = {n for n, tags in files.items() if any([normalize(p) for p in segments(t)][:len(segments(flt))] == [normalize(p) for p in segments(flt)] for t in tags)}
            if got != want_set: ref_bad.append(("filter", flt))
    ok &= check(not ref_bad, f"TagTree: 300 bộ dữ liệu ngẫu nhiên: danh sách thư mục, độ sâu, nhãn, SỐ TÀI LIỆU và lọc theo thư mục cha = đối chứng vét cạn{'' if not ref_bad else ' ' + str(ref_bad[:3])}")
    f = {"a.pdf": {"Work/Invoices"}, "b.pdf": {"Work", "Workshop"}, "c.pdf": {"công việc/Hoá đơn/2026", "Work/Invoices"}, "d.pdf": {"Nhà"}}
    r = tag_rows(f)
    ok &= check([(x[0], x[2], x[3]) for x in r] == [("công việc", 1, 1), ("công việc/Hoá đơn", 2, 1), ("công việc/Hoá đơn/2026", 3, 1), ("Nhà", 1, 1), ("Work", 1, 3), ("Work/Invoices", 2, 2), ("Workshop", 1, 1)],
                "TagTree: ví dụ có tên: cha đứng trước con, 'Work' đếm 3 tài liệu (a, b, c) dù c chỉ có thẻ con, 'Work/Invoices' đếm 2, 'Workshop' tách riêng")
    ok &= check(tag_matches("Work/Invoices", "Work") and tag_matches("Work", "work") and not tag_matches("Workshop", "Work") and not tag_matches("Work", "Work/Invoices") and tag_matches("Công việc/Hoá đơn", "cong viec/hoa don") and not tag_matches("x", ""), "TagTree.matches: con thuộc cha, Workshop KHÔNG thuộc Work, cha không thuộc con, bỏ dấu và hoa / thường, bộ lọc rỗng không khớp gì")
    items = [dict(name="a.pdf", modified=3, size=1, fav=False, tags=("Work/Invoices",)), dict(name="b.pdf", modified=2, size=1, fav=False, tags=("Workshop",)), dict(name="c.pdf", modified=1, size=1, fav=False, tags=("work",))]
    ok &= check([i["name"] for i in arrange(items, "", "NEWEST", "Work")] == ["a.pdf", "c.pdf"], "lọc 'Work': gồm Work/Invoices và work, KHÔNG gồm Workshop")
    # NEGATIVE CONTROL: the old exact-match filter would have missed the sub-folder
    old = [i["name"] for i in items if any(normalize(t) == normalize("Work") for t in i["tags"])]
    ok &= check(old == ["c.pdf"], "ÂM TÍNH: bộ lọc khớp-chính-xác cũ bỏ sót tài liệu trong thư mục con (nên cần TagTree.matches)")
    return ok


def main():
    good = True
    good &= check(normalize("Hợp Đồng Thuê Nhà") == "hop dong thue nha", "chuẩn hoá: bỏ dấu, hạ chữ, đ -> d")
    good &= check(normalize("ĐỖ ĐÌNH") == "do dinh", "chuẩn hoá chữ hoa có Đ")
    nfc = "Hợp đồng"
    nfd = unicodedata.normalize("NFD", nfc)
    good &= check(nfc != nfd and normalize(nfc) == normalize(nfd), "dạng NFC và NFD của cùng một chữ cho kết quả giống nhau")
    good &= check(matches("Hợp đồng thuê nhà.pdf", "hop dong"), "gõ không dấu tìm ra tên có dấu")
    good &= check(matches("Hợp đồng thuê nhà.pdf", "HỢP ĐỒNG"), "gõ có dấu, chữ hoa")
    good &= check(matches("Hợp đồng thuê nhà.pdf", "nha hop"), "nhiều từ, không cần đúng thứ tự")
    good &= check(not matches("Hợp đồng thuê nhà.pdf", "hop dong xe"), "một từ không có thì loại (AND)")
    good &= check(matches("anything.pdf", "") and matches("anything.pdf", "   "), "truy vấn trống hoặc toàn dấu cách khớp tất cả")
    good &= check(matches("Scan_2026-10-03.pdf", "2026-10"), "tìm theo một phần của số/ngày")
    good &= check(not matches("hoa don.pdf", "hóa đơn xyz"), "không khớp khi thiếu từ")
    good &= check(matches("hoa don.pdf", "hóa đơn"), "gõ CÓ dấu vẫn tìm ra tên KHÔNG dấu")

    items = [
        dict(name="b_hop dong.pdf", modified=100, size=500, fav=False),
        dict(name="A_ban sao.pdf", modified=300, size=100, fav=False),
        dict(name="Đơn xin.pdf", modified=200, size=900, fav=True),
        dict(name="c_hoa don.epub", modified=400, size=900, fav=False),
        dict(name="Z_ghi chu.txt", modified=50, size=100, fav=True),
    ]
    names = lambda r: [i["name"] for i in r]
    r = arrange(items, "", "NEWEST")
    good &= check(names(r) == ["Đơn xin.pdf", "Z_ghi chu.txt", "c_hoa don.epub", "A_ban sao.pdf", "b_hop dong.pdf"],
                  "NEWEST: yêu thích lên đầu (mới nhất trước), rồi phần còn lại mới nhất trước")
    r = arrange(items, "", "NAME")
    good &= check(names(r) == ["Đơn xin.pdf", "Z_ghi chu.txt", "A_ban sao.pdf", "b_hop dong.pdf", "c_hoa don.epub"],
                  "NAME: theo tên đã bỏ dấu, không phân biệt hoa-thường ('Đơn' ~ 'don' đứng trước 'z')")
    r = arrange(items, "", "LARGEST")
    good &= check(names(r) == ["Đơn xin.pdf", "Z_ghi chu.txt", "c_hoa don.epub", "b_hop dong.pdf", "A_ban sao.pdf"],
                  "LARGEST: lớn nhất trước trong từng nhóm; bằng nhau thì giữ thứ tự cũ (ổn định)")
    r = arrange(items, "don", "NEWEST")
    # tìm theo chuỗi con nên "don" cũng khớp "hop dong" (d-o-n-g chứa d-o-n): 3 kết quả, yêu thích trước, còn lại mới nhất trước
    good &= check(names(r) == ["Đơn xin.pdf", "c_hoa don.epub", "b_hop dong.pdf"], "lọc 'don' (khớp chuỗi con) rồi sắp xếp: yêu thích trước")
    r = arrange(items, "don xin", "NEWEST")
    good &= check(names(r) == ["Đơn xin.pdf"], "thêm từ thứ hai thu hẹp kết quả còn 1")
    r = arrange(items, "khong co", "NEWEST")
    good &= check(r == [], "không khớp gì -> danh sách rỗng")
    # hai tệp bằng nhau về mọi khoá sắp xếp phải giữ thứ tự vào (ổn định)
    # ---- thẻ ----
    tagged = [
        dict(name="scan_001.pdf", modified=10, size=1, fav=False, tags=["Hợp đồng", "Nhà"]),
        dict(name="scan_002.pdf", modified=30, size=1, fav=False, tags=["Thuế 2026"]),
        dict(name="scan_003.pdf", modified=20, size=1, fav=True, tags=["hop dong"]),
        dict(name="scan_004.pdf", modified=40, size=1, fav=False),
    ]
    good &= check(names(arrange(tagged, "thue", "NEWEST")) == ["scan_002.pdf"], "tìm theo chữ trong thẻ (không dấu): 'thue' ra tài liệu gắn thẻ 'Thuế 2026'")
    good &= check(names(arrange(tagged, "", "NEWEST", "Hợp đồng")) == ["scan_003.pdf", "scan_001.pdf"], "lọc theo thẻ 'Hợp đồng' gồm cả thẻ viết không dấu 'hop dong' (cùng một thẻ), sao lên đầu")
    good &= check(names(arrange(tagged, "nha", "NEWEST", "hop dong")) == ["scan_001.pdf"], "lọc thẻ + tìm chữ: AND của hai điều kiện")
    good &= check(names(arrange(tagged, "", "NEWEST", "không có thẻ này")) == [], "thẻ không tồn tại: rỗng")
    good &= check(len(arrange(tagged, "", "NEWEST")) == 4, "không lọc thẻ: đủ 4 tài liệu (kể cả tài liệu chưa gắn thẻ)")
    good &= check(clean_tag('  Hợp   đồng, "A";B\\C  ') == "Hợp đồng A B C", "clean_tag: bỏ , ; \" \\, gộp dấu cách")
    good &= check(clean_tag("x" * 90) == "x" * 60 and clean_tag(",,,") == "", "clean_tag: cắt 60 ký tự (đường dẫn thư mục dài hơn một từ); toàn ký tự cấm -> rỗng")
    good &= check(clean_tag(" Công việc / / Hoá đơn/ ") == "Công việc/Hoá đơn" and clean_tag("/") == "" and clean_tag("//a//") == "a" and clean_tag("a/" + "b" * 80).endswith("b") and not clean_tag("a" * 59 + "/b").endswith("/"), "clean_tag: dọn dấu / của thư mục (khoảng trắng, dấu / thừa đầu cuối, không để lại / ở cuối khi bị cắt)")
    good &= tree_checks()
    good &= check(canonical("hop dong", ["Thuế", "Hợp đồng"]) == "Hợp đồng" and canonical("Mới", ["Thuế"]) == "Mới", "canonical: dùng lại cách viết đã có, thẻ mới giữ nguyên")
    # ---- nội dung (phiên 16) ----
    docs = [
        dict(name="scan_001.pdf", modified=10, size=1, fav=False),
        dict(name="scan_002.pdf", modified=20, size=1, fav=False, tags=["Nhà"]),
        dict(name="scan_003.pdf", modified=30, size=1, fav=True),
        dict(name="scan_004.pdf", modified=40, size=1, fav=False),
    ]
    text = {"scan_001.pdf": normalize("HỢP ĐỒNG thuê nhà số 12\nBên A: Nguyễn Văn An"), "scan_002.pdf": normalize("Hóa đơn tiền điện tháng 9"),
            "scan_003.pdf": normalize("Hợp đồng lao động"), "scan_004.pdf": None}
    body = lambda i: text.get(i["name"])
    good &= check(names(arrange(docs, "hop dong", "NEWEST", None, body)) == ["scan_003.pdf", "scan_001.pdf"], "tìm theo NỘI DUNG: 'hop dong' ra 2 tài liệu có chữ 'Hợp đồng' (yêu thích trước)")
    good &= check(names(arrange(docs, "hop dong", "NEWEST")) == [], "không có nội dung (chưa nạp chỉ mục): tên scan_00x không khớp -> rỗng, đúng như trước phiên 16")
    good &= check(names(arrange(docs, "hop dong thue", "NEWEST", None, body)) == ["scan_001.pdf"], "nhiều từ cùng nằm trong nội dung (AND): 'hop dong thue' chỉ còn 1")
    good &= check(names(arrange(docs, "nha dien", "NEWEST", None, body)) == ["scan_002.pdf"], "AND giữa các nguồn: 'nha' ở THẺ + 'dien' ở NỘI DUNG của cùng một tài liệu")
    good &= check(names(arrange(docs, "004", "NEWEST", None, body)) == ["scan_004.pdf"], "tài liệu không có bản OCR vẫn tìm được theo tên")
    good &= check(names(arrange(docs, "nguyen van an", "NEWEST", None, body)) == ["scan_001.pdf"], "gõ không dấu tìm ra tên riêng có dấu trong nội dung")
    good &= check(names(arrange(docs, "xyz", "NEWEST", None, body)) == [], "từ không có trong tên, thẻ, nội dung -> rỗng")
    good &= check(len(arrange(docs, "", "NEWEST", None, body)) == 4, "truy vấn trống: đủ 4 tài liệu dù có nội dung")
    good &= check(names(arrange(docs, "hop dong", "NEWEST", "Nhà", body)) == [], "lọc thẻ 'Nhà' + tìm nội dung: chỉ scan_002 có thẻ, mà nó không có 'Hợp đồng' -> rỗng")
    twins = [dict(name="x1.pdf", modified=1, size=1, fav=False), dict(name="x2.pdf", modified=1, size=1, fav=False)]
    good &= check(names(arrange(twins, "", "NEWEST")) == ["x1.pdf", "x2.pdf"], "bằng nhau: giữ thứ tự ban đầu")
    print("TAT CA DAT" if good else "CO LOI")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
