"""Thư viện dựng PDF CÓ CHỮ KÝ THẬT bằng tay (phiên 20), dùng chung cho signed_pdf_check.py và timestamp_check.py.

Cách làm giống `digital_signature_check.py` (cập nhật tăng dần + /ByteRange + /Contents dành sẵn, CMS do CmsCheck.java dựng bằng đúng thuật toán của
DerWriter.kt / CmsSigner.kt) nhưng tổng quát hơn: nhiều chữ ký nối tiếp, thứ tự khoá /Contents trước / sau /ByteRange, chứng nhận DocMDP (mức 1-3),
dấu thời gian tài liệu (DocTimeStamp), chỉnh sửa SAU khi ký, và đệm để đặt khoá /ByteRange đúng vào ranh giới khối quét.
Không phải mã của ứng dụng.
"""
import datetime, os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

HERE = os.path.dirname(os.path.abspath(__file__))
CAP = 6000   # byte dành cho khối chữ ký (CMS, có thể kèm dấu thời gian)


def make_cert(prefix, cn="Người ký thử DocScanner"):
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(int.from_bytes(os.urandom(8), "big") | (1 << 62)).not_valid_before(now - datetime.timedelta(days=1))
            .not_valid_after(now + datetime.timedelta(days=3650)).sign(key, hashes.SHA256()))
    open(prefix + ".pk8", "wb").write(key.private_bytes(serialization.Encoding.DER, serialization.PrivateFormat.PKCS8, serialization.NoEncryption()))
    open(prefix + ".der", "wb").write(cert.public_bytes(serialization.Encoding.DER))
    open(prefix + ".pem", "wb").write(cert.public_bytes(serialization.Encoding.PEM))
    return cert


def base_pdf(pad=0):
    """PDF 1 trang. `pad` = số byte dòng chú thích `%xxxx` chèn sau tiêu đề (để dịch mọi vị trí phía sau)."""
    objs = {1: b"<< /Type /Catalog /Pages 2 0 R >>",
            2: b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
            3: b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 200] /Contents 4 0 R /Resources << >> >>"}
    stream = b"0.9 0.2 0.2 rg 20 20 100 60 re f"
    objs[4] = b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream"
    out = bytearray(b"%PDF-1.7\n%\xe2\xe3\xcf\xd3\n")
    if pad:
        out += b"%" + b"x" * (pad - 2) + b"\n"
    offsets = {}
    for n in sorted(objs):
        offsets[n] = len(out)
        out += b"%d 0 obj\n" % n + objs[n] + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n0 5\n0000000000 65535 f \n"
    for n in range(1, 5):
        out += b"%010d 00000 n \n" % offsets[n]
    out += b"trailer\n<< /Size 5 /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % xref
    return bytes(out), xref


def append_update(pdf, prev_xref, objs, size):
    """Cập nhật tăng dần: ghi `objs` {số: thân} + bảng xref + trailer /Prev. Trả (pdf mới, xref mới, {số: offset})."""
    out = bytearray(pdf)
    offsets = {}
    for n in sorted(objs):
        offsets[n] = len(out)
        out += b"%d 0 obj\n" % n + objs[n] + b"\nendobj\n"
    xref = len(out)
    out += b"xref\n"
    for n in sorted(objs):
        out += b"%d 1\n%010d 00000 n \n" % (n, offsets[n])
    out += b"trailer\n<< /Size %d /Root 1 0 R /Prev %d >>\nstartxref\n%d\n%%%%EOF\n" % (size, prev_xref, xref)
    return bytes(out), xref, offsets


def edit_after(pdf, prev_xref, size, color=b"0.1 0.6 0.2"):
    """Một chỉnh sửa KHÔNG ký (đổi màu nội dung) nối thêm sau chữ ký cuối."""
    stream = color + b" rg 20 20 100 60 re f"
    body = b"<< /Length %d >>\nstream\n" % len(stream) + stream + b"\nendstream"
    new, xref, _ = append_update(pdf, prev_xref, {4: body}, size)
    return new, xref


class Chain:
    """Một PDF đang được ký nhiều lần. `add_signature` nối một chữ ký; trạng thái giữ trong self."""

    def __init__(self, pad=0):
        self.pdf, self.xref = base_pdf(pad)
        self.fields = []        # số object của các widget chữ ký
        self.size = 5
        self.last = None

    def _alloc(self):
        sig, widget = self.size, self.size + 1
        self.size += 2
        return sig, widget

    def add_signature(self, order="br_first", subfilter="adbe.pkcs7.detached", certify=0, doc_timestamp=False, cap=CAP):
        """Nối một chữ ký với /Contents toàn số 0; trả thông tin để điền khối chữ ký sau. order: br_first | contents_first."""
        sig, widget = self._alloc()
        self.fields.append(widget)
        hexzero = b"0" * (2 * cap)
        br = b"/ByteRange [0 0000000000 0000000000 0000000000]"
        ct = b"/Contents <" + hexzero + b">"
        parts = (br + b" " + ct) if order == "br_first" else (ct + b" " + br)
        typ = b"/Type /DocTimeStamp " if doc_timestamp else b"/Type /Sig "
        ref = b""
        if certify:
            ref = (b"/Reference [<< /Type /SigRef /TransformMethod /DocMDP /TransformParams << /Type /TransformParams /P %d /V /1.2 >> >>] " % certify)
        sub = (b"/SubFilter /ETSI.RFC3161" if doc_timestamp else b"/SubFilter /" + subfilter.encode())
        sigbody = b"<< " + typ + b"/Filter /Adobe.PPKLite " + sub + b" " + ref + parts + b" /M (D:20261021120000Z) /Name (Test Signer) >>"
        fields = b" ".join(b"%d 0 R" % f for f in self.fields)
        perms = (b" /Perms << /DocMDP %d 0 R >>" % sig) if certify else b""
        objs = {1: b"<< /Type /Catalog /Pages 2 0 R /AcroForm << /Fields [" + fields + b"] /SigFlags 3 >>" + perms + b" >>",
                3: b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 200 200] /Contents 4 0 R /Resources << >> /Annots [" + fields + b"] >>",
                sig: sigbody,
                widget: b"<< /Type /Annot /Subtype /Widget /FT /Sig /Rect [0 0 0 0] /V %d 0 R /T (Signature%d) /F 132 /P 3 0 R >>" % (sig, len(self.fields))}
        new, xref, _ = append_update(self.pdf, self.xref, objs, self.size)
        data = bytearray(new)
        lt = new.index(b"/Contents <", len(self.pdf)) + len(b"/Contents ")
        gt = lt + 1 + 2 * cap
        assert data[gt:gt + 1] == b">"
        a, b = lt, gt + 1
        c = b
        d = len(data) - c
        text = b"/ByteRange [0 %010d %010d %010d]" % (a, c, d)
        i = data.index(b"/ByteRange [0 0000000000", len(self.pdf))
        data[i:i + len(text)] = text
        self.pdf, self.xref = bytes(data), xref
        self.last = dict(lt=lt, gt=gt, a=a, b=b, c=c, d=d, cap=cap, br_pos=i)
        return self.last

    def signed_content(self):
        L = self.last
        return self.pdf[:L["lt"]] + self.pdf[L["gt"] + 1:]

    def fill(self, cms):
        L = self.last
        assert len(cms) <= L["cap"], f"CMS {len(cms)} B vượt chỗ dành sẵn {L['cap']} B"
        data = bytearray(self.pdf)
        data[L["lt"] + 1:L["gt"]] = cms.hex().upper().encode().ljust(2 * L["cap"], b"0")
        self.pdf = bytes(data)

    def edit(self, color=b"0.1 0.6 0.2"):
        self.pdf, self.xref = edit_after(self.pdf, self.xref, self.size, color)


def real_cms(chain, workdir, cert_prefix, name="content.bin"):
    """CMS thật của chữ ký vừa nối (CmsCheck.java = đúng thuật toán của CmsSigner.kt)."""
    cpath = os.path.join(workdir, name)
    open(cpath, "wb").write(chain.signed_content())
    out = os.path.join(workdir, name + ".sig.der")
    r = subprocess.run(["java", os.path.join(HERE, "CmsCheck.java"), cpath, cert_prefix + ".pk8", cert_prefix + ".der", out], capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout, r.stderr)
        raise SystemExit("CmsCheck.java thất bại")
    return open(out, "rb").read()


def pdfsig(path):
    r = subprocess.run(["pdfsig", path], capture_output=True, text=True)
    return r.stdout + r.stderr
