"""Kiểm chứng TrashStore + BulkRename (phiên 17): thùng rác và đổi tên hàng loạt.

TrashCheck.java là bản Java chạy được của hai lớp Kotlin; nó chạy trên THƯ MỤC THẬT (bài kiểm đọc lại bằng os.listdir, không tin lời báo của Java).
A - phần thuần: tách `<mili giây>__<tên>` (tên có "__", chữ Việt, thiếu phần nào thì bị từ chối), hạn 30 ngày (đúng 30 ngày = hết hạn, thiếu 1 ms = chưa,
    mốc trong TƯƠNG LAI không bao giờ hết hạn - đồng hồ chỉnh sai không được xoá thùng), số ngày còn lại.
B - tệp: bỏ PDF kèm `.txt` OCR vào thùng (cả hai cùng mốc, danh sách chỉ hiện PDF); khôi phục khi tên đã bị chiếm -> "a (2).pdf" + "a (2).txt";
    dọn hết hạn (kể cả tệp kèm; tệp lạ trong thùng KHÔNG bị đụng); dọn sạch; tệp không tồn tại; bỏ vào cùng mốc hai lần.
C - đổi tên: ca tay (độ rộng số 01..12, {name}, {date}, đụng tên, mẫu rỗng, giữ nguyên tên mình) + 2 000 ca ngẫu nhiên so với bản tham chiếu
    độc lập, và MÔ PHỎNG chạy đổi tên lần lượt trên hệ tệp ảo: không bao giờ đè lên tệp khác, đuôi tệp giữ nguyên, mọi tên mới khác nhau.
    THỬ ÂM TÍNH: một bản "chỉ kiểm tên trong danh sách chọn" (bỏ qua tệp khác trong thư mục) phải bị mô phỏng bắt là đè tệp.
Chạy: python3 trash_rename_check.py   (cần java 11+)
"""
import os, random, shutil, subprocess, sys, tempfile, unicodedata, datetime
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
HERE = os.path.dirname(os.path.abspath(__file__))
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
    return cond
DAY = 86_400_000
RETENTION_DAYS = 30   # phản chiếu TrashStore.RETENTION_DAYS (doc_sync_check so khớp)

def java(*args):
    r = subprocess.run(["java", os.path.join(HERE, "TrashCheck.java"), *map(str, args)], capture_output=True, text=True, check=True)
    return r.stdout.strip("\n").split("\n") if r.stdout.strip("\n") else []

print("== A. phần thuần ==")
def ref_parse(n):
    i = n.find("__")
    if i <= 0 or i + 2 >= len(n): return None
    d = n[:i]
    if len(d) > 18 or not d.isascii() or not d.isdigit(): return None
    return (int(d), n[i + 2:])
names = ["1700000000000__a.pdf", "1700000000000__Hợp đồng__v2.pdf", "__a.pdf", "1700__", "17x00__a.pdf", "1700000000000_a.pdf", "a.pdf", "0__x", "12345678901234567890__a.pdf",
         "1700000000000__", "-5__a.pdf", "١٢٣__a.pdf"]
f = os.path.join(OUT, "tr_pure.txt")
open(f, "w", encoding="utf-8").write("\n".join("parse\t" + n for n in names) + "\n")
got = java("pure", f)
for n, g in zip(names, got):
    r = ref_parse(n); exp = "NULL" if r is None else f"{r[0]}\t{r[1]}"
    check(g == exp, f"parse {n!r} -> {g!r}")
now = 1_800_000_000_000
cases = [(now - 30 * DAY, now, True), (now - 30 * DAY + 1, now, False), (now - 31 * DAY, now, True), (now + 5 * DAY, now, False), (now, now, False), (now - 29 * DAY - 86_399_999, now, False)]
LEFT_CASES = [(now, now), (now - DAY, now), (now - 29 * DAY - 1, now), (now - 30 * DAY, now), (now + 9 * DAY, now), (now - 15 * DAY - 5, now)]
def ref_left(a, b):
    left = RETENTION_DAYS * DAY - (b - a)
    return 0 if left <= 0 else min(RETENTION_DAYS, -(-left // DAY))
open(f, "w").write("\n".join(f"expired\t{a}\t{b}" for a, b, _ in cases) + "\n" + "\n".join(f"left\t{a}\t{b}" for a, b in LEFT_CASES) + "\n")
got = java("pure", f)
for (a, b, exp), g in zip(cases, got[:len(cases)]): check(g == str(exp).lower(), f"hết hạn? tuổi {(b - a) / DAY:.4f} ngày -> {g}")
left = [int(x) for x in got[len(cases):]]
check(left == [ref_left(a, b) for a, b in LEFT_CASES] and left == [30, 29, 1, 0, 30, 15], f"số ngày còn lại: {left}")

print("== B. thùng rác trên thư mục thật ==")
tmp = tempfile.mkdtemp(prefix="trash_"); T = os.path.join(tmp, "trash"); E = os.path.join(tmp, "export"); os.makedirs(E)
def touch(name, text="x"): open(os.path.join(E, name), "w").write(text)
touch("a.pdf", "PDFDATA"); touch("a.txt", "OCR"); touch("Hợp đồng.pdf"); touch("sach.epub"); touch("note.txt")
check(java("trash", T, os.path.join(E, "a.pdf"), 1000) == ["OK"], "bỏ a.pdf vào thùng")
check(sorted(os.listdir(E)) == sorted(["Hợp đồng.pdf", "sach.epub", "note.txt"]), "a.pdf VÀ a.txt (OCR kèm) đã rời thư mục xuất: " + str(sorted(os.listdir(E))))
check(sorted(os.listdir(T)) == ["1000__a.pdf", "1000__a.txt"], "thùng có hai tệp cùng mốc: " + str(sorted(os.listdir(T))))
check(java("list", T) == ["1000\ta.pdf"], "danh sách chỉ hiện PDF (tệp OCR kèm bị ẩn)")
check(java("trash", T, os.path.join(E, "sach.epub"), 2000) == ["OK"] and java("trash", T, os.path.join(E, "note.txt"), 3000) == ["OK"], "bỏ epub và một .txt đứng riêng (không phải tệp kèm của PDF nào)")
check(java("list", T) == ["3000\tnote.txt", "2000\tsach.epub", "1000\ta.pdf"], "danh sách theo thứ tự xoá mới nhất trước, .txt đứng riêng vẫn hiện: " + str(java("list", T)))
check(java("trash", T, os.path.join(E, "khong_co.pdf"), 4000) == ["FAIL"], "tệp không tồn tại -> FAIL, không tạo gì")
touch("a.pdf", "NEW"); touch("a.txt", "NEWOCR")      # tên cũ đã bị tệp mới chiếm
idx = [l.split("\t")[1] for l in java("list", T)].index("a.pdf")
r = java("restore", T, E, idx)
check(r == ["a (2).pdf"], f"khôi phục khi tên bị chiếm -> {r}")
check(sorted(os.listdir(E)) == sorted(["Hợp đồng.pdf", "a.pdf", "a.txt", "a (2).pdf", "a (2).txt"]), "tệp OCR kèm đi theo bản khôi phục dưới tên mới: " + str(sorted(os.listdir(E))))
check(open(os.path.join(E, "a.pdf")).read() == "NEW" and open(os.path.join(E, "a (2).pdf")).read() == "PDFDATA", "tệp mới không bị đè; bản khôi phục giữ nguyên nội dung")
check(java("list", T) == ["3000\tnote.txt", "2000\tsach.epub"] and sorted(os.listdir(T)) == ["2000__sach.epub", "3000__note.txt"], "thùng không còn gì của a.pdf")
# dọn hết hạn
open(os.path.join(T, "ghi_chu_la.txt"), "w").write("khong phai cua ta")
os.rename(os.path.join(T, "2000__sach.epub"), os.path.join(T, f"{now - 31 * DAY}__sach.epub"))
touch("b.pdf"); touch("b.txt"); java("trash", T, os.path.join(E, "b.pdf"), now - 31 * DAY)
touch("c.pdf"); java("trash", T, os.path.join(E, "c.pdf"), now - 29 * DAY - 86_000_000)
touch("d.pdf"); java("trash", T, os.path.join(E, "d.pdf"), now + 9 * DAY)
before = sorted(os.listdir(T))
n = int(java("purge", T, now)[0])
after = sorted(os.listdir(T))
gone = sorted(set(before) - set(after))
check(n == 4 and gone == sorted([f"{now - 31 * DAY}__sach.epub", f"{now - 31 * DAY}__b.pdf", f"{now - 31 * DAY}__b.txt", "3000__note.txt"]), f"dọn hết hạn: xoá {n} tệp (epub, b.pdf + tệp kèm b.txt, và note.txt mốc 3000 vốn đã quá cũ): {gone}")
check("ghi_chu_la.txt" in after and f"{now - 29 * DAY - 86_000_000}__c.pdf" in after and f"{now + 9 * DAY}__d.pdf" in after, "tệp lạ, tệp chưa hết hạn và tệp mốc tương lai KHÔNG bị xoá")
n = int(java("empty", T)[0]); rest = sorted(os.listdir(T))
check(rest == ["ghi_chu_la.txt"] and n == 2, f"dọn sạch xoá {n} tệp có mốc, để lại tệp lạ: {rest}")
open(os.path.join(E, "z.pdf"), "w").write("z"); java("trash", T, os.path.join(E, "z.pdf"), 7000)
open(os.path.join(E, "z.pdf"), "w").write("z2")
check(java("trash", T, os.path.join(E, "z.pdf"), 7000) == ["FAIL"] and open(os.path.join(E, "z.pdf")).read() == "z2", "cùng tên cùng mốc: từ chối, tệp ở lại thư mục xuất")
shutil.rmtree(tmp)


print("== B2. .meta: sao + thẻ đi cùng tệp vào thùng và về lại ==")
def hexs(x): return x.encode("utf-8").hex()
def meta_ref_decode(text):
    fav, tags = False, []
    for line in text.split("\n"):
        l = line.strip()
        if l == "fav=1": fav = True
        elif l.startswith("tag="):
            h = l[4:]
            try: t = bytes.fromhex(h).decode("utf-8") if h and len(h) % 2 == 0 and all(c in "0123456789abcdefABCDEF" for c in h) else None
            except Exception: t = None
            if t and t not in tags: tags.append(t)
    return fav, tags
rnd2 = random.Random(41)
ALPH = list("abc XYZ019_-.=") + ["\t", "\n", "\r", "ế", "Đ", "😀", "é", "\\", "="]
mcases = []
for _ in range(600):
    tags = ["".join(rnd2.choice(ALPH) for _ in range(rnd2.randint(1, 9))) for _ in range(rnd2.randint(0, 5))]
    mcases.append((rnd2.choice([True, False]), tags))
f = os.path.join(OUT, "tr_meta.txt")
open(f, "w", encoding="utf-8").write("\n".join(f"menc\t{1 if fv else 0}\t{','.join(hexs(t) for t in tg)}" for fv, tg in mcases) + "\n")
enc = java("pure", f)
exp_enc = ["".join(["fav=" + ("1" if fv else "0") + "\n"] + [f"tag={hexs(t)}\n" for t in tg]).encode().hex() for fv, tg in mcases]
check(enc == exp_enc, "mã hoá .meta: Java = chuỗi dựng độc lập (600 ca: tag có tab, xuống dòng, '=', emoji, chữ Việt)")
open(f, "w", encoding="utf-8").write("\n".join(f"mdec\t{e}" for e in enc) + "\n")
dec = java("pure", f); bad = 0
for (fv, tg), d in zip(mcases, dec):
    want_tags = list(dict.fromkeys(t for t in tg if t))
    got_fav, got_tags = d.split("|", 1); got_tags = [bytes.fromhex(h).decode("utf-8") for h in got_tags.split(",") if h]
    if (got_fav == "1") != fv or got_tags != want_tags: bad += 1
check(bad == 0, f"vòng đi-về: giải mã(mã hoá(sao, thẻ)) = nguyên bản, thẻ trùng gộp lại ({bad} lệch)")
junk = ["", "garbage", "fav=2", "tag=zz", "tag=", "tag=abc", "fav=1\r\ntag=" + hexs("x") + "\r\n", "  fav=1  \n tag=" + hexs("a b") + " \nfav=0", "tag=" + hexs("t") + "\ntag=" + hexs("t")]
open(f, "w", encoding="utf-8").write("\n".join(f"mdec\t{hexs(j)}" for j in junk) + "\n")
dj = java("pure", f)
for j, d in zip(junk, dj):
    rf, rt = meta_ref_decode(j); check(d == ("1" if rf else "0") + "|" + ",".join(hexs(t) for t in rt), f"giải mã dễ tính {j[:22]!r} -> {d[:30]!r}")
tmp2 = tempfile.mkdtemp(prefix="trash2_"); T2 = os.path.join(tmp2, "t"); E2 = os.path.join(tmp2, "e"); os.makedirs(E2)
def touch2(n, t="x"): open(os.path.join(E2, n), "w").write(t)
touch2("a.pdf", "PDF"); touch2("a.txt", "OCR"); touch2("b.epub"); touch2("c.pdf")
mf = os.path.join(OUT, "tr_meta_file.txt"); open(mf, "w", encoding="utf-8").write("fav=1\ntag=" + hexs("Hợp đồng") + "\n")
check(java("trashm", T2, os.path.join(E2, "a.pdf"), 5000, mf) == ["OK"] and java("trashm", T2, os.path.join(E2, "b.epub"), 6000, mf) == ["OK"] and java("trash", T2, os.path.join(E2, "c.pdf"), 7000) == ["OK"], "bỏ 3 tệp vào thùng (hai tệp có .meta)")
check(sorted(os.listdir(T2)) == ["5000__a.pdf", "5000__a.pdf.meta", "5000__a.txt", "6000__b.epub", "6000__b.epub.meta", "7000__c.pdf"], "thùng: tệp + .txt kèm + .meta cùng mốc: " + str(sorted(os.listdir(T2))))
check(java("list", T2) == ["7000\tc.pdf", "6000\tb.epub", "5000\ta.pdf"], "danh sách chỉ hiện tài liệu: .meta và .txt kèm đều bị ẩn")
idx = [l.split("\t")[1] for l in java("list", T2)].index("a.pdf")
check(java("readmeta", T2, idx) == ["fav=1|tag=" + hexs("Hợp đồng") + "|"], "đọc .meta trước khi khôi phục")
check(java("readmeta", T2, [l.split("\t")[1] for l in java("list", T2)].index("c.pdf")) == ["NONE"], "tệp không có .meta -> NONE")
check(java("restore", T2, E2, idx) == ["a.pdf"] and sorted(os.listdir(T2)) == ["6000__b.epub", "6000__b.epub.meta", "7000__c.pdf"], "khôi phục a.pdf: .meta và .txt đi cùng ra khỏi thùng (không để rác lại): " + str(sorted(os.listdir(T2))))
idx = [l.split("\t")[1] for l in java("list", T2)].index("b.epub"); java("forever", T2, idx)
check(sorted(os.listdir(T2)) == ["7000__c.pdf"], "xoá hẳn b.epub xoá cả .meta")
shutil.rmtree(tmp2)
open(os.path.join(OUT, "tr_meta_file2.txt"), "w").write("fav=0\n"); tmp3 = tempfile.mkdtemp(prefix="trash3_"); T3 = os.path.join(tmp3, "t"); E3 = os.path.join(tmp3, "e"); os.makedirs(E3)
open(os.path.join(E3, "z.pdf"), "w").write("z"); java("trashm", T3, os.path.join(E3, "z.pdf"), now - 40 * DAY, os.path.join(OUT, "tr_meta_file2.txt"))
check(int(java("purge", T3, now)[0]) == 2 and os.listdir(T3) == [], "dọn hết hạn xoá cả tệp lẫn .meta (2 tệp)")
shutil.rmtree(tmp3)

print("== C. đổi tên hàng loạt ==")
def fmt_date(ms): return datetime.datetime.fromtimestamp(ms / 1000, datetime.timezone.utc).strftime("%Y-%m-%d")
FORBID = set('\\/:*?"<>|\n\r\t')
def ref_sanitize(raw):
    s = "".join(" " if c in FORBID else c for c in raw)
    s = " ".join(s.split()); s = s.strip().strip(".").strip()
    s = s[:60].strip().strip(".").strip()
    return s
def ref_unique(blocked, base, ext):
    e = "." + ext if ext else ""; c = base + e; n = 2
    while blocked(c): c = f"{base} ({n}){e}"; n += 1
    return c
def ref_plan(items, pattern, start, taken):
    from collections import Counter
    existing = Counter(t.lower() for t in taken); assigned = set(); w = max(1, len(str(max(0, start + len(items) - 1)))); out = []
    for i, (name, mod) in enumerate(items):
        dot = name.rfind(".")
        ext, old = (name[dot + 1:], name[:dot]) if dot > 0 else ("", name)
        raw = pattern.replace("{n}", str(start + i).zfill(w)).replace("{name}", old).replace("{date}", fmt_date(mod))
        base = ref_sanitize(raw) or ref_sanitize(old) or "document"
        nn = ref_unique(lambda c, name=name: c.lower() in assigned or (existing[c.lower()] > 0 and c != name), base, ext)
        assigned.add(nn.lower())
        if nn != name: existing[name.lower()] -= 1
        out.append(nn)
    return out
def run_plans(cases):
    """Nhiều ca trong MỘT lần gọi Java (mỗi lần gọi phải biên dịch lại nên chậm)."""
    f = os.path.join(OUT, "tr_plan.txt")
    blocks = [pattern + "\n" + str(start) + "\n" + "\t".join(taken) + "\n" + "\n".join(f"{n}\t{m}" for n, m in items) for items, pattern, start, taken in cases]
    open(f, "w", encoding="utf-8").write("\n---\n".join(blocks) + "\n")
    out = java("plan", f)
    return [line.split("\t") for line in out]
def run_plan(items, pattern, start, taken): return run_plans([(items, pattern, start, taken)])[0]
D0 = 1_760_000_000_000   # 2025-10-09 UTC
three = [("a.pdf", D0), ("b.pdf", D0 + DAY), ("c.PDF", D0 + 2 * DAY)]
check(run_plan(three, "Scan_{n}", 1, [n for n, _ in three]) == ["Scan_1.pdf", "Scan_2.pdf", "Scan_3.PDF"], "Scan_{n}: 1..3 (đuôi giữ nguyên chữ hoa/thường)")
twelve = [(f"f{i}.pdf", D0) for i in range(12)]
check(run_plan(twelve, "Trang {n}", 1, [n for n, _ in twelve])[0] == "Trang 01.pdf" and run_plan(twelve, "Trang {n}", 1, [n for n, _ in twelve])[11] == "Trang 12.pdf", "12 tệp: 01..12 (xếp đúng thứ tự khi sắp theo tên)")
check(run_plan(three, "{date}_{name}", 1, [n for n, _ in three]) == ["2025-10-09_a.pdf", "2025-10-10_b.pdf", "2025-10-11_c.PDF"], "{date}_{name}")
check(run_plan(three, "Scan_{n}", 1, [n for n, _ in three] + ["Scan_1.pdf", "scan_2.PDF"])[:2] == ["Scan_1 (2).pdf", "Scan_2 (2).pdf"], "đụng tên tệp có sẵn (không phân biệt hoa/thường) -> (2)")
check(run_plan(three, "{name}", 1, [n for n, _ in three]) == ["a.pdf", "b.pdf", "c.PDF"], "mẫu {name}: giữ nguyên, không thêm (2)")
check(run_plan(three, "///", 1, [n for n, _ in three]) == ["a.pdf", "b.pdf", "c.PDF"], "mẫu chỉ có ký tự cấm -> giữ tên cũ")
check(run_plan([("x.pdf", D0), ("y.pdf", D0)], "y", 1, ["x.pdf", "y.pdf"]) == ["y (2).pdf", "y.pdf"], "tên cũ của tệp SAU vẫn bị giữ chỗ -> không đè")
check(run_plan([("só 1.pdf", D0)], "{name} - {n}", 7, ["só 1.pdf"]) == ["só 1 - 7.pdf"], "bắt đầu từ 7, chữ Việt")
check(run_plan([("a", D0)], "{foo}{n}", 1, ["a"]) == ["{foo}1"], "token lạ {foo} giữ nguyên như đã gõ")

def simulate(items, new_names, taken):
    fs = {t.lower() for t in taken}; seen = set()
    for (old, _), new in zip(items, new_names):
        if new.lower() != old.lower() and new.lower() in fs: return f"ĐÈ: {old} -> {new}"
        if new.lower() in seen: return f"TRÙNG: {new}"
        seen.add(new.lower()); fs.discard(old.lower()); fs.add(new.lower())
        if old.rsplit(".", 1)[-1] != new.rsplit(".", 1)[-1] and "." in old: return f"MẤT ĐUÔI: {old} -> {new}"
    return None
rnd = random.Random(5)
POOL = ["a", "b", "Hợp đồng", "scan", "Scan_1", "Scan_2", "x y", "tài liệu", "1", "02", "y", "x"]
EXTS = ["pdf", "PDF", "epub", "txt", ""]
PATS = ["{name}_{n}", "Scan_{n}", "{date} {name}", "{n}", "y", "x", "{name}", "", "a/b:{n}", "{name}" * 11, "{n} - {date}"]
batch = []
for k in range(2000):
    items = []
    for _ in range(rnd.randint(1, 14)):
        nm = rnd.choice(POOL) + ("." + e if (e := rnd.choice(EXTS)) else "")
        if nm in [i[0] for i in items]: nm = f"{rnd.choice(POOL)}{rnd.randint(1, 9)}.pdf"
        if nm in [i[0] for i in items]: continue
        items.append((nm, D0 + rnd.randint(0, 400) * DAY))
    taken = [i[0] for i in items] + [rnd.choice(POOL) + "." + rnd.choice(["pdf", "txt"]) for _ in range(rnd.randint(0, 6))] + ["Scan_1.pdf", "y.pdf"][:rnd.randint(0, 2)]
    batch.append((items, rnd.choice(PATS), rnd.choice([1, 1, 5, 99]), list(dict.fromkeys(taken))))
gots = run_plans(batch)
bad = []; bad_sim = []; checked = len(batch)
for (items, pat, start, taken), got in zip(batch, gots):
    exp = ref_plan(items, pat, start, taken)
    if got != exp: bad.append((items, pat, start, taken, got, exp))
    s_ = simulate(items, got, taken)
    if s_: bad_sim.append((s_, pat))
check(not bad, f"{checked} ca ngẫu nhiên: bản Java = bản tham chiếu độc lập ({len(bad)} lệch)")
check(not bad_sim, f"mô phỏng đổi tên lần lượt trên hệ tệp ảo: không đè, không trùng, giữ đuôi ({len(bad_sim)} lỗi) {bad_sim[:2]}")
# thử âm tính: chỉ kiểm tên trong danh sách chọn
def naive_plan(items, pattern, start, taken):
    selected = {n.lower() for n, _ in items}; used = set(); out = []
    w = max(1, len(str(max(0, start + len(items) - 1))))
    for i, (name, mod) in enumerate(items):
        dot = name.rfind("."); ext, old = (name[dot + 1:], name[:dot]) if dot > 0 else ("", name)
        base = ref_sanitize(pattern.replace("{n}", str(start + i).zfill(w)).replace("{name}", old).replace("{date}", fmt_date(mod))) or old
        nn = ref_unique(lambda c: c.lower() in used, base, ext); used.add(nn.lower()); out.append(nn)
    return out
caught = 0
for items, pat, start, taken in batch[:600]:
    if simulate(items, naive_plan(items, pat, start, taken), taken): caught += 1
check(caught > 0, f"thử âm tính: cách chỉ kiểm tên trong danh sách chọn làm ĐÈ tệp ở {caught} ca - mô phỏng bắt được")
print()
print("TAT CA DAT" if not FAILS else f"CO {len(FAILS)} LOI: " + "; ".join(FAILS[:6]))
sys.exit(1 if FAILS else 0)
