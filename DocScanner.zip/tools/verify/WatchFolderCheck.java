import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Ban Java chay duoc cua WatchFolder (phien 18). Chay: java WatchFolderCheck.java pick <tep> | remember <tep>. */
public class WatchFolderCheck {
    static final Set<String> IMAGE_EXT = new HashSet<>(Arrays.asList("jpg", "jpeg", "png", "webp", "heic", "heif", "bmp", "gif"));
    static final String[] TEMP = {".tmp", ".part", ".crdownload", ".pending", ".download"};
    record Entry(String id, String name, String mime, long modified, long size) { }
    static String kindOf(Entry e) {
        String name = e.name().toLowerCase(Locale.ROOT);
        if (name.startsWith(".") || name.startsWith(".trashed")) return null;
        for (String t : TEMP) if (name.endsWith(t)) return null;
        int dot = name.lastIndexOf('.'); String ext = dot < 0 ? "" : name.substring(dot + 1); String mime = e.mime().toLowerCase(Locale.ROOT);
        if (mime.equals("application/pdf") || ext.equals("pdf")) return "PDF";
        if (mime.startsWith("image/") || IMAGE_EXT.contains(ext)) return (mime.startsWith("image/") || mime.equals("application/octet-stream") || mime.isEmpty()) ? "IMAGE" : null;
        return null;
    }
    static boolean isDigit(char c) { return c >= '0' && c <= '9'; }
    static int natural(String a, String b) {
        int i = 0, j = 0;
        while (i < a.length() && j < b.length()) {
            boolean da = isDigit(a.charAt(i)), db = isDigit(b.charAt(j)); int ie = i, je = j;
            while (ie < a.length() && isDigit(a.charAt(ie)) == da) ie++; while (je < b.length() && isDigit(b.charAt(je)) == db) je++;
            String ta = a.substring(i, ie), tb = b.substring(j, je);
            if (da != db) return da ? -1 : 1;
            int c; if (da) { String na = ta.replaceFirst("^0+(?=.)", ""), nb = tb.replaceFirst("^0+(?=.)", ""); c = na.length() != nb.length() ? Integer.compare(na.length(), nb.length()) : na.compareTo(nb); }
            else c = ta.toLowerCase(Locale.ROOT).compareTo(tb.toLowerCase(Locale.ROOT));
            if (c != 0) return c; i = ie; j = je;
        }
        int rest = Integer.compare(a.length() - i, b.length() - j); if (rest != 0) return rest; return a.compareTo(b);
    }
    static List<String> pickCase(List<String> lines) {
        String[] h = lines.get(0).split(" "); long now = Long.parseLong(h[0]), settle = Long.parseLong(h[1]);
        Set<String> seen = new HashSet<>(); if (!lines.get(1).isEmpty()) seen.addAll(Arrays.asList(lines.get(1).split("\\|")));
        List<Entry> es = new ArrayList<>();
        for (int i = 2; i < lines.size(); i++) { String[] t = lines.get(i).split("\t", -1); es.add(new Entry(t[0], t[1], t[2], Long.parseLong(t[3]), Long.parseLong(t[4]))); }
        List<Entry> out = new ArrayList<>(); for (Entry e : es) if (!seen.contains(e.id()) && kindOf(e) != null && e.size() > 0 && now - e.modified() >= settle) out.add(e);
        out.sort((x, y) -> x.modified() != y.modified() ? Long.compare(x.modified(), y.modified()) : natural(x.name(), y.name()));
        List<String> r = new ArrayList<>(); for (Entry e : out) r.add(e.id() + "\t" + kindOf(e)); return r;
    }
    static String rememberCase(List<String> lines) {
        int cap = Integer.parseInt(lines.get(0)); LinkedHashSet<String> all = new LinkedHashSet<>();
        if (!lines.get(1).isEmpty()) all.addAll(Arrays.asList(lines.get(1).split("\\|"))); if (lines.size() > 2 && !lines.get(2).isEmpty()) all.addAll(Arrays.asList(lines.get(2).split("\\|")));
        List<String> l = new ArrayList<>(all); if (l.size() > cap) l = l.subList(l.size() - cap, l.size()); return String.join("|", l);
    }
    public static void main(String[] a) throws Exception {
        List<String> lines = Files.readAllLines(Paths.get(a[1]), StandardCharsets.UTF_8);
        boolean batch = a[0].endsWith("-batch"); boolean pick = a[0].startsWith("pick");
        List<List<String>> cases = new ArrayList<>(); List<String> cur = new ArrayList<>();
        if (!batch) cases.add(lines); else { for (String l : lines) { if (l.equals("===")) { cases.add(cur); cur = new ArrayList<>(); } else cur.add(l); } }
        for (List<String> c : cases) { if (pick) for (String s : pickCase(c)) System.out.println(s); else System.out.println(rememberCase(c)); if (batch) System.out.println("==="); }
    }
}
