"""Kiểm chứng các bộ xuất định dạng (phiên 16, mục 4.30): TableExtractor (bảng từ hộp chữ OCR), XlsxWriter, PptxWriter, TextExporters (HTML, Markdown).

ExportCheck.java là bản Java chạy được, viết lại từng dòng từ Kotlin. Đáp án KHÔNG lấy từ chính mã đó:
- Bảng: DỰNG từ một lưới đã biết (số cột 2-6, số hàng 3-14, ô 1-3 từ, căn trái/phải, ô trống, nhiễu dọc +-2 px, nghiêng trang 0,3 độ, dòng tiêu đề dài) rồi so từng ô; trang chỉ có
  văn xuôi phải ra 1 cột.
- XLSX: đọc lại bằng openpyxl (giá trị, kiểu ô, tên sheet) và bằng LibreOffice (đổi sang CSV); số có số 0 đầu / số dài / "1.234" phải giữ nguyên là chữ; tên sheet theo luật của Excel.
- PPTX: mở bằng python-pptx (kích thước trang chiếu, vị trí/kích thước ảnh, nội dung ảnh, alt text), đổi sang PDF bằng LibreOffice (đúng số trang, có ảnh).
- HTML: đọc bằng html.parser và pandoc: chữ mọi trang còn nguyên, không chèn thẻ lạ. Markdown: đọc bằng pandoc (commonmark): chỉ ra tiêu đề / đoạn văn / đường kẻ giữa trang - không có danh sách,
  trích dẫn, mã, bảng ngoài ý muốn; chữ mỗi trang bằng chữ đưa vào.
- 8 ĐỘT BIẾN cố ý làm hỏng bản Java (khe cột quá lớn, dung sai hàng quá lớn, ranh giới đặt giữa khe, không cắt khoảng trống ngoài bảng, số 0 đầu thành số, bỏ escape đầu đoạn Markdown, bỏ escape HTML, kéo giãn ảnh)
  - mỗi cái phải làm bài kiểm tương ứng đỏ.
Chạy: python3 export_check.py   (cần java 11+, openpyxl, python-pptx, pandoc, LibreOffice, Pillow, poppler)
"""
import glob, html.parser, json, math, os, random, re, shutil, subprocess, sys, tempfile, unicodedata, zipfile
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
HERE = os.path.dirname(os.path.abspath(__file__))
JAVA = os.path.join(HERE, "ExportCheck.java")
FAILS = []
def check(cond, what, quiet=False):
    if not quiet: print(("ok  " if cond else "LOI"), what)
    if not cond and not quiet: FAILS.append(what)
    return cond

def java(java_path, *args):
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", java_path, *map(str, args)], capture_output=True, text=True)
    if r.returncode != 0: sys.exit("Java lỗi:\n" + r.stdout + r.stderr)

def enc(s):
    out = []
    for ch in s:
        o = ord(ch)
        if ch == "\\": out.append("\\\\")
        elif ch == "\n": out.append("\\n")
        elif 0x20 <= o < 0x7F: out.append(ch)
        else:
            b = ch.encode("utf-16-be", "surrogatepass")
            for i in range(0, len(b), 2): out.append("\\u%02x%02x" % (b[i], b[i + 1]))
    return "".join(out)
def is_xml_char(cp): return cp in (9, 10, 13) or 0x20 <= cp <= 0xD7FF or 0xE000 <= cp <= 0xFFFD or 0x10000 <= cp <= 0x10FFFF
def clean(s): return "".join(c for c in s if is_xml_char(ord(c)))
def norm(s): return " ".join(s.split())

# ======================================================================= 1. TableExtractor
H, CHAR_W, SPACE_W = 22.0, 10.0, 5.0
LETTERS = "abcdefghijklmnopqrstuvwxyzàáảãạăâđêôơưÀÁĐÊÔ"
def rand_word(rng): return "".join(rng.choice(LETTERS) for _ in range(rng.randint(2, 9)))
def layout_cell(words, x_left, x_right, align, top):
    """Đặt các từ của một ô trong [x_left, x_right]; trả danh sách (L,T,R,B,chữ)."""
    widths = [len(w) * CHAR_W for w in words]
    total = sum(widths) + SPACE_W * (len(words) - 1)
    x = x_left if align == "L" else x_right - total
    out = []
    for w, wd in zip(words, widths):
        out.append((x, top, x + wd, top + H, w)); x += wd + SPACE_W
    return out

def make_table(rng, skew=0.0, nrows=None):
    ncols, nrows = rng.randint(2, 6), (nrows or rng.randint(3, 14))
    aligns = [rng.choice("LR") for _ in range(ncols)]
    cells = [[[rand_word(rng) for _ in range(rng.randint(1, 3))] if rng.random() > 0.1 else [] for _ in range(ncols)] for _ in range(nrows)]
    cells[0] = [[rand_word(rng) for _ in range(rng.randint(1, 2))] for _ in range(ncols)]            # tiêu đề: đủ mọi cột
    # một hàng toàn ô trống không để lại chữ nào cho OCR thấy, và cần >= 2 hàng nhiều ô thì mới nhận ra là bảng
    for r in range(1, nrows):
        if not any(cells[r]): cells[r][rng.randrange(ncols)] = [rand_word(rng)]
    if sum(1 for r in range(nrows) if sum(1 for c in cells[r] if c) >= 2) < 2:
        for c in range(ncols): cells[1][c] = cells[1][c] or [rand_word(rng)]
    for c in range(ncols):
        if not any(cells[r][c] for r in range(nrows)): cells[0][c] = [rand_word(rng)]
    def wid(ws): return sum(len(w) * CHAR_W for w in ws) + SPACE_W * max(0, len(ws) - 1)
    colw = [max(wid(cells[r][c]) for r in range(nrows)) for c in range(ncols)]
    x0 = rng.uniform(40, 120)
    lefts, x = [], x0
    for c in range(ncols):
        lefts.append(x); x += colw[c] + rng.uniform(30, 70)
    words, expected = [], []
    top = rng.uniform(60, 120)
    title = None
    if rng.random() < 0.5:
        title = [rand_word(rng) for _ in range(rng.randint(3, 6))]
        for (l, t, r, b, w) in layout_cell(title, x0, x0 + 10000, "L", top): words.append((l, t, r, b, w))
        expected.append([" ".join(title)] + [""] * (ncols - 1)); top += 60
    for r in range(nrows):
        row_exp = []
        for c in range(ncols):
            ws = cells[r][c]; row_exp.append(" ".join(ws))
            for (l, t, rr, b, w) in layout_cell(ws, lefts[c], lefts[c] + colw[c], aligns[c], top + rng.uniform(-2, 2)): words.append((l, t, rr, b, w))
        expected.append(row_exp); top += 36 + rng.uniform(-1, 1)
    if skew:
        words = [(l, t + l * skew, r, b + l * skew, w) for (l, t, r, b, w) in words]
    rng.shuffle(words)
    return words, expected

def make_prose(rng, nlines):
    words, expected, top = [], [], 80.0
    for _ in range(nlines):
        ws = [rand_word(rng) for _ in range(rng.randint(6, 12))]
        for (l, t, r, b, w) in layout_cell(ws, 60, 60 + 5000, "L", top): words.append((l, t, r, b, w))
        expected.append([" ".join(ws)]); top += 32
    return words, expected

def run_tables(java_path, tables, tag):
    cin, cout = os.path.join(OUT, f"ex_{tag}.in"), os.path.join(OUT, f"ex_{tag}.out")
    with open(cin, "w", encoding="utf-8") as f:
        for words, _ in tables:
            for (l, t, r, b, w) in words: f.write(f"{l:.3f} {t:.3f} {r:.3f} {b:.3f} {w}\n")
            f.write("===\n")
    java(java_path, "table", cin, cout)
    res, cur = [], []
    for line in open(cout, encoding="utf-8").read().split("\n"):
        if line == "===": res.append(cur); cur = []
        elif line != "": cur.append(line.split("\u001f"))
    return res[:len(tables)]

def table_suite(java_path, quiet=False):
    rng = random.Random(1630)
    ok_all = True
    tables = [make_table(rng) for _ in range(400)]
    res = run_tables(java_path, tables, "t")
    bad = [i for i, ((w, e), g) in enumerate(zip(tables, res)) if g != e]
    ok_all &= check(not bad, f"bảng: 400 bảng dựng từ lưới đã biết (2-6 cột, 3-14 hàng, căn trái/phải, ô trống, nhiễu +-2 px, tiêu đề dài): khớp từng ô" + (f" — sai {len(bad)}/400, vd #{bad[0]}: mong đợi {tables[bad[0]][1][:3]} được {res[bad[0]][:3]}" if bad else ""), quiet)
    skewed = [make_table(rng, skew=math.tan(math.radians(0.3))) for _ in range(150)]
    res = run_tables(java_path, skewed, "s")
    bad = [i for i, ((w, e), g) in enumerate(zip(skewed, res)) if g != e]
    ok_all &= check(not bad, "bảng: 150 bảng nghiêng 0,3 độ vẫn khớp từng ô" + (f" — sai {len(bad)}/150" if bad else ""), quiet)
    prose = [make_prose(rng, rng.randint(3, 20)) for _ in range(100)]
    res = run_tables(java_path, prose, "p")
    bad = [i for i, ((w, e), g) in enumerate(zip(prose, res)) if g != e]
    ok_all &= check(not bad, "văn xuôi (không bảng): 100 trang ra đúng 1 cột, mỗi dòng một hàng" + (f" — sai {len(bad)}/100" if bad else ""), quiet)
    # đoạn văn xuôi phía trên bảng
    mixed = []
    for _ in range(100):
        pw, pe = make_prose(rng, rng.randint(1, 4))
        tw, te = make_table(rng)
        # dịch bảng xuống dưới phần văn xuôi
        dy = 80 + 32 * len(pe) + 40
        tw = [(l, t + dy, r, b + dy, w) for (l, t, r, b, w) in tw]
        ncols = len(te[0]); mixed.append((pw + tw, [row + [""] * (ncols - 1) for row in pe] + te))
    res = run_tables(java_path, mixed, "m")
    bad = [i for i, ((w, e), g) in enumerate(zip(mixed, res)) if g != e]
    ok_all &= check(not bad, "văn xuôi phía trên + bảng: các dòng văn xuôi vào cột đầu, bảng vẫn đúng" + (f" — sai {len(bad)}/100" if bad else ""), quiet)
    # một từ lạc nằm xa bên phải ngoài bảng (chỉ 1 hàng): không được sinh cột thừa
    w, e = make_table(rng, nrows=25); w = [x for x in w]            # 25 hàng: dung sai = 2 hàng (với bảng nhỏ, một cột chỉ có 1 ô là cột thật)
    nc = len(e[0]) if e else 0
    right = max(x[2] for x in w) + 120
    ytop = max(x[1] for x in w if x[4] == e[-1][0] or True)
    ys_sorted = sorted({round(x[1], 1) for x in w}); stray_row_top = ys_sorted[len(ys_sorted) // 2]
    w2 = w + [(right, stray_row_top, right + 40, stray_row_top + H, "zz")]
    res = run_tables(java_path, [(w2, None)], "st")[0]
    cols = {len(r) for r in res}
    ok_all &= check(cols == {nc}, f"từ lạc xa bên phải (1 hàng): vẫn {nc} cột, không sinh cột thừa (được {sorted(cols)})", quiet)
    return ok_all

# ======================================================================= 2. XlsxWriter
def xlsx_misc_suite(java_path, quiet=False):
    import openpyxl
    from openpyxl.utils import get_column_letter
    ok_all = True
    nums = ["0", "7", "-7", "-0", "00", "012", "0912345678", "079185012345", "123456789012345", "1234567890123456", "1.234", "1,5", "-", "", " 42 ", "+5", "1e5", "١٢٣", "99999999999999999"]
    inp = os.path.join(OUT, "ex_misc.in"); outp = os.path.join(OUT, "ex_misc.out")
    with open(inp, "w", encoding="utf-8") as f:
        for n in nums: f.write("num\t" + enc(n) + "\n")
        for i in list(range(0, 80)) + [100, 255, 256, 676, 701, 702, 703, 1000, 2000, 16383]: f.write(f"col\t{i}\n")
    java(java_path, "misc", inp, outp)
    got = open(outp, encoding="utf-8").read().split("\n")
    def ref_num(t):
        t = t.strip()
        return str(int(t)) if re.fullmatch(r"-?(0|[1-9][0-9]{0,14})", t, flags=re.A) and t != "-0" else "text"
    bad = [(n, g, ref_num(n)) for n, g in zip(nums, got) if g != ref_num(n)]
    ok_all &= check(not bad, "asNumber: chỉ số nguyên thường (không số 0 đầu, <= 15 chữ số) thành số; mã, số dài, '1.234', '1,5' giữ nguyên là chữ" + (f" — sai {bad[:3]}" if bad else ""), quiet)
    cols = list(range(0, 80)) + [100, 255, 256, 676, 701, 702, 703, 1000, 2000, 16383]
    gotc = got[len(nums):len(nums) + len(cols)]
    bad = [(i, g, get_column_letter(i + 1)) for i, g in zip(cols, gotc) if g != get_column_letter(i + 1)]
    ok_all &= check(not bad, f"columnName: {len(cols)} chỉ số (0 -> A ... 16383 -> XFD) khớp openpyxl.get_column_letter" + (f" — sai {bad[:2]}" if bad else ""), quiet)
    return ok_all

def sheet_name_suite(java_path, quiet=False):
    rng = random.Random(1631)
    cases = []
    pool = ["Trang 1", "Trang 1", "a:b/c", "[x]*?", "'quote'", "x" * 40, "Hóa đơn tháng 9", "", "   ", "'''", "Sheet", "sheet", "História", "A" * 31, "A" * 31]
    for _ in range(600):
        name = rng.choice(pool) if rng.random() < 0.6 else "".join(rng.choice("abcXYZ []:*?/\\' 12é") for _ in range(rng.randint(0, 45)))
        taken = [rng.choice(pool) for _ in range(rng.randint(0, 4))]
        cases.append((name, taken))
    inp, outp = os.path.join(OUT, "ex_sheet.in"), os.path.join(OUT, "ex_sheet.out")
    with open(inp, "w", encoding="utf-8") as f:
        for name, taken in cases: f.write("sheet\t" + enc(name) + "\t" + "|".join(enc(t) for t in taken) + "\n")
    java(java_path, "misc", inp, outp)
    got = open(outp, encoding="utf-8").read().split("\n")[:len(cases)]
    bad = []
    for (name, taken), g in zip(cases, got):
        legal = 1 <= len(g) <= 31 and not re.search(r"[\[\]:*?/\\]", g) and not g.startswith("'") and not g.endswith("'") and g == g.strip()
        unique = g.lower() not in {t.lower() for t in taken}
        if not (legal and unique): bad.append((name, taken, g, legal, unique))
    return check(not bad, "safeSheetName: 600 tên ngẫu nhiên — luôn hợp lệ theo luật Excel (1-31 ký tự, không [ ] : * ? / \\, không bắt đầu/kết thúc bằng '), không trùng tên đã có (không phân biệt hoa/thường)" + (f" — sai {bad[:2]}" if bad else ""), quiet)

def xlsx_e2e_suite(java_path, quiet=False):
    import openpyxl
    ok_all = True
    sheets = [
        ("Trang 1", [["Họ tên", "Số tiền", "Mã", "Ghi chú"], ["Nguyễn Văn An", "1500000", "0912345678", "a & b < c > d \"q\" 'x'"], ["Trần Thị Bích", "-42", "079185012345", "=SUM(A1:A2)"],
                     ["", "1.234", "", "dòng\nhai"], ["Tổng", "0", "00123", "x" * 200]]),
        ("Trang 1", [["trùng tên sheet"]]),
        ("a:b/c*?[x]", [["", "", "chỉ ô thứ 3"], [], ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12"]]),
    ]
    inp, outp = os.path.join(OUT, "ex_xlsx.in"), os.path.join(OUT, "ex_x.xlsx")
    with open(inp, "w", encoding="utf-8") as f:
        for name, rows in sheets:
            f.write("SHEET\t" + enc(name) + "\n")
            for r in rows: f.write("ROW\t" + "\t".join(enc(c) for c in r) + "\n")
    java(java_path, "xlsx", inp, outp)
    wb = openpyxl.load_workbook(outp)
    names = wb.sheetnames
    ok_all &= check(len(names) == 3 and len({n.lower() for n in names}) == 3 and all(1 <= len(n) <= 31 and not re.search(r"[\[\]:*?/\\]", n) for n in names), f"xlsx: 3 sheet, tên hợp lệ và không trùng: {names}", quiet)
    bad = []
    for (name, rows), ws in zip(sheets, wb.worksheets):
        for r, row in enumerate(rows, 1):
            for c, text in enumerate(row, 1):
                v = ws.cell(row=r, column=c).value
                is_num = re.fullmatch(r"-?(0|[1-9][0-9]{0,14})", text.strip()) and text.strip() != "-0"
                if text == "":
                    if v not in (None, ""): bad.append((r, c, "ô trống mà có giá trị", v))
                elif is_num:
                    if not (isinstance(v, int) and v == int(text)): bad.append((r, c, "phải là số", text, v))
                else:
                    if v != text: bad.append((r, c, "phải là chữ nguyên văn", text[:20], v if not isinstance(v, str) else v[:20]))
                    elif ws.cell(row=r, column=c).data_type == "f": bad.append((r, c, "chữ bắt đầu bằng = bị đọc là CÔNG THỨC", text))
    ok_all &= check(not bad, "xlsx: mọi ô đọc lại bằng openpyxl đúng giá trị và kiểu (số nguyên là số; mã 0912345678, 079185012345, 00123, '1.234' là chữ; '=SUM(...)' KHÔNG thành công thức; & < > \" ' và xuống dòng nguyên vẹn)" + (f" — sai {bad[:3]}" if bad else ""), quiet)
    widths = [ws.column_dimensions[c].width for ws in wb.worksheets[:1] for c in "ABCD"]
    ok_all &= check(all(w and 8 <= w <= 62 for w in widths), f"xlsx: độ rộng cột được đặt theo nội dung, trong 8-62 (có {widths})", quiet)
    # LibreOffice đọc độc lập
    d = tempfile.mkdtemp()
    r = subprocess.run(["soffice", "--headless", "--convert-to", "csv", "--outdir", d, outp], capture_output=True, text=True, timeout=120)
    csvs = glob.glob(os.path.join(d, "*.csv"))
    if csvs:
        import csv
        rows = list(csv.reader(open(csvs[0], encoding="utf-8")))
        row2 = rows[1] if len(rows) > 1 else []
        ok_all &= check(row2[:3] == ["Nguyễn Văn An", "1500000", "0912345678"], f"xlsx: LibreOffice đọc dòng 2 = {row2[:3]}", quiet)
    else:
        ok_all &= check(False, "xlsx: LibreOffice không mở được tệp: " + (r.stderr or r.stdout)[:150], quiet)
    shutil.rmtree(d, ignore_errors=True)
    return ok_all

# ======================================================================= 3. PptxWriter
def pptx_suite(java_path, quiet=False):
    from PIL import Image
    from pptx import Presentation
    ok_all = True
    specs = [(600, 800, "Trang 1 — hóa đơn \"A\" & <B>"), (800, 600, "Trang 2"), (500, 500, "")]
    paths, args = [], []
    for i, (w, h, alt) in enumerate(specs):
        p = os.path.join(OUT, f"ex_img{i}.jpg")
        img = Image.new("RGB", (w, h), (255, 255, 255 - 40 * i))
        for k in range(0, min(w, h), 25): img.putpixel((k, k), (0, 0, 0))
        img.save(p, "JPEG", quality=85); paths.append(p); args.append(f"{p},{w},{h},{alt}")
    outp = os.path.join(OUT, "ex_p.pptx")
    java(java_path, "pptx", outp, *args)
    prs = Presentation(outp)
    cx0, cy0 = (12192000, 12192000 * 800 // 600 if False else None)
    sx, sy = prs.slide_width, prs.slide_height
    exp_cx, exp_cy = 12192000 * 600 // 800, 12192000                      # trang đầu dọc 600x800: cạnh dài = 12 192 000
    ok_all &= check((sx, sy) == (exp_cx, exp_cy), f"pptx: kích thước trang chiếu theo ảnh đầu (dọc): {(sx, sy)} = {(exp_cx, exp_cy)}", quiet)
    ok_all &= check(len(prs.slides) == 3, f"pptx: python-pptx mở được và thấy {len(prs.slides)} trang chiếu", quiet)
    bad = []
    for i, (slide, (w, h, alt)) in enumerate(zip(prs.slides, specs)):
        pics = [s for s in slide.shapes if s.shape_type == 13]
        if len(pics) != 1: bad.append((i, "số ảnh", len(pics))); continue
        pic = pics[0]
        # ảnh phải vừa trong trang chiếu, giữ tỉ lệ, căn giữa
        if not (pic.left >= 0 and pic.top >= 0 and pic.left + pic.width <= sx and pic.top + pic.height <= sy): bad.append((i, "ra ngoài trang chiếu"))
        if abs(pic.width / pic.height - w / h) > 0.001: bad.append((i, "sai tỉ lệ", pic.width, pic.height))
        if not (abs((pic.left * 2 + pic.width) - sx) <= 2 and abs((pic.top * 2 + pic.height) - sy) <= 2): bad.append((i, "không căn giữa"))
        if not (pic.width >= sx - 2 or pic.height >= sy - 2): bad.append((i, "không chạm cạnh trang chiếu nào"))
        if pic.image.blob != open(paths[i], "rb").read(): bad.append((i, "nội dung ảnh khác"))
        descr = pic._element.nvPicPr.cNvPr.get("descr")
        if descr != alt: bad.append((i, "alt text", descr, alt))
    ok_all &= check(not bad, "pptx: mỗi trang chiếu đúng 1 ảnh — vừa khung, giữ tỉ lệ, căn giữa, chạm cạnh, nội dung ảnh nguyên vẹn, alt text đúng (kể cả & < > \")" + (f" — sai {bad[:3]}" if bad else ""), quiet)
    d = tempfile.mkdtemp()
    r = subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", d, outp], capture_output=True, text=True, timeout=180)
    pdfs = glob.glob(os.path.join(d, "*.pdf"))
    if pdfs:
        info = subprocess.run(["pdfinfo", pdfs[0]], capture_output=True, text=True).stdout
        pages = int(re.search(r"Pages:\s+(\d+)", info).group(1))
        imgs = subprocess.run(["pdfimages", "-list", pdfs[0]], capture_output=True, text=True).stdout.strip().splitlines()[2:]
        ok_all &= check(pages == 3 and len(imgs) >= 3, f"pptx: LibreOffice dựng được PDF {pages} trang, có {len(imgs)} ảnh", quiet)
    else:
        ok_all &= check(False, "pptx: LibreOffice không mở được tệp: " + (r.stderr or r.stdout)[:150], quiet)
    shutil.rmtree(d, ignore_errors=True)
    # tệp đầu là ảnh ngang
    outp2 = os.path.join(OUT, "ex_p2.pptx")
    java(java_path, "pptx", outp2, args[1], args[0])
    prs2 = Presentation(outp2)
    ok_all &= check((prs2.slide_width, prs2.slide_height) == (12192000, 12192000 * 600 // 800), f"pptx: ảnh đầu NGANG -> trang chiếu ngang {(prs2.slide_width, prs2.slide_height)}", quiet)
    return ok_all

# ======================================================================= 4. HTML / Markdown
TOKENS = ["Hợp", "đồng", "thuê", "nhà", "Nguyễn", "Văn", "An", "12.500.000", "đ/tháng", "*", "_", "#", "-", "+", ">", "1.", "2)", "[x]", "<b>", "&amp;", "&", "|", "`", "~~~", "===", "\\", "!", "$5", "(a)", "{b}", "a@b.vn",
          "http://x.vn/a_b", "**đậm**", "_nghiêng_", "[link](u)", "# tiêu đề", "- gạch", "> trích", "1. một", "<script>", "</p>", "a < b", "b > a", "\"q\"", "'s'", "…", "—", "Điều 5.", "ghi chú:"]
def fuzz_page(rng):
    paras = []
    for _ in range(rng.randint(1, 5)):
        lines = []
        for _ in range(rng.randint(1, 4)):
            lines.append(" ".join(rng.choice(TOKENS) for _ in range(rng.randint(1, 8))))
        paras.append("\n".join(lines))
    page = "\n\n".join(paras)
    if rng.random() < 0.3: page = page.replace(" ", "\u00a0", 1) if False else page
    return page
def write_pages(path, title, pages):
    with open(path, "w", encoding="utf-8") as f:
        f.write("TITLE\t" + enc(title) + "\n")
        for p in pages: f.write("PAGE\t" + enc(p) + "\n")

class TextCollector(html.parser.HTMLParser):
    def __init__(self): super().__init__(); self.stack, self.tags, self.text = [], [], {}
    def handle_starttag(self, tag, attrs): self.stack.append(tag); self.tags.append(tag)
    def handle_endtag(self, tag):
        if self.stack and self.stack[-1] == tag: self.stack.pop()
    def handle_data(self, data):
        if self.stack and self.stack[-1] in ("p", "title", "h1", "h2"): self.text.setdefault(self.stack[-1], []).append(data)

def html_suite(java_path, quiet=False):
    rng = random.Random(1632)
    ok_all = True
    pages = [fuzz_page(rng) for _ in range(40)]
    title = "Tên sách <script> & \"x\" 'y'"
    inp, outp = os.path.join(OUT, "ex_html.in"), os.path.join(OUT, "ex_h.html")
    write_pages(inp, title, pages); java(java_path, "html", inp, outp)
    raw = open(outp, encoding="utf-8").read()
    pc = TextCollector(); pc.feed(raw)
    allowed = {"html", "head", "meta", "title", "style", "body", "h1", "section", "h2", "p"}
    extra = set(pc.tags) - allowed
    ok_all &= check(not extra, f"html: chỉ có các thẻ do bộ ghi sinh ra (không thẻ lạ lọt từ văn bản như <script>, <b>): thừa {sorted(extra)}", quiet)
    got_text = norm(" ".join(pc.text.get("p", [])))
    want_text = norm(" ".join(clean(p) for p in pages))
    ok_all &= check(got_text == want_text, "html: toàn bộ chữ trong các <p> (html.parser) = chữ các trang đưa vào, không mất / thêm / đổi" + ("" if got_text == want_text else f" — khác ở: {next((i for i,(a,b) in enumerate(zip(got_text,want_text)) if a!=b), min(len(got_text),len(want_text)))}"), quiet)
    ok_all &= check(norm("".join(pc.text.get("title", []))) == norm(clean(title)) and norm("".join(pc.text.get("h1", []))) == norm(clean(title)), "html: <title> và <h1> giữ nguyên tiêu đề có <script> & \" '", quiet)
    ok_all &= check(len(pc.text.get("h2", [])) == len(pages) and "lang=\"vi\"" in raw and "charset=\"utf-8\"" in raw, f"html: {len(pages)} mục 'Trang N', lang=vi, UTF-8", quiet)
    # pandoc đọc độc lập: cấu trúc (mỗi <section> là một Div có Header 'Trang N') và chữ từng trang
    r = subprocess.run(["pandoc", "-f", "html", "-t", "json", outp], capture_output=True, text=True)
    if r.returncode != 0:
        ok_all &= check(False, "html: pandoc không đọc được: " + r.stderr[:100], quiet)
    else:
        def flat(x, out):
            if isinstance(x, dict):
                if x.get("t") == "Str": out.append(x["c"])
                elif x.get("t") in ("Space", "SoftBreak", "LineBreak"): out.append(" ")
                else: flat(x.get("c"), out)
            elif isinstance(x, list):
                for y in x: flat(y, out)
        sections = [b for b in json.loads(r.stdout)["blocks"] if b["t"] == "Div"]
        got_pages = []
        for d in sections:
            parts = []
            for b in d["c"][1]:
                if b["t"] == "Para":
                    t = []; flat(b["c"], t); parts.append("".join(t))
            got_pages.append(norm(" ".join(parts)))
        want_pages = [norm(clean(" ".join(DocxPara(pg)))) for pg in pages] if False else None
        bad = [i for i, (pg, g) in enumerate(zip(pages, got_pages)) if norm(clean(pg)) != g]
        ok_all &= check(len(sections) == len(pages) and not bad, f"html: pandoc thấy {len(sections)} mục trang, chữ từng trang = chữ đưa vào" + (f" — sai trang {bad[:3]}" if bad else ""), quiet)
    return ok_all

def md_suite(java_path, quiet=False):
    rng = random.Random(1633)
    ok_all = True
    pages = [fuzz_page(rng) for _ in range(60)]
    title = "Tên *sách* # 1. [x] _y_"
    inp, outp = os.path.join(OUT, "ex_md.in"), os.path.join(OUT, "ex_m.md")
    write_pages(inp, title, pages); java(java_path, "md", inp, outp)
    r = subprocess.run(["pandoc", "-f", "commonmark", "-t", "json", outp], capture_output=True, text=True)
    if r.returncode != 0: return check(False, "markdown: pandoc không đọc được: " + r.stderr[:100], quiet)
    doc = json.loads(r.stdout)
    blocks = doc["blocks"]
    kinds = {b["t"] for b in blocks}
    ok_all &= check(kinds <= {"Header", "Para", "HorizontalRule"}, f"markdown: pandoc (commonmark) chỉ thấy tiêu đề / đoạn văn / đường kẻ — không danh sách, trích dẫn, mã, bảng, HTML ngoài ý muốn (thấy {sorted(kinds)})", quiet)
    headers = [b for b in blocks if b["t"] == "Header"]
    ok_all &= check(len(headers) == 1 + len(pages) and headers[0]["c"][0] == 1 and all(h["c"][0] == 2 for h in headers[1:]), f"markdown: 1 tiêu đề cấp 1 + {len(pages)} tiêu đề 'Trang N' cấp 2 (thấy {len(headers)})", quiet)
    ok_all &= check(sum(1 for b in blocks if b["t"] == "HorizontalRule") == len(pages) - 1, "markdown: đường kẻ '---' giữa các trang, không thừa không thiếu", quiet)
    def inl(x):
        out = []
        def walk(y):
            if isinstance(y, dict):
                if y.get("t") == "Str": out.append(y["c"])
                elif y.get("t") in ("Space", "SoftBreak", "LineBreak"): out.append(" ")
                elif y.get("t") == "Code": out.append(y["c"][1])
                else: walk(y.get("c"))
            elif isinstance(y, list):
                for z in y: walk(z)
        walk(x); return "".join(out)
    page_texts, cur = [], None
    for b in blocks:
        if b["t"] == "Header" and b["c"][0] == 2: cur = []; page_texts.append(cur)
        elif b["t"] == "Para" and cur is not None: cur.append(inl(b["c"]))
    bad = [i for i, (p, g) in enumerate(zip(pages, page_texts)) if norm(clean(p)) != norm(" ".join(g))]
    ok_all &= check(not bad and len(page_texts) == len(pages), f"markdown: chữ của từng trang trong pandoc = chữ đưa vào ({len(pages)} trang chứa * _ # - + > 1. [x] <b> &amp; | ` ~~~ === \\ ...)" + (f" — sai trang {bad[:3]}: {norm(clean(pages[bad[0]]))[:60]!r} vs {norm(' '.join(page_texts[bad[0]]))[:60]!r}" if bad else ""), quiet)
    ok_all &= check(norm(inl(headers[0]["c"][2])) == norm(clean(title)), "markdown: tiêu đề sách có * # 1. [x] _ giữ nguyên chữ", quiet)
    return ok_all

# ======================================================================= đột biến
SRC = open(JAVA, encoding="utf-8").read()
def mutated(old, new):
    assert SRC.count(old) == 1, ("đột biến không tìm thấy đúng 1 chỗ", old[:60], SRC.count(old))
    path = os.path.join(OUT, "ExportCheckMut.java")
    open(path, "w", encoding="utf-8").write(SRC.replace(old, new, 1).replace("public class ExportCheck", "public class ExportCheckMut"))
    return path

def main():
    print("== bảng từ hộp chữ ==")
    table_suite(JAVA)
    print("== xlsx ==")
    xlsx_misc_suite(JAVA); sheet_name_suite(JAVA); xlsx_e2e_suite(JAVA)
    print("== pptx ==")
    pptx_suite(JAVA)
    print("== html / markdown ==")
    html_suite(JAVA); md_suite(JAVA)
    print("== đột biến (mỗi cái phải làm bài kiểm tương ứng đỏ) ==")
    muts = [
        ("khe giữa các ô quá lớn (3,0 x chiều cao thay vì 0,8): các cột dính nhau", ("float cellGap = 0.8f * medianH;", "float cellGap = 3.0f * medianH;"), table_suite),
        ("dung sai gộp hàng quá lớn (1,6 thay vì 0,6): các hàng dính nhau", ("w.centerY() - rowCenter > 0.6f * medianH", "w.centerY() - rowCenter > 1.6f * medianH"), table_suite),
        ("không cắt phần ngoài bảng (> 0 thay vì > dung sai): sinh cột thừa", ("if (coverage[k] > tolerance) { if (firstUsed < 0) firstUsed = k; lastUsed = k; }", "if (coverage[k] > 0) { if (firstUsed < 0) firstUsed = k; lastUsed = k; }"), table_suite),
        ("ranh giới cột đặt ở GIỮA khe thay vì điểm bắt đầu phần trống hoàn toàn: ô dài nhất của cột căn phải bị xếp nhầm sang cột bên trái", ("return bestLen >= minBuckets ? minX + bestStart * step : minX + (from + to) / 2f * step;", "return minX + (from + to) / 2f * step;"), table_suite),
        ("số 0 đầu / số dài thành số", ("\"-?(0|[1-9][0-9]{0,14})\")) return null;", "\"-?[0-9]{1,15}\")) return null;"), xlsx_misc_suite),
        ("Markdown không escape dấu đầu đoạn (# - + 1.)", ("if (startOfBlock) {", "if (false) {"), md_suite),
        ("HTML không escape văn bản", ("sb.append(\"<p>\").append(escape(p)).append(\"</p>\\n\");", "sb.append(\"<p>\").append(p).append(\"</p>\\n\");"), html_suite),
        ("ảnh PPTX bị kéo giãn kín trang chiếu", ("cx = sx; cy = Math.max(1L, sx * h / w); } else { cy = sy; cx = Math.max(1L, sy * w / h); }", "cx = sx; cy = sy; } else { cy = sy; cx = sx; }"), pptx_suite),
    ]
    for label, (old, new), suite in muts:
        path = mutated(old, new)
        caught = not suite(path, quiet=True)
        check(caught, f"đột biến bị bắt: {label}")
    print("\nTAT CA DAT" if not FAILS else f"\nCO {len(FAILS)} LOI")
    sys.exit(1 if FAILS else 0)

if __name__ == "__main__":
    main()
