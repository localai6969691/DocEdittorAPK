"""Kiểm chứng TextChunker (phiên 15): cắt văn bản thành các đoạn <= max ký tự cho TextToSpeech và dịch, không mất/đảo chữ nào.

Bản Python song song của app/.../util/TextChunker.kt. Thuộc tính cần giữ: mọi đoạn <= max, không đoạn rỗng, ghép các đoạn theo thứ tự chứa đủ mọi ký tự khác
khoảng trắng của đầu vào (đúng thứ tự), các dòng ngắn được gộp, dòng dài cắt sau dấu kết câu ưu tiên hơn cắt ở dấu cách, cắt cứng chỉ khi không có dấu cách.
Chạy: python3 text_chunker_check.py
"""
import random, re, sys


def cut_line(line, mx):
    if len(line) <= mx:
        return [line]
    pieces, rest = [], line
    while len(rest) > mx:
        window = rest[:mx]
        cut = -1
        for i in range(len(window) - 1, 0, -1):
            c = window[i - 1]
            if c in ".!?…" and window[i] == " ":
                cut = i; break
        if cut <= 0:
            cut = window.rfind(" ")
        if cut <= 0:
            cut = mx
        head = rest[:cut].strip()
        if head:
            pieces.append(head)
        rest = rest[cut:].strip()
    if rest:
        pieces.append(rest)
    return pieces


def split(text, mx):
    assert mx >= 20
    out, cur = [], []
    def length(parts):
        return sum(len(p) for p in parts) + max(len(parts) - 1, 0)
    def flush():
        nonlocal cur
        t = "\n".join(cur).strip()
        if t:
            out.append(t)
        cur = []
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        for piece in cut_line(line, mx):
            if cur and length(cur) + 1 + len(piece) > mx:
                flush()
            cur.append(piece)
    flush()
    return out


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    return cond


def squeeze(s):
    return re.sub(r"\s+", "", s)


def main():
    good = True
    good &= check(split("", 50) == [] and split("  \n \n", 50) == [], "văn bản trống -> không đoạn nào")
    good &= check(split("Một dòng ngắn.", 50) == ["Một dòng ngắn."], "một dòng ngắn giữ nguyên")
    r = split("Dòng một.\nDòng hai.\n\n\nDòng ba.", 100)
    good &= check(r == ["Dòng một.\nDòng hai.\nDòng ba."], f"các dòng ngắn được gộp, dòng trống bỏ: {r}")
    r = split("a" * 30 + "\n" + "b" * 30 + "\n" + "c" * 30, 70)
    good &= check(r == ["a" * 30 + "\n" + "b" * 30, "c" * 30], "gói tối đa vào mỗi đoạn rồi mới sang đoạn mới")
    long_line = "Câu thứ nhất khá dài ở đây. Câu thứ hai cũng dài như thế. Câu thứ ba kết thúc."
    r = split(long_line, 40)
    good &= check(all(len(x) <= 40 for x in r) and squeeze("".join(r)) == squeeze(long_line) and r[0].endswith("."), f"dòng dài cắt sau dấu kết câu: {r}")
    r = split("từ " * 40, 30)
    good &= check(all(len(x) <= 30 for x in r) and squeeze("".join(r)) == squeeze("từ " * 40), "không có dấu kết câu: cắt ở dấu cách")
    r = split("x" * 95, 30)
    good &= check([len(x) for x in r] == [30, 30, 30, 5], f"không có dấu cách: cắt cứng đúng độ dài {[len(x) for x in r]}")
    # ngẫu nhiên: thuộc tính bảo toàn
    rng = random.Random(7)
    words = ["xin", "chào", "hợp", "đồng", "thuê", "nhà", "ngày", "3/10/2026.", "Giá:", "1.250.000", "đồng!", "Tốt?", "ok…"]
    bad = 0
    for _ in range(300):
        lines = [" ".join(rng.choice(words) for _ in range(rng.randint(0, 40))) for _ in range(rng.randint(0, 12))]
        text = "\n".join(lines)
        mx = rng.choice([20, 35, 80, 200, 4000])
        r = split(text, mx)
        if not (all(0 < len(x) <= mx for x in r) and squeeze("".join(r)) == squeeze(text)):
            bad += 1
    good &= check(bad == 0, f"300 văn bản ngẫu nhiên: mọi đoạn <= max, không rỗng, đủ chữ đúng thứ tự (lỗi: {bad})")
    print("TAT CA DAT" if good else "CO LOI")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
