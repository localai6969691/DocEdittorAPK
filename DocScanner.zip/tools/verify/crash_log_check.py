"""Kiểm chứng CrashLog.describe (phiên 16): báo cáo sự cố cục bộ không được lộ đường dẫn / tên tài liệu của người dùng.

CrashLogCheck.java là bản Java chạy được của đúng hàm đó. Ca kiểm dùng NGOẠI LỆ THẬT mang đường dẫn kiểu Unix và Windows có tên tài liệu tiếng Việt
("Hợp đồng CCCD 0123456789.pdf", "Hồ sơ bệnh án.pdf", "Sổ hộ khẩu.jpg"): toàn bộ báo cáo KHÔNG được chứa tên đó, cũng không chứa dấu '/' hay '\\' nào của
thông báo; thông báo thường vẫn giữ nguyên (để còn gỡ lỗi); chuỗi nguyên nhân tối đa 6 cấp; tối đa 25 dòng ngăn xếp mỗi cấp; thông báo dài bị cắt 300 ký tự.
Thử âm tính: bản KHÔNG ẩn thông báo (hành vi 'ngây thơ') làm lộ tên tài liệu - nếu không, bài kiểm này không bảo vệ được gì.
Chạy: python3 crash_log_check.py   (cần java 11+)
"""
import os, re, subprocess, sys
HERE = os.path.dirname(os.path.abspath(__file__))
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
    return cond

def run(java_file):
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", "-Dstdout.encoding=UTF-8", java_file], capture_output=True, text=True, encoding="utf-8")
    if r.returncode != 0: sys.exit("Java lỗi:\n" + r.stdout + r.stderr)
    blocks = {}
    for part in re.split(r"^=== ", r.stdout, flags=re.M)[1:]:
        name, _, body = part.partition("\n")
        blocks[name.strip()] = body
    return blocks

b = run(os.path.join(HERE, "CrashLogCheck.java"))
SECRETS = ["Hợp đồng", "CCCD", "0123456789", "Hồ sơ bệnh án", "Sổ hộ khẩu", "/storage", "/data/user", "C:\\", "Users\\An"]
for name in ("unix-path", "windows-path", "cause-with-path"):
    leak = [s for s in SECRETS if s in b[name]]
    check(not leak, f"{name}: báo cáo không chứa tên tài liệu / đường dẫn (lộ: {leak})")
    check("(message hidden" in b[name], f"{name}: thông báo bị ẩn có ghi rõ lý do")
check("Index 5 out of bounds for length 3" in b["plain"], "plain: thông báo thường được giữ (cần để gỡ lỗi)")
check(b["plain"].startswith("java.lang.IndexOutOfBoundsException: Index 5"), "plain: dòng đầu = lớp ngoại lệ + thông báo")
check(b["null-message"].splitlines()[0] == "java.lang.NullPointerException", "null-message: chỉ có tên lớp")
check(b["blank-message"].splitlines()[0] == "java.lang.RuntimeException", "blank-message: thông báo toàn dấu cách bị bỏ")
long_line = b["long-message"].splitlines()[0]
check(len(long_line) == len("java.lang.RuntimeException: ") + 300, f"long-message: thông báo cắt đúng 300 ký tự (dòng dài {len(long_line)})")
check("cause-with-path".startswith("cause") and "Caused by: java.io.FileNotFoundException" in b["cause-with-path"] and "wrapper ok" in b["cause-with-path"],
      "cause-with-path: thông báo vô hại của lớp bọc vẫn giữ, chỉ thông báo của nguyên nhân (có đường dẫn) bị ẩn")
causes = [l for l in b["deep-chain"].splitlines() if l.startswith("Caused by:") or (not l.startswith("    at") and l)]
check(len(causes) == 6, f"deep-chain: chuỗi nguyên nhân dừng ở 6 cấp (có {len(causes)})")
frames = [l for l in b["many-frames"].splitlines() if l.startswith("    at ")]
check(len(frames) == 25, f"many-frames: đúng 25 dòng ngăn xếp (có {len(frames)})")
check(all("deep stack" not in l for l in frames), "dòng ngăn xếp chỉ chứa lớp/hàm/số dòng, không chứa thông báo")

# thử âm tính: bản ngây thơ (không ẩn) làm lộ
src = open(os.path.join(HERE, "CrashLogCheck.java"), encoding="utf-8").read()
naive = src.replace("(message.indexOf('/') >= 0 || message.indexOf('\\\\') >= 0) ? HIDDEN_MESSAGE : message.substring(0, Math.min(300, message.length()))",
                    "message.substring(0, Math.min(300, message.length()))")
assert naive != src, "không tạo được bản ngây thơ - sửa bài kiểm"
tmp = os.path.join(os.environ.get("TMPDIR", "/tmp"), "CrashLogCheck.java")
open(tmp, "w", encoding="utf-8").write(naive)
nb = run(tmp)
leaked = [s for s in SECRETS if s in nb["unix-path"] + nb["windows-path"] + nb["cause-with-path"]]
check(bool(leaked), f"thử âm tính: bản KHÔNG ẩn thông báo làm lộ {leaked[:3]} — bài kiểm này bảo vệ được quyền riêng tư")
print("\nTAT CA DAT" if not FAILS else f"\nCO {len(FAILS)} LOI")
sys.exit(1 if FAILS else 0)
