"""Kiểm chứng EpubTools (phiên 18): sửa thông tin, đổi ảnh bìa, ghép, tách EPUB ở MỨC GÓI ZIP.

EpubToolsCheck.java là bản Java chạy được của util/EpubTools.kt. Bài kiểm KHÔNG tin lời báo của Java: dựng EPUB mẫu bằng zipfile, chạy lệnh,
rồi đọc kết quả bằng công cụ độc lập (zipfile, lxml, pandoc -f epub):
A - sửa thông tin: giá trị đọc lại đúng (có & < và chữ Việt, xuống dòng); MỌI tệp khác byte-for-byte như cũ, cùng thứ tự; `mimetype` đứng đầu và KHÔNG nén;
    EPUB3 có dcterms:modified mới, EPUB2 không bị thêm; tên/ngôn ngữ để trống thì giữ giá trị cũ.
B - đổi bìa: sách có bìa -> GHI ĐÈ nội dung tại CHÍNH đường dẫn cũ (trang bìa XHTML vẫn trỏ đúng), media-type theo ảnh mới; sách chưa bìa -> thêm mục
    + meta cover (+ properties=cover-image với EPUB3). THỬ ÂM TÍNH: cách "xoá bìa cũ, thêm bìa mới" làm trang bìa trỏ vào hư không và bị bộ kiểm tham chiếu bắt.
C - ghép (A+B): mọi href trong manifest / nav / ncx tồn tại; id duy nhất; idref nằm trong manifest; mọi tham chiếu tương đối trong XHTML + CSS còn đúng;
    ảnh giữ nguyên từng byte; pandoc đọc ra đủ chữ của mọi chương theo thứ tự; tên có dấu cách / chữ Việt trong đường dẫn vẫn đúng.
D - tách: phần chỉ giữ ảnh/CSS mà các trang của nó dùng (ảnh thừa bị bỏ), vẫn hợp lệ như C; phạm vi sai bị từ chối; 600 chuỗi phạm vi ngẫu nhiên so với bản tham chiếu.
Chạy: python3 epub_tools_check.py   (cần java 11+, pandoc)
"""
import io, os, random, re, shutil, subprocess, sys, tempfile, zipfile, posixpath, urllib.parse
from lxml import etree
sys.path.insert(0, os.path.dirname(__file__))
HERE = os.path.dirname(os.path.abspath(__file__))
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
    return cond
def java(*args):
    r = subprocess.run(["java", os.path.join(HERE, "EpubToolsCheck.java"), *map(str, args)], capture_output=True, text=True)
    if r.returncode != 0: print(r.stderr[-1500:])
    return r.stdout.strip("\n").split("\n") if r.stdout.strip("\n") else []
NS = {"o": "http://www.idpf.org/2007/opf", "dc": "http://purl.org/dc/elements/1.1/", "x": "http://www.w3.org/1999/xhtml", "n": "http://www.daisy.org/z3986/2005/ncx/"}
tmp = tempfile.mkdtemp(prefix="epubtools_")
def P(n): return os.path.join(tmp, n)

# ---------------------------------------------------------------- dữ liệu mẫu
from PIL import Image
def img(color, fmt, size=(40, 60)):
    b = io.BytesIO(); Image.new("RGB", size, color).save(b, fmt); return b.getvalue()
PIC, BG, UNUSED, COVER_OLD = img("red", "PNG"), img("green", "PNG"), img("blue", "PNG"), img("yellow", "PNG", (50, 80))
def xhtml(title, body, css=None):
    link = f'<link rel="stylesheet" type="text/css" href="{css}"/>' if css else ""
    return f'<?xml version="1.0" encoding="utf-8"?>\n<html xmlns="http://www.w3.org/1999/xhtml"><head><title>{title}</title>{link}</head><body>{body}</body></html>'
def make_epub3(path, with_cover=True):
    files = [("mimetype", b"application/epub+zip", True),
        ("META-INF/container.xml", b'<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>', False)]
    cover_item = '<item id="cov" href="cover.png" media-type="image/png" properties="cover-image"/>\n<item id="covpage" href="cover.xhtml" media-type="application/xhtml+xml"/>' if with_cover else ""
    cover_spine = '<itemref idref="covpage"/>' if with_cover else ""
    opf = f'''<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="uid"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
<dc:identifier id="uid">urn:uuid:11111111-1111-4111-8111-111111111111</dc:identifier><dc:title>Sách A</dc:title><dc:creator>Tác giả A</dc:creator><dc:language>vi</dc:language>
<meta property="dcterms:modified">2020-01-01T00:00:00Z</meta></metadata>
<manifest><item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
<item id="c1" href="text/ch1.xhtml" media-type="application/xhtml+xml"/><item id="c2" href="text/ch2.xhtml" media-type="application/xhtml+xml"/><item id="c3" href="text/ch3.xhtml" media-type="application/xhtml+xml"/>
<item id="css" href="css/style.css" media-type="text/css"/><item id="pic" href="images/pic%20a.png" media-type="image/png"/><item id="bg" href="images/bg.png" media-type="image/png"/><item id="un" href="images/unused.png" media-type="image/png"/>
{cover_item}</manifest><spine>{cover_spine}<itemref idref="c1"/><itemref idref="c2"/><itemref idref="c3"/></spine></package>'''.encode()
    nav = xhtml("Mục lục", '<nav xmlns:epub="http://www.idpf.org/2007/ops" epub:type="toc"><ol><li><a href="text/ch1.xhtml">Chương Một</a></li><li><a href="text/ch2.xhtml#sec">Chương Hai</a></li><li><a href="text/ch3.xhtml">Chương Ba</a></li></ol></nav>')
    files += [("OEBPS/content.opf", opf, False), ("OEBPS/nav.xhtml", nav.encode(), False),
        ("OEBPS/text/ch1.xhtml", xhtml("c1", '<h1>Chương Một</h1><p>Alpha một xin chào.</p><img src="../images/pic%20a.png" alt="x"/><p><a href="ch2.xhtml#sec">sang chương hai</a></p>', "../css/style.css").encode(), False),
        ("OEBPS/text/ch2.xhtml", xhtml("c2", '<h1 id="sec">Chương Hai</h1><p>Beta hai xin chào.</p>', "../css/style.css").encode(), False),
        ("OEBPS/text/ch3.xhtml", xhtml("c3", "<h1>Chương Ba</h1><p>Gamma ba xin chào.</p>").encode(), False),
        ("OEBPS/css/style.css", b"body{background:url(../images/bg.png)} p{margin:0}", False),
        ("OEBPS/images/pic a.png", PIC, False), ("OEBPS/images/bg.png", BG, False), ("OEBPS/images/unused.png", UNUSED, False)]
    if with_cover:
        files += [("OEBPS/cover.png", COVER_OLD, False), ("OEBPS/cover.xhtml", xhtml("cover", '<img src="cover.png" alt="bia"/>').encode(), False)]
    write_zip(path, files)
def make_epub2(path):
    files = [("mimetype", b"application/epub+zip", True),
        ("META-INF/container.xml", b'<?xml version="1.0"?><container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="content/book.opf" media-type="application/oebps-package+xml"/></rootfiles></container>', False),
        ("content/book.opf", '''<?xml version="1.0" encoding="utf-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="2.0" unique-identifier="id"><metadata xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:opf="http://www.idpf.org/2007/opf">
<dc:title>Quyển B</dc:title><dc:creator>Tác giả B</dc:creator><dc:creator>Người dịch B</dc:creator><dc:identifier id="id">isbn-222</dc:identifier><dc:language>en</dc:language><meta name="cover" content="cov"/></metadata>
<manifest><item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/><item id="a" href="a.xhtml" media-type="application/xhtml+xml"/><item id="b" href="b.xhtml" media-type="application/xhtml+xml"/><item id="cov" href="pics/cover.jpg" media-type="image/jpeg"/><item id="pp" href="pics/p.png" media-type="image/png"/></manifest>
<spine toc="ncx"><itemref idref="a"/><itemref idref="b"/></spine></package>'''.encode(), False),
        ("content/toc.ncx", '''<?xml version="1.0"?><ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1"><head/><docTitle><text>Quyển B</text></docTitle><navMap>
<navPoint id="n1" playOrder="1"><navLabel><text>Bài mở đầu</text></navLabel><content src="a.xhtml"/></navPoint><navPoint id="n2" playOrder="2"><navLabel><text>Bài kết thúc</text></navLabel><content src="b.xhtml"/></navPoint></navMap></ncx>'''.encode(), False),
        ("content/a.xhtml", xhtml("a", '<h1>Bài mở đầu</h1><p>Delta bốn mở đầu.</p><img src="pics/p.png" alt=""/>').encode(), False),
        ("content/b.xhtml", xhtml("b", '<h1>Bài kết thúc</h1><p>Epsilon năm kết thúc.</p>').encode(), False),
        ("content/pics/cover.jpg", img("purple", "JPEG"), False), ("content/pics/p.png", img("orange", "PNG"), False)]
    write_zip(path, files)
def write_zip(path, files):
    with zipfile.ZipFile(path, "w") as z:
        for name, data, stored in files:
            z.writestr(zipfile.ZipInfo(name), data, compress_type=zipfile.ZIP_STORED if stored else zipfile.ZIP_DEFLATED)

# ---------------------------------------------------------------- bộ kiểm độc lập
def entries(path):
    with zipfile.ZipFile(path) as z: return {i.filename: z.read(i.filename) for i in z.infolist()}, [i.filename for i in z.infolist()]
def resolve(base, ref):
    ref = ref.split("#")[0].split("?")[0]
    if not ref or re.match(r"^[A-Za-z][A-Za-z0-9+.\-]*:", ref) or ref.startswith("//"): return None
    ref = urllib.parse.unquote(ref)
    return posixpath.normpath(posixpath.join(posixpath.dirname(base), ref))
def validate(path, label):
    """Tra ve danh sach loi cua mot EPUB (kiem bang zipfile + lxml, khong tin Java)."""
    errs = []
    with zipfile.ZipFile(path) as z:
        infos = z.infolist()
        if infos[0].filename != "mimetype" or infos[0].compress_type != zipfile.ZIP_STORED or z.read("mimetype") != b"application/epub+zip": errs.append("mimetype khong o dau / bi nen")
        if z.testzip(): errs.append("zip hong")
        names = set(z.namelist()); data = {n: z.read(n) for n in names}
    cont = etree.fromstring(data["META-INF/container.xml"]); opfp = cont.xpath("//*[local-name()='rootfile']/@full-path")[0]
    if opfp not in names: return errs + ["khong co OPF"]
    opf = etree.fromstring(data[opfp]); man = opf.xpath("//o:manifest/o:item", namespaces=NS)
    ids = [i.get("id") for i in man]
    if len(ids) != len(set(ids)): errs.append("id manifest trung")
    byid = {i.get("id"): i for i in man}
    for i in man:
        t = resolve(opfp, i.get("href"))
        if t not in names: errs.append(f"manifest tro vao hu khong: {i.get('href')}")
        fb = i.get("fallback")
        if fb and fb not in byid: errs.append(f"fallback hong {fb}")
    for r in opf.xpath("//o:spine/o:itemref", namespaces=NS):
        if r.get("idref") not in byid: errs.append(f"idref khong co: {r.get('idref')}")
    cov = [i for i in man if "cover-image" in (i.get("properties") or "").split()]
    if len(cov) > 1: errs.append("nhieu hon mot cover-image")
    mc = opf.xpath("//o:meta[@name='cover']/@content", namespaces=NS)
    if mc and mc[0] not in byid: errs.append("meta cover tro vao id khong co")
    for i in man:
        t = resolve(opfp, i.get("href")); typ = i.get("media-type")
        if t not in names: continue
        text = None
        if typ == "application/xhtml+xml":
            try: etree.fromstring(data[t])
            except Exception as e: errs.append(f"XHTML khong parse duoc {t}: {e}")
            text = data[t].decode("utf-8")
            refs = re.findall(r"""(?:\bsrc|\bhref|xlink:href)\s*=\s*["']([^"']*)["']""", text) + re.findall(r"url\(\s*[\"']?([^)\"']*)", text)
        elif typ == "text/css":
            text = data[t].decode("utf-8"); refs = re.findall(r"url\(\s*[\"']?([^)\"']*)", text) + re.findall(r"@import\s+[\"']([^\"']*)", text)
        else: continue
        for r in refs:
            rr = resolve(t, r)
            if rr is not None and rr not in names: errs.append(f"{t} tro vao hu khong: {r}")
    # nav / ncx
    for i in man:
        if "nav" in (i.get("properties") or "").split():
            t = resolve(opfp, i.get("href")); d = etree.fromstring(data[t])
            for a in d.xpath("//x:a", namespaces=NS):
                rr = resolve(t, a.get("href"))
                if rr not in names: errs.append(f"nav tro vao hu khong: {a.get('href')}")
        if i.get("media-type") == "application/x-dtbncx+xml":
            t = resolve(opfp, i.get("href")); d = etree.fromstring(data[t])
            for c in d.xpath("//n:content/@src", namespaces=NS):
                if resolve(t, c) not in names: errs.append(f"ncx tro vao hu khong: {c}")
    return errs
def pandoc_text(path):
    r = subprocess.run(["pandoc", "-f", "epub", "-t", "plain", "--wrap=none", path], capture_output=True, text=True)
    return r.stdout
def opf_of(path):
    d, _ = entries(path); cont = etree.fromstring(d["META-INF/container.xml"]); p = cont.xpath("//*[local-name()='rootfile']/@full-path")[0]
    return p, etree.fromstring(d[p]), d

A, B, C0 = P("A.epub"), P("B.epub"), P("C0.epub")
make_epub3(A); make_epub2(B); make_epub3(C0, with_cover=False)
for n, f in (("A", A), ("B", B), ("A khong bia", C0)): check(validate(f, n) == [], f"mẫu {n} hợp lệ theo bộ kiểm độc lập")

print("== A. sửa thông tin ==")
m = {l.split("\t")[0]: l.split("\t", 1)[1] for l in java("meta-read", A)}
check(m["title"] == "Sách A" and m["authors"] == "Tác giả A" and m["language"] == "vi" and m["identifier"].startswith("urn:uuid:1111"), f"đọc thông tin EPUB3: {m}")
m = {l.split("\t")[0]: l.split("\t", 1)[1] for l in java("meta-read", B)}
check(m["authors"] == "Tác giả B|Người dịch B" and m["identifier"] == "isbn-222" and m["language"] == "en", f"đọc thông tin EPUB2 (hai tác giả): {m}")
A2 = P("A2.epub")
T = 'Tiêu đề & "mới" <b>'; D = "Dòng một\nDòng hai & ba"
check(java("meta-write", A, A2, T, "Nguyễn Văn Á|Trần Thị B", "fr", "NXB Trẻ", D) == ["OK"], "ghi thông tin mới")
m = {l.split("\t")[0]: l.split("\t", 1)[1] for l in java("meta-read", A2)}
check(m["title"] == T and m["authors"] == "Nguyễn Văn Á|Trần Thị B" and m["language"] == "fr" and m["publisher"] == "NXB Trẻ" and m["description"] == D.replace("\n", "\\n"), f"đọc lại đúng (có & \" < và xuống dòng): {m}")
# lxml độc lập
p, opf, d2 = opf_of(A2)
check(opf.xpath("//dc:title/text()", namespaces=NS) == [T] and len(opf.xpath("//dc:creator", namespaces=NS)) == 2, "lxml đọc cùng giá trị, hai tác giả")
check(opf.xpath("//o:meta[@property='dcterms:modified']/text()", namespaces=NS) == ["2026-10-16T00:00:00Z"], "dcterms:modified được cập nhật (EPUB3)")
check(opf.xpath("//dc:identifier/text()", namespaces=NS) == ["urn:uuid:11111111-1111-4111-8111-111111111111"], "định danh sách không đổi")
d1, o1 = entries(A); d2, o2 = entries(A2)
check(o1 == o2 and all(d1[k] == d2[k] for k in d1 if k != "OEBPS/content.opf"), "mọi tệp khác giống từng byte, cùng thứ tự")
check(validate(A2, "A2") == [], "kết quả hợp lệ (mimetype đầu + không nén, tham chiếu đúng)")
B2 = P("B2.epub")
java("meta-write", B, B2, "", "", "", "", "")   # trống = giữ tên + ngôn ngữ cũ; tác giả / nhà xuất bản / mô tả bị XOÁ theo ý người dùng
m = {l.split("\t")[0]: l.split("\t", 1)[1] for l in java("meta-read", B2)}
check(m["title"] == "Quyển B" and m["language"] == "en" and m["authors"] == "" and m["publisher"] == "", f"tên/ngôn ngữ trống thì giữ; tác giả để trống thì xoá: {m}")
_, opfb, _ = opf_of(B2)
check(not opfb.xpath("//o:meta[@property='dcterms:modified']", namespaces=NS), "EPUB2 không bị thêm dcterms:modified")
check(validate(B2, "B2") == [], "EPUB2 sau khi sửa vẫn hợp lệ")

print("== B. đổi ảnh bìa ==")
NEWJ = img("black", "JPEG", (30, 45)); open(P("new.jpg"), "wb").write(NEWJ)
A3 = P("A3.epub")
check(java("cover", A, A3, P("new.jpg")) == ["OK"], "đổi bìa sách đã có bìa")
d3, o3 = entries(A3); p, opf, _ = opf_of(A3)
check(d3["OEBPS/cover.png"] == NEWJ and set(d3) == set(d1), "ghi đè tại ĐÚNG đường dẫn cũ, không thêm / bớt tệp")
check(opf.xpath("//o:item[@id='cov']/@media-type", namespaces=NS) == ["image/jpeg"], "media-type theo ảnh mới")
check(validate(A3, "A3") == [] and "cover.png" in d3["OEBPS/cover.xhtml"].decode(), "trang bìa XHTML vẫn trỏ vào ảnh có thật")
# thử âm tính: cách ngây thơ "xoá bìa cũ + thêm bìa mới" để lại tham chiếu hỏng
naive = P("naive.epub"); dd, oo = entries(A)
write_zip(naive, [(n, dd[n], n == "mimetype") for n in oo if n != "OEBPS/cover.png"] + [("OEBPS/images/new-cover.jpg", NEWJ, False)])
check(any("cover.png" in e for e in validate(naive, "naive")), "thử âm tính: bộ kiểm bắt được cách ngây thơ làm hỏng trang bìa")
C1 = P("C1.epub")
check(java("cover", C0, C1, P("new.jpg")) == ["OK"], "thêm bìa cho sách chưa có bìa")
p, opf, dc1 = opf_of(C1)
its = opf.xpath("//o:item[@properties='cover-image']", namespaces=NS)
check(len(its) == 1 and its[0].get("media-type") == "image/jpeg" and dc1[posixpath.join(posixpath.dirname(p), urllib.parse.unquote(its[0].get("href")))] == NEWJ, "mục cover-image mới, nội dung đúng")
check(opf.xpath("//o:meta[@name='cover']/@content", namespaces=NS) == [its[0].get("id")] and validate(C1, "C1") == [], "meta cover (EPUB2) trỏ đúng mục; kết quả hợp lệ")
B3 = P("B3.epub")
java("cover", B, B3, P("new.jpg")); db3, _ = entries(B3)
check(db3["content/pics/cover.jpg"] == NEWJ and validate(B3, "B3") == [], "EPUB2: ghi đè bìa đã khai bằng meta cover; hợp lệ")

print("== C. ghép ==")
M = P("M.epub")
check(java("merge", M, "Bộ sách & \"hai\" tập", "vi", A, B) == ["OK"], "ghép A + B")
errs = validate(M, "M"); check(errs == [], "ghép hợp lệ: " + "; ".join(errs[:4]))
dm, om = entries(M)
check(om[0] == "mimetype" and dm.get("OEBPS/b1/OEBPS/images/pic a.png") == PIC and dm.get("OEBPS/b1/OEBPS/images/bg.png") == BG and dm.get("OEBPS/b2/content/pics/p.png") == img("orange", "PNG"), "ảnh (kể cả tên có dấu cách) giữ nguyên từng byte ở đường dẫn mới")
txt = pandoc_text(M)
order = ["Alpha một", "Beta hai", "Gamma ba", "Delta bốn", "Epsilon năm"]
pos = [txt.find(s) for s in order]
check(all(p >= 0 for p in pos) and pos == sorted(pos), f"pandoc đọc đủ 5 chương theo đúng thứ tự: {pos}")
p, opf, _ = opf_of(M)
check(opf.xpath("//dc:title/text()", namespaces=NS) == ['Bộ sách & "hai" tập'] and sorted(opf.xpath("//dc:creator/text()", namespaces=NS)) == sorted(["Tác giả A", "Tác giả B", "Người dịch B"]), "tiêu đề (có & \") và tác giả gộp đúng")
check(len(opf.xpath("//o:item[@properties and contains(@properties,'cover-image')]", namespaces=NS)) == 1 and len(opf.xpath("//o:itemref", namespaces=NS)) == 6, "đúng một ảnh bìa; spine = 4 (A kể cả trang bìa) + 2 (B)")
nav = etree.fromstring(dm["OEBPS/nav.xhtml"]); labels = nav.xpath("//x:a/text()", namespaces=NS)
check(labels[0] == "Sách A" and "Chương Hai" in labels and "Quyển B" in labels and "Bài kết thúc" in labels, f"mục lục gộp: {labels}")
check(any("#sec" in h for h in nav.xpath("//x:a/@href", namespaces=NS)), "mục lục giữ mỏ neo #sec")

print("== D. tách ==")
S = P("S")
check(java("split", A, S, "1-3,4") == ["OK 2"], "tách A (spine = bìa, 1, 2, 3) thành 2 phần: 1-3 và 4")
p1, p2 = S + "-1.epub", S + "-2.epub"
for f in (p1, p2): errs = validate(f, f); check(errs == [], f"{os.path.basename(f)} hợp lệ: " + "; ".join(errs[:3]))
d_1, _ = entries(p1); d_2, _ = entries(p2)
has = lambda dd, tail: any(k.endswith(tail) for k in dd)
check(has(d_1, "images/pic a.png") and has(d_1, "images/bg.png") and has(d_1, "css/style.css") and not has(d_1, "unused.png"), "phần 1 giữ ảnh + CSS các trang dùng, bỏ ảnh thừa")
check(not has(d_2, "pic a.png") and not has(d_2, "bg.png") and not has(d_2, "style.css") and not has(d_2, "unused.png"), "phần 2 (chỉ chương 3, không dùng gì) không mang theo ảnh / CSS")
check("Gamma ba" in pandoc_text(p2) and "Alpha" not in pandoc_text(p2) and "Alpha" in pandoc_text(p1), "văn bản đúng phần")
_, o1x, _ = opf_of(p1)
check(o1x.xpath("//dc:title/text()", namespaces=NS) == ["Sách A (phần 1)"], "tiêu đề phần")
# phạm vi
def ref_parts(n, spec):
    out = []
    for piece in spec.split(","):
        t = piece.strip()
        if not t: return None
        try:
            if "-" not in t: a = b = int(t)
            else:
                lo, hi = t.split("-", 1); a = int(lo.strip()) if lo.strip() else 1; b = int(hi.strip()) if hi.strip() else n
        except ValueError: return None
        if a < 1 or b > n or a > b: return None
        out.append((a, b))
    return out
fixed = [(4, "1-2,3"), (4, "1-"), (4, "-2"), (4, "0-2"), (4, "2-1"), (4, "1-5"), (4, ""), (4, "a"), (4, "1,,2"), (4, " 2 - 3 "), (4, "1-2-3")]
rnd = random.Random(7); alphabet = "0123456789-, a"
for _ in range(600): fixed.append((rnd.randint(1, 9), "".join(rnd.choice(alphabet) for _ in range(rnd.randint(0, 7)))))
bad = 0
open(P("parts.txt"), "w", encoding="utf-8").write("\n".join(f"{n}\t{spec}" for n, spec in fixed) + "\n")
got_all = java("parts-batch", P("parts.txt"))
check(len(got_all) == len(fixed), "bản Java trả đủ kết quả cho mọi chuỗi")
for (n, spec), got in zip(fixed, got_all):
    exp = ref_parts(n, spec)
    expect = "LOI" if exp is None else "".join(f"{a}-{b};" for a, b in exp)
    if got != expect: bad += 1; print("  khac:", n, repr(spec), got, expect)
check(bad == 0, f"phạm vi tách: {len(fixed)} chuỗi khớp bản tham chiếu độc lập")

print("== E. EPUB -> HTML / Markdown (theo chuong) ==")
import html.parser, json
def enc(s):   # cung quy uoc voi export_check.enc / ExportCheck.unesc
    return s.replace("\\", "\\\\").replace("\n", "\\n").replace("\t", "\\t").replace("\r", "\\r")
NASTY = ["# khong phai tieu de", "- khong phai danh sach", "1. khong phai so thu tu", "*nghieng* va **dam** va _gach_", "<b>khong phai the</b> & &amp; &lt;", "| a | b |", "~~~ === ---", "[lien ket](http://x) `ma` \\ ngoac", "Đoạn tiếng Việt có dấu: ắ ằ ẳ ẵ ặ, ‘nháy’ “kép”", "+ cong va > trich dan"]
CHAPS = [("Mở đầu", NASTY[:4]), ("1. Chương <đặc biệt> & *sao* #1", NASTY[4:8]), ("Kết", NASTY[8:])]
BTITLE = "Sách <script> & \"x\" 'y' *z*"
inp = P("chap.in")
with open(inp, "w", encoding="utf-8") as f:
    f.write("TITLE\t" + enc(BTITLE) + "\n")
    for t, ps in CHAPS:
        f.write("CHAP\t" + enc(t) + "\n")
        for q in ps: f.write("PARA\t" + enc(q) + "\n")
def run_export(kind, out):
    r = subprocess.run(["java", os.path.join(HERE, "ExportCheck.java"), kind, inp, out], capture_output=True, text=True)
    if r.returncode != 0: print(r.stderr[-800:])
    return open(out, encoding="utf-8").read()
class Col(html.parser.HTMLParser):
    def __init__(self): super().__init__(); self.stack, self.tags, self.text = [], [], {}
    def handle_starttag(self, tag, attrs): self.tags.append(tag); self.stack.append(tag)
    def handle_endtag(self, tag):
        if self.stack and self.stack[-1] == tag: self.stack.pop()
    def handle_data(self, d):
        if self.stack: self.text.setdefault(self.stack[-1], []).append(d)
norm = lambda s: " ".join(s.split())
raw = run_export("chtml", P("c.html"))
c = Col(); c.feed(raw)
extra = set(c.tags) - {"html", "head", "meta", "title", "style", "body", "h1", "section", "h2", "p"}
check(not extra, f"html: khong co the la lot tu van ban (thua {sorted(extra)})")
check(norm(" ".join(c.text.get("p", []))) == norm(" ".join(q for _, ps in CHAPS for q in ps)), "html: toan bo chu trong <p> = cac doan dua vao")
check([norm(x) for x in c.text.get("h2", [])] == [norm(t) for t, _ in CHAPS] and norm("".join(c.text.get("h1", []))) == norm(BTITLE), "html: <h1> ten sach va cac <h2> ten chuong dung (co < > & *)")
r = subprocess.run(["pandoc", "-f", "html", "-t", "plain", "--wrap=none", P("c.html")], capture_output=True, text=True)
check(r.returncode == 0 and all(norm(q)[:25] in norm(r.stdout) for _, ps in CHAPS for q in ps[:1]), "html: pandoc doc duoc")
mdraw = run_export("cmd", P("c.md"))
r = subprocess.run(["pandoc", "-f", "commonmark", "-t", "json", P("c.md")], capture_output=True, text=True)
ast = json.loads(r.stdout); blocks = ast["blocks"]
def flat(x, out):
    if isinstance(x, list):
        for y in x: flat(y, out)
    elif isinstance(x, dict):
        t = x.get("t"); c = x.get("c")
        if t == "Str": out.append(c)
        elif t in ("Space", "SoftBreak", "LineBreak"): out.append(" ")
        elif t in ("Code", "RawInline"): out.append(c[1])
        elif c is not None: flat(c, out)
def textof(b): o = []; flat(b.get("c"), o); return norm("".join(o))
kinds = {b["t"] for b in blocks}
check(kinds <= {"Header", "Para"}, f"markdown: pandoc chi thay tieu de / doan van (thay {sorted(kinds)})")
hs = [b for b in blocks if b["t"] == "Header"]
check(len(hs) == 1 + len(CHAPS) and hs[0]["c"][0] == 1 and all(h["c"][0] == 2 for h in hs[1:]), f"markdown: 1 tieu de cap 1 + {len(CHAPS)} tieu de chuong cap 2")
check([textof({"c": h["c"][2]}) for h in hs[1:]] == [norm(t) for t, _ in CHAPS], "markdown: ten chuong giu nguyen chu (1. * # < > &)")
paras = [textof(b) for b in blocks if b["t"] == "Para"]
check(paras == [norm(q) for _, ps in CHAPS for q in ps], "markdown: moi doan trong pandoc = doan dua vao (10 doan co ky tu Markdown)")

shutil.rmtree(tmp, ignore_errors=True)
print("\nTAT CA DAT" if not FAILS else f"\n{len(FAILS)} LOI")
sys.exit(1 if FAILS else 0)
