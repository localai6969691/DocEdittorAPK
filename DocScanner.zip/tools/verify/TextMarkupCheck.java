// Bản Java chạy được của PdfTextMarkup.findPhrase / wordsInRect / lineBoxes (phiên 17): cùng logic, cùng thứ tự.
// Dùng bởi text_markup_check.py: java TextMarkupCheck.java <tệp ca> <tệp ra>.
// Ca (phân cách bằng dòng "---"): "Q\t<cụm từ>", "R\tl\tt\tr\tb", rồi các từ "W\t<dòng>\tl\tt\tr\tb\t<chữ>". Ra mỗi ca: một dòng "M a-b,..|I i,j|B l t r b;...".
import java.nio.file.*;
import java.text.Normalizer;
import java.util.*;
import java.util.regex.*;

public class TextMarkupCheck {
    static final float LINE_PAD = 0.08f;
    static class Word { String text; float[] box; int line; }

    static String normalize(String text) {
        String s = Normalizer.normalize(text.toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        return Pattern.compile("\\p{Mn}+").matcher(s).replaceAll("").replace('đ', 'd');
    }
    static String keepAlnum(String s) { StringBuilder b = new StringBuilder(); for (char c : s.toCharArray()) if (Character.isLetterOrDigit(c)) b.append(c); return b.toString(); }
    static String fold(String s) { return keepAlnum(normalize(s)); }

    static List<int[]> findPhrase(List<Word> words, String query) {
        List<String> q = new ArrayList<>();
        for (String w : normalize(query).split("\\s+")) { String f = keepAlnum(w); if (!f.isEmpty()) q.add(f); }
        List<int[]> out = new ArrayList<>();
        if (q.isEmpty()) return out;
        List<Integer> idx = new ArrayList<>(); List<String> folded = new ArrayList<>();
        for (int i = 0; i < words.size(); i++) { String f = fold(words.get(i).text); if (!f.isEmpty()) { idx.add(i); folded.add(f); } }
        int i = 0;
        while (i + q.size() <= folded.size()) {
            boolean ok = true;
            for (int k = 0; k < q.size(); k++) {
                String w = folded.get(i + k); boolean hit;
                if (q.size() == 1) hit = w.contains(q.get(0));
                else if (k == 0) hit = w.endsWith(q.get(0));
                else if (k == q.size() - 1) hit = w.startsWith(q.get(k));
                else hit = w.equals(q.get(k));
                if (!hit) { ok = false; break; }
            }
            if (ok) { out.add(new int[]{idx.get(i), idx.get(i + q.size() - 1)}); i += q.size(); } else i++;
        }
        return out;
    }

    static List<Integer> wordsInRect(List<Word> words, float[] r) {
        float l = Math.min(r[0], r[2]), rr = Math.max(r[0], r[2]), t = Math.min(r[1], r[3]), b = Math.max(r[1], r[3]);
        List<Integer> out = new ArrayList<>();
        for (int i = 0; i < words.size(); i++) {
            float[] bx = words.get(i).box; float cx = (bx[0] + bx[2]) / 2f, cy = (bx[1] + bx[3]) / 2f;
            if (cx >= l && cx <= rr && cy >= t && cy <= b) out.add(i);
        }
        return out;
    }

    static List<float[]> lineBoxes(List<Word> words, Collection<Integer> chosen) {
        TreeMap<Integer, float[]> byLine = new TreeMap<>();
        for (int i : new TreeSet<>(chosen)) {
            if (i < 0 || i >= words.size()) continue;
            Word w = words.get(i); float[] cur = byLine.get(w.line);
            if (cur == null) byLine.put(w.line, w.box.clone());
            else { cur[0] = Math.min(cur[0], w.box[0]); cur[1] = Math.min(cur[1], w.box[1]); cur[2] = Math.max(cur[2], w.box[2]); cur[3] = Math.max(cur[3], w.box[3]); }
        }
        List<float[]> out = new ArrayList<>();
        for (float[] b : byLine.values()) {
            float pad = (b[3] - b[1]) * LINE_PAD;
            out.add(new float[]{clamp(b[0]), clamp(b[1] - pad), clamp(b[2]), clamp(b[3] + pad)});
        }
        return out;
    }
    static float clamp(float v) { return Math.max(0f, Math.min(1f, v)); }

    public static void main(String[] a) throws Exception {
        List<String> lines = Files.readAllLines(Paths.get(a[0]));
        StringBuilder res = new StringBuilder();
        String query = ""; float[] rect = null; List<Word> words = new ArrayList<>(); boolean seen = false;
        lines.add("---");
        for (String ln : lines) {
            if (ln.equals("---")) {
                if (seen) {
                    List<int[]> m = findPhrase(words, query);
                    TreeSet<Integer> chosen = new TreeSet<>();
                    StringBuilder ms = new StringBuilder();
                    for (int[] r : m) { ms.append(ms.length() > 0 ? "," : "").append(r[0]).append("-").append(r[1]); for (int i = r[0]; i <= r[1]; i++) chosen.add(i); }
                    List<Integer> inr = rect == null ? new ArrayList<>() : wordsInRect(words, rect);
                    StringBuilder is = new StringBuilder();
                    for (int i : inr) is.append(is.length() > 0 ? "," : "").append(i);
                    TreeSet<Integer> all = new TreeSet<>(chosen); all.addAll(inr);
                    StringBuilder bs = new StringBuilder();
                    for (float[] b : lineBoxes(words, all)) bs.append(bs.length() > 0 ? ";" : "").append(String.format(Locale.US, "%.4f %.4f %.4f %.4f", b[0], b[1], b[2], b[3]));
                    res.append("M ").append(ms).append("|I ").append(is).append("|B ").append(bs).append("\n");
                }
                query = ""; rect = null; words = new ArrayList<>(); seen = false;
                continue;
            }
            seen = true;
            String[] p = ln.split("\t", -1);
            if (p[0].equals("Q")) query = p.length > 1 ? p[1] : "";
            else if (p[0].equals("R")) rect = new float[]{Float.parseFloat(p[1]), Float.parseFloat(p[2]), Float.parseFloat(p[3]), Float.parseFloat(p[4])};
            else if (p[0].equals("W")) { Word w = new Word(); w.line = Integer.parseInt(p[1]); w.box = new float[]{Float.parseFloat(p[2]), Float.parseFloat(p[3]), Float.parseFloat(p[4]), Float.parseFloat(p[5])}; w.text = p[6]; words.add(w); }
        }
        Files.writeString(Paths.get(a[1]), res.toString());
    }
}
