// Bản Java chạy được của PageRanges.parse / everyN / label (phiên 16): cùng logic, cùng thứ tự kiểm tra.
// Dùng bởi page_ranges_check.py: java PageRangesCheck.java <tệp ca> <tệp ra>. Mỗi dòng ca: "<số trang>\t<chuỗi>" ; ra: "OK\t<nhóm>" hoặc "ERR\t<lý do>\t<mảnh>".
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class PageRangesCheck {
    static final Pattern TOKEN = Pattern.compile("(\\d*)\\s*(-?)\\s*(\\d*)");

    static String parse(String spec, int pageCount) {
        List<String> tokens = new ArrayList<>();
        for (String t : spec.split("[,;]", -1)) { t = t.strip(); if (!t.isEmpty()) tokens.add(t); }
        if (tokens.isEmpty()) return "ERR\tEMPTY\t";
        List<String> groups = new ArrayList<>();
        for (String token : tokens) {
            Matcher m = TOKEN.matcher(token);
            if (!m.matches()) return "ERR\tSYNTAX\t" + token;
            String a = m.group(1), dash = m.group(2), b = m.group(3);
            if ((dash.isEmpty() && (a.isEmpty() || !b.isEmpty())) || (a.isEmpty() && b.isEmpty())) return "ERR\tSYNTAX\t" + token;
            long from, to;
            if (a.isEmpty()) from = 1; else { try { from = Long.parseLong(a); } catch (NumberFormatException e) { return "ERR\tOUT_OF_RANGE\t" + token; } }
            if (dash.isEmpty()) to = from;
            else if (b.isEmpty()) to = pageCount;
            else { try { to = Long.parseLong(b); } catch (NumberFormatException e) { return "ERR\tOUT_OF_RANGE\t" + token; } }
            if (from < 1 || from > pageCount || to < 1 || to > pageCount) return "ERR\tOUT_OF_RANGE\t" + token;
            if (from > to) return "ERR\tREVERSED\t" + token;
            StringBuilder g = new StringBuilder();
            for (long i = from - 1; i < to; i++) g.append(i == from - 1 ? "" : ",").append(i);
            groups.add(g.toString());
        }
        return "OK\t" + String.join("|", groups);
    }

    public static void main(String[] args) throws Exception {
        List<String> out = new ArrayList<>();
        for (String line : Files.readAllLines(Paths.get(args[0]), StandardCharsets.UTF_8)) {
            int tab = line.indexOf('\t');
            out.add(parse(line.substring(tab + 1), Integer.parseInt(line.substring(0, tab))));
        }
        Files.write(Paths.get(args[1]), out, StandardCharsets.UTF_8);
    }
}
