// Bản Java song song (chạy được trên máy tính) của phần thuật toán trong app/.../util/PdfComparer.kt (phiên 15):
// căn chỉnh theo ô, so sánh có dung sai, gom vùng, chữ ký trang và ghép trang. Cùng cấu trúc, cùng hằng số, dùng double như numpy.
// Dùng bởi tools/verify/compare_java_check.py:
//   java CompareCheck.java pair <a.raw> <b.raw> <w> <h>        -> in "BOX x y w h" cho mỗi hộp + "GLOBAL dx dy"
//   java CompareCheck.java pages <w> <h> <nOld> <nNew> <files...> -> in "PAIR i j" (0-based) cho các cặp được ghép
// Tệp .raw: w*h byte độ sáng (0-255), từng hàng một.
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class CompareCheck {

    static final double THRESHOLD = 32;
    static final int BLOCK = 16;
    static final int MIN_PIXELS = 8;
    static final int TILE = 64;
    static final int GLOBAL_RANGE = 5;
    static final int AFFINE_MIN_TILES = 6;
    static final double AFFINE_MAX_LINEAR = 0.08;
    static final int[] PYRAMID = {8, 4, 2};
    static final int LEVEL_RANGE = 2;
    static final double[] PYR_OUTLIER_PX = {8.0, 4.0, 2.5};
    static final double SHIFT_PENALTY = 0.05;
    static final double FLAT_SPREAD = 40;
    static final double BLUR_SIGMA = 1.0;
    static final int SIG_W = 96, SIG_H = 128;
    static final double SIG_SIGMA = 1.5;
    static final double MATCH_MIN = 0.5;

    // ---------- Plane ----------
    static final class Plane {
        final int w, h; final double[] d;
        Plane(int w, int h, double[] d) { this.w = w; this.h = h; this.d = d; }
    }

    static Plane boxDown(double[] src, int w, int h, int f) {
        int nw = w / f, nh = h / f;
        double[] out = new double[nw * nh];
        for (int y = 0; y < nh; y++) for (int x = 0; x < nw; x++) {
            double s = 0;
            for (int j = 0; j < f; j++) for (int i = 0; i < f; i++) s += src[(y * f + j) * w + x * f + i];
            out[y * nw + x] = s / (f * f);
        }
        return new Plane(nw, nh, out);
    }

    static double sad(Plane a, Plane b, int u, int v) {
        int w = a.w, h = a.h;
        int x0 = Math.max(0, -u), x1 = Math.min(w, w - u);
        int y0 = Math.max(0, -v), y1 = Math.min(h, h - v);
        if (x1 <= x0 || y1 <= y0) return 1e9;
        double s = 0;
        for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) s += Math.abs(a.d[y * w + x] - b.d[(y + v) * w + x + u]);
        return s / ((double) (x1 - x0) * (y1 - y0));
    }

    static double[] ink(double[] lum) {
        double[] r = new double[lum.length];
        for (int i = 0; i < r.length; i++) r[i] = 255.0 - lum[i];
        return r;
    }

    static int[] estimateGlobal(double[] a, double[] b, int w, int h) {
        Plane a4 = boxDown(ink(a), w, h, 4), b4 = boxDown(ink(b), w, h, 4);
        double best = Double.NaN; int bu = 0, bv = 0; boolean have = false;
        for (int v = -GLOBAL_RANGE; v <= GLOBAL_RANGE; v++) for (int u = -GLOBAL_RANGE; u <= GLOBAL_RANGE; u++) {
            double c = sad(a4, b4, u, v) + SHIFT_PENALTY * (Math.abs(u) + Math.abs(v));
            if (!have || c < best) { best = c; bu = u; bv = v; have = true; }
        }
        return new int[]{bu * 4, bv * 4};
    }

    static void refineTiles(double[] a, double[] b, int w, int h, int[] shifts, int nty, int ntx) {
        int ts = TILE * 2;
        for (int ty = 0; ty < nty; ty++) for (int tx = 0; tx < ntx; tx++) {
            int y0 = ty * ts, y1 = Math.min((ty + 1) * ts, h), x0 = tx * ts, x1 = Math.min((tx + 1) * ts, w);
            if (y0 >= h || x0 >= w) continue;
            double mx = -1e18, mn = 1e18;
            for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) { double v = 255.0 - a[y * w + x]; if (v > mx) mx = v; if (v < mn) mn = v; }
            if (mx - mn < FLAT_SPREAD) continue;
            int dx = shifts[2 * (ty * ntx + tx)], dy = shifts[2 * (ty * ntx + tx) + 1];
            double best = 0; int bx = dx, by = dy; boolean have = false;
            int[] order = {0, -1, 1};
            for (int j : order) for (int i : order) {
                int u = dx + i, v = dy + j;
                double s = 0;
                for (int y = y0; y < y1; y++) {
                    int sy = y + v;
                    for (int x = x0; x < x1; x++) {
                        int sx = x + u;
                        double bv = (sy >= 0 && sy < h && sx >= 0 && sx < w) ? 255.0 - b[sy * w + sx] : 0.0;
                        s += Math.abs((255.0 - a[y * w + x]) - bv);
                    }
                }
                double c = s / ((double) (y1 - y0) * (x1 - x0));
                if (!have || c < best - 1e-9) { best = c; bx = u; by = v; have = true; }
            }
            shifts[2 * (ty * ntx + tx)] = bx; shifts[2 * (ty * ntx + tx) + 1] = by;
        }
    }

    static double[] alignB(double[] b, int w, int h, int[] shifts, int nty, int ntx) {
        double[] out = new double[w * h];
        Arrays.fill(out, 255.0);
        int ts = TILE * 2;
        for (int ty = 0; ty < nty; ty++) for (int tx = 0; tx < ntx; tx++) {
            int y0 = ty * ts, y1 = Math.min((ty + 1) * ts, h), x0 = tx * ts, x1 = Math.min((tx + 1) * ts, w);
            if (y0 >= h || x0 >= w) continue;
            int dx = shifts[2 * (ty * ntx + tx)], dy = shifts[2 * (ty * ntx + tx) + 1];
            for (int y = y0; y < y1; y++) {
                int sy = y + dy;
                if (sy < 0 || sy >= h) continue;
                for (int x = x0; x < x1; x++) {
                    int sx = x + dx;
                    if (sx >= 0 && sx < w) out[y * w + x] = b[sy * w + sx];
                }
            }
        }
        return out;
    }

    static double[] gaussianBlur(double[] src, int w, int h, double sigma) {
        int r = Math.max(1, (int) Math.ceil(3 * sigma));
        double[] k = new double[2 * r + 1]; double sum = 0;
        for (int i = -r; i <= r; i++) { k[i + r] = Math.exp(-0.5 * (i / sigma) * (i / sigma)); sum += k[i + r]; }
        for (int i = 0; i < k.length; i++) k[i] /= sum;
        double[] tmp = new double[w * h], out = new double[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            double s = 0;
            for (int i = -r; i <= r; i++) { int xx = Math.min(Math.max(x + i, 0), w - 1); s += k[i + r] * src[y * w + xx]; }
            tmp[y * w + x] = s;
        }
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            double s = 0;
            for (int i = -r; i <= r; i++) { int yy = Math.min(Math.max(y + i, 0), h - 1); s += k[i + r] * tmp[yy * w + x]; }
            out[y * w + x] = s;
        }
        return out;
    }

    static boolean[] tolerantMask(double[] a, double[] b, int w, int h) {
        double[] aLo = new double[w * h], aHi = new double[w * h], bLo = new double[w * h], bHi = new double[w * h];
        windowMinMax(a, w, h, aLo, aHi);
        windowMinMax(b, w, h, bLo, bHi);
        boolean[] mask = new boolean[w * h];
        for (int i = 0; i < mask.length; i++) {
            double da = Math.max(Math.max(bLo[i] - a[i], a[i] - bHi[i]), 0);
            double db = Math.max(Math.max(aLo[i] - b[i], b[i] - aHi[i]), 0);
            mask[i] = Math.max(da, db) > THRESHOLD;
        }
        return mask;
    }

    static void windowMinMax(double[] src, int w, int h, double[] lo, double[] hi) {
        double[] rl = new double[w * h], rh = new double[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            double mn = Double.MAX_VALUE, mx = -Double.MAX_VALUE;
            for (int i = -1; i <= 1; i++) { int xx = Math.min(Math.max(x + i, 0), w - 1); double v = src[y * w + xx]; if (v < mn) mn = v; if (v > mx) mx = v; }
            rl[y * w + x] = mn; rh[y * w + x] = mx;
        }
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            double mn = Double.MAX_VALUE, mx = -Double.MAX_VALUE;
            for (int i = -1; i <= 1; i++) { int yy = Math.min(Math.max(y + i, 0), h - 1); double l = rl[yy * w + x], hh = rh[yy * w + x]; if (l < mn) mn = l; if (hh > mx) mx = hh; }
            lo[y * w + x] = mn; hi[y * w + x] = mx;
        }
    }

    static List<int[]> boxesFromMask(boolean[] mask, int w, int h) {
        int bw = (w + BLOCK - 1) / BLOCK, bh = (h + BLOCK - 1) / BLOCK;
        int[] counts = new int[bw * bh];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) if (mask[y * w + x]) counts[(y / BLOCK) * bw + x / BLOCK]++;
        boolean[] changed = new boolean[bw * bh], grouped = new boolean[bw * bh], seen = new boolean[bw * bh];
        for (int i = 0; i < changed.length; i++) changed[i] = counts[i] >= MIN_PIXELS;
        for (int by = 0; by < bh; by++) for (int bx = 0; bx < bw; bx++) {
            if (!changed[by * bw + bx]) continue;
            for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                int nx = bx + dx, ny = by + dy;
                if (nx >= 0 && nx < bw && ny >= 0 && ny < bh) grouped[ny * bw + nx] = true;
            }
        }
        List<int[]> boxes = new ArrayList<>();
        for (int start = 0; start < bw * bh; start++) {
            if (!grouped[start] || seen[start]) continue;
            int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, maxX = -1, maxY = -1;
            ArrayDeque<Integer> stack = new ArrayDeque<>();
            stack.addLast(start); seen[start] = true;
            while (!stack.isEmpty()) {
                int cur = stack.removeLast(); int cx = cur % bw, cy = cur / bw;
                if (changed[cur]) { minX = Math.min(minX, cx); maxX = Math.max(maxX, cx); minY = Math.min(minY, cy); maxY = Math.max(maxY, cy); }
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    int nx = cx + dx, ny = cy + dy;
                    if (nx < 0 || nx >= bw || ny < 0 || ny >= bh) continue;
                    int idx = ny * bw + nx;
                    if (grouped[idx] && !seen[idx]) { seen[idx] = true; stack.addLast(idx); }
                }
            }
            if (maxX < 0) continue;
            int x0 = minX * BLOCK, y0 = minY * BLOCK, x1 = Math.min((maxX + 1) * BLOCK, w), y1 = Math.min((maxY + 1) * BLOCK, h);
            boxes.add(new int[]{x0, y0, x1 - x0, y1 - y0});
        }
        return boxes;
    }


    // ---------- căn chỉnh affine theo kim tự tháp ----------
    /** pq = {p0, p1, p2, q0, q1, q2}: dịch chuyển (dx, dy) = (p0 + p1 x + p2 y, q0 + q1 x + q2 y). */
    static double[] warpAffine(double[] b, int w, int h, double[] pq) {
        double[] out = new double[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            double sx = x + pq[0] + pq[1] * x + pq[2] * y;
            double sy = y + pq[3] + pq[4] * x + pq[5] * y;
            int x0 = (int) Math.floor(sx), y0 = (int) Math.floor(sy);
            double fx = sx - x0, fy = sy - y0;
            out[y * w + x] = at(b, w, h, y0, x0) * (1 - fx) * (1 - fy) + at(b, w, h, y0, x0 + 1) * fx * (1 - fy)
                    + at(b, w, h, y0 + 1, x0) * (1 - fx) * fy + at(b, w, h, y0 + 1, x0 + 1) * fx * fy;
        }
        return out;
    }

    static double at(double[] b, int w, int h, int y, int x) {
        return (y >= 0 && y < h && x >= 0 && x < w) ? b[y * w + x] : 255.0;
    }

    /** Giải bình phương tối thiểu 3 ẩn từ các hàng [1, cx, cy] của các điểm giữ lại; null nếu suy biến. */
    static double[] leastSquares(List<double[]> pts, boolean[] keep, int col) {
        double[][] m = new double[3][4];
        for (int i = 0; i < pts.size(); i++) {
            if (!keep[i]) continue;
            double[] p = pts.get(i);
            double[] row = {1.0, p[0], p[1]};
            for (int r = 0; r < 3; r++) { for (int c = 0; c < 3; c++) m[r][c] += row[r] * row[c]; m[r][3] += row[r] * p[col]; }
        }
        for (int c = 0; c < 3; c++) {
            int piv = c;
            for (int r = c + 1; r < 3; r++) if (Math.abs(m[r][c]) > Math.abs(m[piv][c])) piv = r;
            if (Math.abs(m[piv][c]) < 1e-9) return null;
            double[] tmp = m[c]; m[c] = m[piv]; m[piv] = tmp;
            for (int r = 0; r < 3; r++) {
                if (r == c) continue;
                double f = m[r][c] / m[c][c];
                for (int k = c; k < 4; k++) m[r][k] -= f * m[c][k];
            }
        }
        return new double[]{m[0][3] / m[0][0], m[1][3] / m[1][1], m[2][3] / m[2][2]};
    }

    static double[] estimateAffinePyramid(double[] a, double[] b, int w, int h, int[] g) {
        int h2 = h / 2, w2 = w / 2;
        int nty = (h2 + TILE - 1) / TILE, ntx = (w2 + TILE - 1) / TILE;
        double[] pq = {g[0], 0.0, 0.0, g[1], 0.0, 0.0};
        double[] inkA = ink(a);
        for (int f : PYRAMID) {
            double[] bw = ink(warpAffine(b, w, h, pq));
            Plane A = boxDown(inkA, w, h, f), B = boxDown(bw, w, h, f);
            int tile = 128 / f;
            List<double[]> pts = new ArrayList<>();
            for (int ty = 0; ty < nty; ty++) for (int tx = 0; tx < ntx; tx++) {
                int y0 = ty * tile, y1 = Math.min((ty + 1) * tile, A.h), x0 = tx * tile, x1 = Math.min((tx + 1) * tile, A.w);
                if (y1 <= y0 || x1 <= x0) continue;
                double mx = -1e18, mn = 1e18;
                for (int y = y0; y < y1; y++) for (int x = x0; x < x1; x++) { double v = A.d[y * A.w + x]; if (v > mx) mx = v; if (v < mn) mn = v; }
                if (mx - mn < FLAT_SPREAD) continue;
                double best = 0; int bu = 0, bv = 0; boolean have = false;
                for (int dv = -LEVEL_RANGE; dv <= LEVEL_RANGE; dv++) for (int du = -LEVEL_RANGE; du <= LEVEL_RANGE; du++) {
                    double s = 0;
                    for (int y = y0; y < y1; y++) {
                        int sy = y + dv;
                        for (int x = x0; x < x1; x++) {
                            int sx = x + du;
                            double bv2 = (sy >= 0 && sy < B.h && sx >= 0 && sx < B.w) ? B.d[sy * B.w + sx] : 0.0;
                            s += Math.abs(A.d[y * A.w + x] - bv2);
                        }
                    }
                    double c = s / ((double) (y1 - y0) * (x1 - x0)) + SHIFT_PENALTY * (Math.abs(du) + Math.abs(dv));
                    if (!have || c < best) { best = c; bu = du; bv = dv; have = true; }
                }
                double cx = tx * 128 + 64.0, cy = ty * 128 + 64.0;
                double px = pq[0] + pq[1] * cx + pq[2] * cy, py = pq[3] + pq[4] * cx + pq[5] * cy;
                pts.add(new double[]{cx, cy, px + bu * f, py + bv * f});
            }
            if (pts.size() < AFFINE_MIN_TILES) continue;
            boolean[] keep = new boolean[pts.size()];
            Arrays.fill(keep, true);
            double[] fit = null;
            for (double thr : PYR_OUTLIER_PX) {
                int cnt = 0; for (boolean k : keep) if (k) cnt++;
                if (cnt < AFFINE_MIN_TILES) break;
                double[] p = leastSquares(pts, keep, 2), q = leastSquares(pts, keep, 3);
                if (p == null || q == null) break;
                for (int i = 0; i < pts.size(); i++) {
                    double[] pt = pts.get(i);
                    double rx = Math.abs(p[0] + p[1] * pt[0] + p[2] * pt[1] - pt[2]);
                    double ry = Math.abs(q[0] + q[1] * pt[0] + q[2] * pt[1] - pt[3]);
                    keep[i] = Math.max(rx, ry) <= thr;
                }
                fit = new double[]{p[0], p[1], p[2], q[0], q[1], q[2]};
            }
            int cnt = 0; for (boolean k : keep) if (k) cnt++;
            if (fit != null && cnt >= AFFINE_MIN_TILES
                    && Math.max(Math.max(Math.abs(fit[1]), Math.abs(fit[2])), Math.max(Math.abs(fit[4]), Math.abs(fit[5]))) <= AFFINE_MAX_LINEAR) {
                pq = fit;
            }
        }
        return pq;
    }

    static List<int[]> comparePages(double[] a, double[] b, int w, int h, int[] globalOut) {
        int[] g = estimateGlobal(a, b, w, h);
        if (globalOut != null) { globalOut[0] = g[0]; globalOut[1] = g[1]; }
        int nty = (h / 2 + TILE - 1) / TILE, ntx = (w / 2 + TILE - 1) / TILE;
        double[] pq = estimateAffinePyramid(a, b, w, h, g);
        double[] bEff = warpAffine(b, w, h, pq);
        int[] shifts = new int[nty * ntx * 2];          // dư lượng theo ô, bắt đầu từ 0
        refineTiles(a, bEff, w, h, shifts, nty, ntx);
        double[] aligned = alignB(bEff, w, h, shifts, nty, ntx);
        double[] ba = gaussianBlur(a, w, h, BLUR_SIGMA), bb = gaussianBlur(aligned, w, h, BLUR_SIGMA);
        return boxesFromMask(tolerantMask(ba, bb, w, h), w, h);
    }

    // ---------- chữ ký và ghép trang ----------
    static double[] rawSignature(double[] lum, int w, int h) {
        double[] g = new double[SIG_W * SIG_H];
        for (int i = 0; i < SIG_H; i++) {
            int y0 = (int) ((long) i * h / SIG_H), y1 = (int) ((long) (i + 1) * h / SIG_H);
            y1 = Math.max(y1, y0 + 1);
            for (int j = 0; j < SIG_W; j++) {
                int x0 = (int) ((long) j * w / SIG_W), x1 = (int) ((long) (j + 1) * w / SIG_W);
                x1 = Math.max(x1, x0 + 1);
                double s = 0; int n = 0;
                for (int y = y0; y < y1 && y < h; y++) for (int x = x0; x < x1 && x < w; x++) { s += 255.0 - lum[y * w + x]; n++; }
                g[i * SIG_W + j] = n > 0 ? s / n : 0;
            }
        }
        return gaussianBlur(g, SIG_W, SIG_H, SIG_SIGMA);
    }

    static List<double[]> normalizedSignatures(List<double[]> raws) {
        int n = raws.get(0).length;
        double[] mean = new double[n];
        for (double[] r : raws) for (int i = 0; i < n; i++) mean[i] += r[i];
        for (int i = 0; i < n; i++) mean[i] /= raws.size();
        List<double[]> out = new ArrayList<>();
        for (double[] r : raws) {
            double[] x = new double[n]; double m = 0;
            for (int i = 0; i < n; i++) { x[i] = r[i] - mean[i]; m += x[i]; }
            m /= n; double norm = 0;
            for (int i = 0; i < n; i++) { x[i] -= m; norm += x[i] * x[i]; }
            norm = Math.sqrt(norm);
            if (norm > 1e-9) for (int i = 0; i < n; i++) x[i] /= norm;
            out.add(x);
        }
        return out;
    }

    static double dot(double[] a, double[] b) { double s = 0; for (int i = 0; i < a.length; i++) s += a[i] * b[i]; return s; }

    static List<int[]> alignPages(List<double[]> sOld, List<double[]> sNew) {
        int n = sOld.size(), m = sNew.size();
        double[][] sim = new double[n][m];
        for (int i = 0; i < n; i++) for (int j = 0; j < m; j++) sim[i][j] = dot(sOld.get(i), sNew.get(j));
        double[][] dp = new double[n + 1][m + 1];
        for (int i = 1; i <= n; i++) for (int j = 1; j <= m; j++) {
            double best = Math.max(dp[i - 1][j], dp[i][j - 1]);
            double s = sim[i - 1][j - 1];
            if (s >= MATCH_MIN) best = Math.max(best, dp[i - 1][j - 1] + s);
            dp[i][j] = best;
        }
        List<int[]> pairs = new ArrayList<>();
        int i = n, j = m;
        while (i > 0 && j > 0) {
            double s = sim[i - 1][j - 1];
            if (s >= MATCH_MIN && Math.abs(dp[i][j] - (dp[i - 1][j - 1] + s)) < 1e-9) { pairs.add(new int[]{i - 1, j - 1}); i--; j--; }
            else if (Math.abs(dp[i][j] - dp[i - 1][j]) < 1e-9) i--;
            else j--;
        }
        Collections.reverse(pairs);
        return pairs;
    }

    static double[] readRaw(String path, int w, int h) throws IOException {
        byte[] bytes = Files.readAllBytes(Paths.get(path));
        if (bytes.length != w * h) throw new IOException("size " + bytes.length + " != " + (w * h));
        double[] d = new double[w * h];
        for (int i = 0; i < d.length; i++) d[i] = bytes[i] & 0xFF;
        return d;
    }

    public static void main(String[] args) throws Exception {
        if (args[0].equals("pair")) {
            int w = Integer.parseInt(args[3]), h = Integer.parseInt(args[4]);
            double[] a = readRaw(args[1], w, h), b = readRaw(args[2], w, h);
            int[] g = new int[2];
            for (int[] box : comparePages(a, b, w, h, g)) System.out.println("BOX " + box[0] + " " + box[1] + " " + box[2] + " " + box[3]);
            System.out.println("GLOBAL " + g[0] + " " + g[1]);
        } else {
            int w = Integer.parseInt(args[1]), h = Integer.parseInt(args[2]);
            int nOld = Integer.parseInt(args[3]), nNew = Integer.parseInt(args[4]);
            List<double[]> raws = new ArrayList<>();
            for (int i = 0; i < nOld + nNew; i++) raws.add(rawSignature(readRaw(args[5 + i], w, h), w, h));
            List<double[]> sigs = normalizedSignatures(raws);
            for (int[] p : alignPages(sigs.subList(0, nOld), sigs.subList(nOld, nOld + nNew))) System.out.println("PAIR " + p[0] + " " + p[1]);
        }
    }
}
