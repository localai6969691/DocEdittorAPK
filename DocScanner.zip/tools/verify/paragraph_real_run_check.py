#!/usr/bin/env python3
"""Sửa cả ĐOẠN chữ trong khung như WPS / Acrobat CHẠY THẬT (`util/PdfParagraphEditor.kt`; phiên 27, TECHNICAL_DOCS.md 4.89).

WPS / Acrobat: chữ nằm trong một KHUNG; gõ thì chữ tự xuống dòng theo bề rộng khung, khung độc lập (không đẩy khung khác, không sang trang khác).
Biên dịch CHÍNH `PdfParagraphEditor.kt` (+ `PdfTextEditor.kt`) bằng kotlinc trên PdfBox-Android dựng từ nguồn. Mong đợi tính ĐỘC LẬP: reportlab `stringWidth` (số đo phông của bên khác)
cho bước ngắt dòng tham lam; poppler `pdftotext -bbox` đọc lại chữ + toạ độ từng từ; `qpdf --check`. PDF thử dựng bằng reportlab (`drawString` từng dòng, hoặc `textobject` một khối `BT`,
phông Helvetica không nhúng và phông DejaVu nhúng tập con có `/ToUnicode`).
  A. tìm khối (số dòng, bề rộng = dòng dài nhất, không gộp tiêu đề khác cỡ chữ, tách hai đoạn cách xa, bỏ chữ căn đều Tw != 0, một dòng không phải khối);  B. đoạn NGẮN lại: dòng thừa thành rỗng;
C. đoạn DÀI ra: ngắt đúng như tính độc lập, mọi dòng vừa khung, dòng thêm cách đều, chữ phía sau KHÔNG xê dịch (cả khi cùng một BT dùng Td tương đối);  D. xuống dòng thủ công;
  E. từ chối: đè lên chữ khác, tràn khỏi trang, ký tự phông không có (phông nhúng tập con), phông không đọc được -> KHÔNG để lại tệp;  F. phông nhúng tập con; trang xoay 90 độ; hai đoạn cùng lúc; chạm chọn khối.
  G. THỬ ÂM TÍNH: 6 bản mã cố tình làm hỏng phải bị bắt.
KHÔNG kiểm được: chữ căn đều / căn giữa / căn phải / nhiều cột, chữ xoay hoặc dọc (cố ý không coi là khối), giao diện chạm và hộp soạn thảo trên máy thật, gạch nối cuối dòng (không tách từ).
Chạy: python3 tools/verify/paragraph_real_run_check.py [--fast]  (--fast bỏ phần G)"""
import os, re, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
import pikepdf  # noqa: E402
from reportlab.pdfgen import canvas  # noqa: E402
from reportlab.pdfbase import pdfmetrics  # noqa: E402
from reportlab.pdfbase.ttfonts import TTFont  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="para-")
P = lambda n: os.path.join(WORK, n)
DOUBLE = {"PdfVerify.kt": ("    fun opensAsPdf(file: File, expectedPages: Int): Boolean {",
    "    fun opensAsPdf(file: File, expectedPages: Int): Boolean {\n        return try {\n            if (!file.exists() || file.length() <= 0L) return false\n"
    "            com.tom_roush.pdfbox.pdmodel.PDDocument.load(file).use { d -> d.numberOfPages > 0 && (expectedPages <= 0 || d.numberOfPages == expectedPages) }\n        } catch (e: Exception) { false }\n    }")}
FILES = ["PdfParagraphEditor.kt", "PdfTextEditor.kt", "PdfPageGeometry.kt", "PdfVerify.kt", "PdfFormFiller.kt", "PdfStructureOptimizer.kt"]
HARNESS = os.path.join(HERE, "real_run", "ParagraphHarness.kt")
cls = tc.compile(FILES, [HARNESS], os.path.join(WORK, "cls"), None, DOUBLE)[0]
def harness(c, *a):
    r = tc.run(c, "ParagraphHarnessKt", list(a))
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-1200:])
    return [l for l in r.stdout.split("\n") if l.strip()]
def sh(*cmd): return subprocess.run(cmd, capture_output=True, text=True)
def qpdf_ok(pdf): return sh("qpdf", "--check", pdf).returncode == 0
def apply(c, src, out, *edits):
    spec = []
    for i, (page, first, text) in enumerate(edits):
        tf = P(f"txt{abs(hash((out, i))) % 10**8}.txt"); open(tf, "w", encoding="utf-8").write(text); spec.append(f"{page}:{first}:{tf}")
    if os.path.exists(out): os.remove(out)
    return harness(c, "apply", src, out, ",".join(spec))[0]

# ------------------------------------------------------------------ independent pieces: wrapping with reportlab's metrics, reading back with poppler
def width(text, font="Helvetica", size=12): return pdfmetrics.stringWidth(text, font, size)
def wrap(text, maxw, font="Helvetica", size=12, measure=None):
    width = measure or (lambda t, f=font, z=size: pdfmetrics.stringWidth(t, f, z))   # noqa: F811
    lines = []
    for para in text.split("\n"):
        cur = ""
        for w in [x for x in para.split(" ") if x]:
            if not cur: cur = w
            elif width(cur + " " + w) <= maxw + 0.02: cur += " " + w
            else: lines.append(cur); cur = w
        lines.append(cur)
    return lines
def words(pdf, page=1):
    out = sh("pdftotext", "-bbox", "-f", str(page), "-l", str(page), pdf, "-").stdout
    return [(float(a), float(b), float(c), float(d), t) for a, b, c, d, t in re.findall(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(.*?)</word>', out)]
def text_lines(pdf, page=1):
    """lines as (yMin, xMin, xMax, text), grouped by y (poppler's own coordinates: y down from the top)."""
    rows = []
    for x0, y0, x1, y1, t in sorted(words(pdf, page), key=lambda w: (round(w[1]), w[0])):
        if rows and abs(rows[-1][0] - y0) < 2: rows[-1][2] = x1; rows[-1][3].append(t)
        else: rows.append([y0, x0, x1, [t]])
    return [(r[0], r[1], r[2], " ".join(r[3])) for r in rows]
import html
def lines_text(pdf, page=1): return [html.unescape(l[3]) for l in text_lines(pdf, page)]

SRC_TEXT = ("The quick brown fox jumps over the lazy dog while the small committee quietly reviews every single proposal before lunch, "
            "and nobody asks why the report keeps growing. Later that afternoon the tired clerk files another form, sighs, and wonders whether the archive will ever "
            "be finished before the building closes for the long winter holiday.")
W0 = 300.0
ORIG = wrap(SRC_TEXT, W0)
def make_pdf(path, para_lines, x=72, y=700, step=16, font="Helvetica", size=12, extras=(), mode="draw", rotate=0, wordspace=0, extra_blocks=()):
    c = canvas.Canvas(path, pagesize=(612, 792))
    for ex in extras:
        c.setFont(ex[0], ex[1]); c.drawString(ex[2], ex[3], ex[4])
    if mode == "draw":
        c.setFont(font, size)
        if wordspace:
            t = c.beginText(x, y); t.setFont(font, size); t.setLeading(step); t.setWordSpace(wordspace)
            for l in para_lines: t.textLine(l)
            c.drawText(t)
        else:
            for i, l in enumerate(para_lines): c.drawString(x, y - i * step, l)
    else:
        t = c.beginText(x, y); t.setFont(font, size); t.setLeading(step)
        for l in para_lines: t.textLine(l)
        t.moveCursor(0, 60); t.setFont(font, 9); t.textLine("Footer note after the paragraph")
        c.drawText(t)
    for (bx, by, blines) in extra_blocks:
        c.setFont(font, size)
        for i, l in enumerate(blines): c.drawString(bx, by - i * step, l)
    c.showPage(); c.save()
    if rotate:
        with pikepdf.open(path, allow_overwriting_input=True) as pdf:
            pdf.pages[0].Rotate = rotate; pdf.save(path)
def blocks(c, pdf, page=1):
    out = []
    for l in harness(c, "blocks", pdf, str(page)):
        head, text, pl = [s.strip() for s in l.split("|", 2)]
        h = head.split(); out.append((int(h[0]), int(h[1]), float(h[2]), float(h[3]), text, pl))
    return out

BASE = P("base.pdf"); make_pdf(BASE, ORIG, extras=[("Helvetica-Bold", 18, 72, 750, "Heading of the page"), ("Helvetica", 12, 72, 300, "Unrelated sentence far below the paragraph.")])
# NOTE: reportlab writes the page-level extras FIRST, so the paragraph's first line is operator number 2
print("== A. tìm khối")
B = blocks(cls, BASE)
check(len(B) == 1, f"1 khối (tiêu đề cỡ 18 và câu lẻ không bị gộp): {len(B)}")
b = B[0]
check(b[1] == len(ORIG) and b[0] == 2, f"{len(ORIG)} dòng, dòng đầu là toán tử số 2: lineCount={b[1]} first={b[0]}")
check(abs(b[2] - max(width(l) for l in ORIG)) < 0.5 and b[3] == 12.0, f"bề rộng khung = dòng dài nhất ({max(width(l) for l in ORIG):.2f}): {b[2]}")
check(b[4] == SRC_TEXT, "văn bản khối = các dòng nối bằng dấu cách (đúng đoạn gốc)")
two = P("two.pdf"); make_pdf(two, ORIG[:3], y=700, extra_blocks=[(72, 400, ORIG[3:6])])
B2 = blocks(cls, two); check(len(B2) == 2 and B2[0][1] == 3 and B2[1][1] == 3, f"hai đoạn cách xa là HAI khối 3 + 3 dòng: {[(x[0], x[1]) for x in B2]}")
ws = P("ws.pdf"); make_pdf(ws, ORIG, wordspace=2.5); check(blocks(cls, ws) == [], "chữ có Tw != 0 (căn đều) không coi là khối")
one = P("one.pdf"); make_pdf(one, ORIG[:1]); check(blocks(cls, one) == [], "một dòng không phải khối (đã có sửa chữ ngắn)")
ind = P("ind.pdf"); c = canvas.Canvas(ind, pagesize=(612, 792)); c.setFont("Helvetica", 12)
for i, l in enumerate(ORIG[:3]): c.drawString(72 + (30 if i == 1 else 0), 700 - 16 * i, l)
c.showPage(); c.save(); check(blocks(cls, ind) == [], "dòng lệch lề trái giữa chừng -> không phải khối")
gap = P("gap.pdf"); c = canvas.Canvas(gap, pagesize=(612, 792)); c.setFont("Helvetica", 12)
for i, y in enumerate((700, 684, 668, 600, 584)): c.drawString(72, y, ORIG[i])
c.showPage(); c.save(); G = blocks(cls, gap); check([x[1] for x in G] == [3, 2], f"khoảng trống lớn tách khối 3 + 2: {[x[1] for x in G]}")
pk = harness(cls, "pick", BASE, "1", "0.2", "0.2")[0]
check(pk == "2" and harness(cls, "pick", BASE, "1", "0.2", "0.9")[0] == "-", f"chạm vào đoạn -> chọn khối (số 2), chạm chỗ trống -> không có: {pk}")

print("== B. đoạn ngắn lại")
NEW_SHORT = "Short and sweet: this paragraph now says much less than before."
out = P("short.pdf"); check(apply(cls, BASE, out, (1, 2, NEW_SHORT)) == "OK", "viết lại ngắn hơn")
exp = wrap(NEW_SHORT, b[2]); got = lines_text(out)
para = [t for t in got if t not in ("Heading of the page", "Unrelated sentence far below the paragraph.")]
check(para == exp, f"các dòng đúng như ngắt dòng độc lập: {para} (mong đợi {exp})")
check("Heading of the page" in got and "Unrelated sentence far below the paragraph." in got, "tiêu đề và câu lẻ nguyên vẹn")
check(qpdf_ok(out), "qpdf --check sạch")

print("== C. đoạn dài ra")
NEW_LONG = SRC_TEXT + " Meanwhile the intern, who had been waiting patiently in the corridor, finally received a coffee and a polite apology from the manager."
out = P("long.pdf"); check(apply(cls, BASE, out, (1, 2, NEW_LONG)) == "OK", "viết dài hơn (thêm dòng)")
exp = wrap(NEW_LONG, b[2]); L = text_lines(out)
para_rows = [r for r in L if r[3] not in ("Heading of the page", "Unrelated sentence far below the paragraph.")]
check([html.unescape(r[3]) for r in para_rows] == exp and len(exp) > len(ORIG), f"{len(exp)} dòng đúng như ngắt dòng độc lập")
check(all(abs(r[1] - 72) < 0.6 for r in para_rows), "mọi dòng cùng lề trái 72")
check(all(width(l) <= b[2] + 0.1 for l in exp) and all((r[2] - r[1]) <= b[2] + 0.5 for r in para_rows), "không dòng nào vượt bề rộng khung")
ys = [r[0] for r in para_rows]; d = [ys[i + 1] - ys[i] for i in range(len(ys) - 1)]
check(all(abs(x - 16) < 0.6 for x in d), f"các dòng cách đều 16pt: {[round(x, 2) for x in d]}")
un = [r for r in L if r[3].startswith("Unrelated")][0]; un0 = [r for r in text_lines(BASE) if r[3].startswith("Unrelated")][0]
check(abs(un[0] - un0[0]) < 0.3 and abs(un[1] - un0[1]) < 0.3, "câu lẻ bên dưới KHÔNG xê dịch")
check(qpdf_ok(out), "qpdf --check sạch")

print("== C2. cùng một khối BT (Td / T* tương đối), chữ phía sau không xê dịch")
BT = P("bt.pdf"); make_pdf(BT, ORIG, mode="text")
bb = blocks(cls, BT); check(len(bb) == 1 and bb[0][1] == len(ORIG), f"khối trong một BT: {[(x[0], x[1]) for x in bb]}")
f0 = [r for r in text_lines(BT) if r[3].startswith("Footer")][0]
out = P("bt-long.pdf"); check(apply(cls, BT, out, (1, bb[0][0], NEW_LONG)) == "OK", "viết dài hơn trong một BT")
f1 = [r for r in text_lines(out) if r[3].startswith("Footer")]
check(len(f1) == 1 and abs(f1[0][0] - f0[0]) < 0.3 and abs(f1[0][1] - f0[1]) < 0.3, f"dòng chân trang (Td tương đối sau đoạn) vẫn đúng chỗ: {f1[0][:2] if f1 else None} so với {f0[:2]}")
out = P("bt-short.pdf"); apply(cls, BT, out, (1, bb[0][0], NEW_SHORT)); f2 = [r for r in text_lines(out) if r[3].startswith("Footer")]
check(len(f2) == 1 and abs(f2[0][0] - f0[0]) < 0.3, "ngắn lại trong một BT: chân trang vẫn đúng chỗ")
check(qpdf_ok(out), "qpdf --check sạch")

print("== D. xuống dòng thủ công")
out = P("nl.pdf"); apply(cls, BASE, out, (1, 2, "First paragraph line.\nSecond starts here and is a bit longer than the first one is.\n\nAfter a blank line."))
exp = wrap("First paragraph line.\nSecond starts here and is a bit longer than the first one is.\n\nAfter a blank line.", b[2]); got = [t for t in lines_text(out) if t not in ("Heading of the page", "Unrelated sentence far below the paragraph.")]
check(got == [e for e in exp if e], f"dấu xuống dòng ép ngắt dòng (dòng trống không có chữ): {got}")

print("== E. từ chối")
over = P("over.pdf"); make_pdf(over, ORIG, extras=[("Helvetica", 12, 72, 700 - 16 * len(ORIG) - 8, "Text directly under the paragraph")])
ob = blocks(cls, over)[0]
r1 = apply(cls, over, P("o1.pdf"), (1, ob[0], NEW_LONG)); check(r1.startswith("ERR:") and "Overlaps" in r1 and not os.path.exists(P("o1.pdf")), f"thêm dòng sẽ đè lên chữ bên dưới -> từ chối, không để lại tệp: {r1[:90]}")
r2 = apply(cls, over, P("o2.pdf"), (1, ob[0], NEW_SHORT)); check(r2 == "OK", "cùng đoạn viết NGẮN lại (không thêm dòng) thì được")
low = P("low.pdf"); make_pdf(low, ORIG, y=70)
lb = blocks(cls, low)[0]; r3 = apply(cls, low, P("o3.pdf"), (1, lb[0], NEW_LONG * 3)); check(r3.startswith("ERR:") and "OffPage" in r3 and not os.path.exists(P("o3.pdf")), f"tràn khỏi đáy trang -> từ chối: {r3[:90]}")
r4 = apply(cls, BASE, P("o4.pdf"), (1, 2, "Chữ Hán 漢字 không có trong phông")); check(r4.startswith("ERR:") and "MissingGlyphs" in r4 and not os.path.exists(P("o4.pdf")), f"ký tự phông không có -> từ chối: {r4[:100]}")
r5 = apply(cls, BASE, P("o5.pdf"), (1, 0, "x")); check(r5.startswith("ERR:") and "NotFound" in r5, f"chỉ số không phải dòng đầu của khối -> từ chối: {r5[:90]}")
r6 = apply(cls, BASE, P("o6.pdf"), (3, 2, "x")); check(r6.startswith("ERR:") and not os.path.exists(P("o6.pdf")), "trang không có -> lỗi")
r7 = apply(cls, BASE, P("o7.pdf"), (1, 2, "word " * 6000)); check(r7.startswith("ERR:") and "TooManyLines" in r7, "quá nhiều dòng -> từ chối")

print("== F. phông nhúng tập con / trang xoay / hai đoạn / nhiều lần")
import shutil
if shutil.which("soffice"):
    # a REAL producer: LibreOffice writes a subset TrueType font with an exact /ToUnicode (only the characters the document uses), like Word / Chrome do
    os.makedirs(P("lo"), exist_ok=True); open(P("lo/para.txt"), "w").write(SRC_TEXT + "\n")
    subprocess.run(["soffice", f"-env:UserInstallation=file://{P('lo-profile')}", "--headless", "--convert-to", "pdf", "--outdir", P("lo"), P("lo/para.txt")], capture_output=True, timeout=240)
    EM = P("lo/para.pdf")
    eb = blocks(cls, EM); check(len(eb) == 1 and eb[0][1] >= 4, f"PDF do LibreOffice (phông nhúng tập con): tìm được khối: {[(x[0], x[1]) for x in eb]}")
    with pikepdf.open(EM) as pdf:
        tf = [ops for ops, op in pikepdf.parse_content_stream(pdf.pages[0]) if str(op) == "Tf"][0]; fsize = float(tf[1])
    mono = lambda t: 0.6 * fsize * len(t)            # Liberation Mono: every glyph is 600 / 1000 em wide (independent of the code under test)
    check(abs(eb[0][2] - max(mono(l) for l in lines_text(EM))) < 0.6, f"bề rộng khối = dòng dài nhất tính độc lập: {eb[0][2]:.2f}")
    NEWE = "The quick fox files the report while the lazy committee reviews every proposal before the building closes."
    out = P("emb-out.pdf"); r = apply(cls, EM, out, (1, eb[0][0], NEWE)); check(r == "OK", f"viết lại bằng chữ có trong tập con: {r[:100]}")
    exp = wrap(NEWE, eb[0][2], measure=mono); check(lines_text(out) == exp, f"phông nhúng: dòng đúng như tính độc lập: {lines_text(out)} (mong đợi {exp})")
    check(qpdf_ok(out), "phông nhúng: qpdf --check sạch")
    r = apply(cls, EM, P("emb-bad.pdf"), (1, eb[0][0], "Zebra quickly jumped over the dog")); check(r.startswith("ERR:") and "MissingGlyphs" in r and not os.path.exists(P("emb-bad.pdf")), f"chữ HOA Z không có trong tập con -> từ chối: {r[:100]}")
else:
    print("bỏ qua: không có soffice (CI có libreoffice)")
R90 = P("r90.pdf"); make_pdf(R90, ORIG, rotate=90); rb = blocks(cls, R90); check(len(rb) == 1 and rb[0][5] != "-", f"trang xoay 90: có khối, có vị trí trên trang nhìn thấy: {rb[0][5] if rb else None}")
out = P("r90-out.pdf"); check(apply(cls, R90, out, (1, rb[0][0], NEW_LONG)) == "OK" and qpdf_ok(out), "trang xoay 90: viết dài hơn")
check(sh("pdftotext", "-raw", out, "-").stdout.split() == NEW_LONG.split(), "trang xoay 90: đọc lại đủ chữ, đúng thứ tự (pdftotext -raw)")
out = P("both.pdf"); r = apply(cls, two, out, (1, B2[0][0], NEW_SHORT), (1, B2[1][0], NEW_LONG[:150]))
check(r == "OK" and qpdf_ok(out), f"hai đoạn cùng lúc (sửa khối sau trước): {r[:90]}")
allt = " ".join(lines_text(out)); check(NEW_SHORT.split()[0] in allt and NEW_LONG[:150].split()[-1] in allt, "cả hai đoạn đều đã đổi")
out2 = P("twice.pdf"); apply(cls, BASE, P("tw1.pdf"), (1, 2, NEW_SHORT)); b1 = blocks(cls, P("tw1.pdf"))
check(apply(cls, P("tw1.pdf"), out2, (1, b1[0][0], NEW_LONG)) == "OK", "sửa tiếp trên bản đã sửa (khối còn tìm được sau lần đầu)")

def boundary_text():
    """A text whose first line is decided by the width of ONE SPACE: the next word fits without the space but not with it (found by search, so it needs no luck)."""
    ws = SRC_TEXT.split()
    for st in range(len(ws)):
        sub = ws[st:]; cur = sub[0]
        for k in range(1, len(sub)):
            if width(cur) + width(sub[k]) <= b[2] and width(cur + " " + sub[k]) > b[2] + 0.02: return " ".join(sub[:k + 8])
            if width(cur + " " + sub[k]) > b[2]: break
            cur += " " + sub[k]
    raise SystemExit("no boundary text found")
BOUNDARY = boundary_text()
print("== G. thử âm tính")
def scenario(c):
    ok = []
    o = P("s1.pdf"); r = apply(c, BASE, o, (1, 2, NEW_LONG)); L = text_lines(o) if r == "OK" else []
    pr = [html.unescape(x[3]) for x in L if x[3] not in ("Heading of the page", "Unrelated sentence far below the paragraph.")]
    ok.append(r == "OK" and pr == wrap(NEW_LONG, b[2]))
    ys = [x[0] for x in L if x[3] not in ("Heading of the page", "Unrelated sentence far below the paragraph.")]
    ok.append(r == "OK" and len(ys) > 2 and all(abs((ys[i + 1] - ys[i]) - 16) < 0.6 for i in range(len(ys) - 1)))
    o = P("s2.pdf"); r = apply(c, BT, o, (1, bb[0][0], NEW_LONG)); f = [x for x in text_lines(o) if x[3].startswith("Footer")] if r == "OK" else []
    ok.append(r == "OK" and len(f) == 1 and abs(f[0][0] - f0[0]) < 0.3)
    r = apply(c, over, P("s3.pdf"), (1, ob[0], NEW_LONG)); ok.append(r.startswith("ERR:") and "Overlaps" in r)
    o = P("s4.pdf"); r = apply(c, BASE, o, (1, 2, NEW_SHORT)); pr2 = [t for t in lines_text(o) if t not in ("Heading of the page", "Unrelated sentence far below the paragraph.")] if r == "OK" else []
    ok.append(r == "OK" and pr2 == wrap(NEW_SHORT, b[2]))
    SPACEY = BOUNDARY
    o = P("s6.pdf"); r = apply(c, BASE, o, (1, 2, SPACEY)); ok.append(r == "OK" and [t for t in lines_text(o) if t not in ("Heading of the page", "Unrelated sentence far below the paragraph.")] == wrap(SPACEY, b[2]))
    return ok
check(all(scenario(cls)), "đối chứng: mã gốc đạt cả 6 phép thử")
if "--fast" not in sys.argv:
    MUT = (("không trả lại ma trận dòng chữ (Td khôi phục)", "insert.add(COSFloat(0f)); insert.add(COSFloat(extra * stepText)); insert.add(Operator.getOperator(\"Td\"))", ""),
           ("ngắt dòng bỏ qua khoảng trắng", "currentWidth + space + ww <= maxWidth", "currentWidth + ww <= maxWidth"),
           ("dòng thêm đi LÊN thay vì xuống", "insert.add(COSFloat(0f)); insert.add(COSFloat(-stepText)); insert.add(Operator.getOperator(\"Td\"))", "insert.add(COSFloat(0f)); insert.add(COSFloat(stepText)); insert.add(Operator.getOperator(\"Td\"))"),
           ("bỏ kiểm tra đè lên chữ khác", "if (b[0] < right && b[2] > left && b[1] < bottom && b[3] > top) return Result.Overlaps", ""),
           ("dòng thừa không được xoá (giữ chữ cũ)", "val text = if (k < lines.size) tokens[k] else COSString(ByteArray(0))", "val text = if (k < lines.size) tokens[k] else continue"),
           ("bề rộng khung bị bỏ qua (không giới hạn)", "widthOf(ops, range) / scaleX + 0.02f, missing)", "100000f, missing)"))
    for name, old, new in MUT:
        try:
            mdir = tc.compile(FILES, [HARNESS], os.path.join(WORK, "mut"), {"PdfParagraphEditor.kt": (old, new)}, DOUBLE)[0]
            res = scenario(mdir); check(not all(res), f"mã sai bị bắt: {name} ({res})")
        except RuntimeError as e:
            check(False, f"mutant không biên dịch được: {name}: {str(e)[:160]}")
print(); print("TAT CA DAT" if not fails else f"{len(fails)} LOI")
sys.exit(1 if fails else 0)
