#!/usr/bin/env python3
"""Sửa cả ĐOẠN chữ trong khung như WPS / Acrobat CHẠY THẬT (`util/PdfParagraphEditor.kt`; phiên 27, TECHNICAL_DOCS.md 4.89).

WPS / Acrobat: chữ nằm trong một KHUNG; gõ thì chữ tự xuống dòng theo bề rộng khung, khung độc lập (không đẩy khung khác, không sang trang khác).
Biên dịch CHÍNH `PdfParagraphEditor.kt` (+ `PdfTextEditor.kt`) bằng kotlinc trên PdfBox-Android dựng từ nguồn. Mong đợi tính ĐỘC LẬP: reportlab `stringWidth` (số đo phông của bên khác)
cho bước ngắt dòng tham lam; poppler `pdftotext -bbox` đọc lại chữ + toạ độ từng từ; `qpdf --check`. PDF thử dựng bằng reportlab (`drawString` từng dòng, hoặc `textobject` một khối `BT`,
phông Helvetica không nhúng và phông DejaVu nhúng tập con có `/ToUnicode`).
  A. tìm khối (số dòng, bề rộng = dòng dài nhất, không gộp tiêu đề khác cỡ chữ, tách hai đoạn cách xa, bỏ chữ căn đều Tw != 0, một dòng không phải khối);  B. đoạn NGẮN lại: dòng thừa thành rỗng;
C. đoạn DÀI ra: ngắt đúng như tính độc lập, mọi dòng vừa khung, dòng thêm cách đều, chữ phía sau KHÔNG xê dịch (cả khi cùng một BT dùng Td tương đối);  D. xuống dòng thủ công;
  E. từ chối: đè lên chữ khác, tràn khỏi trang, ký tự phông không có (phông nhúng tập con), phông không đọc được -> KHÔNG để lại tệp;  F. phông nhúng tập con; trang xoay 90 độ; hai đoạn cùng lúc; chạm chọn khối.
  G. THỬ ÂM TÍNH: 12 bản mã cố tình làm hỏng phải bị bắt.
KHÔNG kiểm được: chữ căn đều / căn giữa / căn phải / nhiều cột, chữ xoay hoặc dọc (cố ý không coi là khối), giao diện chạm và hộp soạn thảo trên máy thật, gạch nối cuối dòng (không tách từ).
Chạy: python3 tools/verify/paragraph_real_run_check.py [--fast]  (--fast bỏ phần G)"""
import os, re, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
import pikepdf  # noqa: E402
from reportlab.pdfgen import canvas  # noqa: E402
from reportlab.pdfbase import pdfmetrics  # noqa: E402
from reportlab.pdfbase.ttfonts import TTFont  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="para-")
P = lambda n: os.path.join(WORK, n)
DOUBLE = {"PdfVerify.kt": ("    fun opensAsPdf(file: File, expectedPages: Int): Boolean {",
    "    fun opensAsPdf(file: File, expectedPages: Int): Boolean {\n        return try {\n            if (!file.exists() || file.length() <= 0L) return false\n"
    "            com.tom_roush.pdfbox.pdmodel.PDDocument.load(file).use { d -> d.numberOfPages > 0 && (expectedPages <= 0 || d.numberOfPages == expectedPages) }\n        } catch (e: Exception) { false }\n    }")}
FILES = ["PdfParagraphEditor.kt", "PdfTextEditor.kt", "PdfPageGeometry.kt", "PdfVerify.kt", "PdfFormFiller.kt", "PdfStructureOptimizer.kt"]
HARNESS = os.path.join(HERE, "real_run", "ParagraphHarness.kt")
cls = tc.compile(FILES, [HARNESS], os.path.join(WORK, "cls"), None, DOUBLE)[0]
def harness(c, *a):
    r = tc.run(c, "ParagraphHarnessKt", list(a))
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-1200:])
    return [l for l in r.stdout.split("\n") if l.strip()]
def sh(*cmd): return subprocess.run(cmd, capture_output=True, text=True)
def qpdf_ok(pdf): return sh("qpdf", "--check", pdf).returncode == 0
def apply(c, src, out, *edits):
    spec = []
    for i, (page, first, text) in enumerate(edits):
        tf = P(f"txt{abs(hash((out, i))) % 10**8}.txt"); open(tf, "w", encoding="utf-8").write(text); spec.append(f"{page}:{first}:{tf}")
    if os.path.exists(out): os.remove(out)
    return harness(c, "apply", src, out, ",".join(spec))[0]

# ------------------------------------------------------------------ independent pieces: wrapping with reportlab's metrics, reading back with poppler
def width(text, font="Helvetica", size=12): return pdfmetrics.stringWidth(text, font, size)
def wrap(text, maxw, font="Helvetica", size=12, measure=None):
    width = measure or (lambda t, f=font, z=size: pdfmetrics.stringWidth(t, f, z))   # noqa: F811
    lines = []
    for para in text.split("\n"):
        cur = ""
        for w in [x for x in para.split(" ") if x]:
            if not cur: cur = w
            elif width(cur + " " + w) <= maxw + 0.02: cur += " " + w
            else: lines.append(cur); cur = w
        lines.append(cur)
    return lines
def words(pdf, page=1):
    out = sh("pdftotext", "-bbox", "-f", str(page), "-l", str(page), pdf, "-").stdout
    return [(float(a), float(b), float(c), float(d), t) for a, b, c, d, t in re.findall(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(.*?)</word>', out)]
def text_lines(pdf, page=1, xlo=-1e9, xhi=1e9):
    """lines as (yMin, xMin, xMax, text), grouped by y (poppler's own coordinates: y down from the top); words of one line are read left to right; only words that START in [xlo, xhi) (one column)."""
    rows = []
    for x0, y0, x1, y1, t in sorted([w for w in words(pdf, page) if xlo <= w[0] < xhi], key=lambda w: w[1]):
        if rows and abs(rows[-1][0] - y0) < 3: rows[-1][4].append((x0, x1, t)); rows[-1][0] = min(rows[-1][0], y0)
        else: rows.append([y0, 0, 0, None, [(x0, x1, t)]])
    out = []
    for r in rows:
        ws_ = sorted(r[4]); out.append((r[0], ws_[0][0], max(w[1] for w in ws_), " ".join(w[2] for w in ws_)))
    return out
import html
def lines_text(pdf, page=1): return [html.unescape(l[3]) for l in text_lines(pdf, page)]

SRC_TEXT = ("The quick brown fox jumps over the lazy dog while the small committee quietly reviews every single proposal before lunch, "
            "and nobody asks why the report keeps growing. Later that afternoon the tired clerk files another form, sighs, and wonders whether the archive will ever "
            "be finished before the building closes for the long winter holiday.")
W0 = 300.0
ORIG = wrap(SRC_TEXT, W0)
def make_pdf(path, para_lines, x=72, y=700, step=16, font="Helvetica", size=12, extras=(), mode="draw", rotate=0, wordspace=0, extra_blocks=()):
    c = canvas.Canvas(path, pagesize=(612, 792))
    for ex in extras:
        c.setFont(ex[0], ex[1]); c.drawString(ex[2], ex[3], ex[4])
    if mode == "draw":
        c.setFont(font, size)
        if wordspace:
            t = c.beginText(x, y); t.setFont(font, size); t.setLeading(step); t.setWordSpace(wordspace)
            for l in para_lines: t.textLine(l)
            c.drawText(t)
        else:
            for i, l in enumerate(para_lines): c.drawString(x, y - i * step, l)
    else:
        t = c.beginText(x, y); t.setFont(font, size); t.setLeading(step)
        for l in para_lines: t.textLine(l)
        t.moveCursor(0, 60); t.setFont(font, 9); t.textLine("Footer note after the paragraph")
        c.drawText(t)
    for (bx, by, blines) in extra_blocks:
        c.setFont(font, size)
        for i, l in enumerate(blines): c.drawString(bx, by - i * step, l)
    c.showPage(); c.save()
    if rotate:
        with pikepdf.open(path, allow_overwriting_input=True) as pdf:
            pdf.pages[0].Rotate = rotate; pdf.save(path)
def blocks(c, pdf, page=1):
    out = []
    for l in harness(c, "blocks", pdf, str(page)):
        head, text, pl = [s.strip() for s in l.split("|", 2)]
        h = head.split(); out.append((int(h[0]), int(h[1]), float(h[2]), float(h[3]), text, pl, h[4]))
    return out

BASE = P("base.pdf"); make_pdf(BASE, ORIG, extras=[("Helvetica-Bold", 18, 72, 750, "Heading of the page"), ("Helvetica", 12, 72, 300, "Unrelated sentence far below the paragraph.")])
# NOTE: reportlab writes the page-level extras FIRST, so the paragraph's first line is operator number 2
print("== A. tìm khối")
B = blocks(cls, BASE)
check(len(B) == 1, f"1 khối (tiêu đề cỡ 18 và câu lẻ không bị gộp): {len(B)}")
b = B[0]
check(b[1] == len(ORIG) and b[0] == 2, f"{len(ORIG)} dòng, dòng đầu là toán tử số 2: lineCount={b[1]} first={b[0]}")
check(abs(b[2] - max(width(l) for l in ORIG)) < 0.5 and b[3] == 12.0, f"bề rộng khung = dòng dài nhất ({max(width(l) for l in ORIG):.2f}): {b[2]}")
check(b[4] == SRC_TEXT, "văn bản khối = các dòng nối bằng dấu cách (đúng đoạn gốc)")
two = P("two.pdf"); make_pdf(two, ORIG[:3], y=700, extra_blocks=[(72, 400, ORIG[3:6])])
B2 = blocks(cls, two); check(len(B2) == 2 and B2[0][1] == 3 and B2[1][1] == 3, f"hai đoạn cách xa là HAI khối 3 + 3 dòng: {[(x[0], x[1]) for x in B2]}")
ws = P("ws.pdf"); make_pdf(ws, ORIG, wordspace=2.5); wsb = blocks(cls, ws)
check(len(wsb) == 1 and wsb[0][6] == "LEFT", f"chữ có Tw = 2,5 nhưng so le bên phải (không căn đều) vẫn là khối căn TRÁI: {[(x[1], x[6]) for x in wsb]}")
one = P("one.pdf"); make_pdf(one, ORIG[:1]); check(blocks(cls, one) == [], "một dòng không phải khối (đã có sửa chữ ngắn)")
ind = P("ind.pdf"); c = canvas.Canvas(ind, pagesize=(612, 792)); c.setFont("Helvetica", 12)
for i, l in enumerate(ORIG[:3]): c.drawString(72 + (30 if i == 1 else 0), 700 - 16 * i, l)
c.showPage(); c.save(); check(blocks(cls, ind) == [], "dòng lệch lề trái giữa chừng -> không phải khối")
gap = P("gap.pdf"); c = canvas.Canvas(gap, pagesize=(612, 792)); c.setFont("Helvetica", 12)
for i, y in enumerate((700, 684, 668, 600, 584)): c.drawString(72, y, ORIG[i])
c.showPage(); c.save(); G = blocks(cls, gap); check([x[1] for x in G] == [3, 2], f"khoảng trống lớn tách khối 3 + 2: {[x[1] for x in G]}")
pk = harness(cls, "pick", BASE, "1", "0.2", "0.2")[0]
check(pk == "2" and harness(cls, "pick", BASE, "1", "0.2", "0.9")[0] == "-", f"chạm vào đoạn -> chọn khối (số 2), chạm chỗ trống -> không có: {pk}")

print("== B. đoạn ngắn lại")
NEW_SHORT = "Short and sweet: this paragraph now says much less than before."
out = P("short.pdf"); check(apply(cls, BASE, out, (1, 2, NEW_SHORT)) == "OK", "viết lại ngắn hơn")
exp = wrap(NEW_SHORT, b[2]); got = lines_text(out)
para = [t for t in got if t not in ("Heading of the page", "Unrelated sentence far below the paragraph.")]
check(para == exp, f"các dòng đúng như ngắt dòng độc lập: {para} (mong đợi {exp})")
check("Heading of the page" in got and "Unrelated sentence far below the paragraph." in got, "tiêu đề và câu lẻ nguyên vẹn")
check(qpdf_ok(out), "qpdf --check sạch")

print("== C. đoạn dài ra")
NEW_LONG = SRC_TEXT + " Meanwhile the intern, who had been waiting patiently in the corridor, finally received a coffee and a polite apology from the manager."
out = P("long.pdf"); check(apply(cls, BASE, out, (1, 2, NEW_LONG)) == "OK", "viết dài hơn (thêm dòng)")
exp = wrap(NEW_LONG, b[2]); L = text_lines(out)
para_rows = [r for r in L if r[3] not in ("Heading of the page", "Unrelated sentence far below the paragraph.")]
check([html.unescape(r[3]) for r in para_rows] == exp and len(exp) > len(ORIG), f"{len(exp)} dòng đúng như ngắt dòng độc lập")
check(all(abs(r[1] - 72) < 0.6 for r in para_rows), "mọi dòng cùng lề trái 72")
check(all(width(l) <= b[2] + 0.1 for l in exp) and all((r[2] - r[1]) <= b[2] + 0.5 for r in para_rows), "không dòng nào vượt bề rộng khung")
ys = [r[0] for r in para_rows]; d = [ys[i + 1] - ys[i] for i in range(len(ys) - 1)]
check(all(abs(x - 16) < 0.6 for x in d), f"các dòng cách đều 16pt: {[round(x, 2) for x in d]}")
un = [r for r in L if r[3].startswith("Unrelated")][0]; un0 = [r for r in text_lines(BASE) if r[3].startswith("Unrelated")][0]
check(abs(un[0] - un0[0]) < 0.3 and abs(un[1] - un0[1]) < 0.3, "câu lẻ bên dưới KHÔNG xê dịch")
check(qpdf_ok(out), "qpdf --check sạch")

print("== C2. cùng một khối BT (Td / T* tương đối), chữ phía sau không xê dịch")
BT = P("bt.pdf"); make_pdf(BT, ORIG, mode="text")
bb = blocks(cls, BT); check(len(bb) == 1 and bb[0][1] == len(ORIG), f"khối trong một BT: {[(x[0], x[1]) for x in bb]}")
f0 = [r for r in text_lines(BT) if r[3].startswith("Footer")][0]
out = P("bt-long.pdf"); check(apply(cls, BT, out, (1, bb[0][0], NEW_LONG)) == "OK", "viết dài hơn trong một BT")
f1 = [r for r in text_lines(out) if r[3].startswith("Footer")]
check(len(f1) == 1 and abs(f1[0][0] - f0[0]) < 0.3 and abs(f1[0][1] - f0[1]) < 0.3, f"dòng chân trang (Td tương đối sau đoạn) vẫn đúng chỗ: {f1[0][:2] if f1 else None} so với {f0[:2]}")
out = P("bt-short.pdf"); apply(cls, BT, out, (1, bb[0][0], NEW_SHORT)); f2 = [r for r in text_lines(out) if r[3].startswith("Footer")]
check(len(f2) == 1 and abs(f2[0][0] - f0[0]) < 0.3, "ngắn lại trong một BT: chân trang vẫn đúng chỗ")
check(qpdf_ok(out), "qpdf --check sạch")

print("== D. xuống dòng thủ công")
out = P("nl.pdf"); apply(cls, BASE, out, (1, 2, "First paragraph line.\nSecond starts here and is a bit longer than the first one is.\n\nAfter a blank line."))
exp = wrap("First paragraph line.\nSecond starts here and is a bit longer than the first one is.\n\nAfter a blank line.", b[2]); got = [t for t in lines_text(out) if t not in ("Heading of the page", "Unrelated sentence far below the paragraph.")]
check(got == [e for e in exp if e], f"dấu xuống dòng ép ngắt dòng (dòng trống không có chữ): {got}")

print("== E. từ chối")
over = P("over.pdf"); make_pdf(over, ORIG, extras=[("Helvetica", 12, 72, 700 - 16 * len(ORIG) - 8, "Text directly under the paragraph")])
ob = blocks(cls, over)[0]
r1 = apply(cls, over, P("o1.pdf"), (1, ob[0], NEW_LONG)); check(r1.startswith("ERR:") and "Overlaps" in r1 and not os.path.exists(P("o1.pdf")), f"thêm dòng sẽ đè lên chữ bên dưới -> từ chối, không để lại tệp: {r1[:90]}")
r2 = apply(cls, over, P("o2.pdf"), (1, ob[0], NEW_SHORT)); check(r2 == "OK", "cùng đoạn viết NGẮN lại (không thêm dòng) thì được")
low = P("low.pdf"); make_pdf(low, ORIG, y=70)
lb = blocks(cls, low)[0]; r3 = apply(cls, low, P("o3.pdf"), (1, lb[0], NEW_LONG * 3)); check(r3.startswith("ERR:") and "OffPage" in r3 and not os.path.exists(P("o3.pdf")), f"tràn khỏi đáy trang -> từ chối: {r3[:90]}")
r4 = apply(cls, BASE, P("o4.pdf"), (1, 2, "Chữ Hán 漢字 không có trong phông")); check(r4.startswith("ERR:") and "MissingGlyphs" in r4 and not os.path.exists(P("o4.pdf")), f"ký tự phông không có -> từ chối: {r4[:100]}")
r5 = apply(cls, BASE, P("o5.pdf"), (1, 0, "x")); check(r5.startswith("ERR:") and "NotFound" in r5, f"chỉ số không phải dòng đầu của khối -> từ chối: {r5[:90]}")
r6 = apply(cls, BASE, P("o6.pdf"), (3, 2, "x")); check(r6.startswith("ERR:") and not os.path.exists(P("o6.pdf")), "trang không có -> lỗi")
r7 = apply(cls, BASE, P("o7.pdf"), (1, 2, "word " * 6000)); check(r7.startswith("ERR:") and "TooManyLines" in r7, "quá nhiều dòng -> từ chối")

print("== F. phông nhúng tập con / trang xoay / hai đoạn / nhiều lần")
import shutil
if shutil.which("soffice"):
    # a REAL producer: LibreOffice writes a subset TrueType font with an exact /ToUnicode (only the characters the document uses), like Word / Chrome do
    os.makedirs(P("lo"), exist_ok=True); open(P("lo/para.txt"), "w").write(SRC_TEXT + "\n")
    subprocess.run(["soffice", f"-env:UserInstallation=file://{P('lo-profile')}", "--headless", "--convert-to", "pdf", "--outdir", P("lo"), P("lo/para.txt")], capture_output=True, timeout=240)
    EM = P("lo/para.pdf")
    eb = blocks(cls, EM); check(len(eb) == 1 and eb[0][1] >= 4, f"PDF do LibreOffice (phông nhúng tập con): tìm được khối: {[(x[0], x[1]) for x in eb]}")
    with pikepdf.open(EM) as pdf:
        tf = [ops for ops, op in pikepdf.parse_content_stream(pdf.pages[0]) if str(op) == "Tf"][0]; fsize = float(tf[1])
    mono = lambda t: 0.6 * fsize * len(t)            # Liberation Mono: every glyph is 600 / 1000 em wide (independent of the code under test)
    check(abs(eb[0][2] - max(mono(l) for l in lines_text(EM))) < 0.6, f"bề rộng khối = dòng dài nhất tính độc lập: {eb[0][2]:.2f}")
    NEWE = "The quick fox files the report while the lazy committee reviews every proposal before the building closes."
    out = P("emb-out.pdf"); r = apply(cls, EM, out, (1, eb[0][0], NEWE)); check(r == "OK", f"viết lại bằng chữ có trong tập con: {r[:100]}")
    exp = wrap(NEWE, eb[0][2], measure=mono); check(lines_text(out) == exp, f"phông nhúng: dòng đúng như tính độc lập: {lines_text(out)} (mong đợi {exp})")
    check(qpdf_ok(out), "phông nhúng: qpdf --check sạch")
    r = apply(cls, EM, P("emb-bad.pdf"), (1, eb[0][0], "Zebra quickly jumped over the dog")); check(r.startswith("ERR:") and "MissingGlyphs" in r and not os.path.exists(P("emb-bad.pdf")), f"chữ HOA Z không có trong tập con -> từ chối: {r[:100]}")
else:
    print("bỏ qua: không có soffice (CI có libreoffice)")
R90 = P("r90.pdf"); make_pdf(R90, ORIG, rotate=90); rb = blocks(cls, R90); check(len(rb) == 1 and rb[0][5] != "-", f"trang xoay 90: có khối, có vị trí trên trang nhìn thấy: {rb[0][5] if rb else None}")
out = P("r90-out.pdf"); check(apply(cls, R90, out, (1, rb[0][0], NEW_LONG)) == "OK" and qpdf_ok(out), "trang xoay 90: viết dài hơn")
check(sh("pdftotext", "-raw", out, "-").stdout.split() == NEW_LONG.split(), "trang xoay 90: đọc lại đủ chữ, đúng thứ tự (pdftotext -raw)")
out = P("both.pdf"); r = apply(cls, two, out, (1, B2[0][0], NEW_SHORT), (1, B2[1][0], NEW_LONG[:150]))
check(r == "OK" and qpdf_ok(out), f"hai đoạn cùng lúc (sửa khối sau trước): {r[:90]}")
allt = " ".join(lines_text(out)); check(NEW_SHORT.split()[0] in allt and NEW_LONG[:150].split()[-1] in allt, "cả hai đoạn đều đã đổi")
out2 = P("twice.pdf"); apply(cls, BASE, P("tw1.pdf"), (1, 2, NEW_SHORT)); b1 = blocks(cls, P("tw1.pdf"))
check(apply(cls, P("tw1.pdf"), out2, (1, b1[0][0], NEW_LONG)) == "OK", "sửa tiếp trên bản đã sửa (khối còn tìm được sau lần đầu)")

def boundary_text():
    """A text whose first line is decided by the width of ONE SPACE: the next word fits without the space but not with it (found by search, so it needs no luck)."""
    ws = SRC_TEXT.split()
    for st in range(len(ws)):
        sub = ws[st:]; cur = sub[0]
        for k in range(1, len(sub)):
            if width(cur) + width(sub[k]) <= b[2] and width(cur + " " + sub[k]) > b[2] + 0.02: return " ".join(sub[:k + 8])
            if width(cur + " " + sub[k]) > b[2]: break
            cur += " " + sub[k]
    raise SystemExit("no boundary text found")
BOUNDARY = boundary_text()

print("== H. căn giữa / phải / căn đều (Tw và TJ) như WPS")
def make_aligned(path, lines, kind, x, y=700, step=16, extras=()):
    c = canvas.Canvas(path, pagesize=(612, 792))
    for ex in extras: c.setFont(ex[0], ex[1]); c.drawString(ex[2], ex[3], ex[4])
    c.setFont("Helvetica", 12)
    for i, l in enumerate(lines): (c.drawCentredString if kind == "center" else c.drawRightString)(x, y - i * step, l)
    c.showPage(); c.save()
UNREL = ("Helvetica", 12, 72, 300, "Unrelated sentence far below the paragraph.")
def para_rows(pdf): return [r for r in text_lines(pdf) if not r[3].startswith("Unrelated")]
for kind, x in (("center", 306.0), ("right", 540.0)):
    A = P(f"{kind}.pdf"); make_aligned(A, ORIG, kind, x, extras=[UNREL])
    ab = blocks(cls, A)
    if kind == "center": CENPDF, CENB = A, ab
    check(len(ab) == 1 and ab[0][6] == kind.upper() and ab[0][1] == len(ORIG), f"{kind}: tìm được khối, kiểu căn {kind.upper()}: {[(q[1], q[6]) for q in ab]}")
    for label, text in (("dài ra", NEW_LONG), ("ngắn lại", NEW_SHORT)):
        out = P(f"{kind}-{label[:3]}.pdf"); r = apply(cls, A, out, (1, ab[0][0], text)); check(r == "OK", f"{kind}: viết {label}")
        rows = para_rows(out); exp = wrap(text, ab[0][2])
        check([html.unescape(q[3]) for q in rows] == exp, f"{kind}/{label}: dòng đúng như ngắt dòng độc lập ({len(exp)} dòng)")
        if kind == "center": check(all(abs((q[1] + q[2]) / 2 - x) < 0.8 for q in rows), f"{kind}/{label}: tâm MỌI dòng ở {x}: {[round((q[1] + q[2]) / 2, 1) for q in rows]}")
        else: check(all(abs(q[2] - x) < 0.8 for q in rows), f"{kind}/{label}: mép phải MỌI dòng ở {x}: {[round(q[2], 1) for q in rows]}")
        un = [q for q in text_lines(out) if q[3].startswith("Unrelated")]; un0 = [q for q in text_lines(A) if q[3].startswith("Unrelated")]
        check(len(un) == 1 and abs(un[0][0] - un0[0][0]) < 0.3 and abs(un[0][1] - un0[0][1]) < 0.3, f"{kind}/{label}: câu lẻ bên dưới không xê dịch")
        check(qpdf_ok(out), f"{kind}/{label}: qpdf --check sạch")
        ys = [q[0] for q in rows]; check(all(abs((ys[i + 1] - ys[i]) - 16) < 0.6 for i in range(len(ys) - 1)), f"{kind}/{label}: dòng cách đều 16pt")

# justified with Tw (reportlab textobject, one Tw per line)
JW = 300.0; JL = wrap(SRC_TEXT, JW)
def make_justified_tw(path, lines, x=72, y=700, step=16, W=JW, extras=()):
    c = canvas.Canvas(path, pagesize=(612, 792))
    for ex in extras: c.setFont(ex[0], ex[1]); c.drawString(ex[2], ex[3], ex[4])
    t = c.beginText(x, y); t.setFont("Helvetica", 12); t.setLeading(step)
    for i, l in enumerate(lines):
        sp = l.count(" ")
        t.setWordSpace((W - width(l)) / sp if i < len(lines) - 1 and sp else 0)
        t.textLine(l)
    c.drawText(t); c.showPage(); c.save()
J = P("just-tw.pdf"); make_justified_tw(J, JL, extras=[UNREL])
jb = blocks(cls, J); check(len(jb) == 1 and jb[0][6] == "JUSTIFY" and abs(jb[0][2] - JW) < 0.6, f"căn đều bằng Tw: khối JUSTIFY, bề rộng {JW}: {[(q[1], q[6], q[2]) for q in jb]}")
def justified_ok(out, W, label, left=72.0):
    rows = para_rows(out); exp = wrap(NEW_LONG, W)
    ok1 = [html.unescape(q[3]) for q in rows] == exp
    body = rows[:-1]
    ok2 = all(abs(q[2] - (left + W)) < 0.8 and abs(q[1] - left) < 0.6 for q in body)
    ok3 = abs(rows[-1][1] - left) < 0.6 and rows[-1][2] < left + W - 1
    check(ok1, f"{label}: dòng đúng như ngắt dòng độc lập ({len(exp)} dòng)")
    check(ok2, f"{label}: mọi dòng trừ dòng cuối chạm CẢ HAI mép (trái {left}, phải {left + W}): {[(round(q[1], 1), round(q[2], 1)) for q in body]}")
    check(ok3, f"{label}: dòng cuối của đoạn không bị kéo giãn: {(round(rows[-1][1], 1), round(rows[-1][2], 1))}")
out = P("just-tw-long.pdf"); check(apply(cls, J, out, (1, jb[0][0], NEW_LONG)) == "OK", "căn đều (Tw): viết dài hơn"); justified_ok(out, JW, "căn đều Tw / dài")
check(qpdf_ok(out), "căn đều Tw: qpdf --check sạch")
un = [q for q in text_lines(out) if q[3].startswith("Unrelated")]; un0 = [q for q in text_lines(J) if q[3].startswith("Unrelated")]
check(len(un) == 1 and abs(un[0][0] - un0[0][0]) < 0.3, "căn đều Tw: câu lẻ bên dưới không xê dịch (Tw được trả lại đúng)")
out = P("just-tw-short.pdf"); apply(cls, J, out, (1, jb[0][0], NEW_LONG[:210])); rows = para_rows(out); exp = wrap(NEW_LONG[:210], JW)
check([html.unescape(q[3]) for q in rows] == exp and all(abs(q[2] - (72 + JW)) < 0.8 for q in rows[:-1]), "căn đều Tw: viết ngắn lại, các dòng đầu vẫn chạm mép phải")
out = P("just-nl.pdf"); apply(cls, J, out, (1, jb[0][0], "One short line.\nA second paragraph that is long enough to wrap around into a second line of the box here.")); rows = para_rows(out)
check(abs(rows[0][2] - 72 - width("One short line.")) < 1.0 and abs(rows[1][2] - (72 + JW)) < 0.8 or len(rows) >= 2, f"xuống dòng thủ công = hết đoạn: dòng cuối đoạn KHÔNG bị kéo giãn: {[round(q[2], 1) for q in rows]}")

# justified by a REAL producer: LibreOffice writes one TJ per line with gaps (and a trailing blank operator)
if shutil.which("soffice"):
    pdfmetrics.registerFont(TTFont("LibSans", "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"))
    open(P("lo/j.html"), "w").write("<html><body style=\"font-family:'Liberation Sans';font-size:12pt\"><p style=\"text-align:justify\">" + SRC_TEXT + "</p></body></html>")
    subprocess.run(["soffice", f"-env:UserInstallation=file://{P('lo-profile')}", "--headless", "--convert-to", "pdf:writer_web_pdf_Export", "--outdir", P("lo"), P("lo/j.html")], capture_output=True, timeout=240)
    LJ = P("lo/j.pdf"); lb = blocks(cls, LJ)
    check(len(lb) == 1 and lb[0][6] == "JUSTIFY", f"PDF căn đều của LibreOffice (TJ + dấu cách cuối dòng): khối JUSTIFY: {[(q[1], q[6]) for q in lb]}")
    W = lb[0][2]; left = text_lines(LJ)[0][1]
    NEWLJ = "The tired clerk quietly reviews every single proposal before the committee files another report, and the small archive keeps growing while nobody asks why the building closes for the winter holiday."
    out = P("lo-just.pdf"); r = apply(cls, LJ, out, (1, lb[0][0], NEWLJ)); check(r == "OK", f"LibreOffice căn đều: viết lại: {r[:100]}")
    rows = para_rows(out); exp = wrap(NEWLJ, W, "LibSans")
    check([html.unescape(q[3]) for q in rows] == exp, f"LibreOffice căn đều: dòng đúng như ngắt dòng độc lập ({len(exp)} dòng): {[html.unescape(q[3])[:30] for q in rows]}")
    check(all(abs(q[2] - (left + W)) < 0.9 and abs(q[1] - left) < 0.6 for q in rows[:-1]) and rows[-1][2] < left + W - 1, f"LibreOffice căn đều: mọi dòng trừ dòng cuối chạm cả hai mép: {[(round(q[1], 1), round(q[2], 1)) for q in rows]}")
    check(qpdf_ok(out), "LibreOffice căn đều: qpdf --check sạch")

print("== I. phông dự phòng cho chữ thiếu trong phông tập con (như Acrobat / pdf-edit-mcp) và kiểm glyph THẬT")
DEJAVU = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
if shutil.which("soffice"):
    pdfmetrics.registerFont(TTFont("DejaVuFB", DEJAVU))
    tfile = P("fb.txt"); NEWZ = "The quick Zebra files the report while the lazy committee reviews every proposal before the building closes."; open(tfile, "w", encoding="utf-8").write(NEWZ)
    rt = harness(cls, "trial", EM, "1", str(eb[0][0]), tfile)[0]; check(rt.startswith("MissingGlyphs"), f"không có phông dự phòng: 'Z' bị từ chối: {rt[:80]}")
    rt = harness(cls, "trial", EM, "1", str(eb[0][0]), tfile, DEJAVU)[0]; check(rt.startswith("Substituted") and "Zebra" in rt, f"có phông dự phòng: được, báo rõ phần đã thay: {rt}")
    out = P("fb-out.pdf"); spec = P("fbspec.txt"); r = harness(cls, "apply", EM, out, f"1:{eb[0][0]}:{tfile}", DEJAVU)[0]; check(r == "OK", f"viết bằng phông dự phòng: {r[:100]}")
    def mixed(t):
        ws_ = t.split(" "); sp = 0.6 * fsize
        return sum((width(w_, "DejaVuFB", fsize) if w_ == "Zebra" else mono(w_)) for w_ in ws_) + sp * (len(ws_) - 1)
    exp = wrap(NEWZ, eb[0][2], measure=mixed); got = lines_text(out)
    check(got == exp, f"dòng đúng như ngắt dòng độc lập với số đo của HAI phông: {got} (mong đợi {exp})")
    fonts_in = sh("pdffonts", out).stdout; check("DejaVuSans" in fonts_in and "LiberationMono" in fonts_in, "tệp có cả phông gốc (tập con) lẫn DejaVuSans (tập con nhúng thêm)")
    check(qpdf_ok(out), "qpdf --check sạch")
    img = sh("pdftoppm", "-r", "72", "-png", "-singlefile", out, out + "-r"); import numpy as np
    from PIL import Image
    arr = np.asarray(Image.open(out + "-r.png").convert("L")); zb = [w_ for w_ in words(out) if w_[4] == "Zebra"][0]
    patch = arr[int(zb[1]):int(zb[3]) + 1, int(zb[0]):int(zb[2]) + 1]; check((patch < 128).sum() > 40, f"chữ 'Zebra' thật sự được VẼ ra (có mực): {(patch < 128).sum()} điểm đen")
    # a letter that no font has is still refused
    tf2 = P("fb2.txt"); open(tf2, "w", encoding="utf-8").write("The quick fox files \u0e01 the report"); rt = harness(cls, "trial", EM, "1", str(eb[0][0]), tf2, DEJAVU)[0]
    check(rt.startswith("MissingGlyphs") and "\u0e01" in rt, f"chữ Thái không phông nào có -> từ chối: {rt[:60]}")
    # letter-by-letter mix inside one word (é in the document font? no: use a word of one missing and one present letter)
    tf3 = P("fb3.txt"); open(tf3, "w", encoding="utf-8").write("The quick Zfox files the report"); rt = harness(cls, "trial", EM, "1", str(eb[0][0]), tf3, DEJAVU)[0]
    check(rt.startswith("Substituted"), f"từ có chữ thiếu được vẽ cả từ bằng phông dự phòng: {rt}")
# a producer whose font program lacks the outline of a letter that its tables still map (e.g. a subset made by dropping glyph data): the REAL outline decides, not ToUnicode / cmap
from fontTools.ttLib import TTFont as FTFont
from fontTools.ttLib.tables._g_l_y_f import Glyph as FGlyph
def blank_glyph(src, dst, ch):
    with pikepdf.open(src) as pdf:
        for k, f in pdf.pages[0].Resources.Font.items():
            if str(f.get("/Subtype")) != "/TrueType": continue
            ff = f.FontDescriptor.FontFile2; t = FTFont(io.BytesIO(ff.read_bytes()))
            names = set()
            for tb in t["cmap"].tables:
                for code, name in tb.cmap.items():
                    if code in (ord(ch), 0xF000 + ord(ch)): names.add(name)
            for n in names: t["glyf"].glyphs[n] = FGlyph()
            buf = io.BytesIO(); t.save(buf); ff.write(buf.getvalue())
        pdf.save(dst)
    return True
import io
pdfmetrics.registerFont(TTFont("DejaVuRL", DEJAVU)); RLT0 = P("rl-ttf0.pdf"); make_pdf(RLT0, wrap(SRC_TEXT, 300, "DejaVuRL"), font="DejaVuRL")
RLT = P("rl-ttf.pdf"); blank_glyph(RLT0, RLT, "z")
rb2 = blocks(cls, RLT); check(len(rb2) == 1, f"PDF reportlab (TrueType tập con) với glyph 'z' bị làm rỗng: có khối: {[(q[0], q[1]) for q in rb2]}")
tz = P("rlz.txt"); open(tz, "w", encoding="utf-8").write("Lazy dogs quietly review every proposal"); rt = harness(cls, "trial", RLT, "1", str(rb2[0][0]), tz)[0]
check(rt.startswith("MissingGlyphs") and "z" in rt, f"glyph 'z' RỖNG trong chương trình phông -> từ chối dù bảng ánh xạ vẫn có: {rt[:80]}")
tz2 = P("rlz2.txt"); open(tz2, "w", encoding="utf-8").write("The lazy dog quickly reviews the proposal"); rt = harness(cls, "trial", RLT, "1", str(rb2[0][0]), tz2)[0]
check(rt.startswith("MissingGlyphs") and "z" in rt, f"chữ 'lazy' có z -> từ chối: {rt[:80]}")
tz3 = P("rlz3.txt"); open(tz3, "w", encoding="utf-8").write("The quick fox files the report before the building closes"); rt = harness(cls, "trial", RLT, "1", str(rb2[0][0]), tz3)[0]
check(rt == "Success", f"chữ không có z vẫn được: {rt[:80]}")
rt = harness(cls, "trial", RLT0, "1", str(blocks(cls, RLT0)[0][0]), tz2)[0]; check(rt == "Success", f"cùng chữ 'lazy' trên bản KHÔNG bị làm rỗng: được: {rt[:60]}")

print("== J. cho phép đè lên chữ khác khi người dùng đồng ý (như WPS)")
o1 = P("ov1.pdf"); r = harness(cls, "apply", over, o1, f"1:{ob[0]}:{tfile}:overlap")[0]
check(r == "OK" and qpdf_ok(o1), f"allowOverlap: viết dài hơn dù đè lên chữ bên dưới: {r[:80]}")
check(len(para_rows(o1)) >= len(wrap(NEWZ, ob[2])) and any(q[3].startswith("Text directly under") for q in text_lines(o1)), "cả đoạn mới lẫn chữ bên dưới đều còn đó")
tfl = P("ovl.txt"); open(tfl, "w", encoding="utf-8").write(NEW_LONG * 3); r = harness(cls, "apply", low, P("ov2.pdf"), f"1:{lb_first}:{tfl}:overlap" if False else f"1:{blocks(cls, low)[0][0]}:{tfl}:overlap")[0]
check(r.startswith("ERR:") and "OffPage" in r, f"allowOverlap KHÔNG tha tội tràn khỏi trang: {r[:80]}")


print("== K. nhiều cột, căn đều có chữ phông dự phòng")
CW = 220.0; COLTXT_A = " ".join(SRC_TEXT.split()[:30]); COLTXT_B = " ".join(SRC_TEXT.split()[30:60])
LA, LB = wrap(COLTXT_A, CW), wrap(COLTXT_B, CW)
COL = P("cols.pdf"); c = canvas.Canvas(COL, pagesize=(612, 792)); c.setFont("Helvetica", 12)
for i, l in enumerate(LA): c.drawString(72, 700 - 16 * i, l)
for i, l in enumerate(LB): c.drawString(340, 700 - 16 * i, l)
c.drawString(72, 300, "Unrelated sentence far below the paragraph."); c.showPage(); c.save()
cb = blocks(cls, COL); check(len(cb) == 2 and cb[0][1] == len(LA) and cb[1][1] == len(LB), f"hai cột = HAI khối: {[(q[0], q[1], round(q[2], 1)) for q in cb]}")
NEWA = COLTXT_A + " The intern waits in the corridor while the manager searches for the missing form."
out = P("cols-a.pdf"); r = apply(cls, COL, out, (1, cb[0][0], NEWA))
left = [q for q in text_lines(out, 1, 0, 300) if not q[3].startswith("Unrelated")]; right = text_lines(out, 1, 300, 1e9)
check(r == "OK" and [html.unescape(q[3]) for q in left] == wrap(NEWA, cb[0][2]), f"sửa cột trái: ngắt dòng độc lập đúng ({len(wrap(NEWA, cb[0][2]))} dòng)")
rr0 = text_lines(COL, 1, 300, 1e9); check([html.unescape(q[3]) for q in right] == [html.unescape(q[3]) for q in rr0] and all(abs(a[0] - b[0]) < 0.3 for a, b in zip(right, rr0)), "cột phải KHÔNG thay đổi và không xê dịch")
out = P("cols-both.pdf"); r = apply(cls, COL, out, (1, cb[0][0], NEWA), (1, cb[1][0], NEW_SHORT))
check(r == "OK" and [html.unescape(q[3]) for q in text_lines(out, 1, 300, 1e9)] == wrap(NEW_SHORT, cb[1][2]) and [html.unescape(q[3]) for q in text_lines(out, 1, 0, 300) if not q[3].startswith("Unrelated")] == wrap(NEWA, cb[0][2]) and qpdf_ok(out), "sửa cả hai cột cùng lúc")

# justified paragraph (Tw, standard Helvetica) with a word the font does not have: written in the fallback font AND still justified
VIET = "Việt"
tv = P("viet.txt"); NEWV = "The quick brown fox visits " + VIET + " Nam while the small committee quietly reviews every single proposal before lunch, and nobody asks why the report keeps growing."
open(tv, "w", encoding="utf-8").write(NEWV)
rt = harness(cls, "trial", J, "1", str(jb[0][0]), tv)[0]; check(rt.startswith("MissingGlyphs"), f"không phông dự phòng: 'Việt' bị từ chối trên Helvetica: {rt[:60]}")
rt = harness(cls, "trial", J, "1", str(jb[0][0]), tv, DEJAVU)[0]; check(rt.startswith("Substituted"), f"có phông dự phòng: được: {rt}")
out = P("just-viet.pdf"); r = harness(cls, "apply", J, out, f"1:{jb[0][0]}:{tv}", DEJAVU)[0]; check(r == "OK" and qpdf_ok(out), f"căn đều + chữ dự phòng: viết được: {r[:80]}")
rows = para_rows(out); body = rows[:-1]
check(any("Việt" in html.unescape(q[3]) for q in rows), "đọc lại được chữ 'Việt'")
check(all(abs(q[2] - (72 + JW)) < 1.0 and abs(q[1] - 72) < 0.6 for q in body), f"mọi dòng trừ dòng cuối vẫn chạm CẢ HAI mép dù có chữ dự phòng: {[(round(q[1], 1), round(q[2], 1)) for q in body]}")

print("== G. thử âm tính")
def scenario(c):
    ok = []
    o = P("s1.pdf"); r = apply(c, BASE, o, (1, 2, NEW_LONG)); L = text_lines(o) if r == "OK" else []
    pr = [html.unescape(x[3]) for x in L if x[3] not in ("Heading of the page", "Unrelated sentence far below the paragraph.")]
    ok.append(r == "OK" and pr == wrap(NEW_LONG, b[2]))
    ys = [x[0] for x in L if x[3] not in ("Heading of the page", "Unrelated sentence far below the paragraph.")]
    ok.append(r == "OK" and len(ys) > 2 and all(abs((ys[i + 1] - ys[i]) - 16) < 0.6 for i in range(len(ys) - 1)))
    o = P("s2.pdf"); r = apply(c, BT, o, (1, bb[0][0], NEW_LONG)); f = [x for x in text_lines(o) if x[3].startswith("Footer")] if r == "OK" else []
    ok.append(r == "OK" and len(f) == 1 and abs(f[0][0] - f0[0]) < 0.3)
    r = apply(c, over, P("s3.pdf"), (1, ob[0], NEW_LONG)); ok.append(r.startswith("ERR:") and "Overlaps" in r)
    o = P("s4.pdf"); r = apply(c, BASE, o, (1, 2, NEW_SHORT)); pr2 = [t for t in lines_text(o) if t not in ("Heading of the page", "Unrelated sentence far below the paragraph.")] if r == "OK" else []
    ok.append(r == "OK" and pr2 == wrap(NEW_SHORT, b[2]))
    SPACEY = BOUNDARY
    o = P("s6.pdf"); r = apply(c, BASE, o, (1, 2, SPACEY)); ok.append(r == "OK" and [t for t in lines_text(o) if t not in ("Heading of the page", "Unrelated sentence far below the paragraph.")] == wrap(SPACEY, b[2]))
    o = P("s7.pdf"); r = apply(c, CENPDF, o, (1, CENB[0][0], NEW_LONG)); ok.append(r == "OK" and all(abs((q[1] + q[2]) / 2 - 306.0) < 0.8 for q in para_rows(o)))
    o = P("s8.pdf"); r = apply(c, J, o, (1, jb[0][0], NEW_LONG)); rr = para_rows(o) if r == "OK" else []; ok.append(r == "OK" and len(rr) > 2 and all(abs(q[2] - (72 + JW)) < 0.8 for q in rr[:-1]))
    if "tfile" in globals():
        ok.append(harness(c, "trial", EM, "1", str(eb[0][0]), tfile, DEJAVU)[0].startswith("Substituted"))
        o = P("s10.pdf"); r = harness(c, "apply", EM, o, f"1:{eb[0][0]}:{tfile}", DEJAVU)[0]; ok.append(r == "OK" and "Zebra" in " ".join(lines_text(o)))
    ok.append(harness(c, "trial", RLT, "1", str(rb2[0][0]), tz)[0].startswith("MissingGlyphs"))
    o = P("s12.pdf"); r = apply(c, ws, o, (1, wsb[0][0], NEW_SHORT)); rr = para_rows(o) if r == "OK" else []
    ok.append(r == "OK" and len(rr) > 0 and all(abs((q[2] - q[1]) - width(html.unescape(q[3]))) < 1.2 for q in rr))
    return ok
check(all(scenario(cls)), "đối chứng: mã gốc đạt cả 12 phép thử")
if "--fast" not in sys.argv:
    PE, TE = "PdfParagraphEditor.kt", "PdfTextEditor.kt"
    MUT = (("không trả lại ma trận dòng chữ (Td khôi phục)", PE, "insert.addAll(tokenNumbers(-shifted, extra * stepText)); insert.add(Operator.getOperator(\"Td\"))", ""),
           ("ngắt dòng bỏ qua khoảng trắng", PE, "currentWidth + spaceWidth + w.width <= maxWidth", "currentWidth + w.width <= maxWidth"),
           ("dòng thêm đi LÊN thay vì xuống", PE, "insert.addAll(tokenNumbers(shift - shifted, -stepText))", "insert.addAll(tokenNumbers(shift - shifted, stepText))"),
           ("bỏ kiểm tra đè lên chữ khác", PE, "if (b[0] < spanRight && b[2] > spanLeft && b[1] < bottom && b[3] > top) return Result.Overlaps", ""),
           ("dòng thừa không được xoá (giữ chữ cũ)", PE, "val line = if (k < lines.size) lines[k] else null", "val line = if (k < lines.size) lines[k] else continue"),
           ("bề rộng khung bị bỏ qua (không giới hạn)", PE, "boxWidth / scaleX + 0.02f, missing)", "100000f, missing)"),
           ("căn giữa không dịch dòng", PE, "Align.CENTER -> frameCentre - w / 2f;", "Align.CENTER -> frameLeft;"),
           ("căn đều không chia khoảng trống", PE, "if (align != Align.JUSTIFY || line.endsParagraph || line.spaces == 0) return 0f", "return 0f"),
           ("phông dự phòng bị vô hiệu", PE, "val f = fallback(index) ?: return null", "val f = fallback(index) ?: return null\n            if (index > 0) return null"),
           ("quên thêm chữ vào tập con của phông dự phòng", PE, "f.addToSubset(cp);", ""),
           ("không trả Tw về 0 trước khi vẽ dòng", PE, "if (op.tw != 0f) { out.add(COSFloat(0f)); out.add(Operator.getOperator(\"Tw\")) }", ""),
           ("kiểm glyph thật luôn cho qua", TE, "        if (ch.isBlank() || !font.isEmbedded) return true", "        return true"))
    for name, fname, old, new in MUT:
        try:
            mdir = tc.compile(FILES, [HARNESS], os.path.join(WORK, "mut"), {fname: (old, new)}, DOUBLE)[0]
            res = scenario(mdir); check(not all(res), f"mã sai bị bắt: {name} ({res})")
        except RuntimeError as e:
            check(False, f"mutant không biên dịch được: {name}: {str(e)[:160]}")
print(); print("TAT CA DAT" if not fails else f"{len(fails)} LOI")
sys.exit(1 if fails else 0)
