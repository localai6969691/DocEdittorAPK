#!/usr/bin/env python3
"""Xoay / xoá / sắp xếp trang PDF THẬT (`util/PdfPageOps.kt`; phiên 24, TECHNICAL_DOCS.md 4.64) - lần đầu một bộ kiểm CHẠY mã Kotlin thật trên PdfBox thật.

Khác mọi bộ kiểm trước: không có bản Java chép lại, không dựng PDF "tương đương" bằng pikepdf. `real_run/toolchain.py` biên dịch CHÍNH `PdfPageOps.kt` (cùng `PdfBookmarks.kt`,
`PdfStructureOptimizer.kt`...) bằng kotlinc trên PdfBox-Android dựng từ mã nguồn của nó, rồi `PageOpsHarness.kt` gọi nó. Kết quả được kiểm bằng công cụ ĐỘC LẬP: poppler
(`pdftotext`, `pdfinfo`), `qpdf --check`, `pikepdf` (cấu trúc, mục lục, nhãn trang).

  A. phần thuần (xoay / xoá / chuyển / hợp lệ / không đổi / đổi thứ tự / chuẩn hoá góc) so với mô hình Python trên 3 000 chuỗi thao tác ngẫu nhiên;
  B. chạy thật: (1) cây phẳng 6 trang: đảo thứ tự + xoay + xoá, chữ từng trang đúng thứ tự, vết của trang đã xoá KHÔNG còn trong tệp; (2) cây LỒNG 3 cấp mà MediaBox, Rotate và
     Resources (phông) chỉ có ở nút trung gian: sau khi làm phẳng mọi trang vẫn đúng cỡ, đúng hướng, vẫn hiện chữ; không còn nút /Pages rỗng; (3) mục lục: dấu trang đi theo trang tới vị
     trí mới, dấu trang của trang đã xoá biến mất; (4) nhãn trang (/PageLabels) bị bỏ khi đổi thứ tự nhưng GIỮ khi chỉ xoay; (5) xoay cộng dồn với /Rotate sẵn có (90 + 270 = 0);
     (6) kế hoạch sai (trùng / ngoài phạm vi / rỗng / góc 45) -> -1 và không để lại tệp; (7) tệp mã hoá -> -1; (8) kế hoạch nguyên trạng cho cùng chữ; (9) sách 300 trang xáo trộn;
     (10) `qpdf --check` sạch cho mọi kết quả;
  C. THỬ ÂM TÍNH: 8 bản `PdfPageOps.kt` bị làm hỏng (bỏ thừa kế thuộc tính, không dọn nút rỗng, không dời dấu trang, không bỏ nhãn trang, bỏ qua /Rotate cũ, cho xoá trang cuối, chấp
     nhận trang trùng, thêm trang theo thứ tự ngược) được biên dịch lại và PHẢI bị bắt.
KHÔNG kiểm được: bản dựng thật trên điện thoại, hộp thoại và danh sách trang của màn hình (chỉ lõi), PDF có chữ ký số (màn hình hỏi trước bằng SignedPdfGuard), trường biểu mẫu / liên kết
trỏ vào trang đã xoá (xem 4.64). Cần: java 17+, git, unzip, kotlinc + PdfBox dựng bởi real_run/toolchain.py (lần đầu vài phút, cần github.com), pikepdf, poppler, qpdf.
Chạy: python3 tools/verify/page_ops_check.py [--fast]   (--fast bỏ phần C; --mutant=N chỉ chạy bản hỏng thứ N, 1-8, để chia nhỏ phần C khi mỗi lệnh có giới hạn thời gian)"""
import os, random, re, shutil, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
import pikepdf  # noqa: E402
from pikepdf import Array, Dictionary, Name, String  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get()
HARNESS = os.path.join(HERE, "real_run", "PageOpsHarness.kt")
STUBS = os.path.join(HERE, "real_run", "UtilStubs.kt")
FILES = ["PdfPageOps.kt", "PdfBookmarks.kt", "PdfStructureOptimizer.kt", "PdfVerify.kt"]
WORK = tempfile.mkdtemp(prefix="pageops-")

def build(mutate=None, tag="base"):
    return tc.compile(FILES, [HARNESS, STUBS], os.path.join(WORK, "cls-" + tag), mutate)[0]

def apply_real(cls, src, plan, out):
    r = tc.run(cls, "PageOpsHarnessKt", ["apply", src, out, plan])
    if r.returncode:
        raise SystemExit("harness crashed: " + r.stderr[-800:])
    return int(r.stdout.strip().splitlines()[-1])

def pure(cls, lines):
    r = tc.run(cls, "PageOpsHarnessKt", [], stdin="\n".join(lines) + "\n")
    if r.returncode:
        raise SystemExit("harness crashed: " + r.stderr[-800:])
    return r.stdout.split("\n")[:-1]

def sh(*cmd):
    return subprocess.run(cmd, capture_output=True, text=True)

# ---------------------------------------------------------------- building test PDFs (independent of the code under test)
def font_dict(pdf):
    return pdf.make_indirect(Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Helvetica))

def content(pdf, text, marker=None, at=(72, 700)):
    body = f"BT /F1 24 Tf {at[0]} {at[1]} Td ({text}) Tj ET\n"
    if marker:
        body += f"% {marker}\n"
    return pdf.make_stream(body.encode())

def build_flat(path, n, marker_page=None):
    pdf = pikepdf.new()
    font = font_dict(pdf)
    for i in range(n):
        pdf.add_blank_page(page_size=(612, 792))
        p = pdf.pages[-1]
        p.Resources = Dictionary(Font=Dictionary(F1=font))
        p.Contents = content(pdf, f"PAGE{i + 1:03d}", "DELMARKER_UNIQUE_%d" % (i + 1) + "_X" * 40 if marker_page == i else None)
    pdf.save(path, compress_streams=False)

def build_nested(path):
    """Root -> [A (MediaBox 300x400, Rotate 90, Resources F1) -> [p1, B(MediaBox 200x250) -> [p2, p3 (own MediaBox 500x500)]], C -> [p4]]. p4 inherits NOTHING (own box + resources)."""
    pdf = pikepdf.new()
    font = font_dict(pdf)
    res = pdf.make_indirect(Dictionary(Font=Dictionary(F1=font)))
    def page(text, **kw):
        # the text is drawn at (20, 100): the nested pages are only 200-500 pt high, a baseline at y = 700 would lie OUTSIDE the page and pdftotext would (rightly) print nothing
        d = Dictionary(Type=Name.Page, Contents=content(pdf, text, at=(20, 100)), **kw)
        return pdf.make_indirect(d)
    p1, p2, p3 = page("NEST1"), page("NEST2"), page("NEST3", MediaBox=Array([0, 0, 500, 500]))
    p4 = page("NEST4", MediaBox=Array([0, 0, 612, 792]), Resources=Dictionary(Font=Dictionary(F1=font)))
    B = pdf.make_indirect(Dictionary(Type=Name.Pages, MediaBox=Array([0, 0, 200, 250]), Kids=Array([p2, p3]), Count=2))
    A = pdf.make_indirect(Dictionary(Type=Name.Pages, MediaBox=Array([0, 0, 300, 400]), Rotate=90, Resources=res, Kids=Array([p1, B]), Count=3))
    C = pdf.make_indirect(Dictionary(Type=Name.Pages, Kids=Array([p4]), Count=1))
    root = pdf.make_indirect(Dictionary(Type=Name.Pages, Kids=Array([A, C]), Count=4))
    for kid, parent in ((p1, A), (B, A), (p2, B), (p3, B), (p4, C), (A, root), (C, root)):
        kid.Parent = parent
    pdf.Root.Pages = root
    pdf.save(path, compress_streams=False)

def build_outlined(path, n=6, labels=False):
    build_flat(path, n)
    pdf = pikepdf.open(path, allow_overwriting_input=True)
    with pdf.open_outline() as outline:
        ch1 = pikepdf.OutlineItem("Chapter A", 0)
        ch1.children.append(pikepdf.OutlineItem("A.1", 1))
        outline.root.extend([ch1, pikepdf.OutlineItem("Chapter B", 2), pikepdf.OutlineItem("Chapter C", 4)])
    if labels:
        pdf.Root.PageLabels = Dictionary(Nums=Array([0, Dictionary(S=Name.r), 2, Dictionary(S=Name.D, St=1)]))
    pdf.save(path, compress_streams=False)

def page_texts(path):
    n = int(re.search(r"Pages:\s+(\d+)", sh("pdfinfo", path).stdout).group(1))
    return [sh("pdftotext", "-f", str(i), "-l", str(i), path, "-").stdout.strip() for i in range(1, n + 1)]

def page_geom(path):
    out = sh("pdfinfo", "-f", "1", "-l", "9999", path).stdout
    sizes = [tuple(float(x) for x in m) for m in re.findall(r"Page\s+\d+ size:\s+([\d.]+) x ([\d.]+) pts", out)]
    rots = [int(x) for x in re.findall(r"Page\s+\d+ rot:\s+(\d+)", out)]
    return sizes, rots

def qpdf_ok(path):
    r = sh("qpdf", "--check", path)
    return r.returncode == 0 and "No syntax or stream encoding errors" in r.stdout

def root_info(path):
    """(list of /Type of the root's kids, has /PageLabels) read with pikepdf; the Pdf object is kept alive while reading"""
    with pikepdf.open(path) as pdf:
        kids = [str(k.get("/Type")) for k in pdf.Root.Pages.Kids]
        return kids, "/PageLabels" in pdf.Root

def outline_map(path):
    """bookmark title -> text of the page it opens (read with pikepdf, not with the code under test)"""
    pdf = pikepdf.open(path)
    ids = [p.objgen for p in pdf.pages]
    texts = page_texts(path)
    out = {}
    def walk(items):
        for it in items:
            d = it.destination
            if d is not None and len(d) and hasattr(d[0], "objgen") and d[0].objgen in ids:
                out[str(it.title)] = texts[ids.index(d[0].objgen)]
            walk(it.children)
    with pdf.open_outline() as outline:
        walk(outline.root)
    return out

def build_rot(path):
    pdf = pikepdf.new(); font = font_dict(pdf)
    for i, r in enumerate((90, 0, 270, 180)):
        pdf.add_blank_page(page_size=(300, 200)); p = pdf.pages[-1]
        p.Resources = Dictionary(Font=Dictionary(F1=font)); p.Contents = content(pdf, f"ROT{i}")
        if r: p.Rotate = r
    pdf.save(path, compress_streams=False)

ONLY_MUTANT = next((int(x.split("=")[1]) for x in sys.argv if x.startswith("--mutant=")), None)

def run_ab():
    # ---------------------------------------------------------------- A. pure functions against a Python model
    def norm(d): return (((int(d / 90)) % 4) + 4) % 4 * 90
    def m_rot(plan, pos, delta): return plan if not 0 <= pos < len(plan) else [(s, norm(t + delta)) if i == pos else (s, t) for i, (s, t) in enumerate(plan)]
    def m_del(plan, pos): return plan if not 0 <= pos < len(plan) or len(plan) <= 1 else plan[:pos] + plan[pos + 1:]
    def m_mov(plan, a, b):
        if not (0 <= a < len(plan) and 0 <= b < len(plan)) or a == b: return plan
        c = list(plan); x = c.pop(a); c.insert(b, x); return c
    def m_valid(plan, n): return bool(plan) and n > 0 and all(0 <= s < n for s, _ in plan) and all(t in (0, 90, 180, 270) for _, t in plan) and len({s for s, _ in plan}) == len(plan)
    def fmt(plan): return "-" if not plan else ",".join(f"{s}:{t}" for s, t in plan)

    print("== A. phần thuần so với mô hình độc lập")
    cls = build()
    rnd = random.Random(24)
    cmds, want = [], []
    for _ in range(3000):
        n = rnd.randint(1, 9)
        plan = [(i, 0) for i in range(n)]
        for _ in range(rnd.randint(0, 8)):
            op = rnd.choice("RDM")
            if op == "R": plan = m_rot(plan, rnd.randint(-1, len(plan)), rnd.choice([90, -90, 180, 270, 360, 450]))
            elif op == "D": plan = m_del(plan, rnd.randint(-1, len(plan)))
            else: plan = m_mov(plan, rnd.randint(-1, len(plan)), rnd.randint(-1, len(plan)))
        k = rnd.choice("RDMVUO")
        if k == "R": p, a = rnd.randint(-1, len(plan)), rnd.choice([90, -90, 180, 270, 360, 45]); cmds.append(f"ROT {fmt(plan)} {p} {a}"); want.append(fmt(m_rot(plan, p, a)))
        elif k == "D": p = rnd.randint(-1, len(plan)); cmds.append(f"DEL {fmt(plan)} {p}"); want.append(fmt(m_del(plan, p)))
        elif k == "M": a, b = rnd.randint(-1, len(plan)), rnd.randint(-1, len(plan)); cmds.append(f"MOV {fmt(plan)} {a} {b}"); want.append(fmt(m_mov(plan, a, b)))
        elif k == "V":
            bad = list(plan)
            if rnd.random() < .5 and bad: bad.append(rnd.choice(bad))
            if rnd.random() < .3 and bad: bad[0] = (bad[0][0], rnd.choice([0, 45, 90, 360]))
            cmds.append(f"VAL {n} {fmt(bad)}"); want.append("1" if m_valid(bad, n) else "0")
        elif k == "U": cmds.append(f"UNCH {n} {fmt(plan)}"); want.append("1" if plan == [(i, 0) for i in range(n)] else "0")
        else: cmds.append(f"ORD {n} {fmt(plan)}"); want.append("1" if [s for s, _ in plan] != list(range(n)) else "0")
    got = pure(cls, cmds)
    bad = [(c, w, g) for c, w, g in zip(cmds, want, got) if w != g]
    check(not bad, f"3 000 phép thuần của Kotlin thật khớp mô hình Python {bad[:1]}")
    check(pure(cls, ["NORM 450", "NORM -90", "NORM 360", "NORM 0", "NORM 270", "ID 3", "DEL 0:0 0", "VAL 3 -", "VAL 0 0:0"]) == ["90", "270", "0", "0", "270", "0:0,1:0,2:0", "0:0", "0", "0"],
          "góc chuẩn hoá (450 -> 90, -90 -> 270), trang cuối không xoá được, kế hoạch rỗng / tài liệu rỗng không hợp lệ")

    # ---------------------------------------------------------------- B. real runs
    print("== B. chạy thật")
    def run_case(name, builder, plan, expect_n=None):
        src = os.path.join(WORK, name + "-src.pdf"); out = os.path.join(WORK, name + "-out.pdf")
        builder(src)
        return src, out, apply_real(cls, src, plan, out)

    # B1 flat
    src, out, n = run_case("flat", lambda p: build_flat(p, 6, marker_page=2), "5:0,0:90,3:0,1:180,4:0")
    t = page_texts(out)
    check(n == 5 and t == ["PAGE006", "PAGE001", "PAGE004", "PAGE002", "PAGE005"], f"(1) cây phẳng: đảo thứ tự + xoá trang 3: chữ từng trang đúng thứ tự {t}")
    sizes, rots = page_geom(out)
    check(rots == [0, 90, 0, 180, 0], f"(1) hướng trang: 0, 90, 0, 180, 0 ({rots})")
    check(b"DELMARKER_UNIQUE_3" in open(src, "rb").read() and b"DELMARKER_UNIQUE_3" not in open(out, "rb").read(), "(1) nội dung riêng của trang đã xoá có trong tệp gốc nhưng KHÔNG còn trong kết quả")
    check(qpdf_ok(out), "(10) qpdf --check sạch (cây phẳng)")
    check(os.path.getsize(out) < os.path.getsize(src), f"(1) kết quả nhỏ hơn bản gốc khi xoá trang ({os.path.getsize(out)} < {os.path.getsize(src)})")

    # B2 nested with inheritance
    src, out, n = run_case("nested", build_nested, "3:0,0:0,2:90,1:0")
    sizes, rots = page_geom(out); t = page_texts(out)
    check(n == 4 and t == ["NEST4", "NEST1", "NEST3", "NEST2"], f"(2) cây lồng: chữ các trang (phông thừa kế từ nút trung gian vẫn dùng được) {t}")
    # pdfinfo prints the page box as stored (not swapped for /Rotate): NEST4 612x792 rot0; NEST1 inherits 300x400 + Rotate 90; NEST3 own 500x500 + inherited Rotate 90 + turn 90 = 180; NEST2 inherits 200x250 + Rotate 90
    check(sizes == [(612.0, 792.0), (300.0, 400.0), (500.0, 500.0), (200.0, 250.0)] and rots == [0, 90, 180, 90], f"(2) cỡ và hướng của từng trang giữ đúng dù không còn nút cha: {sizes} {rots}")
    rootkids = root_info(out)[0]
    check(rootkids == ["/Page"] * 4, f"(2) cây trang phẳng, không còn nút /Pages rỗng: {rootkids}")
    check(qpdf_ok(out), "(10) qpdf --check sạch (cây lồng)")

    # B3 bookmarks
    src, out, n = run_case("outline", lambda p: build_outlined(p, 6), "5:0,4:0,2:0,3:0,0:0")      # pages 1 (idx1) deleted -> "A.1" (page idx 1) disappears
    m = outline_map(out)
    check(m == {"Chapter A": "PAGE001", "Chapter B": "PAGE003", "Chapter C": "PAGE005"}, f"(3) dấu trang theo trang tới chỗ mới; 'A.1' (trang đã xoá) biến mất: {m}")
    check(qpdf_ok(out), "(10) qpdf --check sạch (có mục lục)")
    src, out, n = run_case("outline-del-all-marked", lambda p: build_outlined(p, 6), "3:0,1:0")
    m = outline_map(out)
    check(m == {"A.1": "PAGE002"} and n == 2, f"(3) xoá hết trang có dấu trang trừ một: chỉ còn dấu trang của trang còn lại {m}")

    # B4 page labels
    src, out, n = run_case("labels-reorder", lambda p: build_outlined(p, 6, labels=True), "1:0,0:0,2:0,3:0,4:0,5:0")
    check(not root_info(out)[1], "(4) đổi thứ tự trang -> nhãn trang (/PageLabels) bị bỏ")
    src, out, n = run_case("labels-rotate", lambda p: build_outlined(p, 6, labels=True), "0:90,1:0,2:0,3:0,4:0,5:0")
    check(root_info(out)[1] and page_geom(out)[1][0] == 90, "(4) chỉ xoay -> nhãn trang được GIỮ và trang 1 xoay 90")
    src, out, n = run_case("labels-delete", lambda p: build_outlined(p, 6, labels=True), "0:0,1:0,2:0,3:0,4:0")
    check(not root_info(out)[1], "(4) xoá trang cuối -> nhãn trang bị bỏ (số thứ tự không còn khớp)")

    # B5 cumulative rotation
    src, out, n = run_case("rot", build_rot, "0:270,1:90,2:90,3:180")
    check(page_geom(out)[1] == [0, 90, 0, 0], f"(5) /Rotate sẵn có cộng dồn: 90+270=0, 0+90=90, 270+90=0, 180+180=0 ({page_geom(out)[1]})")

    # B6 invalid plans
    src = os.path.join(WORK, "inv-src.pdf"); build_flat(src, 4)
    for label, plan in (("trang trùng", "0:0,0:90"), ("ngoài phạm vi", "0:0,9:0"), ("số âm", "-1:0"), ("góc 45", "0:45"), ("rỗng", "-")):
        out = os.path.join(WORK, "inv-out.pdf")
        if os.path.exists(out): os.remove(out)
        r = apply_real(cls, src, plan, out)
        check(r == -1 and not os.path.exists(out), f"(6) kế hoạch sai ({label}) -> -1 và không để lại tệp")

    # B7 encrypted
    enc = os.path.join(WORK, "enc-src.pdf"); build_flat(os.path.join(WORK, "enc-plain.pdf"), 3)
    with pikepdf.open(os.path.join(WORK, "enc-plain.pdf")) as pdf:
        pdf.save(enc, encryption=pikepdf.Encryption(user="u", owner="o"))
    out = os.path.join(WORK, "enc-out.pdf")
    check(apply_real(cls, enc, "0:0", out) == -1 and not os.path.exists(out), "(7) tệp mã hoá -> -1 (trình đọc làm việc trên bản đã mở khoá)")

    # B8 identity
    src, out, n = run_case("ident", lambda p: build_flat(p, 5), "0:0,1:0,2:0,3:0,4:0")
    check(n == 5 and page_texts(out) == page_texts(src) and page_geom(out) == page_geom(src), "(8) kế hoạch nguyên trạng cho cùng chữ, cỡ và hướng")

    # B9 big book, shuffled
    src = os.path.join(WORK, "big-src.pdf"); build_flat(src, 300)
    order = list(range(300)); random.Random(5).shuffle(order); order = order[:280]
    plan = ",".join(f"{s}:{(90 * (s % 4))}" for s in order)
    out = os.path.join(WORK, "big-out.pdf"); t0 = time.time(); n = apply_real(cls, src, plan, out); dt = time.time() - t0
    t = page_texts(out); sizes, rots = page_geom(out)
    check(n == 280 and t == [f"PAGE{s + 1:03d}" for s in order] and rots == [90 * (s % 4) for s in order], f"(9) sách 300 trang xáo trộn, bỏ 20 trang: đúng thứ tự và hướng cả 280 trang ({dt:.1f}s)")
    check(qpdf_ok(out), "(10) qpdf --check sạch (300 trang)")



if ONLY_MUTANT is None:
    run_ab()

# ---------------------------------------------------------------- C. negative tests
if "--fast" in sys.argv and ONLY_MUTANT is None:
    print("== C. bỏ qua thử âm tính (--fast)")
else:
    print("== C. thử âm tính: bản Kotlin hỏng phải bị bắt")
    MUTANTS = [
        ("bỏ ghi thuộc tính thừa kế lên trang", "PdfPageOps.kt", ("            for (page in originals) materializeInherited(page)\n", "")),
        ("không dọn nút trung gian rỗng", "PdfPageOps.kt", ("            root.setItem(COSName.KIDS, COSArray())\n", "")),
        ("dấu trang không dời theo trang", "PdfPageOps.kt", ("PdfBookmarks.write(d, remapBookmarks(bookmarks, plan))", "PdfBookmarks.write(d, bookmarks)")),
        ("giữ nhãn trang cũ khi đổi thứ tự", "PdfPageOps.kt", ("d.documentCatalog.cosObject.removeItem(COSName.PAGE_LABELS)", "Unit")),
        ("bỏ qua /Rotate sẵn có", "PdfPageOps.kt", ("page.rotation = normalizeTurn(page.rotation + e.turn)", "page.rotation = normalizeTurn(e.turn)")),
        ("cho xoá cả trang cuối", "PdfPageOps.kt", ("plan.size <= 1) return plan", "plan.isEmpty()) return plan")),
        ("chấp nhận trang trùng", "PdfPageOps.kt", ("            if (!seen.add(e.source)) return false\n", "")),
        # (đột biến "bỏ vòng gỡ từng trang trước khi đặt lại /Kids" là TƯƠNG ĐƯƠNG - việc đặt lại /Kids đã bỏ hết cây cũ - nên mã thừa đó đã được GỠ khỏi PdfPageOps, không đưa vào đây)
        ("thêm trang theo thứ tự ngược", "PdfPageOps.kt", ("            for (e in plan) {\n                val page = originals[e.source]", "            for (e in plan.reversed()) {\n                val page = originals[e.source]")),
    ]
    for number, (name, fname, (old, new)) in enumerate(MUTANTS, 1):
        if ONLY_MUTANT is not None and number != ONLY_MUTANT:
            continue
        try:
            mcls = build({fname: (old, new)}, tag="mut")
        except RuntimeError as exc:
            check(True, f"ÂM TÍNH '{name}': bản hỏng thậm chí không biên dịch được (bị bắt)")
            continue
        caught = False
        try:
            r1 = pure(mcls, ["DEL 0:0 0", "VAL 3 0:0,0:90", "VAL 3 0:0,1:0"])
            if r1 != ["0:0", "0", "1"]: caught = True
            s1 = os.path.join(WORK, "m-nested.pdf"); build_nested(s1); o1 = os.path.join(WORK, "m-nested-out.pdf")
            n1 = apply_real(mcls, s1, "3:0,0:0,2:90,1:0", o1)
            if n1 != 4: caught = True
            else:
                sz, rt = page_geom(o1); kids = root_info(o1)[0]
                if sz != [(612.0, 792.0), (300.0, 400.0), (500.0, 500.0), (200.0, 250.0)] or rt != [0, 90, 180, 90] or kids != ["/Page"] * 4 or page_texts(o1) != ["NEST4", "NEST1", "NEST3", "NEST2"]: caught = True
            s2 = os.path.join(WORK, "m-ol.pdf"); build_outlined(s2, 6, labels=True); o2 = os.path.join(WORK, "m-ol-out.pdf")
            n2 = apply_real(mcls, s2, "5:0,4:0,2:0,3:0,0:0", o2)
            if n2 != 5 or outline_map(o2) != {"Chapter A": "PAGE001", "Chapter B": "PAGE003", "Chapter C": "PAGE005"} or root_info(o2)[1]: caught = True
            s3 = os.path.join(WORK, "m-rot.pdf"); build_rot(s3); o3 = os.path.join(WORK, "m-rot-out.pdf")
            n3 = apply_real(mcls, s3, "0:270,1:90,2:90,3:180", o3)
            if n3 != 4 or page_geom(o3)[1] != [0, 90, 0, 0]: caught = True
            o4 = os.path.join(WORK, "m-dup-out.pdf")
            if os.path.exists(o4): os.remove(o4)
            if apply_real(mcls, s1, "0:0,0:90", o4) != -1: caught = True
            o5 = os.path.join(WORK, "m-del-out.pdf")
            s5 = os.path.join(WORK, "m-flat.pdf"); build_flat(s5, 5)
            n5 = apply_real(mcls, s5, "4:0,0:0", o5)
            if n5 != 2 or page_texts(o5) != ["PAGE005", "PAGE001"]: caught = True
        except SystemExit:
            caught = True
        check(caught, f"ÂM TÍNH '{name}': bản hỏng bị bắt")

shutil.rmtree(WORK, ignore_errors=True)
print("\nTAT CA DAT" if not fails else f"\n{len(fails)} LOI")
sys.exit(1 if fails else 0)
