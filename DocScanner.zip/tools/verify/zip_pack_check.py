"""ZipPack (phiên 22, mục 4.49.1): "Nén thành ZIP" có mật khẩu AES-256 (WinZip AE-2).

Kiểm bản Java song song (ZipPackCheck.java, cùng thuật toán với ZipPack.kt) bằng một BỘ ĐỌC ĐỘC LẬP viết ở đây THEO ĐẶC TẢ WinZip AES
(không dùng lại mã của bản ghi): hashlib.pbkdf2_hmac, `cryptography` (AES-ECB tự ghép bộ đếm little-endian), hmac, zlib, struct.
  1. PBKDF2-HMAC-SHA1: Java = hashlib trên mật khẩu ASCII / tiếng Việt / emoji, muối ngẫu nhiên, 1..1000 vòng, độ dài 1..100 byte.
  2. entryNames: tính chất (duy nhất không phân biệt hoa/thường, không ký tự cấm, không rỗng, giữ nguyên tên đã hợp lệ).
  3. dosDateTime: Java = datetime của Python theo múi giờ (zoneinfo), trước 1980 bị kẹp.
  4. ZIP thường: zipfile.testzip(), tên / nội dung / kiểu nén (pdf lưu nguyên, txt nén), `unzip -t`.
  5. ZIP AES: cấu trúc (cờ, phương thức 99, trường 0x9901, CRC 0 của AE-2, kích thước ở đầu cục bộ = thư mục trung tâm, offset), giải mã bằng bộ đọc
     độc lập (khớp từng byte với tệp gốc: rỗng, 1, 15, 16, 17 byte, 64 KiB +-1, 5 MB ngẫu nhiên, 3 MB văn bản), zipinfo đọc được cấu trúc.
  6. Sai mật khẩu bị loại bởi giá trị xác minh; sửa 1 byte dữ liệu bị HMAC bắt; sửa muối bị bắt.
  7. THỬ ÂM TÍNH (bộ kiểm có răng): bộ đếm big-endian và mật khẩu cắt 8-bit (kiểu PKCS#5 8-bit của nhà cung cấp Android) KHÔNG giải mã được tệp.
Chạy: python3 zip_pack_check.py   (cần java, cryptography; ~1-2 phút)
"""
import hashlib, hmac, os, random, struct, subprocess, sys, zipfile, zlib, tempfile, datetime
from zoneinfo import ZoneInfo
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from _common import OUT

HERE = os.path.dirname(os.path.abspath(__file__))
JAVA = os.path.join(HERE, "ZipPackCheck.java")
ENV = dict(os.environ, LC_ALL="C.UTF-8")
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

def java(args, stdin=None):
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", "-Dstdout.encoding=UTF-8", "-Dsun.jnu.encoding=UTF-8", JAVA] + args, capture_output=True, text=True, input=stdin, env=ENV)
    if r.returncode != 0: raise RuntimeError(r.stderr)
    return r.stdout.split("\n")[:-1] if r.stdout else []

rnd = random.Random(2210)

# ---------- 1. PBKDF2 ----------
pws = ["password", "Mật khẩu tiếng Việt!", "🔐emoji🔐", "a", "x" * 200, "Đặng Văn Ấn 123"]
cases = []
for pw in pws:
    for _ in range(4):
        salt = bytes(rnd.randrange(256) for _ in range(16)); it = rnd.choice([1, 2, 5, 1000, 1000]); ln = rnd.choice([1, 20, 21, 66, 100])
        cases.append((pw, salt, it, ln))
out = java(["pbkdf2batch"], "\n".join(f"{pw.encode().hex()} {salt.hex()} {it} {ln}" for pw, salt, it, ln in cases) + "\n")
bad = [c for c, o in zip(cases, out) if hashlib.pbkdf2_hmac("sha1", c[0].encode("utf-8"), c[1], c[2], c[3]).hex() != o]
check(len(out) == len(cases) and not bad, f"PBKDF2-HMAC-SHA1: Java = hashlib trên {len(cases)} ca (ASCII, tiếng Việt, emoji, mật khẩu 200 ký tự)")
# thêm bằng chứng cho lý do tự viết PBKDF2: cắt 8-bit khác UTF-8 với mật khẩu có dấu
vn = "Mật khẩu"; low8 = bytes(ord(c) & 0xFF for c in vn)
check(low8 != vn.encode("utf-8") and hashlib.pbkdf2_hmac("sha1", low8, b"s" * 16, 1000, 66) != hashlib.pbkdf2_hmac("sha1", vn.encode(), b"s" * 16, 1000, 66),
      "mật khẩu có dấu: kiểu cắt 8-bit cho khoá KHÁC UTF-8 (đúng lý do không gọi SecretKeyFactory)")

# ---------- 2. entryNames ----------
names_in = ["a.pdf", "A.PDF", "dir/sub/x.txt", "...", "", "bad:na*me?.txt", "tên tệp.pdf", "tên tệp.pdf", "TÊN TỆP.PDF", "x\\y\\z.doc", "noext", "noext", "a.tar.gz", "a.tar.gz", "  sp  .txt", "\u0001ctl.txt"]
res = java(["names"] + names_in)
forbidden = set('/\\:*?"<>|') | {chr(i) for i in range(32)}
check(len(res) == len(names_in) and len({r.lower() for r in res}) == len(res), f"entryNames: {len(res)} tên duy nhất không phân biệt hoa/thường {res}")
check(all(r and not (set(r) & forbidden) for r in res), "entryNames: không rỗng, không ký tự cấm / điều khiển")
safe = ["one.pdf", "two (2).txt", "ba.docx", "tên.pdf"]
check(java(["names"] + safe) == safe, "entryNames: danh sách tên đã hợp lệ và khác nhau được giữ NGUYÊN")
check(res[res.index("tên tệp.pdf") + 1] == "tên tệp (2).pdf" and res[res.index("tên tệp.pdf") + 2] == "TÊN TỆP (3).PDF", "entryNames: bản trùng đánh số (2), (3) trước phần mở rộng")

# ---------- 3. dos date/time ----------
zones = ["UTC", "Asia/Ho_Chi_Minh", "America/New_York", "Asia/Kolkata", "Pacific/Auckland"]
ms = [rnd.randrange(315532800000, 4102444800000) for _ in range(300)] + [0, 315532799000, 315532800000, 946684799000]
lines = [(m, rnd.choice(zones)) for m in ms]
out = java(["dosbatch"], "\n".join(f"{m} {z}" for m, z in lines) + "\n")
def ref(m, z):
    dt = datetime.datetime.fromtimestamp(m / 1000, ZoneInfo(z))
    if dt.year < 1980: return (0, (1 << 5) | 1)
    return ((dt.hour << 11) | (dt.minute << 5) | (dt.second // 2), ((dt.year - 1980) << 9) | (dt.month << 5) | dt.day)
bad = [(l, o) for l, o in zip(lines, out) if tuple(map(int, o.split())) != ref(*l)]
check(len(out) == len(lines) and not bad, f"dosDateTime: Java = datetime/zoneinfo trên {len(lines)} ca (5 múi giờ, kẹp 1980){'' if not bad else ' ' + str(bad[:2])}")

# ---------- files for packing ----------
work = tempfile.mkdtemp(prefix="zp_", dir=OUT)
def mk(name, data):
    p = os.path.join(work, name); open(p, "wb").write(data); return p
text = ("Xin chào thế giới, đây là văn bản tiếng Việt có dấu. " * 200).encode()
blobs = {
    "empty.txt": b"", "one.txt": b"x", "f15.txt": text[:15], "f16.txt": text[:16], "f17.txt": text[:17],
    "k64m.bin": os.urandom(65535), "k64.bin": os.urandom(65536), "k64p.bin": os.urandom(65537),
    "rand5m.dat": os.urandom(5_000_000), "text3m.txt": (text * 300)[:3_000_000], "doc.pdf": b"%PDF-1.4\n" + os.urandom(100_000),
    "tên đẹp 🙂.md": "# tiêu đề\nnội dung\n".encode() * 50,
}
paths = {n: mk("src_" + n.replace("/", "_"), d) for n, d in blobs.items()}
os.utime(paths["doc.pdf"], (1_700_000_000, 1_700_000_000))
order = list(blobs) + ["one.txt"]           # "one.txt" lặp -> "one (2).txt"
pack_args = []
for n in order: pack_args += [paths[n], n]

def pack(name, pw, seed=7, tz="Asia/Ho_Chi_Minh"):
    out_zip = os.path.join(work, name)
    java(["pack", out_zip, "-" if pw is None else pw.encode().hex(), str(seed), tz] + pack_args)
    return out_zip
expected_names = java(["names"] + order)
expected = [blobs[n] for n in order]

# ---------- 4. ZIP thường ----------
zp = pack("plain.zip", None)
with zipfile.ZipFile(zp) as z:
    check(z.testzip() is None, "ZIP thường: zipfile.testzip() sạch (CRC từng mục)")
    check([i.filename for i in z.infolist()] == expected_names, "ZIP thường: tên mục đúng và đúng thứ tự")
    check(all(z.read(n) == d for n, d in zip(expected_names, expected)), "ZIP thường: nội dung từng mục khớp từng byte")
    kinds = {i.filename: i.compress_type for i in z.infolist()}
    check(kinds["doc.pdf"] == zipfile.ZIP_STORED and kinds["text3m.txt"] == zipfile.ZIP_DEFLATED, "ZIP thường: pdf lưu nguyên, văn bản nén")
    check(z.getinfo("doc.pdf").date_time[0] >= 2023, "ZIP thường: giữ ngày sửa tệp")
r = subprocess.run(["unzip", "-tq", zp], capture_output=True, text=True)
check(r.returncode == 0 and "No errors" in r.stdout, "ZIP thường: `unzip -t` không lỗi")

# ---------- bộ đọc AES ĐỘC LẬP ----------
def ctr_stream(key, nblocks_bytes, endian="little"):
    ecb = Cipher(algorithms.AES(key), modes.ECB()).encryptor(); out = bytearray(); c = 1
    while len(out) < nblocks_bytes:
        out += ecb.update(c.to_bytes(16, endian)); c += 1
    return bytes(out[:nblocks_bytes])

def parse(path):
    d = open(path, "rb").read()
    eocd = d.rfind(b"PK\x05\x06"); assert eocd >= 0
    _, dn, cdn, n_here, n_all, cdsize, cdoff, clen = struct.unpack("<IHHHHIIH", d[eocd:eocd + 22])
    assert clen == 0 and dn == 0 and cdn == 0 and n_here == n_all and cdoff + cdsize == eocd
    ents = []; p = cdoff
    for _ in range(n_all):
        (sig, vmade, vneed, flag, meth, t, dt, crc, csz, usz, nl, el, cl, ds, ia, ea, lho) = struct.unpack("<IHHHHHHIIIHHHHHII", d[p:p + 46])
        assert sig == 0x02014b50
        name = d[p + 46:p + 46 + nl].decode("utf-8"); extra = d[p + 46 + nl:p + 46 + nl + el]
        ents.append(dict(vneed=vneed, flag=flag, meth=meth, time=t, date=dt, crc=crc, csz=csz, usz=usz, name=name, extra=extra, lho=lho))
        p += 46 + nl + el + cl
    assert p == eocd
    for e in ents:
        (sig, vneed, flag, meth, t, dt, crc, csz, usz, nl, el) = struct.unpack("<IHHHHHIIIHH", d[e["lho"]:e["lho"] + 30])
        assert sig == 0x04034b50
        lname = d[e["lho"] + 30:e["lho"] + 30 + nl].decode("utf-8"); lextra = d[e["lho"] + 30 + nl:e["lho"] + 30 + nl + el]
        e["local"] = dict(vneed=vneed, flag=flag, meth=meth, time=t, date=dt, crc=crc, csz=csz, usz=usz, name=lname, extra=lextra)
        e["data"] = d[e["lho"] + 30 + nl + el:e["lho"] + 30 + nl + el + csz]
    return d, ents

def decrypt(e, password, endian="little", low8=False, pw_bytes=None):
    """-> (status, plaintext): status in ok / bad_password / bad_mac"""
    blob = e["data"]; salt, pvv, body, mac = blob[:16], blob[16:18], blob[18:-10], blob[-10:]
    pwb = pw_bytes if pw_bytes is not None else (bytes(ord(c) & 0xFF for c in password) if low8 else password.encode("utf-8"))
    dk = hashlib.pbkdf2_hmac("sha1", pwb, salt, 1000, 66)
    if dk[64:66] != pvv: return "bad_password", None
    if hmac.new(dk[32:64], body, "sha1").digest()[:10] != mac: return "bad_mac", None
    ks = ctr_stream(dk[:32], len(body), endian)
    plain = bytes(a ^ b for a, b in zip(body, ks))
    return "ok", (zlib.decompress(plain, -15) if e["extra"][-2:] == b"\x08\x00" else plain)

PW = "Mật khẩu 🔐 dài-123"
zp = pack("aes.zip", PW, seed=11)
d, ents = parse(zp)
check([e["name"] for e in ents] == expected_names, "ZIP AES: tên mục đúng, UTF-8")
spec_ok = True
for e in ents:
    L = e["local"]
    spec_ok &= e["flag"] == 0x0801 and L["flag"] == 0x0801 and e["meth"] == 99 and L["meth"] == 99 and e["vneed"] == 51 and L["vneed"] == 51
    spec_ok &= e["crc"] == 0 and L["crc"] == 0                                   # AE-2: không lưu CRC
    spec_ok &= e["csz"] == L["csz"] and e["usz"] == L["usz"] and L["name"] == e["name"]
    spec_ok &= e["extra"] == L["extra"] and e["extra"][:9] == b"\x01\x99\x07\x00\x02\x00AE\x03"   # 0x9901, size 7, v2, "AE", AES-256
    spec_ok &= (e["extra"][9:11] == b"\x00\x00") == (e["name"].lower().rsplit(".", 1)[-1] in ("pdf",))
check(spec_ok, "ZIP AES: cờ 0x0801, phương thức 99, version 51, CRC 0 (AE-2), trường 0x9901 {v2,'AE',256-bit,phương thức thật}, đầu cục bộ = thư mục trung tâm")
check(all(len(e["data"]) >= 28 for e in ents) and all(e["lho"] < ents[i + 1]["lho"] for i, e in enumerate(ents[:-1])), "ZIP AES: muối 16 + PVV 2 + MAC 10, offset tăng dần")
res = [decrypt(e, PW) for e in ents]
check(all(s == "ok" for s, _ in res), "ZIP AES: mọi mục qua kiểm giá trị xác minh + HMAC")
bad = [e["name"] for e, (s, p), want in zip(ents, res, expected) if p != want]
check(not bad, f"ZIP AES: giải mã bằng bộ đọc ĐỘC LẬP khớp từng byte {len(ents)} mục (rỗng, 1/15/16/17 byte, 64 KiB±1, 5 MB ngẫu nhiên, 3 MB văn bản, tên emoji, trùng tên){'' if not bad else ' sai: ' + str(bad)}")
check(len({e["data"][:16] for e in ents}) == len(ents), "ZIP AES: mỗi mục có MUỐI RIÊNG")
with zipfile.ZipFile(zp) as z:
    check([i.filename for i in z.infolist()] == expected_names and all(i.compress_type == 99 for i in z.infolist()), "ZIP AES: zipfile đọc được thư mục trung tâm (phương thức 99)")
r = subprocess.run(["zipinfo", zp], capture_output=True, text=True)
check(r.returncode == 0 and f"{len(order)} files" in r.stdout and "Zp" not in r.stdout.split("\n")[0], f"ZIP AES: zipinfo (Info-ZIP) phân tích đủ {len(order)} mục")

# ---------- 6. phá hoại ----------
e0 = next(e for e in ents if e["name"] == "text3m.txt")
check(decrypt(e0, "sai mat khau")[0] == "bad_password", "sai mật khẩu bị loại bởi giá trị xác minh 2 byte")
t = dict(e0); b = bytearray(t["data"]); b[len(b) // 2] ^= 1; t["data"] = bytes(b)
check(decrypt(t, PW)[0] == "bad_mac", "sửa 1 bit dữ liệu mã hoá bị HMAC bắt")
t = dict(e0); b = bytearray(t["data"]); b[3] ^= 1; t["data"] = bytes(b)
check(decrypt(t, PW)[0] == "bad_password", "sửa muối làm sai khoá, bị bắt")
t = dict(e0); b = bytearray(t["data"]); b[-1] ^= 1; t["data"] = bytes(b)
check(decrypt(t, PW)[0] == "bad_mac", "sửa mã xác thực bị bắt")

# ---------- 7. thử âm tính ----------
e1 = next(e for e in ents if e["name"] == "f17.txt")
def wrong(endian):
    try: return decrypt(e1, PW, endian=endian)[1] != blobs["f17.txt"]
    except zlib.error: return True        # dòng khoá sai -> dữ liệu nén thành rác: cũng là "không giải mã được"
check(wrong("big"), "ÂM TÍNH: bộ đếm big-endian KHÔNG giải mã được (bộ kiểm bắt lỗi thứ tự byte của bộ đếm)")
check(decrypt(e1, PW, low8=True)[0] == "bad_password", "ÂM TÍNH: mật khẩu cắt 8-bit (kiểu nhà cung cấp Android) KHÔNG mở được")
zp2 = pack("aes2.zip", PW, seed=11)
check(open(zp, "rb").read() == open(zp2, "rb").read(), "cùng hạt giống ngẫu nhiên -> cùng byte (bộ ghi xác định, không phụ thuộc giờ)")
zp3 = pack("aes3.zip", PW, seed=12)
check(open(zp, "rb").read() != open(zp3, "rb").read(), "khác hạt giống -> khác muối -> khác byte")

print()
print("TAT CA DAT" if not fails else f"{len(fails)} LOI: {fails}")
sys.exit(1 if fails else 0)
