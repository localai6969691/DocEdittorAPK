// Bản Java song song (chạy được trên máy tính) của EbookBuilder.fb2Document + esc/xmlSafe (phiên 16) - cùng logic, cùng thứ tự phần tử.
// Dùng bởi tools/verify/fb2_check.py:  java Fb2Check.java <vào> <ra .fb2>
// Vào: mỗi dòng "BOOK\t<tên sách>" (một lần), "C\t<tên chương>" (bắt đầu chương), "P\t<đoạn>" (thuộc chương gần nhất).
// Mọi ký tự lạ được viết dạng \\uXXXX (và \\\\ cho dấu gạch chéo ngược) để đưa cả ký tự điều khiển / surrogate lẻ qua tệp văn bản.
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class Fb2Check {
    record Chapter(String title, List<String> paragraphs) {}

    static String unescape(String s) {
        StringBuilder o = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char d = s.charAt(i + 1);
                if (d == '\\') { o.append('\\'); i++; }
                else if (d == 'u') { o.append((char) Integer.parseInt(s.substring(i + 2, i + 6), 16)); i += 5; }
                else o.append(c);
            } else o.append(c);
        }
        return o.toString();
    }

    static boolean isXmlChar(int cp) {
        return cp == 0x9 || cp == 0xA || cp == 0xD || (cp >= 0x20 && cp <= 0xD7FF) || (cp >= 0xE000 && cp <= 0xFFFD) || (cp >= 0x10000 && cp <= 0x10FFFF);
    }

    static String xmlSafe(String s) {
        boolean clean = true;
        for (int i = 0; i < s.length(); ) { int cp = s.codePointAt(i); if (!isXmlChar(cp)) { clean = false; break; } i += Character.charCount(cp); }
        if (clean) return s;
        StringBuilder out = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); ) { int cp = s.codePointAt(i); int len = Character.charCount(cp); if (isXmlChar(cp)) out.append(s, i, i + len); i += len; }
        return out.toString();
    }

    static String esc(String s) {
        return xmlSafe(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;");
    }

    static String fb2Document(String bookTitle, List<Chapter> chapters, String id, String isoDate) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        sb.append("<FictionBook xmlns=\"http://www.gribuser.ru/xml/fictionbook/2.0\" xmlns:l=\"http://www.w3.org/1999/xlink\">\n");
        sb.append("<description>\n<title-info>\n");
        sb.append("<genre>nonfiction</genre>\n");
        sb.append("<author><nickname>DocScanner</nickname></author>\n");
        sb.append("<book-title>").append(esc(bookTitle)).append("</book-title>\n");
        sb.append("<date value=\"").append(isoDate).append("\">").append(isoDate).append("</date>\n");
        sb.append("<lang>vi</lang>\n</title-info>\n");
        sb.append("<document-info>\n<author><nickname>DocScanner</nickname></author>\n");
        sb.append("<program-used>DocScanner</program-used>\n");
        sb.append("<date value=\"").append(isoDate).append("\">").append(isoDate).append("</date>\n");
        sb.append("<id>").append(esc(id)).append("</id>\n<version>1.0</version>\n</document-info>\n");
        sb.append("</description>\n<body>\n");
        if (!bookTitle.isBlank()) sb.append("<title><p>").append(esc(bookTitle)).append("</p></title>\n");
        String noText = "(không có văn bản)";
        List<Chapter> sections = chapters.isEmpty() ? List.of(new Chapter("", List.of())) : chapters;
        for (Chapter chapter : sections) {
            sb.append("<section>\n");
            if (!chapter.title().isBlank()) sb.append("<title><p>").append(esc(chapter.title())).append("</p></title>\n");
            List<String> paragraphs = new ArrayList<>();
            for (String p : chapter.paragraphs()) if (!p.isBlank()) paragraphs.add(p);
            if (paragraphs.isEmpty()) sb.append("<p>").append(noText).append("</p>\n");
            else for (String p : paragraphs) sb.append("<p>").append(esc(p.trim())).append("</p>\n");
            sb.append("</section>\n");
        }
        sb.append("</body>\n</FictionBook>\n");
        return sb.toString();
    }

    public static void main(String[] args) throws Exception {
        String book = "";
        List<Chapter> chapters = new ArrayList<>();
        String curTitle = null; List<String> cur = null;
        for (String line : Files.readAllLines(Paths.get(args[0]), StandardCharsets.UTF_8)) {
            if (line.isEmpty()) continue;
            int tab = line.indexOf('\t');
            String kind = line.substring(0, tab), val = unescape(line.substring(tab + 1));
            if (kind.equals("BOOK")) book = val;
            else if (kind.equals("C")) { if (cur != null) chapters.add(new Chapter(curTitle, cur)); curTitle = val; cur = new ArrayList<>(); }
            else if (kind.equals("P")) { if (cur == null) { curTitle = ""; cur = new ArrayList<>(); } cur.add(val); }
        }
        if (cur != null) chapters.add(new Chapter(curTitle, cur));
        String xml = fb2Document(book, chapters, "00000000-0000-4000-8000-000000000001", "2026-10-10");
        Files.write(Paths.get(args[1]), xml.getBytes(StandardCharsets.UTF_8));
    }
}
