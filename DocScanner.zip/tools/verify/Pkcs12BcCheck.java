import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.security.cert.X509Certificate;
import java.util.*;

/**
 * Reads PKCS#12 files with the BOUNCYCASTLE provider instead of the JDK's own (phiên 22, 4.49.8): Android's KeyStore.getInstance("PKCS12") is
 * BouncyCastle's, and the JDK refuses non-ASCII passwords ("Password is not ASCII"). Run with bcprov on the class path:
 *   java -cp /usr/share/java/bcprov.jar Pkcs12BcCheck.java <file.p12> <passwordHexUtf8>   ->  "OK <alg> <chainLength>" or "FAIL <message>"
 */
public class Pkcs12BcCheck {
    public static void main(String[] a) throws Exception {
        Security.insertProviderAt(new org.bouncycastle.jce.provider.BouncyCastleProvider(), 1);
        byte[] bytes = Files.readAllBytes(Paths.get(a[0]));
        byte[] pb = new byte[a[1].length() / 2]; for (int i = 0; i < pb.length; i++) pb[i] = (byte) Integer.parseInt(a[1].substring(2 * i, 2 * i + 2), 16);
        String typed = new String(pb, StandardCharsets.UTF_8);
        boolean variants = a.length > 2 && a[2].equals("variants");      // mirror of Pkcs12Import.passwordVariants: typed, NFC, NFD
        List<String> tries = new ArrayList<>(); tries.add(typed);
        if (variants) { for (java.text.Normalizer.Form f : new java.text.Normalizer.Form[]{java.text.Normalizer.Form.NFC, java.text.Normalizer.Form.NFD}) { String n = java.text.Normalizer.normalize(typed, f); if (!tries.contains(n)) tries.add(n); } }
        try {
            KeyStore ks = null; char[] password = null; Exception last = null;
            for (String t : tries) { try { KeyStore k = KeyStore.getInstance("PKCS12", "BC"); k.load(new ByteArrayInputStream(bytes), t.toCharArray()); ks = k; password = t.toCharArray(); break; } catch (Exception e) { last = e; } }
            if (ks == null) throw last;
            String alias = null; for (String s : Collections.list(ks.aliases())) if (ks.isKeyEntry(s)) { alias = s; break; }
            PrivateKey key = (PrivateKey) ks.getKey(alias, password);
            java.security.cert.Certificate[] chain = ks.getCertificateChain(alias);
            // the same sign + verify round trip Pkcs12Import does
            String alg = key.getAlgorithm().equals("EC") || key.getAlgorithm().equals("ECDSA") ? "SHA256withECDSA" : "SHA256withRSA";
            Signature s = Signature.getInstance(alg); s.initSign(key); s.update(new byte[]{1, 2, 3}); byte[] sig = s.sign();
            Signature v = Signature.getInstance(alg); v.initVerify(chain[0].getPublicKey()); v.update(new byte[]{1, 2, 3});
            System.out.println((v.verify(sig) ? "OK " : "MISMATCH ") + key.getAlgorithm() + " " + chain.length);
        } catch (Exception e) { System.out.println("FAIL " + e.getClass().getSimpleName() + ": " + e.getMessage()); }
    }
}
