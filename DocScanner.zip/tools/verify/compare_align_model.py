"""Mô hình Python (numpy) của phần CĂN CHỈNH trong PdfComparer (phiên 15, sau phản hồi "sao không tra cứu khắc phục hạn chế").

Hạn chế cũ: trang chỉ lệch nhẹ vị trí/xoay/tỉ lệ bị coi là khác khắp nơi; trang chèn/xoá làm mọi trang sau lệch. Cách khắc phục (kỹ thuật chuẩn
trong so sánh ảnh tài liệu: đăng ký ảnh bằng dịch chuyển, rồi so sánh có dung sai cục bộ; ghép trang bằng chuỗi con chung dài nhất):
  1. estimate_global: dịch chuyển toàn trang (±5 điểm ảnh ở 1/4 độ phân giải = ±20 px) bằng tổng chênh lệch tuyệt đối (SAD) trên vùng chồng;
  2. estimate_tiles + refine_tiles_full: dịch chuyển RIÊNG cho từng ô 128 px (±3 ở 1/2 độ phân giải quanh dịch chuyển toàn trang, rồi ±1 px thật)
     - xấp xỉ từng mảnh của phép xoay/co giãn nhẹ;
  3. tolerant_mask: điểm "khác" chỉ khi giá trị của nó nằm NGOÀI khoảng [min, max] của cửa sổ 3x3 bên kia (và ngược lại) quá ngưỡng;
  4. align_pages: ghép trang hai phiên bản bằng quy hoạch động (như LCS) trên độ tương quan của chữ ký trang 96x128 đã làm mờ và trừ trang trung bình.
compare_check.py gọi các hàm này; Kotlin (PdfComparer.kt) là bản dịch từng bước.
"""
import numpy as np

THRESHOLD = 32       # chênh độ sáng (sau khi làm mờ, ngoài dung sai cửa sổ 3x3) để một điểm được coi là khác
BLOCK = 16
MIN_PIXELS = 8      # điểm khác tối thiểu trong một khối 16x16 để khối được tính là đổi (bỏ chấm lẻ, nhiễu nội suy)
BLUR_SIGMA = 1.0     # làm mờ CẢ HAI ảnh trước khi so: san bằng độ nét khác nhau (nội suy, chụp/scan) - đo trên 3 trang chữ: xoay 0,3-1° từ ~65% diện tích hộp xuống 0-10%; bộ tham số (sigma 1,0; ngưỡng 32; tối thiểu 8) chọn bằng quét 36 tổ hợp: vẫn phát hiện 6/6 ca đổi số/xoá chữ
TILE = 64            # điểm ảnh ở 1/2 độ phân giải (= 128 px thật)
TILE_RANGE = 3
GLOBAL_RANGE = 5     # điểm ảnh ở 1/4 độ phân giải
SHIFT_PENALTY = 0.05  # mức độ đậm mực cho mỗi điểm ảnh dịch chuyển: chỉ để phá thế hoà, ưu tiên không dịch
FLAT_SPREAD = 40     # ô gần như trắng/đồng màu (max-min < 40): không đủ thông tin, dùng dịch chuyển toàn trang
SIG_W, SIG_H = 48, 64
MATCH_MIN = 0.75


def box_down(a, f):
    h, w = a.shape[0] // f * f, a.shape[1] // f * f
    return a[:h, :w].reshape(h // f, f, w // f, f).mean(axis=(1, 3))


def sad(a, b, u, v):
    """Sai khác tuyệt đối trung bình giữa a[y,x] và b[y+v,x+u] trên vùng chồng; không chồng -> rất lớn."""
    h, w = a.shape
    x0, x1 = max(0, -u), min(w, w - u)
    y0, y1 = max(0, -v), min(h, h - v)
    if x1 <= x0 or y1 <= y0:
        return 1e9
    return float(np.abs(a[y0:y1, x0:x1] - b[y0 + v:y1 + v, x0 + u:x1 + u]).mean())


def estimate_global(a, b):
    """(dx, dy) tính bằng điểm ảnh THẬT: b[y+dy, x+dx] ≈ a[y, x]. Ước lượng ở 1/4 độ phân giải."""
    a4, b4 = box_down(255.0 - a, 4), box_down(255.0 - b, 4)     # đo trên ĐỘ ĐẬM MỰC: vùng trắng không góp gì, nên điểm cực tiểu rõ ràng
    best, bu, bv = None, 0, 0
    for v in range(-GLOBAL_RANGE, GLOBAL_RANGE + 1):
        for u in range(-GLOBAL_RANGE, GLOBAL_RANGE + 1):
            c = sad(a4, b4, u, v) + SHIFT_PENALTY * (abs(u) + abs(v))
            if best is None or c < best:
                best, bu, bv = c, u, v
    return bu * 4, bv * 4


def estimate_tiles(a, b, g):
    """Dịch chuyển (dx, dy) thật cho từng ô TILE*2 px: mảng [ty][tx] gồm cặp. g là dịch chuyển toàn trang (thật)."""
    a2, b2 = box_down(255.0 - a, 2), box_down(255.0 - b, 2)
    h2, w2 = a2.shape
    g2x, g2y = g[0] // 2, g[1] // 2
    nty, ntx = (h2 + TILE - 1) // TILE, (w2 + TILE - 1) // TILE
    out = [[(g[0], g[1]) for _ in range(ntx)] for _ in range(nty)]
    for ty in range(nty):
        for tx in range(ntx):
            y0, y1, x0, x1 = ty * TILE, min((ty + 1) * TILE, h2), tx * TILE, min((tx + 1) * TILE, w2)
            at = a2[y0:y1, x0:x1]
            if at.max() - at.min() < FLAT_SPREAD:
                continue
            best, bdu, bdv = None, 0, 0
            for dv in range(-TILE_RANGE, TILE_RANGE + 1):
                for du in range(-TILE_RANGE, TILE_RANGE + 1):
                    u, v = g2x + du, g2y + dv
                    s = 0.0; n = 0
                    for yy in range(y0, y1):
                        sy = yy + v
                        for xx in range(x0, x1):
                            sx = xx + u
                            bv = b2[sy, sx] if 0 <= sy < h2 and 0 <= sx < w2 else 0.0
                            s += abs(a2[yy, xx] - bv); n += 1
                    c = s / n + SHIFT_PENALTY * (abs(du) + abs(dv))
                    if best is None or c < best:
                        best, bdu, bdv = c, du, dv
            out[ty][tx] = ((g2x + bdu) * 2, (g2y + bdv) * 2)
    return out


def estimate_tiles_fast(a, b, g):
    """Cùng kết quả với estimate_tiles nhưng dùng numpy (cho bộ test chạy nhanh)."""
    a2, b2 = box_down(255.0 - a, 2), box_down(255.0 - b, 2)
    h2, w2 = a2.shape
    g2x, g2y = g[0] // 2, g[1] // 2
    M = abs(g2x) + abs(g2y) + TILE_RANGE + 2
    bp = np.pad(b2, M, constant_values=0.0)
    nty, ntx = (h2 + TILE - 1) // TILE, (w2 + TILE - 1) // TILE
    out = [[(g[0], g[1]) for _ in range(ntx)] for _ in range(nty)]
    for ty in range(nty):
        for tx in range(ntx):
            y0, y1, x0, x1 = ty * TILE, min((ty + 1) * TILE, h2), tx * TILE, min((tx + 1) * TILE, w2)
            at = a2[y0:y1, x0:x1]
            if at.max() - at.min() < FLAT_SPREAD:
                continue
            best, bdu, bdv = None, 0, 0
            for dv in range(-TILE_RANGE, TILE_RANGE + 1):
                for du in range(-TILE_RANGE, TILE_RANGE + 1):
                    u, v = g2x + du, g2y + dv
                    seg = bp[y0 + v + M:y1 + v + M, x0 + u + M:x1 + u + M]
                    c = float(np.abs(at - seg).mean()) + SHIFT_PENALTY * (abs(du) + abs(dv))
                    if best is None or c < best:
                        best, bdu, bdv = c, du, dv
            out[ty][tx] = ((g2x + bdu) * 2, (g2y + bdv) * 2)
    return out


def refine_tiles_full(a, b, shifts):
    """Tinh chỉnh từng ô ±1 điểm ảnh THẬT quanh kết quả ở 1/2 độ phân giải (SAD ở độ phân giải đầy đủ). Ô gần như đồng màu giữ nguyên."""
    h, w = a.shape
    ts = TILE * 2
    M = 40
    bp = np.pad(255.0 - b.astype(np.float64), M, constant_values=0.0)
    af = 255.0 - a.astype(np.float64)
    out = [list(row) for row in shifts]
    for ty, row in enumerate(shifts):
        for tx, (dx, dy) in enumerate(row):
            y0, y1, x0, x1 = ty * ts, min((ty + 1) * ts, h), tx * ts, min((tx + 1) * ts, w)
            at = af[y0:y1, x0:x1]
            if at.max() - at.min() < FLAT_SPREAD:
                continue
            best, bx, by = None, dx, dy
            for j in (0, -1, 1):
                for i in (0, -1, 1):
                    u, v = dx + i, dy + j
                    seg = bp[y0 + v + M:y1 + v + M, x0 + u + M:x1 + u + M]
                    c = float(np.abs(at - seg).mean())
                    if best is None or c < best - 1e-9:
                        best, bx, by = c, u, v
            out[ty][tx] = (bx, by)
    return out


def align_b(b, shifts):
    """b' [y,x] = b[y + dy(tile), x + dx(tile)] với (dx, dy) của ô chứa (x, y); ngoài ảnh -> 255."""
    h, w = b.shape
    out = np.full((h, w), 255, dtype=b.dtype)
    ts = TILE * 2
    for ty, row in enumerate(shifts):
        for tx, (dx, dy) in enumerate(row):
            y0, y1, x0, x1 = ty * ts, min((ty + 1) * ts, h), tx * ts, min((tx + 1) * ts, w)
            if y0 >= h or x0 >= w:
                continue
            sy0, sy1, sx0, sx1 = y0 + dy, y1 + dy, x0 + dx, x1 + dx
            cy0, cy1, cx0, cx1 = max(sy0, 0), min(sy1, h), max(sx0, 0), min(sx1, w)
            if cy1 <= cy0 or cx1 <= cx0:
                continue
            out[y0 + (cy0 - sy0):y0 + (cy1 - sy0), x0 + (cx0 - sx0):x0 + (cx1 - sx0)] = b[cy0:cy1, cx0:cx1]
    return out


def win_minmax(a, r=1):
    p = np.pad(a, r, mode="edge")
    h, w = a.shape
    lo = np.full((h, w), 1e9); hi = np.full((h, w), -1e9)
    for dy in range(-r, r + 1):
        for dx in range(-r, r + 1):
            seg = p[r + dy:r + dy + h, r + dx:r + dx + w]
            lo = np.minimum(lo, seg); hi = np.maximum(hi, seg)
    return lo, hi


def tolerant_mask(a, b, r=1):
    a = a.astype(np.float64); b = b.astype(np.float64)
    alo, ahi = win_minmax(a, r); blo, bhi = win_minmax(b, r)
    da = np.maximum(np.maximum(blo - a, a - bhi), 0)
    db = np.maximum(np.maximum(alo - b, b - ahi), 0)
    return np.maximum(da, db) > THRESHOLD


def boxes_from_mask(mask):
    h, w = mask.shape
    bw, bh = (w + BLOCK - 1) // BLOCK, (h + BLOCK - 1) // BLOCK
    counts = np.zeros((bh, bw), dtype=int)
    ys, xs = np.nonzero(mask)
    np.add.at(counts, (ys // BLOCK, xs // BLOCK), 1)
    changed = counts >= MIN_PIXELS
    grouped = np.zeros_like(changed)
    for by, bx in zip(*np.nonzero(changed)):
        grouped[max(by - 1, 0):by + 2, max(bx - 1, 0):bx + 2] = True
    seen = np.zeros_like(changed)
    boxes = []
    for sy, sx in zip(*np.nonzero(grouped)):
        if seen[sy, sx]:
            continue
        minx = miny = 10**9; maxx = maxy = -1
        stack = [(sy, sx)]; seen[sy, sx] = True
        while stack:
            cy, cx = stack.pop()
            if changed[cy, cx]:
                minx, maxx, miny, maxy = min(minx, cx), max(maxx, cx), min(miny, cy), max(maxy, cy)
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    ny, nx = cy + dy, cx + dx
                    if 0 <= ny < bh and 0 <= nx < bw and grouped[ny, nx] and not seen[ny, nx]:
                        seen[ny, nx] = True; stack.append((ny, nx))
        if maxx < 0:
            continue
        x0, y0 = minx * BLOCK, miny * BLOCK
        boxes.append((x0, y0, min((maxx + 1) * BLOCK, w) - x0, min((maxy + 1) * BLOCK, h) - y0))
    return boxes


def blur_both(a, b):
    return gaussian_blur(a.astype(np.float64), BLUR_SIGMA), gaussian_blur(b.astype(np.float64), BLUR_SIGMA)


def compare_pages_tiles(a, b):
    """(Bản trung gian, chỉ để so sánh số đo) căn chỉnh theo ô quanh dịch chuyển toàn trang -> làm mờ -> so có dung sai -> gom vùng."""
    g = estimate_global(a, b)
    shifts = refine_tiles_full(a, b, estimate_tiles_fast(a, b, g))
    ba, bb = blur_both(a, align_b(b, shifts))
    return boxes_from_mask(tolerant_mask(ba, bb))


def compare_pages_unaligned(a, b):
    """Như compare_pages nhưng không căn chỉnh (cho các phép thử cơ bản)."""
    ba, bb = blur_both(a, b)
    return boxes_from_mask(tolerant_mask(ba, bb))


# ---------------- ghép trang ----------------
# Chữ ký trang: mật độ mực trên lưới 96x128, làm mờ Gaussian sigma 1,5 (chịu được dịch/xoay nhẹ), rồi TRỪ ảnh trung bình của mọi trang của cả hai
# tài liệu (bỏ phần chung: lề, khoảng cách dòng, vốn khiến mọi trang chữ trông giống nhau) và chuẩn hoá. Đo trên 8 trang chữ tổng hợp: cùng trang bị
# dịch (9,-6) + xoay 0,4 độ có độ tương tự >= 0,865; hai trang khác nhau <= 0,116 (cách nhau 0,75) -> ngưỡng ghép 0,5.
SIG_W, SIG_H, SIG_SIGMA = 96, 128, 1.5
MATCH_MIN = 0.5


def gaussian_blur(a, sigma):
    """Làm mờ phân tách được với nhân Gaussian cắt ở 3 sigma (khớp với cách làm trong PdfComparer.kt)."""
    r = max(1, int(np.ceil(3 * sigma)))
    k = np.exp(-0.5 * (np.arange(-r, r + 1) / sigma) ** 2)
    k /= k.sum()
    p = np.pad(a, ((0, 0), (r, r)), mode="edge")
    t = sum(k[i] * p[:, i:i + a.shape[1]] for i in range(2 * r + 1))
    p = np.pad(t, ((r, r), (0, 0)), mode="edge")
    return sum(k[i] * p[i:i + a.shape[0], :] for i in range(2 * r + 1))


def raw_signature(a):
    """Mật độ mực của trang trên lưới SIG_H x SIG_W (trung bình từng ô), đã làm mờ, dạng vector."""
    h, w = a.shape
    ink = 255.0 - a.astype(np.float64)
    ys = np.linspace(0, h, SIG_H + 1).astype(int); xs = np.linspace(0, w, SIG_W + 1).astype(int)
    g = np.array([[ink[ys[i]:max(ys[i + 1], ys[i] + 1), xs[j]:max(xs[j + 1], xs[j] + 1)].mean() for j in range(SIG_W)] for i in range(SIG_H)])
    return gaussian_blur(g, SIG_SIGMA).ravel()


def normalized_signatures(raws):
    """Trừ trang trung bình của TOÀN BỘ trang (cả hai tài liệu), trừ trung bình riêng, chia độ dài."""
    mean = np.mean(raws, axis=0)
    out = []
    for r in raws:
        x = r - mean
        x = x - x.mean()
        n = np.linalg.norm(x)
        out.append(x / n if n > 1e-9 else x)
    return out


def similarity(sa, sb):
    return float(np.dot(sa, sb))


def align_pages(sigs_old, sigs_new):
    """Cặp (i, j) 0-based được ghép; quy hoạch động tối đa hoá tổng độ tương tự của các cặp có độ tương tự >= MATCH_MIN."""
    n, m = len(sigs_old), len(sigs_new)
    sim = [[similarity(sigs_old[i], sigs_new[j]) for j in range(m)] for i in range(n)]
    dp = [[0.0] * (m + 1) for _ in range(n + 1)]
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            best = max(dp[i - 1][j], dp[i][j - 1])
            s = sim[i - 1][j - 1]
            if s >= MATCH_MIN:
                best = max(best, dp[i - 1][j - 1] + s)
            dp[i][j] = best
    pairs, i, j = [], n, m
    while i > 0 and j > 0:
        s = sim[i - 1][j - 1]
        if s >= MATCH_MIN and abs(dp[i][j] - (dp[i - 1][j - 1] + s)) < 1e-9:
            pairs.append((i - 1, j - 1)); i -= 1; j -= 1
        elif abs(dp[i][j] - dp[i - 1][j]) < 1e-9:
            i -= 1
        else:
            j -= 1
    return pairs[::-1]


# ---------------- căn chỉnh AFFINE theo KIM TỰ THÁP (khắc phục "xoay >= 1 độ" của phiên 15) ----------------
# Chẩn đoán ban đầu: với xoay 1-2 độ hoặc co 3%, dịch chuyển tại góc trang lên tới 16-26 px, vượt vùng tìm ±6 px quanh dịch chuyển toàn trang
# (27-39/54 ô sai > 2 px). Thử khớp affine rồi tìm lại quanh dự đoán (vòng lặp): chỉ hội tụ khi xoay <= 2 độ, hỏng với co 3% (sai số mô hình tới 30 px).
# Cách làm đúng là KIM TỰ THÁP thô -> mịn: ở mức 1/8 dịch chuyển nhỏ lại 8 lần nên vùng tìm ±2 điểm ảnh của mức đó phủ ±16 px thật; mỗi mức biến đổi b theo
# affine hiện tại, tìm dịch chuyển DƯ theo ô (nhỏ), khớp lại affine (bình phương tối thiểu, loại ngoại lai) từ dịch chuyển tổng. Đo: xoay tới 3° và co tới 3% còn 0% hộp.
AFFINE_MIN_TILES = 6
AFFINE_MAX_LINEAR = 0.08      # |hệ số tuyến tính| tối đa (≈ xoay 4,5° hoặc co 8%); vượt thì coi là khớp hỏng và giữ kết quả mức trước


def tile_centers(shape):
    h, w = shape
    ts = TILE * 2
    nty, ntx = (box_down(np.zeros(shape), 2).shape[0] + TILE - 1) // TILE, (box_down(np.zeros(shape), 2).shape[1] + TILE - 1) // TILE
    return nty, ntx, [[(tx * ts + ts / 2.0, ty * ts + ts / 2.0) for tx in range(ntx)] for ty in range(nty)]


def flat_tiles(a):
    a2 = box_down(255.0 - a, 2)
    h2, w2 = a2.shape
    nty, ntx = (h2 + TILE - 1) // TILE, (w2 + TILE - 1) // TILE
    mask = [[False] * ntx for _ in range(nty)]
    for ty in range(nty):
        for tx in range(ntx):
            t = a2[ty * TILE:min((ty + 1) * TILE, h2), tx * TILE:min((tx + 1) * TILE, w2)]
            mask[ty][tx] = (t.max() - t.min()) < FLAT_SPREAD
    return mask


def predict(centers, pq):
    p, q = pq
    return [[(float(p[0] + p[1] * cx + p[2] * cy), float(q[0] + q[1] * cx + q[2] * cy)) for (cx, cy) in row] for row in centers]


def warp_affine(b, pq):
    """b' [y,x] = b[y + dy(x,y), x + dx(x,y)] con (dx, dy) tuyến tính; nội suy song tuyến; ngoài ảnh = 255."""
    h, w = b.shape
    p, q = pq
    ys, xs = np.mgrid[0:h, 0:w].astype(np.float64)
    sx = xs + p[0] + p[1] * xs + p[2] * ys
    sy = ys + q[0] + q[1] * xs + q[2] * ys
    x0 = np.floor(sx).astype(int); y0 = np.floor(sy).astype(int)
    fx = sx - x0; fy = sy - y0
    out = np.full((h, w), 255.0)
    def g(yy, xx):
        ok = (yy >= 0) & (yy < h) & (xx >= 0) & (xx < w)
        v = np.full((h, w), 255.0)
        v[ok] = b[yy[ok], xx[ok]]
        return v
    out = (g(y0, x0) * (1 - fx) * (1 - fy) + g(y0, x0 + 1) * fx * (1 - fy) + g(y0 + 1, x0) * (1 - fx) * fy + g(y0 + 1, x0 + 1) * fx * fy)
    return out


# ---------------- căn chỉnh affine theo KIM TỰ THÁP (thay cho vòng lặp ở trên: hội tụ ổn định cho xoay/co lớn) ----------------
# Đo: vòng lặp quanh dự đoán chỉ hội tụ khi xoay <= 2 độ và hỏng với co 3% (sai số mô hình tới 30 px). Kim tự tháp chuẩn: ở mức thô (1/8) dịch chuyển nhỏ lại 8 lần
# nên vùng tìm ±2 điểm ảnh của mức đó phủ ±16 px thật; mỗi mức biến đổi b theo affine hiện tại, tìm dịch chuyển DƯ theo ô (nhỏ), khớp lại affine từ dịch chuyển tổng.
PYRAMID = (8, 4, 2)
LEVEL_RANGE = 2
PYR_OUTLIER_PX = (8.0, 4.0, 2.5)


def estimate_affine_pyramid(a, b, g):
    nty, ntx, centers = tile_centers(a.shape)
    pq = (np.array([float(g[0]), 0.0, 0.0]), np.array([float(g[1]), 0.0, 0.0]))
    ink_a = 255.0 - a
    for f in PYRAMID:
        bw = 255.0 - warp_affine(b.astype(np.float64), pq)           # mực của b đã biến đổi
        A, B = box_down(ink_a, f), box_down(bw, f)
        h2, w2 = A.shape
        tile = 128 // f
        M = LEVEL_RANGE + 1
        Bp = np.pad(B, M, constant_values=0.0)
        pts = []
        pred = predict(centers, pq)
        for ty in range(nty):
            for tx in range(ntx):
                y0, y1, x0, x1 = ty * tile, min((ty + 1) * tile, h2), tx * tile, min((tx + 1) * tile, w2)
                if y1 <= y0 or x1 <= x0:
                    continue
                at = A[y0:y1, x0:x1]
                if at.max() - at.min() < FLAT_SPREAD:
                    continue
                best, bu, bv = None, 0, 0
                for dv in range(-LEVEL_RANGE, LEVEL_RANGE + 1):
                    for du in range(-LEVEL_RANGE, LEVEL_RANGE + 1):
                        seg = Bp[y0 + dv + M:y1 + dv + M, x0 + du + M:x1 + du + M]
                        c = float(np.abs(at - seg).mean()) + SHIFT_PENALTY * (abs(du) + abs(dv))
                        if best is None or c < best:
                            best, bu, bv = c, du, dv
                cx, cy = centers[ty][tx]
                pts.append((cx, cy, pred[ty][tx][0] + bu * f, pred[ty][tx][1] + bv * f))
        if len(pts) < AFFINE_MIN_TILES:
            continue
        P = np.array(pts, dtype=np.float64)
        keep = np.ones(len(P), dtype=bool)
        fit = None
        for thr in PYR_OUTLIER_PX:
            if keep.sum() < AFFINE_MIN_TILES:
                break
            Am = np.c_[np.ones(keep.sum()), P[keep, 0], P[keep, 1]]
            p = np.linalg.lstsq(Am, P[keep, 2], rcond=None)[0]
            q = np.linalg.lstsq(Am, P[keep, 3], rcond=None)[0]
            Af = np.c_[np.ones(len(P)), P[:, 0], P[:, 1]]
            res = np.maximum(np.abs(Af @ p - P[:, 2]), np.abs(Af @ q - P[:, 3]))
            keep = res <= thr
            fit = (p, q)
        if fit is not None and keep.sum() >= AFFINE_MIN_TILES and max(abs(fit[0][1]), abs(fit[0][2]), abs(fit[1][1]), abs(fit[1][2])) <= AFFINE_MAX_LINEAR:
            pq = fit
    return pq


def compare_pages_pyramid(a, b):
    g = estimate_global(a, b)
    nty, ntx, _ = tile_centers(a.shape)
    pq = estimate_affine_pyramid(a, b, g)
    b_eff = warp_affine(b.astype(np.float64), pq)
    resid = refine_tiles_full(a, b_eff, [[(0, 0)] * ntx for _ in range(nty)])
    ba, bb = blur_both(a, align_b(b_eff, resid))
    return boxes_from_mask(tolerant_mask(ba, bb))


def compare_pages(a, b):
    """Hộp khác nhau giữa hai trang (độ sáng 0-255, cùng kích thước): căn chỉnh affine kim tự tháp -> làm mờ -> so có dung sai -> gom vùng."""
    return compare_pages_pyramid(a, b)
