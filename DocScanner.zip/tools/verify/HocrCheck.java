import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

/**
 * Runnable Java mirror of util/HocrParser.kt (same regexes, same steps). hocr_check.py feeds it REAL Tesseract hOCR plus hand-made
 * cases and compares the result with an independent Python parser. Usage: java HocrCheck.java file.hocr  ->  one line per word:
 * "P<paragraph> L<line> left top right bottom conf text" (text with \n, \t escaped).
 */
public class HocrCheck {
    static final int MIN_CONFIDENCE = 20;
    static final Pattern TAG = Pattern.compile("<(p|span)\\s+class=['\"](ocr_par|ocr_line|ocrx_word)['\"][^>]*?title\\s*=\\s*(?:'([^']*)'|\"([^\"]*)\")[^>]*>");
    static final Pattern BBOX = Pattern.compile("bbox\\s+(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)\\s+(-?\\d+)");
    static final Pattern WCONF = Pattern.compile("x_wconf\\s+(\\d+)");
    static final Pattern ANY_TAG = Pattern.compile("<[^>]*>");
    static final Pattern NUM_ENTITY = Pattern.compile("&#(x[0-9a-fA-F]+|\\d+);");

    static String decode(String s) {
        if (s.indexOf('&') < 0) return s;
        Matcher m = NUM_ENTITY.matcher(s);
        StringBuilder sb = new StringBuilder();
        int last = 0;
        while (m.find()) {
            sb.append(s, last, m.start());
            String body = m.group(1);
            Integer cp = null;
            try { cp = body.startsWith("x") ? Integer.parseInt(body.substring(1), 16) : Integer.parseInt(body); } catch (NumberFormatException e) { }
            if (cp == null || cp <= 0 || cp > 0x10FFFF) sb.append(m.group()); else sb.appendCodePoint(cp);
            last = m.end();
        }
        sb.append(s.substring(last));
        return sb.toString().replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&");
    }

    static class Word { String text; int l, t, r, b, c; }

    public static void main(String[] a) throws Exception {
        String hocr = new String(Files.readAllBytes(Paths.get(a[0])), StandardCharsets.UTF_8);
        List<List<List<Word>>> result = new ArrayList<>();
        List<List<Word>> paragraph = new ArrayList<>();
        List<Word> words = null;
        int pos = 0;
        while (true) {
            Matcher m = TAG.matcher(hocr);
            if (!m.find(pos)) break;
            String cls = m.group(2);
            String title = (m.group(3) != null && !m.group(3).isEmpty()) ? m.group(3) : (m.group(4) == null ? "" : m.group(4));
            pos = m.end();
            if (cls.equals("ocr_par")) {
                if (words != null && !words.isEmpty()) paragraph.add(words);
                words = null;
                if (!paragraph.isEmpty()) result.add(paragraph);
                paragraph = new ArrayList<>();
            } else if (cls.equals("ocr_line")) {
                if (words != null && !words.isEmpty()) paragraph.add(words);
                words = new ArrayList<>();
            } else {
                int end = hocr.indexOf("</span>", pos);
                if (end < 0) break;
                String raw = hocr.substring(pos, end);
                pos = end + 7;
                Matcher bb = BBOX.matcher(title);
                if (!bb.find()) continue;
                String text = decode(ANY_TAG.matcher(raw).replaceAll("")).trim();
                if (text.isEmpty()) continue;
                Matcher wc = WCONF.matcher(title);
                int conf = 100;
                if (wc.find()) { try { conf = Integer.parseInt(wc.group(1)); } catch (NumberFormatException e) { } }
                if (conf < MIN_CONFIDENCE) continue;
                if (words == null) words = new ArrayList<>();
                Word w = new Word();
                w.text = text; w.l = Integer.parseInt(bb.group(1)); w.t = Integer.parseInt(bb.group(2));
                w.r = Integer.parseInt(bb.group(3)); w.b = Integer.parseInt(bb.group(4)); w.c = conf;
                words.add(w);
            }
        }
        if (words != null && !words.isEmpty()) paragraph.add(words);
        if (!paragraph.isEmpty()) result.add(paragraph);
        StringBuilder out = new StringBuilder();
        for (int p = 0; p < result.size(); p++)
            for (int l = 0; l < result.get(p).size(); l++)
                for (Word w : result.get(p).get(l))
                    out.append("P").append(p).append(" L").append(l).append(' ').append(w.l).append(' ').append(w.t).append(' ')
                       .append(w.r).append(' ').append(w.b).append(' ').append(w.c).append(' ')
                       .append(w.text.replace("\\", "\\\\").replace("\n", "\\n").replace("\t", "\\t")).append('\n');
        System.out.print(out);
    }
}
