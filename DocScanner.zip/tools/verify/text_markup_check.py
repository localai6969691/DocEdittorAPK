"""Kiểm chứng PdfTextMarkup (phiên 17): tô sáng / gạch chân / gạch ngang THẬT trên chữ.

PHẦN A - phần thuần (TextMarkupCheck.java = bản Java của findPhrase / wordsInRect / lineBoxes): so với bản tham chiếu ĐỘC LẬP viết bằng Python
(unicodedata, không dùng lại mã Java) trên ca viết tay và 3 000 trang từ ngẫu nhiên: cùng đoạn khớp, cùng từ trong khung kéo, cùng hộp theo dòng
(sai số < 1e-3). Ca khó: "thue nha" khớp "thuê nhà" và "thuê nhàn" (từ cuối khớp tiền tố) nhưng KHÔNG khớp "thuê ở nhà"; "hop dong" khớp "Hợp đồng,"; dấu gạch rời không làm đứt cụm; hoa/thường và NFC/NFD như nhau.
PHẦN B - hình học + luồng hiển thị bằng poppler (trình đọc độc lập): 4 hướng xoay x không/có CropBox lệch x 3 kiểu = 24 tổ hợp. Hộp đặt ở
vị trí đã biết TRÊN TRANG ĐANG HIỂN THỊ; poppler vẽ (pdftoppm -cropbox) và đo: tô sáng = vàng trong hộp, trắng ngoài hộp (nhân màu: chữ đen vẫn đen);
gạch chân = vạch gần MÉP DƯỚI hiển thị (không ở trên); gạch ngang = vạch ở GIỮA. Cùng thử: qpdf --check, /Annots đọc lại được bằng pikepdf,
/QuadPoints theo thứ tự TL,TR,BL,BR của hộp hiển thị. THỬ ÂM TÍNH: ghi QuadPoints bằng toạ độ KHÔNG qua phép xoay -> vị trí sai trên trang xoay phải bị bắt.
Chạy: python3 text_markup_check.py   (cần java 11+, pikepdf, numpy, pillow, pdftoppm, qpdf)
"""
import os, random, subprocess, sys, unicodedata
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import numpy as np
import pikepdf
from pikepdf import Name, Array, Dictionary
from page_geometry_check import Geometry, render
HERE = os.path.dirname(os.path.abspath(__file__))
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
    return cond

# ---- hằng số phản chiếu PdfTextMarkup.kt (doc_sync_check so khớp) ----
HIGHLIGHT_OPACITY = 0.6; LINE_FRACTION = 0.07; LINE_MIN = 0.7; LINE_PAD = 0.08

# =============================================================== A. phần thuần
def norm(s):
    s = unicodedata.normalize("NFD", s.lower())
    return "".join(c for c in s if unicodedata.category(c) != "Mn").replace("đ", "d")
def fold(s): return "".join(c for c in norm(s) if c.isalnum())

def ref_find(words, query):
    q = [x for x in ("".join(c for c in w if c.isalnum()) for w in norm(query).split()) if x]
    if not q: return []
    idx = [i for i, w in enumerate(words) if fold(w[0])]
    f = [fold(words[i][0]) for i in idx]
    out, i = [], 0
    while i + len(q) <= len(f):
        ok = True
        for k, qk in enumerate(q):
            w = f[i + k]
            hit = (qk in w) if len(q) == 1 else (w.endswith(qk) if k == 0 else (w.startswith(qk) if k == len(q) - 1 else w == qk))
            if not hit: ok = False; break
        if ok: out.append((idx[i], idx[i + len(q) - 1])); i += len(q)
        else: i += 1
    return out
def ref_in_rect(words, r):
    l, rr, t, b = min(r[0], r[2]), max(r[0], r[2]), min(r[1], r[3]), max(r[1], r[3])
    return [i for i, w in enumerate(words) if l <= (w[2][0] + w[2][2]) / 2 <= rr and t <= (w[2][1] + w[2][3]) / 2 <= b]
def ref_boxes(words, chosen):
    by = {}
    for i in sorted(set(chosen)):
        ln, bx = words[i][1], list(words[i][2])
        if ln not in by: by[ln] = bx
        else: c = by[ln]; c[0] = min(c[0], bx[0]); c[1] = min(c[1], bx[1]); c[2] = max(c[2], bx[2]); c[3] = max(c[3], bx[3])
    cl = lambda v: max(0.0, min(1.0, v))
    out = []
    for ln in sorted(by):
        b = by[ln]; pad = (b[3] - b[1]) * LINE_PAD
        out.append((cl(b[0]), cl(b[1] - pad), cl(b[2]), cl(b[3] + pad)))
    return out
def ref_line(words, query, rect):
    m = ref_find(words, query)
    chosen = set(i for a, b in m for i in range(a, b + 1))
    inr = ref_in_rect(words, rect) if rect else []
    return m, inr, ref_boxes(words, chosen | set(inr))

VOC = ["Hợp", "đồng", "thuê", "nhà", "nhàn", "Nguyễn", "Thị", "Thuỳ", "Dương", "điện", "thoại", "Việt", "Nam", "độc", "lập", "tự", "do", "-", "•", "2026,", "12/10", "(ghi", "chú)", "ĐIỀU", "ĐỒNG", "hop", "dong", "thue", "nha"]
def rand_case(rnd):
    n = rnd.randint(0, 40); words = []; line = 0
    for k in range(n):
        if rnd.random() < 0.18: line += 1
        x0 = rnd.random() * 0.8; y0 = line * 0.05 + 0.02
        words.append((rnd.choice(VOC), line, (x0, y0, x0 + 0.05 + rnd.random() * 0.1, y0 + 0.03)))
    if words and rnd.random() < 0.7:
        i = rnd.randrange(len(words)); k = rnd.randint(1, 3)
        q = " ".join(rnd.choice([norm(w[0]), w[0].upper(), unicodedata.normalize("NFD", w[0])]) for w in words[i:i + k])
    else: q = " ".join(rnd.choice(VOC) for _ in range(rnd.randint(0, 3)))
    rect = None if rnd.random() < 0.5 else tuple(rnd.random() for _ in range(4))
    return words, q, rect
def case_text(words, q, rect):
    out = ["Q\t" + q]
    if rect: out.append("R\t" + "\t".join(f"{v:.6f}" for v in rect))
    for t, ln, b in words: out.append(f"W\t{ln}\t" + "\t".join(f"{v:.6f}" for v in b) + "\t" + t)
    return "\n".join(out)
def fmt(m, inr, boxes):
    return "M " + ",".join(f"{a}-{b}" for a, b in m) + "|I " + ",".join(map(str, inr)) + "|B " + ";".join(" ".join(f"{v:.4f}" for v in b) for b in boxes)
def run_java(cases):
    fin, fout = os.path.join(OUT, "tm_in.txt"), os.path.join(OUT, "tm_out.txt")
    with open(fin, "w", encoding="utf-8") as f: f.write("\n---\n".join(case_text(*c) for c in cases) + "\n")
    subprocess.run(["java", os.path.join(HERE, "TextMarkupCheck.java"), fin, fout], check=True)
    return open(fout, encoding="utf-8").read().split("\n")[:-1]

def close_line(a, b):
    pa, pb = a.split("|"), b.split("|")
    if pa[0] != pb[0] or pa[1] != pb[1]: return False
    ba = [x for x in pa[2][2:].split(";") if x]; bb = [x for x in pb[2][2:].split(";") if x]
    if len(ba) != len(bb): return False
    return all(abs(float(u) - float(v)) < 1e-3 for x, y in zip(ba, bb) for u, v in zip(x.split(), y.split()))

print("== A. phần thuần ==")
W = lambda *ts: [(t, 0, (0.1 * i, 0.1, 0.1 * i + 0.08, 0.14)) for i, t in enumerate(ts)]
hand = [
    (W("Bạn", "thuê", "nhàn", "rỗi"), "thue nha", None, "M 1-2|I |B 0.1000 0.0968 0.2800 0.1432"),   # từ cuối khớp TIỀN TỐ (như khi đang gõ dở)
    (W("thuê", "ở", "nhà"), "thue nha", None, "M |I |B "),   # nhưng từ phải liền nhau
    (W("Hợp", "đồng,", "thuê", "nhà."), "hop dong", None, "M 0-1|I |B 0.0000 0.0968 0.1800 0.1432"),
    (W("Hợp", "-", "đồng"), "HOP DONG", None, "M 0-2|I |B 0.0000 0.0968 0.2800 0.1432"),
    (W("hợp", "đồng"), "p do", None, "M 0-1|I |B 0.0000 0.0968 0.1800 0.1432"),
    (W("Thuỳ", "Dương"), unicodedata.normalize("NFD", "thuỳ"), None, "M 0-0|I |B 0.0000 0.0968 0.0800 0.1432"),
    (W("a", "b"), "", None, "M |I |B "),
    (W("a", "b", "c"), "zzz", (0.0, 0.0, 0.2, 1.0), "M |I 0,1|B 0.0000 0.0968 0.1800 0.1432"),
]
cases = [(w, q, r) for w, q, r, _ in hand]
got = run_java(cases)
for (w, q, r, exp), g in zip(hand, got):
    check(close_line(g, exp), f"ca tay {q!r}: {g}")
rnd = random.Random(11)
many = [rand_case(rnd) for _ in range(3000)]
got = run_java(many)
bad = [i for i, (c, g) in enumerate(zip(many, got)) if not close_line(g, fmt(*ref_line(*c)))]
check(not bad, f"3 000 trang từ ngẫu nhiên: bản Java = bản tham chiếu độc lập ({len(bad)} lệch)")
nonempty = sum(1 for c in many if ref_line(*c)[0]); check(nonempty > 700, f"bộ ngẫu nhiên có {nonempty} ca có đoạn khớp (không rỗng tuếch)")

# =============================================================== B. hình học + poppler
def f3(v): return f"{v:.3f}"
def quad_points(geo, box):
    l, r = min(box[0], box[2]) * geo.dw, max(box[0], box[2]) * geo.dw
    t, b = min(box[1], box[3]) * geo.dh, max(box[1], box[3]) * geo.dh
    pts = [geo.to_user(l, t), geo.to_user(r, t), geo.to_user(l, b), geo.to_user(r, b)]
    return [c for p in pts for c in p]
def appearance(style, rgb, q):
    c = f"{f3(rgb[0])} {f3(rgb[1])} {f3(rgb[2])}"
    if style == "Highlight":
        return f"/GS gs\n{c} rg\n{f3(q[0])} {f3(q[1])} m {f3(q[2])} {f3(q[3])} l {f3(q[6])} {f3(q[7])} l {f3(q[4])} {f3(q[5])} l h f\n"
    h = ((q[0] - q[4]) ** 2 + (q[1] - q[5]) ** 2) ** 0.5
    w = max(LINE_MIN, LINE_FRACTION * h)
    ux, uy = ((q[0] - q[4]) / h, (q[1] - q[5]) / h) if h > 0 else (0, 1)
    if style == "Underline": x1, y1, x2, y2 = q[4] + ux * w, q[5] + uy * w, q[6] + ux * w, q[7] + uy * w
    else: x1, y1, x2, y2 = (q[0] + q[4]) / 2, (q[1] + q[5]) / 2, (q[2] + q[6]) / 2, (q[3] + q[7]) / 2
    return f"{c} RG\n{f3(w)} w\n{f3(x1)} {f3(y1)} m {f3(x2)} {f3(y2)} l S\n"

def build(path, mediabox, cropbox, rotate, style, box, rgb, naive_quad=False):
    pdf = pikepdf.new()
    pg = pdf.add_blank_page(page_size=(mediabox[2] - mediabox[0], mediabox[3] - mediabox[1]))
    pg.MediaBox = Array(mediabox)
    if cropbox: pg.CropBox = Array(cropbox)
    pg.Rotate = rotate
    pg.Contents = pdf.make_stream(b"")
    cb = cropbox or mediabox
    geo = Geometry(cb[0], cb[1], cb[2] - cb[0], cb[3] - cb[1], rotate)
    if naive_quad:   # sai: coi hộp là toạ độ trang gốc, không qua phép xoay
        l, r, t, b = box[0] * (cb[2] - cb[0]), box[2] * (cb[2] - cb[0]), box[1] * (cb[3] - cb[1]), box[3] * (cb[3] - cb[1])
        q = [cb[0] + l, cb[1] + (cb[3] - cb[1]) - t, cb[0] + r, cb[1] + (cb[3] - cb[1]) - t, cb[0] + l, cb[1] + (cb[3] - cb[1]) - b, cb[0] + r, cb[1] + (cb[3] - cb[1]) - b]
    else: q = quad_points(geo, box)
    xs, ys = q[0::2], q[1::2]
    rect = [min(xs), min(ys), max(xs), max(ys)]
    ap = pdf.make_stream(appearance(style, rgb, q).encode("ascii"))
    ap.Type = Name.XObject; ap.Subtype = Name.Form; ap.BBox = Array(rect)
    ap.Resources = Dictionary(ExtGState=Dictionary(GS=Dictionary(Type=Name.ExtGState, BM=Name.Multiply, ca=HIGHLIGHT_OPACITY))) if style == "Highlight" else Dictionary()
    annot = pdf.make_indirect(Dictionary(Type=Name.Annot, Subtype=Name("/" + style), Rect=Array(rect), QuadPoints=Array(q), C=Array(rgb), F=4, T=pikepdf.String("DocScanner"), AP=Dictionary(N=ap)))
    pg.Annots = Array([annot])
    pdf.save(path)
    return geo, q

def yellowish(c): return c[0] > 200 and c[1] > 190 and c[2] < 150
def whitish(c): return all(v > 235 for v in c)
def dark_fraction_rows(img, x0, x1, y0, y1):
    """Hàng (theo y) có nhiều điểm ảnh màu nhất trong vùng."""
    sub = img[y0:y1, x0:x1].astype(int)
    colored = (sub.min(axis=2) < 200)
    return colored.sum(axis=1)

print("== B. poppler: 24 tổ hợp xoay x CropBox x kiểu ==")
BOX = (0.25, 0.40, 0.75, 0.47)
for rotate in (0, 90, 180, 270):
    for crop_name, mb, cb in (("không CropBox", [0, 0, 400, 600], None), ("CropBox lệch", [0, 0, 500, 700], [37, 53, 437, 653])):
        for style in ("Highlight", "Underline", "StrikeOut"):
            path = os.path.join(OUT, f"tm_{rotate}_{bool(cb)}_{style}.pdf")
            rgb = [1.0, 1.0, 0.0] if style == "Highlight" else [0.8, 0.0, 0.0]
            geo, q = build(path, mb, cb, rotate, style, BOX, rgb)
            img = render(path); H, Wd = img.shape[:2]
            x0, x1 = int(BOX[0] * Wd), int(BOX[2] * Wd); y0, y1 = int(BOX[1] * H), int(BOX[3] * H)
            tag = f"xoay {rotate:3d}, {crop_name}, {style}"
            if style == "Highlight":
                cx, cy = (x0 + x1) // 2, (y0 + y1) // 2
                inside = yellowish(tuple(img[cy, cx])) and yellowish(tuple(img[y0 + 2, x0 + 3])) and yellowish(tuple(img[y1 - 3, x1 - 4]))
                out_pts = [(x0 - 8, cy), (x1 + 8, cy), (cx, y0 - 8), (cx, y1 + 8)]
                outside = all(whitish(tuple(img[max(0, min(H - 1, y)), max(0, min(Wd - 1, x))])) for x, y in out_pts)
                check(inside and outside, f"{tag}: vàng trong hộp, trắng ngoài hộp")
            else:
                rows = dark_fraction_rows(img, x0 + 2, x1 - 2, max(0, y0 - 6), min(H, y1 + 6))
                peak = int(np.argmax(rows)) + max(0, y0 - 6)
                want = (y1 - 1 - max(1, int(0.07 * (y1 - y0)))) if style == "Underline" else (y0 + y1) // 2
                span = int((rows > 0.8 * (x1 - x0 - 4)).sum())
                check(rows.max() > 0.8 * (x1 - x0 - 4) and abs(peak - want) <= 3 and span <= 4, f"{tag}: vạch tại y={peak} (mong đợi ~{want}), dày {span} px")
            r = subprocess.run(["qpdf", "--check", path], capture_output=True, text=True)
            if r.returncode != 0: check(False, f"{tag}: qpdf --check: {r.stdout[-200:]}")
pdf = pikepdf.open(os.path.join(OUT, "tm_90_True_Highlight.pdf"))
a = pdf.pages[0].Annots[0]
check(str(a.Subtype) == "/Highlight" and len(a.QuadPoints) == 8 and "/AP" in a, "đọc lại bằng pikepdf: Subtype, QuadPoints (8 số), AP có")
geo90 = Geometry(37, 53, 400, 600, 90); qq = quad_points(geo90, BOX)
check(all(abs(float(u) - v) < 1e-3 for u, v in zip(a.QuadPoints, qq)), "QuadPoints = TL, TR, BL, BR của hộp HIỂN THỊ (đã qua phép xoay 90 + CropBox)")
# thử âm tính
p = os.path.join(OUT, "tm_neg.pdf"); build(p, [0, 0, 400, 600], None, 90, "Highlight", BOX, [1, 1, 0], naive_quad=True)
img = render(p); H, Wd = img.shape[:2]
cx, cy = int((BOX[0] + BOX[2]) / 2 * Wd), int((BOX[1] + BOX[3]) / 2 * H)
check(not yellowish(tuple(img[cy, cx])), "thử âm tính: QuadPoints không qua phép xoay đặt SAI chỗ trên trang xoay 90 (bài kiểm bắt được)")
print()
print("TAT CA DAT" if not FAILS else f"CO {len(FAILS)} LOI: " + "; ".join(FAILS[:6]))
sys.exit(1 if FAILS else 0)
