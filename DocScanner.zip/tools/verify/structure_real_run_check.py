#!/usr/bin/env python3
"""Cấu trúc trong của PDF và sửa PDF hỏng CHẠY THẬT (`util/PdfStructureTools.kt`, `util/PdfRepair.kt`; phiên 26, TECHNICAL_DOCS.md 4.83).

Từ phiên 18 hai tệp này chỉ có bản Python dựng lại bằng pikepdf (`pdf_structure_check.py`, `pdf_repair_check.py`); mã Kotlin + PdfBox thật chưa từng chạy. Bộ này gọi CHÍNH mã Kotlin (kotlinc, PdfBox-Android
dựng từ nguồn, `real_run/StructureHarness.kt`) rồi đo bằng công cụ ĐỘC LẬP:
  A. TỆP ĐÍNH KÈM: thêm 4 tệp (tên tiếng Việt, nhị phân 200 KB, trùng tên -> " (2)") rồi `pdfdetach -list / -save`, `qpdf --list-attachments`, pikepdf đọc lại; cây tên sắp theo BYTE THÔ (ISO 32000 7.9.6);
     đọc tệp đính kèm do pikepdf tạo (kể cả cây tên có Kids); trích ra đúng từng byte; xoá; xoá hết thì gỡ /EmbeddedFiles; qpdf --check sạch;
  B. PORTFOLIO: bật khi chưa có tệp đính kèm bị từ chối; bật / tắt (/Collection /View /D) đọc lại bằng pikepdf;
  C. LỚP HIỂN THỊ (OCG): liệt kê tên + trạng thái; bật / tắt từng lớp rồi DỰNG TRANG bằng poppler (poppler tôn trọng /OC): màu của lớp tắt phải biến mất, lớp bật còn;
  D. LIÊN KẾT: liệt kê (web / nhảy trang / điểm đến có tên / khác) so với danh sách đã dựng bằng pikepdf; xoá chỉ liên kết web hoặc mọi liên kết; chú thích khác (Text) được giữ;
  E. SỬA PDF HỎNG: 8 kiểu hỏng làm trực tiếp trên byte (sai startxref, startxref trỏ chỗ khác, rác trước tiêu đề, thiếu %%EOF, thiếu tiêu đề, thiếu startxref, cắt cụt, rác hoàn toàn): chẩn đoán đúng loại, kết quả
     `qpdf --check` sạch, đủ trang, chữ từng trang khớp bản gốc; trường hợp không cứu được thì lỗi và KHÔNG để lại tệp; tệp mã hoá bị từ chối.
THỬ ÂM TÍNH: 7 bản mã bị làm hỏng (không sắp cây tên theo byte, đảo bật / tắt lớp, xoá cả liên kết trang khi chỉ định xoá liên kết web, bỏ kiểm tra trùng tên, không nhận ra bảng xref cổ điển,
repair để lại tệp tạm .hdr, và bản vá tiêu đề của phiên 26 đặt lại như cũ) PHẢI bị bắt.
KHÔNG kiểm được: Acrobat (Portfolio hiển thị như thư mục), điện thoại. Chạy: python3 tools/verify/structure_real_run_check.py [--fast]   (--mutant=N chỉ chạy bản hỏng thứ N, 1-7)"""
import base64, hashlib, os, random, re, subprocess, sys, tempfile
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
import pikepdf  # noqa: E402
from pikepdf import Array, Dictionary, Name, String  # noqa: E402
from PIL import Image  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="structure-")
FILES = ["PdfStructureTools.kt", "PdfRepair.kt"]; HARNESS = os.path.join(HERE, "real_run", "StructureHarness.kt")
def build(mutate=None, tag="base"): return tc.compile(FILES, [HARNESS], os.path.join(WORK, "cls-" + tag), mutate)[0]
b = lambda s: base64.b64encode(s.encode()).decode(); u = lambda s: base64.b64decode(s).decode()
def hz(cls, *args):
    r = tc.run(cls, "StructureHarnessKt", list(args))
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-800:])
    return r.stdout.strip().splitlines()
def last(cls, *args): out = hz(cls, *args); return out[-1] if out else ""
def sh(*c): return subprocess.run(c, capture_output=True, text=True)
def P(n): return os.path.join(WORK, n)
def qpdf_clean(path): r = sh("qpdf", "--check", path); t = r.stdout + r.stderr; return r.returncode == 0 and "No syntax or stream encoding errors" in t and "WARNING" not in t, t[-300:]

def base_pdf(path, pages=2):
    pdf = pikepdf.new(); font = pdf.make_indirect(Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Helvetica))
    for i in range(pages):
        pdf.add_blank_page(page_size=(300, 300)); pg = pdf.pages[-1]; pg.Resources = Dictionary(Font=Dictionary(F1=font))
        pg.Contents = pdf.make_stream(f"BT /F1 24 Tf 20 150 Td (PAGE{i + 1} TEXT) Tj ET".encode())
    pdf.save(path, compress_streams=False, object_stream_mode=pikepdf.ObjectStreamMode.disable); return path

# ------------------------------------------------------------------------------------------------------------------------------ A. attachments
def group_attachments(cls):
    src = base_pdf(P("att-src.pdf")); rnd = random.Random(7); blob = bytes(rnd.getrandbits(8) for _ in range(200_000))
    files = {"z.txt": (b"zzz", "text/plain", "last"), "báo cáo.txt": ("Xin chào, đây là báo cáo".encode(), "text/plain", "Báo cáo tháng"), "a.txt": (b"first", None, ""), "dữ liệu.bin": (blob, "application/octet-stream", "")}
    cur = src; used = {}
    for i, (name, (data, mime, desc)) in enumerate(files.items()):
        dfile = P(f"att-data{i}"); open(dfile, "wb").write(data); out = P(f"att-{i}.pdf")
        r = hz(cls, "att-add", cur, out, b(name), dfile, b(mime) if mime else "-", b(desc) if desc else "-")[-1]
        used[name] = u(r) if not r.startswith("ERR") else r; cur = out
    check(all(used[n] == n for n in files), f"(A1) thêm 4 tệp đính kèm (tên tiếng Việt, 200 KB nhị phân): tên dùng {list(used.values())}")
    dup = P("att-dup"); open(dup, "wb").write(b"second a"); out = P("att-dup.pdf"); r = u(hz(cls, "att-add", cur, out, b("a.txt"), dup, "-", "-")[-1]); cur = out
    check(r == "a (2).txt", f"(A2) trùng tên -> thêm hậu tố: {r!r}")
    names_pd = sh("pdfdetach", "-list", cur).stdout; listed = re.findall(r"^\d+: (.*)$", names_pd, re.M)
    check(sorted(listed) == sorted(list(files) + ["a (2).txt"]), f"(A3) pdfdetach -list (poppler) thấy đủ 5 tệp: {listed}")
    with pikepdf.open(cur) as q:   # the raw name array first: merely touching q.attachments makes pikepdf / qpdf re-order the tree itself
        raw = [bytes(x) for i, x in enumerate(q.Root.Names.EmbeddedFiles.Names) if i % 2 == 0]
    with pikepdf.open(cur) as q:
        got = {k: q.attachments[k].get_file().read_bytes() for k in q.attachments.keys()}
    check(got.get("dữ liệu.bin") == blob and got.get("báo cáo.txt") == "Xin chào, đây là báo cáo".encode() and got.get("a (2).txt") == b"second a", "(A3) pikepdf đọc lại đúng từng byte (kể cả 200 KB nhị phân và chữ Việt)")
    check(raw == sorted(raw), f"(A4) cây tên sắp theo BYTE THÔ của chuỗi (ISO 32000 7.9.6): {[x[:6] for x in raw]}")
    r = sh("qpdf", "--list-attachments", cur); check(r.returncode == 0 and "a.txt" in r.stdout, "(A4) qpdf --list-attachments đọc được")
    ok, t = qpdf_clean(cur); check(ok, "(A4) qpdf --check sạch " + ("" if ok else t))
    check("PAGE2 TEXT" in sh("pdftotext", cur, "-").stdout, "(A4) trang giữ nguyên chữ")
    lst = {u(l.split(" ")[0]): (int(l.split(" ")[1]), u(l.split(" ")[2]) if len(l.split(" ")) > 2 else "") for l in hz(cls, "att-list", cur)}
    check(lst.get("báo cáo.txt") == (len("Xin chào, đây là báo cáo".encode()), "Báo cáo tháng") and lst.get("dữ liệu.bin", (0,))[0] == 200_000, f"(A5) listAttachments: tên, kích thước, mô tả đúng ({sorted(lst)[:3]}...)")
    outf = P("att-ex"); r = last(cls, "att-extract", cur, b("dữ liệu.bin"), outf); check(r == "200000" and open(outf, "rb").read() == blob, f"(A5) extractAttachment giải nén đúng từng byte (200 KB): {r}")
    check(last(cls, "att-extract", cur, b("không có.txt"), outf) == "-", "(A5) tên không tồn tại -> null")
    # an attachment tree written by pikepdf, with a Kids tree (independent writer)
    kid = P("att-kids.pdf"); pdf = pikepdf.open(base_pdf(P("att-kids-src.pdf")))
    for n in ["b1.txt", "b2.txt", "c.txt"]: pdf.attachments[n] = pikepdf.AttachedFileSpec(pdf, f"data-{n}".encode(), mime_type="text/plain")
    pdf.save(kid); pdf.close()
    lst2 = sorted(u(l.split(" ")[0]) for l in hz(cls, "att-list", kid)); check(lst2 == ["b1.txt", "b2.txt", "c.txt"], f"(A6) đọc tệp đính kèm do pikepdf tạo: {lst2}")
    check(last(cls, "att-extract", kid, b("b2.txt"), outf) == str(len(b"data-b2.txt")) and open(outf, "rb").read() == b"data-b2.txt", "(A6) trích tệp do pikepdf tạo")
    out2 = P("att-rm.pdf"); n = last(cls, "att-remove", cur, out2, b("z.txt") + "," + b("a (2).txt") + "," + b("không có")); check(n == "2", f"(A7) xoá 2 tệp có thật + 1 tên không có -> {n}")
    with pikepdf.open(out2) as q: left = sorted(q.attachments.keys())
    check(left == sorted(["a.txt", "báo cáo.txt", "dữ liệu.bin"]), f"(A7) còn lại đúng: {left}")
    out3 = P("att-rm-all.pdf"); n = last(cls, "att-remove", out2, out3, ",".join(b(x) for x in left))
    with pikepdf.open(out3) as q: gone = ("/Names" not in q.Root) or ("/EmbeddedFiles" not in q.Root.Names)
    check(n == "3" and gone, f"(A7) xoá hết: gỡ hẳn /EmbeddedFiles khỏi catalog ({n})"); ok, t = qpdf_clean(out3); check(ok, "(A7) qpdf --check sạch")
    return cur

# ------------------------------------------------------------------------------------------------------------------------------ B. portfolio
def group_portfolio(cls, with_att):
    plain = base_pdf(P("pf-plain.pdf")); r = last(cls, "portfolio-set", plain, P("pf-x.pdf"), "1")
    check(r.startswith("ERR:IllegalStateException:no attachments") and not os.path.exists(P("pf-x.pdf")), "(B1) bật Portfolio khi chưa có tệp đính kèm bị từ chối, không để lại tệp: " + r)
    out = P("pf-on.pdf"); r = last(cls, "portfolio-set", with_att, out, "1")
    with pikepdf.open(out) as q: coll = q.Root.get("/Collection"); okc = coll is not None and str(coll.get("/View")) == "/D" and str(coll.get("/Type")) == "/Collection"
    check(r == "done" and okc and last(cls, "portfolio", out) == "true" and last(cls, "portfolio", with_att) == "false", "(B2) bật: catalog có /Collection << /Type /Collection /View /D >>; isPortfolio true / false đúng")
    off = P("pf-off.pdf"); last(cls, "portfolio-set", out, off, "0")
    with pikepdf.open(off) as q: gone = "/Collection" not in q.Root
    ok, t = qpdf_clean(off); check(gone and last(cls, "portfolio", off) == "false" and ok, "(B3) tắt: gỡ /Collection, tệp đính kèm còn, qpdf sạch")

# ------------------------------------------------------------------------------------------------------------------------------ C. layers
def layers_pdf(path, off_initially=()):
    pdf = pikepdf.new(); pdf.add_blank_page(page_size=(300, 100)); pg = pdf.pages[0]
    ocgs = [pdf.make_indirect(Dictionary(Type=Name.OCG, Name=String(n))) for n in ("Đỏ", "Xanh lá", "Xanh dương")]
    pdf.Root.OCProperties = Dictionary(OCGs=Array(ocgs), D=Dictionary(Order=Array(ocgs), ON=Array([g for i, g in enumerate(ocgs) if i not in off_initially]), OFF=Array([ocgs[i] for i in off_initially])))
    pg.Resources = Dictionary(Properties=Dictionary(MC0=ocgs[0], MC1=ocgs[1], MC2=ocgs[2]))
    pg.Contents = pdf.make_stream(b"/OC /MC0 BDC 1 0 0 rg 10 10 80 80 re f EMC /OC /MC1 BDC 0 0.8 0 rg 110 10 80 80 re f EMC /OC /MC2 BDC 0 0 1 rg 210 10 80 80 re f EMC")
    pdf.save(path, compress_streams=False); return path

def colours(pdf):
    sh("pdftoppm", "-r", "36", "-png", pdf, P("ly")); f = [x for x in os.listdir(WORK) if x.startswith("ly") and x.endswith(".png")][0]
    im = np.asarray(Image.open(P(f)).convert("RGB")).astype(int); os.remove(P(f)); r, g, b_ = im[..., 0], im[..., 1], im[..., 2]
    return ((r - np.maximum(g, b_) > 120).sum() > 100, (g - np.maximum(r, b_) > 100).sum() > 100, (b_ - np.maximum(r, g) > 120).sum() > 100)

def group_layers(cls):
    src = layers_pdf(P("ly-src.pdf")); lst = [(u(l.split(" ")[0]), l.split(" ")[1]) for l in hz(cls, "layers-list", src)]
    check(lst == [("Đỏ", "true"), ("Xanh lá", "true"), ("Xanh dương", "true")], f"(C1) listLayers: tên tiếng Việt + trạng thái bật: {lst}")
    check(colours(src) == (True, True, True), "(C1) poppler dựng cả 3 màu khi cả 3 lớp bật")
    cases = [((1, 0, 1), (True, False, True)), ((0, 0, 0), (False, False, False)), ((0, 1, 0), (False, True, False)), ((1, 1, 1), (True, True, True))]
    cur = src
    for k, (want, expect) in enumerate(cases):
        out = P(f"ly-{k}.pdf"); r = last(cls, "layers-set", cur, out, ",".join(str(x) for x in want)); cur = out
        seen = colours(out); st = [l.split(" ")[1] == "true" for l in hz(cls, "layers-list", out)]
        check(r == "done" and seen == expect and st == [bool(x) for x in want], f"(C2) setLayers {want}: poppler dựng màu (đỏ, lá, dương) = {seen}, listLayers = {st}")
        ok, t = qpdf_clean(out); check(ok, f"(C2) qpdf --check sạch ({want})")
    pre = layers_pdf(P("ly-pre.pdf"), off_initially=(1,)); check(colours(pre) == (True, False, True) and [l.split(" ")[1] for l in hz(cls, "layers-list", pre)] == ["true", "false", "true"], "(C3) tệp có sẵn lớp tắt (/OFF): listLayers phản ánh đúng, poppler cũng ẩn")
    out = P("ly-pre-on.pdf"); last(cls, "layers-set", pre, out, "1,1,1"); check(colours(out) == (True, True, True), "(C3) bật lại lớp đang tắt: poppler hiện cả 3 màu")
    check(last(cls, "layers-set", src, P("ly-bad.pdf"), "1,0").startswith("ERR:") and not os.path.exists(P("ly-bad.pdf")), "(C4) số phần tử không khớp số lớp -> lỗi, không để lại tệp")
    check(last(cls, "layers-set", base_pdf(P("ly-none.pdf")), P("ly-none-out.pdf"), "1").startswith("ERR:IllegalStateException:no layers"), "(C4) PDF không có lớp -> lỗi rõ ràng")

# ------------------------------------------------------------------------------------------------------------------------------ D. links
def links_pdf(path):
    pdf = pikepdf.new(); font = pdf.make_indirect(Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Helvetica)); pages = []
    for i in range(3):
        pdf.add_blank_page(page_size=(300, 300)); pg = pdf.pages[-1]; pg.Resources = Dictionary(Font=Dictionary(F1=font)); pg.Contents = pdf.make_stream(f"BT /F1 20 Tf 20 150 Td (L{i + 1}) Tj ET".encode()); pages.append(pg)
    def link(rect, **kw): return pdf.make_indirect(Dictionary(Type=Name.Annot, Subtype=Name.Link, Rect=Array(rect), Border=Array([0, 0, 0]), **kw))
    web = lambda uri: Dictionary(S=Name.URI, URI=String(uri))
    pages[0].Annots = Array([link([10, 10, 100, 30], A=web("https://example.com/a")), link([10, 40, 100, 60], A=Dictionary(S=Name.GoTo, D=Array([pages[2].obj, Name.Fit]))),
                             link([10, 70, 100, 90], Dest=Array([pages[1].obj, Name.XYZ, 0, 300, 0])), link([10, 100, 100, 120], A=Dictionary(S=Name.GoTo, D=String("chapter"))),
                             pdf.make_indirect(Dictionary(Type=Name.Annot, Subtype=Name.Text, Rect=Array([200, 10, 220, 30]), Contents=String("note")))])
    pages[1].Annots = Array([link([10, 10, 100, 30], A=web("https://example.org/b?x=1")), link([10, 40, 100, 60], A=Dictionary(S=Name.Launch, F=String("x.exe")))])
    pdf.Root.Dests = Dictionary(chapter=Array([pages[1].obj, Name.Fit])); pdf.save(path, compress_streams=False); return path

def group_links(cls):
    src = links_pdf(P("lk-src.pdf")); got = [(l.split(" ")[0], l.split(" ")[1], u(l.split(" ")[2]) if len(l.split(" ")) > 2 else "") for l in hz(cls, "links-list", src)]
    want = [("1", "WEB", "https://example.com/a"), ("1", "PAGE", "3"), ("1", "PAGE", "2"), ("1", "PAGE", "2"), ("2", "WEB", "https://example.org/b?x=1"), ("2", "OTHER", "")]
    check(got == want, f"(D1) listLinks: web, nhảy trang (GoTo, Dest), điểm đến CÓ TÊN, khác: {got}")
    out = P("lk-web.pdf"); n = last(cls, "links-remove", src, out, "1")
    with pikepdf.open(out) as q: kinds = [[str(a.get("/Subtype")) + ("W" if "/A" in a and str(a.A.get("/S")) == "/URI" else "") for a in pg.get("/Annots", [])] for pg in q.pages]
    check(n == "2" and kinds[0] == ["/Link", "/Link", "/Link", "/Text"] and kinds[1] == ["/Link"], f"(D2) xoá chỉ liên kết web: {n} liên kết, liên kết trang / chú thích Text còn: {kinds}")
    out2 = P("lk-all.pdf"); n = last(cls, "links-remove", src, out2, "0")
    with pikepdf.open(out2) as q: kinds = [[str(a.get("/Subtype")) for a in pg.get("/Annots", [])] for pg in q.pages]
    ok, t = qpdf_clean(out2); check(n == "6" and kinds[0] == ["/Text"] and kinds[1] == [] and ok, f"(D3) xoá mọi liên kết: {n}; chỉ còn chú thích Text {kinds}")
    enc = P("lk-enc.pdf"); pikepdf.open(src).save(enc, encryption=pikepdf.Encryption(user="u", owner="o")); check(last(cls, "links-list", enc).startswith("ERR:"), "(D4) tệp mã hoá bị từ chối")

# ------------------------------------------------------------------------------------------------------------------------------ E. repair
def group_repair(cls):
    good = base_pdf(P("rp-good.pdf"), pages=4); data = open(good, "rb").read(); text0 = sh("pdftotext", good, "-").stdout
    start = data.rindex(b"startxref"); eof = data.rindex(b"%%EOF")
    kinds = {
        "wrong-startxref": (data[:start] + b"startxref\n99999999\n%%EOF\n", "BAD_XREF_OFFSET", True),
        "startxref-elsewhere": (data[:start] + b"startxref\n20\n%%EOF\n", "BAD_XREF_OFFSET", True),
        "junk-before-header": (b"JUNK" * 20 + b"\n" + data, "JUNK_BEFORE_HEADER", False),
        "no-eof": (data[:eof], "NO_EOF", False),
        "no-header": (b"%XXX-1.4" + data[8:], "NO_HEADER", False),
        "no-startxref": (data[:start] + b"%%EOF\n", "NO_STARTXREF", True),
    }
    for name, (blob, diag, severe) in kinds.items():
        src = P(f"rp-{name}.pdf"); open(src, "wb").write(blob); d = last(cls, "diag", src)
        check(d == diag, f"(E1) chẩn đoán {name}: {d} (mong đợi {diag})")
        out = P(f"rp-{name}-out.pdf"); r = last(cls, "repair", src, out)
        check(not os.path.exists(out + ".hdr") and not os.path.exists(out + ".part"), f"(E2) {name}: không để lại tệp tạm (.hdr / .part)")
        if r.startswith("ERR"): check(False, f"(E2) sửa {name} lỗi: {r}"); continue
        ok, t = qpdf_clean(out); same = sh("pdftotext", out, "-").stdout == text0
        check(r.split(" ")[0] == "4" and r.split(" ")[1] == diag and ok and same, f"(E2) sửa {name}: 4 trang, chẩn đoán {r.split(' ')[1]}, qpdf sạch={ok}, chữ khớp bản gốc={same}")
        qs = sh("qpdf", "--check", src); qtext = qs.stdout + qs.stderr; warned = ("reconstruct" in qtext) or ("startxref" in qtext) or ("xref" in qtext and "WARNING" in qtext)
        if severe: check(warned, f"(E3) {name}: qpdf CŨNG báo phải dựng lại bảng tham chiếu (không báo nhầm là ổn)")
    cut = P("rp-cut.pdf"); open(cut, "wb").write(data[: int(len(data) * 0.55)]); out = P("rp-cut-out.pdf"); r = last(cls, "repair", cut, out)
    if r.startswith("ERR"): check(not os.path.exists(out) and not os.path.exists(out + ".part"), f"(E4) tệp cắt cụt không cứu được: lỗi rõ ràng và KHÔNG để lại tệp ({r[:70]})")
    else:
        ok, t = qpdf_clean(out); check(ok and int(r.split(" ")[0]) > 0, f"(E4) tệp cắt cụt cứu được {r.split(' ')[0]} trang, qpdf sạch")
    junk = P("rp-junk.pdf"); open(junk, "wb").write(os.urandom(5000)); out = P("rp-junk-out.pdf"); r = last(cls, "repair", junk, out)
    check(r.startswith("ERR") and not os.path.exists(out) and not os.path.exists(out + ".part") and last(cls, "diag", junk) == "NO_HEADER", f"(E5) rác hoàn toàn: NO_HEADER, lỗi, không để lại tệp ({r[:60]})")
    enc = P("rp-enc.pdf"); pikepdf.open(good).save(enc, encryption=pikepdf.Encryption(user="u", owner="o")); r = last(cls, "repair", enc, P("rp-enc-out.pdf"))
    check(r.startswith("ERR") and not os.path.exists(P("rp-enc-out.pdf")), "(E6) tệp mã hoá bị từ chối, không để lại tệp: " + r[:60])
    check(last(cls, "diag", good) == "OK", "(E7) tệp nguyên vẹn: OK")

MUTANTS = [
    (1, "PdfStructureTools.kt", "sortedWith { x, y -> compareBytes(x.first.bytes, y.first.bytes) }", "sortedWith { x, y -> x.first.string.compareTo(y.first.string) }", "A"),
    (2, "PdfStructureTools.kt", "val (add, drop) = if (enabled[i]) on to off else off to on", "val (add, drop) = if (enabled[i]) off to on else on to off", "C"),
    (3, "PdfStructureTools.kt", "val drop = a is PDAnnotationLink && (!onlyWeb || a.action is PDActionURI)", "val drop = a is PDAnnotationLink", "D"),
    (4, "PdfStructureTools.kt", "while (map.containsKey(final)) { final = withSuffix(name, k); k++ }", "", "A"),
    (5, "PdfRepair.kt", "String(at, k, 4, Charsets.ISO_8859_1) == \"xref\"", "String(at, k, 4, Charsets.ISO_8859_1) == \"xrex\"", "E"),
    (6, "PdfRepair.kt", "        } finally {\n            withHeader.delete()\n        }", "        } finally {\n        }", "E"),
    (7, "PdfRepair.kt", "val readable = if (diagnosis == Diagnosis.NO_HEADER) {", "val readable = if (false) {", "E"),   # the fix of phiên 26 put back to the old behaviour
]
def run_group(cls, g):
    if g == "A": group_attachments(cls)
    elif g == "B": group_portfolio(cls, group_attachments_src(cls))
    elif g == "C": group_layers(cls)
    elif g == "D": group_links(cls)
    elif g == "E": group_repair(cls)
def group_attachments_src(cls):
    src = base_pdf(P("pfa-src.pdf")); d = P("pfa-data"); open(d, "wb").write(b"hello"); out = P("pfa.pdf"); hz(cls, "att-add", src, out, b("x.txt"), d, "-", "-"); return out

def main():
    args = sys.argv[1:]; fast = "--fast" in args; only = [int(a.split("=")[1]) for a in args if a.startswith("--mutant=")]
    if not only:
        cls = build()
        for g in "ABCDE":
            print(f"== nhóm {g}"); run_group(cls, g)
    if not fast:
        print("== THỬ ÂM TÍNH: mỗi bản mã bị làm hỏng PHẢI bị bắt")
        import io, contextlib
        for n, fname, old, new, g in MUTANTS:
            if only and n not in only: continue
            before = len(fails); cls = build({fname: (old, new)}, f"m{n}"); buf = io.StringIO()
            with contextlib.redirect_stdout(buf):
                try: run_group(cls, g)
                except SystemExit as e: print("LOI harness " + str(e)[:80])
            caught = [l for l in buf.getvalue().splitlines() if l.startswith("LOI")]; del fails[before:]
            check(len(caught) > 0, f"bản hỏng {n} ({fname}: {new.strip()[:55]!r}) bị bắt bởi {len(caught)} phép kiểm")
    print("\nTAT CA DAT" if not fails else f"\n{len(fails)} LOI: " + "; ".join(fails[:4])); sys.exit(1 if fails else 0)

main()
