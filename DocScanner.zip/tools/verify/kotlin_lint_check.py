"""Rà lỗi Kotlin ở mức TỪ VỰNG (phiên 22, mục 4.49.9) khi KHÔNG có trình biên dịch. Không thay được `kotlinc`, nhưng bắt được các lớp lỗi hay gặp khiến CI đỏ hoặc sập trên máy cũ:
  1. ngoặc () {} [] cân bằng trong từng tệp (bỏ qua chuỗi, ký tự, chú thích; hiểu chuỗi thô \"\"\" và mẫu ${...});
  2. (ĐÃ BỎ rule "độ ưu tiên toán tử": trong Kotlin hàm trung tố `and` / `or` / `shl` có độ ưu tiên CAO HƠN so sánh, nên `x and 0xFF == 0` là `(x and 0xFF) == 0`, hợp lệ;
     phiên 22 từng nghĩ ngược lại và thêm ngoặc thừa - vô hại. Bẫy thật nằm ở phía cộng trừ: `1 shl n - 1` là `1 shl (n - 1)`; bộ rà không cấm vì nhiều chỗ cố ý.)
  3. cú pháp Java lạc sang Kotlin: `new Foo(`, `instanceof`, và GỌI HÀM tĩnh của lớp Java như `Integer.parseInt`, `Long.parseLong`, `Double.valueOf`, `Float.isNaN(x)` (hằng số như `Float.NaN`, `Long.MAX_VALUE` là Kotlin hợp lệ);
  4. API KHÔNG CÓ trên Android 7 (minSdk 24) mà Kotlin / Java gọi thẳng: java.time.*, java.util.Base64, java.nio.file.*, InputStream.readAllBytes / transferTo, List.of / Set.of / Map.of, String.strip / isBlank gọi kiểu Java trên Java String, Optional.isEmpty, Collectors.toUnmodifiable*, Files.*, ImageDecoder (28), Resources.getFont (26), ...
     (lỗi này KHÔNG làm build đỏ mà làm app SẬP trên máy cũ: lint chỉ cảnh báo);
  5. `!!` sau biểu thức `?.` liền kề không lỗi nên bỏ qua; `when` dùng như biểu thức phải có `else` KHÔNG kiểm được ở mức từ vựng (ghi rõ).
Danh sách ngoại lệ có chủ ý nằm trong ALLOW (kèm lý do). Chạy: python3 kotlin_lint_check.py
"""
import os, re, sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "app", "src", "main", "java")
fails = []
def report(path, line, msg): fails.append(f"{os.path.relpath(path, ROOT)}:{line}: {msg}")

PAIRS = {")": "(", "]": "[", "}": "{"}

def scan(src):
    """-> (code with strings / comments blanked, newlines kept; list of (offset, char)). Understands //, nested /* */, "...", '...', raw strings, and ${...} templates
    (a template's braces are balanced like any other, and the matching } returns to the string)."""
    out = []; brackets = []; i = 0; n = len(src)
    stack = []                       # open brackets: (char, return_mode_or_None); return_mode is set for the "{" of a ${ template
    mode = "code"; block = 0
    while i < n:
        c = src[i]; nxt = src[i + 1] if i + 1 < n else ""
        if mode == "code":
            if c == "/" and nxt == "/":
                while i < n and src[i] != "\n": out.append(" "); i += 1
                continue
            if c == "/" and nxt == "*": block = 1; out.append("  "); i += 2; mode = "block"; continue
            if c == '"' and src.startswith('"""', i): out.append("   "); i += 3; mode = "raw"; continue
            if c == '"': out.append(" "); i += 1; mode = "str"; continue
            if c == "'":
                j = i + 1
                if j < n and src[j] == "\\":
                    j += 2
                    while j < n and src[j] != "'" and src[j] != "\n": j += 1
                else: j += 1
                if j < n and src[j] == "'":
                    out.append(" " * (j + 1 - i)); i = j + 1; continue
            if c in "([{":
                stack.append((c, None)); brackets.append((len(out), c))
            elif c in ")]}":
                if c == "}" and stack and stack[-1][0] == "{" and stack[-1][1] is not None:
                    mode = stack.pop()[1]; brackets.append((len(out), c)); out.append(" "); i += 1; continue
                brackets.append((len(out), c))
                if stack: stack.pop()
            out.append(c); i += 1
        elif mode == "block":
            if c == "/" and nxt == "*": block += 1; out.append("  "); i += 2; continue
            if c == "*" and nxt == "/":
                block -= 1; out.append("  "); i += 2
                if block == 0: mode = "code"
                continue
            out.append("\n" if c == "\n" else " "); i += 1
        else:                         # "str" or "raw"
            raw = mode == "raw"
            if not raw and c == "\\": out.append("  "); i += 2; continue
            if raw and src.startswith('"""', i):
                j = i + 3
                while j < n and src[j] == '"': j += 1
                out.append(" " * (j - i)); i = j; mode = "code"; continue
            if not raw and c == '"': out.append(" "); i += 1; mode = "code"; continue
            if c == "$" and nxt == "{":
                stack.append(("{", mode)); brackets.append((len(out), "{")); out.append("  "); i += 2; mode = "code"; continue
            if not raw and c == "\n": mode = "code"
            out.append("\n" if c == "\n" else " "); i += 1
    return "".join(out), brackets

def balance(path, src, brackets, code):
    st = []
    for off, ch in brackets:
        if ch in "({[": st.append((off, ch))
        else:
            if not st or st[-1][1] != PAIRS[ch]:
                report(path, code.count("\n", 0, off) + 1, f"ngoặc '{ch}' không khớp"); return
            st.pop()
    if st: report(path, code.count("\n", 0, st[-1][0]) + 1, f"ngoặc '{st[-1][1]}' không được đóng")

ALLOW = {}
JAVAISMS = [
    (re.compile(r"(?<![\w\.])new\s+[A-Z]\w*\s*[\(<\[]"), "`new` không có trong Kotlin"),
    (re.compile(r"\binstanceof\b"), "`instanceof` không có trong Kotlin (dùng `is`)"),
    (re.compile(r"(?<![\w\.\"'])(Integer|Long|Double|Boolean|Float|Short|Byte|Character)\.(parse\w*|valueOf|toString|compare\w*|toHexString|toBinaryString|toOctalString|bitCount|signum|isNaN|isInfinite|sum|max|min|hashCode|reverse\w*|highestOneBit|lowestOneBit|numberOfLeadingZeros|numberOfTrailingZeros)\("), "hàm tĩnh của lớp Java: dùng hàm Kotlin (toInt(), toLong(), toString(16), isNaN()...)"),
]
# API chưa có ở minSdk 24
API = [
    (r"\bjava\.time\.", "java.time cần API 26"), (r"\bjava\.util\.Base64\b", "java.util.Base64 cần API 26"), (r"\bjava\.nio\.file\.", "java.nio.file cần API 26"),
    (r"\.readAllBytes\(\)", "InputStream.readAllBytes cần API 33 (dùng readBytes() của Kotlin)"), (r"\.transferTo\(", "InputStream.transferTo cần API 33 (dùng copyTo)"),
    (r"\b(List|Set|Map)\.of\(", "List/Set/Map.of cần API 30 (dùng listOf / setOf / mapOf)"), (r"\bOptional\w*\.[a-z]+\([^)]*\)\.isEmpty\(\)", "Optional.isEmpty cần API 33"),
    (r"\bCollectors\.toUnmodifiable", "Collectors.toUnmodifiable* cần API 33"), (r"\bImageDecoder\b", "ImageDecoder cần API 28"), (r"\bResources[\w\.\(\)]*\.getFont\(", "Resources.getFont cần API 26"),
    (r"\bFiles\.(read|write|copy|move|delete|list|walk|exists|createTemp|newInput|newOutput)\w*\(", "java.nio.file.Files cần API 26"), (r"\bPaths\.get\(", "java.nio.file.Paths cần API 26"),
    (r"\bStandardCharsets\.", None),     # fine since API 19: listed only so a typo here is noticed
    (r"\.isBlank\(\)\s*\)?\s*$", None),
]
API = [(re.compile(p), m) for p, m in API if m]


# ---------- tự kiểm: bộ rà phải bắt lỗi thật và KHÔNG báo nhầm ----------
def lint_text(text):
    code, br = scan(text); issues = []
    st = []
    for off, ch in br:
        if ch in "({[": st.append(ch)
        else:
            if not st or st[-1] != PAIRS[ch]: issues.append("balance"); break
            st.pop()
    if st and "balance" not in issues: issues.append("balance")
    for ln, line in enumerate(code.split("\n"), 1):
        for rx, msg in JAVAISMS:
            if rx.search(line): issues.append("java")
        for rx, msg in API:
            if rx.search(line): issues.append("api")
    return issues
SELF = [
    ("fun f() { if (a) { b() } }", []),
    ("fun f() { if (a) { b() }", ["balance"]),
    ("fun f() { b()) }", ["balance"]),
    ('val s = "a { b ( c"', []),                                  # brackets inside a string do not count
    ('val s = "x ${map["k"]} y"', []),                           # template with [] and quotes inside
    ('val s = "x ${f { it + 1 }} y"', []),                       # template with a lambda
    ('val s = "x ${"nested ${1 + 2}"} y"', []),                  # template inside a template
    ("val r = \"\"\"raw { ( \"quoted\" \"\"\"", []),                # raw string
    ("val c = '{'; val d = '\\''; val e = '\\u0041'", []),         # char literals
    ("// a { comment\nval x = 1", []), ("/* a { /* nested ( */ still */ val x = 1", []),
    ("val x = new Foo()", ["java"]), ("val x = Integer.parseInt(s)", ["java"]), ("val x = Long.parseLong(s)", ["java"]), ("val y = Float.isNaN(v)", ["java"]),
    ("val m = Long.MAX_VALUE; val n = Float.NaN; val o = Double.MAX_VALUE", []),
    ("val d = java.time.LocalDate.now()", ["api"]), ("val b = java.util.Base64.getEncoder()", ["api"]), ("val a = stream.readAllBytes()", ["api"]),
    ("val l = List.of(1, 2)", ["api"]), ("val k = ImageDecoder.createSource(f)", ["api"]),
    ('val s = "new Foo() and java.time.X and Integer.parseInt(" ', []),   # same words inside a string are not code
    ("val z = x and 0xFF == 0", []),                              # valid Kotlin: infix binds tighter than ==
]
bad_self = [(t, want, lint_text(t)) for t, want in SELF if sorted(set(lint_text(t))) != sorted(set(want))]
if bad_self:
    for t, want, got in bad_self: print(f"LOI  tự kiểm: {t!r} mong đợi {want}, được {got}")
    sys.exit(1)
print(f"tự kiểm: {len(SELF)} ca đạt (bắt lỗi thật, không báo nhầm chuỗi / mẫu / chú thích)")

total = 0
for dirpath, _, files in os.walk(ROOT):
    for f in sorted(files):
        if not f.endswith(".kt"): continue
        path = os.path.join(dirpath, f); src = open(path, encoding="utf-8").read(); total += 1
        code, brackets = scan(src)
        balance(path, src, brackets, code)
        for ln, line in enumerate(code.split("\n"), 1):
            if not line.strip(): continue
            for rx, msg in JAVAISMS:
                if rx.search(line): report(path, ln, f"{msg}: `{line.strip()[:110]}`")
            for rx, msg in API:
                if rx.search(line): report(path, ln, f"{msg}: `{line.strip()[:110]}`")
print(f"đã rà {total} tệp .kt")
for x in fails: print("LOI  " + x)
print("TAT CA DAT" if not fails else f"{len(fails)} LOI")
sys.exit(1 if fails else 0)
