#!/usr/bin/env python3
"""Bút và bút dạ của trình đọc CHẠY THẬT (`util/PdfInk.kt`; phiên 24, TECHNICAL_DOCS.md 4.64): phần PdfBox của mục 4.62 chưa từng được chạy ở đâu, giờ chạy trên PdfBox-Android thật.

`ink_check.py` (phiên 23) kiểm bản Java chép lại và dựng chú thích bằng pikepdf; bộ này gọi CHÍNH `PdfInk.annotate` (Kotlin) rồi đo bằng poppler. Trang 600x800 với 4 hướng xoay x (CropBox
bằng MediaBox | CropBox lệch gốc) = 8 trang; nét được cho bằng toạ độ NGƯỜI DÙNG THẤY (0..1 từ góc trên-trái của trang đang hiển thị), vẽ lại bằng pdftoppm, rồi đo hộp bao của điểm ảnh có mực
so với chỗ đã chấm: nét ngang đỏ (bút), nét chéo xanh lá (bút) và nét dạ vàng (trong suốt: vàng nhạt chứ không phải vàng đặc). Kèm kiểm cấu trúc (/Ink, /InkList, /AP /N, /F 4), qpdf --check,
và: trang không bị rasterize (chữ gốc còn đủ), bút ghi vào đúng trang, chỉ số trang ngoài phạm vi / nét rỗng không ghi gì, tệp mã hoá bị từ chối.
THAY THẾ DUY NHẤT so với mã thật: `PdfVerify.opensAsPdf` (kiểm bằng PdfRenderer của Android, không có ngoài máy) được đổi thành kiểm bằng PdfBox "mở được và đủ số trang" - cùng hợp đồng.
THỬ ÂM TÍNH: bỏ đổi toạ độ theo xoay / CropBox (nét sai chỗ khi xoay), cho bút dạ đặc (mất trong suốt), đảo trục y - đều PHẢI bị bắt.
KHÔNG kiểm được: cảm ứng trên màn hình, độ mượt của nét lúc vẽ, hình dạng nét trên máy thật. Chạy: python3 tools/verify/ink_real_run_check.py [--fast]   (--mutant=N chỉ chạy bản hỏng thứ N, 1-3)"""
import os, re, shutil, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
import pikepdf  # noqa: E402
from pikepdf import Array, Dictionary, Name  # noqa: E402
from PIL import Image  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="ink-")
DOUBLE = {"PdfVerify.kt": ("    fun opensAsPdf(file: File, expectedPages: Int): Boolean {",
    "    fun opensAsPdf(file: File, expectedPages: Int): Boolean {\n        return try {\n            if (!file.exists() || file.length() <= 0L) return false\n"
    "            com.tom_roush.pdfbox.pdmodel.PDDocument.load(file).use { d -> d.numberOfPages > 0 && (expectedPages <= 0 || d.numberOfPages == expectedPages) }\n        } catch (e: Exception) { false }\n    }")}
FILES = ["PdfInk.kt", "PdfPageGeometry.kt", "PdfStructureOptimizer.kt", "PdfVerify.kt"]
HARNESS = os.path.join(HERE, "real_run", "InkHarness.kt")
def build(mutate=None, tag="base"): return tc.compile(FILES, [HARNESS], os.path.join(WORK, "cls-" + tag), mutate, DOUBLE)[0]
def annotate(cls, src, out, spec):
    r = tc.run(cls, "InkHarnessKt", ["annotate", src, out, spec])
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-800:])
    return r.stdout.strip().splitlines()[-1]
def sh(*c): return subprocess.run(c, capture_output=True, text=True)

def make_pdf(path, rotate, crop):
    pdf = pikepdf.new(); font = pdf.make_indirect(Dictionary(Type=Name.Font, Subtype=Name.Type1, BaseFont=Name.Helvetica))
    pdf.add_blank_page(page_size=(700, 900) if crop else (600, 800)); p = pdf.pages[0]
    p.Resources = Dictionary(Font=Dictionary(F1=font)); p.Contents = pdf.make_stream(b"BT /F1 20 Tf 60 120 Td (ORIGINAL TEXT STAYS) Tj ET\n")
    if crop: p.CropBox = Array([50, 60, 650, 860])
    if rotate: p.Rotate = rotate
    pdf.save(path, compress_streams=False)

def render(pdf, page=1):
    base = os.path.join(WORK, "r"); sh("pdftoppm", "-cropbox", "-r", "72", "-png", "-f", str(page), "-l", str(page), pdf, base)   # -cropbox: the displayed page is the CropBox (as in Android PdfRenderer); pdftoppm defaults to the MediaBox
    f = [x for x in os.listdir(WORK) if x.startswith("r") and x.endswith(".png")][0]
    im = Image.open(os.path.join(WORK, f)).convert("RGB"); os.remove(os.path.join(WORK, f)); return im

def bbox(im, pred):
    w, h = im.size; px = im.load(); xs, ys = [], []
    for y in range(h):
        for x in range(w):
            if pred(*px[x, y]): xs.append(x); ys.append(y)
    return (min(xs), min(ys), max(xs), max(ys), len(xs)) if xs else None

RED = lambda r, g, b: r - max(g, b) > 100
GREEN = lambda r, g, b: g - max(r, b) > 100
YELLOW = lambda r, g, b: r > 235 and g > 235 and b < 225
SPEC = "0;0;#FF0000;0.004;0.2,0.25 0.5,0.25 0.8,0.25|0;0;#00AA00;0.004;0.1,0.5 0.3,0.65 0.5,0.8|0;1;#FFFF00;0.022;0.2,0.1 0.5,0.1 0.8,0.1"

def run_page(cls, rotate, crop, tag):
    src = os.path.join(WORK, f"s-{tag}.pdf"); out = os.path.join(WORK, f"o-{tag}.pdf"); make_pdf(src, rotate, crop)
    n = annotate(cls, src, out, SPEC)
    return src, out, n

def measure(out):
    im = render(out); w, h = im.size
    return im, w, h, bbox(im, RED), bbox(im, GREEN), bbox(im, YELLOW)

def close(a, b, tol): return abs(a - b) <= tol
def verdict(w, h, red, green, yel):
    probs = []
    if not red or not (close(red[0], .2 * w, .03 * w) and close(red[2], .8 * w, .03 * w) and close(red[1], .25 * h, .02 * h) and close(red[3], .25 * h, .02 * h)): probs.append(f"nét đỏ {red} (mong đợi x {.2*w:.0f}-{.8*w:.0f}, y {.25*h:.0f})")
    if not green or not (close(green[0], .1 * w, .03 * w) and close(green[2], .5 * w, .03 * w) and close(green[1], .5 * h, .03 * h) and close(green[3], .8 * h, .03 * h)): probs.append(f"nét xanh {green} (mong đợi x {.1*w:.0f}-{.5*w:.0f}, y {.5*h:.0f}-{.8*h:.0f})")
    if not yel or not (close(yel[0], .2 * w, .035 * w) and close(yel[2], .8 * w, .035 * w) and close(yel[1] + (yel[3] - yel[1]) / 2, .1 * h, .02 * h)): probs.append(f"nét dạ {yel} (mong đợi x {.2*w:.0f}-{.8*w:.0f}, y {.1*h:.0f})")
    return probs

print("== B. vẽ thật: 4 hướng xoay x 2 kiểu CropBox"); cls = build()
for rot in (0, 90, 180, 270):
    for crop in (False, True):
        tag = f"{rot}-{int(crop)}"; src, out, n = run_page(cls, rot, crop, tag)
        if n != "3": check(False, f"xoay {rot}° CropBox {'lệch' if crop else 'thường'}: annotate trả '{n}' (mong đợi 3)"); continue
        im, w, h, red, green, yel = measure(out); probs = verdict(w, h, red, green, yel)
        check(not probs, f"xoay {rot}° CropBox {'lệch gốc' if crop else '= MediaBox'}: 3 nét đúng chỗ người dùng chấm ({w}x{h}px) {probs}")
        if rot == 0 and not crop:
            px = im.load(); ys = [y for y in range(h) if YELLOW(*px[int(.5 * w), y])]
            blues = sorted(px[int(.5 * w), y][2] for y in ys)
            check(bool(blues) and 120 <= blues[len(blues) // 2] <= 185, f"bút dạ TRONG SUỐT (vàng nhạt, kênh xanh dương ~153 khi 40 %): {blues[len(blues)//2] if blues else None}")
            check("ORIGINAL TEXT STAYS" in sh("pdftotext", out, "-").stdout, "chữ gốc của trang vẫn còn (trang không bị rasterize)")
            with pikepdf.open(out) as pdf:
                an = list(pdf.pages[0].Annots)
                check(len(an) == 3 and all(str(a.Subtype) == "/Ink" and int(a.F) == 4 and a.AP.N is not None and len(a.InkList) == 1 for a in an), "cấu trúc: 3 chú thích /Ink, /F 4, có /AP /N và /InkList")
                check(str(an[2].get("/CA")) in ("0.4", "0.4000"), f"bút dạ có /CA 0.4 ({an[2].get('/CA')})")
            check(sh("qpdf", "--check", out).returncode == 0, "qpdf --check sạch")

print("== B2. nhiều trang / trường hợp biên")
pdf2 = os.path.join(WORK, "multi.pdf")
with pikepdf.new() as pdf:
    for i in range(3): pdf.add_blank_page(page_size=(300, 400))
    pdf.save(pdf2)
o = os.path.join(WORK, "multi-o.pdf"); n = annotate(cls, pdf2, o, "1;0;#FF0000;0.01;0.2,0.5 0.8,0.5")
with pikepdf.open(o) as pdf:
    counts = [len(p.get("/Annots", [])) for p in pdf.pages]
check(n == "1" and counts == [0, 1, 0], f"nét ghi vào đúng trang 2 trong 3 trang ({counts})")
o = os.path.join(WORK, "multi-o2.pdf"); n = annotate(cls, pdf2, o, "7;0;#FF0000;0.01;0.2,0.5 0.8,0.5")
check(n.startswith("ERR") and not os.path.exists(o), f"trang ngoài phạm vi: không ghi gì, báo lỗi ('{n}'), không để lại tệp")
enc = os.path.join(WORK, "enc.pdf")
with pikepdf.open(pdf2) as pdf: pdf.save(enc, encryption=pikepdf.Encryption(user="u", owner="o"))
n = annotate(cls, enc, os.path.join(WORK, "enc-o.pdf"), "0;0;#FF0000;0.01;0.2,0.5 0.8,0.5")
check(n.startswith("ERR"), f"tệp mã hoá bị từ chối ('{n}')")

ONLY = next((int(a.split("=")[1]) for a in sys.argv if a.startswith("--mutant=")), None)
if "--fast" in sys.argv and ONLY is None: print("== D. bỏ qua thử âm tính (--fast)")
else:
    print("== D. thử âm tính")
    MUT = [("bỏ đổi toạ độ theo xoay / CropBox", ("val p = geo.toUser(stroke.points[2 * i].coerceIn(0f, 1f) * geo.displayWidth, stroke.points[2 * i + 1].coerceIn(0f, 1f) * geo.displayHeight)",
                                               "val p = Pair(stroke.points[2 * i].coerceIn(0f, 1f) * geo.displayWidth, stroke.points[2 * i + 1].coerceIn(0f, 1f) * geo.displayHeight)")),
           ("bút dạ đặc (mất trong suốt)", ("const val MARKER_OPACITY = 0.4f", "const val MARKER_OPACITY = 1.0f")),
           ("đảo trục y", ("stroke.points[2 * i + 1].coerceIn(0f, 1f) * geo.displayHeight)", "(1f - stroke.points[2 * i + 1].coerceIn(0f, 1f)) * geo.displayHeight)"))]
    for number, (name, (old, new)) in enumerate(MUT, 1):
        if ONLY is not None and number != ONLY: continue
        try: mcls = build({"PdfInk.kt": (old, new)}, tag="mut")
        except RuntimeError: check(True, f"ÂM TÍNH '{name}': bản hỏng không biên dịch (bị bắt)"); continue
        caught = False
        for rot, crop in ((0, False), (90, False), (270, True)):
            src, out, n = run_page(mcls, rot, crop, f"m{rot}{int(crop)}")
            if n != "3": caught = True; break
            im, w, h, red, green, yel = measure(out)
            if verdict(w, h, red, green, yel): caught = True; break
            px = im.load(); ys = [y for y in range(h) if YELLOW(*px[int(.5 * w), y])]
            blues = sorted(px[int(.5 * w), y][2] for y in ys)
            if rot == 0 and not (blues and 120 <= blues[len(blues) // 2] <= 185): caught = True; break
        check(caught, f"ÂM TÍNH '{name}': bản hỏng bị bắt")
shutil.rmtree(WORK, ignore_errors=True); print("\nTAT CA DAT" if not fails else f"\n{len(fails)} LOI"); sys.exit(1 if fails else 0)
