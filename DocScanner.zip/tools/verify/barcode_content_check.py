"""Kiểm chứng BarcodeContent (phiên 17): hiểu nội dung QR / mã vạch.

BarcodeContentCheck.java là bản Java chạy được của BarcodeContent.kt. Cách kiểm: VÒNG ĐI-VỀ theo định dạng ZXing / điện thoại thật sự ghi:
sinh giá trị ngẫu nhiên (có `; , : \\ "`, dấu cách, chữ Việt, emoji), MÃ HOÁ theo đúng quy tắc của từng định dạng bằng mã Python viết riêng ở đây, đưa chuỗi mã
cho bản Java phân tích, và đòi lại ĐÚNG giá trị ban đầu. Cộng các ví dụ nguyên văn từ trang "Barcode Contents" của ZXing và RFC 6068.
Ca khó có đáp án tay: mật khẩu thật sự bắt đầu và kết thúc bằng dấu `"` (viết `\\"..\\"`) phải GIỮ ngoặc; giá trị toàn chữ số được bọc `"0123"` thì bỏ ngoặc;
`+` trong địa chỉ thư và số điện thoại KHÔNG thành dấu cách; tên miền chữ Việt và emoji qua % mã hoá; liên kết có dấu cách là văn bản, không phải URL.
THỬ ÂM TÍNH: một bộ phân tích "ngây thơ" (cắt theo `;` mà không xét `\\`, bỏ ngoặc kép mù quáng) phải bị vòng đi-về bắt.
Chạy: python3 barcode_content_check.py   (cần java 11+)
"""
import os, random, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
HERE = os.path.dirname(os.path.abspath(__file__))
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
    return cond

def enc_line(raw, product=False): return ("1" if product else "0") + "\t" + raw.replace("\\", "\\\\").replace("\n", "\\n").replace("\r", "\\r").replace("\t", "\\t")
def unesc(s):
    out, i = [], 0
    while i < len(s):
        c = s[i]
        if c == "\\" and i + 1 < len(s):
            i += 1; d = s[i]; out.append({"n": "\n", "t": "\t", "r": "\r"}.get(d, d))
        else: out.append(c)
        i += 1
    return "".join(out)
def run(cases):
    fin, fout = os.path.join(OUT, "bc_in.txt"), os.path.join(OUT, "bc_out.txt")
    with open(fin, "w", encoding="utf-8") as f: f.write("\n".join(enc_line(*c) for c in cases) + "\n")
    subprocess.run(["java", os.path.join(HERE, "BarcodeContentCheck.java"), fin, fout], check=True)
    res = []
    for ln in open(fout, encoding="utf-8").read().split("\n")[:-1]:
        parts = ln.split("\t"); fields = {}
        for p in parts[1:]:
            k, _, v = p.partition("="); fields[k] = unesc(v)
        res.append((parts[0], fields))
    return res

# ---- bộ mã hoá độc lập ----
def esc_semi(v): return "".join("\\" + c if c in '\\;,:"' else c for c in v)
def pct(v): return "".join(c if c.isalnum() and c.isascii() or c in "-._~" else "".join(f"%{b:02X}" for b in c.encode("utf-8")) for c in v)
ALPHA = list("abcXYZ019 -_.+@/!#$%^&*()=?<>[]{}'~`|") + ["\\", ";", ",", ":", '"', "ế", "ộ", "Đ", "ự", "😀", "é"]
def rnd_text(r, lo=1, hi=14): return "".join(r.choice(ALPHA) for _ in range(r.randint(lo, hi)))

print("== ví dụ nguyên văn (ZXing wiki, RFC 6068) ==")
H = [
    ("WIFI:T:WPA;S:mynetwork;P:mypass;;", ("WIFI", {"ssid": "mynetwork", "password": "mypass", "security": "WPA", "hidden": "false"})),
    ("WIFI:S:no pass net;;", ("WIFI", {"ssid": "no pass net", "password": "", "security": "nopass", "hidden": "false"})),
    ('WIFI:T:WEP;S:"1234";P:"5678";H:true;;', ("WIFI", {"ssid": "1234", "password": "5678", "security": "WEP", "hidden": "true"})),
    ('WIFI:T:WPA;S:\\"quoted\\";P:\\"p\\;w\\";;', ("WIFI", {"ssid": '"quoted"', "password": '"p;w"', "security": "WPA", "hidden": "false"})),
    ("wifi:t:wpa;s:Home;p:pw;;", ("WIFI", {"ssid": "Home", "password": "pw", "security": "WPA", "hidden": "false"})),
    ("mailto:someone@example.com?subject=Hello%20World&body=Line%201", ("EMAIL", {"address": "someone@example.com", "subject": "Hello World", "body": "Line 1"})),
    ("mailto:a+tag@example.com", ("EMAIL", {"address": "a+tag@example.com", "subject": "", "body": ""})),
    ("MATMSG:TO:a@b.com;SUB:Hi\\; there;BODY:Body;;", ("EMAIL", {"address": "a@b.com", "subject": "Hi; there", "body": "Body"})),
    ("tel:+84912345678", ("PHONE", {"number": "+84912345678"})),
    ("smsto:+84912345678:Xin chào", ("SMS", {"number": "+84912345678", "body": "Xin chào"})),
    ("sms:+84912345678?body=Xin%20ch%C3%A0o", ("SMS", {"number": "+84912345678", "body": "Xin chào"})),
    ("smsto:+84912345678:Bạn khoẻ không? Gọi lại nhé", ("SMS", {"number": "+84912345678", "body": "Bạn khoẻ không? Gọi lại nhé"})),   # có ? nhưng KHÔNG phải dạng ?body=
    ("geo:10.7769,106.7009", ("GEO", {"lat": "10.7769", "lon": "106.7009"})),
    ("geo:95,10", ("TEXT", {"text": "geo:95,10"})),
    ("MECARD:N:Nguyễn,Văn An;TEL:0912345678;EMAIL:an@x.vn;ORG:Cty;;", ("CONTACT", {"name": "Văn An Nguyễn", "phone": "0912345678", "email": "an@x.vn", "org": "Cty"})),
    ("BEGIN:VCARD\nVERSION:3.0\nN:Nguyễn;Văn An;;;\nFN:Văn An Nguyễn\nTEL;TYPE=CELL:0912345678\nEMAIL;TYPE=INTERNET:an@x.vn\nORG:Cty\nEND:VCARD", ("CONTACT", {"name": "Văn An Nguyễn", "phone": "0912345678", "email": "an@x.vn", "org": "Cty"})),
    ("BEGIN:VCARD\r\nN:Tran;Binh;;;\r\nTEL:1\r\nEND:VCARD", ("CONTACT", {"name": "Binh Tran", "phone": "1", "email": "", "org": ""})),
    ("BEGIN:VEVENT\nSUMMARY:Họp\nDTSTART:20261014T090000Z\nLOCATION:Phòng 1\nEND:VEVENT", ("EVENT", {"summary": "Họp", "start": "20261014T090000Z", "end": "", "location": "Phòng 1"})),
    ("https://example.com/a?b=c", ("URL", {"url": "https://example.com/a?b=c"})),
    ("HTTP://EXAMPLE.COM", ("URL", {"url": "HTTP://EXAMPLE.COM"})),
    ("www.example.com", ("URL", {"url": "https://www.example.com"})),
    ("https://example.com/with space", ("TEXT", {"text": "https://example.com/with space"})),
    ("  xin chào  ", ("TEXT", {"text": "xin chào"})),
    ("", ("TEXT", {})),
]
got = run([(raw,) for raw, _ in H])
for (raw, exp), g in zip(H, got): check(g == exp, f"{raw[:48]!r} -> {g[0]}")
pr = run([("8934673000012", True), ("9786041234567", True), ("978604123456", True), ("12345", False), ("ABC123", True)])
check(pr[0] == ("PRODUCT", {"code": "8934673000012", "isbn": ""}) and pr[1] == ("PRODUCT", {"code": "9786041234567", "isbn": "9786041234567"}) and pr[2][0] == "PRODUCT" and pr[2][1]["isbn"] == "" and pr[3][0] == "TEXT" and pr[4][0] == "TEXT", "mã sản phẩm: EAN-13 thường, ISBN (978/979), 12 chữ số không phải ISBN; số trần không có định dạng sản phẩm là văn bản")

print("== vòng đi-về ngẫu nhiên ==")
r = random.Random(17)
cases, expect = [], []
for _ in range(1500):
    k = r.choice(["wifi", "mailto", "matmsg", "smsto", "sms", "mecard", "geo"])
    if k == "wifi":
        ssid, pw = rnd_text(r), rnd_text(r, 0, 12)
        if r.random() < 0.15: ssid = '"' + ssid + '"'
        sec = r.choice(["WPA", "WEP", "nopass"]); hid = r.choice([True, False])
        s = f"WIFI:T:{sec};S:{esc_semi(ssid)};" + (f"P:{esc_semi(pw)};" if sec != "nopass" or pw else "") + ("H:true;" if hid else "") + ";"
        if ssid.strip() == "" : continue
        cases.append((s,)); expect.append(("WIFI", {"ssid": ssid, "password": pw if (sec != "nopass" or pw) else "", "security": sec, "hidden": "true" if hid else "false"}))
    elif k == "mailto":
        a = "".join(r.choice("abcxyz.-_+") for _ in range(r.randint(1, 8))) + "@" + "ex.com"
        sub, body = rnd_text(r, 0, 12), rnd_text(r, 0, 20)
        s = "mailto:" + a + "?subject=" + pct(sub) + "&body=" + pct(body)
        cases.append((s,)); expect.append(("EMAIL", {"address": a, "subject": sub, "body": body}))
    elif k == "matmsg":
        a = "u" + str(r.randint(1, 99)) + "@ex.com"; sub, body = rnd_text(r, 0, 12), rnd_text(r, 0, 20)
        cases.append((f"MATMSG:TO:{a};SUB:{esc_semi(sub)};BODY:{esc_semi(body)};;",)); expect.append(("EMAIL", {"address": a, "subject": sub, "body": body}))
    elif k == "smsto":
        num = "+" + "".join(r.choice("0123456789") for _ in range(10)); body = rnd_text(r, 0, 20).replace("\n", " ")
        cases.append((f"smsto:{num}:{body}",)); expect.append(("SMS", {"number": num, "body": body}))
    elif k == "sms":
        num = "+" + "".join(r.choice("0123456789") for _ in range(10)); body = rnd_text(r, 0, 20)
        cases.append((f"sms:{num}?body={pct(body)}",)); expect.append(("SMS", {"number": num, "body": body}))
    elif k == "mecard":
        last, first = rnd_text(r, 1, 8).replace(",", ""), rnd_text(r, 1, 8).replace(",", "")
        if last.strip() == "" or first.strip() == "": continue
        tel = "".join(r.choice("0123456789") for _ in range(10)); mail = "m" + str(r.randint(1, 9)) + "@x.vn"
        cases.append((f"MECARD:N:{esc_semi(last)},{esc_semi(first)};TEL:{tel};EMAIL:{mail};;",)); expect.append(("CONTACT", {"name": (first.strip() + " " + last.strip()).strip(), "phone": tel, "email": mail, "org": ""}))
    else:
        lat, lon = round(r.uniform(-90, 90), 5), round(r.uniform(-180, 180), 5)
        cases.append((f"geo:{lat},{lon}",)); expect.append(("GEO", {"lat": str(lat), "lon": str(lon)}))
got = run(cases)
bad = [(c[0], e, g) for c, e, g in zip(cases, expect, got) if e != g]
check(not bad, f"{len(cases)} chuỗi mã ngẫu nhiên (WIFI/mailto/MATMSG/smsto/sms/MECARD/geo): phân tích đòi lại đúng giá trị ({len(bad)} lệch) {bad[:1]}")
kinds = {}
for e in expect: kinds[e[0]] = kinds.get(e[0], 0) + 1
check(len(kinds) == 5 and min(kinds.values()) > 50, f"mọi loại đều có > 50 ca: {kinds}")

print("== thử âm tính: bộ phân tích ngây thơ ==")
def naive_wifi(s):
    f = {}
    for part in s[5:].split(";"):
        if ":" in part: k, _, v = part.partition(":"); f[k] = v.strip('"')
    return f.get("S", ""), f.get("P", "")
wifi_cases = [(c[0], e[1]) for c, e in zip(cases, expect) if e[0] == "WIFI"]
caught = sum(1 for s, e in wifi_cases if naive_wifi(s) != (e["ssid"], e["password"]))
check(caught > 20, f"cách ngây thơ (cắt theo `;`, bỏ `\"` mù quáng) sai ở {caught}/{len(wifi_cases)} ca Wi-Fi - vòng đi-về bắt được")
print()
print("TAT CA DAT" if not FAILS else f"CO {len(FAILS)} LOI: " + "; ".join(FAILS[:5]))
sys.exit(1 if FAILS else 0)
