import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.zip.*;

/** Ban Java chay duoc cua util/ArchiveImages.kt (phien 18): lay anh tu goi CBZ/ZIP theo thu tu tu nhien, an toan voi zip-slip / zip-bomb; va ham kiem dung luong trong. */
public class ArchiveImagesCheck {
    static final Set<String> EXT = new HashSet<>(Arrays.asList("jpg", "jpeg", "png", "webp", "gif", "bmp"));

    static boolean isImageName(String raw) {
        String name = raw.replace('\\', '/');
        if (name.endsWith("/")) return false;
        String[] seg = name.split("/");
        for (String s : seg) { if (s.isEmpty()) continue; if (s.startsWith(".") || s.equals("__MACOSX")) return false; }
        String last = seg[seg.length - 1];
        if (last.equalsIgnoreCase("thumbs.db")) return false;
        int dot = last.lastIndexOf('.'); if (dot < 0) return false;
        return EXT.contains(last.substring(dot + 1).toLowerCase(Locale.ROOT));
    }
    static boolean isDigit(char c) { return c >= '0' && c <= '9'; }
    static int natural(String a, String b) {
        int i = 0, j = 0;
        while (i < a.length() && j < b.length()) {
            boolean da = isDigit(a.charAt(i)), db = isDigit(b.charAt(j));
            int ie = i, je = j;
            while (ie < a.length() && isDigit(a.charAt(ie)) == da) ie++;
            while (je < b.length() && isDigit(b.charAt(je)) == db) je++;
            String ta = a.substring(i, ie), tb = b.substring(j, je);
            if (da != db) return da ? -1 : 1;                       // so dung truoc chu
            int c;
            if (da) {
                String na = ta.replaceFirst("^0+(?=.)", ""), nb = tb.replaceFirst("^0+(?=.)", "");
                c = na.length() != nb.length() ? Integer.compare(na.length(), nb.length()) : na.compareTo(nb);
            } else c = ta.toLowerCase(Locale.ROOT).compareTo(tb.toLowerCase(Locale.ROOT));
            if (c != 0) return c;
            i = ie; j = je;
        }
        int rest = Integer.compare(a.length() - i, b.length() - j);
        if (rest != 0) return rest;
        return a.compareTo(b);
    }
    static List<File> extract(File zip, File outDir, String prefix, int maxEntries, long maxEntryBytes, long maxTotalBytes) throws IOException {
        ArrayList<File> out = new ArrayList<>();
        try (ZipFile z = new ZipFile(zip)) {
            ArrayList<ZipEntry> picked = new ArrayList<>();
            for (Enumeration<? extends ZipEntry> en = z.entries(); en.hasMoreElements(); ) { ZipEntry e = en.nextElement(); if (!e.isDirectory() && isImageName(e.getName())) picked.add(e); }
            picked.sort((x, y) -> natural(x.getName().replace('\\', '/'), y.getName().replace('\\', '/')));
            if (!outDir.exists()) outDir.mkdirs();
            long total = 0; int n = 0;
            for (ZipEntry e : picked) {
                if (n >= maxEntries) break;
                String nm = e.getName(); String ext = nm.substring(nm.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT);
                File f = new File(outDir, String.format("%s%04d.%s", prefix, n + 1, ext));
                long bytes = 0; boolean ok = true;
                try (InputStream in = z.getInputStream(e); OutputStream os = new FileOutputStream(f)) {
                    byte[] buf = new byte[65536]; int r;
                    while ((r = in.read(buf)) > 0) { bytes += r; if (bytes > maxEntryBytes || total + bytes > maxTotalBytes) { ok = false; break; } os.write(buf, 0, r); }
                }
                if (!ok) { f.delete(); if (total + bytes > maxTotalBytes && bytes <= maxEntryBytes) break; continue; }
                total += bytes; n++; out.add(f);
            }
        }
        return out;
    }
    // ---- dung luong trong
    static final long MARGIN = 64L * 1024 * 1024;
    static long required(long input) { long twice = input > Long.MAX_VALUE / 2 ? Long.MAX_VALUE : input * 2; return twice > Long.MAX_VALUE - MARGIN ? Long.MAX_VALUE : twice + MARGIN; }
    static boolean enough(long free, long input) { return free >= required(input); }

    public static void main(String[] a) throws Exception {
        switch (a[0]) {
            case "sort": {   // tep: moi dong mot ten -> in cac ten theo thu tu tu nhien
                List<String> names = Files.readAllLines(Paths.get(a[1])); names.sort(ArchiveImagesCheck::natural); for (String s : names) System.out.println(s); break;
            }
            case "sort-batch": {   // cac danh sach cach nhau bang dong "---"; in moi danh sach da sap xep roi dong "---"
                List<String> cur = new ArrayList<>();
                for (String l : Files.readAllLines(Paths.get(a[1]), java.nio.charset.StandardCharsets.UTF_8)) {
                    if (l.equals("---")) { cur.sort(ArchiveImagesCheck::natural); for (String s : cur) System.out.println(s); System.out.println("---"); cur.clear(); } else cur.add(l);
                }
                break;
            }
            case "isimage": { for (String s : Files.readAllLines(Paths.get(a[1]))) System.out.println(isImageName(s)); break; }
            case "extract": {   // zip outDir prefix maxEntries maxEntry maxTotal
                try { for (File f : extract(new File(a[1]), new File(a[2]), a[3], Integer.parseInt(a[4]), Long.parseLong(a[5]), Long.parseLong(a[6]))) System.out.println(f.getName() + "\t" + f.length()); }
                catch (IOException e) { System.out.println("ERR"); }
                break;
            }
            case "space": { for (String l : Files.readAllLines(Paths.get(a[1]))) { String[] p = l.split(" "); System.out.println(enough(Long.parseLong(p[0]), Long.parseLong(p[1]))); } break; }
            default: System.exit(2);
        }
    }
}
