"""Kiểm chứng THIẾT KẾ của PdfFormFiller (phiên 15): giá trị đặt thẳng vào /V kèm cờ NeedAppearances vẫn HIỆN trong trình đọc.

Không chạy được PdfBox trên máy tính, nên kiểm cái ý tưởng dự phòng cho chữ tiếng Việt: PdfBox từ chối dựng giao diện (appearance) của ô văn bản khi
font của ô (Helvetica) không mã hoá được ký tự, nên mã gán /V trực tiếp rồi bật /NeedAppearances để trình đọc tự vẽ.
Với reportlab dựng một biểu mẫu có ô văn bản và ô tích, pikepdf đặt giá trị bằng đúng hai cách rồi poppler (pdftoppm) vẽ lại, đo mực trong khung ô:
  A. /V có chữ tiếng Việt nhưng KHÔNG bật NeedAppearances -> ô vẫn trống (chứng minh vì sao cần cờ);
  B. /V có chữ tiếng Việt + NeedAppearances true -> ô có mực (trình đọc tự vẽ);
  C. phép đọc lại: pikepdf thấy đúng /V và cờ; ô tích đặt qua /V + /AS = /Yes hiện dấu tích.
Chạy: python3 form_check.py   (cần reportlab, pikepdf, numpy, pillow, pdftoppm)
"""
import os, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import numpy as np
from PIL import Image
import pikepdf
from pikepdf import Name, String
from reportlab.pdfgen import canvas

RECT_TEXT = (60, 700, 300, 725)      # x0, y0, x1, y1 (pt, gốc dưới-trái, trang 400x800)
RECT_BOX = (60, 650, 80, 670)


def build_form(path):
    c = canvas.Canvas(path, pagesize=(400, 800))
    c.drawString(60, 735, "Ho ten:")
    c.acroForm.textfield(name="ho_ten", x=RECT_TEXT[0], y=RECT_TEXT[1], width=RECT_TEXT[2] - RECT_TEXT[0], height=RECT_TEXT[3] - RECT_TEXT[1], borderWidth=0, fillColor=None, textColor=None, forceBorder=False)
    c.acroForm.checkbox(name="dong_y", x=RECT_BOX[0], y=RECT_BOX[1], size=20, borderWidth=0, forceBorder=False)
    c.save()


def ink(path, rect):
    base = path[:-4]
    subprocess.run(["pdftoppm", "-r", "72", "-png", "-singlefile", path, base], check=True)
    img = np.array(Image.open(base + ".png").convert("L"))
    h = img.shape[0]
    x0, y0, x1, y1 = rect
    region = img[h - y1:h - y0, x0:x1]
    return int((region < 140).sum())


def fields(pdf):
    return {str(f.get("/T")): f for f in pdf.Root.AcroForm.Fields}


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    return cond


def main():
    good = True
    src = os.path.join(OUT, "form_src.pdf"); build_form(src)
    good &= check(ink(src, RECT_TEXT) == 0, "biểu mẫu gốc: ô văn bản trống")
    value = "Nguyễn Văn Ạ"

    a = os.path.join(OUT, "form_a.pdf")
    with pikepdf.open(src) as pdf:
        fields(pdf)["ho_ten"].V = String(value)
        if "/NeedAppearances" in pdf.Root.AcroForm:
            del pdf.Root.AcroForm["/NeedAppearances"]
        pdf.save(a)
    ink_a = ink(a, RECT_TEXT)
    good &= check(ink_a == 0, f"A: /V có chữ nhưng KHÔNG bật NeedAppearances -> ô vẫn trống (mực={ink_a})")

    b = os.path.join(OUT, "form_b.pdf")
    with pikepdf.open(src) as pdf:
        fields(pdf)["ho_ten"].V = String(value)
        pdf.Root.AcroForm.NeedAppearances = True
        pdf.save(b)
    ink_b = ink(b, RECT_TEXT)
    good &= check(ink_b > 30, f"B: /V có chữ + NeedAppearances -> trình đọc tự vẽ, ô có mực (mực={ink_b})")
    with pikepdf.open(b) as pdf:
        good &= check(str(fields(pdf)["ho_ten"].V) == value and bool(pdf.Root.AcroForm.NeedAppearances), "đọc lại: /V và cờ NeedAppearances đúng như đã đặt")

    c = os.path.join(OUT, "form_c.pdf")
    with pikepdf.open(src) as pdf:
        box = fields(pdf)["dong_y"]
        on_names = [k for k in box.AP.N.keys()]
        on = next((k for k in on_names if k != "/Off"), None)
        box.V = Name(on); box.AS = Name(on)
        pdf.save(c)
    ink_c = ink(c, RECT_BOX)
    good &= check(on is not None and ink_c > 20, f"C: ô tích đặt /V và /AS = {on} -> hiện dấu tích (mực={ink_c})")
    print("TAT CA DAT" if good else "CO LOI")
    return 0 if good else 1


if __name__ == "__main__":
    sys.exit(main())
