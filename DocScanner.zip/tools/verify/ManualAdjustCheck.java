// Bản Java chạy được của Despeckle (phiên 17): cùng logic, cùng thứ tự với app/.../util/Despeckle.kt.
// Dùng bởi manual_adjust_check.py: java ManualAdjustCheck.java <vào> <ra>.
// vào: int w, int h, int level, int longEdge (big-endian), rồi w*h byte mặt nạ mực (0/1); ra: w*h byte (1 = điểm ảnh thuộc đốm).
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class ManualAdjustCheck {
    static final int REF_EDGE = 1500;
    static final int[] LEVEL_AREA = {0, 6, 16, 36};
    static final double GAP_FACTOR = 0.8;

    static int maxAreaFor(int level, int longEdge) {
        int l = Math.max(0, Math.min(3, level));
        if (l == 0) return 0;
        double s = (double) longEdge / REF_EDGE;
        return Math.max(1, (int) Math.round(LEVEL_AREA[l] * s * s));
    }

    static int[] parent;
    static int find(int a) { int x = a; while (parent[x] != x) { parent[x] = parent[parent[x]]; x = parent[x]; } return x; }
    static void union(int a, int b) { int ra = find(a), rb = find(b); if (ra != rb) { if (ra < rb) parent[rb] = ra; else parent[ra] = rb; } }

    static int count; static int[] lab, areas, heights;

    static void label(byte[] mask, int w, int h) {
        parent = new int[w * h / 2 + 2];
        int next = 1;
        lab = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int p = y * w + x;
            if (mask[p] == 0) continue;
            int m = 0;
            int[] cand = { x > 0 ? lab[p - 1] : 0, (x > 0 && y > 0) ? lab[p - w - 1] : 0, y > 0 ? lab[p - w] : 0, (x < w - 1 && y > 0) ? lab[p - w + 1] : 0 };
            for (int c : cand) if (c != 0 && m == 0) m = c;
            if (m == 0) { parent[next] = next; lab[p] = next; next++; }
            else { lab[p] = m; for (int c : cand) if (c != 0) union(m, c); }
        }
        int[] remap = new int[next];
        count = 0;
        for (int i = 1; i < next; i++) if (find(i) == i) { count++; remap[i] = count; }
        for (int i = 1; i < next; i++) remap[i] = remap[find(i)];
        areas = new int[count + 1];
        int[] minY = new int[count + 1], maxY = new int[count + 1];
        Arrays.fill(minY, Integer.MAX_VALUE); Arrays.fill(maxY, -1);
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) {
            int p = y * w + x; int l = lab[p];
            if (l == 0) continue;
            int r = remap[l]; lab[p] = r; areas[r]++;
            if (y < minY[r]) minY[r] = y; if (y > maxY[r]) maxY[r] = y;
        }
        heights = new int[count + 1];
        for (int i = 1; i <= count; i++) heights[i] = maxY[i] - minY[i] + 1;
    }

    static int gapFor(int maxArea, int longEdge) {
        List<Integer> hs = new ArrayList<>();
        for (int i = 1; i <= count; i++) if (areas[i] > maxArea) hs.add(heights[i]);
        double glyph;
        if (hs.isEmpty()) glyph = Math.max(8.0, longEdge / 100.0); else { Collections.sort(hs); glyph = hs.get(hs.size() / 2); }
        return Math.max(2, (int) Math.round(GAP_FACTOR * glyph));
    }

    static boolean[] findSpecks(int w, int h, int maxArea, int gap) {
        boolean[] speck = new boolean[count + 1];
        if (maxArea <= 0 || count == 0) return speck;
        byte[] tmp = new byte[w * h];
        for (int p = 0; p < w * h; p++) { int lb = lab[p]; if (lb != 0 && areas[lb] > maxArea) tmp[p] = 1; }
        byte[] horiz = new byte[w * h];
        for (int y = 0; y < h; y++) {
            int cnt = 0;
            for (int x = 0; x < Math.min(gap, w); x++) cnt += tmp[y * w + x];
            for (int x = 0; x < w; x++) {
                if (x + gap < w) cnt += tmp[y * w + x + gap];
                if (x - gap - 1 >= 0) cnt -= tmp[y * w + x - gap - 1];
                if (cnt > 0) horiz[y * w + x] = 1;
            }
        }
        byte[] near = new byte[w * h];
        for (int x = 0; x < w; x++) {
            int cnt = 0;
            for (int y = 0; y < Math.min(gap, h); y++) cnt += horiz[y * w + x];
            for (int y = 0; y < h; y++) {
                if (y + gap < h) cnt += horiz[(y + gap) * w + x];
                if (y - gap - 1 >= 0) cnt -= horiz[(y - gap - 1) * w + x];
                if (cnt > 0) near[y * w + x] = 1;
            }
        }
        boolean[] prot = new boolean[count + 1];
        for (int p = 0; p < w * h; p++) { int lb = lab[p]; if (lb != 0 && near[p] != 0) prot[lb] = true; }
        for (int i = 1; i <= count; i++) speck[i] = areas[i] <= maxArea && !prot[i];
        return speck;
    }

    public static void main(String[] a) throws Exception {
        DataInputStream in = new DataInputStream(new BufferedInputStream(Files.newInputStream(Paths.get(a[0]))));
        int w = in.readInt(), h = in.readInt(), level = in.readInt(), longEdge = in.readInt();
        byte[] ink = new byte[w * h]; in.readFully(ink);
        label(ink, w, h);
        int maxArea = maxAreaFor(level, longEdge);
        boolean[] sp = findSpecks(w, h, maxArea, gapFor(maxArea, longEdge));
        byte[] out = new byte[w * h];
        for (int p = 0; p < w * h; p++) { int l = lab[p]; if (l != 0 && sp[l]) out[p] = 1; }
        Files.write(Paths.get(a[1]), out);
    }
}
