"""Dựng một PDF/A-2b MẪU bằng đúng các bước của PdfAConverter.kt (phiên 17), dùng chính các BYTE ICC và gói XMP do PdfACheck.java sinh
(Java chạy cùng logic với SrgbIcc.kt / PdfAXmp.kt). Dùng ở hai nơi:
  - pdfa_check.py: kiểm bằng công cụ độc lập (qpdf, lcms, pdftotext, phân tích XML);
  - CI (.github/workflows/android-build.yml, job `pdfa`): kiểm bằng veraPDF - bộ kiểm chuẩn PDF/A thật, thứ môi trường làm việc không chạy được.
Mẫu giống sản phẩm thật của app: trang quét (ảnh JPEG toàn trang) + lớp chữ vô hình (phông Type3 rỗng, Tr 3, ToUnicode) như SearchablePdfBuilder.
Chạy: python3 pdfa_sample.py <ra.pdf>   (cần java 11+, pikepdf, pillow)
"""
import io, os, struct, subprocess, sys, tempfile
import pikepdf
from pikepdf import Name, Array, Dictionary, String
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__))
TMP = tempfile.mkdtemp(prefix="pdfa_")

def java(*args): subprocess.run(["java", os.path.join(HERE, "PdfACheck.java"), *map(str, args)], check=True)

def icc_bytes():
    out = os.path.join(TMP, "srgb.icc"); java("icc", out); return open(out, "rb").read()

def hexs(s): return s.encode("utf-8").hex()
def xmp_for(title, author, producer, tool, created_ms, mod_ms, off_min):
    """-> (chuỗi ngày Info tạo, chuỗi ngày Info sửa, gói XMP dạng chuỗi) do bản Java của PdfAXmp sinh."""
    fin, fout = os.path.join(TMP, "x_in.txt"), os.path.join(TMP, "x_out.txt")
    with open(fin, "w", encoding="utf-8") as f: f.write("\t".join([hexs(title), hexs(author), hexs(producer), hexs(tool), str(created_ms), str(mod_ms), str(off_min)]) + "\n")
    java("xmp", fin, fout)
    lines = open(fout, encoding="utf-8").read().split("\n")
    c, m = lines[0][5:].split("\t")
    return c, m, bytes.fromhex(lines[1]).decode("utf-8")

TEXT = "Hop dong thue nha"
def build_scan_pdf(path, pages=2, text_layer=True):
    pdf = pikepdf.new()
    # phông Type3 vô hình như SearchablePdfBuilder.buildType3Font
    cps = sorted(set(TEXT))
    glyph = pdf.make_stream(b"500 0 d0\n")
    charprocs = Dictionary({f"/g{i + 1}": glyph for i in range(len(cps))})
    cmap = "/CIDInit /ProcSet findresource begin 12 dict begin begincmap /CMapName /Adobe-Identity-UCS def /CMapType 2 def\n1 begincodespacerange <01> <FF> endcodespacerange\n%d beginbfchar\n" % len(cps)
    cmap += "".join(f"<{i + 1:02X}> <{ord(ch):04X}>\n" for i, ch in enumerate(cps))
    cmap += "endbfchar\nendcmap CMapName currentdict /CMap defineresource pop end end\n"
    tounicode = pdf.make_stream(cmap.encode("ascii"))
    font = pdf.make_indirect(Dictionary(
        Type=Name.Font, Subtype=Name.Type3, FontBBox=Array([0, -200, 500, 800]), FontMatrix=Array([0.001, 0, 0, 0.001, 0, 0]),
        CharProcs=charprocs, Encoding=Dictionary(Type=Name.Encoding, Differences=Array([1] + [Name(f"/g{i + 1}") for i in range(len(cps))])),
        FirstChar=1, LastChar=len(cps), Widths=Array([500] * len(cps)), ToUnicode=tounicode))
    codes = "".join(f"{cps.index(ch) + 1:02X}" for ch in TEXT)
    for p in range(pages):
        img = Image.new("RGB", (300, 424), (250, 250, 245))
        for y in range(60, 380, 24):
            for x in range(30, 270): img.putpixel((x, y), (30, 30, 30))
        bio = io.BytesIO(); img.save(bio, "JPEG", quality=85)
        im = pdf.make_stream(bio.getvalue())
        im.Type = Name.XObject; im.Subtype = Name.Image; im.Width = 300; im.Height = 424; im.ColorSpace = Name.DeviceRGB; im.BitsPerComponent = 8; im.Filter = Name.DCTDecode
        page = pdf.add_blank_page(page_size=(595, 842))
        page.Resources = Dictionary(XObject=Dictionary(Im0=im), Font=Dictionary(F1=font))
        content = b"q 595 0 0 842 0 0 cm /Im0 Do Q\n"
        if text_layer: content += f"BT 3 Tr /F1 10 Tf 50 700 Td <{codes}> Tj ET\n".encode("ascii")
        page.Contents = pdf.make_stream(content)
    pdf.save(path)

def make_pdfa(src, dst, title="Hợp đồng thuê nhà", author="Nguyễn Văn An", producer="DocScanner", tool="DocScanner", created_ms=1_760_000_000_000, mod_ms=1_760_600_000_000, off_min=420):
    """Cùng các bước với PdfAConverter.convert: Info + XMP nhất quán, OutputIntent sRGB, bỏ JavaScript/AA, cờ chú thích, ID, phiên bản 1.7."""
    pdf = pikepdf.open(src)
    c_info, m_info, xmp = xmp_for(title, author, producer, tool, created_ms, mod_ms, off_min)
    pdf.docinfo = pdf.make_indirect(Dictionary(Title=String(title), Author=String(author), Producer=String(producer), Creator=String(tool), CreationDate=String(c_info), ModDate=String(m_info)))
    meta = pikepdf.Stream(pdf, xmp.encode("utf-8"))
    meta.Type = Name.Metadata; meta.Subtype = Name.XML
    pdf.Root.Metadata = pdf.make_indirect(meta)
    icc = pikepdf.Stream(pdf, icc_bytes()); icc.N = 3
    pdf.Root.OutputIntents = Array([pdf.make_indirect(Dictionary(Type=Name.OutputIntent, S=Name.GTS_PDFA1, OutputConditionIdentifier=String("sRGB IEC61966-2.1"), Info=String("sRGB IEC61966-2.1"), DestOutputProfile=pdf.make_indirect(icc)))])
    for key in ("/OpenAction", "/AA"):
        if key in pdf.Root:
            oa = pdf.Root[key]
            if key == "/AA" or (isinstance(oa, pikepdf.Dictionary) and "/S" in oa and str(oa.S) in ("/JavaScript", "/Launch")): del pdf.Root[key]
    if "/Names" in pdf.Root and "/JavaScript" in pdf.Root.Names: del pdf.Root.Names["/JavaScript"]
    for page in pdf.pages:
        for a in page.get("/Annots", []):
            f = int(a.get("/F", 0)); a.F = (f | 4) & ~2 & ~32
            if "/A" in a and "/S" in a.A and str(a.A.S) in ("/JavaScript", "/Launch", "/Sound", "/Movie", "/ResetForm", "/ImportData"): del a["/A"]
    pdf.save(dst, min_version="1.7", compress_streams=False, object_stream_mode=pikepdf.ObjectStreamMode.disable)
    return xmp

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "pdfa_sample.pdf"
    src = os.path.join(TMP, "scan.pdf"); build_scan_pdf(src); make_pdfa(src, out)
    print("ghi", out)
