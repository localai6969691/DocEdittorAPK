"""JSON / XML / Base64 export (phiên 22, mục 4.49.2): TextExporters.jsonFromParagraphs / xmlFromParagraphs / base64 (bản Java TextFormatsCheck.java).

Đọc lại bằng bộ đọc ĐỘC LẬP:
  1. JSON: json.loads (+ jq nếu có) trên 300 tài liệu ngẫu nhiên: dấu nháy, gạch chéo ngược, ký tự điều khiển 0x00-0x1F và 0x7F, xuống dòng,
     emoji (cặp thay thế), nửa cặp thay thế đơn độc (phải thành U+FFFD, không thành "?"), U+2028/2029, chữ Việt, đoạn dài, tài liệu không trang / trang không đoạn.
  2. XML: xml.etree + lxml (nghiêm ngặt) + xmllint: văn bản đọc lại = văn bản vào đã bỏ ký tự XML 1.0 cấm; CR được giữ (không bị đổi thành LF); thuộc tính title có
     nháy kép, xuống dòng, tab, &, <.
  3. Base64: Java = base64.b64encode của Python, mọi độ dài 0..200 (đủ ba số dư), các biên khối đệm 12 288 +-1/2, 1 MB ngẫu nhiên, độ dài dòng 76 và 0 (một dòng);
     `base64 -d` (coreutils) và b64decode giải lại đúng từng byte; mọi dòng đúng 76 ký tự trừ dòng cuối.
  4. Thử âm tính: bộ thoát JSON ngây thơ (không xử lý nửa cặp đơn độc / ký tự điều khiển) bị bắt; XML không đổi CR bị bắt.
Chạy: python3 text_formats_check.py   (cần java, lxml; jq / xmllint / base64 nếu có; ~1 phút)
"""
import base64, json, os, random, re, shutil, subprocess, sys, tempfile
from xml.etree import ElementTree as ET
from _common import OUT

HERE = os.path.dirname(os.path.abspath(__file__)); JAVA = os.path.join(HERE, "TextFormatsCheck.java")
ENV = dict(os.environ, LC_ALL="C.UTF-8")
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

def java(args, stdin=None, binary=False):
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", JAVA] + args, capture_output=True, input=stdin.encode("ascii") if isinstance(stdin, str) else stdin, env=ENV)
    if r.returncode != 0: raise RuntimeError(r.stderr.decode())
    return r.stdout if binary else r.stdout.decode("utf-8")

def units(s_units):                 # list of UTF-16 code units -> hex string
    return "".join(f"{u:04x}" for u in s_units)
def to_units(s):                    # str -> UTF-16 code units (lone surrogates allowed)
    b = s.encode("utf-16-le", "surrogatepass"); return [int.from_bytes(b[i:i + 2], "little") for i in range(0, len(b), 2)]
def from_units(us):                 # code units -> str, lone surrogates -> U+FFFD (what Java should write)
    return b"".join(u.to_bytes(2, "little") for u in us).decode("utf-16-le", "replace")
def from_units_raw(us):             # code units -> str KEEPING lone surrogates (XML must DROP them: they are not XML 1.0 characters)
    return b"".join(u.to_bytes(2, "little") for u in us).decode("utf-16-le", "surrogatepass")
def spec(title_units, pages):
    out = [units(title_units)]
    for page in pages:
        out.append("P")
        for para in page: out.append("T " + units(para))
    return "\n".join(out) + "\n=\n"

def batch(kind, documents):
    """one JVM run for many documents -> list of output texts"""
    res = java([kind], "".join(spec(t, p) for t, p in documents)).split("\u0001")
    assert res.pop() == "" and len(res) == len(documents), (len(res), len(documents))
    return res

rnd = random.Random(2202)
ALPHA = list("abcxyzABC 0123456789.,;:!?-_/()[]{}'\"\\\n\t\r") + [chr(c) for c in list(range(0, 32)) + [0x7F, 0x80, 0xA0, 0x2028, 0x2029, 0xFEFF, 0xFFFE, 0xFFFF]] \
        + list("ăâêôơưđĐáàảãạếềểễệ") + ["🙂", "𝒜", "😀", "中", "한", "ह", "ж"]
def rand_units():
    us = []
    for _ in range(rnd.choice([0, 1, 2, 5, 20, 60])):
        r = rnd.random()
        if r < 0.04: us.append(rnd.choice([0xD800, 0xDBFF, 0xDC00, 0xDFFF]))        # LONE surrogate
        else: us += to_units(rnd.choice(ALPHA))
    return us
docs = []
for _ in range(300):
    pages = [[rand_units() for _ in range(rnd.choice([0, 1, 3]))] for _ in range(rnd.choice([0, 1, 2, 4]))]
    docs.append((rand_units(), pages))
docs.append(([], [])); docs.append((to_units("x"), [[]])); docs.append((to_units("long"), [[to_units("Việt Nam " * 5000)]]))

# ---------- 1. JSON ----------
bad = []
for (title, pages), out in zip(docs, batch("json", docs)):
    try: d = json.loads(out)
    except Exception as e: bad.append(("parse", str(e))); continue
    want = {"title": from_units(title), "pageCount": len(pages), "pages": [{"page": i + 1, "paragraphs": [from_units(p) for p in pg]} for i, pg in enumerate(pages)]}
    if d != want: bad.append(("diff", out[:200]))
check(not bad, f"JSON: json.loads đọc lại đúng cấu trúc và từng ký tự trên {len(docs)} tài liệu (điều khiển, nháy, gạch chéo, emoji, nửa cặp đơn độc -> U+FFFD){'' if not bad else ' ' + str(bad[:2])}")
if shutil.which("jq"):
    sample = batch("json", [docs[5]])[0]; p = os.path.join(OUT, "tf_sample.json"); open(p, "w", encoding="utf-8").write(sample)
    check(subprocess.run(["jq", ".", p], capture_output=True).returncode == 0, "JSON: jq cũng đọc được")
out = batch("json", [(to_units("a\u2028b"), [[to_units("\u2028\u2029")]])])[0]
check("\u2028" in out and json.loads(out)["title"] == "a\u2028b", "JSON: U+2028 / U+2029 giữ nguyên (hợp lệ trong JSON)")
check(json.loads(batch("json", [(to_units("\ud800x"), [])])[0])["title"] == "\ufffdx", "JSON: nửa cặp thay thế đơn độc thành U+FFFD, không thành '?'")

# ---------- 2. XML ----------
def xml_ok(cp): return cp in (9, 10, 13) or 0x20 <= cp <= 0xD7FF or 0xE000 <= cp <= 0xFFFD or 0x10000 <= cp <= 0x10FFFF
def xml_clean(s): return "".join(ch for ch in s if xml_ok(ord(ch)))
bad = []; lx = None
try:
    from lxml import etree as lx
except ImportError: pass
for (title, pages), out in zip(docs, batch("xml", docs)):
    try: root = ET.fromstring(out.encode("utf-8"))
    except Exception as e: bad.append(("parse", str(e), out[:120])); continue
    got = [[p.text or "" for p in pg.findall("paragraph")] for pg in root.findall("page")]
    want = [[xml_clean(from_units_raw(p)) for p in pg] for pg in pages]
    if got != want or root.get("title") != xml_clean(from_units_raw(title)) or root.get("pages") != str(len(pages)): bad.append(("diff", out[:160], got[:1], want[:1]))
    if lx is not None:
        try: lx.fromstring(out.encode("utf-8"), lx.XMLParser(resolve_entities=False))
        except Exception as e: bad.append(("lxml", str(e)))
check(not bad, f"XML: xml.etree{' + lxml' if lx else ''} đọc lại đúng văn bản (đã bỏ ký tự XML 1.0 cấm, GIỮ CR) và thuộc tính title trên {len(docs)} tài liệu{'' if not bad else ' ' + str(bad[:2])}")
t = to_units('Tên "kép"\n<&>\tvà\r')
out = batch("xml", [(t, [[to_units("a\r\nb\rc")]])])[0]
root = ET.fromstring(out.encode()); check(root.get("title") == 'Tên "kép"\n<&>\tvà\r' and root.find("page/paragraph").text == "a\r\nb\rc", "XML: nháy kép, xuống dòng, tab, &, <, CR trong thuộc tính và văn bản đọc lại đúng")
if shutil.which("xmllint"):
    p = os.path.join(OUT, "tf_sample.xml"); open(p, "w", encoding="utf-8").write(out)
    check(subprocess.run(["xmllint", "--noout", p], capture_output=True).returncode == 0, "XML: xmllint --noout sạch")

# ---------- 3. Base64 ----------
work = tempfile.mkdtemp(prefix="tf_", dir=OUT)
sizes = list(range(0, 201)) + [12285, 12286, 12287, 12288, 12289, 12290, 24575, 24576, 24577, 1_000_000]
bad = []; wrapbad = 0
datas = {}; paths = []
for n in sizes:
    p = os.path.join(work, f"f{n}.bin"); datas[n] = os.urandom(n); open(p, "wb").write(datas[n]); paths.append(p)
for ll in (76, 0):
    encs = java(["b64multi", str(ll)] + paths, binary=True).split(b"\x01"); assert encs.pop() == b"" and len(encs) == len(sizes)
    for n, enc in zip(sizes, encs):
        data = datas[n]; ref = base64.b64encode(data)
        if ll == 0:
            ok = enc == ref
        else:
            lines = enc.split(b"\n")
            ok = enc.replace(b"\n", b"") == ref and ((n == 0 and enc == b"") or enc.endswith(b"\n")) and all(len(l) == 76 for l in lines[:-2])
            wrapbad += 0 if all(len(l) <= 76 for l in lines) else 1
        if not ok: bad.append((n, ll))
        elif base64.b64decode(enc) != data: bad.append((n, ll, "decode"))
check(not bad and wrapbad == 0, f"Base64: Java = base64.b64encode trên {len(sizes)} kích thước x 2 độ dài dòng (mọi số dư, biên khối đệm, 1 MB); giải lại đúng từng byte")
if shutil.which("base64"):
    p = os.path.join(work, "f1000000.bin"); enc = java(["b64", "76", p], binary=True)
    r = subprocess.run(["base64", "-d"], input=enc, capture_output=True)
    check(r.returncode == 0 and r.stdout == open(p, "rb").read(), "Base64: `base64 -d` (coreutils) giải lại đúng 1 MB")
check(java(["b64", "76", os.path.join(work, "f0.bin")], binary=True) == b"", "Base64: tệp rỗng -> đầu ra rỗng")

# ---------- 4. thử âm tính ----------
def naive_json_string(s): return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'
try: json.loads(naive_json_string("a\nb")); naive_catches = False
except Exception: naive_catches = True
check(naive_catches, "ÂM TÍNH: bộ thoát JSON ngây thơ (thiếu ký tự điều khiển) cho JSON KHÔNG hợp lệ -> bài kiểm có răng")
try: ET.fromstring('<a t="x\ry"/>'.encode()).get("t") == "x\ry"; bad_cr = ET.fromstring('<a t="x\ry"/>'.encode()).get("t") != "x\ry"
except Exception: bad_cr = True
check(bad_cr, "ÂM TÍNH: CR để nguyên trong thuộc tính bị đọc lại thành dấu cách (nên mã dùng &#13;)")

print(); print("TAT CA DAT" if not fails else f"{len(fails)} LOI: {fails}")
sys.exit(1 if fails else 0)
