#!/usr/bin/env python3
"""Xuất văn bản ra RTF, LaTeX và OpenDocument (.odt) CHẠY THẬT (`TextExporters.rtf` / `latex`, `OdtWriter`; phiên 24, TECHNICAL_DOCS.md 4.65; PDF 10.4, 10.5, 10.8).

Mã Kotlin THẬT (qua `real_run/toolchain.py`) viết ba tệp từ cùng một tài liệu mẫu; mỗi tệp được ĐỌC LẠI bằng công cụ không chung mã với nó và so với văn bản đã đưa vào:
  - RTF: `pandoc -f rtf` và LibreOffice (`soffice --convert-to txt`): đủ chữ Việt có dấu, tiếng Nhật, tiếng Ả Rập, emoji (cặp thay thế UTF-16), `\\ { } $ & # ^ _ % ~`;
  - ODT: `odfpy` (đọc tệp), `pandoc -f odt`, LibreOffice đổi sang PDF rồi `pdftotext`; cấu trúc gói: `mimetype` là mục ĐẦU, KHÔNG nén, đúng nội dung, manifest liệt kê đủ các phần, nhiều dấu cách liền và tab giữ nguyên;
  - LaTeX: biên dịch bằng XeLaTeX rồi `pdftotext`: chuỗi từ trong PDF = chuỗi từ đã đưa vào (kể cả `--`, `''`, `_`, `%`, `\\`, `~`, `^`), số trang PDF >= số trang đầu vào. Chỉ chữ Latin / Việt (phông mặc định không có chữ Nhật / Ả Rập: giới hạn đã ghi trong tệp .tex).
  - THỬ ÂM TÍNH: 8 bản Kotlin hỏng (không thoát `{`, không tách cặp thay thế, quên `\\u`, không thoát `_`, để `--` thành gạch nối dài, nén `mimetype`, bỏ `text:s`, bỏ ngắt trang) PHẢI bị bắt (`--fast` bỏ; `--mutant=N` chạy một bản).
KHÔNG kiểm được: Word thật / Pages thật (chỉ pandoc và LibreOffice), phông tiếng Nhật / Ả Rập trong LaTeX, màn chọn định dạng trên máy. Cần: java 17+, git, unzip, github.com, pandoc, LibreOffice, xelatex, pdftotext, odfpy.
Chạy: python3 tools/verify/text_formats_check.py [--fast] [--mutant=N]"""
import os, re, shutil, subprocess, sys, tempfile, zipfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)
tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="textfmt-")
FILES = ["TextExporters.kt", "OdtWriter.kt", "DocxWriter.kt"]; HARNESS = os.path.join(HERE, "real_run", "TextFormatsHarness.kt"); STUBS = os.path.join(HERE, "real_run", "UtilStubs.kt")
def build(mutate=None, tag="base"): return tc.compile(FILES, [HARNESS, STUBS], os.path.join(WORK, "cls-" + tag), mutate)[0]
def sh(*c, **k): return subprocess.run(c, capture_output=True, text=True, **k)

TITLE = "Báo cáo \"Tổng kết\" & kế hoạch 2026_v2"
LATIN = [  # one paragraph per block, each ends with a full stop so that DocxWriter.paragraphsFromText keeps blocks as they are
    ["Nguyễn Văn Ánh đã đến Hà Nội ngày 5/1 và gặp bà Trần Thị Phượng.", "Đường dẫn C:\\Users\\An\\file_01.txt, thư mục ~/docs, ghi chú #1 và 50% giảm giá.", "Công thức: a^2 + b_1 = {c} & $d$ -- hết."],
    ["Câu nói: ''xin chào'' và `lệnh` khác; năm 2026-11-14 -- --- dấu gạch.", "Chữ hoa ĐẶC BIỆT: Ơ Ư Đ Ă Â Ê Ô, chữ thường: ơ ư đ ă â ê ô ạ ặ ỉ ỵ ỹ."],
    ["Một trang chỉ có một đoạn văn thật dài " + "lặp lại nhiều lần để tràn dòng " * 30 + "kết thúc."],
]
UNICODE = LATIN + [["日本語のテキスト：こんにちは世界。", "مرحبا بالعالم. نص عربي للاختبار.", "Emoji: 😀 và 🎉 cùng ký tự hiếm 𠮷.", "Dấu cách  kép và\tdấu tab trong câu này.", "  Dòng bắt đầu bằng dấu cách và kết thúc bằng dấu cách.  "]]
def doc_text(pages): return "\n=====PAGE=====\n".join("\n\n".join(p) for p in pages)
def expected_paragraphs(pages):
    out = [TITLE]
    for i, p in enumerate(pages, 1): out += [f"Trang {i}"] + [x.strip() for x in p]
    return out
def write_inputs(pages, tag):
    t, p = os.path.join(WORK, tag + "-title.txt"), os.path.join(WORK, tag + "-pages.txt")
    open(t, "w", encoding="utf-8").write(TITLE); open(p, "w", encoding="utf-8").write(doc_text(pages)); return t, p
def make(cls, kind, pages, tag):
    t, p = write_inputs(pages, tag); out = os.path.join(WORK, f"{tag}.{kind}")
    r = tc.run(cls, "TextFormatsHarnessKt", [kind, t, p, out])
    if r.returncode or "ok" not in r.stdout: raise SystemExit("harness crashed: " + r.stderr[-600:])
    return out
norm = lambda s: re.sub(r"\s+", " ", s).strip()
def words(s): return norm(s).split(" ")
def worddiff(got, want):
    """first places where the two word lists differ (for the failure message)"""
    out = [(g, w) for g, w in zip(got, want) if g != w][:4]
    return out or (f"độ dài {len(got)} != {len(want)}" if len(got) != len(want) else None)

def pandoc_plain(path, fmt):
    r = sh("pandoc", "-f", fmt, "-t", "plain", "--wrap=none", path); return r.stdout, r.returncode
def soffice_txt(path):
    d = tempfile.mkdtemp(dir=WORK); r = sh("soffice", "--headless", "--convert-to", "txt:Text (encoded):UTF8", "--outdir", d, path, env={**os.environ, "HOME": WORK})
    f = [x for x in os.listdir(d) if x.endswith(".txt")]; return open(os.path.join(d, f[0]), encoding="utf-8", errors="replace").read().lstrip("\ufeff") if f else ""

def verify_rtf(cls_tag, cls, pages, label):
    path = make(cls, "rtf", pages, cls_tag); exp = expected_paragraphs(pages); expected_words = words(" ".join(exp))
    res = []
    txt, rc = pandoc_plain(path, "rtf")
    # pandoc 3.1.3 does not join the two UTF-16 halves of a character above U+FFFF (it shows two replacement characters); LibreOffice must read them back exactly
    exp_pandoc = [re.sub("[\U00010000-\U0010ffff]", "\ufffd\ufffd", w) for w in expected_words]
    if rc == 0: res.append(("pandoc (ký tự ngoài BMP = hai đơn vị)", words(txt) == exp_pandoc, worddiff(words(txt), exp_pandoc)))
    lo = words(soffice_txt(path)); res.append(("LibreOffice", lo == expected_words, worddiff(lo, expected_words)))
    return res, expected_words

def verify_odt(cls_tag, cls, pages, label):
    path = make(cls, "odt", pages, cls_tag); exp = expected_paragraphs(pages); expected_words = words(" ".join(exp)); res = []
    with zipfile.ZipFile(path) as z:
        names = z.namelist(); info = z.infolist()[0]
        struct = names[0] == "mimetype" and info.compress_type == zipfile.ZIP_STORED and z.read("mimetype") == b"application/vnd.oasis.opendocument.text" and not info.extra
        manifest = z.read("META-INF/manifest.xml").decode()
        struct = struct and all(f'full-path="{n}"' in manifest for n in ("content.xml", "styles.xml", "meta.xml"))
    res.append(("cấu trúc gói", struct, None))
    from odf.opendocument import load; from odf import teletype, text as odftext
    doc = load(path); items = [teletype.extractText(e) for e in doc.getElementsByType(odftext.H) + doc.getElementsByType(odftext.P)]
    # document order: headings and paragraphs interleaved, so read them in order from the body
    body = doc.text; seq = []
    for node in body.childNodes:
        if hasattr(node, "qname") and node.qname[1] in ("h", "p"): seq.append(teletype.extractText(node))
    res.append(("odfpy (từng đoạn, giữ nguyên dấu cách)", seq == exp, seq[:8]))
    txt, rc = pandoc_plain(path, "odt"); res.append(("pandoc", rc == 0 and words(txt) == expected_words, None))
    lo_text = soffice_txt(path); res.append(("LibreOffice", words(lo_text) == expected_words, worddiff(words(lo_text), expected_words)))
    probe = "Dấu cách  kép và\tdấu tab trong câu này."
    if any(probe in p for page in pages for p in page):   # odfpy reads the raw XML (two spaces survive there even without <text:s>); LibreOffice is the reader that COLLAPSES them
        res.append(("LibreOffice giữ nguyên dấu cách kép và Tab", probe in lo_text, repr(lo_text[lo_text.find("Dấu cách"):][:50])))
    d = tempfile.mkdtemp(dir=WORK); r = sh("soffice", "--headless", "--convert-to", "pdf", "--outdir", d, path, env={**os.environ, "HOME": WORK})
    pdfs = [x for x in os.listdir(d) if x.endswith(".pdf")]
    last = f"Trang {len(pages)}"
    ok_pdf = bool(pdfs) and last in sh("pdftotext", os.path.join(d, pdfs[0]), "-").stdout
    res.append((f"LibreOffice -> PDF (có '{last}')", ok_pdf, None))
    if pdfs and len(pages) > 1:
        npdf = int(re.search(r"Pages:\s+(\d+)", sh("pdfinfo", os.path.join(d, pdfs[0])).stdout).group(1))
        res.append((f"ngắt trang: PDF có {npdf} trang >= {len(pages)} trang đầu vào", npdf >= len(pages), None))
    return res, exp

def verify_tex(cls_tag, cls, pages, label):
    path = make(cls, "tex", pages, cls_tag); d = tempfile.mkdtemp(dir=WORK); shutil.copy(path, d)
    r = sh("xelatex", "-interaction=nonstopmode", "-halt-on-error", "-output-directory", d, os.path.join(d, os.path.basename(path)))
    pdf = os.path.join(d, os.path.basename(path)[:-4] + ".pdf")
    if r.returncode or not os.path.exists(pdf): return [("XeLaTeX biên dịch", False, r.stdout[-700:])], None
    txt = sh("pdftotext", pdf, "-").stdout; got = words(txt); want = words(" ".join(expected_paragraphs(pages)))
    npages = int(re.search(r"Pages:\s+(\d+)", sh("pdfinfo", pdf).stdout).group(1))
    return [("XeLaTeX biên dịch được", True, None), ("chuỗi từ trong PDF = chuỗi từ đưa vào", got == want, [(a, b) for a, b in zip(got, want) if a != b][:4]), (f"số trang PDF {npages} >= số trang vào {len(pages)}", npages >= len(pages), None)], want

def report(kind, res, label):
    for name, ok, detail in res: check(ok, f"{kind} ({label}): {name}" + ("" if ok else f"  {str(detail)[:300]}"))

print("== B. chạy thật"); cls = build()
for tag, pages, label in (("uni", UNICODE, "Việt + Nhật + Ả Rập + emoji + ký tự đặc biệt"), ("one", [["Chỉ một đoạn ngắn."]], "một trang một đoạn")):
    report("RTF", verify_rtf("rtf-" + tag, cls, pages, label)[0], label)
    report("ODT", verify_odt("odt-" + tag, cls, pages, label)[0], label)
report("LaTeX", verify_tex("tex-lat", cls, LATIN, "Việt + ký tự đặc biệt")[0], "Việt + ký tự đặc biệt")
report("LaTeX", verify_tex("tex-one", cls, [["Chỉ một đoạn ngắn."]], "một trang")[0], "một trang")
# the \u escapes: signed 16-bit values and surrogate pair of an emoji, checked against an independent computation
rtf = open(make(cls, "rtf", [["Đ😀."]], "esc"), encoding="utf-8").read()
check("\\u272 ?" in rtf and "\\u-10179 ?\\u-8704 ?" in rtf, "RTF: 'Đ' = \\u272, emoji U+1F600 = cặp thay thế \\u-10179 \\u-8704, mỗi mã có dấu cách rồi dấu ? (tính độc lập: 0xD83D, 0xDE00 - 65536)")
tex = open(make(cls, "tex", [["a_b 50% {x} -- ''y'' ~ ^ $ & #."]], "esc2"), encoding="utf-8").read()
check(r"a\_b 50\% \{x\} -{}-{} \textquotesingle{}\textquotesingle{}y\textquotesingle{}\textquotesingle{} \textasciitilde{} \textasciicircum{} \$ \& \#." in tex, "LaTeX: mọi ký tự đặc biệt được thoát; '--' không thành gạch dài, dấu nháy thẳng ' và \" ở lại dấu nháy THẲNG (không thành ’ ” )")
check(tex.startswith("% !TeX program = xelatex") and "\\setmainfont" in tex, "LaTeX: dòng đầu chọn XeLaTeX, có gợi ý \\setmainfont cho chữ không phải Latin")

if "--fast" in sys.argv and not any(a.startswith("--mutant=") for a in sys.argv): print("== C. bỏ qua thử âm tính (--fast)")
else:
    print("== C. thử âm tính")
    ONLY = next((int(a.split("=")[1]) for a in sys.argv if a.startswith("--mutant=")), None)
    MUT = [("RTF không thoát '{'", "TextExporters.kt", ('ch == \'{\' -> sb.append("\\\\{")', 'ch == \'{\' -> sb.append("{")'), "rtf", UNICODE),
           ("RTF không tách cặp thay thế (cộng sai)", "TextExporters.kt", ("if (code > 32767) code - 65536 else code", "code"), "rtf", UNICODE),
           ("RTF bỏ dấu cách sau mã \\u (dạng pandoc đọc sai)", "TextExporters.kt", ('.append(" ?")', ".append('?')"), "rtf", UNICODE),
           ("RTF quên \\u (chữ có dấu thành '?')", "TextExporters.kt", ('sb.append("\\\\u").append(if (code > 32767) code - 65536 else code).append(" ?")', "sb.append('?')"), "rtf", UNICODE),
           ("LaTeX không thoát '_'", "TextExporters.kt", ("'_' -> sb.append(\"\\\\_\")", "'_' -> sb.append(\"_\")"), "tex", LATIN),
           ("LaTeX để '--' thành gạch dài", "TextExporters.kt", ("'-' -> sb.append(\"-{}\")", "'-' -> sb.append(\"-\")"), "tex", LATIN),
           ("ODT nén mimetype", "OdtWriter.kt", ("first.method = ZipEntry.STORED", "first.method = ZipEntry.DEFLATED"), "odt", UNICODE),
           ("ODT bỏ text:s (dấu cách kép biến mất)", "OdtWriter.kt", ("if (!text.contains(\"  \")", "if (true || !text.contains(\"  \")"), "odt", UNICODE),
           ("ODT bỏ ngắt trang", "OdtWriter.kt", ('<style:paragraph-properties fo:break-before=\\"page\\"/>', '<style:paragraph-properties/>'), "odt", UNICODE)]
    for number, (name, fname, (old, new), kind, pages) in enumerate(MUT, 1):
        if ONLY is not None and number != ONLY: continue
        try: mcls = build({fname: (old, new)}, tag="mut")
        except RuntimeError as exc: check("mutation target not found" not in str(exc), f"ÂM TÍNH '{name}': bản hỏng không biên dịch (bị bắt)"); continue
        fn = {"rtf": verify_rtf, "tex": verify_tex, "odt": verify_odt}[kind]
        try: res, _ = fn("m", mcls, pages, "m")
        except (Exception, SystemExit) as exc: res = [("ghi tệp thất bại / đọc lại lỗi", False, str(exc)[:120])]   # a mutant that crashes the writer is caught too
        if kind == "rtf":   # LibreOffice and pandoc ACCEPT an unsigned \u above 32767, the standard asks for a signed one: check the escape itself as well
            rtf = open(make(mcls, "rtf", [["Đ😀."]], "m-esc"), encoding="utf-8").read()
            res.append(("dạng mã \\u theo chuẩn (có dấu, cặp thay thế)", "\\u272 ?" in rtf and "\\u-10179 ?\\u-8704 ?" in rtf, rtf[-120:]))
        check(any(not ok for _, ok, _ in res), f"ÂM TÍNH '{name}': bản hỏng bị bắt ({[n for n, ok, _ in res if not ok][:2]})")
shutil.rmtree(WORK, ignore_errors=True); print("\nTAT CA DAT" if not fails else f"\n{len(fails)} LOI"); sys.exit(1 if fails else 0)
