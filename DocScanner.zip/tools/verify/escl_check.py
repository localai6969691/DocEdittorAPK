"""Kiểm chứng eSCL (phiên 17): EsclProtocol + EsclClient (EsclCheck.java là bản Java chạy được) với MÁY QUÉT GIẢ viết bằng Python.

Máy quét giả nói đúng giao thức (ScannerCapabilities, ScanJobs, NextDocument, DELETE) và mô phỏng thói quen thật của thiết bị: 503 khi khởi động, 503 giữa các trang,
Location tuyệt đối / tương đối / đường dẫn KHÔNG theo sách giáo khoa, không có Location, luôn bận, 404 ngay. Mỗi ca kiểm: trang nhận về đúng từng byte, đúng thứ tự yêu cầu
ghi lại ở máy chủ, ScanSettings gửi đi (phân tích bằng lxml) đúng nguồn / độ phân giải / vùng quét, và công việc luôn được DELETE.
Cùng kiểm: ba kiểu XML năng lực (tiền tố HP, không gian tên mặc định kiểu Canon, có khay giấy), chọn độ phân giải gần nhất, `baseUrl` (nhập tay), `resolveLocation`,
và RÀO CHẮN RIÊNG TƯ: địa chỉ công cộng bị từ chối TRƯỚC khi kết nối - cả khi máy quét giả (hoặc kẻ giả mạo) chỉ Location sang địa chỉ công cộng.
THỬ ÂM TÍNH: một máy khách "tự ghép" đường dẫn công việc thay vì dùng Location nguyên văn thất bại với máy quét dùng đường dẫn riêng.
Chạy: python3 escl_check.py   (cần java 11+, lxml)
"""
import http.server, os, re, socketserver, subprocess, sys, threading, urllib.error, urllib.request
from lxml import etree
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
HERE = os.path.dirname(os.path.abspath(__file__))
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
    return cond
NS = {"scan": "http://schemas.hp.com/imaging/escl/2011/05/03", "pwg": "http://www.pwg.org/schemas/2010/12/sm"}
HEXB = lambda s: s.encode("utf-8").hex()
def java(*args): return subprocess.run(["java", os.path.join(HERE, "EsclCheck.java"), *map(str, args)], capture_output=True, text=True, check=True).stdout.strip("\n").split("\n")

CAPS_HP = """<?xml version="1.0" encoding="UTF-8"?>
<scan:ScannerCapabilities xmlns:pwg="http://www.pwg.org/schemas/2010/12/sm" xmlns:scan="http://schemas.hp.com/imaging/escl/2011/05/03">
<pwg:Version>2.63</pwg:Version><pwg:MakeAndModel>HP LaserJet MFP M28w</pwg:MakeAndModel>
<scan:Platen><scan:PlatenInputCaps><scan:MinWidth>16</scan:MinWidth><scan:MaxWidth>2550</scan:MaxWidth><scan:MinHeight>16</scan:MinHeight><scan:MaxHeight>3507</scan:MaxHeight>
<scan:SettingProfiles><scan:SettingProfile><scan:ColorModes><scan:ColorMode>RGB24</scan:ColorMode></scan:ColorModes>
<scan:DocumentFormats><pwg:DocumentFormat>application/pdf</pwg:DocumentFormat><pwg:DocumentFormat>image/jpeg</pwg:DocumentFormat></scan:DocumentFormats>
<scan:SupportedResolutions><scan:DiscreteResolutions>
<scan:DiscreteResolution><scan:XResolution>75</scan:XResolution><scan:YResolution>75</scan:YResolution></scan:DiscreteResolution>
<scan:DiscreteResolution><scan:XResolution>150</scan:XResolution><scan:YResolution>150</scan:YResolution></scan:DiscreteResolution>
<scan:DiscreteResolution><scan:XResolution>300</scan:XResolution><scan:YResolution>300</scan:YResolution></scan:DiscreteResolution>
<scan:DiscreteResolution><scan:XResolution>600</scan:XResolution><scan:YResolution>600</scan:YResolution></scan:DiscreteResolution>
</scan:DiscreteResolutions></scan:SupportedResolutions></scan:SettingProfile></scan:SettingProfiles></scan:PlatenInputCaps></scan:Platen>
<scan:Adf><scan:AdfSimplexInputCaps><scan:MaxWidth>2480</scan:MaxWidth><scan:MaxHeight>4200</scan:MaxHeight></scan:AdfSimplexInputCaps></scan:Adf>
</scan:ScannerCapabilities>"""
CAPS_CANON = """<?xml version="1.0" encoding="UTF-8"?>
<ScannerCapabilities xmlns="http://schemas.hp.com/imaging/escl/2011/05/03" xmlns:pwg="http://www.pwg.org/schemas/2010/12/sm">
<pwg:Version>2.1</pwg:Version><pwg:MakeAndModel>Canon TR4500 series</pwg:MakeAndModel>
<Platen><PlatenInputCaps><MaxWidth>2550</MaxWidth><MaxHeight>3507</MaxHeight><SettingProfiles><SettingProfile>
<DocumentFormats><pwg:DocumentFormat>image/jpeg</pwg:DocumentFormat></DocumentFormats>
<SupportedResolutions><DiscreteResolutions><DiscreteResolution><XResolution>100</XResolution><YResolution>100</YResolution></DiscreteResolution>
<DiscreteResolution><XResolution>200</XResolution><YResolution>200</YResolution></DiscreteResolution></DiscreteResolutions></SupportedResolutions>
</SettingProfile></SettingProfiles></PlatenInputCaps></Platen></ScannerCapabilities>"""
CAPS_ADF_ONLY = CAPS_HP.replace("<scan:Platen>", "<scan:Gone>").replace("</scan:Platen>", "</scan:Gone>")

print("== A. phần thuần ==")
cases = [
    ("base\t192.168.1.50", "http://192.168.1.50:80/eSCL"), ("base\t192.168.1.50:8080", "http://192.168.1.50:8080/eSCL"), ("base\thttp://printer.local", "http://printer.local:80/eSCL"),
    ("base\thttp://10.0.0.7:443/eSCL/", "http://10.0.0.7:443/eSCL"), ("base\t10.0.0.7/scanner", "http://10.0.0.7:80/scanner"), ("base\t[fe80::1]:8080", "http://[fe80::1]:8080/eSCL"),
    ("base\t", "NULL"), ("base\thost with space", "NULL"), ("base\thttps://x.local", "NULL"), ("base\t192.168.1.1:99999", "NULL"), ("base\tbad_host!", "NULL"), ("base\t192.168.1.1:abc", "NULL"),
    ("loc\thttp://10.0.0.7:80/eSCL/ScanJobs\thttp://10.0.0.7:80/eSCL/ScanJobs/abc", "http://10.0.0.7:80/eSCL/ScanJobs/abc"),
    ("loc\thttp://10.0.0.7:80/eSCL/ScanJobs\t/eSCL/ScanJobs/abc/", "http://10.0.0.7:80/eSCL/ScanJobs/abc"),
    ("loc\thttp://10.0.0.7:80/eSCL/ScanJobs\tabc", "http://10.0.0.7:80/eSCL/abc"),
    ("loc\thttp://10.0.0.7:80/eSCL/ScanJobs\thttp://10.0.0.7:8080/custom/job9", "http://10.0.0.7:8080/custom/job9"),
    ("loc\thttp://10.0.0.7:80/eSCL/ScanJobs\t<null>", "NULL"), ("loc\thttp://10.0.0.7:80/eSCL/ScanJobs\t   ", "NULL"),
]
PRIV = [("10.1.2.3", True), ("172.16.0.1", True), ("172.31.255.255", True), ("172.32.0.1", False), ("172.15.0.1", False), ("192.168.0.1", True), ("192.169.0.1", False), ("169.254.1.1", True),
        ("127.0.0.1", True), ("8.8.8.8", False), ("1.2.3.4", False), ("100.64.0.1", False), ("::1", True), ("fe80::1", True), ("fd12:3456::1", True), ("fc00::1", True), ("fe00::1", False),
        ("2001:4860:4860::8888", False), ("0.0.0.0", False)]
f = os.path.join(OUT, "escl_pure.txt")
lines = [c[0] for c in cases] + [f"priv\t{ip}" for ip, _ in PRIV] + [f"caps\t{HEXB(CAPS_HP)}", f"caps\t{HEXB(CAPS_CANON)}", f"caps\t{HEXB(CAPS_ADF_ONLY)}"]
lines += [f"fit\t{HEXB(CAPS_HP)}\tPlaten\tRGB24\t200", f"fit\t{HEXB(CAPS_HP)}\tPlaten\tRGB24\t250", f"fit\t{HEXB(CAPS_HP)}\tFeeder\tGrayscale8\t300", f"fit\t{HEXB(CAPS_CANON)}\tFeeder\tRGB24\t300", f"fit\t{HEXB(CAPS_ADF_ONLY)}\tPlaten\tRGB24\t300", f"fit\t{HEXB(CAPS_HP)}\tPlaten\tRGB24\t5000"]
lines += ["xml\tPlaten\tRGB24\t300\timage/jpeg\t2480\t3508"]
open(f, "w", encoding="utf-8").write("\n".join(lines) + "\n")
out = java("pure", f); k = 0
for (cmd, exp) in cases: check(out[k] == exp, f"{cmd.split(chr(9))[0]} {cmd.split(chr(9))[1][:40]!r} -> {out[k]}"); k += 1
for ip, exp in PRIV: check(out[k] == str(exp).lower(), f"địa chỉ {ip}: {'nội bộ' if exp else 'công cộng'}"); k += 1
check(out[k] == "HP LaserJet MFP M28w|[75, 150, 300, 600]|true|true|[application/pdf, image/jpeg]|2550x3507|2480x4200", f"năng lực HP (tiền tố): {out[k]}"); k += 1
check(out[k] == "Canon TR4500 series|[100, 200]|true|false|[image/jpeg]|2550x3507|2480x3508", f"năng lực Canon (không gian tên mặc định): {out[k]}"); k += 1
check(out[k] == "HP LaserJet MFP M28w|[75, 150, 300, 600]|false|true|[application/pdf, image/jpeg]|2480x3508|2480x4200", f"chỉ có khay giấy: {out[k]}"); k += 1
for exp, what in (("Platen|150|image/jpeg|2480|3507", "200 dpi -> 150 (gần nhất)"), ("Platen|300|image/jpeg|2480|3507", "250 dpi -> 300 (gần 300 hơn 150)"), ("Feeder|300|image/jpeg|2480|3508", "xin khay giấy: máy có -> khay giấy, vùng lấy theo KHAY (2480x4200 -> A4 3508), không lấy số của kính"),
                  ("Platen|200|image/jpeg|2480|3507", "Canon không có khay: xin Feeder nhận Platen, 300 -> 200"), ("Feeder|300|image/jpeg|2480|3508", "máy chỉ có khay: xin Platen nhận Feeder, vùng theo khay (2480x4200 -> A4 3508)"), ("Platen|600|image/jpeg|2480|3507", "5000 dpi -> 600")):
    check(out[k] == exp, f"fit: {what}: {out[k]}"); k += 1
xml = out[k].replace("\\n", "\n")
root = etree.fromstring(xml.encode("utf-8"))
g = lambda q: root.xpath(q, namespaces=NS)
check(g("string(/scan:ScanSettings/pwg:Version)") == "2.0" and g("string(//pwg:InputSource)") == "Platen" and g("string(//scan:ColorMode)") == "RGB24" and g("string(//scan:XResolution)") == "300" and g("string(//scan:YResolution)") == "300"
      and g("string(//pwg:DocumentFormat)") == "image/jpeg" and g("string(//pwg:Width)") == "2480" and g("string(//pwg:Height)") == "3508" and g("string(//pwg:ContentRegionUnits)") == "escl:ThreeHundredthsOfInches", "ScanSettings: phiên bản, nguồn, màu, độ phân giải, định dạng, vùng quét đúng")
check([e.tag.split("}")[1] for e in root] == ["Version", "ScanRegions", "InputSource", "ColorMode", "XResolution", "YResolution", "DocumentFormat"], "thứ tự phần tử như các máy khách thật (SANE airscan, Apple, Windows)")

print("== B. máy quét giả ==")
JPEG = lambda tag: b"\xff\xd8\xff\xe0" + tag.encode() * 500 + b"\xff\xd9"
class Scanner:
    def __init__(self, caps=CAPS_HP, location="abs", pages=1, warmup=2, between=0, post_code=201, never_ready=False, first_404=False, evil_location=False, base_path="/eSCL", duplex_limit=None):
        self.caps, self.location, self.pages, self.warmup, self.between, self.post_code, self.never_ready, self.first_404, self.evil, self.base_path = caps, location, pages, warmup, between, post_code, never_ready, first_404, evil_location, base_path
        self.duplex_limit = duplex_limit
        self.log = []; self.job_path = None; self.posted = None; self.served = 0; self.polls = 0; self.sent503 = 0; self.between_left = 0
        outer = self
        class H(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a): pass
            def _send(self, code, body=b"", headers=None):
                self.send_response(code)
                for k, v in (headers or {}).items(): self.send_header(k, v)
                self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
            def do_GET(self):
                outer.log.append(("GET", self.path))
                if self.path == outer.base_path + "/ScannerCapabilities": return self._send(200, outer.caps.encode(), {"Content-Type": "text/xml"})
                if self.path.endswith("/NextDocument"):
                    if outer.job_path is None or self.path != outer.job_path + "/NextDocument": return self._send(404)   # chỉ phục vụ đúng đường dẫn công việc đã phát ra
                    outer.polls += 1
                    if outer.never_ready: outer.sent503 += 1; return self._send(503)
                    if outer.first_404: return self._send(404)
                    if outer.served == 0 and outer.sent503 < outer.warmup: outer.sent503 += 1; return self._send(503)
                    if outer.served > 0 and outer.served < outer.pages and outer.between_left < outer.between: outer.between_left += 1; return self._send(503)
                    if outer.served < outer.pages:
                        outer.served += 1; outer.between_left = 0; return self._send(200, JPEG(f"P{outer.served}"), {"Content-Type": "image/jpeg"})
                    return self._send(404)
                self._send(404)
            def do_POST(self):
                n = int(self.headers.get("Content-Length", 0)); outer.posted = (self.headers.get("Content-Type"), self.rfile.read(n)); outer.log.append(("POST", self.path))
                if outer.post_code == 503: return self._send(503)
                if outer.duplex_limit and b"<scan:Duplex>true</scan:Duplex>" in outer.posted[1]:
                    h = int(re.search(rb"<pwg:Height>(\d+)</pwg:Height>", outer.posted[1]).group(1))
                    if h > outer.duplex_limit: return self._send(409)   # như máy Epson thật: vùng quét hai mặt vượt giới hạn hai mặt
                port = self.server.server_address[1]
                if outer.evil: loc = "http://8.8.8.8/eSCL/ScanJobs/x"
                elif outer.location == "abs": loc = f"http://127.0.0.1:{port}{outer.base_path}/ScanJobs/job1"
                elif outer.location == "rel": loc = f"{outer.base_path}/ScanJobs/job2/"
                elif outer.location == "weird": loc = f"http://127.0.0.1:{port}/custom/path/job9"
                else: loc = None
                if loc and not outer.evil: outer.job_path = "/" + loc.split("://", 1)[-1].split("/", 1)[-1].rstrip("/") if "://" in loc else loc.rstrip("/")
                self._send(outer.post_code, b"", {"Location": loc} if loc else {})
            def do_DELETE(self): outer.log.append(("DELETE", self.path)); self._send(200)
        self.srv = socketserver.ThreadingTCPServer(("127.0.0.1", 0), H); self.srv.daemon_threads = True; self.port = self.srv.server_address[1]
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()
    def base(self): return f"http://127.0.0.1:{self.port}{self.base_path}"
    def close(self): self.srv.shutdown(); self.srv.server_close()
def run(sc, dpi=300, source="Platen", color="RGB24", retry=40, maxwait=400, duplex=False, java_file=None):
    d = os.path.join(OUT, f"escl_pages_{sc.port}"); os.makedirs(d, exist_ok=True)
    args = ["scan", sc.base(), d, dpi, source, color, retry, maxwait] + (["duplex"] if duplex else [])
    r = (java(*args) if java_file is None else subprocess.run(["java", java_file, *map(str, args)], capture_output=True, text=True, check=True).stdout.strip().split("\n"))[0]
    pages = [open(os.path.join(d, f"page_{i}.bin"), "rb").read() for i in range(len([x for x in os.listdir(d) if x.endswith('.bin')]))]
    return r, pages
S = Scanner(location="abs", pages=1, warmup=2); r, pages = run(S)
check(r == "OK 1 Platen 300" and pages == [JPEG("P1")], f"A. bàn kính: 503 khởi động x2 rồi 1 trang đúng từng byte ({r})")
check([x[0] for x in S.log] == ["GET", "POST"] + ["GET"] * 4 + ["DELETE"] and S.log[-1][1] == "/eSCL/ScanJobs/job1", f"   thứ tự yêu cầu: GET caps, POST, 4 x NextDocument (503,503,200,404), DELETE: {[x[0] for x in S.log]}")
ct, body = S.posted; root = etree.fromstring(body)
check(ct == "text/xml" and root.xpath("string(//pwg:InputSource)", namespaces=NS) == "Platen" and root.xpath("string(//scan:XResolution)", namespaces=NS) == "300" and root.xpath("string(//pwg:Width)", namespaces=NS) == "2480" and root.xpath("string(//pwg:Height)", namespaces=NS) == "3507",
      "   ScanSettings gửi đi: Content-Type text/xml, Platen, 300 dpi, vùng min(A4, tối đa của máy) = 2480 x 3507")
S.close()
S = Scanner(location="rel", pages=3, warmup=1, between=1); r, pages = run(S, source="Feeder")
check(r == "OK 3 Feeder 300" and pages == [JPEG("P1"), JPEG("P2"), JPEG("P3")], f"B. khay giấy 3 trang, Location tương đối, 503 giữa các trang ({r})")
check(S.log.count(("DELETE", "/eSCL/ScanJobs/job2")) == 1, "   công việc bị xoá đúng một lần, bằng đường dẫn đã giải quyết từ Location tương đối")
S.close()
S = Scanner(location="none"); r, pages = run(S)
check(r == "ERR no_location" and not any("NextDocument" in x[1] for x in S.log) and not any(x[0] == "DELETE" for x in S.log), f"C. không có Location: từ chối ({r}), không dò trang, không DELETE bừa")
S.close()
S = Scanner(location="weird", pages=2, warmup=0); r, pages = run(S)
check(r == "OK 2 Platen 300" or r.startswith("OK 2"), f"D. đường dẫn công việc KHÔNG theo sách giáo khoa: dùng Location nguyên văn ({r})")
check(("GET", "/custom/path/job9/NextDocument") in S.log and ("DELETE", "/custom/path/job9") in S.log, "   mọi yêu cầu sau đó đi đúng /custom/path/job9")
weird_log = list(S.log); S.close()
S = Scanner(post_code=503); r, _ = run(S); check(r == "ERR busy", f"E. POST trả 503: báo bận ({r})"); S.close()
S = Scanner(never_ready=True); r, _ = run(S, retry=40, maxwait=200); check(r == "ERR busy" and ("DELETE", "/eSCL/ScanJobs/job1") in S.log and 4 <= S.polls <= 8, f"F. luôn bận: bỏ cuộc sau ~200 ms ({S.polls} lần hỏi) và vẫn DELETE ({r})"); S.close()
S = Scanner(first_404=True); r, _ = run(S); check(r == "ERR no_pages" and ("DELETE", "/eSCL/ScanJobs/job1") in S.log, f"G. 404 ngay lập tức: lỗi 'không có trang', vẫn DELETE ({r})"); S.close()
r = java("scan", "http://8.8.8.8:80/eSCL", OUT, 300, "Platen", "RGB24", 40, 400)[0]; check(r == "ERR not_local", f"H. địa chỉ công cộng bị từ chối TRƯỚC khi kết nối ({r})")
S = Scanner(evil_location=True, warmup=0); r, _ = run(S); check(r == "ERR not_local" and not any("NextDocument" in x[1] for x in S.log), f"I. máy quét (hoặc kẻ giả mạo) chỉ Location sang địa chỉ công cộng: từ chối, không dò trang ({r})"); S.close()
S = Scanner(caps=CAPS_CANON, warmup=0, base_path="/eSCL"); r, pages = run(S, dpi=250); check(r == "OK 1 Platen 200" and pages == [JPEG("P1")], f"J. máy Canon (không gian tên mặc định), xin 250 dpi -> chọn 200 ({r})"); S.close()

# ----------------------------------------------------------------------------------------------------------------------------------------------------------
# D. HAI MẶT (phiên 20, 4.48.4). Tên phần tử đã xác nhận bằng HAI nguồn độc lập (không phải bằng đặc tả Mopria, không tải được): (1) client Go `stnokott/airscan`
# (ScanSettings: `pwg:InputSource`, `scan:Duplex` kiểu bool); (2) log GET /eSCL/ScannerCapabilities của một máy Epson ET-4950 (khối `scan:AdfDuplexInputCaps` có
# MaxWidth / MaxHeight riêng; vùng quét hai mặt vượt giới hạn đó bị trả 409). CAPS_EPSON dưới đây dựng từ chính log đó (4200 một mặt, 3510 hai mặt).
print("== D. hai mặt ==")
ADF_DUP = lambda w, h: f"<scan:AdfDuplexInputCaps><scan:MinWidth>96</scan:MinWidth><scan:MaxWidth>{w}</scan:MaxWidth><scan:MinHeight>96</scan:MinHeight><scan:MaxHeight>{h}</scan:MaxHeight><scan:MaxXOffset>2454</scan:MaxXOffset><scan:MaxYOffset>3414</scan:MaxYOffset><scan:MaxScanRegions>1</scan:MaxScanRegions></scan:AdfDuplexInputCaps>"
CAPS_EPSON = CAPS_HP.replace("HP LaserJet MFP M28w", "EPSON ET-4950 Series").replace("<scan:Adf><scan:AdfSimplexInputCaps><scan:MaxWidth>2480</scan:MaxWidth>", "<scan:Adf><scan:AdfSimplexInputCaps><scan:MaxWidth>2550</scan:MaxWidth>").replace("</scan:AdfSimplexInputCaps></scan:Adf>", "</scan:AdfSimplexInputCaps>" + ADF_DUP(2550, 3510) + "</scan:Adf>")
CAPS_DUP_FIRST = CAPS_HP.replace("<scan:Adf><scan:AdfSimplexInputCaps>", "<scan:Adf>" + ADF_DUP(2480, 3000) + "<scan:AdfSimplexInputCaps>")
CAPS_SHORT_DUP = CAPS_HP.replace("</scan:AdfSimplexInputCaps></scan:Adf>", "</scan:AdfSimplexInputCaps>" + ADF_DUP(2480, 3000) + "</scan:Adf>")
d_lines = [f"caps2\t{HEXB(CAPS_EPSON)}", f"caps2\t{HEXB(CAPS_HP)}", f"caps2\t{HEXB(CAPS_DUP_FIRST)}", f"caps2\t{HEXB(CAPS_CANON)}",
           f"fitd\t{HEXB(CAPS_SHORT_DUP)}\tFeeder\tRGB24\t300\t1", f"fitd\t{HEXB(CAPS_SHORT_DUP)}\tFeeder\tRGB24\t300\t0", f"fitd\t{HEXB(CAPS_HP)}\tFeeder\tRGB24\t300\t1",
           f"fitd\t{HEXB(CAPS_SHORT_DUP)}\tPlaten\tRGB24\t300\t1", f"fitd\t{HEXB(CAPS_EPSON)}\tFeeder\tRGB24\t300\t1", f"fitd\t{HEXB(CAPS_DUP_FIRST)}\tFeeder\tRGB24\t300\t0",
           "xmld\tFeeder\tRGB24\t300\timage/jpeg\t2480\t3000\t1", "xmld\tFeeder\tRGB24\t300\timage/jpeg\t2480\t3508\t0"]
fd = os.path.join(OUT, "escl_duplex.txt"); open(fd, "w", encoding="utf-8").write("\n".join(d_lines) + "\n")
o = java("pure", fd)
exp = ["true|2550x4200|2550x3510", "false|2480x4200|2480x4200", "true|2480x4200|2480x3000", "false|2550x3507|2550x3507"]
for k, e in enumerate(exp):
    pass
check(o[0] == exp[0], f"máy Epson thật (log): giới hạn một mặt 2550x4200, hai mặt 2550x3510, có hai mặt: {o[0]}")
check(o[1] == exp[1], f"máy không có AdfDuplexInputCaps: không hai mặt, giới hạn hai mặt = một mặt: {o[1]}")
check(o[2] == exp[2], f"khối hai mặt đứng TRƯỚC khối một mặt: giới hạn một mặt vẫn lấy từ AdfSimplexInputCaps (2480x4200), hai mặt 2480x3000: {o[2]}")
check(o[3].split("|")[0] == "false", f"máy Canon không có khay giấy: không hai mặt: {o[3]}")
check(o[4] == "Feeder|300|2480|3000|true", f"xin hai mặt, máy giới hạn hai mặt 3000: vùng 2480x3000 (không phải A4 3508): {o[4]}")
check(o[5] == "Feeder|300|2480|3508|false", f"không xin hai mặt: một mặt như cũ, vùng A4: {o[5]}")
check(o[6] == "Feeder|300|2480|3508|false", f"xin hai mặt nhưng máy không có khối hai mặt: bỏ hai mặt (không gửi <scan:Duplex>): {o[6]}")
check(o[7].endswith("|false") and o[7].startswith("Platen"), f"hai mặt chỉ cho khay giấy: kính phẳng bỏ qua: {o[7]}")
check(o[8] == "Feeder|300|2480|3508|true", f"Epson thật: 3508 <= 3510 nên A4 vẫn vừa: {o[8]}")
check(o[9] == "Feeder|300|2480|3508|false", f"khối hai mặt đứng trước, KHÔNG xin hai mặt: vùng theo giới hạn một mặt: {o[9]}")
x2 = etree.fromstring(o[10].replace("\\n", "\n").encode("utf-8")); x1 = etree.fromstring(o[11].replace("\\n", "\n").encode("utf-8"))
tags = [e.tag.split("}")[1] for e in x2]; tags1 = [e.tag.split("}")[1] for e in x1]
check(tags == ["Version", "ScanRegions", "InputSource", "ColorMode", "XResolution", "YResolution", "Duplex", "DocumentFormat"] and x2.xpath("string(//scan:Duplex)", namespaces=NS) == "true" and x2.xpath("string(//pwg:Height)", namespaces=NS) == "3000",
      f"ScanSettings hai mặt: <scan:Duplex>true</scan:Duplex> sau YResolution, vùng 2480x3000: {tags}")
check("Duplex" not in tags1, "ScanSettings một mặt: KHÔNG có phần tử Duplex (không đổi so với trước)")
# máy quét giả: 2 tờ x 2 mặt = 4 ảnh; vùng quét hai mặt vượt giới hạn -> 409 như máy Epson
S = Scanner(caps=CAPS_SHORT_DUP, pages=4, warmup=0, duplex_limit=3000)
r, pages = run(S, source="Feeder", duplex=True)
check(r == "OK 4 Feeder 300" and pages == [JPEG(f"P{i}") for i in range(1, 5)], f"máy giả hai mặt: 2 tờ = 4 ảnh theo thứ tự, vùng gửi đi vừa giới hạn hai mặt ({r})")
check(b"<scan:Duplex>true</scan:Duplex>" in S.posted[1] and etree.fromstring(S.posted[1]).xpath("string(//pwg:Height)", namespaces=NS) == "3000", "   yêu cầu POST thật có <scan:Duplex>true</scan:Duplex> và Height 3000")
S.close()
S = Scanner(caps=CAPS_SHORT_DUP, pages=1, warmup=0, duplex_limit=3000)
req = urllib.request.Request(S.base() + "/ScanJobs", data=o[10].replace("\\n", "\n").replace("3000", "3508").encode("utf-8"), method="POST")
try: urllib.request.urlopen(req); code = 201
except urllib.error.HTTPError as e: code = e.code
check(code == 409, f"máy giả giữ đúng hành vi Epson: gửi hai mặt với Height 3508 > 3000 bị từ chối ({code}), nên việc kẹp theo giới hạn hai mặt là cần thiết")
S.close()
# bản hỏng: dùng giới hạn MỘT MẶT cho hai mặt -> máy trả 409
src = open(os.path.join(HERE, "EsclCheck.java"), encoding="utf-8").read()
old = "s.w = Math.min(A4W, fd ? (s.duplex ? c.feederDW : c.feederW) : c.platenW); s.h = Math.min(A4H, fd ? (s.duplex ? c.feederDH : c.feederH) : c.platenH);"
assert src.count(old) == 1
mp = os.path.join(OUT, "EsclCheckM.java"); open(mp, "w", encoding="utf-8").write(src.replace(old, "s.w = Math.min(A4W, fd ? c.feederW : c.platenW); s.h = Math.min(A4H, fd ? c.feederH : c.platenH);").replace("EsclCheck", "EsclCheckM"))
S = Scanner(caps=CAPS_SHORT_DUP, pages=2, warmup=0, duplex_limit=3000)
dd = os.path.join(OUT, f"escl_pages_{S.port}"); os.makedirs(dd, exist_ok=True)
rm = subprocess.run(["java", mp, "scan", S.base(), dd, "300", "Feeder", "RGB24", "40", "400", "duplex"], capture_output=True, text=True).stdout.strip()
check(rm == "ERR http_409", f"bản hỏng 'dùng giới hạn một mặt cho hai mặt' bị bắt: máy trả 409 ({rm})")
S.close()
print("== thử âm tính ==")
S = Scanner(location="weird", pages=2, warmup=0)
def naive_scan(sc):
    req = urllib.request.Request(sc.base() + "/ScanJobs", data=b"<x/>", method="POST"); resp = urllib.request.urlopen(req)
    job_id = resp.headers["Location"].rstrip("/").split("/")[-1]; naive_job = sc.base() + "/ScanJobs/" + job_id   # tự ghép đường dẫn theo sách giáo khoa
    try: urllib.request.urlopen(naive_job + "/NextDocument"); return True
    except Exception: return False
check(naive_scan(S) is False, "máy khách 'tự ghép' đường dẫn công việc THẤT BẠI với máy quét dùng đường dẫn riêng - dùng Location nguyên văn là bắt buộc")
S.close()
print()
print("TAT CA DAT" if not FAILS else f"CO {len(FAILS)} LOI: " + "; ".join(FAILS[:5]))
sys.exit(1 if FAILS else 0)
