#!/usr/bin/env python3
"""Bắt lỗi "gọi hàm không có định nghĩa" (phiên 25, TECHNICAL_DOCS.md 4.80). Không có trình biên dịch Android ở đây nên các bộ kiểm khác không thấy một lỗi kiểu: gọi `showVersionSettings()` trong khi hàm
đó đã bị một bản vá khác cắt mất (xảy ra thật ở cuối phiên 25: bản zip giao trước đó sẽ không biên dịch, tất cả bộ kiểm tĩnh vẫn "đạt").

Cách làm: lấy mọi lời gọi hàm TRẦN (không có `.` đứng trước) trong các tệp .kt, rồi báo những tên mà (1) không được khai ở bất kỳ đâu trong dự án (`fun`, `val`/`var`, tham số) và (2) không nằm trong DANH SÁCH ĐÃ BIẾT:
`known_calls_baseline.txt` = mọi tên gọi trần trong BẢN ZIP GỐC mà chủ dự án đã biên dịch được (sinh bằng `--make-baseline <DocScanner.zip gốc>`), cộng `known_calls_reviewed.txt` = tên mới
mà một người đã xem và xác nhận là có thật (hàm của Kotlin / Android). Tên mới thật sự chưa được duyệt sẽ bị báo kèm tệp:dòng: hoặc là hàm bị thiếu (sửa mã), hoặc là hàm thư viện hợp lệ (thêm vào danh sách đã duyệt).
Hạn chế: chỉ bắt lời gọi TRẦN (không bắt `obj.hamThieu()`), và một tên có định nghĩa ở tệp khác thì không bị báo dù gọi sai tệp. Chạy: python3 tools/verify/unresolved_calls_check.py"""
import os, re, sys, zipfile
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
SRC = os.path.join(ROOT, "app", "src")
BASELINE = os.path.join(HERE, "known_calls_baseline.txt"); REVIEWED = os.path.join(HERE, "known_calls_reviewed.txt")
KEYWORDS = {"if", "for", "while", "when", "catch", "return", "fun", "super", "this", "constructor", "init", "get", "set", "try", "else", "do", "in", "is", "as", "by", "object", "class", "interface", "throw", "val", "var",
            "import", "package", "typealias", "break", "continue", "where", "out", "vararg", "override", "private", "public", "protected", "internal", "inline", "suspend", "lateinit", "companion", "data", "sealed", "enum", "abstract", "open", "final", "const", "operator", "infix", "tailrec", "external", "annotation", "reified", "crossinline", "noinline", "expect", "actual"}

def strip(text):
    """Takes comments and string / char literals out in ONE pass (the order matters: a string such as "image/*" must not start a block comment). Kotlin block comments nest."""
    out = []; i = 0; n = len(text)
    while i < n:
        c = text[i]; two = text[i:i + 2]
        if two == "//":
            j = text.find("\n", i); i = n if j < 0 else j
        elif two == "/*":
            depth = 1; i += 2
            while i < n and depth:
                if text.startswith("/*", i): depth += 1; i += 2
                elif text.startswith("*/", i): depth -= 1; i += 2
                else: i += 1
            out.append(" ")
        elif text.startswith('"""', i):
            j = text.find('"""', i + 3); i = n if j < 0 else j + 3
            while i < n and text[i] == '"': i += 1
            out.append('""')
        elif c == '"':
            i += 1
            while i < n and text[i] != '"' and text[i] != "\n":
                i += 2 if text[i] == "\\" else 1
            i += 1; out.append('""')
        elif c == "'" and (i + 2 < n and (text[i + 2] == "'" or (text[i + 1] == "\\" and "'" in text[i + 2:i + 8]))):
            j = text.find("'", i + 2 if text[i + 1] != "\\" else i + 3); i = (j if j >= 0 else i) + 1; out.append("''")
        else:
            out.append(c); i += 1
    return "".join(out)

CALL = re.compile(r"(?<![\w.\"'$@])([a-z_][A-Za-z0-9_]*)\s*(?:<[^<>()\n]*>)?\s*\(")
DECL_FUN = re.compile(r"\bfun\s+(?:<[^>]*>\s*)?(?:[\w.<>?, ]+\.)?([A-Za-z_]\w*)\s*[(<]")
DECL_VAL = re.compile(r"\b(?:val|var)\s+([a-z_]\w*)")
DECL_PARAM = re.compile(r"\b([a-z_]\w*)\s*:\s*[\w(?@]")
DECL_LAMBDA = re.compile(r"\{\s*([a-z_]\w*(?:\s*,\s*[a-z_]\w*)*)\s*->")
def files():
    for dp, dn, fn in os.walk(SRC):
        for f in fn:
            if f.endswith(".kt"): yield os.path.join(dp, f)
def read_names(text):
    t = strip(text); t_nofun = DECL_FUN.sub(" ", t)
    return {m.group(1) for m in CALL.finditer(t_nofun)} - KEYWORDS

if "--make-baseline" in sys.argv:
    zf = zipfile.ZipFile(sys.argv[sys.argv.index("--make-baseline") + 1]); names = set()
    for n in zf.namelist():
        if n.endswith(".kt") and "/src/main/java/" in n: names |= read_names(zf.read(n).decode("utf-8", "replace"))
    open(BASELINE, "w", encoding="utf-8").write("\n".join(sorted(names)) + "\n"); print(f"baseline: {len(names)} tên"); sys.exit(0)

declared = set(); calls = []   # (name, file, line)
for path in files():
    raw = open(path, encoding="utf-8", errors="replace").read(); t = strip(raw)
    declared |= {m.group(1) for m in DECL_FUN.finditer(t)} | {m.group(1) for m in DECL_VAL.finditer(t)} | {m.group(1) for m in DECL_PARAM.finditer(t)}
    for m in DECL_LAMBDA.finditer(t): declared |= {x.strip() for x in m.group(1).split(",")}
    t_nofun = DECL_FUN.sub(lambda m: " " * len(m.group(0)), t)
    for m in CALL.finditer(t_nofun):
        name = m.group(1)
        if name not in KEYWORDS: calls.append((name, os.path.relpath(path, ROOT), t_nofun.count("\n", 0, m.start()) + 1))
known = set(open(BASELINE, encoding="utf-8").read().split()) if os.path.exists(BASELINE) else set()
reviewed = set(open(REVIEWED, encoding="utf-8").read().split()) if os.path.exists(REVIEWED) else set()
bad = {}
for name, f, line in calls:
    if name in declared or name in known or name in reviewed: continue
    bad.setdefault(name, []).append(f"{f}:{line}")
for name, where in sorted(bad.items()): print(f"LOI  lời gọi trần `{name}(` không có định nghĩa, không có trong bản gốc, chưa được duyệt: {', '.join(where[:3])}")
print(f"đã quét {len(set(c[1] for c in calls))} tệp .kt, {len(calls)} lời gọi trần, {len(declared)} tên khai báo, {len(known)} tên của bản gốc, {len(reviewed)} tên đã duyệt")
print("TAT CA DAT" if not bad else f"{len(bad)} LOI")
sys.exit(1 if bad else 0)
