#!/usr/bin/env python3
"""Kiểm chứng DocumentImport.kt (phiên 19, mục 4.47.2): nhập Markdown / HTML / Word (.docx) / CSV-TSV thành khối văn bản.

Bản Java song song (DocImportCheck.java, cùng thuật toán với Kotlin) được so với các bộ đọc ĐỘC LẬP, trên dữ liệu sinh ngẫu nhiên:
  A. Markdown  <-> `pandoc -f commonmark+pipe_tables` (cây cú pháp AST: tiêu đề, đoạn, mục danh sách lồng nhau, khối mã, hàng bảng)
  B. HTML      <-> lxml.html (bộ phân tích DOM thật; chạy lại thuật toán 'khối' trên cây DOM)
  C. DOCX      <-> python-docx (tạo tệp .docx thật rồi đọc lại bằng chính thư viện đó)
  D. CSV / TSV <-> mô-đun `csv` của Python (RFC 4180, nháy kép, xuống dòng trong ô, BOM) + nhận dạng dấu ngăn
  E. khối -> chương: so với bản Python viết lại riêng
  F. thử âm tính: mỗi lỗi cố ý (độ sâu danh sách, thực thể, nháy kép, ...) phải bị bài kiểm bắt.
Môi trường cần: java, pandoc, lxml, python-docx. In 'TAT CA DAT' khi mọi mục đều đạt.
"""
import io, json, os, random, re, subprocess, sys, zipfile
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
HERE = os.path.dirname(os.path.abspath(__file__))
FAIL = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: FAIL.append(msg)
rnd = random.Random(1904)
hx = lambda s: s.encode("utf-8").hex()
unhx = lambda h: bytes.fromhex(h).decode("utf-8")

def java(lines):
    src = os.path.join(OUT, "docimport_in.txt"); dst = os.path.join(OUT, "docimport_out.txt")
    open(src, "w", encoding="utf-8").write("\n".join(lines) + "\n")
    r = subprocess.run(["java", os.path.join(HERE, "DocImportCheck.java"), src, dst], capture_output=True, text=True)
    if r.returncode: print(r.stderr[-2000:]); sys.exit(1)
    return open(dst, encoding="utf-8").read().split("\n")[:len(lines)]
def parse_blocks(line):
    out = []
    for b in line.split(";"):
        if not b: continue
        k, lv, m, t = b.split("|"); out.append((k, int(lv), unhx(m), unhx(t)))
    return out
norm = lambda s: re.sub(r"\s+", " ", s.replace("\u00a0", " ")).strip()
def key(b): return (b[0], b[1], "\n".join(norm(x) for x in b[3].split("\n")))

# ============================================================ A. Markdown <-> pandoc
WORDS = "alpha beta gamma delta tài liệu quét chữ Việt 日本語 résumé naïve file_name snake_case_word 3*4*5 a_b c.d e-f".split()
def inline_md():
    parts = []
    for _ in range(rnd.randint(1, 7)):
        w = rnd.choice(WORDS); r = rnd.random()
        if r < .10: w = f"**{w}**"
        elif r < .18: w = f"*{w}*"
        elif r < .24: w = f"_{w}_" if "_" not in w and w.isalpha() else w
        elif r < .30: w = f"`{w}`"
        elif r < .36: w = f"[{w}](https://example.org/{rnd.randint(1,99)})"
        elif r < .40: w = f"![{w}](img{rnd.randint(1,9)}.png)"
        elif r < .44: w = w + "\\*"
        elif r < .47: w = w + " &amp; &lt;x&gt; &#233;"
        elif r < .50: w = f"~~{w}~~"
        elif r < .53: w = f"<https://a.b/{rnd.randint(1,9)}>"
        parts.append(w)
    return " ".join(parts)
def md_doc():
    out = []; stack = []
    for _ in range(rnd.randint(2, 9)):
        k = rnd.random()
        if k < .17: out.append("#" * rnd.randint(1, 4) + " " + inline_md() + ("" if rnd.random() < .8 else " ##")); out.append("")
        elif k < .22:
            t = inline_md(); out += [t, rnd.choice(["===", "---", "======", "-----"]), ""]
        elif k < .45:
            out.append(inline_md());
            if rnd.random() < .3: out[-1] += rnd.choice(["  ", "\\"]); out.append(inline_md())
            elif rnd.random() < .3: out.append(inline_md())
            out.append("")
        elif k < .70:
            depth = 0; items = []; ordered = [rnd.random() < .4]; counters = [rnd.randint(1, 3) if ordered[0] else 0]; offs = [0]
            loose = rnd.random() < .4
            for _ in range(rnd.randint(2, 6)):
                if rnd.random() < .3 and len(offs) < 3: # đi sâu một cấp
                    ordered.append(rnd.random() < .4); counters.append(1 if ordered[-1] else 0); offs.append(offs[-1] + (3 if len(offs) and ordered[-2] else 2))
                elif rnd.random() < .3 and len(offs) > 1: offs.pop(); ordered.pop(); counters.pop()
                mark = f"{counters[-1]}." if ordered[-1] else rnd.choice("-*+")
                if ordered[-1]: counters[-1] += 1
                items.append(" " * offs[-1] + mark + " " + inline_md())
                if loose: items.append("")
            out += items + ([] if loose else [""])
        elif k < .78: out += ["```" + rnd.choice(["", "py", "text"]), *[rnd.choice(["x = 1", "  indent_line", "a_b *c*", "# not a heading"]) for _ in range(rnd.randint(1, 4))], "```", ""]
        elif k < .87:
            cols = rnd.randint(2, 4); head = [rnd.choice(WORDS) for _ in range(cols)]
            out.append("| " + " | ".join(head) + " |"); out.append("|" + "|".join(rnd.choice([" --- ", ":---:", "---"]) for _ in range(cols)) + "|")
            for _ in range(rnd.randint(1, 3)): out.append("| " + " | ".join(rnd.choice(WORDS) + (" **b**" if rnd.random() < .2 else "") for _ in range(cols)) + " |")
            out.append("")
        elif k < .93: out += ["> " + inline_md(), ""]
        else: out += [rnd.choice(["---", "***", "___", "- - -"]), ""]
    return "\n".join(out) + "\n"

def ast_text(inl):
    o = []
    for x in inl:
        t = x["t"]
        if t == "Str": o.append(x["c"])
        elif t in ("Space", "SoftBreak"): o.append(" ")
        elif t == "LineBreak": o.append("\n")
        elif t == "Code": o.append(x["c"][1])
        elif t in ("Emph", "Strong", "Strikeout", "Underline", "Superscript", "Subscript", "SmallCaps"): o.append(ast_text(x["c"]))
        elif t == "Link": o.append(ast_text(x["c"][1]))
        elif t == "Image": o.append(ast_text(x["c"][1]))
        elif t in ("Span",): o.append(ast_text(x["c"][1]))
        elif t == "Quoted": o.append(ast_text(x["c"][1]))
        # RawInline: bỏ
    return "".join(o)
def ast_blocks(blocks, depth=0, out=None):
    out = [] if out is None else out
    for b in blocks:
        t = b["t"]
        if t == "Header": out.append(("H", b["c"][0], "", ast_text(b["c"][2])))
        elif t in ("Para", "Plain"): out.append(("P", 0, "", ast_text(b["c"])))
        elif t == "CodeBlock": out.append(("CODE", 0, "", b["c"][1].rstrip()))
        elif t == "BlockQuote": ast_blocks(b["c"], depth, out)
        elif t in ("BulletList", "OrderedList"):
            items = b["c"] if t == "BulletList" else b["c"][1]
            for it in items:
                first = True
                for sub in it:
                    if sub["t"] in ("Para", "Plain") and first: out.append(("LI", depth + 1, "", ast_text(sub["c"]))); first = False
                    elif sub["t"] in ("BulletList", "OrderedList"): ast_blocks([sub], depth + 1, out)
        elif t == "Table":
            c = b["c"]; head = c[3][1]; bodies = c[4]; foot = c[5][1]
            rows = list(head) + [r for bd in bodies for r in bd[3]] + list(foot)
            for r in rows:
                cells = [ast_text([i for blk in cell[4] for i in (blk["c"] if blk["t"] in ("Para", "Plain") else [])]) for cell in r[1]]
                out.append(("ROW", 0, "", " | ".join(norm(x) for x in cells)))
    return [x for x in out if not (x[0] in ("P", "H") and not norm(x[3]))]

def pandoc_blocks(md):
    r = subprocess.run(["pandoc", "-f", "commonmark+pipe_tables+strikeout", "-t", "json"], input=md, capture_output=True, text=True)
    return ast_blocks(json.loads(r.stdout)["blocks"])

print("== A. Markdown <-> pandoc (commonmark): tiêu đề, đoạn, danh sách lồng nhau, khối mã, bảng, trích dẫn ==")
docs = [md_doc() for _ in range(700)]
got = java(["MD\t" + hx(d) for d in docs]); bad = []; nb = 0; nested = 0; hs = 0
for d, g in zip(docs, got):
    mine = [key(b) for b in parse_blocks(g)]; ref = [key(b) for b in pandoc_blocks(d)]
    nb += len(ref); nested += sum(1 for b in ref if b[0] == "LI" and b[1] >= 2); hs += sum(1 for b in ref if b[0] == "H")
    if mine != ref: bad.append((d, mine, ref))
print(f"     {len(docs)} tài liệu, {nb} khối ({hs} tiêu đề, {nested} mục danh sách từ cấp 2)")
check(not bad, f"Markdown: Java = pandoc ở {len(docs) - len(bad)}/{len(docs)} tài liệu")
for d, m, r in bad[:3]:
    print("---- LỆCH\n" + d); 
    for a, b in zip(m + [None] * 30, r + [None] * 30):
        if a != b: print("  mine:", a, "\n  ref :", b); break
check(nested > 200 and hs > 150, "bộ dữ liệu có đủ danh sách lồng nhau và tiêu đề (không kiểm chay)")

# ============================================================ B. HTML <-> lxml
import lxml.html
INLINE_TAGS = {"a", "b", "i", "em", "strong", "span", "code", "small", "u", "sup", "sub", "abbr", "mark", "s", "font", "label", "tt", "kbd", "cite", "q", "var", "samp", "big", "del", "ins", "img"}
def html_ref(src):
    src = re.sub(r"<!--.*?-->", "", src, flags=re.S)
    root = lxml.html.document_fromstring(src)   # DOM thật: <head> riêng, <body> riêng
    for bad_tag in root.xpath("//script|//style|//noscript|//head|//template"): bad_tag.drop_tree()
    out = []
    def inline_text(e, pre=False):
        o = []
        if e.text: o.append(e.text)
        for c in e:
            if not isinstance(c.tag, str): 
                if c.tail: o.append(c.tail)
                continue
            if c.tag == "br": o.append("\n" if pre else "\x01")
            elif c.tag in INLINE_TAGS: o.append(inline_text(c, pre))
            if c.tail: o.append(c.tail)
        return "".join(o)
    def clean(s): return re.sub(r"[ \t\u00a0\r\n]+", " ", s.replace("\x01", " \x01 ")).strip().replace(" \x01 ", "\n").replace("\x01", "\n").strip()
    def emit(kind, lvl, txt, mk="", pre=False):
        t = txt.strip("\n") if pre else clean(txt)
        if t: out.append((kind, lvl, mk, t))
    def walk(e, depth):
        cur = [e.text or ""]
        def flush():
            emit("P", 0, "".join(cur)); cur.clear()
        for c in e:
            if not isinstance(c.tag, str): cur.append(c.tail or ""); continue
            tag = c.tag
            if tag in INLINE_TAGS: cur.append(inline_text(c) if tag != "br" else ""); cur.append(c.tail or ""); continue
            if tag == "br": cur.append("\x01"); cur.append(c.tail or ""); continue
            flush()
            if re.fullmatch(r"h[1-6]", tag): emit("H", int(tag[1]), inline_text(c))
            elif tag == "pre": emit("CODE", 0, inline_text(c, True) if not len(c) else "".join(c.itertext()), pre=True)
            elif tag in ("ul", "ol"):
                n = 0
                for li in c:
                    if li.tag != "li": continue
                    n += 1; mk = f"{n}." if tag == "ol" else "\u2022"; first = [li.text or ""]
                    nested = [x for x in li if isinstance(x.tag, str) and x.tag in ("ul", "ol")]
                    for x in li:
                        if not isinstance(x.tag, str): first.append(x.tail or ""); continue
                        if x.tag in INLINE_TAGS: first.append(inline_text(x)); first.append(x.tail or "")
                        elif x.tag == "br": first.append("\x01"); first.append(x.tail or "")
                    emit("LI", depth + 1, "".join(first), mk)
                    for sub in nested: walk(wrap([sub]), depth + 1)
            elif tag == "table":
                for tr in c.iter("tr"):
                    cells = [clean(" ".join(td.itertext()).replace("\x01", " ")) for td in tr if td.tag in ("td", "th")]
                    if any(cells): out.append(("ROW", 0, "", " | ".join(cells)))
            else: walk(c, depth)
            cur.append(c.tail or "")
        flush()
    def wrap(children):
        w = lxml.html.fromstring("<div></div>")
        for ch in children: w.append(ch)
        return w
    walk(root.find("body"), 0)
    return out

def html_doc():
    o = []
    for _ in range(rnd.randint(2, 8)):
        k = rnd.random(); w = lambda: " ".join(rnd.choice(WORDS + ["&amp;", "&eacute;", "&#233;", "&nbsp;x", "<b>bold</b>", "<a href='u'>link</a>", "<em>em</em>"]) for _ in range(rnd.randint(1, 6)))
        if k < .2: n = rnd.randint(1, 6); o.append(f"<h{n}>{w()}</h{n}>")
        elif k < .45: o.append(f"<p>{w()}{'<br>' + w() if rnd.random() < .25 else ''}</p>")
        elif k < .55: o.append(f"<div><p>{w()}</p><p>{w()}</p></div>")
        elif k < .75:
            tag = rnd.choice(["ul", "ol"]); items = []
            for _ in range(rnd.randint(2, 5)):
                if rnd.random() < .25: items.append(f"<li>{w()}<{rnd.choice(['ul','ol'])}><li>{w()}</li><li>{w()}</li></{'ul'}></li>".replace("</ul></li>", "</ul></li>"))
                else: items.append(f"<li>{w()}</li>")
            body = "".join(items)
            body = re.sub(r"<(ul|ol)><li>(.*?)</li><li>(.*?)</li></ul>", lambda m: f"<{m.group(1)}><li>{m.group(2)}</li><li>{m.group(3)}</li></{m.group(1)}>", body)
            o.append(f"<{tag}>{body}</{tag}>")
        elif k < .83: o.append("<pre>" + "\n".join(rnd.choice(["x = 1", "  indent", "a &lt; b", "tail"]) for _ in range(rnd.randint(1, 3))) + "</pre>")
        elif k < .93: o.append("<table>" + "".join("<tr>" + "".join(f"<{c}>{w()}</{c}>" for _ in range(3)) + "</tr>" for c in ["th"] + ["td"] * rnd.randint(1, 3)) + "</table>")
        else: o.append(rnd.choice(["<!-- ghi chú ẩn -->", "<script>var x = '<p>không</p>';</script>", "<style>p{color:red}</style>", "<hr>"]))
    return "<html><head><title>T</title></head><body>\n" + "\n".join(o) + "\n</body></html>"

print("== B. HTML <-> lxml.html ==")
pages = [html_doc() for _ in range(600)]
got = java(["HTML\t" + hx(p) for p in pages]); bad = []
for p, g in zip(pages, got):
    mine = [(b[0], b[1], b[2], norm(b[3])) for b in parse_blocks(g)]; ref = [(a, b_, c, norm(d)) for a, b_, c, d in html_ref(p)]
    if mine != ref: bad.append((p, mine, ref))
check(not bad, f"HTML: Java = lxml ở {len(pages) - len(bad)}/{len(pages)} trang")
for p, m, r in bad[:3]:
    print("---- LỆCH\n" + p)
    for a, b in zip(m + [None] * 30, r + [None] * 30):
        if a != b: print("  mine:", a, "\n  ref :", b); break

# ============================================================ C. DOCX <-> python-docx
import docx
def make_docx(path):
    d = docx.Document(); ref = []
    for _ in range(rnd.randint(2, 9)):
        k = rnd.random(); w = lambda: " ".join(rnd.choice(WORDS + ["&", "<tag>", "x > y", "\"quote\""]) for _ in range(rnd.randint(1, 6)))
        if k < .12: t = w(); d.add_heading(t, 0); ref.append(("H", 1, t))
        elif k < .30: n = rnd.randint(1, 4); t = w(); d.add_heading(t, n); ref.append(("H", n, t))
        elif k < .52:
            p = d.add_paragraph(); t1, t2 = w(), w(); p.add_run(t1).bold = True; p.add_run(" " + t2)
            if rnd.random() < .2: p.add_run("\tTab")
            if rnd.random() < .2: r = p.add_run(); r.add_break(); r.add_text("dòng hai")
            ref.append(("P", 0, p.text))
        elif k < .70:
            for _ in range(rnd.randint(1, 3)):
                t = w(); st = rnd.choice(["List Bullet", "List Bullet 2", "List Number"]); d.add_paragraph(t, style=st)
                ref.append(("LI", 2 if st.endswith("2") else 1, t))
        elif k < .88:
            rows, cols = rnd.randint(1, 3), rnd.randint(2, 3); tb = d.add_table(rows=rows, cols=cols)
            for r in tb.rows:
                cells = []
                for c in r.cells: t = w(); c.text = t; cells.append(t)
                ref.append(("ROW", 0, " | ".join(cells)))
        else: d.add_paragraph("")
    d.save(path); return ref
print("== C. DOCX <-> python-docx ==")
bad = []; N = 250; nl = 0; xmls, refs = [], []
for i in range(N):
    path = os.path.join(OUT, "t.docx"); refs.append(make_docx(path))
    xmls.append(zipfile.ZipFile(path).read("word/document.xml").decode("utf-8"))
last_xml = xmls[-1]
for ref, g in zip(refs, java(["DOCX\t" + hx(x) for x in xmls])):   # MỘT lần chạy Java cho cả 250 tệp (mỗi lần khởi động JVM mất ~1 giây)
    mine = [(b[0], b[1], norm(b[3])) for b in parse_blocks(g)]; exp = [(a, b_, norm(c)) for a, b_, c in ref]
    exp = [x for x in exp if x[2]]
    nl += sum(1 for x in exp if x[0] == "LI")
    if mine != exp: bad.append((mine, exp))
check(not bad, f"DOCX: Java = đọc lại bằng python-docx ở {N - len(bad)}/{N} tệp ({nl} mục danh sách, tiêu đề, bảng, tab, ngắt dòng)")
for m, e in bad[:2]:
    for a, b in zip(m + [None] * 30, e + [None] * 30):
        if a != b: print("  mine:", a, "\n  ref :", b); break

# ============================================================ D. CSV
import csv
def csv_table():
    cols = rnd.randint(2, 6); rows = []
    for _ in range(rnd.randint(1, 8)):
        row = []
        for _ in range(cols):
            r = rnd.random()
            row.append("" if r < .08 else rnd.choice(["abc", "Nguyễn Văn A", "12,5", "a;b", "x|y", "dòng1\ndòng2", "có \"nháy\" kép", " cách ", "日本語", "tab\tsep", "1.5", "end\r\nCRLF"]) if r < .5 else rnd.choice(WORDS))
        rows.append(row)
    return rows
print("== D. CSV / TSV <-> csv của Python ==")
cases, exp, lines = [], [], []
for _ in range(1500):
    d = rnd.choice([",", ";", "\t", "|"]); t = csv_table(); nlz = rnd.choice(["\n", "\r\n"])
    buf = io.StringIO(newline=""); wr = csv.writer(buf, delimiter=d, lineterminator=nlz); wr.writerows(t); s = buf.getvalue()
    if rnd.random() < .3: s = s.rstrip("\r\n")
    if rnd.random() < .2: s = "\ufeff" + s
    ref = list(csv.reader(io.StringIO(s.lstrip("\ufeff"), newline=""), delimiter=d))
    lines.append(f"CSV\t{ord(d)}\t{hx(s)}"); exp.append(ref); cases.append(s)
got = java(lines); bad = 0
for g, e in zip(got, exp):
    rows = [[unhx(c) for c in r[1:].split(",")] if r[1:] else [""] for r in g.split(";")[:-1]]
    if rows != e: bad += 1
check(bad == 0, f"CSV: Java = csv.reader ở {len(exp) - bad}/{len(exp)} tệp (nháy kép, xuống dòng trong ô, CRLF, BOM, ô trống, Unicode)")
tests = [("a,b\n1,2\n", [["a", "b"], ["1", "2"]]), ("a,\"b\nc\",d", [["a", "b\nc", "d"]]), ("\"x\"\"y\",z\r\n", [["x\"y", "z"]]), ("", []), ("a,b\r\n\r\n", [["a", "b"]]), ("\n\na,b\n\n\nc,d\n", [["a", "b"], ["c", "d"]]), ("a,b\n\"\"\n", [["a", "b"], [""]])]
got = java([f"CSV\t44\t{hx(s)}" for s, _ in tests])
for (s, e), g in zip(tests, got):
    rows = [[unhx(c) for c in r[1:].split(",")] if r[1:] else [""] for r in g.split(";")[:-1]]
    check(rows == e, f"CSV ca riêng {s[:18]!r} -> {e}")
# nhận dạng dấu ngăn: tệp 'sạch' (ô không chứa dấu ngăn nào khác) phải nhận đúng 100%
det_cases, det_exp = [], []
for _ in range(800):
    d = rnd.choice([",", ";", "\t", "|"]); cols = rnd.randint(2, 6); rowsn = rnd.randint(2, 12)
    t = [[rnd.choice(["abc", "Nguyễn", "12", "x y", "日本", "3.14", "" if rnd.random() < .1 else "k"]) for _ in range(cols)] for _ in range(rowsn)]
    buf = io.StringIO(newline=""); csv.writer(buf, delimiter=d, lineterminator="\n").writerows(t)
    det_cases.append("DET\t" + hx(buf.getvalue())); det_exp.append(ord(d))
got = java(det_cases); wrong = sum(1 for g, e in zip(got, det_exp) if int(g) != e)
check(wrong == 0, f"nhận dạng dấu ngăn (, ; TAB |) đúng {len(det_exp) - wrong}/{len(det_exp)} tệp sạch")
# khó: ô có dấu ngăn khác nằm trong nháy kép (12,5 / a;b / x|y)
hard, hexp = [], []
for _ in range(600):
    d = rnd.choice([",", ";", "\t", "|"]); t = [[rnd.choice(["abc", "12,5", "a;b", "x|y", "plain", "k"]) for _ in range(rnd.randint(2, 5))] for _ in range(rnd.randint(4, 10))]
    c = max(map(len, t)); t = [r + ["z"] * (c - len(r)) for r in t]
    buf = io.StringIO(newline=""); csv.writer(buf, delimiter=d, lineterminator="\n").writerows(t); hard.append("DET\t" + hx(buf.getvalue())); hexp.append(ord(d))
got = java(hard); wrong = sum(1 for g, e in zip(got, hexp) if int(g) != e)
check(wrong <= len(hexp) * 0.03, f"nhận dạng dấu ngăn khi ô chứa dấu ngăn khác (trong nháy kép): đúng {len(hexp) - wrong}/{len(hexp)} (cho phép sai ≤ 3 %: ô ít, dấu ngăn thưa)")

# ---- thực thể ký tự: toàn bộ 252 tên HTML 4 + số thập phân / thập lục / Windows-1252 so với html.unescape
import html as _html
from html.entities import name2codepoint
ents = [f"&{n};" for n in sorted(name2codepoint)]
nums = [f"&#{c};" for c in list(range(32, 127)) + [233, 7840, 8364, 128512, 150, 151, 146, 133]] + [f"&#x{c:X};" for c in (0xE9, 0x1EA0, 0x20AC, 0x1F600, 0x96)]
got = java(["ENT\t" + hx(e) for e in ents + nums]); badE = [e for e, g in zip(ents + nums, got) if unhx(g) != _html.unescape(e)]
check(not badE, f"thực thể: {len(ents)} tên HTML 4 + {len(nums)} mã số (kể cả 0x80-0x9F kiểu Windows-1252) = html.unescape ({len(badE)} lệch {badE[:4]})")
got = java(["ENT\t" + hx(e) for e in ["&foo;", "&#0;", "&#xD800;", "&#1114112;", "&;", "a & b", "&amp", "&#;"]])
check([unhx(g) for g in got] == ["&foo;", "&#0;", "&#xD800;", "&#1114112;", "&;", "a & b", "&amp", "&#;"], "thực thể lạ / mã không hợp lệ / thiếu dấu ; được để nguyên")

# ---- mã hoá văn bản: BOM UTF-8 / UTF-16, <meta charset>, UTF-8 hợp lệ, rơi về Windows-1252
print("== D2. nhận dạng mã hoá văn bản ==")
vi_text = "Tiếng Việt: Nguyễn Văn Ánh – “trích dẫn” € 日本語 ©"
latin_text = "Café résumé – “quotes” € ©"                 # có trong Windows-1252
encs = []
for t in (vi_text, latin_text, "plain ascii"):
    encs.append(("utf-8", t.encode("utf-8"), 0, t)); encs.append(("utf-8 BOM", b"\xef\xbb\xbf" + t.encode("utf-8"), 0, t))
    encs.append(("utf-16 LE BOM", b"\xff\xfe" + t.encode("utf-16-le"), 0, t)); encs.append(("utf-16 BE BOM", b"\xfe\xff" + t.encode("utf-16-be"), 0, t))
for t in (latin_text, "Café – “x”"):
    encs.append(("cp1252 (rơi về)", t.encode("cp1252"), 0, t))
    page = ('<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252"></head><body>' + t + "</body></html>")
    encs.append(("html meta cp1252", page.encode("cp1252"), 1, page))
    page2 = ('<meta charset="iso-8859-1"><p>' + "Café déjà vu" + "</p>"); encs.append(("html meta latin-1", page2.encode("latin-1"), 1, page2))
    page3 = ('<meta charset=utf-8><p>' + vi_text + "</p>"); encs.append(("html meta utf-8", page3.encode("utf-8"), 1, page3))
got = java([f"DEC\t{sn}\t{b.hex()}" for _, b, sn, _ in encs]); badd = [(n, unhx(g)[:40]) for (n, b, sn, t), g in zip(encs, got) if unhx(g) != t]
check(not badd, f"{len(encs)} ca mã hoá (UTF-8 / BOM / UTF-16 / meta charset / Windows-1252) giải đúng ({len(badd)} lệch {badd[:2]})")
got = java([f"DEC\t0\t{b.hex()}" for b in (b"", b"\xff", b"abc\xe9", b"\xef\xbb\xbf")])
check([unhx(g) for g in got] == ["", "\u00ff", "abcé", ""], "ca biên: rỗng, byte lẻ, chỉ có BOM không làm hỏng")
# ---- TableLayout: bề rộng cột
print("== D3. chia bề rộng cột bảng (TableLayout) ==")
tl, ex = [], []
for _ in range(3000):
    n = rnd.randint(1, 9); nat = [round(rnd.choice([0.0, 12.0, 30.5, 55.0, 80.0, 140.0, 260.0, rnd.uniform(5, 300)]), 2) for _ in range(n)]
    av = round(rnd.choice([100.0, 250.0, 400.0, 523.0, 770.0, rnd.uniform(60, 800)]), 2); mn = rnd.choice([30.0, 48.0, 60.0])
    tl.append(f"TL\t{av}\t{mn}\t{','.join(map(str, nat))}"); ex.append((nat, av, mn))
got = java(tl); okp = True; why = ""
for (nat, av, mn), g in zip(ex, got):
    w = [float(x) for x in g.split(",")]; eps = 1e-3 * max(1.0, av)
    tot = sum(nat); sb = sum(min(x, mn) for x in nat)
    if len(w) != len(nat): okp = False; why = "độ dài"; break
    if abs(sum(w) - min(tot, av)) > eps: okp = False; why = f"tổng {sum(w):.3f} khác {min(tot, av):.3f}"; break
    if any(wi < -1e-6 or wi > x + 1e-3 for wi, x in zip(w, nat)): okp = False; why = "cột vượt bề rộng tự nhiên hoặc âm"; break
    if sb <= av and tot > av and any(wi < min(x, mn) - 1e-3 for wi, x in zip(w, nat)): okp = False; why = "cột nhỏ hơn mức tối thiểu dù còn chỗ"; break
    if any(nat[i] <= nat[j] and w[i] > w[j] + 1e-3 for i in range(len(nat)) for j in range(len(nat))): okp = False; why = "thứ tự cột bị đảo"; break
check(okp, f"3 000 ca chia cột: tổng = min(tổng tự nhiên, chỗ có), 0 <= cột <= tự nhiên, cột >= mức tối thiểu khi còn chỗ, giữ thứ tự độ rộng {why}")
got = java([f"TL\t500.0\t48.0\t100.0,100.0,100.0", "TL\t300.0\t48.0\t100.0,100.0,100.0", "TL\t90.0\t48.0\t100.0,100.0,100.0"])
check([[round(float(x), 2) for x in g.split(",")] for g in got] == [[100.0] * 3, [100.0] * 3, [30.0] * 3], "vừa khổ giấy: giữ nguyên; vừa khít: giữ; thiếu chỗ dưới mức tối thiểu: co đều")

# ============================================================ E. khối -> chương
print("== E. khối -> chương ==")
def py_chapters(blocks, fallback):
    out, title, paras, counter = [], None, [], 0
    def close():
        nonlocal paras
        if title is not None or paras: out.append((title if title is not None else fallback, paras))
        paras = []
    for k, lv, mk, tx in blocks:
        if k == "H" and lv <= 2: close(); title = tx; counter = 0
        elif k == "LI":
            if mk == "#": counter += 1; m = f"{counter}."
            else: m = mk
            paras.append("  " * max(lv - 1, 0) + m + " " + tx)
        else: paras.append(tx)
    close(); return out
cases, exps = [], []
for _ in range(1000):
    bl = []
    for _ in range(rnd.randint(0, 12)):
        k = rnd.choice(["H", "H", "P", "LI", "LI", "CODE", "ROW"]); lv = rnd.randint(1, 4) if k in ("H", "LI") else 0
        bl.append((k, lv, rnd.choice(["\u2022", "#", "3."]) if k == "LI" else "", rnd.choice(["Chương một", "đoạn", "mục", "x y"]) + str(rnd.randint(0, 9))))
    fb = "Tên dự phòng"; cases.append("CH\t" + hx(fb) + "\t" + "\t".join(f"{k}|{lv}|{hx(mk)}|{hx(tx)}" for k, lv, mk, tx in bl)); exps.append(py_chapters(bl, fb))
got = java(cases); bad = 0
for g, e in zip(got, exps):
    ch = [(unhx(x.split(":")[0]), [unhx(p) for p in x.split(":")[1].split(",")] if x.split(":")[1] else []) for x in g.split(";")[:-1]]
    if ch != [(t, list(p)) for t, p in e]: bad += 1
check(bad == 0, f"chương: Java = bản Python viết riêng ở {len(exps) - bad}/{len(exps)} ca (tiêu đề cấp 1-2 mở chương, mục có dấu đầu dòng / số thứ tự, thụt 2 dấu cách mỗi cấp)")

# ============================================================ F. thử âm tính
print("== F. thử âm tính ==")
src = open(os.path.join(HERE, "DocImportCheck.java"), encoding="utf-8").read()
def mutant(name, old, new, probe):
    assert old in src, name
    d = os.path.join(OUT, "mut_" + name); os.makedirs(d, exist_ok=True)
    open(os.path.join(d, "DocImportCheck.java"), "w", encoding="utf-8").write(src.replace(old, new, 1))
    r = subprocess.run(["java", os.path.join(d, "DocImportCheck.java"), os.path.join(OUT, "docimport_in.txt"), os.path.join(d, "o.txt")], capture_output=True, text=True)
    return r.returncode == 0 and open(os.path.join(d, "o.txt"), encoding="utf-8").read().split("\n")
def caught_md(m, n=250):
    if not m: return True
    open(os.path.join(OUT, "docimport_in.txt"), "w", encoding="utf-8").write("\n".join("MD\t" + hx(d) for d in docs[:n]) + "\n")
    return None
def run_mut(name, old, new, kind, items, expect_fn):
    assert old in src, name
    d = os.path.join(OUT, "mut_" + name); os.makedirs(d, exist_ok=True)
    open(os.path.join(d, "DocImportCheck.java"), "w", encoding="utf-8").write(src.replace(old, new, 1))
    inp = os.path.join(d, "in.txt"); open(inp, "w", encoding="utf-8").write("\n".join(kind + "\t" + hx(x) if kind != "CSV" else f"CSV\t44\t{hx(x)}" for x in items) + "\n")
    r = subprocess.run(["java", os.path.join(d, "DocImportCheck.java"), inp, os.path.join(d, "o.txt")], capture_output=True, text=True)
    if r.returncode: return True
    outl = open(os.path.join(d, "o.txt"), encoding="utf-8").read().split("\n")[:len(items)]
    return sum(1 for x, o in zip(items, outl) if expect_fn(x, o)) > 0
md_sub = docs[:300]
check(run_mut("blankdepth", "afterBlank = true; i++; continue;", "afterBlank = true; offsets.clear(); i++; continue;", "MD", md_sub, lambda d, o: [key(b) for b in parse_blocks(o)] != [key(b) for b in pandoc_blocks(d)]), "âm tính: bản 'dòng trống làm mất độ sâu danh sách' bị pandoc bắt")
check(run_mut("entity", "s = decodeEntities(s);", "", "MD", md_sub, lambda d, o: [key(b) for b in parse_blocks(o)] != [key(b) for b in pandoc_blocks(d)]), "âm tính: bản 'không giải mã &amp; &#233;' bị bắt")
check(run_mut("codespan", "String s = replaceAll(CODESPAN, raw, m ->", "String s = replaceAll(Pattern.compile(\"(?!)\"), raw, m ->", "MD", md_sub, lambda d, o: [key(b) for b in parse_blocks(o)] != [key(b) for b in pandoc_blocks(d)]), "âm tính: bản 'xoá cả mã trong `...`' bị bắt")
check(run_mut("quote", "if (c == '\"') { if (i + 1 < text.length() && text.charAt(i + 1) == '\"') { field.append('\"'); i++; } else quoted = false; }", "if (c == '\"') { quoted = false; }", "CSV", [s for s in cases[:0]] or ["a,\"x\"\"y\",c\n"], lambda d, o: True), "âm tính: bản CSV 'nháy kép đôi \"\" thành hết nháy' bị bắt")
check(run_mut("htmlscript", "static final Pattern SKIPPED = Pattern.compile(\"<(script|style|head|noscript|template)", "static final Pattern SKIPPED = Pattern.compile(\"<(zzz|style|head|noscript|template)", "HTML", pages[:300], lambda d, o: [(b[0], b[1], b[2], norm(b[3])) for b in parse_blocks(o)] != [(a, b_, c, norm(x)) for a, b_, c, x in html_ref(d)]), "âm tính: bản 'không bỏ <script>' bị lxml bắt")
check(run_mut("docxstyle", "heading([1-9])$\")", "heading([1-9])zz$\")", "DOCX", [last_xml], lambda d, o: True), "âm tính: bản 'không nhận Heading1-9 ở .docx' cho kết quả khác")

print()
print("TAT CA DAT" if not FAIL else f"CÓ {len(FAIL)} LỖI")
sys.exit(1 if FAIL else 0)
