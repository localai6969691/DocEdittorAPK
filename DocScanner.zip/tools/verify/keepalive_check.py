"""Kiểm chứng WorkTracker / KeepAlive (phiên 18): bộ đếm việc đang chạy điều khiển dịch vụ nền.

KeepAliveCheck.java là bản Java chạy được của WorkTracker (util/KeepAlive.kt). So 3 000 kịch bản ngẫu nhiên với MÔ HÌNH THAM CHIẾU độc lập (Python):
dịch vụ BẮT ĐẦU đúng khi đếm từ 0 lên 1 và DỪNG đúng khi về 0; release khi đang 0 bị bỏ qua (đếm không âm); reset (hệ thống ngắt dịch vụ vì hết giờ) đưa về 0 và
dừng đúng một lần; sau reset một acquire mới khởi động lại; `during` luôn release kể cả khi khối ném lỗi hay lồng nhau (không rò đếm -> không có dịch vụ chạy mãi).
Kiểm đến đây là LOGIC. Không kiểm được ở đây: Android có thật sự khởi động / ngắt dịch vụ (cần máy thật), xem TECHNICAL_DOCS.md 4.38.
Chạy: python3 keepalive_check.py   (cần java 11+)
"""
import os, random, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); FAILS = []
def check(c, w):
    print(("ok  " if c else "LOI"), w)
    if not c: FAILS.append(w)
def model(script):
    ev, n = [], 0
    def acq():
        nonlocal n
        n += 1
        if n == 1: ev.append("START")
    def rel():
        nonlocal n
        if n == 0: return
        n -= 1
        if n == 0: ev.append("STOP")
    for c in script:
        if c == "A": acq()
        elif c == "R": rel()
        elif c == "X":
            if n > 0: n = 0; ev.append("STOP")
        elif c in "DF": acq(); rel()
        elif c == "N": acq(); acq(); acq(); rel(); rel(); rel()   # ba tầng, tầng giữa lỗi: cả ba vẫn release
    return ",".join(ev) + "|" + str(n)
rnd = random.Random(18)
scripts = ["", "A", "AR", "R", "RR", "AAR", "AARR", "AX", "AXR", "AXA", "AXAR", "XAR", "D", "F", "N", "AN", "ANR", "AFR", "FFFF", "NNN", "AAAXRRR"]
scripts += ["".join(rnd.choice("ARXDFN") for _ in range(rnd.randint(1, 40))) for _ in range(3000)]
f = tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False); f.write("\n".join(scripts) + "\n"); f.close()
r = subprocess.run(["java", os.path.join(HERE, "KeepAliveCheck.java"), f.name], capture_output=True, text=True)
if r.returncode != 0: print(r.stderr[-800:])
got = r.stdout.rstrip("\n").split("\n")
os.unlink(f.name)
check(len(got) == len(scripts), f"{len(scripts)} kịch bản, Java trả đủ kết quả")
bad = [(s, g, model(s)) for s, g in zip(scripts, got) if g != model(s)]
check(not bad, f"mọi kịch bản khớp mô hình tham chiếu {bad[:2]}")
check(got[scripts.index("R")] == "|0" and got[scripts.index("RR")] == "|0", "release khi đang 0 bị bỏ qua, đếm không âm, không có sự kiện")
check(got[scripts.index("AXAR")] == "START,STOP,START,STOP|0", "sau khi hệ thống ngắt (reset), acquire mới khởi động lại dịch vụ")
check(got[scripts.index("ANR")] == "START,STOP|0" and got[scripts.index("N")] == "START,STOP|0", "during lồng nhau có tầng lỗi vẫn release hết: dịch vụ dừng, đếm về 0")
print("\nTAT CA DAT" if not FAILS else f"\n{len(FAILS)} LOI"); sys.exit(1 if FAILS else 0)
