import java.io.*;
import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipEntry;

/**
 * Bản Java song song, CÙNG THUẬT TOÁN, của util/OfficeImport.kt (ODT, PPTX, XLSX) + util/RtfImport.kt (phiên 20, 4.48.2). Dùng bởi office_import_check.py.
 * Dùng: java OfficeImportCheck.java   rồi đưa lệnh qua stdin, mỗi dòng một lệnh:
 *   ODT <đường dẫn> | PPTX <đường dẫn> | XLSX <đường dẫn> | RTF <đường dẫn> | RTFHEX <hex byte> | ODTXML <hex content.xml> <hex styles.xml>
 *   FMT <hex số> <hex mã định dạng> | GEN <hex số> | CLS <hex mã> | DATE <ngày> <1904: 0/1> | COL <ref>
 */
public class OfficeImportCheck {
    // ------------------------------------------------------------------------------------------------- tiện ích (Char.isWhitespace của Kotlin)
    static boolean isWs(char c) { return Character.isWhitespace(c) || Character.isSpaceChar(c); }
    static String ktTrim(String s) { int a = 0, b = s.length(); while (a < b && isWs(s.charAt(a))) a++; while (b > a && isWs(s.charAt(b - 1))) b--; return s.substring(a, b); }
    static String[] ktLines(String s) { return s.split("\r\n|\n|\r", -1); }
    static String hex(String s) { StringBuilder b = new StringBuilder(); for (byte x : s.getBytes(StandardCharsets.UTF_8)) b.append(String.format("%02x", x)); return b.toString(); }
    static byte[] unhexBytes(String h) { byte[] b = new byte[h.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return b; }
    static String unhex(String h) { return new String(unhexBytes(h), StandardCharsets.UTF_8); }
    static final Pattern WS = Pattern.compile("[ \\t\\u00A0\\r\\n]+");
    static String collapse(String s) { return ktTrim(WS.matcher(s).replaceAll(" ")); }

    static class Block { String kind, text, marker; int level; Block(String k, int l, String t, String m) { kind = k; level = l; text = t; marker = m; } Block(String k, int l, String t) { this(k, l, t, ""); } }
    static class Sheet { String name; List<List<String>> rows; Sheet(String n, List<List<String>> r) { name = n; rows = r; } }

    // ------------------------------------------------------------------------------------------------- ZIP
    static final int MAX_ENTRY = 64 * 1024 * 1024;
    static final long MAX_TOTAL = 160L * 1024 * 1024;
    interface Wanted { boolean test(String name); }

    static Map<String, String> zipTexts(InputStream in, Wanted wanted) throws IOException {
        Map<String, String> out = new LinkedHashMap<>();
        long total = 0;
        try (ZipInputStream zip = new ZipInputStream(in)) {
            ZipEntry e;
            while ((e = zip.getNextEntry()) != null) {
                if (e.isDirectory() || !wanted.test(e.getName())) continue;
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                byte[] buf = new byte[16 * 1024];
                int size = 0, n;
                while ((n = zip.read(buf)) >= 0) {
                    size += n; total += n;
                    if (size > MAX_ENTRY || total > MAX_TOTAL) return null;
                    bytes.write(buf, 0, n);
                }
                out.put(e.getName(), bytes.toString("UTF-8"));
            }
        }
        return out;
    }

    // ------------------------------------------------------------------------------------------------- máy quét XML
    static abstract class XmlHandler {
        void start(String name, Map<String, String> attrs) {}
        void end(String name) {}
        void text(String t) {}
    }
    static final Pattern XML_ENTITY = Pattern.compile("&(#[0-9]{1,7}|#[xX][0-9A-Fa-f]{1,6}|amp|lt|gt|quot|apos);");
    static String xmlDecode(String s) {
        if (s.indexOf('&') < 0) return s;
        Matcher m = XML_ENTITY.matcher(s);
        StringBuilder sb = new StringBuilder();
        int last = 0;
        while (m.find()) {
            sb.append(s, last, m.start());
            String b = m.group(1), r;
            switch (b) {
                case "amp": r = "&"; break;
                case "lt": r = "<"; break;
                case "gt": r = ">"; break;
                case "quot": r = "\""; break;
                case "apos": r = "'"; break;
                default: {
                    int cp;
                    try { cp = (b.charAt(1) == 'x' || b.charAt(1) == 'X') ? Integer.parseInt(b.substring(2), 16) : Integer.parseInt(b.substring(1)); } catch (NumberFormatException ex) { cp = -1; }
                    r = (cp >= 1 && cp <= 0x10FFFF && !(cp >= 0xD800 && cp <= 0xDFFF)) ? new String(Character.toChars(cp)) : m.group();
                }
            }
            sb.append(r);
            last = m.end();
        }
        sb.append(s.substring(last));
        return sb.toString();
    }
    static final Pattern ATTR = Pattern.compile("([A-Za-z_][A-Za-z0-9_:.\\-]*)\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')");

    static String localOrFull(String name, boolean strip) { return strip ? name.substring(name.indexOf(':') + 1) : name; }

    static void scanXml(String s, XmlHandler h, boolean stripPrefix) {
        int i = 0, n = s.length();
        while (i < n) {
            int lt = s.indexOf('<', i);
            if (lt < 0) { h.text(xmlDecode(s.substring(i))); break; }
            if (lt > i) h.text(xmlDecode(s.substring(i, lt)));
            if (s.startsWith("<!--", lt)) {
                int e = s.indexOf("-->", lt + 4);
                i = e < 0 ? n : e + 3;
            } else if (s.startsWith("<![CDATA[", lt)) {
                int e = s.indexOf("]]>", lt + 9);
                int stop = e < 0 ? n : e;
                h.text(s.substring(lt + 9, stop));
                i = e < 0 ? n : e + 3;
            } else if (s.startsWith("<?", lt) || s.startsWith("<!", lt)) {
                int e = s.indexOf('>', lt);
                i = e < 0 ? n : e + 1;
            } else {
                int j = lt + 1;
                char quote = ' ';
                while (j < n) {
                    char c = s.charAt(j);
                    if (quote != ' ') { if (c == quote) quote = ' '; }
                    else if (c == '"' || c == '\'') quote = c;
                    else if (c == '>') break;
                    j++;
                }
                if (j >= n) break;
                String inner = s.substring(lt + 1, j);
                i = j + 1;
                if (inner.startsWith("/")) { h.end(localOrFull(ktTrim(inner.substring(1)), stripPrefix)); continue; }
                boolean selfClosing = false;
                if (inner.endsWith("/")) { selfClosing = true; inner = inner.substring(0, inner.length() - 1); }
                int k = 0;
                while (k < inner.length() && !isWs(inner.charAt(k))) k++;
                String name = localOrFull(inner.substring(0, k), stripPrefix);
                Map<String, String> attrs = new LinkedHashMap<>();
                if (k < inner.length()) {
                    Matcher m = ATTR.matcher(inner.substring(k));
                    while (m.find()) {
                        String v = m.group(2) != null ? m.group(2) : (m.group(3) != null ? m.group(3) : "");
                        attrs.put(m.group(1), xmlDecode(v));
                    }
                }
                h.start(name, attrs);
                if (selfClosing) h.end(name);
            }
        }
    }

    static int toInt(String s, int dflt) { if (s == null) return dflt; try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return dflt; } }
    static Integer toIntOrNull(String s) { if (s == null) return null; try { return Integer.parseInt(s.trim()); } catch (NumberFormatException e) { return null; } }
    static Double toDoubleOrNull(String s) { if (s == null) return null; try { return Double.valueOf(s.trim()); } catch (NumberFormatException e) { return null; } }
    static BigDecimal toBigOrNull(String s) { if (s == null) return null; try { return new BigDecimal(s.trim()); } catch (NumberFormatException e) { return null; } }

    // ------------------------------------------------------------------------------------------------- ODT
    static final Set<String> ODT_SKIP = new HashSet<>(Arrays.asList(
        "office:automatic-styles", "office:font-face-decls", "office:scripts", "text:tracked-changes", "text:note", "office:annotation",
        "text:table-of-content", "text:alphabetical-index", "text:bibliography", "text:user-index", "text:illustration-index", "text:table-index", "text:object-index"));

    static Map<String, Map<Integer, Boolean>> odfListKinds(String... docs) {
        Map<String, Map<Integer, Boolean>> kinds = new HashMap<>();
        for (String doc : docs) {
            if (doc.isEmpty()) continue;
            String[] cur = {null};
            scanXml(doc, new XmlHandler() {
                void start(String name, Map<String, String> attrs) {
                    switch (name) {
                        case "text:list-style": cur[0] = attrs.get("style:name"); break;
                        case "text:list-level-style-number": if (cur[0] != null) kinds.computeIfAbsent(cur[0], k -> new HashMap<>()).put(toInt(attrs.get("text:level"), 1), true); break;
                        case "text:list-level-style-bullet": case "text:list-level-style-image": if (cur[0] != null) kinds.computeIfAbsent(cur[0], k -> new HashMap<>()).put(toInt(attrs.get("text:level"), 1), false); break;
                    }
                }
                void end(String name) { if (name.equals("text:list-style")) cur[0] = null; }
            }, false);
        }
        return kinds;
    }

    static class OdtPara { String kind, style; int level; StringBuilder sb = new StringBuilder(); OdtPara(String k, int l, String s) { kind = k; level = l; style = s; } }

    static String lineText(String s) {
        StringBuilder b = new StringBuilder(); String[] ls = ktLines(s);
        for (int i = 0; i < ls.length; i++) { if (i > 0) b.append('\n'); b.append(collapse(ls[i])); }
        return ktTrim(b.toString());
    }

    static List<Block> blocksFromOdtXml(String content, String styles) {
        Map<String, Map<Integer, Boolean>> listKinds = odfListKinds(content, styles);
        List<Block> out = new ArrayList<>();
        int[] skip = {0, 0};                         // [0] = profundidad dentro de un elemento omitido, [1] = tableDepth
        List<String> lists = new ArrayList<>();
        List<boolean[]> itemUsed = new ArrayList<>();
        List<OdtPara> paras = new ArrayList<>();
        List<String>[] cells = new List[]{new ArrayList<String>()};
        StringBuilder[] cell = {new StringBuilder()};
        scanXml(content, new XmlHandler() {
            void start(String name, Map<String, String> attrs) {
                if (skip[0] > 0) { skip[0]++; return; }
                if (ODT_SKIP.contains(name)) { skip[0] = 1; return; }
                switch (name) {
                    case "text:list": lists.add(attrs.containsKey("text:style-name") ? attrs.get("text:style-name") : (lists.isEmpty() ? null : lists.get(lists.size() - 1))); break;
                    case "text:list-item": case "text:list-header": itemUsed.add(new boolean[]{false}); break;
                    case "text:h": { int lv = toInt(attrs.get("text:outline-level"), 1); paras.add(new OdtPara("H", Math.max(1, Math.min(6, lv)), "")); break; }
                    case "text:p": paras.add(new OdtPara("P", 0, attrs.containsKey("text:style-name") ? attrs.get("text:style-name") : "")); break;
                    case "text:s": case "text:tab": if (!paras.isEmpty()) paras.get(paras.size() - 1).sb.append(' '); break;
                    case "text:line-break": if (!paras.isEmpty()) paras.get(paras.size() - 1).sb.append('\n'); break;
                    case "table:table": skip[1]++; if (skip[1] == 1) cells[0] = new ArrayList<>(); break;
                    case "table:table-row": if (skip[1] == 1) cells[0] = new ArrayList<>(); break;
                    case "table:table-cell": if (skip[1] == 1) cell[0] = new StringBuilder(); break;
                }
            }
            void end(String name) {
                if (skip[0] > 0) { skip[0]--; return; }
                switch (name) {
                    case "text:list": if (!lists.isEmpty()) lists.remove(lists.size() - 1); break;
                    case "text:list-item": case "text:list-header": if (!itemUsed.isEmpty()) itemUsed.remove(itemUsed.size() - 1); break;
                    case "text:h": case "text:p": {
                        if (paras.isEmpty()) return;
                        OdtPara p = paras.remove(paras.size() - 1);
                        String text = lineText(p.sb.toString());
                        if (text.isEmpty()) return;
                        if (skip[1] > 0) {
                            if (cell[0].length() > 0) cell[0].append(' ');
                            cell[0].append(text.replace('\n', ' '));
                            return;
                        }
                        int depth = lists.size();
                        if (p.kind.equals("H")) out.add(new Block("H", p.level, collapse(text)));
                        else if (p.style.equalsIgnoreCase("Title")) out.add(new Block("H", 1, collapse(text)));
                        else if (depth > 0 && !itemUsed.isEmpty() && !itemUsed.get(itemUsed.size() - 1)[0]) {
                            itemUsed.get(itemUsed.size() - 1)[0] = true;
                            String ls = lists.get(lists.size() - 1);
                            Map<Integer, Boolean> m = listKinds.get(ls == null ? "" : ls);
                            boolean numbered = m != null && Boolean.TRUE.equals(m.get(depth));
                            out.add(new Block("LI", depth, text, numbered ? "#" : "\u2022"));
                        } else out.add(new Block("P", 0, text));
                        break;
                    }
                    case "table:table-cell": if (skip[1] == 1) cells[0].add(collapse(cell[0].toString())); break;
                    case "table:table-row": if (skip[1] == 1) { boolean any = false; for (String c : cells[0]) if (!c.isEmpty()) any = true; if (any) out.add(new Block("ROW", 0, String.join(" | ", cells[0]))); } break;
                    case "table:table": if (skip[1] > 0) skip[1]--; break;
                }
            }
            void text(String t) { if (skip[0] == 0 && !paras.isEmpty()) paras.get(paras.size() - 1).sb.append(t); }
        }, false);
        return out;
    }

    static List<Block> blocksFromOdt(InputStream in) throws IOException {
        Map<String, String> t = zipTexts(in, nm -> nm.equals("content.xml") || nm.equals("styles.xml"));
        if (t == null || !t.containsKey("content.xml")) return new ArrayList<>();
        return blocksFromOdtXml(t.get("content.xml"), t.getOrDefault("styles.xml", ""));
    }

    // ------------------------------------------------------------------------------------------------- PPTX
    static class PptxPara { int level, bullet; StringBuilder sb = new StringBuilder(); PptxPara(int l, int b) { level = l; bullet = b; } }
    static final Set<String> PPTX_SKIP_PH = new HashSet<>(Arrays.asList("sldNum", "dt", "ftr", "hdr"));

    static List<Block> blocksFromPptxSlide(String xml, String label) {
        String[] title = {null};
        List<Block> body = new ArrayList<>();
        int[] st = {0, 0, 0};                         // skip, spDepth, tblDepth
        String[] phType = {null};
        boolean[] hasPh = {false, false, false};      // hasPh, inCell, inT
        List<PptxPara> shapeParas = new ArrayList<>();
        PptxPara[] para = {null};
        List<String>[] cells = new List[]{new ArrayList<String>()};
        StringBuilder[] cell = {new StringBuilder()};
        scanXml(xml, new XmlHandler() {
            void start(String name, Map<String, String> attrs) {
                if (st[0] > 0) { st[0]++; return; }
                if (name.equals("mc:Fallback")) { st[0] = 1; return; }
                switch (name) {
                    case "p:sp": st[1]++; if (st[1] == 1) { phType[0] = null; hasPh[0] = false; shapeParas.clear(); } break;
                    case "p:ph": if (st[1] == 1) { hasPh[0] = true; phType[0] = attrs.get("type"); } break;
                    case "a:tbl": st[2]++; break;
                    case "a:tr": if (st[2] == 1) cells[0] = new ArrayList<>(); break;
                    case "a:tc": if (st[2] == 1) { cell[0] = new StringBuilder(); String h = attrs.get("hMerge"), v = attrs.get("vMerge"); hasPh[1] = !("1".equals(h) || "1".equals(v) || "true".equals(h) || "true".equals(v)); } break;
                    case "a:p": para[0] = new PptxPara(0, -1); break;
                    case "a:pPr": if (para[0] != null) para[0].level = Math.max(0, Math.min(8, toInt(attrs.get("lvl"), 0))); break;
                    case "a:buNone": if (para[0] != null) para[0].bullet = 0; break;
                    case "a:buChar": if (para[0] != null) para[0].bullet = 1; break;
                    case "a:buAutoNum": if (para[0] != null) para[0].bullet = 2; break;
                    case "a:br": if (para[0] != null) para[0].sb.append('\n'); break;
                    case "a:t": hasPh[2] = true; break;
                }
            }
            void end(String name) {
                if (st[0] > 0) { st[0]--; return; }
                switch (name) {
                    case "a:t": hasPh[2] = false; break;
                    case "a:p": {
                        PptxPara p = para[0];
                        if (p == null) return;
                        para[0] = null;
                        String text = lineText(p.sb.toString());
                        if (st[2] > 0) {
                            if (hasPh[1] && !text.isEmpty()) { if (cell[0].length() > 0) cell[0].append(' '); cell[0].append(text.replace('\n', ' ')); }
                        } else if (st[1] > 0 && !text.isEmpty()) { PptxPara q = new PptxPara(p.level, p.bullet); q.sb.append(text); shapeParas.add(q); }
                        break;
                    }
                    case "a:tc": if (st[2] == 1 && hasPh[1]) { cells[0].add(collapse(cell[0].toString())); hasPh[1] = false; } break;
                    case "a:tr": if (st[2] == 1) { boolean any = false; for (String c : cells[0]) if (!c.isEmpty()) any = true; if (any) body.add(new Block("ROW", 0, String.join(" | ", cells[0]))); } break;
                    case "a:tbl": if (st[2] > 0) st[2]--; break;
                    case "p:sp": if (st[1] > 0) {
                        st[1]--;
                        if (st[1] == 0) {
                            String t = phType[0];
                            if (hasPh[0] && (("title").equals(t) || ("ctrTitle").equals(t))) {
                                StringBuilder j = new StringBuilder();
                                for (int k = 0; k < shapeParas.size(); k++) { if (k > 0) j.append(' '); j.append(shapeParas.get(k).sb); }
                                String joined = collapse(j.toString());
                                if (!joined.isEmpty()) title[0] = title[0] == null ? joined : title[0] + " " + joined;
                            } else if (hasPh[0] && t != null && PPTX_SKIP_PH.contains(t)) {
                            } else for (PptxPara p : shapeParas) {
                                String text = p.sb.toString();
                                boolean bodyPh = hasPh[0] && !"subTitle".equals(t);
                                boolean listItem = bodyPh ? p.bullet != 0 : p.bullet > 0;
                                if (listItem) body.add(new Block("LI", p.level + 1, text, p.bullet == 2 ? "#" : "\u2022"));
                                else body.add(new Block("P", 0, text));
                            }
                        }
                    } break;
                }
            }
            void text(String t) { if (hasPh[2] && para[0] != null) para[0].sb.append(t); }
        }, false);
        List<Block> out = new ArrayList<>();
        if (title[0] == null && body.isEmpty()) return out;
        out.add(new Block("H", 2, title[0] != null ? title[0] : label));
        out.addAll(body);
        return out;
    }

    static final Pattern SLD_NUM = Pattern.compile("slide([0-9]+)\\.xml$");

    static List<Block> blocksFromPptx(InputStream in) throws IOException {
        Map<String, String> t = zipTexts(in, nm -> nm.equals("ppt/presentation.xml") || nm.equals("ppt/_rels/presentation.xml.rels") || (nm.startsWith("ppt/slides/slide") && nm.endsWith(".xml")));
        if (t == null) return new ArrayList<>();
        List<String> order = new ArrayList<>();
        String pres = t.get("ppt/presentation.xml"), rels = t.get("ppt/_rels/presentation.xml.rels");
        if (pres != null && rels != null) {
            Map<String, String> targets = new HashMap<>();
            scanXml(rels, new XmlHandler() {
                void start(String name, Map<String, String> attrs) {
                    if (name.equals("Relationship")) { String id = attrs.get("Id"), target = attrs.get("Target"); if (id != null && target != null) targets.put(id, target.startsWith("/") ? target.substring(1) : "ppt/" + target); }
                }
            }, false);
            scanXml(pres, new XmlHandler() {
                void start(String name, Map<String, String> attrs) {
                    if (name.equals("p:sldId")) { String id = attrs.get("r:id"); if (id != null && targets.containsKey(id)) order.add(targets.get(id)); }
                }
            }, false);
        }
        List<String> slides = new ArrayList<>();
        for (String o : order) if (t.containsKey(o)) slides.add(o);
        if (slides.isEmpty()) {
            for (String k : t.keySet()) if (SLD_NUM.matcher(k).find()) slides.add(k);
            slides.sort(Comparator.comparingInt(k -> { Matcher m = SLD_NUM.matcher(k); m.find(); return Integer.parseInt(m.group(1)); }));
        }
        List<Block> out = new ArrayList<>();
        for (int i = 0; i < slides.size(); i++) { String x = t.get(slides.get(i)); if (x != null) out.addAll(blocksFromPptxSlide(x, "Slide " + (i + 1))); }
        return out;
    }

    // ------------------------------------------------------------------------------------------------- XLSX
    static String builtinFormat(int id) {
        switch (id) {
            case 1: return "0";
            case 2: return "0.00";
            case 3: return "#,##0";
            case 4: return "#,##0.00";
            case 9: return "0%";
            case 10: return "0.00%";
            case 14: case 15: case 16: case 17: case 27: case 28: case 29: case 30: case 31: case 36: case 50: case 51: case 54: case 57: case 58: return "yyyy-mm-dd";
            case 18: case 20: case 32: case 34: case 52: case 55: return "hh:mm";
            case 19: case 21: case 33: case 35: case 45: case 47: case 53: case 56: return "hh:mm:ss";
            case 46: return "[h]:mm:ss";
            case 22: return "yyyy-mm-dd hh:mm";
            default: return "General";
        }
    }

    static class DateFmt { boolean hasDate, hasTime, seconds, elapsed; DateFmt(boolean d, boolean t, boolean s, boolean e) { hasDate = d; hasTime = t; seconds = s; elapsed = e; } }
    static final Pattern FMT_STRIP = Pattern.compile("\"[^\"]*\"|\\\\.|_.|\\*.");
    static final Pattern FMT_BRACKET = Pattern.compile("\\[([^\\]]*)\\]");

    static DateFmt classifyDate(String code) {
        boolean elapsed = false;
        String c = FMT_STRIP.matcher(code).replaceAll("");
        Matcher m = FMT_BRACKET.matcher(c);
        StringBuilder sb = new StringBuilder();
        int last = 0;
        while (m.find()) {
            sb.append(c, last, m.start());
            String k = m.group(1).toLowerCase(Locale.ROOT);
            if (k.equals("h") || k.equals("hh") || k.equals("m") || k.equals("mm") || k.equals("s") || k.equals("ss")) { elapsed = true; sb.append(k.charAt(0)); }
            last = m.end();
        }
        sb.append(c.substring(last));
        String l = sb.toString().toLowerCase(Locale.ROOT);
        boolean yd = l.indexOf('y') >= 0 || l.indexOf('d') >= 0;
        boolean hs = l.indexOf('h') >= 0 || l.indexOf('s') >= 0;
        boolean hasDate = yd || (l.indexOf('m') >= 0 && !hs && !elapsed);
        boolean hasTime = hs || elapsed;
        if (!hasDate && !hasTime) return null;
        return new DateFmt(hasDate, hasTime, l.indexOf('s') >= 0, elapsed);
    }

    static String pad(int n, int width) { String s = Integer.toString(n); StringBuilder b = new StringBuilder(); for (int i = s.length(); i < width; i++) b.append('0'); return b + s; }

    static int[] civil(long daysSinceEpoch) {
        long z = daysSinceEpoch + 719468;
        long era = Math.floorDiv(z, 146097L);
        long doe = z - era * 146097;
        long yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
        long y = yoe + era * 400;
        long doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
        long mp = (5 * doy + 2) / 153;
        long d = doy - (153 * mp + 2) / 5 + 1;
        long m = mp < 10 ? mp + 3 : mp - 9;
        return new int[]{(int) (y + (m <= 2 ? 1 : 0)), (int) m, (int) d};
    }

    static String excelDate(long days, boolean date1904) {
        if (!date1904) { if (days == 60) return "1900-02-29"; if (days == 0) return "1900-01-00"; }
        long epoch = date1904 ? days - 24107 : (days < 60 ? days - 25568 : days - 25569);
        int[] c = civil(epoch);
        return pad(c[0], 4) + "-" + pad(c[1], 2) + "-" + pad(c[2], 2);
    }

    static String serialToText(double v, DateFmt f, boolean date1904) {
        if (f.elapsed && !f.hasDate) {
            long total = Math.round(v * 86400);
            return (total / 3600) + ":" + pad((int) ((total / 60) % 60), 2) + ":" + pad((int) (total % 60), 2);
        }
        long days = (long) Math.floor(v);
        long secs = Math.round((v - days) * 86400);
        if (secs >= 86400) { days++; secs -= 86400; }
        StringBuilder sb = new StringBuilder();
        if (f.hasDate) sb.append(excelDate(days, date1904));
        if (f.hasTime) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(pad((int) (secs / 3600), 2)).append(':').append(pad((int) ((secs / 60) % 60), 2));
            if (f.seconds || secs % 60 != 0) sb.append(':').append(pad((int) (secs % 60), 2));
        }
        return sb.toString();
    }

    static String generalNumber(String raw) {
        BigDecimal bd = toBigOrNull(raw);
        if (bd == null) return raw;
        if (bd.signum() == 0) return "0";
        BigDecimal r = bd.round(new MathContext(15, RoundingMode.HALF_UP)).stripTrailingZeros();
        BigDecimal abs = r.abs();
        return (abs.compareTo(new BigDecimal("1E15")) >= 0 || abs.compareTo(new BigDecimal("1E-9")) < 0) ? r.toString() : r.toPlainString();
    }

    static List<String> splitSections(String code) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean quoted = false;
        int i = 0;
        while (i < code.length()) {
            char c = code.charAt(i);
            if (c == '"') quoted = !quoted;
            if (c == '\\' && i + 1 < code.length()) { cur.append(c).append(code.charAt(i + 1)); i += 2; continue; }
            if (c == ';' && !quoted) { out.add(cur.toString()); cur.setLength(0); } else cur.append(c);
            i++;
        }
        out.add(cur.toString());
        return out;
    }

    static int count(String s, char ch) { int n = 0; for (int i = 0; i < s.length(); i++) if (s.charAt(i) == ch) n++; return n; }

    static String formatNumber(String raw, String code) {
        BigDecimal bd = toBigOrNull(raw);
        if (bd == null) return null;
        List<String> sections = splitSections(code);
        boolean neg = bd.signum() < 0;
        String sec = (neg && sections.size() >= 2) ? sections.get(1) : (bd.signum() == 0 && sections.size() >= 3) ? sections.get(2) : sections.get(0);
        StringBuilder prefix = new StringBuilder(), suffix = new StringBuilder(), core = new StringBuilder();
        boolean percent = false;
        int stage = 0;
        int i = 0;
        while (i < sec.length()) {
            char c = sec.charAt(i);
            String lit = null;
            if (c == '"') {
                int e = sec.indexOf('"', i + 1);
                if (e < 0) return null;
                lit = sec.substring(i + 1, e); i = e;
            } else if (c == '\\' && i + 1 < sec.length()) { lit = String.valueOf(sec.charAt(i + 1)); i++; }
            else if (c == '_' && i + 1 < sec.length()) { lit = " "; i++; }
            else if (c == '*' && i + 1 < sec.length()) { i++; }
            else if (c == '[') {
                int e = sec.indexOf(']', i + 1);
                if (e < 0) return null;
                String inner = sec.substring(i + 1, e);
                if (inner.startsWith("$")) { String t = inner.substring(1); int d = t.indexOf('-'); lit = d >= 0 ? t.substring(0, d) : t; }
                else if (inner.startsWith("<") || inner.startsWith(">") || inner.startsWith("=")) return null;
                i = e;
            } else if (c == '0' || c == '#' || c == '?' || c == '.' || c == ',') {
                if (stage == 2) return null;
                stage = 1; core.append(c);
            } else if (c == '%') { percent = true; lit = "%"; }
            else if (c == ' ' || c == '-' || c == '+' || c == '(' || c == ')' || c == ':' || c == '$' || c == '\u20AC' || c == '\u00A3' || c == '\u00A5' || c == '\u20AB') lit = String.valueOf(c);
            else return null;
            if (lit != null) { if (stage == 1) stage = 2; (stage == 0 ? prefix : suffix).append(lit); }
            i++;
        }
        String spec = core.toString();
        if (spec.isEmpty() || spec.endsWith(",") || spec.contains(",.") || count(spec, '.') > 1) return null;
        String intSpec = spec.contains(".") ? spec.substring(0, spec.indexOf('.')) : spec;
        String fracSpec = spec.contains(".") ? spec.substring(spec.indexOf('.') + 1) : "";
        if (fracSpec.contains(",")) return null;
        int minInt = count(intSpec, '0');
        boolean grouping = intSpec.contains(",");
        int decimals = fracSpec.length();
        int mandatory = count(fracSpec, '0');
        BigDecimal v = neg ? bd.abs() : bd;
        if (percent) v = v.multiply(new BigDecimal(100));
        String plain = v.setScale(decimals, RoundingMode.HALF_UP).toPlainString();
        String intPart = plain.contains(".") ? plain.substring(0, plain.indexOf('.')) : plain;
        String frac = plain.contains(".") ? plain.substring(plain.indexOf('.') + 1) : "";
        while (frac.length() > mandatory && frac.endsWith("0")) frac = frac.substring(0, frac.length() - 1);
        if (intPart.equals("0") && minInt == 0 && !frac.isEmpty()) intPart = "";
        while (intPart.length() < minInt) intPart = "0" + intPart;
        if (grouping && intPart.length() > 3) {
            StringBuilder g = new StringBuilder();
            for (int k = 0; k < intPart.length(); k++) { if (k > 0 && (intPart.length() - k) % 3 == 0) g.append(','); g.append(intPart.charAt(k)); }
            intPart = g.toString();
        }
        String body = prefix + intPart + (frac.isEmpty() ? "" : "." + frac) + suffix;
        return (neg && sections.size() < 2) ? "-" + body : body;
    }

    static List<String> xlsxStyleCodes(String styles) {
        Map<Integer, String> custom = new HashMap<>();
        List<Integer> ids = new ArrayList<>();
        boolean[] inCellXfs = {false};
        scanXml(styles, new XmlHandler() {
            void start(String name, Map<String, String> attrs) {
                switch (name) {
                    case "numFmt": { Integer id = toIntOrNull(attrs.get("numFmtId")); String code = attrs.get("formatCode"); if (id != null && code != null) custom.put(id, code); break; }
                    case "cellXfs": inCellXfs[0] = true; break;
                    case "xf": if (inCellXfs[0]) ids.add(toInt(attrs.get("numFmtId"), 0)); break;
                }
            }
            void end(String name) { if (name.equals("cellXfs")) inCellXfs[0] = false; }
        }, true);
        List<String> out = new ArrayList<>();
        for (int id : ids) out.add(custom.containsKey(id) ? custom.get(id) : builtinFormat(id));
        return out;
    }

    static List<String> xlsxSharedStrings(String xml) {
        List<String> out = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        boolean[] f = {false, false};   // inSi, inT
        int[] phonetic = {0};
        scanXml(xml, new XmlHandler() {
            void start(String name, Map<String, String> attrs) {
                switch (name) { case "si": f[0] = true; sb.setLength(0); break; case "rPh": phonetic[0]++; break; case "t": f[1] = true; break; }
            }
            void end(String name) {
                switch (name) { case "t": f[1] = false; break; case "rPh": phonetic[0]--; break; case "si": out.add(sb.toString()); f[0] = false; break; }
            }
            void text(String t) { if (f[0] && f[1] && phonetic[0] == 0) sb.append(t); }
        }, true);
        return out;
    }

    static int columnIndex(String ref) {
        int n = 0, letters = 0;
        for (int i = 0; i < ref.length(); i++) {
            char ch = ref.charAt(i);
            if (ch >= 'A' && ch <= 'Z') { n = n * 26 + (ch - 'A' + 1); letters++; }
            else if (ch >= 'a' && ch <= 'z') { n = n * 26 + (ch - 'a' + 1); letters++; }
            else break;
        }
        return letters == 0 ? -1 : n - 1;
    }

    static final int MAX_ROWS = 100000, MAX_COLS = 1024;

    static List<List<String>> xlsxRows(String xml, List<String> sst, List<String> codes, List<DateFmt> dates, boolean date1904) {
        List<List<String>> rows = new ArrayList<>();
        List<String>[] row = new List[]{new ArrayList<String>()};
        int[] st = {0, 0, 0};                 // col, style, phonetic
        String[] type = {""};
        StringBuilder v = new StringBuilder(), inline = new StringBuilder();
        boolean[] f = {false, false, false};  // inV, inIs, inT
        scanXml(xml, new XmlHandler() {
            void start(String name, Map<String, String> attrs) {
                switch (name) {
                    case "row": row[0] = new ArrayList<>(); break;
                    case "c": {
                        int ci = attrs.get("r") != null ? columnIndex(attrs.get("r")) : -1;
                        st[0] = ci >= 0 ? ci : row[0].size();
                        type[0] = attrs.get("t") != null ? attrs.get("t") : "";
                        st[1] = toInt(attrs.get("s"), 0);
                        v.setLength(0); inline.setLength(0);
                        break;
                    }
                    case "v": f[0] = true; break;
                    case "is": f[1] = true; break;
                    case "rPh": st[2]++; break;
                    case "t": if (f[1]) f[2] = true; break;
                }
            }
            void end(String name) {
                switch (name) {
                    case "v": f[0] = false; break;
                    case "is": f[1] = false; break;
                    case "t": f[2] = false; break;
                    case "rPh": st[2]--; break;
                    case "c": {
                        if (st[0] >= MAX_COLS) return;
                        String raw = ktTrim(v.toString());
                        String text;
                        switch (type[0]) {
                            case "s": { Integer ix = toIntOrNull(raw); text = (ix != null && ix >= 0 && ix < sst.size()) ? sst.get(ix) : ""; break; }
                            case "str": case "e": case "d": text = v.toString(); break;
                            case "inlineStr": text = inline.toString(); break;
                            case "b": text = raw.isEmpty() ? "" : raw.equals("1") ? "TRUE" : "FALSE"; break;
                            default:
                                if (raw.isEmpty()) text = "";
                                else {
                                    DateFmt d = st[1] >= 0 && st[1] < dates.size() ? dates.get(st[1]) : null;
                                    Double dv = toDoubleOrNull(raw);
                                    if (d != null && dv != null) text = serialToText(dv, d, date1904);
                                    else {
                                        String code = st[1] >= 0 && st[1] < codes.size() ? codes.get(st[1]) : "General";
                                        if (code.equals("General")) text = generalNumber(raw);
                                        else { String fm = formatNumber(raw, code); text = fm != null ? fm : generalNumber(raw); }
                                    }
                                }
                        }
                        while (row[0].size() < st[0]) row[0].add("");
                        if (row[0].size() == st[0]) row[0].add(text); else row[0].set(st[0], text);
                        break;
                    }
                    case "row": {
                        int last = row[0].size();
                        while (last > 0 && row[0].get(last - 1).isEmpty()) last--;
                        if (last > 0 && rows.size() < MAX_ROWS) rows.add(new ArrayList<>(row[0].subList(0, last)));
                        break;
                    }
                }
            }
            void text(String t) {
                if (f[0]) v.append(t);
                else if (f[1] && f[2] && st[2] == 0) inline.append(t);
            }
        }, true);
        return rows;
    }

    static String relId(Map<String, String> attrs) { for (Map.Entry<String, String> e : attrs.entrySet()) if (e.getKey().endsWith(":id")) return e.getValue(); return null; }

    static List<Sheet> sheetsFromXlsx(InputStream in) throws IOException {
        Map<String, String> t = zipTexts(in, nm -> nm.equals("xl/workbook.xml") || nm.equals("xl/_rels/workbook.xml.rels") || nm.equals("xl/sharedStrings.xml") || nm.equals("xl/styles.xml") || (nm.startsWith("xl/worksheets/") && nm.endsWith(".xml")));
        if (t == null || !t.containsKey("xl/workbook.xml")) return new ArrayList<>();
        Map<String, String> rels = new HashMap<>();
        if (t.containsKey("xl/_rels/workbook.xml.rels")) scanXml(t.get("xl/_rels/workbook.xml.rels"), new XmlHandler() {
            void start(String name, Map<String, String> attrs) {
                if (name.equals("Relationship")) { String id = attrs.get("Id"), target = attrs.get("Target"); if (id != null && target != null) rels.put(id, target.startsWith("/") ? target.substring(1) : "xl/" + target); }
            }
        }, true);
        List<String[]> refs = new ArrayList<>();
        boolean[] d1904 = {false};
        scanXml(t.get("xl/workbook.xml"), new XmlHandler() {
            void start(String name, Map<String, String> attrs) {
                if (name.equals("workbookPr")) d1904[0] = "1".equals(attrs.get("date1904")) || "true".equals(attrs.get("date1904"));
                else if (name.equals("sheet")) {
                    String stt = attrs.get("state");
                    if (!"hidden".equals(stt) && !"veryHidden".equals(stt)) { String rid = relId(attrs); refs.add(new String[]{attrs.getOrDefault("name", ""), rid == null ? null : rels.get(rid)}); }
                }
            }
        }, true);
        List<String> sst = t.containsKey("xl/sharedStrings.xml") ? xlsxSharedStrings(t.get("xl/sharedStrings.xml")) : new ArrayList<>();
        List<String> codes = t.containsKey("xl/styles.xml") ? xlsxStyleCodes(t.get("xl/styles.xml")) : new ArrayList<>();
        List<DateFmt> dates = new ArrayList<>();
        for (String c : codes) dates.add(classifyDate(c));
        List<Sheet> out = new ArrayList<>();
        for (String[] r : refs) {
            String xml = r[1] == null ? null : t.get(r[1]);
            if (xml == null) continue;
            List<List<String>> rows = xlsxRows(xml, sst, codes, dates, d1904[0]);
            if (!rows.isEmpty()) out.add(new Sheet(r[0], rows));
        }
        return out;
    }

    // ------------------------------------------------------------------------------------------------- RTF
    static final Set<String> RTF_SKIP = new HashSet<>(Arrays.asList(
        "colortbl", "info", "header", "headerl", "headerr", "headerf", "footer", "footerl", "footerr", "footerf", "pict", "object", "fldinst", "listtable",
        "listoverridetable", "rsidtbl", "generator", "revtbl", "footnote", "bkmkstart", "bkmkend", "datafield", "themedata", "colorschememapping", "latentstyles",
        "xmlnstbl", "mmathPr", "pgptbl", "protusertbl", "template", "ftnsep", "ftnsepc", "aftnsep", "aftnsepc", "private", "filetbl", "pn", "pnseclvl", "falt",
        "shpinst", "userprops", "nonshppict", "author", "operator", "factoidname", "docvar", "listname", "upr", "ud", "fchars", "lchars", "xe", "tc", "txe", "rxe"));
    static final Pattern HEADING = Pattern.compile("^heading\\s*([1-9])$", Pattern.CASE_INSENSITIVE);
    static final Pattern NUMBERED = Pattern.compile("^\\(?([0-9]+|[A-Za-z]|[ivxlcdmIVXLCDM]+)[.)]");

    static boolean isAlpha(char ch) { return (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'); }
    static boolean isDigit(char ch) { return ch >= '0' && ch <= '9'; }

    static Charset charsetForCodePage(int cp) {
        String[] names;
        switch (cp) {
            case 932: names = new String[]{"windows-31j", "Shift_JIS"}; break;
            case 936: names = new String[]{"GBK", "x-mswin-936"}; break;
            case 949: names = new String[]{"x-windows-949", "windows-949", "EUC-KR"}; break;
            case 950: names = new String[]{"x-windows-950", "Big5"}; break;
            case 1361: names = new String[]{"x-Johab"}; break;
            case 874: names = new String[]{"x-windows-874", "windows-874"}; break;
            case 10000: names = new String[]{"x-MacRoman", "MacRoman"}; break;
            default: names = new String[]{"windows-" + cp};
        }
        for (String n : names) try { return Charset.forName(n); } catch (Exception e) { }
        return Charset.forName("windows-1252");
    }

    static class Group {
        boolean skip; int uc, font; String dest; StringBuilder capture;
        Group(boolean s, int u, int f, String d, StringBuilder c) { skip = s; uc = u; font = f; dest = d; capture = c; }
        Group copy() { return new Group(skip, uc, font, dest, capture); }
    }

    static class RtfParser {
        final String rtf;
        List<Block> out = new ArrayList<>();
        List<Group> stack = new ArrayList<>();
        Group cur = new Group(false, 1, -1, null, null);
        Map<Integer, Integer> fontCharset = new HashMap<>(), fontCp = new HashMap<>();
        Map<Integer, String> styleNames = new HashMap<>();
        int docCp = 1252, fontDef = -1, styleNum = -1;
        StringBuilder styleBuf = new StringBuilder();
        StringBuilder para = new StringBuilder();
        int paraStyle = -1, outline = 0, ilvl = 0;
        String marker = null;
        boolean inRow = false;
        List<String> cells = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        int pendingSkip = 0;
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        int bytesFont = -1;

        RtfParser(String rtf) { this.rtf = rtf; }

        Charset charsetOf(int font) {
            Integer cp = fontCp.get(font);
            if (cp == null) {
                Integer cs = fontCharset.get(font);
                int v = docCp;
                if (cs != null) switch (cs) {
                    case 77: v = 10000; break; case 128: v = 932; break; case 129: v = 949; break; case 130: v = 1361; break; case 134: v = 936; break; case 136: v = 950; break;
                    case 161: v = 1253; break; case 162: v = 1254; break; case 163: v = 1258; break; case 177: v = 1255; break; case 178: v = 1256; break; case 186: v = 1257; break;
                    case 204: v = 1251; break; case 222: v = 874; break; case 238: v = 1250; break;
                }
                cp = v;
            }
            return charsetForCodePage(cp);
        }

        void emit(String s) {
            Group g = cur;
            if ("stylesheet".equals(g.dest)) { styleBuf.append(s); return; }
            if (g.skip || "fonttbl".equals(g.dest)) return;
            (g.capture != null ? g.capture : para).append(s);
        }

        void flushBytes() {
            if (bytes.size() == 0) return;
            String s = new String(bytes.toByteArray(), charsetOf(bytesFont));
            bytes.reset();
            emit(s);
        }

        void endPara() {
            flushBytes();
            String text = lineText(para.toString());
            para.setLength(0);
            int st = paraStyle, ol = outline, lv = ilvl;
            String mk = marker;
            paraStyle = -1; outline = 0; marker = null; ilvl = 0;
            if (text.isEmpty()) return;
            if (inRow) { if (cell.length() > 0) cell.append(' '); cell.append(text.replace('\n', ' ')); return; }
            String styleName = styleNames.getOrDefault(st, "");
            Matcher hm = HEADING.matcher(styleName);
            Integer heading = hm.find() ? Integer.valueOf(hm.group(1)) : null;
            int level;
            if (ol >= 1 && ol <= 9) level = Math.min(ol, 6);
            else if (heading != null) level = Math.min(heading, 6);
            else if (styleName.equalsIgnoreCase("Title")) level = 1;
            else level = 0;
            if (level > 0) out.add(new Block("H", level, collapse(text)));
            else if (mk != null) out.add(new Block("LI", lv + 1, text, NUMBERED.matcher(ktTrim(mk)).find() ? "#" : "\u2022"));
            else out.add(new Block("P", 0, text));
        }

        void startRow() { endPara(); inRow = true; cells = new ArrayList<>(); cell.setLength(0); }

        void endCell() {
            if (!inRow) { endPara(); return; }
            flushBytes();
            String text = lineText(para.toString());
            para.setLength(0);
            if (!text.isEmpty()) { if (cell.length() > 0) cell.append(' '); cell.append(text.replace('\n', ' ')); }
            cells.add(collapse(cell.toString()));
            cell.setLength(0);
            paraStyle = -1; outline = 0; marker = null; ilvl = 0;
        }

        void endRow() {
            if (!inRow) return;
            if (para.length() > 0) endCell();
            boolean any = false; for (String c : cells) if (!c.isEmpty()) any = true;
            if (any) out.add(new Block("ROW", 0, String.join(" | ", cells)));
            inRow = false;
            cells = new ArrayList<>();
        }

        void literal(char ch) {
            if ("stylesheet".equals(cur.dest)) {
                if (cur.skip) return;
                if (ch == ';') { if (styleNum >= 0) styleNames.put(styleNum, ktTrim(styleBuf.toString())); styleBuf.setLength(0); }
                else styleBuf.append(ch);
                return;
            }
            if (cur.skip || "fonttbl".equals(cur.dest)) return;
            flushBytes();
            (cur.capture != null ? cur.capture : para).append(ch);
        }

        void endGroup() {
            flushBytes();
            Group g = cur;
            StringBuilder cap = g.capture;
            if (cap != null && (stack.isEmpty() ? null : stack.get(stack.size() - 1).capture) != cap) marker = cap.toString();
            if (!stack.isEmpty()) cur = stack.remove(stack.size() - 1);
        }

        int word(String name, Integer param, int after) {
            int next = after;
            if (!name.equals("u")) pendingSkip = 0;
            if ("fonttbl".equals(cur.dest)) {
                switch (name) {
                    case "f": fontDef = param != null ? param : -1; break;
                    case "fcharset": if (param != null) fontCharset.put(fontDef, param); break;
                    case "cpg": if (param != null) fontCp.put(fontDef, param); break;
                }
                if (!name.equals("falt") && !RTF_SKIP.contains(name)) return next;
            }
            if ("stylesheet".equals(cur.dest)) {
                switch (name) {
                    case "s": styleNum = param != null ? param : -1; styleBuf.setLength(0); break;
                    case "cs": case "ds": case "ts": styleNum = -1; break;
                }
                if (!RTF_SKIP.contains(name)) return next;
            }
            switch (name) {
                case "fonttbl": cur.dest = "fonttbl"; return next;
                case "stylesheet": cur.dest = "stylesheet"; styleNum = -1; styleBuf.setLength(0); return next;
                case "listtext": case "pntext": cur.capture = new StringBuilder(); return next;
            }
            if (RTF_SKIP.contains(name)) { cur.skip = true; return next; }
            if (name.equals("bin") && param != null && param > 0) next = Math.min(rtf.length(), after + param);
            if (cur.skip) return next;
            switch (name) {
                case "par": endPara(); break;
                case "line": emit("\n"); break;
                case "tab": emit(" "); break;
                case "cell": endCell(); break;
                case "row": endRow(); break;
                case "trowd": startRow(); break;
                case "pard": if (cur.capture == null) { paraStyle = -1; outline = 0; ilvl = 0; } break;
                case "s": paraStyle = param != null ? param : -1; break;
                case "outlinelevel": outline = (param != null && param >= 0 && param <= 8) ? param + 1 : 0; break;
                case "ilvl": ilvl = param != null ? param : 0; break;
                case "f": flushBytes(); cur.font = param != null ? param : -1; break;
                case "ansicpg": docCp = param != null ? param : 1252; break;
                case "uc": cur.uc = param != null ? param : 1; break;
                case "u":
                    flushBytes();
                    if (param != null) emit(String.valueOf((char) (param < 0 ? param + 65536 : param)));
                    pendingSkip = cur.uc;
                    break;
                case "emdash": emit("\u2014"); break;
                case "endash": emit("\u2013"); break;
                case "emspace": case "enspace": case "qmspace": emit(" "); break;
                case "bullet": emit("\u2022"); break;
                case "lquote": emit("\u2018"); break;
                case "rquote": emit("\u2019"); break;
                case "ldblquote": emit("\u201C"); break;
                case "rdblquote": emit("\u201D"); break;
            }
            return next;
        }

        List<Block> run() {
            int n = rtf.length(), i = 0;
            while (i < n) {
                char c = rtf.charAt(i);
                if (c == '{') { flushBytes(); stack.add(cur.copy()); i++; }
                else if (c == '}') { endGroup(); i++; }
                else if (c == '\r' || c == '\n') i++;
                else if (c == '\\') {
                    if (i + 1 >= n) { i++; continue; }
                    char nx = rtf.charAt(i + 1);
                    if (nx == '\\' || nx == '{' || nx == '}') {
                        if (pendingSkip > 0) pendingSkip--; else literal(nx);
                        i += 2;
                    } else if (nx == '\'') {
                        Integer hex = null;
                        if (i + 4 <= n) { try { hex = Integer.parseInt(rtf.substring(i + 2, i + 4), 16); } catch (NumberFormatException e) { hex = null; } }
                        if (pendingSkip > 0) pendingSkip--;
                        else if (hex != null && !cur.skip && !"fonttbl".equals(cur.dest) && !"stylesheet".equals(cur.dest)) {
                            if (bytes.size() == 0) bytesFont = cur.font;
                            bytes.write(hex);
                        }
                        i += 4;
                    } else if (nx == '*') {
                        int j = i + 2;
                        if (j + 1 < n && rtf.charAt(j) == '\\') {
                            int k = j + 1;
                            while (k < n && isAlpha(rtf.charAt(k))) k++;
                            String name = rtf.substring(j + 1, k);
                            if (!name.equals("listtext") && !name.equals("pntext")) cur.skip = true;
                        } else cur.skip = true;
                        i = j;
                    } else if (nx == '~') { flushBytes(); if (!cur.skip) literal('\u00A0'); i += 2; }
                    else if (nx == '_') { flushBytes(); if (!cur.skip) literal('-'); i += 2; }
                    else if (nx == '-' || nx == '|' || nx == ':') i += 2;
                    else if (nx == '\r' || nx == '\n') { if (!cur.skip) endPara(); i += 2; }
                    else if (isAlpha(nx)) {
                        int k = i + 1;
                        while (k < n && isAlpha(rtf.charAt(k))) k++;
                        String name = rtf.substring(i + 1, k);
                        Integer param = null;
                        int p = k;
                        if (p < n && (rtf.charAt(p) == '-' || isDigit(rtf.charAt(p)))) {
                            p++;
                            while (p < n && isDigit(rtf.charAt(p))) p++;
                            param = toIntOrNull(rtf.substring(k, p));
                        }
                        if (p < n && rtf.charAt(p) == ' ') p++;
                        flushBytes();
                        i = word(name, param, p);
                    } else i += 2;
                } else {
                    if (pendingSkip > 0) { pendingSkip--; i++; continue; }
                    if (c >= 0x80) {
                        if (!cur.skip && !"fonttbl".equals(cur.dest) && !"stylesheet".equals(cur.dest)) { if (bytes.size() == 0) bytesFont = cur.font; bytes.write(c & 0xFF); }
                    } else literal(c);
                    i++;
                }
            }
            flushBytes();
            endRow();
            endPara();
            return out;
        }
    }

    static List<Block> blocksFromRtf(String rtf) { return new RtfParser(rtf).run(); }

    // ------------------------------------------------------------------------------------------------- CLI
    static String blocksOut(List<Block> bs) {
        StringBuilder o = new StringBuilder();
        for (Block b : bs) o.append("B|").append(b.kind).append('|').append(b.level).append('|').append(hex(b.marker)).append('|').append(hex(b.text)).append('\n');
        return o.toString();
    }

    static String sheetsOut(List<Sheet> ss) {
        StringBuilder o = new StringBuilder();
        for (Sheet s : ss) {
            o.append("S|").append(hex(s.name)).append('\n');
            for (List<String> r : s.rows) {
                o.append("R|");
                for (int i = 0; i < r.size(); i++) { if (i > 0) o.append(','); o.append(hex(r.get(i))); }
                o.append('\n');
            }
        }
        return o.toString();
    }

    public static void main(String[] a) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        String line;
        StringBuilder res = new StringBuilder();
        while ((line = in.readLine()) != null) {
            if (line.isEmpty()) continue;
            String[] p = line.split(" ", -1);
            res.append("== ").append(line.length() > 120 ? line.substring(0, 120) : line).append('\n');
            try {
                switch (p[0]) {
                    case "ODT": try (InputStream f = new FileInputStream(p[1])) { res.append(blocksOut(blocksFromOdt(f))); } break;
                    case "PPTX": try (InputStream f = new FileInputStream(p[1])) { res.append(blocksOut(blocksFromPptx(f))); } break;
                    case "XLSX": try (InputStream f = new FileInputStream(p[1])) { res.append(sheetsOut(sheetsFromXlsx(f))); } break;
                    case "RTF": { byte[] b = java.nio.file.Files.readAllBytes(new File(p[1]).toPath()); res.append(blocksOut(blocksFromRtf(new String(b, StandardCharsets.ISO_8859_1)))); break; }
                    case "RTFHEX": res.append(blocksOut(blocksFromRtf(new String(unhexBytes(p[1]), StandardCharsets.ISO_8859_1)))); break;
                    case "ODTXML": res.append(blocksOut(blocksFromOdtXml(unhex(p[1]), p.length > 2 ? unhex(p[2]) : ""))); break;
                    case "FMT": { String r = formatNumber(unhex(p[1]), unhex(p[2])); res.append(r == null ? "NULL" : "V|" + hex(r)).append('\n'); break; }
                    case "GEN": res.append("V|").append(hex(generalNumber(unhex(p[1])))).append('\n'); break;
                    case "CLS": { DateFmt d = classifyDate(unhex(p[1])); res.append(d == null ? "NONE" : (d.hasDate ? "D" : "-") + (d.hasTime ? "T" : "-") + (d.seconds ? "S" : "-") + (d.elapsed ? "E" : "-")).append('\n'); break; }
                    case "DATE": res.append(excelDate(Long.parseLong(p[1]), p[2].equals("1"))).append('\n'); break;
                    case "SER": { DateFmt d = classifyDate(unhex(p[2])); res.append(serialToText(Double.parseDouble(p[1]), d, p[3].equals("1"))).append('\n'); break; }
                    case "DATES": { long from = Long.parseLong(p[1]), to = Long.parseLong(p[2]); for (long d = from; d <= to; d++) res.append(excelDate(d, p[3].equals("1"))).append('\n'); break; }
                    case "COL": res.append(columnIndex(p[1])).append('\n'); break;
                    default: res.append("?\n");
                }
            } catch (Exception e) { res.append("ERR ").append(e).append('\n'); }
        }
        System.out.print(res);
    }
}
