import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.*;
import java.util.zip.*;
import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

/**
 * Java twin of app/.../util/ZipPack.kt (same algorithm, same constants, same order of operations) so tools/verify/zip_pack_check.py
 * can run it on a JVM. Commands (all output is plain text / files, read back by the Python check):
 *   names   <name>...                      -> one resulting entry name per line
 *   store   <name>...                      -> "name true|false"
 *   dos     <millis> <tz-id>               -> "time date"
 *   pbkdf2  <passwordHex> <saltHex> <iter> <len> -> hex
 *   pack    <out.zip> <password|-> <seedHex> <tz> <file>... -> writes the ZIP (names via entryNames of the base names)
 */
public class ZipPackCheck {
    static final int AES_KEY = 32, SALT = 16, ITER = 1000, MAC_BYTES = 10, CHUNK = 64 * 1024;
    static final Set<String> STORED = new HashSet<>(Arrays.asList("pdf","jpg","jpeg","png","webp","epub","zip","docx","xlsx","pptx","cbz","mp4","gz","7z"));

    static boolean shouldStore(String name) {
        int d = name.lastIndexOf('.');
        String ext = d < 0 ? "" : name.substring(d + 1).toLowerCase(Locale.ROOT);
        return STORED.contains(ext);
    }

    static List<String> entryNames(List<String> names) {
        Set<String> used = new HashSet<>();
        List<String> out = new ArrayList<>();
        for (String raw : names) {
            String s = raw.substring(raw.lastIndexOf('/') + 1);
            s = s.substring(s.lastIndexOf('\\') + 1);
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.length(); i++) {
                char c = s.charAt(i);
                sb.append((c < 32 || c == ':' || c == '*' || c == '?' || c == '"' || c == '<' || c == '>' || c == '|') ? '_' : c);
            }
            String base = sb.toString().trim();   // String.trim() = chars <= U+0020, same as Kotlin trim { it.code <= 32 }
            while (base.startsWith(".")) base = base.substring(1);
            while (base.endsWith(".")) base = base.substring(0, base.length() - 1);
            if (base.isEmpty()) base = "file";
            String cand = base; int n = 2;
            while (!used.add(cand.toLowerCase(Locale.ROOT))) {
                int dot = base.lastIndexOf('.');
                cand = dot > 0 ? base.substring(0, dot) + " (" + n + ")" + base.substring(dot) : base + " (" + n + ")";
                n++;
            }
            out.add(cand);
        }
        return out;
    }

    static int[] dos(long millis, TimeZone tz) {
        Calendar c = Calendar.getInstance(tz); c.setTimeInMillis(millis);
        int year = c.get(Calendar.YEAR);
        if (year < 1980) return new int[]{0, (1 << 5) | 1};
        int date = ((year - 1980) << 9) | ((c.get(Calendar.MONTH) + 1) << 5) | c.get(Calendar.DAY_OF_MONTH);
        int time = (c.get(Calendar.HOUR_OF_DAY) << 11) | (c.get(Calendar.MINUTE) << 5) | (c.get(Calendar.SECOND) / 2);
        return new int[]{time, date};
    }

    static byte[] pbkdf2(byte[] pw, byte[] salt, int iterations, int dkLen) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA1"); mac.init(new SecretKeySpec(pw, "HmacSHA1"));
        int hLen = mac.getMacLength(), blocks = (dkLen + hLen - 1) / hLen;
        byte[] out = new byte[dkLen];
        for (int i = 1; i <= blocks; i++) {
            mac.update(salt);
            mac.update(new byte[]{(byte)(i >>> 24), (byte)(i >>> 16), (byte)(i >>> 8), (byte) i});
            byte[] u = mac.doFinal(); byte[] t = u.clone();
            for (int j = 2; j <= iterations; j++) { u = mac.doFinal(u); for (int k = 0; k < t.length; k++) t[k] ^= u[k]; }
            int start = (i - 1) * hLen;
            System.arraycopy(t, 0, out, start, Math.min(hLen, dkLen - start));
        }
        return out;
    }

    static class Ctr {
        final Cipher cipher; final byte[] counter = new byte[16]; byte[] stream = new byte[16]; int used = 16;
        Ctr(byte[] key) throws Exception { cipher = Cipher.getInstance("AES/ECB/NoPadding"); cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES")); counter[0] = 1; }
        void process(byte[] b, int off, int len) throws Exception {
            for (int i = off; i < off + len; i++) {
                if (used == 16) {
                    stream = cipher.doFinal(counter);
                    for (int k = 0; k < 16; k++) { counter[k]++; if (counter[k] != 0) break; }
                    used = 0;
                }
                b[i] ^= stream[used++];
            }
        }
    }

    static byte[] le16(int v) { return new byte[]{(byte) v, (byte)(v >>> 8)}; }
    static byte[] le32(long v) { return new byte[]{(byte) v, (byte)(v >>> 8), (byte)(v >>> 16), (byte)(v >>> 24)}; }
    static byte[] cat(byte[]... parts) { ByteArrayOutputStream o = new ByteArrayOutputStream(); for (byte[] p : parts) o.write(p, 0, p.length); return o.toByteArray(); }
    static byte[] extra(int realMethod) { return cat(le16(0x9901), le16(7), le16(2), new byte[]{'A', 'E', 3}, le16(realMethod)); }

    static void writePlain(List<File> files, List<String> names, File out) throws Exception {
        try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(out)))) {
            zip.setLevel(Deflater.BEST_SPEED);
            byte[] buf = new byte[CHUNK];
            for (int i = 0; i < files.size(); i++) {
                File f = files.get(i);
                ZipEntry e = new ZipEntry(names.get(i)); e.setTime(f.lastModified());
                if (shouldStore(names.get(i))) {
                    CRC32 crc = new CRC32();
                    try (InputStream in = new FileInputStream(f)) { int n; while ((n = in.read(buf)) >= 0) crc.update(buf, 0, n); }
                    e.setMethod(ZipEntry.STORED); e.setSize(f.length()); e.setCompressedSize(f.length()); e.setCrc(crc.getValue());
                }
                zip.putNextEntry(e);
                try (InputStream in = new FileInputStream(f)) { int n; while ((n = in.read(buf)) >= 0) zip.write(buf, 0, n); }
                zip.closeEntry();
            }
        }
    }

    static void writeAes(List<File> files, List<String> names, File out, String password, SecureRandom rnd, TimeZone tz) throws Exception {
        byte[] pw = password.getBytes(StandardCharsets.UTF_8);
        List<Object[]> done = new ArrayList<>();
        try (RandomAccessFile raf = new RandomAccessFile(out, "rw")) {
            raf.setLength(0);
            for (int i = 0; i < files.size(); i++) {
                File f = files.get(i);
                byte[] name = names.get(i).getBytes(StandardCharsets.UTF_8);
                int method = shouldStore(names.get(i)) ? 0 : 8;
                int[] dt = dos(f.lastModified(), tz);
                long offset = raf.getFilePointer(), size = f.length();
                byte[] ex = extra(method);
                raf.write(cat(le32(0x04034b50L), le16(51), le16(0x0801), le16(99), le16(dt[0]), le16(dt[1]), le32(0), le32(0), le32(size), le16(name.length), le16(ex.length), name, ex));
                long dataStart = raf.getFilePointer();
                byte[] salt = new byte[SALT]; rnd.nextBytes(salt);
                byte[] dk = pbkdf2(pw, salt, ITER, 2 * AES_KEY + 2);
                Ctr ctr = new Ctr(Arrays.copyOfRange(dk, 0, AES_KEY));
                Mac mac = Mac.getInstance("HmacSHA1"); mac.init(new SecretKeySpec(Arrays.copyOfRange(dk, AES_KEY, 2 * AES_KEY), "HmacSHA1"));
                raf.write(salt); raf.write(dk, 2 * AES_KEY, 2);
                byte[] buf = new byte[CHUNK];
                if (method == 0) {
                    try (InputStream in = new FileInputStream(f)) { int n; while ((n = in.read(buf)) >= 0) { if (n > 0) { ctr.process(buf, 0, n); mac.update(buf, 0, n); raf.write(buf, 0, n); } } }
                } else {
                    Deflater d = new Deflater(Deflater.BEST_SPEED, true); byte[] packed = new byte[CHUNK];
                    try (InputStream in = new FileInputStream(f)) {
                        int n;
                        while ((n = in.read(buf)) >= 0) {
                            d.setInput(buf, 0, n);
                            while (!d.needsInput()) { int m = d.deflate(packed); if (m > 0) { ctr.process(packed, 0, m); mac.update(packed, 0, m); raf.write(packed, 0, m); } }
                        }
                        d.finish();
                        while (!d.finished()) { int m = d.deflate(packed); if (m > 0) { ctr.process(packed, 0, m); mac.update(packed, 0, m); raf.write(packed, 0, m); } }
                    } finally { d.end(); }
                }
                raf.write(mac.doFinal(), 0, MAC_BYTES);
                long end = raf.getFilePointer(), compressed = end - dataStart;
                raf.seek(offset + 18); raf.write(le32(compressed)); raf.seek(end);
                done.add(new Object[]{name, method, dt[0], dt[1], compressed, size, offset});
            }
            long cdStart = raf.getFilePointer();
            for (Object[] d : done) {
                byte[] name = (byte[]) d[0]; byte[] ex = extra((Integer) d[1]);
                raf.write(cat(le32(0x02014b50L), le16(0x0033), le16(51), le16(0x0801), le16(99), le16((Integer) d[2]), le16((Integer) d[3]), le32(0),
                        le32((Long) d[4]), le32((Long) d[5]), le16(name.length), le16(ex.length), le16(0), le16(0), le16(0), le32(0), le32((Long) d[6]), name, ex));
            }
            long cdSize = raf.getFilePointer() - cdStart;
            raf.write(cat(le32(0x06054b50L), le16(0), le16(0), le16(done.size()), le16(done.size()), le32(cdSize), le32(cdStart), le16(0)));
        } finally { Arrays.fill(pw, (byte) 0); }
    }

    static byte[] unhex(String s) { byte[] b = new byte[s.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2), 16); return b; }
    static String hex(byte[] b) { StringBuilder sb = new StringBuilder(); for (byte x : b) sb.append(String.format("%02x", x)); return sb.toString(); }

    /** Deterministic "random" for tests: a SecureRandom subclass that returns a repeatable stream from a seed. */
    static class Seeded extends SecureRandom {
        final Random r; Seeded(long seed) { r = new Random(seed); }
        @Override public void nextBytes(byte[] b) { r.nextBytes(b); }
    }

    public static void main(String[] a) throws Exception {
        switch (a[0]) {
            case "names": { List<String> in = new ArrayList<>(Arrays.asList(a).subList(1, a.length)); for (String s : entryNames(in)) System.out.println(s); break; }
            case "store": for (int i = 1; i < a.length; i++) System.out.println(a[i] + " " + shouldStore(a[i])); break;
            case "pbkdf2batch": { BufferedReader r = new BufferedReader(new InputStreamReader(System.in)); String line;
                while ((line = r.readLine()) != null) { String[] p = line.split(" "); System.out.println(hex(pbkdf2(unhex(p[0]), unhex(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3])))); } break; }
            case "dosbatch": { BufferedReader r = new BufferedReader(new InputStreamReader(System.in)); String line;
                while ((line = r.readLine()) != null) { String[] p = line.split(" "); int[] d = dos(Long.parseLong(p[0]), TimeZone.getTimeZone(p[1])); System.out.println(d[0] + " " + d[1]); } break; }
            case "dos": { int[] d = dos(Long.parseLong(a[1]), TimeZone.getTimeZone(a[2])); System.out.println(d[0] + " " + d[1]); break; }
            case "pbkdf2": System.out.println(hex(pbkdf2(unhex(a[1]), unhex(a[2]), Integer.parseInt(a[3]), Integer.parseInt(a[4])))); break;
            case "pack": {
                File out = new File(a[1]); String pw = a[2].equals("-") ? null : new String(unhex(a[2]), StandardCharsets.UTF_8);
                long seed = Long.parseLong(a[3]); TimeZone tz = TimeZone.getTimeZone(a[4]);
                List<File> files = new ArrayList<>(); List<String> raw = new ArrayList<>();
                for (int i = 5; i < a.length; i += 2) { files.add(new File(a[i])); raw.add(a[i + 1]); }
                List<String> names = entryNames(raw);
                if (pw == null) writePlain(files, names, out); else writeAes(files, names, out, pw, new Seeded(seed), tz);
                break;
            }
            default: throw new IllegalArgumentException(a[0]);
        }
    }
}
