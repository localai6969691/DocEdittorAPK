// Bản Java chạy được của QrEncoder (phiên 19, mục 4.47.5): cùng thuật toán, cùng thứ tự với app/.../util/QrEncoder.kt. Dùng bởi qr_check.py.
//   java QrCheck.java <tệp vào> <tệp ra>
// Dòng vào: "ENC\t<hex UTF-8>\t<mức 0-3 = L,M,Q,H>\t<phiên bản nhỏ nhất>\t<boost 0/1>"  -> "version mask size matrixRows(0/1 nối liền)" hoặc "NONE"
//           "CAP\t<phiên bản>\t<mức>" -> số từ mã dữ liệu          "WIFI\t<hex ssid>\t<hex mật khẩu>\t<bảo mật>" -> hex của chuỗi Wi-Fi
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

public class QrCheck {
    static final int[][] ECC_PER_BLOCK = {
        {-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28, 28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30},
        {-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26, 26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28},
        {-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30, 28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30},
        {-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28, 30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30}};
    static final int[][] NUM_BLOCKS = {
        {-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8, 8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25},
        {-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16, 17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49},
        {-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20, 23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68},
        {-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25, 25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81}};
    static final int[] FORMAT_BITS = {1, 0, 3, 2};
    static final String ALNUM = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:";

    static int rawDataModules(int version) {
        int result = (16 * version + 128) * version + 64;
        if (version >= 2) { int numAlign = version / 7 + 2; result -= (25 * numAlign - 10) * numAlign - 55; if (version >= 7) result -= 36; }
        return result;
    }
    static int dataCodewords(int version, int ecl) { return rawDataModules(version) / 8 - ECC_PER_BLOCK[ecl][version] * NUM_BLOCKS[ecl][version]; }
    static int charCountBits(int mode, int version) { int k = version <= 9 ? 0 : (version <= 26 ? 1 : 2); return mode == 1 ? new int[]{10, 12, 14}[k] : (mode == 2 ? new int[]{9, 11, 13}[k] : new int[]{8, 16, 16}[k]); }

    static class Qr { int version, size, mask; boolean[] modules; }
    static Qr encode(String text, int ecl, int minVersion, boolean boost) {
        boolean allDigits = !text.isEmpty(), allAlnum = !text.isEmpty();
        for (int i = 0; i < text.length(); i++) { char c = text.charAt(i); if (c < '0' || c > '9') allDigits = false; if (ALNUM.indexOf(c) < 0) allAlnum = false; }
        int mode = allDigits ? 1 : (allAlnum ? 2 : 4);
        byte[] bytes = text.getBytes(StandardCharsets.UTF_8);
        int count = mode == 4 ? bytes.length : text.length();
        int dataBits = mode == 1 ? count / 3 * 10 + (count % 3 == 0 ? 0 : (count % 3 == 1 ? 4 : 7)) : (mode == 2 ? count / 2 * 11 + count % 2 * 6 : count * 8);
        int version = Math.max(1, Math.min(40, minVersion));
        while (true) {
            int used = 4 + charCountBits(mode, version) + dataBits;
            if (count < (1 << charCountBits(mode, version)) && used <= dataCodewords(version, ecl) * 8) break;
            if (version >= 40) return null;
            version++;
        }
        int level = ecl;
        if (boost) for (int cand = 1; cand <= 3; cand++) if (cand > level && 4 + charCountBits(mode, version) + dataBits <= dataCodewords(version, cand) * 8) level = cand;
        List<Integer> bits = new ArrayList<>();
        put(bits, mode, 4); put(bits, count, charCountBits(mode, version));
        if (mode == 1) { int i = 0; while (i < text.length()) { int n = Math.min(3, text.length() - i); put(bits, Integer.parseInt(text.substring(i, i + n)), n * 3 + 1); i += n; } }
        else if (mode == 2) { int i = 0; while (i + 1 < text.length()) { put(bits, ALNUM.indexOf(text.charAt(i)) * 45 + ALNUM.indexOf(text.charAt(i + 1)), 11); i += 2; } if (text.length() % 2 == 1) put(bits, ALNUM.indexOf(text.charAt(text.length() - 1)), 6); }
        else for (byte b : bytes) put(bits, b & 0xFF, 8);
        int capacityBits = dataCodewords(version, level) * 8;
        put(bits, 0, Math.min(4, capacityBits - bits.size())); put(bits, 0, (8 - bits.size() % 8) % 8);
        int pad = 0xEC; while (bits.size() < capacityBits) { put(bits, pad, 8); pad ^= (0xEC ^ 0x11); }
        int[] data = new int[bits.size() / 8]; for (int i = 0; i < bits.size(); i++) data[i >>> 3] |= bits.get(i) << (7 - (i & 7));
        return draw(addEccAndInterleave(data, version, level), version, level);
    }
    static void put(List<Integer> bits, int value, int length) { for (int i = length - 1; i >= 0; i--) bits.add((value >>> i) & 1); }
    static int gfMul(int x, int y) { int z = 0; for (int i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; } return z; }
    static int[] rsDivisor(int degree) { int[] r = new int[degree]; r[degree - 1] = 1; int root = 1; for (int k = 0; k < degree; k++) { for (int j = 0; j < r.length; j++) { r[j] = gfMul(r[j], root); if (j + 1 < r.length) r[j] ^= r[j + 1]; } root = gfMul(root, 2); } return r; }
    static int[] rsRemainder(int[] data, int[] divisor) { int[] r = new int[divisor.length]; for (int b : data) { int factor = b ^ r[0]; System.arraycopy(r, 1, r, 0, r.length - 1); r[r.length - 1] = 0; for (int i = 0; i < r.length; i++) r[i] ^= gfMul(divisor[i], factor); } return r; }
    static int[] addEccAndInterleave(int[] data, int version, int ecl) {
        int numBlocks = NUM_BLOCKS[ecl][version], blockEccLen = ECC_PER_BLOCK[ecl][version], rawCodewords = rawDataModules(version) / 8;
        int numShortBlocks = numBlocks - rawCodewords % numBlocks, shortBlockLen = rawCodewords / numBlocks;
        int[] divisor = rsDivisor(blockEccLen); List<int[]> db = new ArrayList<>(), eb = new ArrayList<>(); int k = 0;
        for (int i = 0; i < numBlocks; i++) { int len = shortBlockLen - blockEccLen + (i < numShortBlocks ? 0 : 1); int[] dat = Arrays.copyOfRange(data, k, k + len); k += len; db.add(dat); eb.add(rsRemainder(dat, divisor)); }
        List<Integer> result = new ArrayList<>(); int maxData = shortBlockLen - blockEccLen + 1;
        for (int i = 0; i < maxData; i++) for (int j = 0; j < numBlocks; j++) if (i < db.get(j).length) result.add(db.get(j)[i]);
        for (int i = 0; i < blockEccLen; i++) for (int j = 0; j < numBlocks; j++) result.add(eb.get(j)[i]);
        if (result.size() != rawCodewords) throw new IllegalStateException("codeword count");
        int[] r = new int[result.size()]; for (int i = 0; i < r.length; i++) r[i] = result.get(i); return r;
    }
    static boolean[] dark, fn; static int size;
    static void setFn(int x, int y, boolean v) { dark[y * size + x] = v; fn[y * size + x] = true; }
    static int[] alignmentPositions(int version) {
        if (version == 1) return new int[0];
        int numAlign = version / 7 + 2; int step = version == 32 ? 26 : (version * 4 + numAlign * 2 + 1) / (numAlign * 2 - 2) * 2; int sz = version * 4 + 17;
        int[] r = new int[numAlign]; r[0] = 6; int pos = sz - 7; for (int i = numAlign - 1; i >= 1; i--) { r[i] = pos; pos -= step; } return r;
    }
    static boolean bit(int x, int i) { return ((x >>> i) & 1) != 0; }
    static void finder(int cx, int cy) { for (int dy = -4; dy <= 4; dy++) for (int dx = -4; dx <= 4; dx++) { int dist = Math.max(Math.abs(dx), Math.abs(dy)); int xx = cx + dx, yy = cy + dy; if (xx >= 0 && xx < size && yy >= 0 && yy < size) setFn(xx, yy, dist != 2 && dist != 4); } }
    static void format(int ecl, int mask) {
        int data = FORMAT_BITS[ecl] << 3 | mask; int rem = data; for (int i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
        int bits = (data << 10 | rem) ^ 0x5412;
        for (int i = 0; i <= 5; i++) setFn(8, i, bit(bits, i)); setFn(8, 7, bit(bits, 6)); setFn(8, 8, bit(bits, 7)); setFn(7, 8, bit(bits, 8));
        for (int i = 9; i < 15; i++) setFn(14 - i, 8, bit(bits, i));
        for (int i = 0; i < 8; i++) setFn(size - 1 - i, 8, bit(bits, i));
        for (int i = 8; i < 15; i++) setFn(8, size - 15 + i, bit(bits, i));
        setFn(8, size - 8, true);
    }
    static Qr draw(int[] codewords, int version, int ecl) {
        size = version * 4 + 17; dark = new boolean[size * size]; fn = new boolean[size * size];
        for (int i = 0; i < size; i++) { setFn(6, i, i % 2 == 0); setFn(i, 6, i % 2 == 0); }
        finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
        int[] pos = alignmentPositions(version);
        for (int i = 0; i < pos.length; i++) for (int j = 0; j < pos.length; j++) { if (i == 0 && j == 0 || i == 0 && j == pos.length - 1 || i == pos.length - 1 && j == 0) continue; for (int dy = -2; dy <= 2; dy++) for (int dx = -2; dx <= 2; dx++) setFn(pos[i] + dx, pos[j] + dy, Math.max(Math.abs(dx), Math.abs(dy)) != 1); }
        format(ecl, 0);
        if (version >= 7) { int rem = version; for (int i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25); int bits = version << 12 | rem; for (int i = 0; i < 18; i++) { boolean b = bit(bits, i); int a = size - 11 + i % 3, c = i / 3; setFn(a, c, b); setFn(c, a, b); } }
        int idx = 0; int right = size - 1;
        while (right >= 1) { if (right == 6) right = 5; for (int vert = 0; vert < size; vert++) for (int j = 0; j < 2; j++) { int x = right - j; boolean upward = ((right + 1) & 2) == 0; int y = upward ? size - 1 - vert : vert; if (!fn[y * size + x] && idx < codewords.length * 8) { dark[y * size + x] = bit(codewords[idx >>> 3], 7 - (idx & 7)); idx++; } } right -= 2; }
        int best = 0, bestPenalty = Integer.MAX_VALUE;
        for (int m = 0; m < 8; m++) { applyMask(m); format(ecl, m); int p = penalty(); if (p < bestPenalty) { bestPenalty = p; best = m; } applyMask(m); }
        applyMask(best); format(ecl, best);
        Qr q = new Qr(); q.version = version; q.size = size; q.mask = best; q.modules = dark.clone(); return q;
    }
    static void applyMask(int mask) {
        for (int y = 0; y < size; y++) for (int x = 0; x < size; x++) {
            boolean inv;
            switch (mask) { case 0: inv = (x + y) % 2 == 0; break; case 1: inv = y % 2 == 0; break; case 2: inv = x % 3 == 0; break; case 3: inv = (x + y) % 3 == 0; break; case 4: inv = (x / 3 + y / 2) % 2 == 0; break; case 5: inv = x * y % 2 + x * y % 3 == 0; break; case 6: inv = (x * y % 2 + x * y % 3) % 2 == 0; break; default: inv = ((x + y) % 2 + x * y % 3) % 2 == 0; }
            if (inv && !fn[y * size + x]) dark[y * size + x] = !dark[y * size + x];
        }
    }
    static boolean at(int x, int y) { return dark[y * size + x]; }
    static int penalty() {
        int result = 0;
        for (int dir = 0; dir <= 1; dir++) for (int a = 0; a < size; a++) {
            int run = 1; StringBuilder sb = new StringBuilder();
            for (int b = 0; b < size; b++) {
                boolean v = dir == 0 ? at(b, a) : at(a, b); sb.append(v ? '1' : '0');
                if (b > 0) { boolean prev = dir == 0 ? at(b - 1, a) : at(a, b - 1); if (v == prev) { run++; if (run == 5) result += 3; else if (run > 5) result++; } else run = 1; }
            }
            String line = sb.toString(); int from = 0;
            while (true) { int i = line.indexOf("10111010000", from); if (i < 0) break; result += 40; from = i + 1; }
            from = 0; while (true) { int i = line.indexOf("00001011101", from); if (i < 0) break; result += 40; from = i + 1; }
        }
        for (int y = 0; y < size - 1; y++) for (int x = 0; x < size - 1; x++) { boolean c = at(x, y); if (c == at(x + 1, y) && c == at(x, y + 1) && c == at(x + 1, y + 1)) result += 3; }
        int d = 0; for (boolean v : dark) if (v) d++; int total = size * size; int k = (Math.abs(d * 20 - total * 10) + total - 1) / total - 1; result += Math.max(k, 0) * 10;
        return result;
    }
    static String esc(String s) { StringBuilder b = new StringBuilder(); for (char c : s.toCharArray()) { if (c == '\\' || c == ';' || c == ',' || c == ':' || c == '"') b.append('\\'); b.append(c); } return b.toString(); }
    static String wifi(String ssid, String pw, String sec) { String t = sec.equalsIgnoreCase("WEP") ? "WEP" : ((sec.equalsIgnoreCase("NOPASS") || sec.equalsIgnoreCase("NONE") || sec.isEmpty()) ? "nopass" : "WPA"); return t.equals("nopass") ? "WIFI:T:nopass;S:" + esc(ssid) + ";;" : "WIFI:T:" + t + ";S:" + esc(ssid) + ";P:" + esc(pw) + ";;"; }
    static String hex(String s) { StringBuilder b = new StringBuilder(); for (byte x : s.getBytes(StandardCharsets.UTF_8)) b.append(String.format("%02x", x & 0xff)); return b.toString(); }
    static String unhex(String h) { byte[] b = new byte[h.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return new String(b, StandardCharsets.UTF_8); }
    public static void main(String[] a) throws Exception {
        StringBuilder out = new StringBuilder();
        for (String ln : Files.readAllLines(Paths.get(a[0]), StandardCharsets.UTF_8)) {
            if (ln.isEmpty()) continue; String[] p = ln.split("\t", -1);
            if (p[0].equals("ENC")) { Qr q = encode(unhex(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3]), p[4].equals("1")); if (q == null) out.append("NONE\n"); else { out.append(q.version).append(' ').append(q.mask).append(' ').append(q.size).append(' '); for (boolean m : q.modules) out.append(m ? '1' : '0'); out.append('\n'); } }
            else if (p[0].equals("CAP")) out.append(dataCodewords(Integer.parseInt(p[1]), Integer.parseInt(p[2]))).append('\n');
            else if (p[0].equals("WIFI")) out.append(hex(wifi(unhex(p[1]), unhex(p[2]), p[3]))).append('\n');
        }
        Files.write(Paths.get(a[1]), out.toString().getBytes(StandardCharsets.UTF_8));
    }
}
