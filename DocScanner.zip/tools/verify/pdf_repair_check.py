"""Kiểm chứng PdfRepair.diagnose (phiên 18): chẩn đoán cấu trúc PDF theo BYTE, so với qpdf.

PdfRepairCheck.java là bản Java chạy được của PdfRepair.diagnose (util/PdfRepair.kt). Oracle độc lập: qpdf (--check; nó "dựng lại bảng tham chiếu" khi cấu trúc hỏng).
Sinh PDF lành (bảng xref cổ điển VÀ luồng xref của PDF 1.5) rồi gây hỏng theo từng LỚP, so chẩn đoán của app với phán đoán của qpdf:
- KHÔNG BÁO ĐỘNG NHẦM: tệp lành -> OK, qpdf không kêu;
- ĐÚNG KHI BÁO NẶNG: hai mức - HỎNG NẶNG (thiếu / sai startxref: đọc phải dựng lại bảng tham chiếu) thì qpdf PHẢI xác nhận (0 báo nhầm); KHÔNG CHUẨN NHƯNG ĐỌC ĐƯỢC
  (thiếu %%EOF, sai tiêu đề, rác trước tiêu đề) thì qpdf (và PdfBox) khoan dung mở được: chỉ báo cáo con số, không giả vờ qpdf xác nhận;
- ĐỘ BAO PHỦ: tỉ lệ hỏng qpdf kêu mà app bắt được (nói thẳng: chẩn đoán KHÔNG bắt hết, vì chỉ nhìn tiêu đề / %%EOF / startxref);
- KHẢ NĂNG CỨU: tệp hỏng nào qpdf dựng lại được thì số trang bằng bản gốc (bằng chứng cho lớp hỏng "có thể cứu" - đây là qpdf, KHÔNG phải PdfBox).
Chạy: python3 pdf_repair_check.py   (cần pikepdf, qpdf, poppler-utils, java 11+)
"""
import os, random, re, shutil, subprocess, sys, tempfile
import pikepdf
FAILS = []
HERE = os.path.dirname(os.path.abspath(__file__))
def check(c, w):
    print(("ok  " if c else "LOI"), w)
    if not c: FAILS.append(w)
tmp = tempfile.mkdtemp(prefix="repair_"); P = lambda n: os.path.join(tmp, n)
def run(*a): return subprocess.run(list(a), capture_output=True, text=True)
def qpdf_flags(path):
    r = run("qpdf", "--check", path); t = (r.stdout + r.stderr).lower()
    return r.returncode == 2 or "reconstruct" in t or "file is damaged" in t or "can't find startxref" in t
def pages_of(path):
    r = run("pdfinfo", path); m = re.search(r"Pages:\s+(\d+)", r.stdout); return int(m.group(1)) if m else -1
def make(path, pages, objstm):
    pdf = pikepdf.Pdf.new()
    for i in range(pages):
        pdf.add_blank_page(page_size=(200, 200)); pdf.pages[i].Contents = pdf.make_stream(f"BT /F1 12 Tf 20 100 Td (Trang {i+1}) Tj ET".encode())
        pdf.pages[i].Resources = pikepdf.Dictionary(Font=pikepdf.Dictionary(F1=pikepdf.Dictionary(Type=pikepdf.Name.Font, Subtype=pikepdf.Name.Type1, BaseFont=pikepdf.Name.Helvetica)))
    pdf.save(path, object_stream_mode=pikepdf.ObjectStreamMode.generate if objstm else pikepdf.ObjectStreamMode.disable, compress_streams=False, qdf=False)
rnd = random.Random(2026)
bases = []
for k in range(8):
    p = P(f"base{k}.pdf"); make(p, rnd.randint(1, 6), objstm=(k % 2 == 1)); bases.append(p)
def dmg_truncate(b, r): n = r.randint(1, 400); return b[:-n] if n < len(b) - 100 else b[:-10]
def dmg_no_eof(b, r): i = b.rfind(b"%%EOF"); return b[:i]
def dmg_no_startxref_num(b, r): return re.sub(rb"(startxref\s+)\d+", rb"\1", b, count=1)
def dmg_offset(b, r): m = re.search(rb"startxref\s+(\d+)", b); v = int(m.group(1)); nv = max(1, v + r.choice([-97, -13, -1, 1, 7, 211])); return b[:m.start(1)] + str(nv).encode() + b[m.end(1):]
def dmg_xref_kw(b, r): i = b.rfind(b"xref\n", 0, b.rfind(b"startxref")); return b if i < 0 else b[:i] + b"xreg\n" + b[i + 5:]
def dmg_garbage_prefix(b, r): return bytes(r.randrange(256) for _ in range(r.randint(1, 200))).replace(b"%PDF-", b"") + b
def dmg_header(b, r): return b.replace(b"%PDF-", b"%XDF-", 1)
def dmg_midbytes(b, r):
    a = bytearray(b); mid = len(a) // 3
    for _ in range(r.randint(1, 8)): a[r.randrange(20, mid)] = r.randrange(256)
    return bytes(a)
CLASSES = {"cắt đuôi": dmg_truncate, "mất %%EOF": dmg_no_eof, "startxref không số": dmg_no_startxref_num, "startxref sai vị trí": dmg_offset, "đổi chữ xref": dmg_xref_kw, "rác đầu tệp": dmg_garbage_prefix, "đổi tiêu đề": dmg_header, "lật byte giữa tệp": dmg_midbytes}
samples = [("lành", p, p) for p in bases]
for name, fn in CLASSES.items():
    for k, bp in enumerate(bases):
        for rep in range(3):
            b = open(bp, "rb").read(); out = P(f"d_{len(samples)}.pdf"); open(out, "wb").write(fn(b, rnd) if name != "đổi chữ xref" or True else b); samples.append((name, out, bp))
open(P("list.txt"), "w").write("\n".join(s[1] for s in samples) + "\n")
r = subprocess.run(["java", os.path.join(HERE, "PdfRepairCheck.java"), P("list.txt")], capture_output=True, text=True)
if r.returncode != 0: print(r.stderr[-600:])
diag = r.stdout.split("\n")[:len(samples)]
check(len(diag) == len(samples) and all(d for d in diag), f"{len(samples)} mẫu, bản Java chẩn đoán đủ")
SEVERE = {"NO_STARTXREF", "BAD_XREF_OFFSET"}
stat = {}
for (name, path, base), d in zip(samples, diag):
    q = qpdf_flags(path); s = stat.setdefault(name, {"n": 0, "severe": 0, "soft": 0, "qpdf": 0, "sev_and_q": 0, "sev_not_q": 0, "q_not_sev": 0}); sev = d in SEVERE; soft = d != "OK" and not sev
    s["n"] += 1; s["severe"] += sev; s["soft"] += soft; s["qpdf"] += q; s["sev_and_q"] += (sev and q); s["sev_not_q"] += (sev and not q); s["q_not_sev"] += (q and not sev)
good = stat["lành"]
check(good["severe"] == 0 and good["soft"] == 0 and good["qpdf"] == 0, f"không báo động nhầm: {good['n']} tệp lành -> app OK, qpdf không kêu")
print("  lớp hỏng                | mẫu | app: nặng | app: nhẹ | qpdf kêu | nặng & qpdf | nặng mà qpdf không | qpdf kêu mà app không nặng")
for name, s in stat.items():
    if name != "lành": print(f"  {name:<24}| {s['n']:>3} | {s['severe']:>9} | {s['soft']:>8} | {s['qpdf']:>8} | {s['sev_and_q']:>11} | {s['sev_not_q']:>18} | {s['q_not_sev']:>26}")
total_sev_not_q = sum(s["sev_not_q"] for n, s in stat.items())
check(total_sev_not_q == 0, f"ĐÚNG KHI BÁO NẶNG: mọi lần app báo HỎNG NẶNG qpdf đều xác nhận (0 báo nhầm trên {sum(s['severe'] for s in stat.values())} lần báo)")
for name in ["startxref không số", "startxref sai vị trí", "đổi chữ xref"]:
    s = stat[name]; check(s["severe"] > 0, f"'{name}': app có bắt được ({s['severe']}/{s['n']})")
check(stat["lật byte giữa tệp"]["severe"] == 0 and stat["lật byte giữa tệp"]["soft"] == 0, "lật byte giữa tệp (không đụng tiêu đề/EOF/startxref): app không báo - đúng với phạm vi đã nêu")
check(stat["mất %%EOF"]["soft"] == stat["mất %%EOF"]["n"] and stat["đổi tiêu đề"]["soft"] == stat["đổi tiêu đề"]["n"], "chỉ thiếu %%EOF (startxref còn) hoặc chỉ sai tiêu đề: xếp mức NHẸ (qpdf mở được), không phải nặng")
check(stat["cắt đuôi"]["severe"] >= stat["cắt đuôi"]["qpdf"] - 2 and stat["cắt đuôi"]["sev_not_q"] == 0, f"cắt đuôi mất cả startxref: xếp NẶNG ({stat['cắt đuôi']['severe']}/{stat['cắt đuôi']['n']}), qpdf xác nhận ({stat['cắt đuôi']['sev_and_q']})")
check(stat["rác đầu tệp"]["severe"] == 0, f"rác trước tiêu đề: bù độ lệch như qpdf nên KHÔNG bị xếp nặng ({stat['rác đầu tệp']['soft']}/{stat['rác đầu tệp']['n']} xếp nhẹ)")
tot_q = sum(s["qpdf"] for n, s in stat.items() if n != "lành"); tot_both = sum(s["sev_and_q"] for n, s in stat.items() if n != "lành")
print(f"  ĐỘ BAO PHỦ (nói thẳng): qpdf kêu {tot_q} mẫu hỏng, app xếp NẶNG được {tot_both} ({100*tot_both//max(tot_q,1)}%); phần còn lại là hỏng sâu bên trong (xref, luồng, đối tượng) mà chẩn đoán theo byte không thấy - việc SỬA vẫn chạy cho mọi tệp")
# KHẢ NĂNG CỨU (qpdf)
rec = 0; same = 0; tried = 0
for (name, path, base), d in zip(samples, diag):
    if name in ("lành", "lật byte giữa tệp") or d == "OK" or d not in SEVERE: continue
    tried += 1; out = P(f"rec_{tried}.pdf"); r = run("qpdf", path, out)
    if r.returncode in (0, 3) and os.path.exists(out):
        rec += 1
        if pages_of(out) == pages_of(base): same += 1
check(tried > 0 and same == rec, f"khả năng cứu (qpdf làm chứng, không phải PdfBox): {rec}/{tried} tệp HỎNG NẶNG được dựng lại, và cả {same}/{rec} có số trang bằng bản gốc")
shutil.rmtree(tmp, ignore_errors=True)
print("\nTAT CA DAT" if not FAILS else f"\n{len(FAILS)} LOI"); sys.exit(1 if FAILS else 0)
