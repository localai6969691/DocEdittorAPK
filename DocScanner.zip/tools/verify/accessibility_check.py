"""Kiểm chứng trợ năng cơ bản (phiên 16): mọi ImageView / ImageButton / FloatingActionButton trong layout phải hoặc có android:contentDescription (ảnh có ý nghĩa: ảnh xem
trước, nút) hoặc đánh dấu android:importantForAccessibility="no" (biểu tượng trang trí nằm cạnh nhãn chữ). Trước phiên 16 có 30/48 cái thiếu cả hai: TalkBack đọc
"chưa gắn nhãn" cho từng biểu tượng trên màn hình chính. Cũng kiểm: mô tả không rỗng và trỏ tới chuỗi có thật; MaterialButton chỉ có biểu tượng phải có mô tả.
Thử âm tính: tự bỏ thuộc tính khỏi một bản sao trong bộ nhớ thì phải bị bắt.
Chạy: python3 accessibility_check.py
"""
import glob, os, re, sys
import xml.etree.ElementTree as ET
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
RES = os.path.join(ROOT, "app/src/main/res")
A = "{http://schemas.android.com/apk/res/android}"
APP = "{http://schemas.android.com/apk/res-auto}"
strings = {s.get("name"): (s.text or "") for s in ET.parse(f"{RES}/values/strings.xml").getroot().findall("string")}
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
def audit(root, fname):
    problems, total = [], 0
    for el in root.iter():
        tag = el.tag.split(".")[-1]
        icon_only_button = tag == "MaterialButton" and el.get(APP + "icon") and not el.get(A + "text")
        if tag in ("ImageView", "ImageButton", "FloatingActionButton") or icon_only_button:
            total += 1
            cd, imp = el.get(A + "contentDescription"), el.get(A + "importantForAccessibility")
            if imp == "no": continue
            if not cd:
                problems.append(f"{fname}: {tag} {el.get(A + 'id') or el.get(A + 'src') or ''} thiếu contentDescription")
            elif cd.startswith("@string/") and not strings.get(cd[8:], "").strip():
                problems.append(f"{fname}: contentDescription {cd} trỏ tới chuỗi không có / rỗng")
    return problems, total
allp, allt = [], 0
for f in sorted(glob.glob(f"{RES}/layout/*.xml")):
    p, t = audit(ET.parse(f).getroot(), os.path.basename(f)); allp += p; allt += t
check(not allp, f"{allt} ảnh/nút ảnh trong {len(glob.glob(f'{RES}/layout/*.xml'))} layout đều có mô tả hoặc được đánh dấu trang trí" + (f" — thiếu: {allp[:3]}" if allp else ""))
# thử âm tính: một bản sao đã bỏ thuộc tính phải bị bắt
sample = ET.fromstring('<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"><ImageView android:id="@+id/x" android:src="@drawable/ic_pdf"/></LinearLayout>')
neg, _ = audit(sample, "mau.xml")
check(len(neg) == 1, "thử âm tính: ImageView không có mô tả cũng không đánh dấu trang trí bị bắt")
print("\nTAT CA DAT" if not FAILS else f"\nCO {len(FAILS)} LOI")
sys.exit(1 if FAILS else 0)
