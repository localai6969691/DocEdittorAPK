#!/usr/bin/env python3
"""Tìm công cụ (bảng lệnh) CHẠY THẬT (`util/CommandPalette.kt`; phiên 25, TECHNICAL_DOCS.md 4.75; mục 4.9 của PDF): xếp hạng tên công cụ theo chữ người dùng gõ, bỏ dấu tiếng Việt.
Cùng bộ kiểm có thêm `util/ToolPreset.kt` (câu hỏi lần đầu "bạn chủ yếu làm gì?" quyết định nhóm công cụ nào mở sẵn, 4.79).

Mong đợi viết TAY từ đặc tả điểm (100 nguyên tên, 90 đầu tên, 80 đầu một từ, 60 nằm trong tên, 40 mọi từ của câu gõ là đầu một từ, 20 các chữ cái theo thứ tự), không phải bản cài lại cùng logic.
Đối chứng độc lập cho phần bỏ dấu: `unicodedata` của Python (NFD, bỏ dấu kết hợp, đ -> d) trên cả bảng chữ Việt, kèm tiếng Pháp / Đức / Nga.
KHÔNG kiểm được: cách thu thập tên từ các nút / thẻ của màn chính (duyệt View thật), hộp thoại. Chạy: python3 tools/verify/command_palette_real_run_check.py"""
import os, sys, tempfile, unicodedata
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="palette-")
HARNESS = os.path.join(HERE, "real_run", "CommandPaletteHarness.kt")
cls = tc.compile(["CommandPalette.kt", "ToolPreset.kt"], [HARNESS], os.path.join(WORK, "cls"), None, None)[0]
def run(args, lines):
    r = tc.run(cls, "CommandPaletteHarnessKt", args, stdin="\n".join(lines) + "\n")
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-1200:])
    out = r.stdout.split("\n"); return out[:-1] if out and out[-1] == "" else out
def rank(query, names): return run([], [query] + names)[0]

NAMES = ["Quét tài liệu", "Ký tài liệu PDF", "Ghép PDF", "Chia tách PDF", "Đổi sang Word", "Nén PDF", "OCR – nhận dạng chữ", "Đặt mật khẩu"]
print("== A. xếp hạng")
cases = [("ky", "1"), ("KÝ", "1"), ("pdf", "1 2 3 5"), ("dat", "7"), ("đặt mật", "7"), ("mat khau", "7"), ("word", "4"), ("ocr", "6"), ("ghep pdf", "2"),
         ("tai lieu", "0 1"), ("zzz", "-"), ("", "0 1 2 3 4 5 6 7"), ("pf", "1 2 3 5"), ("sang", "4"), ("quet", "0"), ("nhan dang", "6")]
for q, want in cases:
    got = rank(q, NAMES); check(got == want, f"'{q}' -> {got} (mong đợi {want})")
check(rank("pdf", ["Pdf", "Ghép PDF", "PDF thành ảnh"]) == "0 2 1", "'pdf': nguyên tên (100) trước, đầu tên (90) rồi mới tới đầu một từ (80)")
check(rank("an", ["Chia sẻ ảnh", "Ảnh", "Nhận dạng", "Ẩn tệp"]) == "1 3 0 2", "'an': 'Ảnh' đầu tên (90), 'Ẩn tệp' đầu tên (90), rồi 'Chia sẻ ảnh' đầu một từ (80), 'Nhận dạng' trong tên (60)")
check(rank("cu x", ["Cắt ảnh", "Cứu xếp hạng", "Xoá"]) == "1", "câu gõ nhiều từ: mọi từ là đầu một từ trong tên (40)")
check(rank("mat khau", ["Đặt mật khẩu", "Mật khẩu"]) == "1 0", "'mat khau': tên chỉ khác dấu (nguyên tên, 100) lên trước tên chứa nó (60)")
check(rank("a", ["Bắt đầu", "Aaa"]) == "1 0", "một chữ: chỉ khớp đầu tên / đầu từ / trong tên, không dùng 'đúng thứ tự' (cần >= 2 chữ)")

print("== B. bỏ dấu: so với unicodedata của Python")
SAMPLES = ["Quét tài liệu", "ĐẶT MẬT KHẨU", "Nguyễn Thị Tâm", "ươ ƯƠ ẳ ẵ ẫ ộ ỗ ợ ở ỡ", "Café déjà vu Zürich", "Größe Straße", "Привет Мир", "日本語  tab\tspace", "  nhiều   khoảng   trắng  "]
def py_fold(s):
    d = unicodedata.normalize("NFD", s); out = "".join(c for c in d if unicodedata.category(c) != "Mn")
    return " ".join(out.replace("đ", "d").replace("Đ", "D").lower().split())
got = run(["fold"], SAMPLES)
check(got == [py_fold(s) for s in SAMPLES], "bỏ dấu giống unicodedata" + ("" if got == [py_fold(s) for s in SAMPLES] else f"\n  {got}\n  {[py_fold(s) for s in SAMPLES]}"))

print("== B2. câu hỏi lần đầu: nhóm công cụ nào mở sẵn (ToolPreset)")
def preset(goals): return run(["preset", goals], [])[0]
for goals, want in (("", "scan"), ("scan", "scan"), ("edit", "edit,secure"), ("arrange", "arrange"), ("convert", "convert"), ("edit,convert", "edit,secure,convert"),
                    ("scan,edit,arrange,convert", "scan,edit,secure,arrange,convert"), ("all", "scan,arrange,edit,secure,convert,utility"), ("all,scan", "scan,arrange,edit,secure,convert,utility"), ("xyz", "scan")):
    got = preset(goals); check(got == want, f"mục tiêu '{goals}' -> mở {got} (mong đợi {want})")
check("utility" not in preset("scan,edit,arrange,convert"), "nhóm tiện ích (hàng loạt, sao lưu, QR) chỉ mở khi chọn 'tất cả'")

print("== C. thử âm tính")
def probe(class_dir):
    def runc(args, lines):
        r = tc.run(class_dir, "CommandPaletteHarnessKt", args, stdin="\n".join(lines) + "\n").stdout.split("\n"); return r[0]
    return runc([], ["ky"] + NAMES) == "1" and runc([], ["dat"] + NAMES) == "7" and runc([], ["pdf", "Pdf", "Ghép PDF", "PDF thành ảnh"]) == "0 2 1" and runc([], ["pf"] + NAMES) == "1 2 3 5" and runc([], ["mat khau", "Đặt mật khẩu", "Mật khẩu"]) == "1 0"
check(probe(cls), "đối chứng: mã gốc đạt phép thử")
def preset_ok(class_dir): return tc.run(class_dir, "CommandPaletteHarnessKt", ["preset", "edit"], stdin="").stdout.strip() == "edit,secure" and tc.run(class_dir, "CommandPaletteHarnessKt", ["preset", "xyz"], stdin="").stdout.strip() == "scan"
check(preset_ok(cls), "đối chứng: ToolPreset gốc đạt phép thử")
try:
    pdir = tc.compile(["CommandPalette.kt", "ToolPreset.kt"], [HARNESS], os.path.join(WORK, "mutp"), {"ToolPreset.kt": ("            out.add(\"secure\")\n", "")}, None)[0]
    check(not preset_ok(pdir), "mã sai bị bắt: chọn 'chỉnh sửa' mà không mở nhóm ký / bảo mật")
except RuntimeError as e:
    check(False, f"mutant không biên dịch được: {str(e)[:110]}")
try:
    pdir = tc.compile(["CommandPalette.kt", "ToolPreset.kt"], [HARNESS], os.path.join(WORK, "mutp"), {"ToolPreset.kt": ("return if (out.isEmpty()) setOf(\"scan\") else out", "return out")}, None)[0]
    check(not preset_ok(pdir), "mã sai bị bắt: mục tiêu lạ làm mọi nhóm bị thu gọn")
except RuntimeError as e:
    check(False, f"mutant không biên dịch được: {str(e)[:110]}")
for name, old, new in (("không bỏ dấu đ", "'\\u0111', '\\u0110' -> sb.append('d')", "'\\u0111', '\\u0110' -> sb.append(c)"),
                       ("không xếp theo điểm (giữ thứ tự gốc)", "compareBy({ -it.second }, { it.first })", "compareBy({ it.first })"),
                       ("không bỏ dấu kết hợp", "if (Character.getType(c) == Character.NON_SPACING_MARK.toInt()) continue", "")):
    try:
        mdir = tc.compile(["CommandPalette.kt"], [HARNESS], os.path.join(WORK, "mut"), {"CommandPalette.kt": (old, new)}, None)[0]
        check(not probe(mdir), f"mã sai bị bắt: {name}")
    except RuntimeError as e:
        check(False, f"mutant không biên dịch được: {name}: {str(e)[:110]}")

print()
print("TAT CA DAT" if not fails else f"{len(fails)} LOI")
sys.exit(1 if fails else 0)
