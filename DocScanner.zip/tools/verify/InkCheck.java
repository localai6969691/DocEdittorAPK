import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Java twin of the pure parts of app/.../util/PdfInk.kt (phiên 23, 4.62), statement by statement. stdin, one command per line, numbers separated by spaces:
 *   SIMPLIFY minStep x0 y0 x1 y1 ...        -> the kept points, "x0 y0 x1 y1 ..."
 *   CAPPED x0 y0 ...                        -> simplifyCapped, then the number of kept points and the points
 *   BOUNDS pad x0 y0 x1 y1 ...              -> "llx lly urx ury"
 *   APPEARANCE marker(0|1) width r g b x0 y0 ... -> the content stream with "\n" written as "|" (one line per command)
 */
public class InkCheck {
    static final float MIN_STEP = 0.003f; static final int MAX_POINTS = 1500;
    static String f3(float v) { return String.format(Locale.US, "%.3f", v); }
    static float[] simplify(float[] p, float minStep) {
        int n = p.length / 2;
        if (n <= 2) return Arrays.copyOf(p, n * 2);
        List<Float> out = new ArrayList<>(); out.add(p[0]); out.add(p[1]);
        float lx = p[0], ly = p[1];
        for (int i = 1; i < n - 1; i++) {
            float x = p[2 * i], y = p[2 * i + 1];
            if ((float) Math.hypot(x - lx, y - ly) >= minStep) { out.add(x); out.add(y); lx = x; ly = y; }
        }
        out.add(p[2 * (n - 1)]); out.add(p[2 * (n - 1) + 1]);
        float[] r = new float[out.size()]; for (int i = 0; i < r.length; i++) r[i] = out.get(i); return r;
    }
    static float[] simplifyCapped(float[] p) {
        float step = MIN_STEP; float[] r = simplify(p, step); int tries = 0;
        while (r.length / 2 > MAX_POINTS && tries < 6) { step *= 2f; r = simplify(p, step); tries++; }
        return r;
    }
    static float[] bounds(float[] u, float pad) {
        float minX = u[0], maxX = u[0], minY = u[1], maxY = u[1]; int i = 2;
        while (i + 1 < u.length) { minX = Math.min(minX, u[i]); maxX = Math.max(maxX, u[i]); minY = Math.min(minY, u[i + 1]); maxY = Math.max(maxY, u[i + 1]); i += 2; }
        return new float[]{minX - pad, minY - pad, maxX + pad, maxY + pad};
    }
    static String appearance(float[] u, float[] rgb, float width, boolean marker) {
        StringBuilder sb = new StringBuilder();
        if (marker) sb.append("/GS gs\n");
        sb.append(f3(rgb[0])).append(" ").append(f3(rgb[1])).append(" ").append(f3(rgb[2])).append(" RG\n").append(f3(width)).append(" w 1 J 1 j\n");
        sb.append(f3(u[0])).append(" ").append(f3(u[1])).append(" m");
        if (u.length <= 2) sb.append(" ").append(f3(u[0])).append(" ").append(f3(u[1])).append(" l");
        int i = 2;
        while (i + 1 < u.length) { sb.append(" ").append(f3(u[i])).append(" ").append(f3(u[i + 1])).append(" l"); i += 2; }
        sb.append(" S\n");
        return sb.toString();
    }
    static float[] nums(String[] t, int from) { float[] r = new float[t.length - from]; for (int i = from; i < t.length; i++) r[i - from] = Float.parseFloat(t[i]); return r; }
    static String join(float[] a) { StringBuilder sb = new StringBuilder(); for (int i = 0; i < a.length; i++) { if (i > 0) sb.append(" "); sb.append(a[i]); } return sb.toString(); }
    public static void main(String[] args) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.US_ASCII)); String line;
        PrintStream out = new PrintStream(System.out, false, "UTF-8");
        while ((line = r.readLine()) != null) {
            String[] t = line.trim().split(" ");
            switch (t[0]) {
                case "SIMPLIFY": out.println(join(simplify(nums(t, 2), Float.parseFloat(t[1])))); break;
                case "CAPPED": { float[] k = simplifyCapped(nums(t, 1)); out.println((k.length / 2) + " " + join(k)); break; }
                case "BOUNDS": out.println(join(bounds(nums(t, 2), Float.parseFloat(t[1])))); break;
                case "APPEARANCE": { float[] rest = nums(t, 6); out.println(appearance(rest, new float[]{Float.parseFloat(t[3]), Float.parseFloat(t[4]), Float.parseFloat(t[5])}, Float.parseFloat(t[2]), t[1].equals("1")).replace("\n", "|")); break; }
                default: break;
            }
        }
        out.flush();
    }
}
