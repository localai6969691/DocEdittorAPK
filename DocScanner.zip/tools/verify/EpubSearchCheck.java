import java.io.*;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.*;

/**
 * Java twin of app/.../util/EpubSearch.kt (phiên 22, 4.49.5). stdin, one command per line, all text as hex UTF-16 code units:
 *   "Q <query>" sets the query;  "C" starts a chapter;  "P <paragraph>" adds a paragraph to the current chapter;  "RUN <limit>" searches and prints.
 * Output: first line "TOTAL n", then one line per hit: "chapter paragraph beforeHex matchHex afterHex" (hex UTF-16 units).
 */
public class EpubSearchCheck {
    static boolean isMark(char c) { int t = Character.getType(c); return t == Character.NON_SPACING_MARK || t == Character.COMBINING_SPACING_MARK || t == Character.ENCLOSING_MARK; }
    static boolean isSpace(char c) { return Character.isWhitespace(c) || Character.isSpaceChar(c); }

    static class Folded { String text; int[] origin; }
    static Folded fold(String s) {
        StringBuilder sb = new StringBuilder(); int[] map = new int[s.length() + 1]; int n = 0; boolean lastSpace = true;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (isSpace(c)) { if (!lastSpace) { sb.append(' '); map[n++] = i; lastSpace = true; } continue; }
            if (isMark(c)) continue;
            char f = Character.toLowerCase(c);
            if (f == '\u0111') f = 'd';
            else if (f >= 0xC0) { String d = Normalizer.normalize(String.valueOf(f), Normalizer.Form.NFD); f = d.charAt(0); if (isMark(f)) continue; }
            sb.append(f); map[n++] = i; lastSpace = false;
        }
        if (sb.length() > 0 && sb.charAt(sb.length() - 1) == ' ') { sb.setLength(sb.length() - 1); n--; }
        map[n] = s.length();
        Folded r = new Folded(); r.text = sb.toString(); r.origin = Arrays.copyOf(map, n + 1); return r;
    }
    static String squeezeKeep(String s) {
        StringBuilder sb = new StringBuilder(); boolean last = false;
        for (int i = 0; i < s.length(); i++) { char c = s.charAt(i); if (isSpace(c)) { if (!last) sb.append(' '); last = true; } else { sb.append(c); last = false; } }
        return sb.toString();
    }
    static int safeStart(String s, int i) { return (i > 0 && i < s.length() && Character.isLowSurrogate(s.charAt(i)) && Character.isHighSurrogate(s.charAt(i - 1))) ? i - 1 : i; }

    static String unhex(String h) { StringBuilder sb = new StringBuilder(); for (int i = 0; i + 4 <= h.length(); i += 4) sb.append((char) Integer.parseInt(h.substring(i, i + 4), 16)); return sb.toString(); }
    static String hex(String s) { StringBuilder sb = new StringBuilder(); for (int i = 0; i < s.length(); i++) sb.append(String.format("%04x", (int) s.charAt(i))); return sb.toString(); }

    public static void main(String[] a) throws Exception {
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.US_ASCII)); String line;
        String query = ""; List<List<String>> chapters = new ArrayList<>(); PrintStream out = new PrintStream(System.out, false, "UTF-8");
        while ((line = r.readLine()) != null) {
            if (line.startsWith("Q")) query = unhex(line.length() > 2 ? line.substring(2).trim() : "");
            else if (line.equals("C")) chapters.add(new ArrayList<>());
            else if (line.startsWith("P")) chapters.get(chapters.size() - 1).add(unhex(line.length() > 2 ? line.substring(2).trim() : ""));
            else if (line.startsWith("RUN")) {
                int limit = Integer.parseInt(line.substring(4).trim()); String needle = fold(query).text; List<String> hits = new ArrayList<>(); int total = 0;
                if (!needle.isEmpty()) for (int ci = 0; ci < chapters.size(); ci++) for (int pi = 0; pi < chapters.get(ci).size(); pi++) {
                    String paragraph = chapters.get(ci).get(pi); Folded folded = fold(paragraph); int from = 0;
                    while (true) {
                        int at = folded.text.indexOf(needle, from); if (at < 0) break;
                        total++;
                        if (hits.size() < limit) {
                            int start = folded.origin[at]; int end = folded.origin[at + needle.length() - 1] + 1; int realEnd = end;
                            while (realEnd < paragraph.length() && isMark(paragraph.charAt(realEnd))) realEnd++;
                            int b = safeStart(paragraph, Math.max(0, start - 60)); int e = safeStart(paragraph, Math.min(paragraph.length(), realEnd + 60));
                            String before = (b > 0 ? "\u2026" : "") + squeezeKeep(paragraph.substring(b, start));
                            String match = squeezeKeep(paragraph.substring(start, realEnd)).trim();
                            String after = squeezeKeep(paragraph.substring(realEnd, e)) + (e < paragraph.length() ? "\u2026" : "");
                            hits.add(ci + " " + pi + " " + hex(before) + " " + hex(match) + " " + hex(after));
                        }
                        from = at + needle.length();
                    }
                }
                out.println("TOTAL " + total); for (String h : hits) out.println(h);
                out.println("END");
            }
        }
        out.flush();
    }
}
