import java.io.*;
import java.util.*;

/**
 * Ban Java chay duoc cua util/BatchQueue.kt (TaskFailures, BatchQueue) va cac ham thuan cua util/DeviceLoad.kt (phien 24, TECHNICAL_DOCS.md 4.63).
 * Chay: java BatchQueueCheck.java  < cac dong lenh. Moi dong: lenh + doi so; moi dong in ra mot dong ket qua.
 *   C <chain>                      chain = link;link;...  link = tenLop@thongDiep  (thongDiep "~null~" = null)  -> TRANSIENT | DISK_FULL | PERMANENT
 *   D <attempt>                    -> delayMs shouldRetry(TRANSIENT) shouldRetry(DISK_FULL) shouldRetry(PERMANENT)
 *   Q <total> <thao tac...>        N = next, D<i> done, F<i> failed, S<i> skipped, X = stop -> cac chi so next tra ve | dem 6 trang thai
 *   A <percent> <charging 0|1> <thermal>   -> Advice
 *   P <level> <scale>              -> percentOf
 *   G <plugged> <status>           -> isCharging 0|1
 *   K <advice> <now> <until> <snoozed>     -> needsAsk 0|1
 */
public class BatchQueueCheck {
    // ---- TaskFailures ----
    static final int MAX_ATTEMPTS = 3; static final long BASE_DELAY_MS = 400L, MAX_DELAY_MS = 3000L;
    static final String[] DISK_FULL_MARKERS = {"enospc", "no space left", "not enough space", "disk full", "edquot", "quota exceeded"};
    static final String[] TRANSIENT_MARKERS = {"ebusy", "text file busy", "resource busy", "being used by another", "eagain", "try again",
        "temporarily unavailable", "eintr", "interrupted system call", "estale", "stale file"};
    static final String[] TRANSIENT_CLASSES = {"deadobjectexception", "interruptedioexception"};
    static final String[] PERMANENT_CLASSES = {"invalidpasswordexception", "outofmemoryerror"};
    static boolean anyContains(String s, String[] marks) { for (String m : marks) if (s.contains(m)) return true; return false; }
    static String classify(List<String[]> chain) {
        for (String[] link : chain) { String m = (link[1] == null ? "" : link[1]).toLowerCase(); if (anyContains(m, DISK_FULL_MARKERS)) return "DISK_FULL"; }
        for (String[] link : chain) { String c = link[0].toLowerCase(); if (anyContains(c, PERMANENT_CLASSES)) return "PERMANENT"; }
        for (String[] link : chain) {
            String c = link[0].toLowerCase(); String m = (link[1] == null ? "" : link[1]).toLowerCase();
            if (anyContains(c, TRANSIENT_CLASSES) || anyContains(m, TRANSIENT_MARKERS)) return "TRANSIENT";
        }
        return "PERMANENT";
    }
    static boolean shouldRetry(String kind, int attempt) { return kind.equals("TRANSIENT") && attempt < MAX_ATTEMPTS; }
    static long delayMs(int attempt) { int shift = Math.max(0, Math.min(10, attempt - 1)); return Math.min(MAX_DELAY_MS, BASE_DELAY_MS << shift); }

    // ---- BatchQueue ----
    static class Queue {
        static final String[] NAMES = {"QUEUED", "RUNNING", "DONE", "FAILED", "SKIPPED", "STOPPED"};
        final int[] st; boolean stopped = false;
        Queue(int total) { st = new int[Math.max(0, total)]; }
        int next() { if (stopped) return -1; for (int i = 0; i < st.length; i++) if (st[i] == 0) { st[i] = 1; return i; } return -1; }
        void finish(int i, int to) { if (i >= 0 && i < st.length && st[i] == 1) st[i] = to; }
        void stop() { stopped = true; for (int i = 0; i < st.length; i++) if (st[i] == 0) st[i] = 5; }
        int count(int s) { int n = 0; for (int v : st) if (v == s) n++; return n; }
    }

    // ---- DeviceLoad (pure part) ----
    static final int BATTERY_LOW_PERCENT = 15, BATTERY_CRITICAL_PERCENT = 5, THERMAL_HOT = 3, THERMAL_VERY_HOT = 4;
    static String advise(int percent, boolean charging, int thermal) {
        if (thermal >= THERMAL_VERY_HOT) return "VERY_HOT";
        if (thermal >= THERMAL_HOT) return "HOT";
        if (!charging && percent >= 0 && percent <= BATTERY_CRITICAL_PERCENT) return "BATTERY_CRITICAL";
        if (!charging && percent >= 0 && percent <= BATTERY_LOW_PERCENT) return "BATTERY_LOW";
        return "NONE";
    }
    static int percentOf(int level, int scale) {
        if (level < 0 || scale <= 0) return -1;
        int p = (int) ((long) level * 100L / (long) scale);
        return Math.max(0, Math.min(100, p));
    }
    static boolean isCharging(int plugged, int status) { return plugged != 0 || status == 2 || status == 5; }
    static boolean needsAsk(String advice, long now, long snoozedUntil, String snoozedAdvice) {
        return !advice.equals("NONE") && !(now < snoozedUntil && advice.equals(snoozedAdvice));
    }

    public static void main(String[] a) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in, "UTF-8"));
        String line;
        while ((line = in.readLine()) != null) {
            if (line.isEmpty()) { System.out.println(); continue; }
            int sp = line.indexOf(' ');
            String cmd = sp < 0 ? line : line.substring(0, sp); String rest = sp < 0 ? "" : line.substring(sp + 1);
            String[] t = rest.isEmpty() ? new String[0] : rest.split(" ");
            switch (cmd) {
                case "C": {
                    List<String[]> chain = new ArrayList<>();
                    for (String link : rest.split(";")) { int at = link.indexOf('@'); String cls = at < 0 ? link : link.substring(0, at); String msg = at < 0 ? null : link.substring(at + 1); if ("~null~".equals(msg)) msg = null; chain.add(new String[]{cls, msg}); }
                    System.out.println(classify(chain)); break;
                }
                case "D": { int n = Integer.parseInt(t[0]); System.out.println(delayMs(n) + " " + shouldRetry("TRANSIENT", n) + " " + shouldRetry("DISK_FULL", n) + " " + shouldRetry("PERMANENT", n)); break; }
                case "Q": {
                    Queue q = new Queue(Integer.parseInt(t[0])); List<String> got = new ArrayList<>();
                    for (int k = 1; k < t.length; k++) {
                        String op = t[k];
                        if (op.equals("N")) got.add(String.valueOf(q.next()));
                        else if (op.equals("X")) q.stop();
                        else { int i = Integer.parseInt(op.substring(1)); char c = op.charAt(0); q.finish(i, c == 'D' ? 2 : c == 'F' ? 3 : 4); }
                    }
                    StringBuilder sb = new StringBuilder(String.join(",", got)).append("|");
                    for (int s = 0; s < 6; s++) { if (s > 0) sb.append(","); sb.append(q.count(s)); }
                    System.out.println(sb); break;
                }
                case "A": System.out.println(advise(Integer.parseInt(t[0]), t[1].equals("1"), Integer.parseInt(t[2]))); break;
                case "P": System.out.println(percentOf(Integer.parseInt(t[0]), Integer.parseInt(t[1]))); break;
                case "G": System.out.println(isCharging(Integer.parseInt(t[0]), Integer.parseInt(t[1])) ? 1 : 0); break;
                case "K": System.out.println(needsAsk(t[0], Long.parseLong(t[1]), Long.parseLong(t[2]), t[3]) ? 1 : 0); break;
                default: System.out.println("?");
            }
        }
    }
}
