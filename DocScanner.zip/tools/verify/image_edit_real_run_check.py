#!/usr/bin/env python3
"""Sửa ẢNH có sẵn trong PDF CHẠY THẬT (`util/PdfImageEditor.kt`; phiên 27, TECHNICAL_DOCS.md 4.88): liệt kê ảnh + vị trí, xoá, di chuyển, đổi cỡ, xoay, thay ảnh.

Khác bộ kiểm bản Java chép lại: biên dịch CHÍNH `PdfImageEditor.kt` (cùng `PdfPageGeometry.kt`) bằng kotlinc trên PdfBox-Android dựng từ nguồn. Kết quả đo bằng công cụ ĐỘC LẬP: poppler (`pdftoppm` vẽ trang ->
numpy tìm khung của từng màu thuần; `pdfimages -list` đếm ảnh), `qpdf --check`, `pikepdf` (số lần `Do`, số XObject). PDF thử dựng bằng reportlab / pikepdf, không bằng mã đang kiểm.
  A. liệt kê: khung ảnh đúng số đã vẽ, phân số trên trang hiển thị; chạm chọn ảnh nhỏ nhất;  B. xoá: màu biến mất khỏi hình vẽ, ảnh còn lại không đổi, `pdfimages` đếm bớt 1;
  C. di chuyển / đổi cỡ / xoay (ảnh nửa đỏ nửa xanh: xoay 90 độ thuận chiều kim đồng hồ thì đỏ lên trên) đo trên hình poppler vẽ;  D. thay ảnh: giữ tỉ lệ, nằm giữa khung cũ (ảnh dẹt và ảnh cao);
  E. một ảnh vẽ hai lần (cùng XObject): chỉ chỗ được chọn đổi;  F. trang xoay 90 độ: dịch phải / xuống theo trang NHÌN THẤY;  G. thao tác sai (chỉ số lạ, tỉ lệ 0, trang lạ) -> lỗi và KHÔNG để lại tệp; qpdf --check sạch.
  H. THỬ ÂM TÍNH: 10 bản `PdfImageEditor.kt` bị làm hỏng phải bị bắt.
KHÔNG kiểm được: ảnh nội tuyến (BI), ảnh nằm trong form XObject (cố ý không vào, giống PdfTextEditor), giao diện kéo thả, `JPEGFactory` / `LosslessFactory` trên máy thật (ảnh thay dựng thẳng từ byte thô).
Chạy: python3 tools/verify/image_edit_real_run_check.py [--fast]  (--fast bỏ phần H)"""
import io, os, subprocess, sys, tempfile
import numpy as np
from PIL import Image
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402
import pikepdf  # noqa: E402
from reportlab.pdfgen import canvas  # noqa: E402
from reportlab.lib.utils import ImageReader  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="imgedit-")
P = lambda n: os.path.join(WORK, n)
DOUBLE = {"PdfVerify.kt": ("    fun opensAsPdf(file: File, expectedPages: Int): Boolean {",
    "    fun opensAsPdf(file: File, expectedPages: Int): Boolean {\n        return try {\n            if (!file.exists() || file.length() <= 0L) return false\n"
    "            com.tom_roush.pdfbox.pdmodel.PDDocument.load(file).use { d -> d.numberOfPages > 0 && (expectedPages <= 0 || d.numberOfPages == expectedPages) }\n        } catch (e: Exception) { false }\n    }")}
FILES = ["PdfImageEditor.kt", "PdfPageGeometry.kt", "PdfVerify.kt"]
HARNESS = os.path.join(HERE, "real_run", "ImageEditHarness.kt")
cls = tc.compile(FILES, [HARNESS], os.path.join(WORK, "cls"), None, DOUBLE)[0]

def harness(c, *a):
    r = tc.run(c, "ImageEditHarnessKt", list(a))
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-1200:])
    return [l for l in r.stdout.split("\n") if l.strip()]
def sh(*cmd): return subprocess.run(cmd, capture_output=True, text=True)

# ------------------------------------------------------------------ PDFs built independently (reportlab / pikepdf)
def solid(color, size=(40, 24)): return Image.new("RGB", size, color)
def two_tone(size=(40, 24)):
    im = Image.new("RGB", size, (255, 0, 0)); im.paste((0, 0, 255), (size[0] // 2, 0, size[0], size[1])); return im
def make_pdf(path, items, rotate=0):
    """items: (PIL image, x, y, w, h) in points, drawn in order on a 612 x 792 page."""
    c = canvas.Canvas(path, pagesize=(612, 792))
    for im, x, y, w, h in items: c.drawImage(ImageReader(im), x, y, w, h)
    c.showPage(); c.save()
    if rotate:
        with pikepdf.open(path, allow_overwriting_input=True) as pdf:
            pdf.pages[0].Rotate = rotate; pdf.save(path)
RED, BLUE, GREEN = (255, 0, 0), (0, 0, 255), (0, 255, 0)
BASE = P("base.pdf"); make_pdf(BASE, [(solid(RED), 100, 500, 200, 120), (solid(BLUE), 300, 200, 150, 150)])

def render(pdf):
    sh("pdftoppm", "-r", "72", "-png", "-singlefile", pdf, pdf + "-r")
    return np.asarray(Image.open(pdf + "-r.png").convert("RGB")).astype(int)
def bbox(img, which):
    r, g, b = img[..., 0], img[..., 1], img[..., 2]
    m = {"red": (r > 200) & (g < 60) & (b < 60), "blue": (b > 200) & (r < 60) & (g < 60), "green": (g > 200) & (r < 60) & (b < 60)}[which]
    ys, xs = np.nonzero(m)
    if len(xs) == 0: return None
    return (xs.min(), ys.min(), xs.max() + 1, ys.max() + 1)
def near(a, b, tol=2.5): return a is not None and all(abs(x - y) <= tol for x, y in zip(a, b))
def apply(src, out, ops): return harness(cls, "apply", src, out, ops)[0]
def qpdf_ok(pdf): return sh("qpdf", "--check", pdf).returncode == 0
def stream_clean(pdf):
    """No operator with operands it cannot take (a dangling name left by a bad delete shows up as `Q` / `q` with an operand)."""
    with pikepdf.open(pdf) as d:
        return all(not (str(op) in ("q", "Q", "BT", "ET") and len(ops) > 0) for ops, op in pikepdf.parse_content_stream(d.pages[0]))
def nimg(pdf):
    r = sh("pdfimages", "-list", pdf); return max(0, len(r.stdout.strip().splitlines()) - 2)

print("== A. liệt kê")
L = harness(cls, "list", BASE, "1")
check(len(L) == 2, f"2 ảnh được liệt kê: {L}")
f = L[0].split("|")[0].split()
check([int(f[1]), int(f[2])] == [40, 24] and all(abs(float(a) - b) < 0.01 for a, b in zip(f[3:7], [100, 500, 300, 620])), f"khung ảnh đỏ trong hệ trang = (100, 500, 300, 620): {f}")
pl = [float(v) for v in L[0].split("|")[1].split()]
check(all(abs(a - b) < 1e-3 for a, b in zip(pl, [100 / 612, 1 - 620 / 792, 300 / 612, 1 - 500 / 792])), f"phân số trên trang hiển thị (gốc trên-trái): {pl}")
check(harness(cls, "pick", BASE, "1", "0.3", "0.3")[0] == "0" and harness(cls, "pick", BASE, "1", "0.6", "0.65")[0] == "1" and harness(cls, "pick", BASE, "1", "0.9", "0.05")[0] == "-", "chạm chọn đúng ảnh (đỏ, xanh, chỗ trống -> không có)")
OV = P("overlap.pdf"); make_pdf(OV, [(solid(RED), 100, 400, 300, 300), (solid(GREEN), 200, 500, 60, 60)])
check(harness(cls, "pick", OV, "1", "0.4", "0.3")[0] == "1", "ảnh nhỏ nằm trên ảnh lớn thì chọn ảnh nhỏ")

print("== B. xoá")
base_img = render(BASE); red0, blue0 = bbox(base_img, "red"), bbox(base_img, "blue")
check(near(red0, (100, 172, 300, 292)) and near(blue0, (300, 442, 450, 592)), f"hình gốc do poppler vẽ: đỏ {red0}, xanh {blue0}")
out = P("del.pdf"); check(apply(BASE, out, "del:1:0") == "OK", "xoá ảnh đỏ")
img = render(out)
check(bbox(img, "red") is None and near(bbox(img, "blue"), blue0), "ảnh đỏ biến mất, ảnh xanh nguyên chỗ")
check(nimg(out) == 1 and qpdf_ok(out) and stream_clean(out), "pdfimages: còn 1 ảnh; qpdf --check sạch; luồng nội dung không còn toán hạng thừa")

print("== C. di chuyển / đổi cỡ / xoay")
out = P("mv.pdf"); check(apply(BASE, out, "tf:1:0:0.1:0.05:1:0") == "OK", "dịch ảnh đỏ phải 10 %, xuống 5 %")
img = render(out); check(near(bbox(img, "red"), (100 + 61.2, 172 + 39.6, 300 + 61.2, 292 + 39.6)) and near(bbox(img, "blue"), blue0), f"đỏ dịch (+61,+40) px, xanh đứng yên: {bbox(img, 'red')}")
out = P("sc.pdf"); apply(BASE, out, "tf:1:0:0:0:0.5:0"); img = render(out)
check(near(bbox(img, "red"), (150, 202, 250, 262)), f"thu nhỏ 50 % quanh tâm: {bbox(img, 'red')} (mong đợi (150,202,250,262))")
out = P("sc2.pdf"); apply(BASE, out, "tf:1:1:0:0:2:0"); img = render(out)
check(near(bbox(img, "blue"), (225, 367, 525, 667)), f"phóng 200 % quanh tâm: {bbox(img, 'blue')}")
TT = P("tt.pdf"); make_pdf(TT, [(two_tone(), 100, 500, 200, 100)])
def halves(pdf):
    img = render(pdf); r, b = bbox(img, "red"), bbox(img, "blue"); return r, b
r0, b0 = halves(TT); check(near(r0, (100, 192, 200, 292)) and near(b0, (200, 192, 300, 292)), f"ảnh hai nửa: đỏ trái, xanh phải: {r0} {b0}")
out = P("rot.pdf"); check(apply(TT, out, "tf:1:0:0:0:1:90") == "OK", "xoay 90 độ thuận chiều kim đồng hồ")
r1, b1 = halves(out)
check(near(r1, (150, 142, 250, 242)) and near(b1, (150, 242, 250, 342)), f"đỏ lên TRÊN, xanh xuống dưới, tâm giữ nguyên (200,242): {r1} {b1}")
out = P("rot2.pdf"); apply(TT, out, "tf:1:0:0:0:1:-90"); r2, b2 = halves(out)
check(near(r2, (150, 242, 250, 342)) and near(b2, (150, 142, 250, 242)), f"xoay -90: đỏ xuống dưới: {r2} {b2}")
out = P("rot3.pdf"); apply(TT, out, "tf:1:0:0:0:1:180"); r3, b3 = halves(out)
check(near(r3, (200, 192, 300, 292)) and near(b3, (100, 192, 200, 292)), f"xoay 180: hai nửa đổi chỗ: {r3} {b3}")
out = P("combo.pdf"); apply(BASE, out, "tf:1:0:0.1:0:0.5:0;del:1:1"); img = render(out)
check(near(bbox(img, "red"), (211.2, 202, 311.2, 262)) and bbox(img, "blue") is None and qpdf_ok(out), f"nhiều thao tác liền (đổi cỡ + dịch rồi xoá ảnh kia): {bbox(img, 'red')}")
out = P("order.pdf"); check(apply(BASE, out, "del:1:0;tf:1:1:0:0:2:0") == "OK", "xoá ảnh 0 được đòi TRƯỚC, đổi cỡ ảnh 1 sau: vẫn đúng ảnh gốc số 1")
img = render(out); check(bbox(img, "red") is None and near(bbox(img, "blue"), (225, 367, 525, 667)), f"đỏ đã xoá, xanh phóng 200 % (không bị dịch số): {bbox(img, 'blue')}")
out = P("order2.pdf"); check(apply(BASE, out, "del:1:0;del:1:1") == "OK" and nimg(out) == 0, "xoá cả hai lần vẽ theo thứ tự bất kỳ")
out = P("two.pdf"); apply(BASE, out, "tf:1:0:0.1:0:1:0;tf:1:0:0.1:0:1:0"); check(near(bbox(render(out), "red"), (100 + 122.4, 172, 300 + 122.4, 292)), "hai lần dịch cộng dồn (CTM đã sửa được sửa tiếp)")

print("== D. thay ảnh")
def raw(path, color, w, h): open(path, "wb").write(bytes(color) * (w * h))
raw(P("flat.raw"), GREEN, 40, 20); raw(P("tall.raw"), GREEN, 20, 40)
out = P("rep1.pdf"); check(apply(BASE, out, f"rep:1:0:40:20:{P('flat.raw')}") == "OK", "thay ảnh đỏ bằng ảnh xanh lá dẹt 40x20")
img = render(out); check(near(bbox(img, "green"), (100, 182, 300, 282)) and bbox(img, "red") is None and near(bbox(img, "blue"), blue0), f"giữ tỉ lệ 2:1, nằm giữa khung cũ: {bbox(img, 'green')} (mong đợi (100,182,300,282))")
out = P("rep2.pdf"); apply(BASE, out, f"rep:1:0:20:40:{P('tall.raw')}"); img = render(out)
check(near(bbox(img, "green"), (170, 172, 230, 292)), f"ảnh cao 1:2: {bbox(img, 'green')} (mong đợi (170,172,230,292))")
check(qpdf_ok(out) and nimg(out) == 2, "qpdf sạch; vẫn 2 ảnh trên trang")
out = P("rep3.pdf"); apply(TT, out, "tf:1:0:0:0:1:90;rep:1:0:40:20:" + P("flat.raw")); g = bbox(render(out), "green")
check(near(g, (150, 142, 250, 342)), f"thay ảnh đã xoay 90 độ vẫn theo khung xoay (rộng 100, cao 200 trên trang): {g}")

print("== D2. lật / độ trong suốt / cắt (như WPS: lật, trong suốt, cắt)")
def two_tone_v(size=(24, 40)):
    im = Image.new("RGB", size, (255, 0, 0)); im.paste((0, 0, 255), (0, size[1] // 2, size[0], size[1])); return im
VV = P("vv.pdf"); make_pdf(VV, [(two_tone_v(), 100, 500, 100, 200)])
rv, bv = halves(VV); check(near(rv, (100, 92, 200, 192)) and near(bv, (100, 192, 200, 292)), f"ảnh hai nửa trên-dưới: đỏ trên, xanh dưới: {rv} {bv}")
out = P("fh.pdf"); check(apply(TT, out, "tf:1:0:0:0:1:0:h") == "OK", "lật ngang ảnh đỏ-trái / xanh-phải")
rf, bf = halves(out); check(near(rf, (200, 192, 300, 292)) and near(bf, (100, 192, 200, 292)), f"sau lật ngang: xanh trái, đỏ phải: {rf} {bf}")
out = P("fv.pdf"); apply(VV, out, "tf:1:0:0:0:1:0:v"); rg, bg = halves(out)
check(near(rg, (100, 192, 200, 292)) and near(bg, (100, 92, 200, 192)), f"lật dọc: xanh lên trên, đỏ xuống dưới: {rg} {bg}")
out = P("fv2.pdf"); apply(VV, out, "tf:1:0:0:0:1:0:h"); rg, bg = halves(out)
check(near(rg, rv) and near(bg, bv), "lật NGANG ảnh trên-dưới: không đổi chỗ hai nửa")
out = P("fhv.pdf"); apply(TT, out, "tf:1:0:0:0:1:0:hv"); rg, bg = halves(out)
check(near(rg, (200, 192, 300, 292)) and near(bg, (100, 192, 200, 292)), "lật cả ngang lẫn dọc ảnh trái-phải: đổi chỗ trái-phải")
RT = P("r90tt.pdf"); make_pdf(RT, [(two_tone(), 100, 500, 200, 100)], rotate=90)
rr, br = halves(RT); check(rr[1] < br[1], f"trang xoay 90: đỏ nằm TRÊN xanh khi nhìn: {rr} {br}")
out = P("r90fv.pdf"); apply(RT, out, "tf:1:0:0:0:1:0:v"); r2, b2 = halves(out)
check(r2[1] > b2[1] and near(r2, (rr[0], br[1], rr[2], br[3])), f"trang xoay 90, lật dọc THEO TRANG NHÌN THẤY: đỏ xuống dưới xanh: {r2} {b2}")
out = P("r90fh.pdf"); apply(RT, out, "tf:1:0:0:0:1:0:h"); r3, b3 = halves(out)
check(near(r3, rr) and near(b3, br), "trang xoay 90, lật ngang theo trang nhìn thấy: đỏ vẫn trên, xanh vẫn dưới")
out = P("op.pdf"); check(apply(BASE, out, "tf:1:0:0:0:1:0:-:0.5") == "OK", "độ trong suốt 50 % cho ảnh đỏ")
img = render(out); px = img[232, 200]; check(px[0] > 240 and 110 < px[1] < 145 and 110 < px[2] < 145, f"ảnh đỏ 50 % trên nền trắng ra hồng (255,~128,~128): {tuple(px)}")
check(tuple(img[517, 375]) == (0, 0, 255), "ảnh xanh không bị ảnh hưởng (vẫn xanh đặc)")
out = P("op2.pdf"); check(apply(BASE, out, "tf:1:0:0:0:1:0:-:0.0").startswith("ERR:") and apply(BASE, out, "tf:1:0:0:0:1:0:-:1.5").startswith("ERR:"), "độ trong suốt 0 hoặc > 1: từ chối")
out = P("cr.pdf"); check(apply(BASE, out, "crop:1:0:0.25:0.5:0:0") == "OK", "cắt bỏ 25 % bên trái và 50 % phía trên ảnh đỏ")
img = render(out); check(near(bbox(img, "red"), (150, 232, 300, 292)) and near(bbox(img, "blue"), blue0), f"phần còn lại (150,232,300,292), ảnh xanh nguyên: {bbox(img, 'red')}")
check(qpdf_ok(out) and nimg(out) == 2, "qpdf sạch; ảnh vẫn còn nguyên trong tệp (chỉ ẩn bằng khung cắt)")
out = P("cr2.pdf"); apply(BASE, out, "crop:1:0:0:0:0.5:0.5"); check(near(bbox(render(out), "red"), (100, 172, 200, 232)), f"cắt phải + dưới 50 %: {bbox(render(out), 'red')}")
out = P("cr3.pdf"); apply(BASE, out, "tf:1:0:0:0:1:90;crop:1:0:0:0.5:0:0"); check(near(bbox(render(out), "red"), (140, 232, 260, 332)), f"xoay 90 độ rồi cắt nửa trên: {bbox(render(out), 'red')} (mong đợi (140,232,260,332))")
out = P("cr5.pdf"); apply(TT, out, "crop:1:0:0.5:0:0:0"); r5, b5 = halves(out)
check(r5 is None and near(b5, (200, 192, 300, 292)), f"cắt nửa trái của ảnh đỏ-trái / xanh-phải: chỉ còn xanh: {r5} {b5}")
for desc, ops in (("cắt 97 %", "crop:1:0:0.97:0:0:0"), ("trái + phải >= 100 %", "crop:1:0:0.5:0:0.5:0"), ("cắt số âm", "crop:1:0:-0.1:0:0:0")):
    o = P("badcrop.pdf")
    if os.path.exists(o): os.remove(o)
    res = apply(BASE, o, ops); check(res.startswith("ERR:") and not os.path.exists(o), f"{desc} -> lỗi, không để lại tệp")

print("== E. một ảnh vẽ hai lần")
TW = P("twice.pdf"); im = solid(RED); make_pdf(TW, [(im, 100, 600, 100, 60), (im, 350, 600, 100, 60)])
with pikepdf.open(TW) as pdf:
    xo = pdf.pages[0].Resources.XObject; check(len(xo.keys()) == 1, f"dựng đúng: 1 XObject dùng 2 lần ({len(xo.keys())})")
out = P("twice-mv.pdf"); apply(TW, out, "tf:1:0:0:0.2:1:0"); img = render(out)
ys, xs = np.nonzero((img[..., 0] > 200) & (img[..., 1] < 60) & (img[..., 2] < 60))
left = ys[xs < 300]; right = ys[xs >= 300]
check(left.min() >= 132 + 150 - 2 and right.min() <= 133 and right.max() <= 193, f"chỉ ảnh thứ nhất bị dịch xuống 20 %: trái y {left.min()}..{left.max()}, phải y {right.min()}..{right.max()}")
out = P("twice-del.pdf"); apply(TW, out, "del:1:1"); xs2 = np.nonzero((render(out)[..., 0] > 200) & (render(out)[..., 1] < 60))[1]
check(xs2.max() < 300 and xs2.min() >= 99, "xoá chỉ lần vẽ thứ hai, lần đầu còn")

print("== F. trang xoay 90 độ")
RP = P("r90.pdf"); make_pdf(RP, [(solid(RED), 100, 500, 200, 120)], rotate=90)
img = render(RP); rb = bbox(img, "red"); check(img.shape[1] == 792 and img.shape[0] == 612, f"trang vẽ ngang 792x612: {img.shape[:2]}")
LR = harness(cls, "list", RP, "1")[0].split("|")[1].split(); pl = [float(v) for v in LR]
check(all(abs(a - b) < 0.004 for a, b in zip(pl, [rb[0] / 792, rb[1] / 612, rb[2] / 792, rb[3] / 612])), f"phân số trên trang xoay khớp hình poppler vẽ: {pl} so với {[round(rb[0]/792,4), round(rb[1]/612,4), round(rb[2]/792,4), round(rb[3]/612,4)]}")
out = P("r90-mv.pdf"); apply(RP, out, "tf:1:0:0.1:0.05:1:0"); r2 = bbox(render(out), "red")
check(near(r2, (rb[0] + 79.2, rb[1] + 30.6, rb[2] + 79.2, rb[3] + 30.6)), f"dịch phải 10 % và xuống 5 % THEO TRANG NHÌN THẤY: {r2} (gốc {rb})")
check(qpdf_ok(out), "qpdf sạch")
out = P("cr4.pdf"); apply(RP, out, "crop:1:0:0.25:0:0:0"); r4 = bbox(render(out), "red")
check(near(r4, (rb[0] + 0.25 * (rb[2] - rb[0]), rb[1], rb[2], rb[3])), f"trang xoay 90: cắt 25 % bên trái THEO TRANG NHÌN THẤY: {r4} (gốc {rb})")

print("== G. thao tác sai")
for desc, ops in (("chỉ số ảnh lạ", "del:1:5"), ("trang lạ", "del:3:0"), ("tỉ lệ 0", "tf:1:0:0:0:0:0"), ("xoá hai lần cùng chỉ số 1 (ảnh thứ hai đã mất)", "del:1:1;del:1:1")):
    o = P("bad.pdf")
    if os.path.exists(o): os.remove(o)
    res = apply(BASE, o, ops); check(res.startswith("ERR:") and not os.path.exists(o), f"{desc} -> lỗi và không để lại tệp: {res[:70]}")
NOIMG = P("noimg.pdf"); c = canvas.Canvas(NOIMG, pagesize=(612, 792)); c.drawString(100, 700, "no pictures here"); c.showPage(); c.save()
check(harness(cls, "list", NOIMG, "1") == [], "trang không có ảnh: danh sách rỗng")
check(apply(NOIMG, P("noimg-out.pdf"), "del:1:0").startswith("ERR:"), "xoá ảnh ở trang không có ảnh: lỗi")

print("== H. thử âm tính")
def scenario(c):
    def go(src, name, ops):
        o = P(name); 
        if os.path.exists(o): os.remove(o)
        r = harness(c, "apply", src, o, ops)[0]
        return o if r == "OK" and os.path.exists(o) else None
    ok = []
    o = go(BASE, "m1.pdf", "tf:1:0:0.1:0.05:1:0"); ok.append(bool(o) and near(bbox(render(o), "red"), (161.2, 211.6, 361.2, 331.6)))
    o = go(TT, "m2.pdf", "tf:1:0:0:0:1:90"); ok.append(bool(o) and near(halves(o)[0] or (0, 0, 0, 0), (150, 142, 250, 242)))
    o = go(BASE, "m3.pdf", "del:1:0"); ok.append(bool(o) and bbox(render(o), "red") is None and qpdf_ok(o) and stream_clean(o))
    o = go(BASE, "m4.pdf", f"rep:1:0:40:20:{P('flat.raw')}"); ok.append(bool(o) and near(bbox(render(o), "green") or (0, 0, 0, 0), (100, 182, 300, 282)))
    o = go(BASE, "m5.pdf", "tf:1:1:0:0:2:0"); ok.append(bool(o) and near(bbox(render(o), "blue") or (0, 0, 0, 0), (225, 367, 525, 667)))
    o = go(RP, "m6.pdf", "tf:1:0:0.1:0:1:0"); ok.append(bool(o) and near(bbox(render(o), "red") or (0, 0, 0, 0), (rb[0] + 79.2, rb[1], rb[2] + 79.2, rb[3])))
    o = go(TT, "m7.pdf", "tf:1:0:0:0:1:0:h"); ok.append(bool(o) and near(halves(o)[0] or (0, 0, 0, 0), (200, 192, 300, 292)))
    o = go(BASE, "m8.pdf", "crop:1:0:0.25:0.5:0:0"); ok.append(bool(o) and near(bbox(render(o), "red") or (0, 0, 0, 0), (150, 232, 300, 292)))
    o = go(BASE, "m9.pdf", "tf:1:0:0:0:1:0:-:0.5"); ok.append(bool(o) and 110 < render(o)[232, 200][1] < 145)
    o = go(RT, "m10.pdf", "tf:1:0:0:0:1:0:v"); ok.append(bool(o) and (halves(o)[0] or (0, 0, 0, 0))[1] > (halves(o)[1] or (0, 0, 0, 0))[1])
    return ok
check(all(scenario(cls)), "đối chứng: mã gốc đạt cả 10 phép thử")
if "--fast" not in sys.argv:
    MUT = (("bỏ nghịch đảo CTM (ma trận dùng sai hệ toạ độ)", "val local = multiply(multiply(f.ctm, multiply(flip, aboutCentre)), ctmInv)", "val local = multiply(f.ctm, multiply(flip, aboutCentre))"),
           ("xoay ngược chiều", "Math.toRadians(-op.turnDegrees.toDouble())", "Math.toRadians(op.turnDegrees.toDouble())"),
           ("xoá chỉ bỏ Do, để lại tên (luồng hỏng)", "        scan.tokens.removeAt(f.nameIndex)\n        writeBack(document, pageNumber, scan.tokens)\n        return Result.SUCCESS\n    }\n\n    fun transform", "        writeBack(document, pageNumber, scan.tokens)\n        return Result.SUCCESS\n    }\n\n    fun transform"),
           ("thay ảnh không giữ tỉ lệ (kéo đầy khung)", "if (aspect > wOld / hOld) { sx = 1f; sy = (wOld / aspect) / hOld } else { sy = 1f; sx = (hOld * aspect) / wOld }", "sx = 1f; sy = 1f"),
           ("không đổi cỡ quanh tâm (quanh gốc trang)", "floatArrayOf(1f, 0f, 0f, 1f, -cx, -cy), floatArrayOf(op.scale", "floatArrayOf(1f, 0f, 0f, 1f, 0f, 0f), floatArrayOf(op.scale"),
           ("lật bị bỏ qua", "if (op.flipH) flip =", "if (false) flip ="),
           ("cắt nhầm cạnh trên / dưới", "val y0 = minY + op.bottom * h; val y1 = maxY - op.top * h", "val y0 = minY + op.top * h; val y1 = maxY - op.bottom * h"),
           ("độ trong suốt không được áp", "cmTokens(local, gsName)", "cmTokens(local, null)"),
           ("lật làm trong hệ ảnh (không theo trang nhìn thấy)", "val cdy = cx * minv[1] + cy * minv[3] + minv[5]\n        if (op.flipH) flip = multiply(flip, multiply(multiply(minv, floatArrayOf(-1f, 0f, 0f, 1f, 2f * cdx, 0f)), m))\n        if (op.flipV) flip = multiply(flip, multiply(multiply(minv, floatArrayOf(1f, 0f, 0f, -1f, 0f, 2f * cdy)), m))", "val cdy = cx * minv[1] + cy * minv[3] + minv[5]\n        if (op.flipH) flip = multiply(flip, multiply(multiply(minv, floatArrayOf(-1f, 0f, 0f, 1f, 2f * cdx, 0f)), m))\n        if (op.flipV) flip = multiply(flip, multiply(floatArrayOf(1f, 0f, 0f, -1f, 0f, 2f * cy), floatArrayOf(1f, 0f, 0f, 1f, 0f, 0f)))"),
           ("dịch không theo trang xoay (bỏ ma trận hiển thị)", "val shiftX = m[0] * ddx + m[2] * ddy\n        val shiftY = m[1] * ddx + m[3] * ddy", "val shiftX = ddx\n        val shiftY = ddy"))
    for name, old, new in MUT:
        try:
            mdir = tc.compile(FILES, [HARNESS], os.path.join(WORK, "mut"), {"PdfImageEditor.kt": (old, new)}, DOUBLE)[0]
            res = scenario(mdir); check(not all(res), f"mã sai bị bắt: {name} ({res})")
        except RuntimeError as e:
            check(False, f"mutant không biên dịch được: {name}: {str(e)[:150]}")
print(); print("TAT CA DAT" if not fails else f"{len(fails)} LOI")
sys.exit(1 if fails else 0)
