"""EpubSearch (phiên 22, mục 4.49.5): tìm trong EPUB không phân biệt hoa / thường và dấu. Bản Java EpubSearchCheck.java (cùng thuật toán với EpubSearch.kt)
so với một THUẬT TOÁN ĐỐI CHỨNG ĐỘC LẬP viết bằng Python (unicodedata, lập bảng ánh xạ chỉ số theo cách khác):
  - 400 truy vấn x đoạn ngẫu nhiên (chữ Việt có dấu dạng gộp NFC VÀ dạng tách rời NFD, đ / Đ, chữ hoa, khoảng trắng đủ loại gồm NBSP và xuống dòng, emoji,
    ký tự điều khiển): số lần khớp và CHUỖI GỐC được khớp (kể cả dấu tách rời đi kèm) trùng với bản đối chứng;
  - truy vấn không dấu tìm được chữ có dấu, truy vấn có dấu tìm được chữ không dấu, cụm từ vắt qua xuống dòng, truy vấn rỗng / toàn khoảng trắng -> 0;
  - giới hạn: tổng số lần khớp vẫn được đếm đủ khi danh sách bị cắt; ngữ cảnh không cắt đôi cặp thay thế (emoji);
  - THỬ ÂM TÍNH: so khớp ngây thơ (chỉ lowercase) KHÔNG tìm thấy "nguyen" trong "Nguyễn" và bỏ sót dạng NFD -> bài kiểm có răng.
Chạy: python3 epub_search_check.py   (cần java; ~20 giây)
"""
import os, random, subprocess, sys, unicodedata
HERE = os.path.dirname(os.path.abspath(__file__)); JAVA = os.path.join(HERE, "EpubSearchCheck.java")
ENV = dict(os.environ, LC_ALL="C.UTF-8")
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

def units(s): b = s.encode("utf-16-le", "surrogatepass"); return "".join(f"{int.from_bytes(b[i:i+2],'little'):04x}" for i in range(0, len(b), 2))
def from_units(h): return b"".join(int(h[i:i+4], 16).to_bytes(2, "little") for i in range(0, len(h), 4)).decode("utf-16-le", "surrogatepass")

def java_search(book, queries, limit=300):
    lines = []
    for ch in book:
        lines.append("C")
        for p in ch: lines.append("P " + units(p))
    for q in queries: lines.append("Q " + units(q)); lines.append(f"RUN {limit}")
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", JAVA], input=("\n".join(lines) + "\n").encode("ascii"), capture_output=True, env=ENV)
    if r.returncode != 0: raise RuntimeError(r.stderr.decode()[-1500:])
    out = r.stdout.decode("utf-8").split("\n"); results = []; cur = None
    for l in out:
        if l.startswith("TOTAL"): cur = [int(l.split()[1]), []]
        elif l == "END": results.append(cur)
        elif l:
            ci, pi, b, m, a = l.split(" ") if l.count(" ") == 4 else (l.split(" ") + [""] * 5)[:5]
            cur[1].append((int(ci), int(pi), from_units(b), from_units(m), from_units(a)))
    return results

# ---------- THUẬT TOÁN ĐỐI CHỨNG (độc lập) ----------
def ref_fold(s):
    """-> (folded, origin) with origin[i] = index in s of the char that produced folded[i]; whitespace runs -> one space; marks dropped; đ -> d"""
    out, origin, pending_space = [], [], False
    for i, ch in enumerate(s):
        if ch.isspace() or unicodedata.category(ch) in ("Zs", "Zl", "Zp"):
            if out and not pending_space: pending_space = (i,)
            continue
        if unicodedata.category(ch) in ("Mn", "Mc", "Me"): continue
        low = ch.lower()
        if len(low) != 1: low = ch                      # Java toLowerCase(char) is 1:1; keep as is (e.g. 'İ')
        if low in ("đ",): low = "d"
        else:
            d = unicodedata.normalize("NFD", low)
            low = d[0]
            if unicodedata.category(low) in ("Mn", "Mc", "Me"): continue
        if pending_space:
            out.append(" "); origin.append(pending_space[0]); pending_space = False
        out.append(low); origin.append(i)
    return "".join(out), origin

def ref_search(book, query):
    needle, _ = ref_fold(query); hits = []
    if not needle: return 0, hits
    for ci, ch in enumerate(book):
        for pi, para in enumerate(ch):
            text, origin = ref_fold(para); pos = 0
            while True:
                at = text.find(needle, pos)
                if at < 0: break
                start = origin[at]; end = origin[at + len(needle) - 1] + 1
                while end < len(para) and unicodedata.category(para[end]) in ("Mn", "Mc", "Me"): end += 1
                hits.append((ci, pi, " ".join(para[start:end].split()) if False else para[start:end]))
                pos = at + len(needle)
    return len(hits), hits

rnd = random.Random(2205)
VN = "ăâêôơưđĐáàảãạấầẩẫậếềểễệốồổỗộớờởỡợứừửữựÁÀẢÃẠẤẦẨẪẬ"
def nfd(s): return unicodedata.normalize("NFD", s)
words = ["Nguyễn", "đường", "Đường", "Hà Nội", "tiếng Việt", "người", "ngữ", "xin chào", "thế giới", "cuốn sách", "Sài Gòn", "chương", "phố", "cà phê", "trời", "mưa", "ánh sáng", "bóng tối", "Alice", "wonderland", "😀", "café", "naïve", "Zażółć", "straße"]
seps = [" ", "  ", "\u00a0", "\n", " \t ", ", ", ". ", "\u2003"]
def rand_para():
    parts = []
    for _ in range(rnd.choice([0, 1, 3, 8, 20])):
        w = rnd.choice(words); r = rnd.random()
        parts.append(nfd(w) if r < 0.3 else w.upper() if r < 0.4 else w.lower() if r < 0.5 else w)
        parts.append(rnd.choice(seps))
    return "".join(parts)
book = [[rand_para() for _ in range(rnd.choice([0, 2, 5]))] for _ in range(8)]
queries = ["nguyen", "NGUYỄN", nfd("Nguyễn"), "duong", "Đường", "đuong", "ha noi", "hà   nội", "tieng viet", "tiếng\nViệt", "nguoi ngu", "xin chao", "alice", "😀", "cafe", "naive", "zazolc", "strasse", "a", "e", "ế", "xyz-not-there", "", "   ", "\u00a0", "cuon sach, ", ". "]
for _ in range(370):
    w = rnd.choice(words); q = w[rnd.randrange(len(w)):][:rnd.randrange(1, 8)] if len(w) > 1 else w
    queries.append(rnd.choice([q, q.lower(), q.upper(), nfd(q)]))
got = java_search(book, queries, limit=100000)
bad = []
for q, (total, hits) in zip(queries, got):
    want_total, want = ref_search(book, q)
    java_matches = [(h[0], h[1], h[3]) for h in hits]
    want_matches = [(ci, pi, " ".join(m.split())) for ci, pi, m in want]
    if total != want_total or java_matches != want_matches: bad.append((q, total, want_total, java_matches[:2], want_matches[:2]))
check(not bad, f"{len(queries)} truy vấn x sách ngẫu nhiên (NFC + NFD, đ, hoa / thường, NBSP, xuống dòng, emoji): số lần khớp VÀ chuỗi gốc được khớp = bản đối chứng độc lập{'' if not bad else ' ' + str(bad[:2])}")

# ---------- tình huống có tên ----------
b1 = [["Ông Nguyễn Văn A đi trên đường Lê Lợi."], ["Chương hai: NGUYỄN và nguyễn.", "Không có gì."]]
res = java_search(b1, ["nguyen", "duong le", "van a di", "NGUYỄN VĂN", ""])
check(res[0][0] == 3 and [h[3] for h in res[0][1]] == ["Nguyễn", "NGUYỄN", "nguyễn"], "\"nguyen\" tìm thấy Nguyễn / NGUYỄN / nguyễn và trả đúng chữ gốc")
check(res[1][0] == 1 and res[1][1][0][3] == "đường Lê", "\"duong le\" tìm thấy \"đường Lê\" (đ = d, cụm từ nhiều chữ)")
check(res[2][0] == 1 and res[2][1][0][3] == "Văn A đi", "cụm từ \"van a di\" khớp qua nhiều từ")
check(res[3][0] == 1 and res[4][0] == 0, "truy vấn có dấu hoa tìm được; truy vấn rỗng -> 0 kết quả")
b2 = [[nfd("Tiếng Việt") + " rất hay"]]
r2 = java_search(b2, ["tieng viet", "tiếng việt", "Việt rất"])
check(all(r[0] == 1 for r in r2) and r2[0][1][0][3] == nfd("Tiếng Việt") and r2[2][1][0][3] == nfd("Việt") + " rất", "sách lưu dấu dạng TÁCH RỜI: khớp cả hai kiểu gõ và chuỗi trả về giữ nguyên dấu tách rời của chữ cuối")
b3 = [["Dòng một\nvà dòng\u00a0hai   kết thúc."]]
r3 = java_search(b3, ["mot va dong hai"]); check(r3[0][0] == 1, "cụm từ vắt qua xuống dòng / NBSP / nhiều khoảng trắng vẫn khớp")

# ---------- giới hạn và ngữ cảnh ----------
b4 = [["lặp " * 50]] * 10                            # 500 lần \"lặp\"
r4 = java_search(b4, ["lap"], limit=300)
check(r4[0][0] == 500 and len(r4[0][1]) == 300, "giới hạn 300: danh sách bị cắt nhưng TỔNG vẫn đếm đủ 500")
emoji = ["x" * 58 + "😀" + "needle" + "😀" + "y" * 58]
r5 = java_search([emoji], ["needle"])
h = r5[0][1][0]
bad_pairs = [s for s in (h[2], h[4]) if any(0xD800 <= ord(c) <= 0xDFFF for c in s)]
check(not bad_pairs and h[3] == "needle", "ngữ cảnh không cắt đôi cặp thay thế (emoji) ở hai đầu")
check(h[2].startswith("…") is False or len(h[2]) <= 61, "ngữ cảnh trước <= 60 ký tự (+ dấu …)")
long_para = [["a" * 200 + " needle " + "b" * 200]]
h = java_search(long_para, ["needle"])[0][1][0]
check(h[2].startswith("…") and h[4].endswith("…") and len(h[2]) == 61 and len(h[4]) == 61, "đoạn dài: ngữ cảnh 60 ký tự mỗi bên, có dấu … ở chỗ bị cắt")

# ---------- thử âm tính ----------
naive = lambda text, q: text.lower().count(q.lower())
check(naive("Ông Nguyễn", "nguyen") == 0 and naive(nfd("Nguyễn"), "Nguyễn") == 0, "ÂM TÍNH: so khớp ngây thơ (chỉ lowercase) bỏ sót \"nguyen\" -> \"Nguyễn\" và dạng NFD (bài kiểm có răng)")

print(); print("TAT CA DAT" if not fails else f"{len(fails)} LOI: {fails}")
sys.exit(1 if fails else 0)
