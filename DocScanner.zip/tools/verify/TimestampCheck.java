import java.io.*;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Bản Java song song CÙNG THUẬT TOÁN của util/TimeStamp.kt (dựng TimeStampReq, đọc TimeStampResp, tokenMatches) - phiên 20, 4.48.6. Lệnh stdin: REQ <hex băm> <hex nonce> | RESP <hex> | MATCH <hex token> <hex băm> <hex nonce> */
public class TimestampCheck {
    static byte[] concat(byte[]... p) { int n = 0; for (byte[] b : p) n += b.length; byte[] o = new byte[n]; int i = 0; for (byte[] b : p) { System.arraycopy(b, 0, o, i, b.length); i += b.length; } return o; }
    static byte[] lengthBytes(int n) { if (n < 128) return new byte[]{(byte) n}; if (n < 256) return new byte[]{(byte) 0x81, (byte) n}; if (n < 65536) return new byte[]{(byte) 0x82, (byte) (n >> 8), (byte) n}; return new byte[]{(byte) 0x83, (byte) (n >> 16), (byte) (n >> 8), (byte) n}; }
    static byte[] tlv(int tag, byte[] c) { return concat(new byte[]{(byte) tag}, lengthBytes(c.length), c); }
    static byte[] sequence(byte[]... p) { return tlv(0x30, concat(p)); }
    static byte[] nullValue() { return new byte[]{0x05, 0x00}; }
    static byte[] octetString(byte[] b) { return tlv(0x04, b); }
    static byte[] integer(BigInteger v) { return tlv(0x02, v.toByteArray()); }
    static byte[] oid(String dotted) {
        String[] p = dotted.split("\\."); ByteArrayOutputStream o = new ByteArrayOutputStream(); o.write(Integer.parseInt(p[0]) * 40 + Integer.parseInt(p[1]));
        for (int i = 2; i < p.length; i++) { long v = Long.parseLong(p[i]); List<Integer> b = new ArrayList<>(); b.add((int) (v & 0x7F)); v >>= 7; while (v > 0) { b.add(0, (int) ((v & 0x7F) | 0x80)); v >>= 7; } for (int x : b) o.write(x); }
        return tlv(0x06, o.toByteArray());
    }
    /** [tag, độ dài tiêu đề, độ dài nội dung]; ném ngoại lệ khi vượt dữ liệu, và với độ dài không xác định (BER 0x80) cho nội dung 0 (như DerWriter.header). */
    static int[] header(byte[] d, int off) {
        int tag = d[off] & 0xFF; int first = d[off + 1] & 0xFF;
        if (first < 128) return new int[]{tag, 2, first};
        int cnt = first & 0x7F; int len = 0;
        for (int i = 0; i < cnt; i++) len = (len << 8) | (d[off + 2 + i] & 0xFF);
        return new int[]{tag, 2 + cnt, len};
    }
    static final String OID_SHA256 = "2.16.840.1.101.3.4.2.1";

    static byte[] buildRequest(byte[] digest, BigInteger nonce) {
        byte[] imprint = sequence(sequence(oid(OID_SHA256), nullValue()), octetString(digest));
        return sequence(integer(BigInteger.ONE), imprint, integer(nonce), tlv(0x01, new byte[]{(byte) 0xFF}));
    }

    static String parseResponse(byte[] d) {
        try {
            int[] outer = header(d, 0);
            if (!(outer[0] == 0x30 && outer[1] + outer[2] <= d.length)) throw new IllegalArgumentException();
            int end = outer[1] + outer[2], p = outer[1];
            int[] info = header(d, p);
            if (info[0] != 0x30) throw new IllegalArgumentException();
            int[] st = header(d, p + info[1]);
            if (!(st[0] == 0x02 && st[2] >= 1 && st[2] <= 4)) throw new IllegalArgumentException();
            int status = 0;
            for (int i = 0; i < st[2]; i++) status = (status << 8) | (d[p + info[1] + st[1] + i] & 0xFF);
            p += info[1] + info[2];
            String token = "-";
            if (p < end) {
                int[] t = header(d, p);
                if (!(t[0] == 0x30 && p + t[1] + t[2] <= end)) throw new IllegalArgumentException();
                token = hex(Arrays.copyOfRange(d, p, p + t[1] + t[2]));
            }
            return status + "|" + token;
        } catch (IndexOutOfBoundsException | IllegalArgumentException e) { return "ERR"; }
    }

    static boolean tokenMatches(byte[] token, byte[] digest, BigInteger nonce) {
        try {
            int[] ci = header(token, 0);
            if (ci[0] != 0x30 || ci[1] + ci[2] != token.length) return false;
            int p = ci[1];
            int[] oid = header(token, p); p += oid[1] + oid[2];
            int[] ex = header(token, p);
            if (ex[0] != 0xA0) return false;
            p += ex[1];
            int[] sd = header(token, p);
            if (sd[0] != 0x30) return false;
            p += sd[1];
            int[] ver = header(token, p); p += ver[1] + ver[2];
            int[] algs = header(token, p); p += algs[1] + algs[2];
            int[] enc = header(token, p);
            if (enc[0] != 0x30) return false;
            p += enc[1];
            int[] ct = header(token, p); p += ct[1] + ct[2];
            int[] a0 = header(token, p);
            if (a0[0] != 0xA0) return false;
            p += a0[1];
            int[] oct = header(token, p);
            if (oct[0] != 0x04) return false;
            p += oct[1];
            int[] ti = header(token, p);
            if (ti[0] != 0x30) return false;
            int tiEnd = p + ti[1] + ti[2];
            p += ti[1];
            int[] v = header(token, p); p += v[1] + v[2];
            int[] pol = header(token, p); p += pol[1] + pol[2];
            int[] mi = header(token, p);
            if (mi[0] != 0x30) return false;
            int[] alg = header(token, p + mi[1]);
            int[] algOid = header(token, p + mi[1] + alg[1]);
            byte[] expectOid = oid(OID_SHA256);
            byte[] gotOid = Arrays.copyOfRange(token, p + mi[1] + alg[1], p + mi[1] + alg[1] + algOid[1] + algOid[2]);
            if (!Arrays.equals(gotOid, expectOid)) return false;
            int hashOff = p + mi[1] + alg[1] + alg[2];
            int[] hash = header(token, hashOff);
            if (hash[0] != 0x04 || !Arrays.equals(Arrays.copyOfRange(token, hashOff + hash[1], hashOff + hash[1] + hash[2]), digest)) return false;
            p += mi[1] + mi[2];
            int[] ser = header(token, p); p += ser[1] + ser[2];
            int[] gen = header(token, p); p += gen[1] + gen[2];
            while (p < tiEnd) {
                int[] h = header(token, p);
                if (h[0] == 0x02) return new BigInteger(Arrays.copyOfRange(token, p + h[1], p + h[1] + h[2])).equals(nonce);
                p += h[1] + h[2];
            }
            return false;
        } catch (IndexOutOfBoundsException | NegativeArraySizeException | NumberFormatException e) { return false; }
    }

    static String hex(byte[] b) { StringBuilder s = new StringBuilder(); for (byte x : b) s.append(String.format("%02x", x)); return s.toString(); }
    static byte[] unhex(String h) { byte[] b = new byte[h.length() / 2]; for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(h.substring(2 * i, 2 * i + 2), 16); return b; }

    public static void main(String[] a) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8)); String line;
        while ((line = in.readLine()) != null) {
            if (line.isEmpty()) continue; String[] p = line.split(" ", -1);
            switch (p[0]) {
                case "REQ": System.out.println(hex(buildRequest(unhex(p[1]), new BigInteger(p[2], 16)))); break;
                case "RESP": System.out.println(parseResponse(unhex(p[1]))); break;
                case "MATCH": System.out.println(tokenMatches(unhex(p[1]), unhex(p[2]), new BigInteger(p[3], 16))); break;
            }
        }
    }
}
