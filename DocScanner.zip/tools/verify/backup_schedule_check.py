"""Kiểm phần THUẦN của sao lưu theo lịch (`BackupSchedule.kt`, phiên 20, 4.48.5) qua bản Java song song `BackupScheduleCheck.java`.
  A. tên tệp: 2.000 thời điểm ngẫu nhiên x 6 múi giờ (có giờ mùa hè, UTC+7, UTC-3:30, UTC+5:45) = `datetime` + `zoneinfo` của Python.
  B. nhận diện tên: chỉ `docscanner_auto_yyyyMMdd_HHmmss.zip` với ngày giờ có thật; tên của người dùng, bản sao lưu thủ công, ngày không tồn tại (30/2, 25:61) KHÔNG phải của ta.
  C. xoay vòng: 400 thư mục ngẫu nhiên trộn tệp của ta với tệp lạ (ảnh, bản sao lưu thủ công, tên giống mà sai ngày): giữ đúng N bản MỚI NHẤT của ta, không bao giờ xoá tệp lạ,
     không xoá khi chưa vượt N, N ngoài 1..30 bị kẹp, tên trùng chỉ tính một lần.
  D. đến hạn: đúng ranh giới (chu kỳ - 6 giờ), chưa từng chạy, TẮT.
  E. thử âm tính: bản hỏng 'xoá mọi .zip' và 'sắp theo thứ tự đổi ngược' bị bắt.
Chạy: python3 backup_schedule_check.py   (cần java, Python 3.9+ zoneinfo)"""
import os, random, re, subprocess, sys, tempfile, shutil
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import OUT

HERE = os.path.dirname(os.path.abspath(__file__)); JAVA = os.path.join(HERE, "BackupScheduleCheck.java")
FAIL = []; rnd = random.Random(20261023)
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: FAIL.append(msg)
    return ok
def jv(lines, java=JAVA):
    r = subprocess.run(["java", java], input="\n".join(lines) + "\n", capture_output=True, text=True)
    if r.returncode: print(r.stderr[-1500:]); sys.exit(1)
    return r.stdout.split("\n")[:len(lines)]

ZONES = ["UTC", "Asia/Ho_Chi_Minh", "America/New_York", "Europe/Paris", "America/St_Johns", "Asia/Kathmandu"]
def py_name(ms, z): return "docscanner_auto_" + datetime.fromtimestamp(ms / 1000, ZoneInfo(z)).strftime("%Y%m%d_%H%M%S") + ".zip"
def py_ours(n):
    m = re.fullmatch(r"docscanner_auto_([0-9]{8}_[0-9]{6})\.zip", n)
    if not m: return False
    try: datetime.strptime(m.group(1), "%Y%m%d_%H%M%S"); return True
    except ValueError: return False
def py_del(names, keep):
    k = max(1, min(30, keep)); ours = sorted({n for n in names if py_ours(n)}, reverse=True); return ours[k:]

def main():
    tmp = tempfile.mkdtemp(dir=OUT)
    try:
        print("== A. tên tệp")
        cases = [(rnd.randint(946684800000, 4102444800000), rnd.choice(ZONES)) for _ in range(2000)]
        # ranh giới giờ mùa hè (New York 2026-03-08 02:00 -> 03:00; 2026-11-01 02:00 lùi về 01:00)
        cases += [(int(datetime(2026, 3, 8, 6, 59, 59, tzinfo=timezone.utc).timestamp() * 1000), "America/New_York"), (int(datetime(2026, 3, 8, 7, 0, 0, tzinfo=timezone.utc).timestamp() * 1000), "America/New_York"),
                  (int(datetime(2026, 11, 1, 5, 30, 0, tzinfo=timezone.utc).timestamp() * 1000), "America/New_York"), (int(datetime(2026, 11, 1, 6, 30, 0, tzinfo=timezone.utc).timestamp() * 1000), "America/New_York")]
        out = jv([f"NAME\t{ms}\t{z}" for ms, z in cases])
        bad = [(c, o, py_name(*c)) for c, o in zip(cases, out) if o != py_name(*c)]
        check(not bad, f"tên tệp: {len(cases)} thời điểm x 6 múi giờ (kể cả ranh giới giờ mùa hè) = datetime + zoneinfo của Python ({len(bad)} lệch {bad[:2]})")

        print("== B. nhận diện tên")
        names = ["docscanner_auto_20261023_143000.zip", "docscanner_auto_20240229_235959.zip", "docscanner_auto_20240230_100000.zip", "docscanner_auto_20261023_256100.zip", "docscanner_auto_20261323_100000.zip",
                 "docscanner_auto_20261023_143000.zip.tmp", "docscanner_auto_20261023_143000 (1).zip", "docscanner_backup_20261023_143000.zip", "DOCSCANNER_AUTO_20261023_143000.ZIP", "photo.jpg", "docscanner_auto_2026102_143000.zip",
                 "xdocscanner_auto_20261023_143000.zip", "docscanner_auto_20230229_000000.zip", "docscanner_auto_20000229_000000.zip", "docscanner_auto_19000229_000000.zip", ""]
        out = jv([f"OURS\t{n}" for n in names])
        bad = [(n, o) for n, o in zip(names, out) if (o == "true") != py_ours(n)]
        check(not bad, f"nhận diện {len(names)} tên (ngày 30/2, giờ 25:61, tháng 13, năm nhuận 2024 / 2000 và KHÔNG nhuận 1900 / 2023, hậu tố lạ, chữ hoa) = Python ({bad[:3]})")
        check([n for n, o in zip(names, out) if o == "true"] == ["docscanner_auto_20261023_143000.zip", "docscanner_auto_20240229_235959.zip", "docscanner_auto_20000229_000000.zip"], "chỉ 3 tên hợp lệ được coi là của ta (ngày thật; 29/2 năm nhuận)")

        print("== C. xoay vòng")
        foreign = ["photo.jpg", "docscanner_backup_20261023_143000.zip", "report.zip", "docscanner_auto_20240230_100000.zip", "notes.txt", "docscanner_auto_20261023_143000.zip.tmp"]
        lines, exp_list = [], []
        for _ in range(400):
            ours = [py_name(rnd.randint(1500000000000, 1900000000000), rnd.choice(ZONES)) for _ in range(rnd.randint(0, 40))]
            if ours and rnd.random() < .3: ours.append(rnd.choice(ours))   # tên trùng
            names = ours + rnd.sample(foreign, rnd.randint(0, len(foreign)))
            rnd.shuffle(names)
            keep = rnd.choice([1, 2, 3, 5, 7, 10, 0, -4, 30, 31, 100])
            lines.append("DEL\t" + str(keep) + "\t" + "\t".join(names)); exp_list.append((names, keep))
        out = jv(lines)
        bad = foreign_hit = wrong_keep = 0
        for (names, keep), o in zip(exp_list, out):
            got = [x for x in o.split("|") if x]
            exp = py_del(names, keep)
            if sorted(got) != sorted(exp): bad += 1
            if any(g in foreign for g in got) or any(not py_ours(g) for g in got): foreign_hit += 1
            remaining = sorted({n for n in names if py_ours(n)} - set(got), reverse=True)
            ours_all = sorted({n for n in names if py_ours(n)}, reverse=True)
            if remaining != ours_all[:max(1, min(30, keep))]: wrong_keep += 1
        check(bad == 0, f"400 thư mục ngẫu nhiên: tập tên bị xoá = tham chiếu Python ({bad} lệch)")
        check(foreign_hit == 0, f"KHÔNG BAO GIỜ xoá tệp lạ (ảnh, bản sao lưu thủ công, tên giống mà sai ngày, .tmp) ({foreign_hit} lần)")
        check(wrong_keep == 0, f"phần còn lại luôn là N bản MỚI NHẤT của ta (N kẹp trong 1..30; keep 0 / -4 -> 1; 31 / 100 -> 30) ({wrong_keep} lệch)")

        print("== D. đến hạn")
        H = 3600000; D = 24 * H; now = 1_800_000_000_000
        cases = [(0, now, 7, True), (-1, now, 1, True), (now - 7 * D + 6 * H, now, 7, True), (now - 7 * D + 6 * H + 1, now, 7, False), (now - D, now, 1, True), (now - 18 * H, now, 1, True), (now - 18 * H + 1, now, 1, False),
                 (0, now, 0, False), (now - 100 * D, now, 0, False), (now - 30 * D, now, 30, True), (now - 20 * D, now, 30, False)]
        out = jv([f"DUE\t{a}\t{b}\t{c}" for a, b, c, _ in cases])
        check([o == "true" for o in out] == [e for *_, e in cases], f"đến hạn: ranh giới chu kỳ - 6 giờ, chưa từng chạy, TẮT ({out})")

        print("== E. thử âm tính")
        src = open(JAVA, encoding="utf-8").read()
        def mut(old, new, tag):
            assert src.count(old) == 1, old
            p = os.path.join(tmp, f"M{tag}.java"); open(p, "w", encoding="utf-8").write(src.replace(old, new).replace("BackupScheduleCheck", f"M{tag}")); return p
        j = mut('for (String n : names) if (isOurs(n) && !ours.contains(n)) ours.add(n);', 'for (String n : names) if (n.endsWith(".zip") && !ours.contains(n)) ours.add(n);', "A")
        foreign_names = ["photo.jpg", "report.zip", "docscanner_backup_20261023_143000.zip", "docscanner_auto_20260101_000000.zip", "docscanner_auto_20260102_000000.zip"]
        got = [x for x in jv(["DEL\t1\t" + "\t".join(foreign_names)], j)[0].split("|") if x]
        check("docscanner_backup_20261023_143000.zip" in got, f"bản hỏng 'xoá mọi .zip' bị bắt: nó xoá cả bản sao lưu THỦ CÔNG của người dùng ({got})")
        j = mut("ours.sort(Comparator.reverseOrder());", "ours.sort(Comparator.naturalOrder());", "B")
        got = jv(["DEL\t1\t" + "\t".join(["docscanner_auto_20260101_000000.zip", "docscanner_auto_20260102_000000.zip", "docscanner_auto_20260103_000000.zip"])], j)[0]
        check("20260103" in got, f"bản hỏng 'giữ bản CŨ nhất' bị bắt: nó xoá bản mới nhất ({got})")
        j = mut("Math.max(1, Math.min(30, keep))", "keep", "C")
        got = jv(["DEL\t0\t" + "\t".join(["docscanner_auto_20260101_000000.zip", "docscanner_auto_20260102_000000.zip"])], j)[0]
        check(got.count("docscanner_auto_") == 2, f"bản hỏng 'không kẹp keep' bị bắt: keep = 0 xoá TẤT CẢ ({got})")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print("TAT CA DAT" if not FAIL else f"CO LOI ({len(FAIL)})")
    return 1 if FAIL else 0

if __name__ == "__main__": sys.exit(main())
