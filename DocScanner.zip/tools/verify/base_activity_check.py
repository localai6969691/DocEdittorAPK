"""BaseActivity + FontScale (phiên 22, mục 4.49.13): cỡ chữ trong app (I4) và chữ AAA (I3).
  1. MỌI Activity khai báo trong AndroidManifest.xml kế thừa BaseActivity (không còn AppCompatActivity trực tiếp, kể cả Activity kế thừa gián tiếp qua lớp trung gian), để cỡ chữ áp dụng cho MỌI màn;
  2. BaseActivity chỉ làm đúng một việc (attachBaseContext -> FontScale.wrap) và KHÔNG ghi đè applyOverrideConfiguration (AppCompat dùng nó để áp ngôn ngữ riêng của app);
  3. FontScale: mặc định Chuẩn trả về CHÍNH context đó (không đổi hành vi của ai chưa mở cài đặt); công thức hiệu dụng = hệ thống x lựa chọn, chặn ở 2,0 (đối chiếu bản tính độc lập);
  4. mọi cỡ chữ trong layout dùng sp (dp / px sẽ KHÔNG phóng theo cỡ chữ);
  5. tương phản chữ chính / chữ phụ >= 7:1 (WCAG AAA) ở cả giao diện sáng và tối, trên cả nền và mặt phẳng (night_theme_check chạy kiểm này; ở đây đo lại độc lập từ colors.xml).
Chạy: python3 base_activity_check.py
"""
import glob, os, re, sys
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "app", "src", "main")
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)
manifest = open(os.path.join(ROOT, "AndroidManifest.xml"), encoding="utf-8").read()
names = re.findall(r'<activity[^>]*?android:name="\.?([\w\.]+)"', manifest, re.S)
src = {}
for f in glob.glob(os.path.join(ROOT, "java", "**", "*.kt"), recursive=True):
    t = open(f, encoding="utf-8").read()
    for m in re.finditer(r"(?:open |abstract )?class (\w+)[^{:\n]*:\s*(\w+)\(", t): src[m.group(1)] = m.group(2)
def root_of(cls, seen=()):
    sup = src.get(cls)
    if sup is None or cls in seen: return cls
    return root_of(sup, seen + (cls,))
bad = []
for n in names:
    cls = n.split(".")[-1]
    if cls not in src: bad.append((cls, "không tìm thấy mã")); continue
    if root_of(cls) != "AppCompatActivity" or "BaseActivity" not in [cls] + [src.get(cls)] + [src.get(src.get(cls))]:
        # kế thừa trực tiếp hoặc gián tiếp: chuỗi phải đi qua BaseActivity
        chain, c = [], cls
        while c in src: chain.append(src[c]); c = src[c]
        if "BaseActivity" not in chain: bad.append((cls, chain))
check(len(names) >= 25 and not bad, f"{len(names)} Activity trong manifest đều kế thừa BaseActivity{'' if not bad else ' - thiếu: ' + str(bad)}")
direct = [c for c, s in src.items() if s == "AppCompatActivity" and c != "BaseActivity"]
check(not direct, f"không còn lớp nào kế thừa AppCompatActivity trực tiếp ngoài BaseActivity{'' if not direct else ' ' + str(direct)}")
b = open(os.path.join(ROOT, "java", "com", "example", "docscanner", "BaseActivity.kt"), encoding="utf-8").read()
body = re.sub(r"/\*.*?\*/", "", b, flags=re.S)
check("attachBaseContext(newBase: Context)" in body and "FontScale.wrap(newBase)" in body and "applyOverrideConfiguration" not in body, "BaseActivity: chỉ attachBaseContext -> FontScale.wrap, KHÔNG ghi đè applyOverrideConfiguration (ngôn ngữ riêng của app)")
fs = open(os.path.join(ROOT, "java", "com", "example", "docscanner", "util", "FontScale.kt"), encoding="utf-8").read()
check("if (choice == 1.0f) return base" in fs and re.search(r"CHOICES = floatArrayOf\(1\.0f, 1\.15f, 1\.3f, 1\.5f\)", fs) and "MAX_SCALE = 2.0f" in fs, "FontScale: mặc định 1.0 trả về CHÍNH context (không đổi hành vi); các mức 1.0 / 1.15 / 1.3 / 1.5; trần 2.0")
choices = [float(x.rstrip("f")) for x in re.search(r"CHOICES = floatArrayOf\(([^)]*)\)", fs).group(1).split(",")]
formula = re.search(r"fun effective\(system: Float, choice: Float\): Float = (.*)", fs).group(1).strip()
eff = lambda system, c: min(2.0, system * c)                     # the formula the Kotlin source must contain
check(formula == "minOf(MAX_SCALE, system * choice)" and abs(eff(1.3, 1.5) - 1.95) < 1e-9 and eff(2.0, 1.5) == 2.0 and eff(1.0, 1.0) == 1.0 and abs(eff(0.85, 1.3) - 1.105) < 1e-9,
      f"FontScale.effective = `{formula}`: 1,3 x 1,5 = 1,95; máy đã ở 2,0 vẫn 2,0 (trần); 1,0 x 1,0 = 1,0; 0,85 x 1,3 = 1,105")
dp = []
for f in glob.glob(os.path.join(ROOT, "res", "layout*", "*.xml")):
    for m in re.finditer(r'android:textSize="([^"]+)"', open(f, encoding="utf-8").read()):
        if not m.group(1).endswith("sp") and not m.group(1).startswith("@"): dp.append((os.path.basename(f), m.group(1)))
check(not dp, f"mọi android:textSize trong layout dùng sp hoặc tham chiếu @dimen{'' if not dp else ' ' + str(dp[:3])}")
def lum(h):
    h = h.lstrip("#"); r, g, bb = [int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    f = lambda c: c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(bb)
def ratio(a, c):
    la, lc = lum(a), lum(c)
    if la < lc: la, lc = lc, la
    return (la + 0.05) / (lc + 0.05)
worst = 99
for name in ("values", "values-night"):
    pal = dict(re.findall(r'name="(\w+)">(#[0-9A-Fa-f]{6})', open(os.path.join(ROOT, "res", name, "colors.xml"), encoding="utf-8").read()))
    for t in ("text_primary", "text_secondary"):
        for bgk in ("background", "surface"): worst = min(worst, ratio(pal[t], pal[bgk]))
check(worst >= 7, f"tương phản chữ chính / chữ phụ >= 7:1 (AAA) ở sáng và tối, trên nền và mặt phẳng: thấp nhất {worst:.2f}")
check(ratio("#616161", "#F5F5F5") < 7, "ÂM TÍNH: màu chữ phụ cũ #616161 trên nền sáng chỉ 5,68 < 7 (bài kiểm bắt được màu cũ)")
print(); print("TAT CA DAT" if not fails else f"{len(fails)} LOI: {fails}")
sys.exit(1 if fails else 0)
