"""Kiểm chứng PdfImposer (phiên 15): gộp N trang lên một tờ (2-up, 4-up) và in sổ gấp (booklet).

Bản Python song song của PdfImposer.kt (grid/cells, fit, bookletSlots) và PdfPageGeometry (ma trận hiển thị + NGHỊCH ĐẢO của nó).
Ba phần:
  1. hàm thuần: lưới ô nằm trong tờ và không chồng nhau; co vừa ô giữ tỉ lệ và căn giữa;
  2. thứ tự sổ gấp: với mọi số trang 1..60, mỗi trang xuất hiện đúng một lần, hai mặt của một tờ giấy cộng lại đúng (p-1), mỗi "lá" (2j, 2j+1)
     là mặt trước-sau của cùng một mảnh giấy, các lá lồng nhau đúng (lá k và lá p/2-1-k trên cùng một tờ), trang trống chỉ ở cuối;
  3. hình học thật với poppler: dựng trang nguồn có /Rotate 0/90/180/270 và CropBox lệch, có 3 ô màu ở 3 góc của trang ĐANG HIỂN THỊ + một ô giữa
     mang màu riêng cho từng trang; nhúng thành Form XObject (BBox = CropBox, KHÔNG có Matrix) và đặt lên tờ bằng ma trận
     [cell co vừa] x [nghịch đảo ma trận hiển thị]; poppler vẽ tờ rồi đo màu: mỗi trang phải nằm đúng ô, đúng chiều (không lật/xoay).
Chạy: python3 imposition_check.py   (cần pikepdf, numpy, pillow, pdftoppm)
"""
import os, sys, zlib
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import pikepdf
from pikepdf import Name, Dictionary
from page_geometry_check import Geometry, render, color_at, near

A4W, A4H = 595.276, 841.89
MARGIN, GAP = 18.0, 12.0


def sheet_size(mode):
    return (A4H, A4W) if mode in ("TWO_UP", "BOOKLET") else (A4W, A4H)


def grid_dims(mode):
    return {"TWO_UP": (2, 1), "BOOKLET": (2, 1), "FOUR_UP": (2, 2)}[mode]


def cells(mode):
    """Ô theo thứ tự đọc (hàng trên trước, trái sang phải); (x, y, w, h), gốc dưới-trái của tờ."""
    W, H = sheet_size(mode)
    cols, rows = grid_dims(mode)
    cw = (W - 2 * MARGIN - (cols - 1) * GAP) / cols
    ch = (H - 2 * MARGIN - (rows - 1) * GAP) / rows
    out = []
    for r in range(rows):
        for c in range(cols):
            out.append((MARGIN + c * (cw + GAP), H - MARGIN - (r + 1) * ch - r * GAP, cw, ch))
    return out


def fit(dw, dh, cell):
    x, y, w, h = cell
    s = min(w / dw, h / dh)
    return s, x + (w - dw * s) / 2, y + (h - dh * s) / 2


def booklet_slots(n):
    """Trang (0-based) cho từng ô, lần lượt: tờ 1 mặt trước-trái, mặt trước-phải, mặt sau-trái, mặt sau-phải, tờ 2 ... ; None = trang trống."""
    p = ((max(n, 1) + 3) // 4) * 4
    slots = []
    for k in range(p // 4):
        order = [p - 1 - 2 * k, 2 * k, 2 * k + 1, p - 2 - 2 * k]
        slots += [i if i < n else None for i in order]
    return slots


def inverse(m):
    a, b, c, d, e, f = m
    det = a * d - b * c
    return (d / det, -b / det, -c / det, a / det, (c * f - d * e) / det, (b * e - a * f) / det)


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    return cond


def pure_tests():
    good = True
    for mode in ("TWO_UP", "FOUR_UP", "BOOKLET"):
        W, H = sheet_size(mode)
        cs = cells(mode)
        inside = all(x >= -1e-6 and y >= -1e-6 and x + w <= W + 1e-6 and y + h <= H + 1e-6 for x, y, w, h in cs)
        disjoint = all(not (a[0] < b[0] + b[2] - 1e-6 and b[0] < a[0] + a[2] - 1e-6 and a[1] < b[1] + b[3] - 1e-6 and b[1] < a[1] + a[3] - 1e-6)
                       for i, a in enumerate(cs) for b in cs[i + 1:])
        good &= check(inside and disjoint and len(cs) == (4 if mode == "FOUR_UP" else 2), f"{mode}: {len(cs)} ô, nằm trong tờ, không chồng nhau")
    c0, c1 = cells("TWO_UP")
    good &= check(c0[0] < c1[0] and abs(c0[1] - c1[1]) < 1e-9, "TWO_UP: ô đầu bên trái, ô hai bên phải, cùng độ cao")
    f = cells("FOUR_UP")
    good &= check(f[0][1] > f[2][1] and f[0][0] < f[1][0], "FOUR_UP: thứ tự đọc trái→phải, trên→dưới")
    s, ox, oy = fit(595.276, 841.89, cells("TWO_UP")[0])
    cx, cy, cw, ch = cells("TWO_UP")[0]
    good &= check(595.276 * s <= cw + 1e-6 and 841.89 * s <= ch + 1e-6 and (abs(595.276 * s - cw) < 1e-6 or abs(841.89 * s - ch) < 1e-6),
                  "fit: A4 dọc trong ô 2-up vừa khít một chiều, không tràn")
    good &= check(abs((ox - cx) - (cx + cw - (ox + 595.276 * s))) < 1e-6, "fit: căn giữa theo chiều ngang")
    s2, _, _ = fit(841.89, 595.276, cells("FOUR_UP")[0])
    good &= check(s2 < s, "fit: trang ngang vào ô dọc nhỏ hơn (co theo bề ngang)")

    # sổ gấp
    bad = []
    for n in range(1, 61):
        slots = booklet_slots(n)
        p = len(slots)
        pages = [i for i in slots if i is not None]
        if p % 4 or sorted(pages) != list(range(n)):
            bad.append(("thiếu/trùng trang", n)); continue
        full = [i if i is not None else None for i in slots]
        for k in range(p // 4):
            fl, fr, bl, br = full[4 * k:4 * k + 4]
            ids = [x if x is not None else (None) for x in (fl, fr, bl, br)]
            # trang trống nhận chỉ số ảo để kiểm cộng: tính lại theo công thức
            vfl, vfr, vbl, vbr = p - 1 - 2 * k, 2 * k, 2 * k + 1, p - 2 - 2 * k
            if vfl + vfr != p - 1 or vbl + vbr != p - 1:
                bad.append(("tổng hai mặt", n, k))
            if (vfr // 2, vbl // 2) != (k, k) or vfr % 2 != 0 or vbl != vfr + 1:
                bad.append(("lá A không là recto/verso", n, k))
            if (vbr // 2, vfl // 2) != (p // 2 - 1 - k,) * 2 or vbr % 2 != 0 or vfl != vbr + 1:
                bad.append(("lá B không là recto/verso", n, k))
        blanks = [i for i, x in enumerate(slots) if x is None]
        virt = []
        for k in range(p // 4):
            virt += [p - 1 - 2 * k, 2 * k, 2 * k + 1, p - 2 - 2 * k]
        blank_pages = sorted(virt[i] for i in blanks)
        if blank_pages != list(range(n, p)):
            bad.append(("trang trống không phải các chỉ số cuối", n))
    good &= check(not bad, f"sổ gấp n=1..60: mỗi trang đúng một lần, hai mặt cộng (p-1), lá (2j,2j+1) là hai mặt một mảnh giấy, lá lồng nhau, trang trống ở cuối {bad[:3]}")
    s8 = booklet_slots(8)
    good &= check(s8 == [7, 0, 1, 6, 5, 2, 3, 4], f"sổ gấp 8 trang: {s8} (đúng thứ tự in kinh điển 8,1 | 2,7 | 6,3 | 4,5)")
    s5 = booklet_slots(5)
    good &= check(s5 == [None, 0, 1, None, None, 2, 3, 4], f"5 trang -> 8 ô, 3 trang trống (bìa sau và 2 mặt trong): {s5}")
    return good


def make_source_pages(pdf, specs):
    """specs: [(mediabox, cropbox, rotate, center_rgb)]; trả về danh sách (page, Geometry, content_bytes)."""
    out = []
    for mb, cb, rot, center in specs:
        box = cb or mb
        g = Geometry(box[0], box[1], box[2] - box[0], box[3] - box[1], rot)
        a, b, c, d, e, f = g.matrix()
        r, gg, bb = center
        ops = (f"q {a} {b} {c} {d} {e} {f} cm 1 0 0 rg 10 10 40 20 re f 0 0 1 rg 10 {g.dh - 30} 40 20 re f "
               f"0 1 0 rg {g.dw - 50} {g.dh - 30} 40 20 re f {r} {gg} {bb} rg {g.dw / 2 - 20} {g.dh / 2 - 20} 40 40 re f Q\n").encode()
        pg = pdf.add_blank_page(page_size=(mb[2] - mb[0], mb[3] - mb[1]))
        pg.MediaBox = pikepdf.Array(mb)
        if cb:
            pg.CropBox = pikepdf.Array(cb)
        pg.Rotate = rot
        pg.Contents = pdf.make_stream(ops)
        pg.Resources = Dictionary()
        out.append((pg, g, ops, box))
    return out


def geometry_tests():
    good = True
    variants = []
    for rot in (0, 90, 180, 270):
        variants.append(((0, 0, 400, 600), None, rot))
        variants.append(((-50, -40, 350, 560), (-30, -10, 330, 540), rot))
    for mode in ("TWO_UP", "FOUR_UP"):
        W, H = sheet_size(mode)
        cs = cells(mode)
        for v0 in range(0, len(variants), 2):
            # mỗi tờ: các trang nguồn lấy lần lượt các biến thể (xoay/crop khác nhau) để thử nhiều tổ hợp trong một lần
            chosen = [variants[(v0 + i) % len(variants)] for i in range(len(cs))]
            centers = [(1, 1, 0), (1, 0, 1), (0, 1, 1), (0.5, 0.5, 0.5)][:len(cs)]
            pdf = pikepdf.new()
            src = make_source_pages(pdf, [(mb, cb, rot, ctr) for (mb, cb, rot), ctr in zip(chosen, centers)])
            sheet = pdf.add_blank_page(page_size=(W, H))
            forms, ops = {}, ""
            for i, (pg, g, content, box) in enumerate(src):
                form = pdf.make_stream(content)
                form.Type = Name.XObject; form.Subtype = Name.Form
                form.BBox = pikepdf.Array(list(box)); form.Resources = Dictionary()
                forms[f"F{i}"] = form
                s, ox, oy = fit(g.dw, g.dh, cs[i])
                a, b, c, d, e, f = inverse(g.matrix())
                ops += f"q {s * a} {s * b} {s * c} {s * d} {s * e + ox} {s * f + oy} cm /F{i} Do Q\n"
            sheet.Resources = Dictionary(XObject=Dictionary(**forms))
            sheet.Contents = pdf.make_stream(ops.encode())
            for _ in range(len(src)):
                del pdf.pages[0]
            path = os.path.join(OUT, f"imp_{mode}_{v0}.pdf"); pdf.save(path)
            img = render(path)
            h, w = img.shape[:2]
            # poppler làm tròn cỡ trang A4 (841,89 x 595,28 pt) lên số nguyên điểm ảnh: cho phép lệch 1 px
            ok_all = abs(w - W) <= 1.0 and abs(h - H) <= 1.0
            detail = []
            for i, (pg, g, content, box) in enumerate(src):
                s, ox, oy = fit(g.dw, g.dh, cs[i])
                def px(dx, dy):                      # điểm (dx,dy) của khung hiển thị (gốc dưới-trái) -> điểm ảnh
                    return ox + dx * s, h - (oy + dy * s)
                red = color_at(img, *px(30, 20)); blue = color_at(img, *px(30, g.dh - 20)); green = color_at(img, *px(g.dw - 30, g.dh - 20))
                ctr = tuple(int(255 * v) for v in centers[i]); mid = color_at(img, *px(g.dw / 2, g.dh / 2))
                ok = near(red, (255, 0, 0)) and near(blue, (0, 0, 255)) and near(green, (0, 255, 0)) and near(mid, ctr, 45)
                ok_all &= ok
                rot = chosen[i][2]; has_crop = chosen[i][1] is not None
                detail.append(f"ô{i}[rot={rot},crop={'co' if has_crop else 'khong'}]={'ok' if ok else 'LOI'}")
            good &= check(ok_all, f"{mode} biến thể {v0 // 2}: " + " ".join(detail))
    return good


if __name__ == "__main__":
    good = pure_tests()
    good = geometry_tests() and good
    print("TAT CA DAT" if good else "CO LOI")
    sys.exit(0 if good else 1)
