"""Đọc .p12 bằng BOUNCYCASTLE (phiên 22, mục 4.49.8) - cùng họ với bộ KeyStore "PKCS12" của Android (Android dùng BouncyCastle, JDK thì KHÔNG đọc được mật khẩu ngoài ASCII).
Tệp do `cryptography` / OpenSSL 3 tạo, mật khẩu: ASCII, tiếng Việt có dấu dạng gộp (NFC), dạng TÁCH RỜI (NFD), emoji, chữ Nga, chữ Hán; hai kiểu mã hoá (PBES2 / AES-256 của OpenSSL 3 và
3DES + SHA-1 kiểu cũ), khoá RSA và EC. Mỗi tệp phải đọc được VÀ khoá phải khớp chứng thư (ký rồi kiểm). THỬ ÂM TÍNH: sai mật khẩu bị từ chối; mật khẩu NFC đọc tệp NFD bị từ chối
(BouncyCastle không tự chuẩn hoá Unicode - nên ghi chú cho người dùng: gõ lại mật khẩu đúng như lúc tạo tệp).
CẢNH BÁO PHẠM VI: đây là BouncyCastle 1.77 trên JVM, KHÔNG phải bản BouncyCastle đóng gói trong Android (cũ hơn tuỳ phiên bản Android); nó chứng minh logic mật khẩu -> BMPString,
không chứng minh từng phiên bản Android. Bỏ qua (không lỗi) nếu máy không có bcprov.
Chạy: python3 pkcs12_bc_check.py   (cần java, bcprov*.jar, cryptography; ~30 giây)
"""
import datetime, glob, os, subprocess, sys, tempfile, unicodedata
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, ec
from cryptography.hazmat.primitives.serialization import pkcs12
from cryptography.x509.oid import NameOID

HERE = os.path.dirname(os.path.abspath(__file__))
jars = sorted(glob.glob("/usr/share/java/bcprov*.jar")) + sorted(glob.glob(os.path.expanduser("~/.m2/**/bcprov*.jar"), recursive=True))
if not jars: print("BO QUA: không có bcprov*.jar trên máy này"); sys.exit(0)
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

now = datetime.datetime.now(datetime.timezone.utc)
def selfcert(key):
    n = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Thử BC")])
    return (x509.CertificateBuilder().subject_name(n).issuer_name(n).public_key(key.public_key()).serial_number(12345).not_valid_before(now - datetime.timedelta(days=1))
            .not_valid_after(now + datetime.timedelta(days=30)).sign(key, hashes.SHA256()))
work = tempfile.mkdtemp(prefix="bc_", dir=OUT)
def legacy(pw): return (serialization.PrivateFormat.PKCS12.encryption_builder().kdf_rounds(2048).key_cert_algorithm(pkcs12.PBES.PBESv1SHA1And3KeyTripleDESCBC)
                        .hmac_hash(hashes.SHA1()).build(pw.encode("utf-8")))
def modern(pw): return serialization.BestAvailableEncryption(pw.encode("utf-8"))
def bc_read(path, pw, variants=False):
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", "-cp", jars[0], os.path.join(HERE, "Pkcs12BcCheck.java"), path, pw.encode("utf-8").hex()] + (["variants"] if variants else []), capture_output=True, text=True)
    return r.stdout.strip() or r.stderr.strip()[-200:]

rsak = rsa.generate_private_key(65537, 2048); eck = ec.generate_private_key(ec.SECP256R1())
passwords = {"ascii": "matkhau123", "vn_nfc": "Mật khẩu Đặng-Ấn 123", "vn_nfd": unicodedata.normalize("NFD", "Mật khẩu Đặng-Ấn 123"), "emoji": "pw🔐ok", "ru": "пароль123", "zh": "密码测试123"}
for pname, pw in passwords.items():
    for kname, key in (("RSA", rsak), ("EC", eck)):
        for ename, enc in (("modern", modern), ("legacy", legacy)):
            p = os.path.join(work, f"{pname}_{kname}_{ename}.p12")
            open(p, "wb").write(pkcs12.serialize_key_and_certificates(b"s", key, selfcert(key), None, enc(pw)))
            out = bc_read(p, pw)
            check(out.startswith("OK ") and out.split()[1] in (kname, "ECDSA"), f"BouncyCastle đọc {pname}/{kname}/{ename}: {out}")
p = os.path.join(work, "vn_nfc_RSA_modern.p12")
check(bc_read(p, "sai-mat-khau").startswith("FAIL"), "ÂM TÍNH: sai mật khẩu bị BouncyCastle từ chối")
pn = os.path.join(work, "vn_nfd_RSA_modern.p12")
check(bc_read(pn, passwords["vn_nfc"]).startswith("FAIL"), "ÂM TÍNH: mật khẩu NFC KHÔNG mở được tệp tạo bằng mật khẩu NFD (BC không chuẩn hoá Unicode)")
# Pkcs12Import.passwordVariants: thử dạng gõ, NFC, NFD -> mở được cả hai chiều
nfc, nfd = passwords["vn_nfc"], passwords["vn_nfd"]
check(nfc != nfd and bc_read(p, nfd, variants=True).startswith("OK"), "passwordVariants: mật khẩu gõ dạng NFD mở được tệp tạo bằng NFC")
check(bc_read(pn, nfc, variants=True).startswith("OK"), "passwordVariants: mật khẩu gõ dạng NFC mở được tệp tạo bằng NFD (tệp xuất từ máy Mac)")
check(bc_read(pn, "mat-khau-sai", variants=True).startswith("FAIL") and bc_read(pn, "", variants=True).startswith("FAIL"), "passwordVariants: mật khẩu sai / rỗng vẫn bị từ chối (không mở nhầm)")
check(bc_read(os.path.join(work, "ascii_RSA_modern.p12"), "matkhau123", variants=True).startswith("OK"), "passwordVariants: mật khẩu ASCII không đổi hành vi")

print(); print("TAT CA DAT" if not fails else f"{len(fails)} LOI: {fails}")
sys.exit(1 if fails else 0)
