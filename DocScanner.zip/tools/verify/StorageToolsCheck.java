import java.io.*;
import java.nio.file.*;
import java.security.*;
import java.util.*;

/** Ban Java chay duoc cua util/StorageTools.kt (phien 18): bao cao dung luong, tim tai lieu trung, ghi de truoc khi xoa. Chay: java StorageToolsCheck.java <lenh> ... */
public class StorageToolsCheck {
    static String category(String name) {
        int dot = name.lastIndexOf('.'); String ext = dot < 0 ? "" : name.substring(dot + 1).toLowerCase();
        switch (ext) {
            case "pdf": return "pdf"; case "epub": return "epub";
            case "txt": case "md": case "html": case "htm": return "text";
            case "docx": case "xlsx": case "pptx": return "office";
            case "jpg": case "jpeg": case "png": case "webp": return "image";
            default: return "other";
        }
    }
    static List<File> walk(File dir) {
        ArrayList<File> out = new ArrayList<>();
        File[] kids = dir.listFiles(); if (kids == null) return out;
        for (File f : kids) { if (f.isDirectory()) out.addAll(walk(f)); else if (f.isFile() && !f.getName().endsWith(".part")) out.add(f); }
        return out;
    }
    /** Tep .txt nam canh mot .pdf cung ten la lop chu OCR cua PDF do (di cung PDF vao thung rac): khong liet ke / khong coi la tai lieu rieng. */
    static boolean isOcrSidecar(File f) {
        String n = f.getName(); if (!n.toLowerCase().endsWith(".txt")) return false;
        return new File(f.getParentFile(), n.substring(0, n.length() - 4) + ".pdf").isFile();
    }
    static List<File> visible(List<File> all) { ArrayList<File> out = new ArrayList<>(); for (File f : all) if (!isOcrSidecar(f)) out.add(f); return out; }
    static String sha(File f, long limit) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(f)) {
            byte[] buf = new byte[65536]; long left = limit;
            while (left != 0) {
                int n = in.read(buf, 0, (int) (left < 0 ? buf.length : Math.min(buf.length, left)));
                if (n < 0) break; md.update(buf, 0, n); if (left > 0) left -= n;
            }
        }
        StringBuilder sb = new StringBuilder(); for (byte b : md.digest()) sb.append(String.format("%02x", b)); return sb.toString();
    }
    /** Nhom cac tep co NOI DUNG giong het nhau: cung dung luong -> cung SHA-256 cua [prefix] byte dau -> cung SHA-256 toan bo. [fullHash]=false chi de thu am tinh. */
    static List<List<File>> findDuplicates(List<File> files, int prefix, boolean fullHash) throws Exception {
        Map<Long, List<File>> bySize = new TreeMap<>();
        for (File f : files) { long len = f.length(); if (len > 0) bySize.computeIfAbsent(len, k -> new ArrayList<>()).add(f); }
        ArrayList<List<File>> out = new ArrayList<>();
        for (List<File> g1 : bySize.values()) {
            if (g1.size() < 2) continue;
            Map<String, List<File>> byHead = new LinkedHashMap<>();
            for (File f : g1) byHead.computeIfAbsent(sha(f, prefix), k -> new ArrayList<>()).add(f);
            for (List<File> g2 : byHead.values()) {
                if (g2.size() < 2) continue;
                if (!fullHash) { out.add(g2); continue; }
                Map<String, List<File>> byAll = new LinkedHashMap<>();
                for (File f : g2) byAll.computeIfAbsent(sha(f, -1), k -> new ArrayList<>()).add(f);
                for (List<File> g3 : byAll.values()) if (g3.size() >= 2) out.add(g3);
            }
        }
        for (List<File> g : out) g.sort(Comparator.comparingLong(File::lastModified).thenComparing(File::getName));
        out.sort(Comparator.comparingLong((List<File> g) -> -g.get(0).length()).thenComparing(g -> g.get(0).getName()));
        return out;
    }
    /** Ghi de noi dung tai cho bang byte ngau nhien, giu nguyen do dai, roi dong bo xuong dia. */
    static boolean overwrite(File f) {
        try (RandomAccessFile raf = new RandomAccessFile(f, "rw")) {
            long len = raf.length(); SecureRandom r = new SecureRandom(); byte[] buf = new byte[65536];
            raf.seek(0);
            for (long done = 0; done < len; ) { int n = (int) Math.min(buf.length, len - done); r.nextBytes(buf); raf.write(buf, 0, n); done += n; }
            raf.getFD().sync(); return true;
        } catch (IOException e) { return false; }
    }
    static boolean wipe(File f) { if (!f.exists()) return false; if (f.isFile()) overwrite(f); return f.delete(); }

    static int wipeTree(File dir) {
        if (!dir.exists()) return 0;
        if (dir.isFile()) return wipe(dir) ? 1 : 0;
        int n = 0; File[] kids = dir.listFiles();
        if (kids != null) for (File k : kids) n += wipeTree(k);
        dir.delete(); return n;
    }
    public static void main(String[] a) throws Exception {
        switch (a[0]) {
            case "dup": {   // dir [head]   -> moi nhom mot dong: duong dan cach nhau bang TAB
                List<List<File>> gs = findDuplicates(visible(walk(new File(a[1]))), 65536, a.length < 3 || !a[2].equals("head"));
                for (List<File> g : gs) { StringBuilder sb = new StringBuilder(); for (File f : g) { if (sb.length() > 0) sb.append('\t'); sb.append(f.getPath()); } System.out.println(sb); }
                break;
            }
            case "report": {   // dir top
                List<File> fs = visible(walk(new File(a[1]))); long total = 0; TreeMap<String, long[]> cat = new TreeMap<>();
                for (File f : fs) { total += f.length(); long[] c = cat.computeIfAbsent(category(f.getName()), k -> new long[2]); c[0]++; c[1] += f.length(); }
                System.out.println("total\t" + fs.size() + "\t" + total);
                for (Map.Entry<String, long[]> e : cat.entrySet()) System.out.println("cat\t" + e.getKey() + "\t" + e.getValue()[0] + "\t" + e.getValue()[1]);
                fs.sort(Comparator.comparingLong((File f) -> -f.length()).thenComparing(File::getName));
                for (int i = 0; i < Math.min(Integer.parseInt(a[2]), fs.size()); i++) System.out.println("top\t" + fs.get(i).getName() + "\t" + fs.get(i).length());
                break;
            }
            case "dupbatch": {   // dupbatch <tep danh sach thu muc> <head|full>: voi moi thu muc in cac nhom roi dong "==="
                boolean full = a.length < 3 || !a[2].equals("head");
                for (String root : Files.readAllLines(Paths.get(a[1]))) {
                    for (List<File> g : findDuplicates(visible(walk(new File(root))), 65536, full)) { StringBuilder sb = new StringBuilder(); for (File f : g) { if (sb.length() > 0) sb.append('\t'); sb.append(f.getPath()); } System.out.println(sb); }
                    System.out.println("===");
                }
                break;
            }
            case "overwrite": System.out.println(overwrite(new File(a[1]))); break;
            case "wipe": System.out.println(wipe(new File(a[1]))); break;
            case "wipetree": System.out.println(wipeTree(new File(a[1]))); break;
            default: System.exit(2);
        }
    }
}
