#!/usr/bin/env python3
"""Phông dễ đọc Lexend (PDF I6; phiên 24, TECHNICAL_DOCS.md 4.63): kiểm tài nguyên, KHÔNG kiểm giao diện thật.

  1. `res/font/lexend.xml` trỏ đúng hai tệp phông có thật (400 / 700, cả hai khai báo android: và app: cho Android 7);
  2. hai tệp .ttf là bản GỐC của Lexend (băm SHA-256 cố định, commit 7894f02b của googlefonts/lexend): giấy phép OFL cấm đổi bản gốc mà vẫn dùng Reserved Font Name;
  3. phông phủ ĐỦ mọi chữ có dấu tiếng Việt (cần `pip install fonttools`; thiếu thì báo và thoát 2, trừ khi có --soft);
  4. `ThemeOverlay.DocScanner.ReadableFont` đặt android:fontFamily + fontFamily và ĐỦ 15 vai trò chữ của Material 3 (Display / Headline / Title / Body / Label x Large / Medium / Small),
     mỗi vai trò trỏ tới `TextAppearance.DocScanner.Readable.<Vai trò>` có cha `TextAppearance.Material3.<Vai trò>` và đặt font Lexend (Material 3 đọc phông từ chính các kiểu này, không từ theme);
  5. `BaseActivity` chỉ áp overlay khi `ReadableFont.isOn` và trước `super.onCreate`; mặc định TẮT (`getBoolean(..., false)`);
  6. giấy phép OFL 1.1 + dòng bản quyền Lexend nằm trong assets/THIRD_PARTY_NOTICES.txt (điều kiện của OFL khi phân phối);
  7. công tắc có trong hộp thoại cỡ chữ và chuỗi `readable_font_option` có ở mọi ngôn ngữ.
KHÔNG kiểm được: phông có thật sự hiện trên máy (Android 7 / 8+), từng thành phần Material có theo overlay hay không, độ rộng chữ Lexend làm tràn nút (cần máy thật) - xem 4.63.
Chạy: python3 tools/verify/readable_font_check.py [--soft]"""
import hashlib, os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
RES = os.path.join(ROOT, "app/src/main/res"); JAVA = os.path.join(ROOT, "app/src/main/java/com/example/docscanner")
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)
rd = lambda p: open(p, encoding="utf-8").read()
SHA = {"lexend_regular.ttf": "e2082c28389e9871d5d77ae9163d5c0c1c259fe39bdac91f73d56a600b61f60f", "lexend_bold.ttf": "4509838acc21f2c066e9874c9c5eb52b9b8cdac1771a9c1fe9e7e2cda41ce082"}

fam = rd(os.path.join(RES, "font/lexend.xml"))
for w, f in (("400", "lexend_regular"), ("700", "lexend_bold")):
    check(f'android:font="@font/{f}"' in fam and f'app:font="@font/{f}"' in fam and f'android:fontWeight="{w}"' in fam and f'app:fontWeight="{w}"' in fam,
          f"lexend.xml: {f} ở độ đậm {w}, khai báo cả android: và app: (Android 7 dùng app:)")
    check(os.path.isfile(os.path.join(RES, f"font/{f}.ttf")), f"tệp res/font/{f}.ttf tồn tại")
for name, want in SHA.items():
    got = hashlib.sha256(open(os.path.join(RES, "font", name), "rb").read()).hexdigest()
    check(got == want, f"{name} là bản gốc của Lexend (SHA-256 {got[:12]}… = {want[:12]}…)")

try:
    from fontTools.ttLib import TTFont
    VIET = "ẠạẢảẤấẦầẨẩẪẫẬậẮắẰằẲẳẴẵẶặẸẹẺẻẼẽẾếỀềỂểỄễỆệỈỉỊịỌọỎỏỐốỒồỔổỖỗỘộỚớỜờỞởỠỡỢợỤụỦủỨứỪừỬửỮữỰựỲỳỴỵỶỷỸỹĂăÂâÊêÔôƠơƯưĐđ"
    for name in SHA:
        cmap = TTFont(os.path.join(RES, "font", name)).getBestCmap()
        miss = [c for c in VIET if ord(c) not in cmap]
        check(not miss, f"{name} phủ đủ {len(VIET)} chữ có dấu tiếng Việt (thiếu: {''.join(miss) or 'không'})")
except ImportError:
    print("fonttools chưa cài (pip install fonttools): bỏ qua kiểm phủ chữ Việt")
    if "--soft" not in sys.argv: fails.append("fonttools missing")

th = rd(os.path.join(RES, "values/themes.xml"))
ov = re.search(r'<style name="ThemeOverlay\.DocScanner\.ReadableFont"[^>]*>(.*?)</style>', th, re.S)
check(bool(ov), "themes.xml có ThemeOverlay.DocScanner.ReadableFont")
body = ov.group(1) if ov else ""
check('name="android:fontFamily">@font/lexend<' in body and 'name="fontFamily">@font/lexend<' in body, "overlay đặt android:fontFamily và fontFamily = @font/lexend")
roles = [f"{r}{z}" for r in ("Display", "Headline", "Title", "Body", "Label") for z in ("Large", "Medium", "Small")]
for r in roles:
    ok_attr = f'<item name="textAppearance{r}">@style/TextAppearance.DocScanner.Readable.{r}</item>' in body
    st = re.search(rf'<style name="TextAppearance\.DocScanner\.Readable\.{r}" parent="TextAppearance\.Material3\.{r}">(.*?)</style>', th, re.S)
    ok_style = bool(st) and "@font/lexend" in st.group(1) and 'name="android:fontFamily"' in st.group(1) and 'name="fontFamily"' in st.group(1)
    check(ok_attr and ok_style, f"vai trò {r}: overlay -> kiểu có cha TextAppearance.Material3.{r} và font Lexend")
extra = set(re.findall(r'<item name="textAppearance(\w+)">', body)) - set(roles)
check(not extra, f"overlay không đặt vai trò lạ {sorted(extra)}")

ba = rd(os.path.join(JAVA, "BaseActivity.kt"))
m = re.search(r"override fun onCreate\(savedInstanceState: Bundle\?\) \{(.*?)\n    \}", ba, re.S)
blk = m.group(1) if m else ""
check("ReadableFont.isOn(this)" in blk and "theme.applyStyle(R.style.ThemeOverlay_DocScanner_ReadableFont, true)" in blk and blk.index("applyStyle") < blk.index("super.onCreate"),
      "BaseActivity.onCreate: chỉ áp overlay khi isOn, TRƯỚC super.onCreate, bằng applyStyle (không setTheme: setTheme làm mất theme riêng của màn hình)")
check("setTheme(" not in ba, "BaseActivity không dùng setTheme")
rf = rd(os.path.join(JAVA, "util/ReadableFont.kt"))
check(re.search(r'getBoolean\(KEY_ON, false\)', rf) is not None, "mặc định TẮT: đổi gì cũng không xảy ra với người không mở cài đặt này")
notices = rd(os.path.join(ROOT, "app/src/main/assets/THIRD_PARTY_NOTICES.txt"))
check("SIL OPEN FONT LICENSE" in notices.upper() and "The Lexend Project Authors" in notices and "PERMISSION & CONDITIONS" in notices.upper(),
      "THIRD_PARTY_NOTICES.txt có dòng bản quyền Lexend và nguyên văn OFL 1.1 (điều kiện khi phân phối)")
mn = rd(os.path.join(JAVA, "MainActivity.kt"))
check("ReadableFont.setOn(this, checked)" in mn and "R.string.readable_font_option" in mn, "hộp thoại cỡ chữ có hộp kiểm bật / tắt phông")
for d in sorted(os.listdir(RES)):
    f = os.path.join(RES, d, "strings.xml")
    if d.startswith("values") and os.path.isfile(f):
        check('name="readable_font_option"' in rd(f), f"{d}: có chuỗi readable_font_option")
print("\nTAT CA DAT" if not fails else f"\n{len(fails)} LOI"); sys.exit(1 if fails else 0)
