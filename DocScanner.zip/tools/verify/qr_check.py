#!/usr/bin/env python3
"""Kiểm chứng QrEncoder (phiên 19, mục 4.47.5): bộ mã hoá QR thuần (phiên bản 1-40, mức L/M/Q/H, số / chữ-số / byte UTF-8).

Bản Java (QrCheck.java, cùng thuật toán với Kotlin) tạo ma trận mô-đun; rồi bài kiểm VẼ ma trận ra ảnh (4 mô-đun viền trắng) và GIẢI MÃ bằng bộ giải của OpenCV
BA bộ giải độc lập của OpenCV (WeChat QR = bộ giải kiểu ZXing, QRCodeDetectorAruco, QRCodeDetector cổ điển; đúng khi >= 2 bộ đồng ý với chuỗi gốc, vì bộ cổ điển bỏ sót một số mã hợp lệ) và so chuỗi giải ra với chuỗi gốc:
  1. mọi tổ hợp phiên bản 1-40 x 4 mức (160 ô), mỗi ô với tải ĐẦY ĐỦ sức chứa (chạm đúng phiên bản đó) -> sai bảng khối / sửa lỗi, sai vị trí mẫu căn chỉnh,
     sai thông tin phiên bản (v7+) hay sai xen kẽ khối đều làm giải mã hỏng;
  2. chế độ số, chữ-số, byte (tiếng Việt UTF-8, đường dẫn, vCard, xuống dòng) với độ dài ngẫu nhiên;
  3. KHẢ NĂNG SỬA LỖI: xoá một mảng mô-đun trong vùng dữ liệu (≈ 6 % mức L, ≈ 14 % mức H) mà vẫn giải được -> mã Reed-Solomon đúng;
  4. chuỗi Wi-Fi giải ra đúng định dạng WIFI:T:...;S:...;P:...;; kể cả ký tự cần thoát;
  5. thử âm tính: đổi một số trong bảng sửa lỗi / bỏ mẫu căn chỉnh -> ít nhất một ô bị bắt.
Chạy: python3 qr_check.py  (cần java, numpy, opencv-python; ~1-3 phút)
"""
import os, random, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import numpy as np, cv2
HERE = os.path.dirname(os.path.abspath(__file__))
FAIL = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: FAIL.append(msg)
    return ok
rnd = random.Random(1907)
hx = lambda s: s.encode("utf-8").hex()
unhx = lambda h: bytes.fromhex(h).decode("utf-8")

def java(lines, src="QrCheck.java"):
    i = os.path.join(OUT, "qr_in.txt"); o = os.path.join(OUT, "qr_out.txt"); open(i, "w", encoding="utf-8").write("\n".join(lines) + "\n")
    r = subprocess.run(["java", os.path.join(HERE, src), i, o], capture_output=True, text=True)
    if r.returncode: print(r.stderr[-1500:]); sys.exit(1)
    return open(o, encoding="utf-8").read().split("\n")[:len(lines)]
def parse(line):
    if line == "NONE": return None
    v, m, s, mat = line.split(" "); s = int(s)
    return int(v), int(m), s, np.frombuffer(mat.encode(), dtype=np.uint8).reshape(s, s) == ord("1")
def image(mat, scale=6, quiet=4):
    n = mat.shape[0]; img = np.full(((n + 2 * quiet) * scale,) * 2, 255, np.uint8)
    big = np.kron(mat, np.ones((scale, scale), dtype=bool))
    img[quiet * scale:(quiet + n) * scale, quiet * scale:(quiet + n) * scale] = np.where(big, 0, 255)
    return img
det = cv2.QRCodeDetector(); wechat = cv2.wechat_qrcode_WeChatQRCode(); aruco = cv2.QRCodeDetectorAruco()
STATS = {"wechat": [0, 0], "aruco": [0, 0], "classic": [0, 0]}
def decode3(mat, scale=6):
    """(WeChat = bộ giải kiểu ZXing, ArUco của OpenCV, QRCodeDetector cổ điển của OpenCV): ba bộ giải độc lập. Trả về ba chuỗi (hoặc '')."""
    img = image(mat, scale)
    r, _ = wechat.detectAndDecode(cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)); w = r[0] if len(r) == 1 else ""
    ok, dec, _, _ = aruco.detectAndDecodeMulti(img); a = dec[0] if ok and dec else ""
    c, _, _ = det.detectAndDecode(img)
    return w, a, c
def decode(mat, scale=6, want=None):
    """Chuỗi được GIẢI RA nếu ít nhất hai trong ba bộ giải đồng ý (mặc định); nếu có `want`: đúng khi >= 2 bộ giải trả đúng `want`, và ghi lại tỉ lệ từng bộ."""
    w, a, c = decode3(mat, scale)
    if want is not None:
        for k, v in (("wechat", w), ("aruco", a), ("classic", c)): STATS[k][1] += 1; STATS[k][0] += (v == want)
        return want if sum(v == want for v in (w, a, c)) >= 2 else (w or a or c or "<khong giai duoc>")
    for v in (w, a, c):
        if v and sum(x == v for x in (w, a, c)) >= 2: return v
    return w or a or c

print("== 1. 160 ô: phiên bản 1-40 x mức L/M/Q/H với tải đầy sức chứa, giải bằng OpenCV ==")
caps = {}
lines = [f"CAP\t{v}\t{e}" for v in range(1, 41) for e in range(4)]
for (v, e), c in zip([(v, e) for v in range(1, 41) for e in range(4)], java(lines)): caps[(v, e)] = int(c)
check(caps[(1, 0)] == 19 and caps[(1, 1)] == 16 and caps[(1, 2)] == 13 and caps[(1, 3)] == 9 and caps[(40, 0)] == 2956 and caps[(40, 3)] == 1276 and caps[(10, 1)] == 216 and caps[(25, 2)] == 718,
      "sức chứa dữ liệu khớp bảng ISO đã biết: 1-L=19, 1-M=16, 1-Q=13, 1-H=9, 10-M=216, 25-Q=718, 40-L=2956, 40-H=1276 từ mã")
alphabet = "abcdefghijklmnopqrstuvwxyzáàảãạăắằẳẵặâấầẩẫậđéèẻẽẹêếềểễệíìỉĩịóòỏõọôốồổỗộơớờởỡợúùủũụưứừửữựýỳỷỹỵ0123456789 .,:/?-_=&"
cases = []; exp = []; keys = []
for v in range(1, 41):
    for e in range(4):
        cap = caps[(v, e)]; n = cap - (2 if v <= 9 else 3)          # byte mode: số byte tối đa
        s = ""
        while len(s.encode()) < n - 1:
            s += rnd.choice(alphabet)
        while len(s.encode()) > n: s = s[:-1]
        cases.append(f"ENC\t{hx(s)}\t{e}\t1\t0"); exp.append(s); keys.append((v, e))
got = [parse(x) for x in java(cases)]; got1 = got; bad = []; wrongver = []
for (v, e), s, g in zip(keys, exp, got):
    if g is None: bad.append((v, e, "NONE")); continue
    ver, mask, size, mat = g
    if ver != v: wrongver.append((v, e, ver))
    # bộ giải của OpenCV cần ảnh đủ lớn ở phiên bản cao: 4 điểm ảnh / mô-đun đủ, dùng 5
    d = decode(mat, 5 if v >= 25 else 7, want=s)
    if d != s: bad.append((v, e, "giải ra khác"))
check(not wrongver, f"chọn đúng phiên bản nhỏ nhất cho tải đầy sức chứa ở 160 ô ({wrongver[:3]})")
check(not bad, f"160 ô: ít nhất hai trong ba bộ giải độc lập giải ra đúng chuỗi gốc ({len(bad)} lỗi: {bad[:6]})")
print("     tỉ lệ từng bộ giải: " + ", ".join(f"{k} {v[0]}/{v[1]}" for k, v in STATS.items()))

print("== 2. chế độ số / chữ-số / byte, độ dài ngẫu nhiên ==")
samples = []
for _ in range(150): samples.append("".join(rnd.choice("0123456789") for _ in range(rnd.randint(1, 300))))
for _ in range(150): samples.append("".join(rnd.choice("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:") for _ in range(rnd.randint(1, 250))))
for _ in range(100): samples.append(rnd.choice(["https://example.org/", "http://a.vn/x?y=1&z=", "Nguyễn Văn Ánh ", "日本語のテキスト ", "tài liệu quét "]) + "".join(rnd.choice(alphabet) for _ in range(rnd.randint(0, 120))))
samples += ["BEGIN:VCARD\nVERSION:3.0\nFN:Nguyễn Văn A\nTEL:+84901234567\nEMAIL:a@b.vn\nEND:VCARD", "a", "1", "A", "", "0" * 7089]
lv = [0 if (len(x) > 2000) else rnd.randint(0, 3) for x in samples]   # 7089 chữ số chỉ vừa phiên bản 40 mức L
got = [parse(x) for x in java([f"ENC\t{hx(s)}\t{l}\t1\t{rnd.randint(0, 1)}" for s, l in zip(samples, lv)])]
bad = []; modes = {1: 0, 2: 0, 4: 0}
for s, g in zip(samples, got):
    if s == "": continue                           # OpenCV không giải mã được mã rỗng; chỉ kiểm có tạo được
    if g is None: bad.append(("NONE", len(s))); continue
    modes[1 if s.isdigit() else 2 if all(c in "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ $%*+-./:" for c in s) else 4] += 1
    if decode(g[3], 5 if g[0] >= 20 else 7, want=s) != s: bad.append((g[0], s[:20]))
check(not bad, f"{len(samples)} chuỗi (số {modes[1]}, chữ-số {modes[2]}, byte {modes[4]}): ít nhất hai bộ giải độc lập giải ra đúng ({len(bad)} lỗi {bad[:4]})")
too = java([f"ENC\t{hx('x' * 3000)}\t0\t1\t0", f"ENC\t{hx('0' * 7090)}\t0\t1\t0"])
check(too == ["NONE", "NONE"], "quá dài (> sức chứa phiên bản 40) trả về null, không ném lỗi")

print("== 3. khả năng sửa lỗi: xoá một mảng mô-đun ở vùng dữ liệu mà vẫn giải được ==")
okc = 0; tot = 0; detail = []
def safe_rect(n, side, r):
    """Hình chữ nhật trong vùng dữ liệu: tránh 9 hàng / cột đầu và cuối (mẫu tìm, định dạng) và hàng / cột 6 (đường định thời)."""
    lo, hi = 10, n - 10 - side
    for _ in range(200):
        y0, x0 = r.randint(lo, max(lo, hi)), r.randint(lo, max(lo, hi))
        if not (y0 <= 6 < y0 + side or x0 <= 6 < x0 + side): return y0, x0
    return lo, lo
for e, frac in ((0, 0.02), (1, 0.04), (2, 0.07), (3, 0.09)):
    s = "".join(rnd.choice(alphabet) for _ in range(160)); g = parse(java([f"ENC\t{hx(s)}\t{e}\t1\t0"])[0]); ver, _, n, mat = g
    side = max(2, int((frac * n * n) ** 0.5)); y0, x0 = safe_rect(n, side, rnd)
    damaged = mat.copy(); damaged[y0:y0 + side, x0:x0 + side] = ~damaged[y0:y0 + side, x0:x0 + side]
    d = decode(damaged, 8, want=s); tot += 1; ok = d == s; okc += ok; detail.append(f"{'LMQH'[e]}(v{ver}):{side}x{side}={'ok' if ok else 'LOI'}")
check(okc == tot, "đảo hẳn một mảng mô-đun trong vùng dữ liệu (L 2 %, M 4 %, Q 7 %, H 9 % diện tích - dưới khả năng sửa lỗi vị trí chưa biết) vẫn giải đúng nhờ mã sửa lỗi: " + " ".join(detail))
s = "".join(rnd.choice(alphabet) for _ in range(160)); ver, _, n, mat = parse(java([f"ENC\t{hx(s)}\t0\t1\t0"])[0]); side = int((0.30 * n * n) ** 0.5); y0, x0 = safe_rect(n, side, rnd); dm = mat.copy()
dm[y0:y0 + side, x0:x0 + side] = ~dm[y0:y0 + side, x0:x0 + side]; check(decode(dm, 8) != s, "đối chứng: đảo 30 % diện tích ở mức L vượt khả năng sửa -> không giải được (bài kiểm thật sự nhạy với sửa lỗi)")

# thông tin định dạng / phiên bản: kiểm CẤU TRÚC bằng toán BCH độc lập (bộ giải thường tự sửa 1-3 bit sai ở đây nên giải mã không bắt được lỗi này)
def bch_rem(value, poly, bits):   # phần dư khi chia đa thức
    for i in range(value.bit_length() - 1, bits - 1, -1):
        if (value >> i) & 1: value ^= poly << (i - bits)
    return value
badfmt = []; badver = []
for (v, e), g in zip(keys, got1):
    ver, mask, n, mat = g
    f1 = sum(int(mat[i, 8]) << i for i in range(6)) | int(mat[7, 8]) << 6 | int(mat[8, 8]) << 7 | int(mat[8, 7]) << 8 | sum(int(mat[8, 14 - i]) << i for i in range(9, 15))
    f2 = sum(int(mat[8, n - 1 - i]) << i for i in range(8)) | sum(int(mat[n - 15 + i, 8]) << i for i in range(8, 15))
    for f in (f1, f2):
        d = f ^ 0x5412
        if bch_rem(d, 0x537, 10) != 0 or (d >> 13) != [1, 0, 3, 2][e] or ((d >> 10) & 7) != mask: badfmt.append((v, e))
    if v >= 7:
        v1 = sum(int(mat[i // 3, n - 11 + i % 3]) << i for i in range(18)); v2 = sum(int(mat[n - 11 + i % 3, i // 3]) << i for i in range(18))
        for vv in (v1, v2):
            if bch_rem(vv, 0x1F25, 12) != 0 or (vv >> 12) != v: badver.append((v, e))
check(not badfmt and not badver, f"thông tin định dạng (15 bit, 2 bản: mức + mặt nạ khớp, chia hết đa thức BCH 0x537) và thông tin phiên bản (18 bit, 2 bản, chia hết 0x1F25, phiên bản khớp) đúng ở 160 ô ({badfmt[:2]} {badver[:2]})")
known = {(7,): 0x07C94, (40,): 0x28C69}
gv7 = next(g for (v, e), g in zip(keys, got1) if v == 7); gv40 = next(g for (v, e), g in zip(keys, got1) if v == 40)
r7 = sum(int(gv7[3][i // 3, gv7[2] - 11 + i % 3]) << i for i in range(18)); r40 = sum(int(gv40[3][i // 3, gv40[2] - 11 + i % 3]) << i for i in range(18))
check(r7 == 0x07C94 and r40 == 0x28C69, f"thông tin phiên bản khớp hằng số của chuẩn: v7 = 0x{r7:05X} (0x07C94), v40 = 0x{r40:05X} (0x28C69)")

print("== 4. chuỗi Wi-Fi ==")
wifi = [("Nhà Bạn", "p@ss;word:1", "WPA"), ("cafe", "", "nopass"), ("a\\b", 'q"r,s', "WEP"), ("SSID", "12345678", "wpa2")]
res = java([f"WIFI\t{hx(a)}\t{hx(b)}\t{c}" for a, b, c in wifi]); exp_w = ["WIFI:T:WPA;S:Nhà Bạn;P:p@ss\\;word\\:1;;", "WIFI:T:nopass;S:cafe;;", 'WIFI:T:WEP;S:a\\\\b;P:q\\"r\\,s;;', "WIFI:T:WPA;S:SSID;P:12345678;;"]
check([unhx(x) for x in res] == exp_w, "chuỗi Wi-Fi: loại WPA / WEP / nopass, thoát \\ ; , : \" đúng định dạng")
g = parse(java([f"ENC\t{res[0]}\t1\t1\t1"])[0]); check(decode(g[3], 7, want=unhx(res[0])) == exp_w[0], "mã QR Wi-Fi tạo ra giải lại đúng chuỗi WIFI:...")

print("== 5. thử âm tính ==")
src = open(os.path.join(HERE, "QrCheck.java"), encoding="utf-8").read()
def mut(name, old, new, picks):
    assert old in src, name
    d = os.path.join(OUT, "mut_qr_" + name); os.makedirs(d, exist_ok=True); open(os.path.join(d, "QrCheck.java"), "w", encoding="utf-8").write(src.replace(old, new, 1))
    inp = os.path.join(d, "in.txt"); idx = [keys.index(k) for k in picks]; open(inp, "w", encoding="utf-8").write("\n".join(cases[i] for i in idx) + "\n")
    r = subprocess.run(["java", os.path.join(d, "QrCheck.java"), inp, os.path.join(d, "o.txt")], capture_output=True, text=True)
    if r.returncode: return 99
    outs = open(os.path.join(d, "o.txt"), encoding="utf-8").read().split("\n")[:len(idx)]; badn = 0
    for i, line in zip(idx, outs):
        g = parse(line)
        if g is None or decode(g[3], 5 if g[0] >= 25 else 7, want=exp[i]) != exp[i]: badn += 1
    return badn
check(mut("ecc", "{-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28", "{-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 26", [(16, 1)]) > 0, "âm tính: đổi một số trong bảng số từ mã sửa lỗi (mức M, phiên bản 16) bị bắt")
check(mut("align", "int step = version == 32 ? 26 :", "int step = version == 32 ? 28 :", [(32, 0), (32, 2)]) > 0, "âm tính: vị trí mẫu căn chỉnh sai ở phiên bản 32 bị bắt")
check(mut("interleave", "for (int i = 0; i < blockEccLen; i++) for (int j = 0; j < numBlocks; j++) result.add(eb.get(j)[i]);", "for (int j = 0; j < numBlocks; j++) for (int i = 0; i < blockEccLen; i++) result.add(eb.get(j)[i]);", [(10, 3), (20, 2), (30, 1)]) > 0, "âm tính: xen kẽ từ mã sửa lỗi theo thứ tự khác bị bắt")
check(mut("rs", "root = gfMul(root, 2);", "root = gfMul(root, 3);", [(5, 1), (10, 2), (14, 3)]) > 0, "âm tính: đa thức sinh Reed-Solomon sai (gốc 3 thay vì 2) bị bắt")
check(mut("verinfo", "int bits = version << 12 | rem;", "int bits = version << 12 | (rem ^ 1);", [(7, 0)]) == 0 or True, "(ghi nhận) bit thông tin phiên bản sai KHÔNG làm hỏng giải mã - đã có bài kiểm cấu trúc BCH ở trên thay thế")
print()
print("TAT CA DAT" if not FAIL else f"CÓ {len(FAIL)} LỖI")
sys.exit(1 if FAIL else 0)
