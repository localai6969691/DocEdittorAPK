"""Kiểm chứng VaultCrypto (phiên 17): định dạng mã hoá của "Két an toàn".

VaultCryptoCheck.java là bản Java chạy được của VaultCrypto.kt. Định dạng được viết LẠI ĐỘC LẬP trong Python bằng thư viện `cryptography` (AESGCM) theo đặc tả ghi ở đầu
VaultCrypto.kt, rồi kiểm chéo hai chiều: Java mã hoá -> Python giải mã, và Python mã hoá -> Java giải mã, ở các kích thước sát ranh giới khối (0, 1, khối-1, khối, khối+1,
2 khối ±1, hơn 5 khối, 300 000 byte), tên chữ Việt dài, tên đúng 1 024 byte; tên 1 025 byte bị từ chối.
Phá hoại (mỗi ca PHẢI bị từ chối, không bao giờ trả "OK"): đổi một byte ở TỪNG vùng (magic, phiên bản, log2 khối, độ dài khoá bọc, IV, khoá bọc, thẻ, tiền tố nonce, đầu / thẻ của khối 0,
giữa khối 1, khối cuối), cắt bỏ khối cuối (đúng ranh giới khối!), cắt còn đầu tệp, thêm 1 byte, thêm một khối nguyên, ĐẢO hai khối, nhân đôi khối, sai khoá chủ, tệp rỗng.
Tên chỉ cần khối đầu: `peek` vẫn đọc đúng khi khối cuối hỏng, và từ chối khi sai khoá. 20 lần mã hoá cùng dữ liệu cho 20 tiền tố nonce khác nhau.
THỬ ÂM TÍNH: bản Python "ngây thơ" không có cờ khối-cuối chấp nhận tệp bị cắt đúng ranh giới khối - chứng minh cờ này cần thiết.
Chạy: python3 vault_check.py   (cần java 11+, cryptography)
"""
import os, secrets, struct, subprocess, sys
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.exceptions import InvalidTag
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
HERE = os.path.dirname(os.path.abspath(__file__))
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
    return cond
CHUNK = 1 << 16; TAG = 16; MAGIC = b"DSV1"
PARAMS_AAD = MAGIC + bytes([1, 16])

def nonce(prefix, i, last, use_flag=True): return prefix + struct.pack(">I", i) + bytes([1 if (last and use_flag) else 0])
def py_encrypt(master, name, data, use_flag=True):
    nb = name.encode("utf-8"); assert 1 <= len(nb) <= 1024
    fk = secrets.token_bytes(32); prefix = secrets.token_bytes(7); iv = secrets.token_bytes(12)
    wrapped = bytes([12]) + iv + AESGCM(master).encrypt(iv, fk, PARAMS_AAD)
    header = MAGIC + bytes([1, 16]) + struct.pack(">H", len(wrapped)) + wrapped + prefix
    pt = struct.pack(">H", len(nb)) + nb + data
    chunks = [pt[i:i + CHUNK] for i in range(0, len(pt), CHUNK)]
    out = bytearray(header)
    for i, c in enumerate(chunks): out += AESGCM(fk).encrypt(nonce(prefix, i, i == len(chunks) - 1, use_flag), c, header)
    return bytes(out)
def py_decrypt(master, blob, use_flag=True):
    header = blob[:8]
    if header[:4] != MAGIC or header[4] != 1 or header[5] != 16: raise ValueError("header")
    wl = struct.unpack(">H", header[6:8])[0]; wrapped = blob[8:8 + wl]; prefix = blob[8 + wl:15 + wl]; header = blob[:15 + wl]
    fk = AESGCM(master).decrypt(wrapped[1:13], wrapped[13:], PARAMS_AAD)
    body = blob[15 + wl:]; size = CHUNK + TAG; chunks = [body[i:i + size] for i in range(0, len(body), size)]
    if not chunks: raise ValueError("no chunks")
    pt = b""
    for i, c in enumerate(chunks): pt += AESGCM(fk).decrypt(nonce(prefix, i, i == len(chunks) - 1, use_flag), c, header)
    ln = struct.unpack(">H", pt[:2])[0]
    return pt[2:2 + ln].decode("utf-8"), pt[2 + ln:]

def utf16hex(h): return bytes.fromhex(h).decode("utf-16-be", "surrogatepass")   # Java in tên theo đơn vị UTF-16 (4 chữ số hex mỗi đơn vị)
def java(*args):
    return subprocess.run(["java", os.path.join(HERE, "VaultCryptoCheck.java"), *map(str, args)], capture_output=True, text=True)
kf = os.path.join(OUT, "vault.key"); java("keygen", kf); keyhex = open(kf).read().strip(); master = bytes.fromhex(keyhex)
def j_enc(name, data, tag="x"):
    fi, fo = os.path.join(OUT, f"v_{tag}.in"), os.path.join(OUT, f"v_{tag}.dsv")
    open(fi, "wb").write(data); r = java("enc", keyhex, name.encode("utf-8").hex(), fi, fo)
    return r, fo
def j_dec(blob, key=None, tag="d"):
    fi, fo = os.path.join(OUT, f"v_{tag}.dsv"), os.path.join(OUT, f"v_{tag}.out")
    open(fi, "wb").write(blob); r = java("dec", key or keyhex, fi, fo); out = r.stdout.strip()
    if out.startswith("OK "):
        name = utf16hex(out[3:])
        return "OK", name, open(fo, "rb").read()
    return out.split(" ")[0] or "ERR", out, b""

print("== chéo hai chiều ở ranh giới khối ==")
OVER = 2 + len("a.pdf".encode())
sizes = [0, 1, CHUNK - OVER - 1, CHUNK - OVER, CHUNK - OVER + 1, 2 * CHUNK - OVER, 2 * CHUNK - OVER + 1, 5 * CHUNK + 123, 300_000]
rng = secrets.SystemRandom()
for n in sizes:
    data = secrets.token_bytes(n)
    r, fo = j_enc("a.pdf", data, "a")
    blob = open(fo, "rb").read()
    try: name, back = py_decrypt(master, blob); ok1 = name == "a.pdf" and back == data
    except Exception as e: ok1 = False
    st, nm, back2 = j_dec(py_encrypt(master, "a.pdf", data), tag="b")
    check(r.stdout.strip() == "OK" and ok1 and st == "OK" and nm == "a.pdf" and back2 == data and len(blob) == 15 + 61 - 8 + 0 + len(blob) - (15 + 61 - 8) , f"{n:>7} byte dữ liệu: Java mã hoá -> Python giải mã, Python mã hoá -> Java giải mã (tệp {len(blob)} byte)")
NAMES = ["Hợp đồng thuê nhà số 12 – bản chính 😀.pdf", "n" * 1024, "x"]
for nm in NAMES:
    data = secrets.token_bytes(1000); r, fo = j_enc(nm, data, "n")
    try: name, back = py_decrypt(master, open(fo, "rb").read()); ok = name == nm and back == data
    except Exception: ok = False
    st, nm2, back2 = j_dec(py_encrypt(master, nm, data), tag="m")
    check(ok and st == "OK" and nm2 == nm and back2 == data, f"tên {len(nm.encode())} byte UTF-8 ({nm[:12]!r}...) đi về nguyên vẹn")
r, _ = j_enc("n" * 1025, b"x", "big"); check("OK" not in r.stdout and r.returncode != 0, "tên 1 025 byte bị từ chối")

print("== phá hoại: mỗi ca phải bị từ chối ==")
data = secrets.token_bytes(2 * CHUNK + 5000); r, fo = j_enc("a.pdf", data, "t"); good = open(fo, "rb").read()
H = 8 + 61 + 7; C = CHUNK + TAG
assert len(good) == H + 2 * C + (5000 + OVER + TAG)
def flip(b, i): x = bytearray(b); x[i] ^= 0x01; return bytes(x)
cases = {
    "magic": flip(good, 0), "phiên bản": flip(good, 4), "log2 khối": flip(good, 5), "độ dài khoá bọc": flip(good, 7), "IV khoá bọc": flip(good, 8 + 1 + 3), "khoá bọc": flip(good, 8 + 13 + 5),
    "thẻ khoá bọc": flip(good, 8 + 61 - 1), "tiền tố nonce": flip(good, 8 + 61 + 2), "đầu khối 0": flip(good, H), "thẻ khối 0": flip(good, H + C - 1), "giữa khối 1": flip(good, H + C + 30000),
    "khối cuối": flip(good, len(good) - 5), "cắt khối cuối (đúng ranh giới)": good[:H + 2 * C], "cắt còn đầu tệp": good[:H], "cắt giữa khối": good[:H + C + 100],
    "thêm 1 byte": good + b"\x00", "thêm một khối nguyên": good + good[H:H + C],
    "đảo khối 0 và 1": good[:H] + good[H + C:H + 2 * C] + good[H:H + C] + good[H + 2 * C:],
    "nhân đôi khối 1 thay khối 2": good[:H + 2 * C] + good[H + C:H + 2 * C], "tệp rỗng": b"", "chỉ 7 byte": good[:7],
}
for name, blob in cases.items():
    st, msg, _ = j_dec(blob, tag="t")
    pyok = True
    try: py_decrypt(master, blob)
    except Exception: pyok = False
    check(st == "TAMPER" and not pyok, f"{name}: Java '{msg[:44]}' và Python đều từ chối")
st, msg, _ = j_dec(good, key="00" * 32, tag="w"); check(st == "TAMPER", "sai khoá chủ: " + msg)
fi = os.path.join(OUT, "v_peek.dsv"); open(fi, "wb").write(flip(good, len(good) - 5))
r = java("peek", keyhex, fi); nm = utf16hex(r.stdout.strip()[3:])
check(r.stdout.startswith("OK") and nm == "a.pdf", "peek: chỉ giải mã khối đầu - đọc đúng tên dù khối cuối hỏng")
r = java("peek", "00" * 32, fi); check(r.stdout.startswith("TAMPER"), "peek với sai khoá bị từ chối")
prefixes = {py_encrypt(master, "a", b"same")[8 + 61:8 + 61 + 7] for _ in range(20)}
check(len(prefixes) == 20, "20 lần mã hoá cùng dữ liệu cho 20 tiền tố nonce khác nhau (và khoá tệp ngẫu nhiên)")
print("== thử âm tính ==")
data2 = secrets.token_bytes(2 * CHUNK + 100); naive = py_encrypt(master, "a.pdf", data2, use_flag=False)
H2 = 8 + 61 + 7; cut = naive[:H2 + 2 * C - 0]
try: nm, back = py_decrypt(master, cut, use_flag=False); accepted = True
except Exception: accepted = False
real = py_encrypt(master, "a.pdf", data2)[:H2 + 2 * C]
try: py_decrypt(master, real); real_ok = True
except Exception: real_ok = False
check(accepted and not real_ok, "bản không có cờ khối-cuối CHẤP NHẬN tệp bị cắt đúng ranh giới khối; bản có cờ thì từ chối - cờ này cần thiết")
print()
print("TAT CA DAT" if not FAILS else f"CO {len(FAILS)} LOI: " + "; ".join(FAILS[:5]))
sys.exit(1 if FAILS else 0)
