#!/usr/bin/env python3
"""Lịch sử phiên bản của tệp CHẠY THẬT (`util/FileVersions.kt`; phiên 25, TECHNICAL_DOCS.md 4.78 và 4.80; mục 6.1 của PDF): chụp bản cũ TRƯỚC khi ghi đè, giữ N bản gần nhất (mặc định 6),
ghim bản muốn giữ mãi, khôi phục, đổi tên tệp thì lịch sử đi theo, dọn thư mục mồ côi; (4.80) lưu theo MẢNH chia theo nội dung (FastCDC) để phiên bản thứ hai không tốn gấp đôi, hạ giới hạn có hiệu lực NGAY,
thay tệp bằng tệp khác mà vẫn giữ bản cũ.

Cách chia mảnh được kiểm với một bản FastCDC viết LẠI ĐỘC LẬP bằng Python (cùng bảng Gear splitmix64, cùng mặt nạ trải 64 bit): độ dài từng mảnh phải GIỐNG HỆT trên dữ liệu ngẫu nhiên, dữ liệu lặp, tệp rỗng,
tệp nhỏ hơn mảnh nhỏ nhất, tệp đúng bằng mảnh lớn nhất. Cách lưu được đọc lại BẰNG PYTHON: tên tệp mảnh đúng là SHA-256 của nội dung nó, bản kê (manifest) ghép lại đúng từng byte.

Mọi kiểm tra làm trên TỆP THẬT trong một thư mục tạm và đọc kết quả bằng chính hệ thống tệp (hashlib, os) chứ không bằng mã đang kiểm: thư mục đúng là sha1 của tên tệp, tệp phiên bản đúng
tên `v<id>_<ms>_<0|1>.ver` và NỘI DUNG giống từng byte bản cũ, bản sống đã được thay bằng nội dung mới.
Những cái nó phải KHÔNG làm: không để lại tệp dở khi lỗi, không đụng tệp sống khi không giữ được bản cũ, không xoá bản được ghim, không tính bản ghim vào giới hạn, không để khôi phục tự làm mất
đúng bản đang khôi phục (khi giới hạn làm rớt bản cũ nhất).
KHÔNG kiểm được: thư mục `filesDir` thật của Android, hộp thoại. Chạy: python3 tools/verify/file_versions_real_run_check.py"""
import hashlib, os, sys, tempfile, time
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="fver-")
HARNESS = os.path.join(HERE, "real_run", "FileVersionsHarness.kt")
cls = tc.compile(["FileVersions.kt"], [HARNESS], os.path.join(WORK, "cls"), None, None)[0]
def run(*a, klass=None):
    r = tc.run(klass or cls, "FileVersionsHarnessKt", list(map(str, a)))
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-1200:])
    return r.stdout.strip().split("\n") if r.stdout.strip() else []

def new_root(): return tempfile.mkdtemp(prefix="root-", dir=WORK)
def write(path, data):
    os.makedirs(os.path.dirname(path), exist_ok=True); open(path, "wb").write(data if isinstance(data, bytes) else data.encode()); return path
def vdir(root, name): return os.path.join(root, "file_versions", hashlib.sha1(name.encode()).hexdigest())
def vfiles(root, name):
    d = vdir(root, name); return sorted(os.listdir(d)) if os.path.isdir(d) else []
def versions(root, name):
    out = []
    for line in run("list", root, name):
        i, t, s, p, c = line.split("|"); out.append((int(i), int(t), int(s), p == "true"))
    return out
def content(root, name, vid):
    d = vdir(root, name)
    for f in os.listdir(d):
        if f.startswith(f"v{vid}_"): return open(os.path.join(d, f), "rb").read()
    return None
def md5(b): return hashlib.md5(b).hexdigest()

NAME = "báo cáo tháng 11.pdf"   # a name with spaces and Vietnamese letters: the folder name is a hash, so nothing in it can break a path

# ---- an INDEPENDENT FastCDC, written again from the written description (class comment of FileVersions), to compare the cuts with
M64 = (1 << 64) - 1
MIN, AVG, MAX = 16 * 1024, 64 * 1024, 256 * 1024
def gear_table():
    z, out = 0, []
    for _ in range(256):
        z = (z + 0x9E3779B97F4A7C15) & M64; x = z
        x = ((x ^ (x >> 30)) * 0xBF58476D1CE4E5B9) & M64
        x = ((x ^ (x >> 27)) * 0x94D049BB133111EB) & M64
        out.append(x ^ (x >> 31))
    return out
GEAR = gear_table()
def spread(bits):
    m = 0
    for j in range(bits): m |= 1 << (63 - (j * 64 // bits))
    return m
MASK_S, MASK_L = spread(17), spread(15)
def py_cuts(data):
    out, off, n = [], 0, len(data)
    while off < n:
        remaining = n - off
        if remaining <= MIN: out.append(remaining); break
        limit = min(remaining, MAX); normal = min(AVG, limit); fp = 0; i = MIN; cut = limit
        found = False
        while i < normal:
            fp = ((fp << 1) + GEAR[data[off + i]]) & M64
            if fp & MASK_S == 0: cut = i + 1; found = True; break
            i += 1
        if not found:
            while i < limit:
                fp = ((fp << 1) + GEAR[data[off + i]]) & M64
                if fp & MASK_L == 0: cut = i + 1; break
                i += 1
        out.append(cut); off += cut
    return out
def kotlin_cuts(path):
    out = run("cuts", path); return [int(x) for x in out[0].split()] if out and out[0] else []
import random
def rbytes(seed, n): return random.Random(seed).randbytes(n)

def pool_files(root):
    p = os.path.join(root, "file_versions", "chunks"); res = []
    if os.path.isdir(p):
        for shard in os.listdir(p):
            for f in os.listdir(os.path.join(p, shard)): res.append(os.path.join(p, shard, f))
    return res
def physical(root):
    tot = sum(os.path.getsize(f) for f in pool_files(root))
    base = os.path.join(root, "file_versions")
    if os.path.isdir(base):
        for d in os.listdir(base):
            dp = os.path.join(base, d)
            if d != "chunks" and os.path.isdir(dp):
                tot += sum(os.path.getsize(os.path.join(dp, f)) for f in os.listdir(dp) if f.endswith((".vm", ".ver")))
    return tot
def manifest_of(root, name, vid):
    d = vdir(root, name)
    for f in os.listdir(d):
        if f.startswith(f"v{vid}_") and f.endswith(".vm"): return open(os.path.join(d, f), encoding="utf-8").read().splitlines()
    return None
def assemble(root, name, vid):
    """rebuilds a version from the files on disk with Python only: manifest + pieces"""
    lines = manifest_of(root, name, vid); head = lines[0].split(); out = b""
    for line in lines[1:]:
        h, ln = line.split(); data = open(os.path.join(root, "file_versions", "chunks", h[:2], h), "rb").read()
        assert hashlib.sha256(data).hexdigest() == h and len(data) == int(ln), "piece does not match its name"
        out += data
    assert head[0] == "DVM1" and int(head[1]) == len(out) and int(head[2]) == len(lines) - 1
    return out

print("== A. cách chia mảnh: giống bản FastCDC độc lập")
cases = {"ngẫu nhiên 4 MiB": rbytes(1, 4 * 1024 * 1024), "ngẫu nhiên 700 KiB": rbytes(2, 700 * 1024), "lặp lại (toàn byte 7) 1 MiB": b"\x07" * (1024 * 1024),
         "văn bản lặp 600 KiB": (b"lorem ipsum dolor sit amet " * 30000)[:600 * 1024], "nhỏ hơn mảnh nhỏ nhất (5 KiB)": rbytes(3, 5 * 1024), "đúng bằng mảnh lớn nhất (256 KiB)": rbytes(4, MAX),
         "mảnh nhỏ nhất + 1 byte": rbytes(5, MIN + 1), "rỗng": b""}
for label, data in cases.items():
    p = write(os.path.join(WORK, "cut.bin"), data); got = kotlin_cuts(p); want = py_cuts(data)
    check(got == want and sum(got) == len(data), f"{label}: {len(got)} mảnh, độ dài giống bản Python" + ("" if got == want else f" (nhận {got[:5]} mong đợi {want[:5]})"))
sizes = py_cuts(cases["ngẫu nhiên 4 MiB"])
check(all(MIN <= x <= MAX for x in sizes[:-1]) and 40 * 1024 <= sum(sizes) / len(sizes) <= 110 * 1024, f"mọi mảnh trong [16, 256] KiB, cỡ trung bình {sum(sizes) // len(sizes) // 1024} KiB (quanh 64 KiB)")
big = cases["ngẫu nhiên 4 MiB"]; shifted = big[:2 * 1024 * 1024] + rbytes(99, 1000) + big[2 * 1024 * 1024:]
write(os.path.join(WORK, "a.bin"), big); write(os.path.join(WORK, "b.bin"), shifted)
ca, cb = kotlin_cuts(os.path.join(WORK, "a.bin")), kotlin_cuts(os.path.join(WORK, "b.bin"))
def hashes(data, cuts):
    out, off = set(), 0
    for ln in cuts: out.add(hashlib.sha256(data[off:off + ln]).digest()); off += ln
    return out
shared = len(hashes(big, ca) & hashes(shifted, cb)); total = len(hashes(shifted, cb))
check(shared >= total - 4, f"chèn 1000 byte vào GIỮA tệp 4 MiB: {shared}/{total} mảnh của bản sau vẫn là mảnh cũ (ranh giới theo nội dung, không trượt theo)")

print("== B. chụp bản cũ, đọc lại bằng Python")
root = new_root(); live = write(os.path.join(root, "library", NAME), rbytes(10, 900 * 1024))
vid = run("snap", root, NAME, live, 1700000000000, 6)[0]
check(vid == "1", f"bản chụp đầu có số 1 ({vid})")
check(os.path.isdir(vdir(root, NAME)) and open(os.path.join(vdir(root, NAME), "name.txt"), encoding="utf-8").read() == NAME, "thư mục là sha1 của tên tệp, có name.txt ghi tên thật")
check(vfiles(root, NAME) == ["name.txt", "v1_1700000000000_0.vm"], f"đúng tên bản kê v1_<ms>_0.vm, không còn tệp dở ({vfiles(root, NAME)})")
check(assemble(root, NAME, 1) == rbytes(10, 900 * 1024), "ghép lại các mảnh theo bản kê = tệp gốc từng byte; tên mỗi mảnh = SHA-256 nội dung của nó")
check(run("snap", root, NAME, os.path.join(root, "khong-co.pdf"), 1, 6)[0] == "NULL" and len(versions(root, NAME)) == 1, "nguồn không tồn tại -> NULL, không tạo gì thêm")
check(versions(root, NAME)[0][2] == 900 * 1024, "kích thước ghi trong danh sách là kích thước NỘI DUNG của phiên bản")
empty = write(os.path.join(root, "library", "empty.pdf"), b""); check(run("snap", root, "empty.pdf", empty, 1, 6)[0] == "1" and assemble(root, "empty.pdf", 1) == b"", "tệp rỗng cũng chụp được (0 mảnh)")

print("== C. tiết kiệm dung lượng: bản thứ hai chỉ thêm phần KHÁC")
root = new_root(); data = rbytes(20, 3 * 1024 * 1024); live = write(os.path.join(root, "library", NAME), data)
run("snap", root, NAME, live, 1, 6); one = physical(root)
edited = data[:1500000] + rbytes(21, 900) + data[1500900:]          # 900 bytes changed in the middle (same length)
write(live, edited); run("snap", root, NAME, live, 2, 6); two = physical(root)
check(two - one < 0.08 * len(data), f"bản thứ hai (3 MiB, đổi 900 byte ở giữa) chỉ thêm {(two - one) // 1024} KiB, không phải 3072 KiB ({100 * (two - one) / len(data):.1f}% kích thước tệp)")
check(assemble(root, NAME, 1) == data and assemble(root, NAME, 2) == edited, "cả hai bản vẫn ghép lại đúng từng byte")
run("snap", root, NAME, live, 3, 6)
newest = [f for f in os.listdir(vdir(root, NAME)) if f.startswith("v3_")][0]
check(physical(root) - two == os.path.getsize(os.path.join(vdir(root, NAME), newest)), f"chụp lại nội dung Y HỆT thêm đúng {physical(root) - two} byte = riêng bản kê mới (không thêm mảnh nào)")
inserted = edited[:700000] + rbytes(22, 5000) + edited[700000:]     # 5000 bytes INSERTED near the start: everything after shifts
write(live, inserted); before = physical(root); run("snap", root, NAME, live, 4, 6)
check(physical(root) - before < 0.10 * len(inserted), f"chèn 5000 byte gần đầu (mọi thứ sau đó trượt): chỉ thêm {(physical(root) - before) // 1024} KiB")
check(int(run("total", root)[0]) == physical(root), "totalSize = dung lượng thật trên đĩa (bản kê + mảnh, mảnh dùng chung tính một lần)")

print("== D. ghi đè an toàn (commit)")
root = new_root(); live = write(os.path.join(root, "library", NAME), b"OLD" * 100000); new = write(os.path.join(root, "tmp", "new.pdf"), b"NEW" * 100000)
r = run("commit", root, NAME, new, live, 1700000001000, 6)[0]
check(r == "true" and open(live, "rb").read() == b"NEW" * 100000 and not os.path.exists(new), "tệp sống có nội dung MỚI; tệp tạm đã được chuyển vào (không còn)")
check(len(versions(root, NAME)) == 1 and assemble(root, NAME, 1) == b"OLD" * 100000, "bản cũ nằm trong lịch sử đúng từng byte")
root2 = new_root(); live2 = write(os.path.join(root2, "library", NAME), rbytes(30, 400 * 1024)); new2 = write(os.path.join(root2, "tmp", "n.pdf"), b"X" * 10)
write(os.path.join(root2, "file_versions"), b"i am a FILE where the versions folder should be")      # the folder cannot be created
r = run("commit", root2, NAME, new2, live2, 1, 6)[0]
check(r == "false" and open(live2, "rb").read() == rbytes(30, 400 * 1024) and os.path.exists(new2), "không giữ được bản cũ -> KHÔNG ghi đè: tệp sống còn nguyên, tệp mới vẫn còn để làm cách khác")
root3 = new_root(); live3 = write(os.path.join(root3, "library", "x.pdf"), rbytes(31, 300 * 1024)); new3 = write(os.path.join(root3, "tmp", "n.pdf"), b"Y")
os.makedirs(os.path.join(root3, "file_versions")); write(os.path.join(root3, "file_versions", "chunks"), b"a FILE where the pieces folder should be")   # pieces cannot be written
check(run("snap", root3, "x.pdf", live3, 1, 6)[0] == "NULL", "không ghi được mảnh -> snapshot NULL")
leftovers = [f for dp, dn, fn in os.walk(os.path.join(root3, "file_versions")) for f in fn if f.endswith(".part")]
check(not leftovers and not vfiles(root3, "x.pdf") or vfiles(root3, "x.pdf") == ["name.txt"], f"không để lại tệp .part hay bản kê dở ({leftovers}, {vfiles(root3, 'x.pdf')})")
root4 = new_root(); fresh = os.path.join(root4, "library", "moi.pdf"); new4 = write(os.path.join(root4, "tmp", "n.pdf"), b"FIRST")
check(run("commit", root4, "moi.pdf", new4, fresh, 1, 6)[0] == "true" and open(fresh, "rb").read() == b"FIRST" and versions(root4, "moi.pdf") == [], "tệp chưa tồn tại thì chỉ đặt vào, không có phiên bản nào")

print("== E. giữ N bản gần nhất; ghim; dọn mảnh")
root = new_root(); live = os.path.join(root, "library", NAME); contents = {}
for i in range(1, 11):
    contents[i] = rbytes(100 + i, 40 * 1024); write(live, contents[i]); run("snap", root, NAME, live, 1700000000000 + i, 6)
vs = versions(root, NAME)
check([v[0] for v in vs] == [10, 9, 8, 7, 6, 5], f"10 lần chụp, giới hạn 6: còn 6 bản MỚI NHẤT (số 10..5), cũ nhất bị bỏ ({[v[0] for v in vs]})")
check(assemble(root, NAME, 5) == contents[5] and assemble(root, NAME, 10) == contents[10], "nội dung từng bản đúng")
check(len(pool_files(root)) == len({h for i in range(5, 11) for h in [hashlib.sha256(contents[i][k:k + 0]).hexdigest() for k in [0]]}) or len(pool_files(root)) >= 6, "(mỗi bản 40 KiB ngẫu nhiên có ít nhất 1 mảnh riêng)")
used = set(l.split()[0] for i in range(5, 11) for l in manifest_of(root, NAME, i)[1:])
check({os.path.basename(f) for f in pool_files(root)} == used, "mảnh của các bản đã bị bỏ (1..4) ĐÃ bị dọn khỏi kho; kho chỉ còn đúng mảnh mà 6 bản còn lại nhắc tới")
check(run("pin", root, NAME, 5, 1)[0] == "true" and ("v5_1700000000005_1.vm" in vfiles(root, NAME)), "ghim bản 5: tên bản kê đổi cuối thành _1")
for i in range(11, 15):
    contents[i] = rbytes(100 + i, 40 * 1024); write(live, contents[i]); run("snap", root, NAME, live, 1700000000000 + i, 6)
vs = versions(root, NAME)
check(sorted(v[0] for v in vs) == [5, 9, 10, 11, 12, 13, 14] and [v for v in vs if v[0] == 5][0][3], f"bản ghim (5) KHÔNG bị xoá dù quá giới hạn, và không tính vào 6 bản chưa ghim: {[v[0] for v in vs]}")
check(assemble(root, NAME, 5) == contents[5], "mảnh của bản ghim còn nguyên (không bị dọn nhầm)")
check(run("pin", root, NAME, 5, 0)[0] == "true", "bỏ ghim")
contents[15] = rbytes(115, 40 * 1024); write(live, contents[15]); run("snap", root, NAME, live, 1700000000015, 6)
check(5 not in [v[0] for v in versions(root, NAME)], "bỏ ghim rồi thì lần chụp sau dọn bản 5 (đã cũ nhất)")
check(run("del", root, NAME, versions(root, NAME)[0][0])[0] == "true", "xoá một bản")
check(run("del", root, NAME, 999)[0] == "false" and run("pin", root, NAME, 999, 1)[0] == "false", "số không tồn tại -> false")
for v in [v[0] for v in versions(root, NAME)]: run("del", root, NAME, v)
check(pool_files(root) == [], "xoá hết các bản: kho mảnh SẠCH (không còn mảnh mồ côi)")

print("== F. hạ giới hạn có hiệu lực NGAY")
root = new_root(); live = os.path.join(root, "library", NAME); A, B = "a.pdf", "b.pdf"; la, lb = os.path.join(root, "library", A), os.path.join(root, "library", B)
for i in range(1, 7):
    write(la, rbytes(200 + i, 30 * 1024)); run("snap", root, A, la, i, 6)
for i in range(1, 5):
    write(lb, rbytes(300 + i, 30 * 1024)); run("snap", root, B, lb, i, 6)
run("pin", root, A, 1, 1)
check(run("excess", root, 6)[0] == "0" and run("excess", root, 3)[0] == str((5 - 3) + (4 - 3)), f"hạ xuống 3: báo trước sẽ xoá {run('excess', root, 3)[0]} bản (a.pdf có 5 chưa ghim -> 2, b.pdf có 4 -> 1; bản ghim không tính)")
before = len(pool_files(root)); removed = run("pruneall", root, 3)[0]
check(removed == "3" and len(versions(root, A)) == 4 and len(versions(root, B)) == 3, f"pruneall(3): xoá {removed} bản NGAY, a.pdf còn 4 (3 + 1 ghim), b.pdf còn 3")
check(1 in [v[0] for v in versions(root, A)] and len(pool_files(root)) < before, "bản ghim còn; mảnh của các bản đã xoá được dọn")
check(assemble(root, A, 1) == rbytes(201, 30 * 1024), "bản ghim vẫn ghép đúng")
check(run("pruneall", root, 3)[0] == "0", "chạy lại không xoá thêm")

print("== G. khôi phục; kiểm mảnh hỏng / mất")
root = new_root(); live = os.path.join(root, "library", NAME); states = {}
for i in range(1, 4):
    states[i] = rbytes(400 + i, 80 * 1024); write(live, states[i]); run("snap", root, NAME, live, 1700000000000 + i, 6)
write(live, b"state 4 (current)")
r = run("restore", root, NAME, 2, live, 1700000009000, 6)[0]
check(r == "true" and open(live, "rb").read() == states[2], "khôi phục bản 2: tệp sống có nội dung bản 2 từng byte")
check(assemble(root, NAME, 4) == b"state 4 (current)" and [v[0] for v in versions(root, NAME)] == [4, 3, 2, 1], "nội dung đang dùng trước khi khôi phục được GIỮ làm bản 4: khôi phục không làm mất gì")
check(not [f for f in os.listdir(os.path.dirname(live)) if f.endswith(".part")], "không để lại tệp .part cạnh tệp sống")
# the OLDEST version at the limit
root = new_root(); live = os.path.join(root, "library", NAME)
for i in range(1, 3): write(live, rbytes(500 + i, 50 * 1024)); run("snap", root, NAME, live, 1700000000000 + i, 2)
write(live, b"current")
r = run("restore", root, NAME, 1, live, 1700000009000, 2)[0]
check(r == "true" and open(live, "rb").read() == rbytes(501, 50 * 1024), "giới hạn 2, khôi phục bản CŨ NHẤT (bị bản chụp mới đẩy ra khỏi giới hạn): vẫn khôi phục đúng nội dung bản đó")
check(run("restore", root, NAME, 777, live, 1, 6)[0] == "false" and open(live, "rb").read() == rbytes(501, 50 * 1024), "khôi phục số không tồn tại -> false, tệp sống không đổi")
# damage
root = new_root(); live = os.path.join(root, "library", NAME); write(live, rbytes(600, 300 * 1024)); run("snap", root, NAME, live, 1, 6); write(live, b"now")
piece = sorted(pool_files(root))[0]; raw = bytearray(open(piece, "rb").read()); raw[len(raw) // 2] ^= 0xFF; open(piece, "wb").write(bytes(raw))
check(run("restore", root, NAME, 1, live, 2, 6)[0] == "false" and open(live, "rb").read() == b"now" and not [f for f in os.listdir(os.path.dirname(live)) if f.endswith(".part")], "một mảnh bị sửa 1 byte: khôi phục báo LỖI, tệp sống không đổi, không để lại tệp dở")
write(live, rbytes(600, 300 * 1024)); run("snap", root, NAME, live, 3, 6)   # same content again: the damaged piece is found by its NAME (hash) as existing, so a new version points at it too
os.remove(sorted(pool_files(root))[-1]); write(live, b"now2")
check(run("restore", root, NAME, 2, live, 4, 6)[0] == "false" and open(live, "rb").read() == b"now2", "một mảnh BỊ MẤT: khôi phục báo lỗi, tệp sống không đổi")

# an unreadable manifest: the sweep of unused pieces must stop and delete NOTHING (a piece wrongly taken for unused would be data lost for good)
root = new_root(); live = os.path.join(root, "library", NAME)
for i in range(1, 4): write(live, rbytes(80 + i, 60000)); run("snap", root, NAME, live, i, 6)
v1_pieces = {l.split()[0] for l in manifest_of(root, NAME, 1)[1:]}
d = vdir(root, NAME); m1 = [f for f in os.listdir(d) if f.startswith("v1_")][0]; os.remove(os.path.join(d, m1)); os.mkdir(os.path.join(d, m1))   # a directory where a manifest should be: it cannot be read
run("pruneall", root, 1)
check(v1_pieces <= {os.path.basename(f) for f in pool_files(root)}, "một bản kê KHÔNG đọc được: lần dọn mảnh DỪNG và không xoá mảnh nào (mảnh của bản đó còn nguyên)")

print("== H. phiên bản chép đầy đủ của bản dựng đầu (.ver) vẫn đọc được")
root = new_root(); live = os.path.join(root, "library", NAME); write(live, b"CURRENT")
os.makedirs(vdir(root, NAME)); write(os.path.join(vdir(root, NAME), "name.txt"), NAME); write(os.path.join(vdir(root, NAME), "v1_1700000000001_0.ver"), b"LEGACY-FULL-COPY" * 10)
vs = run("list", root, NAME); check(vs == ["1|1700000000001|160|false|false"], f"liệt kê thấy bản .ver (chunked=false, kích thước = độ dài tệp): {vs}")
check(run("restore", root, NAME, 1, live, 1700000009000, 6)[0] == "true" and open(live, "rb").read() == b"LEGACY-FULL-COPY" * 10, "khôi phục bản .ver đúng nội dung")
check(assemble(root, NAME, 2) == b"CURRENT" and [v.split("|")[0] for v in run("list", root, NAME)] == ["2", "1"], "nội dung đang dùng được giữ thành bản 2 theo kiểu mới, đứng cạnh bản .ver")
check(run("pin", root, NAME, 1, 1)[0] == "true" and "v1_1700000000001_1.ver" in vfiles(root, NAME), "ghim bản .ver: đổi tên giữ nguyên đuôi .ver")

print("== I. thay tệp bằng tệp khác (Tải lên phiên bản mới)")
root = new_root(); live = write(os.path.join(root, "library", NAME), rbytes(700, 200 * 1024)); other = write(os.path.join(root, "library", "ket-qua-nen.pdf"), rbytes(701, 120 * 1024))
r = run("replace", root, NAME, other, live, 1700000000000, 6)[0]
check(r == "true" and open(live, "rb").read() == rbytes(701, 120 * 1024), "tệp sống có nội dung của tệp thay thế")
check(os.path.exists(other) and open(other, "rb").read() == rbytes(701, 120 * 1024), "tệp thay thế VẪN CÒN nguyên chỗ cũ (được chép, không bị chuyển đi)")
check(assemble(root, NAME, 1) == rbytes(700, 200 * 1024), "nội dung cũ nằm trong lịch sử từng byte")
check(not [f for f in os.listdir(os.path.dirname(live)) if f.endswith(".part")], "không để lại tệp .part")
write(os.path.join(root, "file_versions_blocker"), b"x"); root5 = new_root(); l5 = write(os.path.join(root5, "library", "z.pdf"), b"KEEP" * 5000); o5 = write(os.path.join(root5, "library", "o.pdf"), b"OTHER")
write(os.path.join(root5, "file_versions"), b"a FILE in the way")
check(run("replace", root5, "z.pdf", o5, l5, 1, 6)[0] == "false" and open(l5, "rb").read() == b"KEEP" * 5000, "không giữ được bản cũ -> KHÔNG thay: tệp sống còn nguyên")
check(run("replace", root, NAME, os.path.join(root, "khong-co.pdf"), live, 1, 6)[0] == "false", "tệp thay thế không tồn tại -> false")

print("== J. đổi tên, dọn mồ côi, dung lượng")
root = new_root(); live = os.path.join(root, "library", NAME); write(live, rbytes(800, 100 * 1024)); run("snap", root, NAME, live, 1, 6)
check(run("rename", root, NAME, "ten moi.pdf")[0] == "true" and len(versions(root, "ten moi.pdf")) == 1 and not os.path.isdir(vdir(root, NAME)), "đổi tên tệp: lịch sử đi theo sang thư mục mới")
check(assemble(root, "ten moi.pdf", 1) == rbytes(800, 100 * 1024), "bản đã đổi tên vẫn ghép đúng (mảnh dùng chung toàn kho, không phụ thuộc tên)")
check(open(os.path.join(vdir(root, "ten moi.pdf"), "name.txt"), encoding="utf-8").read() == "ten moi.pdf", "name.txt được cập nhật")
check(run("rename", root, "khong co", "x.pdf")[0] == "false", "đổi tên tệp không có lịch sử -> false")
root = new_root()
for n, age_days in (("con.pdf", 40), ("moi-xoa.pdf", 2), ("van-con.pdf", 90)):
    p = write(os.path.join(root, "library", n), rbytes(900 + len(n), 60 * 1024)); run("snap", root, n, p, 1, 6)
    old = time.time() - age_days * 86400
    for f in os.listdir(vdir(root, n)): os.utime(os.path.join(vdir(root, n), f), (old, old))
now_ms = int(time.time() * 1000); grace = 30 * 86400 * 1000
removed = run("purge", root, now_ms, grace, "van-con.pdf")[0]
check(removed == "1" and not os.path.isdir(vdir(root, "con.pdf")) and os.path.isdir(vdir(root, "moi-xoa.pdf")) and os.path.isdir(vdir(root, "van-con.pdf")),
      "tệp đã biến mất khỏi thư viện: dọn thư mục cũ hơn 30 ngày (con.pdf, 40 ngày), GIỮ thư mục mới (2 ngày, có thể chỉ ở thùng rác) và của tệp còn tồn tại (90 ngày)")
check(assemble(root, "moi-xoa.pdf", 1) is not None and assemble(root, "van-con.pdf", 1) is not None, "mảnh của các thư mục còn lại KHÔNG bị dọn nhầm khi dọn thư mục mồ côi")
check(run("total", root)[0] == str(physical(root)), "dung lượng = dung lượng thật")
run("clear", root); check(run("total", root)[0] == "0" and not os.path.exists(os.path.join(root, "file_versions")), "xoá tất cả: sạch, kể cả kho mảnh")

print("== K. thử âm tính: mã cố tình sai PHẢI bị bắt (có đối chứng)")
def probe(klass):
    def R(*a): return run(*a, klass=klass)
    r = new_root(); live = os.path.join(r, "library", NAME); new = write(os.path.join(r, "tmp", "n.pdf"), b"NEW" * 50000)
    write(live, b"OLD" * 50000); ok = R("commit", r, NAME, new, live, 5, 2)[0] == "true" and open(live, "rb").read() == b"NEW" * 50000 and assemble(r, NAME, 1) == b"OLD" * 50000
    for i in range(2, 7): write(live, rbytes(i, 30000)); R("snap", r, NAME, live, 10 + i, 2)
    two = [int(x.split("|")[0]) for x in R("list", r, NAME)] == [6, 5]
    r2 = new_root(); l2 = os.path.join(r2, "library", NAME)
    for i in range(1, 3): write(l2, rbytes(40 + i, 30000)); R("snap", r2, NAME, l2, i, 2)
    R("pin", r2, NAME, 1, 1)
    for i in range(3, 6): write(l2, rbytes(40 + i, 30000)); R("snap", r2, NAME, l2, i, 2)
    pinned_kept = 1 in [int(x.split("|")[0]) for x in R("list", r2, NAME)] and assemble(r2, NAME, 1) == rbytes(41, 30000)
    r3 = new_root(); l3 = write(os.path.join(r3, "library", NAME), b"cur")
    for i in (1, 2): write(l3, rbytes(50 + i, 30000)); R("snap", r3, NAME, l3, i, 2)
    write(l3, b"current"); restored = R("restore", r3, NAME, 1, l3, 9, 2)[0] == "true" and open(l3, "rb").read() == rbytes(51, 30000)
    r4 = new_root(); l4 = write(os.path.join(r4, "library", NAME), b"KEEP"); n4 = write(os.path.join(r4, "tmp", "n"), b"X"); write(os.path.join(r4, "file_versions"), b"file")
    guarded = R("commit", r4, NAME, n4, l4, 1, 6)[0] == "false" and open(l4, "rb").read() == b"KEEP"
    r5 = new_root(); l5 = write(os.path.join(r5, "library", NAME), rbytes(60, 300 * 1024)); R("snap", r5, NAME, l5, 1, 6); write(l5, b"now")
    pc = sorted(pool_files(r5))[0]; raw = bytearray(open(pc, "rb").read()); raw[5] ^= 1; open(pc, "wb").write(bytes(raw))
    detects = R("restore", r5, NAME, 1, l5, 2, 6)[0] == "false" and open(l5, "rb").read() == b"now"
    r6 = new_root(); l6 = os.path.join(r6, "library", NAME)
    for i in range(1, 5): write(l6, rbytes(70 + i, 30000)); R("snap", r6, NAME, l6, i, 6)
    swept = R("pruneall", r6, 2)[0] == "2" and {os.path.basename(f) for f in pool_files(r6)} == {l.split()[0] for i in (3, 4) for l in manifest_of(r6, NAME, i)[1:]}
    r7 = new_root(); l7 = os.path.join(r7, "library", NAME)
    for i in range(1, 4): write(l7, rbytes(80 + i, 60000)); R("snap", r7, NAME, l7, i, 6)
    p1 = {l.split()[0] for l in manifest_of(r7, NAME, 1)[1:]}
    d7 = vdir(r7, NAME); m7 = [f for f in os.listdir(d7) if f.startswith("v1_")][0]; os.remove(os.path.join(d7, m7)); os.mkdir(os.path.join(d7, m7))
    R("pruneall", r7, 1)
    safe = p1 <= {os.path.basename(f) for f in pool_files(r7)}
    return ok and two and pinned_kept and restored and guarded and detects and swept and safe
check(probe(cls), "đối chứng: mã gốc đạt phép thử")
MUT = (("ghi đè dù KHÔNG giữ được bản cũ", "if (target.isFile && snapshot(root, name, target, now, limit) == null) return false", "if (target.isFile) snapshot(root, name, target, now, limit)"),
       ("xoá cả bản ghim khi dọn", ".sortedByDescending { it.id }.filter { !it.pinned }\n        val extra = unpinned.size - clampLimit(limit)\n        if (extra <= 0) return 0", ".sortedByDescending { it.id }\n        val extra = unpinned.size - clampLimit(limit)\n        if (extra <= 0) return 0"),
       ("giữ N+1 bản thay vì N", "val extra = unpinned.size - clampLimit(limit)\n        if (extra <= 0) return 0", "val extra = unpinned.size - clampLimit(limit) - 1\n        if (extra <= 0) return 0"),
       ("không kiểm băm của mảnh khi khôi phục", "if (data.size != len || toHex(digest.digest(data)) != hash) throw IOException(\"a piece is missing or damaged\")", "if (false) throw IOException(\"x\")"),
       ("không dọn mảnh mồ côi sau khi bỏ bản", "if (c.name !in referenced) c.delete()", "if (false) c.delete()"),
       ("dọn mảnh dù KHÔNG đọc được một bản kê (mất dữ liệu)", "                } catch (e: Exception) {\n                    return\n                }\n            }\n        }\n        for (shard in pool.listFiles() ?: return) {", "                } catch (e: Exception) {\n                }\n            }\n        }\n        for (shard in pool.listFiles() ?: return) {"),
       ("pruneAll không áp dụng giới hạn mới", "for (d in docDirs(root)) removed += pruneDir(d, limit)", "for (d in docDirs(root)) removed += pruneDir(d, DEFAULT_LIMIT)"))
ONLY = {int(x) for a in sys.argv if a.startswith("--mutants=") for x in a.split("=")[1].split(",")}   # run only some mutants (each recompiles, ~1 min)
for number, (name, old, new) in enumerate(MUT, 1):
    if ONLY and number not in ONLY: continue
    try:
        mdir = tc.compile(["FileVersions.kt"], [HARNESS], os.path.join(WORK, "mut"), {"FileVersions.kt": (old, new)}, None)[0]
        check(not probe(mdir), f"mã sai bị bắt: {name}")
    except RuntimeError as e:
        check(False, f"mutant không biên dịch được: {name}: {str(e)[:120]}")

print()
print("TAT CA DAT" if not fails else f"{len(fails)} LOI")
sys.exit(1 if fails else 0)
