"""LinkImport (phiên 22, mục 4.49.4): "Nhập từ liên kết" - bản Java LinkImportCheck.java (cùng quy tắc, cùng mã HttpURLConnection với LinkImport.kt).

  1. parse: bảng chấp nhận / từ chối (http, ftp, javascript, file, //host, thông tin đăng nhập trong liên kết, khoảng trắng trong máy chủ, quá 2048 ký tự...),
     và dạng chuẩn hoá so với urllib (khoảng trắng + chữ có dấu trong đường dẫn -> %XX UTF-8, máy chủ có dấu -> punycode theo codec idna của Python).
  2. resolveRedirect: tương đối / tuyệt đối / "//host" / "..", KHÔNG hạ cấp https -> http, từ chối ftp / javascript / thông tin đăng nhập.
  3. sniffExtension: JPEG / PNG / WebP / PDF (tiêu đề PDF ở byte 0, 1000, 1024 được; 1025 không), HTML / GIF / ZIP / WAV / rỗng / "%PDF" cụt bị từ chối.
  4. fileName: filename* (RFC 5987, UTF-8 và ISO-8859-1) thắng filename, dấu ';' trong ngoặc kép, "../" bị loại, tên quá dài bị cắt, đuôi giả (.php) thay bằng đuôi đúng.
  5. download với MÁY CHỦ THỬ CỤC BỘ: PDF có rác 600 byte phía trước, JPEG / PNG / WebP, chuỗi chuyển hướng (5 lần chuyển đạt, 6 lần hỏng, vòng lặp hỏng, Location trống / ftp hỏng),
     HTML giả Content-Type pdf bị từ chối, vượt giới hạn (Content-Length khai báo; chunked không khai báo; đúng bằng giới hạn thì đạt, hơn 1 byte thì không),
     404 / 500, cụt giữa chừng, và MỖI lỗi đều không để lại tệp.
Chạy: python3 link_import_check.py   (cần java; ~30 giây)
"""
import os, random, subprocess, sys, tempfile, threading, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from _common import OUT

HERE = os.path.dirname(os.path.abspath(__file__)); JAVA = os.path.join(HERE, "LinkImportCheck.java")
ENV = dict(os.environ, LC_ALL="C.UTF-8")
fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

def h(s): return "-" if s is None else s.encode("utf-8").hex()
def run(lines):
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", JAVA], input=("\n".join(lines) + "\n").encode("ascii"), capture_output=True, env=ENV)
    if r.returncode != 0: raise RuntimeError(r.stderr.decode()[-2000:])
    out = r.stdout.decode("utf-8").split("\n")[:-1]
    assert len(out) == len(lines), (len(out), len(lines))
    return out

# ---------- 1. parse ----------
SAFE = "".join(chr(c) for c in range(0x21, 0x7F) if chr(c) not in '"<>\\^`{|}')
def enc(tail): return urllib.parse.quote(tail, safe=SAFE)
accept = [
    ("https://example.com/a.pdf", "https://example.com/a.pdf"),
    ("  https://example.com/a.pdf \n", "https://example.com/a.pdf"),
    ("HTTPS://Example.COM/A.pdf", "https://Example.COM/A.pdf"),
    ("https://example.com", "https://example.com"),
    ("https://example.com/tài liệu.pdf?x=1&y=2 3#frag", "https://example.com" + enc("/tài liệu.pdf?x=1&y=2 3#frag")),
    ("https://example.com/a%20b.pdf", "https://example.com/a%20b.pdf"),
    ("https://bücher.example/x", "https://" + "bücher.example".encode("idna").decode() + "/x"),
    ("https://example.com:8443/x", "https://example.com:8443/x"),
    ("https://[::1]:8080/x.pdf", "https://[::1]:8080/x.pdf"),
    ("https://localhost/x", "https://localhost/x"),
    ("https://192.168.1.5/x.pdf", "https://192.168.1.5/x.pdf"),
    ("https://example.com/a\"b<c>d^e`f{g|h}i", "https://example.com" + enc("/a\"b<c>d^e`f{g|h}i")),
]
reject = ["http://example.com/x", "ftp://example.com/y", "javascript:alert(1)", "file:///etc/passwd", "//example.com/x", "example.com/x.pdf", "https://", "https:///x",
          "https://user:pw@example.com/x", "https://user@example.com/x", "https://exa mple.com/x", "https://example.com/\x01x", "", "   ", "https://" + "a" * 3000,
          "https://example..com/x", "data:text/html,hi", "HTTP://example.com/x", "https://example.com\\@evil.com/x", "https://a.com/x\x7f"]
res = run([f"parse\t{h(i)}\t0" for i, _ in accept] + [f"parse\t{h(i)}\t0" for i in reject] + [f"parse\t{h('http://127.0.0.1:8080/x')}\t1", f"parse\t{h('http://127.0.0.1:8080/x')}\t0"])
bad = [(i, e, g) for (i, e), g in zip(accept, res) if g != e]
check(not bad, f"parse: {len(accept)} liên kết hợp lệ được chuẩn hoá đúng (khoảng trắng / chữ có dấu -> %XX UTF-8, máy chủ có dấu -> punycode){'' if not bad else ' ' + str(bad[:2])}")
bad = [i for i, g in zip(reject, res[len(accept):]) if g != "null"]
check(not bad, f"parse: {len(reject)} liên kết bị TỪ CHỐI (http, ftp, javascript, file, thông tin đăng nhập, khoảng trắng, ký tự điều khiển, > 2048 ký tự){'' if not bad else ' ' + str(bad)}")
check(res[-2] == "http://127.0.0.1:8080/x" and res[-1] == "null", "parse: http chỉ được chấp nhận khi bật cờ thử nghiệm (ứng dụng luôn tắt cờ)")

# ---------- 2. redirect ----------
B = "https://a.example/dir/page.pdf"
red = [(B, "/other.pdf", 0, "https://a.example/other.pdf"), (B, "other.pdf", 0, "https://a.example/dir/other.pdf"), (B, "../up.pdf", 0, "https://a.example/up.pdf"),
       (B, "https://b.example/x.pdf", 0, "https://b.example/x.pdf"), (B, "http://b.example/x.pdf", 0, "null"), (B, "http://b.example/x.pdf", 1, "null"),
       (B, "//c.example/x", 0, "https://c.example/x"), (B, "/tài liệu.pdf", 0, "https://a.example" + enc("/tài liệu.pdf")), (B, "", 0, "null"),
       (B, "javascript:x", 0, "null"), (B, "https://u:p@evil.example/x", 0, "null"), (B, "ftp://x.example/y", 0, "null"), (B, "?page=2", 0, "https://a.example/dir/page.pdf?page=2"),
       ("http://h.example/p/q", "https://s.example/x", 1, "https://s.example/x"), ("http://h.example/p/q", "/y", 1, "http://h.example/y"), ("http://h.example/p/q", "/y", 0, "null")]
res = run([f"redir\t{h(b)}\t{h(l)}\t{c}" for b, l, c, _ in red])
bad = [(b, l, c, e, g) for (b, l, c, e), g in zip(red, res) if g != e]
check(not bad, f"resolveRedirect: {len(red)} ca (tương đối, tuyệt đối, //host, .., KHÔNG hạ cấp https -> http, từ chối ftp / javascript / đăng nhập){'' if not bad else ' ' + str(bad[:2])}")

# ---------- 3. sniff ----------
def pdf_at(i): return b"x" * i + b"%PDF-1.7\n" + b"y" * 50
snf = [(b"\xff\xd8\xff\xe0abc", "jpg"), (b"\x89PNG\r\n\x1a\n....", "png"), (b"RIFF\x10\x00\x00\x00WEBPVP8 ", "webp"), (b"%PDF-1.4\n", "pdf"), (pdf_at(600), "pdf"), (pdf_at(1000), "pdf"),
       (pdf_at(1024), "pdf"), (pdf_at(1025), "null"), (b"<html><body>login</body></html>", "null"), (b"GIF89a....", "null"), (b"PK\x03\x04....", "null"),
       (b"RIFF\x10\x00\x00\x00WAVEfmt ", "null"), (b"", "null"), (b"%PDF", "null"), (b"%PDF-", "pdf"), (b"\xff\xd8", "null"), (b"\x89PNG\r\n\x1a", "null")]
res = run([f"sniff\t{b.hex() if b else ''}" for b, _ in snf])
bad = [(b[:12], e, g) for (b, e), g in zip(snf, res) if g != e]
check(not bad, f"sniffExtension: {len(snf)} ca (JPEG / PNG / WebP / PDF ở byte 0..1024; HTML, GIF, ZIP, WAV, rỗng, cụt bị loại){'' if not bad else ' ' + str(bad)}")

# ---------- 4. fileName ----------
U = "https://x.example/"
nm = [(U + "files/T%C3%A0i%20li%E1%BB%87u.pdf", None, "pdf", "Tài liệu.pdf"), (U + "a.php?id=3", None, "pdf", "a.pdf"),
      (U + "dl", "attachment; filename*=UTF-8''B%C3%A1o%20c%C3%A1o%20%2B1.pdf", "pdf", "Báo cáo +1.pdf"),
      (U + "dl", 'attachment; filename="a b.pdf"', "pdf", "a b.pdf"),
      (U + "dl", 'attachment; filename="fallback.pdf"; filename*=UTF-8\'\'Th%E1%BA%ADt.pdf', "pdf", "Thật.pdf"),
      (U + "dl", "inline; filename=plain.PDF", "pdf", "plain.pdf"), (U + "dl", 'attachment; filename="../../etc/passwd"', "pdf", "passwd.pdf"),
      (U + "dl", "attachment; filename*=ISO-8859-1''caf%E9.pdf", "pdf", "café.pdf"), (U + "dl", "attachment; filename*=UTF-16''x", "pdf", "dl.pdf"),
      (U, None, "pdf", "download.pdf"), (U + "p/" + "n" * 200 + ".pdf", None, "pdf", "n" * 80 + ".pdf"), (U + "photo.jpeg", None, "jpg", "photo.jpg"),
      (U + "v1.2%20report", None, "pdf", "v1.2 report.pdf"), (U + "a:b", None, "pdf", "a_b.pdf"), (U + "dl", 'attachment; filename="semi;colon.pdf"', "pdf", "semi;colon.pdf"),
      (U + "dl", 'attachment; filename="a\\"b.pdf"', "pdf", "a_b.pdf"), (U + "x%zz.pdf", None, "pdf", "download.pdf"), (U + "plus+sign.pdf", None, "pdf", "plus+sign.pdf"),
      (U + "dl", "attachment", "pdf", "dl.pdf"), (U + "dl", "attachment; filename=", "pdf", "dl.pdf")]
res = run([f"name\t{h(u)}\t{h(d)}\t{h(e)}" for u, d, e, _ in nm])
bad = [(u[-30:], d, e, g) for (u, d, ex, e), g in zip(nm, res) if g != e]
check(not bad, f"fileName: {len(nm)} ca (filename* RFC 5987 UTF-8 / ISO-8859-1, ';' trong ngoặc kép, ../, tên dài, đuôi giả, %zz hỏng){'' if not bad else ' ' + str(bad[:3])}")

# ---------- 5. download với máy chủ cục bộ ----------
rnd = random.Random(7)
def rb(n): return bytes(rnd.randrange(256) for _ in range(n))
PDF = b"x" * 600 + b"%PDF-1.4\n" + rb(300_000) + b"\n%%EOF\n"
JPG = b"\xff\xd8\xff\xe0" + rb(50_000); PNG = b"\x89PNG\r\n\x1a\n" + rb(40_000); WEBP = b"RIFF\x00\x10\x00\x00WEBPVP8 " + rb(30_000)
def exact(n): return (b"%PDF-1.4\n" + rb(n))[:n]
E1M, E1M1 = exact(1_000_000), exact(1_000_001)
BIG = b"%PDF-1.4\n" + rb(5_000_000)
PORT = [0]
class H(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def log_message(self, *a): pass
    def send(self, code, body=b"", headers=(), length=True):
        try:
            self.send_response(code)
            for k, v in headers: self.send_header(k, v)
            if length: self.send_header("Content-Length", str(len(body)))
            self.end_headers(); self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError): pass
    def do_GET(self):
        p = self.path; base = f"http://127.0.0.1:{PORT[0]}"
        if p == "/ok.pdf": self.send(200, PDF, [("Content-Type", "application/pdf")])
        elif p == "/img.jpg": self.send(200, JPG, [("Content-Type", "image/jpeg")])
        elif p == "/img.png": self.send(200, PNG)
        elif p == "/img.webp": self.send(200, WEBP)
        elif p == "/r1": self.send(302, b"", [("Location", "/r2")])
        elif p == "/r2": self.send(301, b"", [("Location", base + "/ok.pdf")])
        elif p == "/loop": self.send(302, b"", [("Location", "/loop")])
        elif p.startswith("/chain"):
            n = int(p[6:]); self.send(302, b"", [("Location", f"/chain{n - 1}" if n > 0 else "/ok.pdf")])
        elif p == "/html": self.send(200, b"<html><body>Please log in</body></html>", [("Content-Type", "text/html")])
        elif p == "/fakepdf": self.send(200, b"<html>error page</html>", [("Content-Type", "application/pdf")])
        elif p == "/big": self.send(200, BIG)
        elif p == "/bigchunk":
            try:
                self.send_response(200); self.send_header("Transfer-Encoding", "chunked"); self.end_headers()
                data = BIG[:3_000_000]
                for i in range(0, len(data), 65536):
                    c = data[i:i + 65536]; self.wfile.write(f"{len(c):x}\r\n".encode() + c + b"\r\n")
                self.wfile.write(b"0\r\n\r\n")
            except (BrokenPipeError, ConnectionResetError): pass
        elif p == "/exact": self.send(200, E1M)
        elif p == "/exactplus": self.send(200, E1M1)
        elif p == "/404": self.send(404, b"nope")
        elif p == "/500": self.send(500, b"boom")
        elif p == "/noloc": self.send(302, b"")
        elif p == "/ftp": self.send(302, b"", [("Location", "ftp://example.com/x.pdf")])
        elif p == "/trunc":
            try:
                self.send_response(200); self.send_header("Content-Length", "100000"); self.end_headers(); self.wfile.write(b"%PDF-1.4\n" + b"z" * 2000); self.wfile.flush()
                self.close_connection = True
            except (BrokenPipeError, ConnectionResetError): pass
        elif p == "/cd": self.send(200, PDF, [("Content-Disposition", "attachment; filename*=UTF-8''B%C3%A1o%20c%C3%A1o.pdf")])
        elif p == "/path/T%C3%A0i%20li%E1%BB%87u.pdf": self.send(200, PDF)
        else: self.send(404, b"")
srv = ThreadingHTTPServer(("127.0.0.1", 0), H); PORT[0] = srv.server_address[1]
threading.Thread(target=srv.serve_forever, daemon=True).start()
work = tempfile.mkdtemp(prefix="li_", dir=OUT)
cases = [  # (path, maxBytes, expected)  expected: ("OK", ext, name, bytes) or ("ERR", reason)
    ("/ok.pdf", 10**7, ("OK", "pdf", "ok.pdf", PDF)), ("/img.jpg", 10**7, ("OK", "jpg", "img.jpg", JPG)), ("/img.png", 10**7, ("OK", "png", "img.png", PNG)), ("/img.webp", 10**7, ("OK", "webp", "img.webp", WEBP)),
    ("/r1", 10**7, ("OK", "pdf", "ok.pdf", PDF)), ("/chain4", 10**7, ("OK", "pdf", "ok.pdf", PDF)), ("/chain5", 10**7, ("ERR", "FAILED")), ("/loop", 10**7, ("ERR", "FAILED")),
    ("/noloc", 10**7, ("ERR", "FAILED")), ("/ftp", 10**7, ("ERR", "FAILED")), ("/html", 10**7, ("ERR", "UNSUPPORTED")), ("/fakepdf", 10**7, ("ERR", "UNSUPPORTED")),
    ("/big", 10**6, ("ERR", "TOO_BIG")), ("/bigchunk", 10**6, ("ERR", "TOO_BIG")), ("/exact", 10**6, ("OK", "pdf", "exact.pdf", E1M)), ("/exactplus", 10**6, ("ERR", "TOO_BIG")),
    ("/404", 10**7, ("ERR", "FAILED")), ("/500", 10**7, ("ERR", "FAILED")), ("/trunc", 10**7, ("ERR", "FAILED")), ("/cd", 10**7, ("OK", "pdf", "Báo cáo.pdf", PDF)),
    ("/path/T%C3%A0i%20li%E1%BB%87u.pdf", 10**7, ("OK", "pdf", "Tài liệu.pdf", PDF)),
]
dests = [os.path.join(work, f"d{i}.bin") for i in range(len(cases))]
res = run([f"dl\t{h(f'http://127.0.0.1:{PORT[0]}' + p)}\t{h(d)}\t{m}" for (p, m, _), d in zip(cases, dests)])
bad = []; leftovers = []
for (p, m, e), d, g in zip(cases, dests, res):
    f = g.split("\t")
    if e[0] == "OK":
        ok = f[0] == "OK" and f[1] == e[1] and f[2] == e[2] and int(f[3]) == len(e[3]) and open(d, "rb").read() == e[3]
    else:
        ok = f[0] == "ERR" and f[1] == e[1]
        if os.path.exists(d): leftovers.append(p)
    if not ok: bad.append((p, g[:80]))
check(not bad, f"download: {len(cases)} tình huống với máy chủ cục bộ (PDF có rác phía trước, ảnh, chuyển hướng 5 lần đạt / 6 lần hỏng, vòng lặp, HTML giả Content-Type pdf, vượt giới hạn khai báo / chunked / sát biên, 404 / 500, cụt){'' if not bad else ' ' + str(bad)}")
check(not leftovers, f"download: mọi lỗi đều KHÔNG để lại tệp dở{'' if not leftovers else ' ' + str(leftovers)}")
srv.shutdown()

print(); print("TAT CA DAT" if not fails else f"{len(fails)} LOI: {fails}")
sys.exit(1 if fails else 0)
