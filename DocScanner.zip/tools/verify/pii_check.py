"""Kiểm chứng PiiDetector (phiên 16): dò thông tin cá nhân (CCCD/CMND, điện thoại, email, thẻ ngân hàng, MST, số tài khoản) để che tự động.

PiiCheck.java là bản Java chạy được của PiiDetector.find / fold / luhn / wordsCovering (cùng java.util.regex, cùng thứ tự ưu tiên).
Đáp án KHÔNG lấy từ chính bộ dò: văn bản được DỰNG từ các giá trị đã biết (nên vị trí và loại đúng nằm sẵn trong cách dựng) xen với "mồi nhử" mà bộ dò
KHÔNG được báo: số tiền có dấu chấm, ngày tháng, số trang, năm, số 12 chữ số không bắt đầu bằng 0, CCCD sai mã tỉnh (000, 097+), số 16 chữ số không qua Luhn,
số 9-10 chữ số trơ trọi không có nhãn. Khuôn: 2000 văn bản ngẫu nhiên + các ca viết tay khó. Giả định có ghi rõ: các chuỗi số được ngăn cách nhau bằng chữ
(giấy tờ thật có nhãn như "Điện thoại:" trước số); hai nhóm số liền nhau đúng kiểu 4-4-4 có thể bị coi là một thẻ.
Cũng kiểm wordsCovering (từ nào bị che) với bản tham chiếu độc lập, và 4 đột biến phải bị bắt.
Chạy: python3 pii_check.py   (cần java 11+)
"""
import os, random, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
HERE = os.path.dirname(os.path.abspath(__file__))
FAILS = []
def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond: FAILS.append(what)
    return cond

rng = random.Random(1612)
FILLER = ["Họ", "tên", "Nguyễn", "Văn", "An", "địa", "chỉ", "Hà", "Nội", "ngày", "sinh", "hợp", "đồng", "số", "tiền", "thanh", "toán", "Total", "Invoice",
          "Điện", "thoại", "liên", "hệ", "Trần", "Thị", "Bích", "ghi", "chú", "người", "mua", "hàng", "công", "ty", "TNHH", "Phường", "Quận", "Điều", "khoản"]
LOWER_BANNED = ("cmnd", "cmt", "cccd", "can cuoc", "chung minh", "mst", "ma so thue", "tax", "stk", "tai khoan", "account")
def folded_ascii(s):
    import unicodedata
    return "".join(unicodedata.normalize("NFD", c)[0] if c not in "đĐ" else ("d" if c == "đ" else "D") for c in s).lower()
assert not any(b in folded_ascii(" ".join(FILLER)) for b in LOWER_BANNED), "từ đệm vô tình chứa nhãn ngữ cảnh"

def digits(n, first=None):
    s = "".join(rng.choice("0123456789") for _ in range(n))
    return (first + s[len(first):]) if first else s
def luhn_ok(d):
    s, dbl = 0, False
    for ch in reversed(d):
        x = int(ch)
        if dbl:
            x *= 2
            if x > 9: x -= 9
        s += x; dbl = not dbl
    return s % 10 == 0
def luhn_number(n):
    base = digits(n - 1, first=rng.choice("123456789"))
    for c in "0123456789":
        if luhn_ok(base + c): return base + c
def sep():
    return rng.choice(["", " ", ".", "-"])

# ---- dương tính: (văn bản, loại, offset đầu, offset cuối trong văn bản đó) ----
def pos_phone_mobile():
    prefix = rng.choice(["0", "84", "+84"])
    nsn = rng.choice("35789") + digits(8)
    cuts = sorted(rng.sample(range(1, 9), rng.randint(0, 3)))
    s = sep() if rng.random() < 0.5 else ""
    parts, last = [], 0
    for c in cuts: parts.append(nsn[last:c]); last = c
    parts.append(nsn[last:])
    joiner = rng.choice(["", " ", ".", "-"])
    t = prefix + (rng.choice(["", " ", ".", "-"])) + joiner.join(parts)
    return t, "PHONE", 0, len(t)
def pos_phone_landline():
    nsn = "2" + digits(9)
    t = "0" + rng.choice(["", " "]) + nsn[:2] + rng.choice(["", " ", "."]) + nsn[2:6] + rng.choice(["", " ", "."]) + nsn[6:]
    return t, "PHONE", 0, len(t)
def pos_email():
    local = "".join(rng.choice("abcdefghijklmnopqrstuvwxyz0123456789._+-") for _ in range(rng.randint(2, 10))).strip(".-+_") or "an"
    labels = ["".join(rng.choice("abcdefghijklmnopqrstuvwxyz0123456789-") for _ in range(rng.randint(2, 8))).strip("-") or "mail" for _ in range(rng.randint(1, 3))]
    t = local + "@" + ".".join(labels) + "." + rng.choice(["com", "vn", "net", "org", "gov"])
    return t, "EMAIL", 0, len(t)
def pos_cccd():
    t = "0" + "%02d" % rng.randint(1, 96) + digits(9)
    return t, "CITIZEN_ID", 0, len(t)
def pos_card():
    L = rng.randint(13, 19)
    d = luhn_number(L)
    s = rng.choice(["", " ", "-"])
    groups = [d[i:i + 4] for i in range(0, len(d) - (len(d) % 4 if len(d) % 4 else 0), 4)]
    rest = d[len(groups) * 4:]
    t = s.join(groups) + ((s if rng.random() < 0.5 else "") + rest if rest else "")
    return t, "CARD", 0, len(t)
def pos_cmnd():
    label = rng.choice(["CMND", "CCCD", "Căn cước", "Chứng minh nhân dân", "SỐ CMND", "CMT"])
    mid = rng.choice([": ", " số ", " ", " - "])
    num = digits(rng.choice([9, 12]))
    t = label + mid + num
    return t, "CITIZEN_ID", len(label + mid), len(t)
def pos_mst():
    label = rng.choice(["MST", "Mã số thuế", "MÃ SỐ THUẾ", "Tax ID", "tax code"])
    mid = rng.choice([": ", " ", " - "])
    num = rng.choice([digits(10), digits(10) + "-" + digits(3), digits(13)])
    num = rng.choice(["0", "01", "03", ""]) + num[len(rng.choice(["0", "01", "03", ""])):] if False else num
    t = label + mid + num
    return t, "TAX_ID", len(label + mid), len(t)
def pos_account():
    label = rng.choice(["STK", "Số tài khoản", "SỐ TÀI KHOẢN", "Account No", "tài khoản"])
    mid = rng.choice([": ", " ", " - "])
    num = digits(rng.randint(6, 19), first=rng.choice(["0", "1", "9", ""]))
    t = label + mid + num
    return t, "ACCOUNT", len(label + mid), len(t)
POS = [pos_phone_mobile, pos_phone_mobile, pos_phone_landline, pos_email, pos_cccd, pos_card, pos_cmnd, pos_mst, pos_account]

# ---- mồi nhử: KHÔNG được báo ----
def decoy():
    k = rng.randint(0, 9)
    if k == 0:
        g = [str(rng.randint(1, 9)) + digits(rng.randint(0, 2))]
        while True:
            g = [str(rng.randint(1, 999))] + ["%03d" % rng.randint(0, 999) for _ in range(rng.randint(1, 3))]
            if g[0] not in ("84",) and not g[0].startswith("0"): break
        return ".".join(g) + " đồng"
    if k == 1: return "%02d/%02d/%04d" % (rng.randint(1, 28), rng.randint(1, 12), rng.randint(1990, 2030))
    if k == 2: return "%04d-%02d-%02d" % (rng.randint(1990, 2030), rng.randint(1, 12), rng.randint(1, 28))
    if k == 3: return str(rng.randint(1, 999))
    if k == 4: return str(rng.randint(1990, 2030))
    if k == 5: return rng.choice("123456789") + digits(11)                       # 12 chữ số không bắt đầu bằng 0
    if k == 6: return rng.choice(["000", "097", "098", "099"]) + digits(9)        # sai mã tỉnh
    if k == 7:
        while True:
            d = digits(16, first=rng.choice("123456789"))
            if not luhn_ok(d): return " ".join(d[i:i + 4] for i in range(0, 16, 4))   # 16 số, không qua Luhn
    if k == 8: return rng.choice(["1", "2", "3", "4", "5", "6", "7", "8", "9"]) + digits(8)   # 9 số trơ trọi
    return rng.choice(["01", "04", "06"]) + digits(8)                            # 10 số trơ trọi (không phải đầu số di động)

def build(rng_):
    parts, expected = [], []
    pos, last_num = 0, False
    for _ in range(rng_.randint(2, 9)):
        r = rng_.random()
        if r < 0.45:
            seg, is_num = " ".join(rng_.choice(FILLER) for _ in range(rng_.randint(1, 4))), False
        elif r < 0.75:
            seg, is_num = decoy(), True
        else:
            seg, is_num = None, True
        if is_num and last_num:      # các chuỗi số phải cách nhau bằng chữ (giả định đã nêu)
            parts.append(rng_.choice(FILLER)); pos += len(parts[-1]) + 1
        if seg is None:
            t, kind, a, b = rng_.choice(POS)()
            expected.append((pos + a, pos + b, kind)); seg = t
        parts.append(seg); pos += len(seg) + 1
        last_num = is_num
    return " ".join(parts), expected

def run(lines, tag):
    cin, cout = os.path.join(OUT, f"pii_{tag}.in"), os.path.join(OUT, f"pii_{tag}.out")
    open(cin, "w", encoding="utf-8").write("\n".join(lines) + "\n")
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", os.path.join(HERE, "PiiCheck.java"), cin, cout], capture_output=True, text=True)
    if r.returncode != 0: sys.exit("Java lỗi:\n" + r.stdout + r.stderr)
    return open(cout, encoding="utf-8").read().split("\n")[:len(lines)]
def parse(out):
    return [tuple(int(x) if i < 2 else x for i, x in enumerate(item.split(":"))) for item in out.split(";") if item]

# ---- ca viết tay ----
HAND_RAW = [  # (văn bản, [(chuỗi con, loại)]) - vị trí được TÍNH từ chuỗi con (đếm tay đã từng sai)
    ("Điện thoại 0912 345 678, email an@x.vn.", [("0912 345 678", "PHONE"), ("an@x.vn", "EMAIL")]),
    ("Liên hệ nguyen.van+a@mail.example.com.vn.", [("nguyen.van+a@mail.example.com.vn", "EMAIL")]),
    ("Tổng cộng: 1.234.567.890 đồng, ngày 12/03/2024", []),
    ("tel:0912345678", [("0912345678", "PHONE")]),
    ("+84 912 345 678", [("+84 912 345 678", "PHONE")]),
    ("Số CMND: 123456789", [("123456789", "CITIZEN_ID")]),
    ("CCCD: 097123456789", [("097123456789", "CITIZEN_ID")]),
    ("097123456789", []),
    ("079185012345", [("079185012345", "CITIZEN_ID")]),
    ("Mã số thuế: 0101234567-001", [("0101234567-001", "TAX_ID")]),
    ("MST: 0312345678", [("0312345678", "TAX_ID")]),
    ("0312345678", [("0312345678", "PHONE")]),
    ("0101234567", []),
    ("123456789", []),
    ("4111 1111 1111 1111", [("4111 1111 1111 1111", "CARD")]),
    ("4111 1111 1111 1112", []),
    ("STK: 0123456789012", [("0123456789012", "ACCOUNT")]),
    ("SỐ TÀI KHOẢN 19031234567890", [("19031234567890", "ACCOUNT")]),
    ("SỐ TÀI KHOẢN: 0490911917972", [("0490911917972", "ACCOUNT")]),   # 13 số, tình cờ qua Luhn: vẫn là tài khoản, không phải thẻ
    ("028 3822 1234", [("028 3822 1234", "PHONE")]),
    ("84912345678", [("84912345678", "PHONE")]),
    ("1912345678", []),
    ("", []),
]
HAND = []
for t, items in HAND_RAW:
    exp = []
    for sub_, kind in items:
        assert t.count(sub_) == 1, (t, sub_)
        a = t.index(sub_); exp.append((a, a + len(sub_), kind))
    HAND.append((t, exp))
assert luhn_ok("0490911917972") and not luhn_ok("4111111111111112"), "ca viết tay giả định sai về Luhn"
res = run(["find\t" + t for t, _ in HAND], "hand")
bad = [(t, exp, parse(g)) for (t, exp), g in zip(HAND, res) if [(a, b, k) for a, b, k in parse(g)] != exp]
check(not bad, f"{len(HAND)} ca viết tay khó (số tiền, ngày, Luhn, sai mã tỉnh, nhãn viết hoa/không dấu...)" + (f" — sai: {bad[:2]}" if bad else ""))

# ---- ngẫu nhiên có đáp án dựng sẵn ----
texts = []
for _ in range(2000):
    texts.append(build(rng))
res = run(["find\t" + t for t, _ in texts], "rnd")
bad = [(t, exp, parse(g)) for (t, exp), g in zip(texts, res) if parse(g) != exp]
n_exp = sum(len(e) for _, e in texts)
n_text_with_decoy = sum(1 for t, _ in texts if "đồng" in t or "/" in t)
check(not bad, f"2000 văn bản dựng từ giá trị đã biết ({n_exp} thông tin cá nhân + mồi nhử): báo đúng và chỉ đúng chúng" + (f" — {len(bad)} sai, vd {bad[0]}" if bad else ""))
kinds_seen = {k for _, e in texts for _, _, k in e}
check(kinds_seen == {"PHONE", "EMAIL", "CITIZEN_ID", "CARD", "TAX_ID", "ACCOUNT"}, f"bộ ngẫu nhiên phủ đủ 6 loại: {sorted(kinds_seen)}")

# ---- wordsCovering với bản tham chiếu độc lập ----
def ref_words(words, a, b):
    offs, pos = [], 0
    for w in words: offs.append((pos, pos + len(w))); pos += len(w) + 1
    hit = [i for i, (s, e) in enumerate(offs) if s < b and e > a]
    return "none" if not hit else f"{hit[0]}-{hit[-1]}"
cases = []
for _ in range(2000):
    words = ["".join(rng.choice("abc0123456789") for _ in range(rng.randint(1, 8))) for _ in range(rng.randint(1, 8))]
    total = len(" ".join(words)); a = rng.randint(0, total); b = rng.randint(a, total + 2)
    cases.append((words, a, b))
res = run([f"words\t{a}\t{b}\t" + "\t".join(w) for w, a, b in cases], "words")
bad = [(w, a, b, ref_words(w, a, b), g) for (w, a, b), g in zip(cases, res) if ref_words(w, a, b) != g]
check(not bad, "wordsCovering: 2000 ca ngẫu nhiên = bản tham chiếu độc lập" + (f" — sai {bad[:1]}" if bad else ""))
check(ref_words(["Tel:", "0912", "345", "678"], 5, 16) == "1-3", "wordsCovering: số 3 từ 'Tel: 0912 345 678' -> các từ 1-3 (vd viết tay)")

# ---- đột biến ----
src = open(os.path.join(HERE, "PiiCheck.java"), encoding="utf-8").read()
def mutate(old, new, label):
    assert old in src, label
    path = os.path.join(OUT, "PiiCheckMut.java")
    open(path, "w", encoding="utf-8").write(src.replace(old, new, 1).replace("class PiiCheck", "class PiiCheckMut"))
    cin, cout = os.path.join(OUT, "pii_hand.in"), os.path.join(OUT, "pii_mut.out")
    r = subprocess.run(["java", "-Dfile.encoding=UTF-8", path, cin, cout], capture_output=True, text=True)
    if r.returncode != 0: return True      # biên dịch/chạy hỏng cũng là bị bắt
    g1 = open(cout, encoding="utf-8").read().split("\n")[:len(HAND)]
    cin2, cout2 = os.path.join(OUT, "pii_rnd.in"), os.path.join(OUT, "pii_mut2.out")
    subprocess.run(["java", "-Dfile.encoding=UTF-8", path, cin2, cout2], capture_output=True, text=True)
    g2 = open(cout2, encoding="utf-8").read().split("\n")[:len(texts)]
    return any(parse(g) != e for (t, e), g in zip(HAND, g1)) or any(parse(g) != e for (t, e), g in zip(texts, g2))
check(mutate("if (digits.length() >= 13 && digits.length() <= 19 && luhn(digits))", "if (digits.length() >= 13 && digits.length() <= 19)", "luhn"), "đột biến 1 (bỏ kiểm Luhn của thẻ) bị bắt")
check(mutate("0(?:0[1-9]|[1-8]\\\\d|9[0-6])", "0\\\\d{2}", "tinh"), "đột biến 2 (nhận mọi mã tỉnh, kể cả 000/097+) bị bắt")
check(mutate("String folded = fold(text);", "String folded = text;", "fold"), "đột biến 3 (không bỏ dấu khi tìm nhãn 'Số CMND', 'Mã số thuế'...) bị bắt")
check(mutate("(?<![\\\\d+])(?:\\\\+84|84|0)[ .\\\\-]?[35789](?:[ .\\\\-]?\\\\d){8}(?!\\\\d)", "(?:\\\\+84|84|0)[ .\\\\-]?[35789](?:[ .\\\\-]?\\\\d){8}", "phone"), "đột biến 4 (số điện thoại không chặn số dài hơn) bị bắt")
print("\nTAT CA DAT" if not FAILS else f"\nCO {len(FAILS)} LOI")
sys.exit(1 if FAILS else 0)
