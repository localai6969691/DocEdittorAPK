"""Kiểm hình học của "tô sáng bằng lớp chữ thật" (`TextLayerWords.kt`, phiên 20, 4.48.7) qua bản Java `TextLayerCheck.java`, trên PDF THẬT:
  reportlab (nhiều phông, cỡ chữ, ký tự có dấu, chữ nghiêng / đậm) + LibreOffice (24 tài liệu python-docx -> PDF: bố cục thật, bảng, tiêu đề).
  Ký tự lấy bằng pdfminer (đọc thứ ba); với MỖI từ, hộp của bản Java được so với hai đáp án ĐỘC LẬP:
   (1) hộp từ của poppler (`pdftotext -bbox`): hai mép trái / phải khớp trong ~1,5 điểm;
   (2) ĐIỂM ẢNH MỰC THẬT của trang (`pdftoppm`, 144 dpi, điểm tối < 128): hộp phải PHỦ >= 97 % mực của từ (không cắt chữ, kể cả dấu và chân chữ g, p, y) mà không phình ra quá 2,2 lần hộp của poppler.
  Thêm ca biên (không ký tự, trang không kích thước, NaN, tràn ra ngoài trang, từ một điểm) và 3 bản hỏng bị bắt (bỏ DESCENT -> cắt chân chữ; không kẹp 0..1; hoán đổi x / y).
KHÔNG kiểm ở đây: `PdfTextLayer` (PDFBox `TextPosition`) chưa chạy trên Android; trang xoay (/Rotate) chưa kiểm.
Chạy: python3 text_layer_check.py   (cần java, pdfminer.six, reportlab, numpy, Pillow, pdftotext / pdftoppm, soffice, python-docx; ~2 phút)"""
import os, re, random, shutil, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import OUT
import numpy as np
from PIL import Image
from pdfminer.high_level import extract_pages
from pdfminer.layout import LTChar, LTAnno, LTTextContainer, LTTextLine, LAParams
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

HERE = os.path.dirname(os.path.abspath(__file__)); JAVA = os.path.join(HERE, "TextLayerCheck.java")
FAIL = []; rnd = random.Random(20261023)
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: FAIL.append(msg)
    return ok
def jv(lines, java=JAVA):
    r = subprocess.run(["java", java], input="\n".join(lines) + "\n", capture_output=True, text=True)
    if r.returncode: print(r.stderr[-1500:]); sys.exit(1)
    return r.stdout.split("\n")[:len(lines)]

def find_font():
    for p in ["/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf"]:
        if os.path.exists(p): return p
    return None

def make_reportlab(path):
    ft = find_font(); c = canvas.Canvas(path, pagesize=A4)
    fonts = ["Helvetica", "Times-Roman", "Courier", "Helvetica-Bold", "Times-Italic"]
    if ft: pdfmetrics.registerFont(TTFont("Uni", ft)); fonts.append("Uni")
    words = "Hợp đồng thuê nhà gypsy jumping quickly Việt Nam ăâêôơư Tiếng paragraph quality yogurt 12.345.678 (ghi chú) hello, world".split()
    for _ in range(2):
        y = 800
        for _ in range(rnd.randint(8, 14)):
            fn = rnd.choice(fonts); size = rnd.choice([8, 10, 12, 14, 18, 24])
            c.setFont(fn, size); x = 40
            for w in [rnd.choice(words) for _ in range(rnd.randint(2, 7))]:
                c.drawString(x, y, w); x += c.stringWidth(w, fn, size) + c.stringWidth(" ", fn, size)
                if x > 520: break
            y -= size * 1.8
            if y < 60: break
        c.showPage()
    c.save()

def poppler_words(pdf):
    out = subprocess.run(["pdftotext", "-bbox", pdf, "-"], capture_output=True, text=True).stdout
    pages = []
    for pm in re.finditer(r'<page width="([\d.]+)" height="([\d.]+)">(.*?)</page>', out, re.S):
        w, h = float(pm.group(1)), float(pm.group(2))
        ws = [(re.sub("&amp;", "&", re.sub("&lt;", "<", re.sub("&gt;", ">", m.group(5)))), float(m.group(1)), float(m.group(2)), float(m.group(3)), float(m.group(4)))
              for m in re.finditer(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">(.*?)</word>', pm.group(3))]
        pages.append((w, h, ws))
    return pages

def miner_words(pdf):
    """[(trang) -> [(chữ, [Glyph(x, baseline từ ĐỈNH, rộng, CỠ CHỮ)])]]; cắt từ ở dấu cách."""
    res = []
    for page in extract_pages(pdf, laparams=LAParams()):
        H = page.height; words = []
        def walk(o):
            if isinstance(o, LTTextLine):
                cur = []
                for ch in o:
                    if isinstance(ch, LTChar) and ch.get_text().strip():
                        base = ch.matrix[5]
                        cur.append((ch.get_text(), (ch.x0, H - base, ch.x1 - ch.x0, ch.size)))
                    else:
                        if cur: words.append(cur); cur = []
                if cur: words.append(cur)
            elif hasattr(o, "__iter__"):
                for x in o: walk(x)
        walk(page); res.append((page.width, page.height, [("".join(t for t, _ in w), [g for _, g in w]) for w in words]))
    return res

def main():
    tmp = tempfile.mkdtemp(dir=OUT); os.chdir(tmp)
    try:
        pdfs = []
        for i in range(4):
            p = f"rl{i}.pdf"; make_reportlab(p); pdfs.append(p)
        import docx
        os.makedirs("docx")
        for i in range(10):
            d = docx.Document(); d.add_heading("Tiêu đề thử nghiệm số %d" % i, 1)
            for _ in range(rnd.randint(3, 8)): d.add_paragraph(" ".join(rnd.choice(["Hợp", "đồng", "thuê", "nhà", "gypsy", "quickly", "Việt", "ăâêôơư", "paragraph", "yogurt", "12.345", "(ghi", "chú)", "hello,"]) for _ in range(rnd.randint(8, 40))))
            t = d.add_table(rows=2, cols=3)
            for r in t.rows:
                for c in r.cells: c.text = rnd.choice(["một", "hai", "quá", "gypsy", "Đường"])
            d.save(f"docx/d{i}.docx")
        subprocess.run(["soffice", "--headless", "--convert-to", "pdf", "--outdir", "lo"] + [f"docx/d{i}.docx" for i in range(10)], capture_output=True, timeout=600)
        pdfs += [f"lo/d{i}.pdf" for i in range(10)]
        total = matched = 0; dx_bad = 0; cover = []; area = []; ncases = 0
        for pdf in pdfs:
            pops = poppler_words(pdf); mins = miner_words(pdf)
            for pno, ((pw, ph, pw_words), (mw, mh, m_words)) in enumerate(zip(pops, mins)):
                subprocess.run(["pdftoppm", "-r", "144", "-gray", "-f", str(pno + 1), "-l", str(pno + 1), "-png", pdf, "pg"], capture_output=True)
                img = [f for f in os.listdir(".") if f.startswith("pg") and f.endswith(".png")][0]
                ink = np.array(Image.open(img).convert("L")) < 128; os.remove(img)
                sx = ink.shape[1] / pw; sy = ink.shape[0] / ph
                cmds = ["%f %f %d %s" % (mw, mh, len(g), " ".join("%f %f %f %f" % q for q in g)) for _, g in m_words]
                boxes = jv(cmds) if cmds else []
                used = set()
                for (txt, x0, y0, x1, y1) in pw_words:
                    total += 1
                    cand = [(abs(((g[0][0] + g[-1][0] + g[-1][2]) / 2) - (x0 + x1) / 2) + abs(g[0][1] - y1 + (y1 - y0) * .25), k) for k, (t, g) in enumerate(m_words) if t == txt and k not in used]
                    if not cand: continue
                    d, k = min(cand)
                    if d > 12: continue
                    used.add(k); matched += 1
                    if boxes[k] == "NULL": continue
                    l, t, r, b = [float(v) for v in boxes[k].split()]
                    L, T, R, B = l * pw, t * ph, r * pw, b * ph
                    if abs(L - x0) > 1.5 or abs(R - x1) > 1.5: dx_bad += 1
                    # mực thật nằm TRONG hộp poppler của từ (poppler phủ cả ascent lẫn descent của phông) và phần của nó mà hộp của ta phủ
                    ra, rb = int(y0 * sy), int(np.ceil(y1 * sy)); ca, cb = int(x0 * sx), int(np.ceil(x1 * sx))
                    ref = ink[ra:rb, ca:cb]
                    if ref.sum() < 8: continue
                    mask = np.zeros_like(ink, dtype=bool)
                    mask[max(0, int(T * sy)):int(np.ceil(B * sy)) + 1, max(0, int(L * sx)):int(np.ceil(R * sx)) + 1] = True
                    cover.append(float(ink[ra:rb, ca:cb][mask[ra:rb, ca:cb]].sum()) / float(ref.sum()))
                    area.append(((R - L) * (B - T)) / max(1e-6, (x1 - x0) * (y1 - y0)))
        check(total > 1500 and matched / total > 0.8, f"{len(pdfs)} PDF thật (4 reportlab nhiều phông / cỡ + 10 LibreOffice): ghép được {matched}/{total} từ giữa poppler và pdfminer")
        check(dx_bad / max(1, matched) < 0.03, f"hai mép trái / phải của hộp = hộp từ poppler trong 1,5 điểm ở {100 - 100 * dx_bad / max(1, matched):.1f} % từ ({dx_bad} lệch)")
        cv = np.array(cover); ar = np.array(area)
        check(np.median(cv) >= 0.999 and np.percentile(cv, 1) >= 0.99, f"hộp PHỦ mực thật trong hộp poppler: trung vị {np.median(cv) * 100:.1f} %, phân vị 1 % {np.percentile(cv, 1) * 100:.1f} % trên {len(cv)} từ (không cắt chữ, dấu chồng trên chữ hoa, chân chữ g p y)")
        check(np.median(ar) < 1.2 and np.percentile(ar, 95) < 1.6, f"hộp không phình: diện tích / hộp poppler trung vị {np.median(ar):.2f}, phân vị 95 % {np.percentile(ar, 95):.2f}")
        # ca biên
        edge = ["595 842 0", "0 842 1 10 700 20 10", "595 0 1 10 700 20 10", "595 842 1 NaN 700 20 10", "595 842 2 580 100 40 10 -5 100 20 10", "595 842 1 10 700 0.0001 0.0001", "595 842 1 10 5 20 10", "595 842 1 10 840 20 10"]
        out = jv(edge)
        check(out[0] == "NULL" and out[1] == "NULL" and out[2] == "NULL" and out[3] == "NULL" and out[5] == "NULL", f"ca biên: không ký tự / trang không kích thước / NaN / từ một điểm -> null ({out[:4]})")
        v = [float(x) for x in out[4].split()]
        check(all(0 <= x <= 1 for x in v) and v[0] == 0.0 and v[2] == 1.0, f"từ tràn ra ngoài trang bị kẹp vào 0..1 ({v})")
        v = [float(x) for x in out[6].split()]; check(v[1] == 0.0 and v[3] > 0.0, f"từ sát mép trên (đỉnh âm) kẹp ở 0 ({v})")
        # bản hỏng
        src = open(JAVA, encoding="utf-8").read(); n = [0]
        def mut(old, new):
            assert src.count(old) == 1, old; n[0] += 1; p = os.path.join(tmp, f"TL{n[0]}.java")
            open(p, "w", encoding="utf-8").write(src.replace(old, new).replace("TextLayerCheck", f"TL{n[0]}")); return p
        base = jv(["595 842 1 100 700 30 10"])[0].split(); 
        j = mut("t = Math.min(t, base - ASCENT * size); b = Math.max(b, base + DESCENT * size);", "t = Math.min(t, base - 0.7f * size); b = Math.max(b, base + 0.1f * size);")
        m1 = jv(["595 842 1 100 700 30 10"], j)[0].split()
        check(float(m1[3]) < float(base[3]) and float(m1[1]) > float(base[1]), "bản hỏng 'hằng số 0,70 / 0,10' (cắt 3-9 % số từ trên dữ liệu thật) cho hộp nhỏ hơn: bị bắt bằng so sánh với hằng số đã chọn")
        j = mut("float[] box = {clamp(l / pw), clamp(t / ph), clamp(r / pw), clamp(b / ph)};", "float[] box = {l / pw, t / ph, r / pw, b / ph};")
        check(jv(["595 842 1 580 100 40 10"], j)[0].split()[2] != "1.0", "bản hỏng 'không kẹp 0..1' bị bắt bởi ca tràn trang")
        j = mut("float[] box = {clamp(l / pw), clamp(t / ph), clamp(r / pw), clamp(b / ph)};", "float[] box = {clamp(l / ph), clamp(t / pw), clamp(r / ph), clamp(b / pw)};")
        check(jv(["595 842 1 100 700 30 10"], j)[0] != jv(["595 842 1 100 700 30 10"])[0], "bản hỏng 'hoán đổi chiều rộng / cao trang' bị bắt")
    finally:
        os.chdir(HERE); shutil.rmtree(tmp, ignore_errors=True)
    print("TAT CA DAT" if not FAIL else f"CO LOI ({len(FAIL)})")
    return 1 if FAIL else 0

if __name__ == "__main__": sys.exit(main())
