#!/usr/bin/env python3
"""Nhớ trang VÀ mức phóng của trình đọc PDF (`util/PdfReadingPositions.kt`; phiên 26, TECHNICAL_DOCS.md 4.82): mã Kotlin thật chạy bằng kotlinc, so với một mô hình Python viết độc lập từ đặc tả.

Đặc tả (từ mục 6.1(c) của tài liệu): mỗi lần mở lại một PDF, trình đọc quay về trang đã đọc dở VÀ mức phóng lúc rời đi. Giá trị đã ghi từ trước phiên 26 (`trang<TAB>khoá`) vẫn đọc được (mức phóng 1x);
mức phóng được lưu bằng phần trăm nguyên (105..400), không lưu khi <= 1,05 (coi là không phóng); dòng hỏng bị bỏ qua, mức phóng hỏng đọc là 1x; tối đa 100 PDF, bỏ cái cũ nhất; khoá có TAB / xuống
dòng được làm sạch; `put` (chỉ trang) giữ mức phóng đã lưu; `putPlace` với mức <= 1,05 xoá mức phóng.
  A. 3 000 thao tác ngẫu nhiên (put / putp / get / getp) trên 150 khoá (vượt giới hạn 100), mỗi kết quả so với mô hình;
  B. các tình huống cố định: giá trị cũ, dòng hỏng (6 kiểu), kẹp mức phóng (9999 -> 4,00; 50 -> 1), làm sạch khoá, `put` giữ mức phóng, `putPlace` 1x xoá mức phóng, bản ghi vòng tròn.
THỬ ÂM TÍNH: 4 bản mã bị làm hỏng (không bao giờ ghi mức phóng; `put` xoá mức phóng; bỏ cái MỚI nhất thay vì cũ nhất; không kẹp 4x) PHẢI bị bắt.
KHÔNG kiểm được: cử chỉ phóng thật và việc `restoreZoom` đặt đúng vị trí trên màn hình (cần điện thoại).
Chạy: python3 tools/verify/reading_positions_real_run_check.py [--fast]"""
import base64, os, random, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="readpos-")
HARNESS = os.path.join(HERE, "real_run", "ReadingPositionsHarness.kt")
def build(mutate=None, tag="base"): return tc.compile(["PdfReadingPositions.kt"], [HARNESS], os.path.join(WORK, "cls-" + tag), mutate)[0]
b = lambda s: base64.b64encode(s.encode()).decode()
u = lambda s: base64.b64decode(s).decode()

def run_batch(cls, lines):
    r = tc.run(cls, "ReadingPositionsHarnessKt", [], stdin="\n".join(lines) + "\n")
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-800:])
    return r.stdout.split("\n")[:-1]

# ----------------------------------------------------------------------------------------- independent model
MAX, MINZ, MAXZ = 100, 1.05, 4.0
def nz(z):
    if z != z or z <= MINZ: return 1.0
    return int(min(z, MAXZ) * 100 + 0.5) / 100
def clean(s): return "".join(" " if c in "\t\n\r" else c for c in s)
class Model:
    def __init__(self): self.d = {}      # insertion ordered: oldest first
    def put(self, key, page, zoom=None):
        k = clean(key); z = nz(zoom) if zoom is not None else (self.d[k][1] if k in self.d else 1.0)
        self.d.pop(k, None); self.d[k] = (max(page, 0), z)
        while len(self.d) > MAX: self.d.pop(next(iter(self.d)))
    def get(self, key): return self.d.get(clean(key))

def parse_text(text):
    """The stored text of the model, as the specification writes it."""
    return "".join(f"{p}\t{k}" + (f"\t{round(z * 100)}" if z > 1.0 else "") + "\n" for k, (p, z) in text.d.items())

def group_random(cls, seed=26):
    rnd = random.Random(seed); keys = [f"file{i}.pdf|{rnd.randint(1000, 99999)}" for i in range(150)] + ["tab\tname.pdf|5", "new\nline.pdf|6"]
    m = Model(); text = ""; cmds = []; expect = []
    # the harness is stateless (text in, text out), so the whole run is driven by Python: one batch per step would be slow; instead replay the model in lock-step with batches of independent steps
    steps = []
    for _ in range(3000):
        op = rnd.choice(["putp", "putp", "put", "getp", "get"]); k = rnd.choice(keys)
        if op == "putp": steps.append((op, k, rnd.randint(0, 900), rnd.choice([1.0, 1.04, 1.06, 1.5, 2.0, 2.37, 3.33, 3.99, 4.0, 4.5, 7.0, 0.5, -3.0])))
        elif op == "put": steps.append((op, k, rnd.randint(0, 900), None))
        else: steps.append((op, k, None, None))
    bad = []; cur = ""; mism = 0
    CH = 60
    for s0 in range(0, len(steps), CH):
        # texts are produced by the REAL code, step by step, but evaluated in one process per chunk: replay inside Python by chaining outputs requires round trips, so run each chunk sequentially in ONE batch
        # by making every command depend only on text we can predict: the model text. The real code's own output is compared to the model text after each write.
        lines = []; exp = []
        for op, k, page, z in steps[s0:s0 + CH]:
            if op == "putp": lines.append(f"putp {b(parse_text(m))} {b(k)} {page} {z}"); m.put(k, page, z); exp.append(("text", parse_text(m)))
            elif op == "put": lines.append(f"put {b(parse_text(m))} {b(k)} {page}"); m.put(k, page); exp.append(("text", parse_text(m)))
            elif op == "getp":
                lines.append(f"getp {b(parse_text(m))} {b(k)}"); g = m.get(k); exp.append(("val", "-" if g is None else f"{g[0]} {g[1]}"))
            else:
                lines.append(f"get {b(parse_text(m))} {b(k)}"); g = m.get(k); exp.append(("val", "-" if g is None else str(g[0])))
        out = run_batch(cls, lines)
        for (kind, want), got, line in zip(exp, out, lines):
            got = u(got) if kind == "text" else got
            if kind == "val":   # the Kotlin prints a Float: 2.0 -> "2.0", the model prints a float the same way
                g = got.split(" "); w = want.split(" ")
                same = got == want or (len(g) == 2 and len(w) == 2 and g[0] == w[0] and abs(float(g[1]) - float(w[1])) < 1e-6)
            else:
                same = got == want
            if not same: mism += 1; bad.append((line[:30], want[:60], got[:60]))
    check(mism == 0, f"(A) 3 000 thao tác ngẫu nhiên trên 152 khoá (có TAB / xuống dòng trong khoá, vượt giới hạn {MAX}): mọi kết quả khớp mô hình" + ("" if not bad else f"; {mism} lệch, ví dụ {bad[:2]}"))
    check(len(m.d) == MAX, f"(A) mô hình ở giới hạn {MAX} mục (kiểm tra đã thực sự chạm giới hạn)")

def one(cls, *line): return run_batch(cls, [" ".join(line)])[0]

def group_fixed(cls):
    old = "5\tname.pdf|100\n7\tother.pdf|200\n"
    check(one(cls, "getp", b(old), b("name.pdf|100")) == "5 1.0" and one(cls, "get", b(old), b("other.pdf|200")) == "7", "(B1) giá trị ghi từ trước phiên 26 (không có mức phóng) vẫn đọc được: trang đúng, mức phóng 1x")
    damaged = "abc\tk1\n-1\tk2\n\tk3\n3\t\nno tab here\n4\tkey4\tnotanumber\n6\tkey6\t9999\n8\tkey8\t50\n9\tkey9\t237\n"
    got = {k: one(cls, "getp", b(damaged), b(k)) for k in ["k1", "k2", "k3", "key4", "key6", "key8", "key9"]}
    check(got["k1"] == got["k2"] == got["k3"] == "-", f"(B2) dòng hỏng (trang không phải số, trang âm, khoá rỗng, không TAB) bị bỏ qua: {got['k1'], got['k2'], got['k3']}")
    check(got["key4"] == "4 1.0", f"(B2) mức phóng không phải số -> đọc là 1x, mục vẫn giữ: {got['key4']}")
    check(got["key6"] == "6 4.0", f"(B2) 9999 hundredths bị kẹp ở 4x: {got['key6']}")
    check(got["key8"] == "8 1.0", f"(B2) 0,50x (dưới ngưỡng) -> 1x: {got['key8']}")
    check(got["key9"] == "9 2.37", f"(B2) 2,37x đọc đúng: {got['key9']}")
    t = u(one(cls, "putp", b(""), b("a.pdf|1"), "3", "2.5")); check(t == "3\ta.pdf|1\t250\n", f"(B3) định dạng ghi: {t!r}")
    t2 = u(one(cls, "putp", b(t), b("a.pdf|1"), "3", "1.0")); check(t2 == "3\ta.pdf|1\n", f"(B3) putPlace với 1x xoá mức phóng đã lưu: {t2!r}")
    t3 = u(one(cls, "put", b(t), b("a.pdf|1"), "9")); check(t3 == "9\ta.pdf|1\t250\n", f"(B4) put (chỉ trang) GIỮ mức phóng đã lưu: {t3!r}")
    t4 = u(one(cls, "putp", b(""), b("x\ty\nz|2"), "1", "2.0")); check(t4 == "1\tx y z|2\t200\n" and one(cls, "getp", b(t4), b("x\ty\nz|2")) == "1 2.0", f"(B5) khoá có TAB / xuống dòng được làm sạch, đọc lại bằng khoá gốc: {t4!r}")
    check(u(one(cls, "key", b("a\tb.pdf"), "123")) == "a b.pdf|123", "(B5) key(): TAB trong tên -> khoảng trắng")
    rt = u(one(cls, "putp", b(t4), b("k2|9"), "7", "3.1")); dec = u(one(cls, "dec", b(rt)))
    check(dec == "1\tx y z|2\n7\tk2|9\n" and one(cls, "getp", b(rt), b("k2|9")) == "7 3.1", f"(B6) bản ghi vòng tròn: decode liệt kê đúng trang, theo thứ tự cũ -> mới: {dec!r}")
    check([one(cls, "nz", x) for x in ("1.0", "1.05", "1.06", "2.0", "4.0", "9.0", "NaN", "0.0", "-2.0")] == ["1.0", "1.0", "1.06", "2.0", "4.0", "4.0", "1.0", "1.0", "1.0"], "(B7) normalizeZoom: 1, 1,05, 1,06, 2, 4, 9, NaN, 0, -2")

MUTANTS = [
    (1, "val z = normalizeZoom(it.value.zoom)\n        it.value.page.toString() + \"\\t\" + it.key + (if (z > 1f)", "val z = normalizeZoom(it.value.zoom)\n        it.value.page.toString() + \"\\t\" + it.key + (if (false)"),
    (2, "return store(map, k, Place(page.coerceAtLeast(0), map[k]?.zoom ?: 1f))", "return store(map, k, Place(page.coerceAtLeast(0), 1f))"),
    (3, "while (map.size > MAX_ENTRIES) map.remove(map.keys.first())", "while (map.size > MAX_ENTRIES) map.remove(map.keys.last())"),
    (4, "return Math.round(minOf(zoom, ZoomMath.MAX_ZOOM) * 100f) / 100f", "return Math.round(zoom * 100f) / 100f"),
]

def main():
    args = sys.argv[1:]; fast = "--fast" in args; only = [int(a.split("=")[1]) for a in args if a.startswith("--mutant=")]
    if not only:
        cls = build(); group_fixed(cls); group_random(cls)
    if not fast:
        print("== THỬ ÂM TÍNH: mỗi bản mã bị làm hỏng PHẢI bị bắt")
        import io, contextlib
        for n, old, new in MUTANTS:
            if only and n not in only: continue
            before = len(fails); cls = build({"PdfReadingPositions.kt": (old, new)}, f"m{n}"); buf = io.StringIO()
            with contextlib.redirect_stdout(buf): group_fixed(cls); group_random(cls)
            caught = [l for l in buf.getvalue().splitlines() if l.startswith("LOI")]; del fails[before:]
            check(len(caught) > 0, f"bản hỏng {n} ({new.strip()[:60]!r}) bị bắt bởi {len(caught)} phép kiểm")
    print("\nTAT CA DAT" if not fails else f"\n{len(fails)} LOI: " + "; ".join(fails[:4])); sys.exit(1 if fails else 0)

main()
