import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.security.cert.*;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.*;
import javax.crypto.*;
import javax.crypto.spec.*;

/**
 * Java twin of app/.../util/Pkcs12Modern.kt (phiên 22, 4.49.8): same structure, same order of operations. Uses NO KeyStore at all (the JDK's PKCS12 reader
 * refuses non-ASCII passwords), so it can be tested against files made by OpenSSL and `cryptography` with accented, Cyrillic and Chinese passwords.
 *   java Pkcs12ModernCheck.java <file.p12> <passwordHexUtf8> <outPrefix>  ->  "OK <chainLength>" (+ <outPrefix>.pk8 and <outPrefix>.<i>.der) or "ERR <FAILURE>"
 */
public class Pkcs12ModernCheck {
    static class Fail extends Exception { final String f; Fail(String f) { super(f); this.f = f; } }
    static class Hash { final String digest, hmac; final int block, out; Hash(String d, String h, int b, int o) { digest = d; hmac = h; block = b; out = o; } }
    static final Map<String, Hash> HASHES = new HashMap<>();
    static final Map<String, String> PRFS = new HashMap<>();
    static final Map<String, Integer> AES = new HashMap<>();
    static {
        HASHES.put("1.3.14.3.2.26", new Hash("SHA-1", "HmacSHA1", 64, 20)); HASHES.put("2.16.840.1.101.3.4.2.4", new Hash("SHA-224", "HmacSHA224", 64, 28));
        HASHES.put("2.16.840.1.101.3.4.2.1", new Hash("SHA-256", "HmacSHA256", 64, 32)); HASHES.put("2.16.840.1.101.3.4.2.2", new Hash("SHA-384", "HmacSHA384", 128, 48));
        HASHES.put("2.16.840.1.101.3.4.2.3", new Hash("SHA-512", "HmacSHA512", 128, 64));
        PRFS.put("1.2.840.113549.2.7", "HmacSHA1"); PRFS.put("1.2.840.113549.2.8", "HmacSHA224"); PRFS.put("1.2.840.113549.2.9", "HmacSHA256");
        PRFS.put("1.2.840.113549.2.10", "HmacSHA384"); PRFS.put("1.2.840.113549.2.11", "HmacSHA512");
        AES.put("2.16.840.1.101.3.4.1.2", 16); AES.put("2.16.840.1.101.3.4.1.22", 24); AES.put("2.16.840.1.101.3.4.1.42", 32);
    }
    static final String OID_DATA = "1.2.840.113549.1.7.1", OID_ENCRYPTED_DATA = "1.2.840.113549.1.7.6", OID_KEY_BAG = "1.2.840.113549.1.12.10.1.1", OID_SHROUDED = "1.2.840.113549.1.12.10.1.2",
        OID_CERT_BAG = "1.2.840.113549.1.12.10.1.3", OID_PBES2 = "1.2.840.113549.1.5.13", OID_PBKDF2 = "1.2.840.113549.1.5.12", OID_PBE_3DES = "1.2.840.113549.1.12.1.3",
        OID_RSA = "1.2.840.113549.1.1.1", OID_EC = "1.2.840.10045.2.1";

    static class Node {
        final byte[] data; final int tag, start, cs, end;
        Node(byte[] d, int t, int s, int c, int e) { data = d; tag = t; start = s; cs = c; end = e; }
        byte[] content() { return Arrays.copyOfRange(data, cs, end); }
        List<Node> children() throws Fail { List<Node> o = new ArrayList<>(); int p = cs; while (p < end) { Node n = read(data, p, end); o.add(n); p = n.end; } return o; }
    }
    static Node read(byte[] d, int at, int limit) throws Fail {
        if (at + 2 > limit) throw new Fail("MALFORMED");
        int p = at; int tag = d[p++] & 0xFF;
        if ((tag & 0x1F) == 0x1F) throw new Fail("MALFORMED");
        int len = d[p++] & 0xFF;
        if ((len & 0x80) != 0) { int n = len & 0x7F; if (n == 0 || n > 4 || p + n > limit) throw new Fail("MALFORMED"); len = 0; for (int i = 0; i < n; i++) len = (len << 8) | (d[p++] & 0xFF); if (len < 0) throw new Fail("MALFORMED"); }
        if (p + len > limit) throw new Fail("MALFORMED");
        return new Node(d, tag, at, p, p + len);
    }
    static String oid(Node n) throws Fail {
        if (n.tag != 0x06 || n.end <= n.cs) throw new Fail("MALFORMED");
        StringBuilder sb = new StringBuilder(); long value = 0; boolean first = true;
        for (int i = n.cs; i < n.end; i++) {
            int b = n.data[i] & 0xFF; value = (value << 7) | (b & 0x7F);
            if ((b & 0x80) == 0) { if (first) { int a = value < 80 ? (int) (value / 40) : 2; sb.append(a).append('.').append(value - 40L * a); first = false; } else sb.append('.').append(value); value = 0; }
        }
        return sb.toString();
    }
    static int intOf(Node n) { int v = 0; for (int i = n.cs; i < n.end; i++) v = (v << 8) | (n.data[i] & 0xFF); return v; }

    static byte[] bmp(char[] pw) { byte[] o = new byte[pw.length * 2 + 2]; for (int i = 0; i < pw.length; i++) { o[2 * i] = (byte) (pw[i] >> 8); o[2 * i + 1] = (byte) pw[i]; } return o; }
    static byte[] utf8(char[] pw) { return new String(pw).getBytes(StandardCharsets.UTF_8); }
    static byte[] fill(byte[] src, int v) { if (src.length == 0) return new byte[0]; byte[] o = new byte[v * ((src.length + v - 1) / v)]; for (int i = 0; i < o.length; i++) o[i] = src[i % src.length]; return o; }

    static byte[] kdf(Hash h, int id, byte[] password, byte[] salt, int iterations, int length) throws Exception {
        int v = h.block, u = h.out; byte[] d = new byte[v]; Arrays.fill(d, (byte) id);
        byte[] s = fill(salt, v), p = fill(password, v); byte[] inp = new byte[s.length + p.length]; System.arraycopy(s, 0, inp, 0, s.length); System.arraycopy(p, 0, inp, s.length, p.length);
        MessageDigest md = MessageDigest.getInstance(h.digest); byte[] out = new byte[length]; int produced = 0;
        while (produced < length) {
            md.update(d); md.update(inp); byte[] a = md.digest(); for (int k = 1; k < iterations; k++) a = md.digest(a);
            int n = Math.min(u, length - produced); System.arraycopy(a, 0, out, produced, n); produced += n; if (produced >= length) break;
            byte[] b = new byte[v]; for (int i = 0; i < v; i++) b[i] = a[i % u];
            for (int j = 0; j < inp.length; j += v) { int carry = 1; for (int k = v - 1; k >= 0; k--) { int sum = (inp[j + k] & 0xFF) + (b[k] & 0xFF) + carry; inp[j + k] = (byte) sum; carry = sum >> 8; } }
        }
        return out;
    }
    static byte[] pbkdf2(String hmac, byte[] password, byte[] salt, int iterations, int length) throws Exception {
        Mac mac = Mac.getInstance(hmac); mac.init(new SecretKeySpec(password.length == 0 ? new byte[1] : password, hmac)); int hLen = mac.getMacLength(); byte[] out = new byte[length];
        for (int block = 1; block <= (length + hLen - 1) / hLen; block++) {
            mac.update(salt); mac.update(new byte[]{(byte) (block >>> 24), (byte) (block >>> 16), (byte) (block >>> 8), (byte) block});
            byte[] u = mac.doFinal(); byte[] t = u.clone();
            for (int j = 2; j <= iterations; j++) { u = mac.doFinal(u); for (int k = 0; k < t.length; k++) t[k] ^= u[k]; }
            System.arraycopy(t, 0, out, (block - 1) * hLen, Math.min(hLen, length - (block - 1) * hLen));
        }
        return out;
    }
    static byte[] decrypt(Node alg, byte[] encrypted, char[] password) throws Exception {
        List<Node> parts = alg.children(); String algOid = oid(parts.get(0));
        try {
            if (algOid.equals(OID_PBES2)) {
                List<Node> params = parts.get(1).children(); List<Node> kd = params.get(0).children();
                if (!oid(kd.get(0)).equals(OID_PBKDF2)) throw new Fail("UNSUPPORTED");
                List<Node> kp = kd.get(1).children();
                if (kp.get(0).tag != 0x04) throw new Fail("UNSUPPORTED");
                byte[] salt = kp.get(0).content(); int iterations = intOf(kp.get(1)); Integer keyLength = null; String prf = "HmacSHA1";
                for (Node extra : kp.subList(2, kp.size())) { if (extra.tag == 0x02) keyLength = intOf(extra); else if (extra.tag == 0x30) { prf = PRFS.get(oid(extra.children().get(0))); if (prf == null) throw new Fail("UNSUPPORTED"); } }
                List<Node> scheme = params.get(1).children(); Integer size = AES.get(oid(scheme.get(0))); if (size == null) throw new Fail("UNSUPPORTED");
                if (keyLength != null && keyLength != size) throw new Fail("MALFORMED");
                byte[] key = pbkdf2(prf, utf8(password), salt, iterations, size);
                Cipher c = Cipher.getInstance("AES/CBC/PKCS5Padding"); c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(scheme.get(1).content())); return c.doFinal(encrypted);
            } else if (algOid.equals(OID_PBE_3DES)) {
                List<Node> params = parts.get(1).children(); byte[] salt = params.get(0).content(); int iterations = intOf(params.get(1)); Hash sha1 = HASHES.get("1.3.14.3.2.26");
                byte[] key = kdf(sha1, 1, bmp(password), salt, iterations, 24), iv = kdf(sha1, 2, bmp(password), salt, iterations, 8);
                Cipher c = Cipher.getInstance("DESede/CBC/PKCS5Padding"); c.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "DESede"), new IvParameterSpec(iv)); return c.doFinal(encrypted);
            } else throw new Fail("UNSUPPORTED");
        } catch (Fail f) { throw f; }
        catch (BadPaddingException e) { throw new Fail("WRONG_PASSWORD"); }
        catch (IllegalBlockSizeException e) { throw new Fail("MALFORMED"); }
        catch (IndexOutOfBoundsException e) { throw new Fail("MALFORMED"); }
    }

    static Object[] parse(byte[] file, char[] password) throws Exception {
        try { return parseUnchecked(file, password); } catch (Fail f) { throw f; } catch (Exception e) { throw new Fail("MALFORMED"); }
    }
    static Object[] parseUnchecked(byte[] file, char[] password) throws Exception {
        Node pfx = read(file, 0, file.length); if (pfx.tag != 0x30) throw new Fail("MALFORMED");
        List<Node> top = pfx.children(); List<Node> authInfo = top.get(1).children();
        if (!oid(authInfo.get(0)).equals(OID_DATA)) throw new Fail("UNSUPPORTED");
        byte[] authSafe = authInfo.get(1).children().get(0).content();
        if (top.size() < 3) throw new Fail("UNSUPPORTED");
        List<Node> md = top.get(2).children(); List<Node> digestInfo = md.get(0).children();
        Hash hash = HASHES.get(oid(digestInfo.get(0).children().get(0))); if (hash == null) throw new Fail("UNSUPPORTED");
        byte[] expected = digestInfo.get(1).content(); byte[] macSalt = md.get(1).content(); int macIterations = md.size() > 2 ? intOf(md.get(2)) : 1;
        byte[] macKey = kdf(hash, 3, bmp(password), macSalt, macIterations, hash.out);
        Mac mac = Mac.getInstance(hash.hmac); mac.init(new SecretKeySpec(macKey, hash.hmac));
        if (!MessageDigest.isEqual(mac.doFinal(authSafe), expected)) throw new Fail("WRONG_PASSWORD");
        List<X509Certificate> certs = new ArrayList<>(); byte[] keyBytes = null; CertificateFactory factory = CertificateFactory.getInstance("X.509");
        for (Node info : read(authSafe, 0, authSafe.length).children()) {
            String kind = oid(info.children().get(0)); Node body = info.children().get(1).children().get(0); byte[] safeContents;
            if (kind.equals(OID_DATA)) safeContents = body.content();
            else if (kind.equals(OID_ENCRYPTED_DATA)) {
                List<Node> eci = body.children().get(1).children(); Node e = eci.get(2); if (e.tag != 0xA0 && e.tag != 0x80) throw new Fail("MALFORMED");
                safeContents = decrypt(eci.get(1), e.content(), password);
            } else throw new Fail("UNSUPPORTED");
            for (Node bag : read(safeContents, 0, safeContents.length).children()) {
                List<Node> parts = bag.children(); Node value = parts.get(1).children().get(0); String id = oid(parts.get(0));
                if (id.equals(OID_CERT_BAG)) certs.add((X509Certificate) factory.generateCertificate(new ByteArrayInputStream(value.children().get(1).children().get(0).content())));
                else if (id.equals(OID_SHROUDED)) { List<Node> epki = value.children(); if (keyBytes == null) keyBytes = decrypt(epki.get(0), epki.get(1).content(), password); }
                else if (id.equals(OID_KEY_BAG)) { if (keyBytes == null) keyBytes = Arrays.copyOfRange(value.data, value.start, value.end); }
            }
        }
        if (keyBytes == null) throw new Fail("MALFORMED");
        String ko = oid(read(keyBytes, 0, keyBytes.length).children().get(1).children().get(0)); String ka;
        if (ko.equals(OID_RSA)) ka = "RSA"; else if (ko.equals(OID_EC)) ka = "EC"; else throw new Fail("UNSUPPORTED");
        PrivateKey key = KeyFactory.getInstance(ka).generatePrivate(new PKCS8EncodedKeySpec(keyBytes));
        if (certs.isEmpty()) throw new Fail("MALFORMED");
        return new Object[]{key, orderChain(key, certs)};
    }
    static List<X509Certificate> orderChain(PrivateKey key, List<X509Certificate> certs) throws Exception {
        String alg = key.getAlgorithm().equalsIgnoreCase("EC") ? "SHA256withECDSA" : "SHA256withRSA"; byte[] probe = {1, 2, 3, 4, 5, 6, 7, 8};
        Signature s = Signature.getInstance(alg); s.initSign(key); s.update(probe); byte[] sig = s.sign(); X509Certificate leaf = null;
        for (X509Certificate c : certs) { try { Signature v = Signature.getInstance(alg); v.initVerify(c.getPublicKey()); v.update(probe); if (v.verify(sig)) { leaf = c; break; } } catch (Exception e) { } }
        if (leaf == null) leaf = certs.get(0);
        List<X509Certificate> chain = new ArrayList<>(); chain.add(leaf); List<X509Certificate> rest = new ArrayList<>(certs); rest.remove(leaf);
        while (true) {
            X509Certificate last = chain.get(chain.size() - 1); if (last.getSubjectX500Principal().equals(last.getIssuerX500Principal())) break;
            X509Certificate issuer = null; for (X509Certificate c : rest) if (c.getSubjectX500Principal().equals(last.getIssuerX500Principal())) { issuer = c; break; }
            if (issuer == null) break; chain.add(issuer); rest.remove(issuer);
        }
        return chain;
    }

    public static void main(String[] a) throws Exception {
        byte[] file = Files.readAllBytes(Paths.get(a[0])); byte[] pb = new byte[a[1].length() / 2]; for (int i = 0; i < pb.length; i++) pb[i] = (byte) Integer.parseInt(a[1].substring(2 * i, 2 * i + 2), 16);
        try {
            Object[] r = parse(file, new String(pb, StandardCharsets.UTF_8).toCharArray());
            Files.write(Paths.get(a[2] + ".pk8"), ((PrivateKey) r[0]).getEncoded()); @SuppressWarnings("unchecked") List<X509Certificate> chain = (List<X509Certificate>) r[1];
            for (int i = 0; i < chain.size(); i++) Files.write(Paths.get(a[2] + "." + i + ".der"), chain.get(i).getEncoded());
            System.out.println("OK " + chain.size());
        } catch (Fail f) { System.out.println("ERR " + f.f); }
    }
}
