"""Đa ngôn ngữ (phiên 18): sinh và kiểm các bản dịch giao diện.

KIẾN TRÚC (theo tài liệu Android: ngôn ngữ máy có trong app -> dùng đúng ngôn ngữ đó; KHÔNG có -> rơi về thư mục tài nguyên MẶC ĐỊNH):
  - res/values/strings.xml            = TIẾNG ANH, thư mục MẶC ĐỊNH => máy dùng ngôn ngữ app không có (Pháp, Đức...) sẽ thấy tiếng Anh;
  - res/values-<mã>/strings.xml       = từng ngôn ngữ khác (vi, ja, ...): máy dùng ngôn ngữ đó tự thấy đúng ngôn ngữ đó;
  - res/xml/locales_config.xml        = danh sách ngôn ngữ cho Cài đặt hệ thống (Android 13+ chọn ngôn ngữ riêng cho app);
  - res/values/languages.xml          = hai mảng (mã, tên bản ngữ) cho bộ chọn ngôn ngữ trong app.
Nguồn: tools/i18n/languages.txt (`mã | thư mục | tên bản ngữ`, dòng đầu PHẢI là en | values) và tools/i18n/<mã>_strings.txt (mỗi dòng `tên ||| nội dung`, mảng là
`@array tên ||| mục ||| mục`). Thứ tự và tập khoá lấy từ bản tiếng Anh. THÊM MỘT NGÔN NGỮ: viết tools/i18n/<mã>_strings.txt, thêm một dòng vào languages.txt, chạy --write.
  python3 i18n_check.py --write   sinh lại mọi tệp (thoát & < > và dấu nháy đơn cho aapt)
  python3 i18n_check.py           KIỂM, với MỌI ngôn ngữ:
    (1) tập khoá = tập khoá tiếng Anh (thiếu / thừa), mảng cùng số phần tử, không chuỗi rỗng;
    (2) dấu thay thế (%1$s, %d, %%, {n}, {N}, {b}, {name}, {date}) giữ nguyên số lượng ở MỌI chuỗi; số \\n khớp; mọi dấu nháy kép đều có thoát \\" (aapt từ chối dấu trần; ngôn ngữ dùng ngoặc riêng như 「」 vẫn hợp lệ);
    (3) không lẫn chữ có dấu tiếng Việt vào ngôn ngữ khác tiếng Việt; chuỗi giống hệt tiếng Anh chỉ được là tên riêng / ký hiệu đã liệt kê;
    (4) mọi tệp sinh ra khớp bản sinh lại (không lệch); thư mục values-* trên đĩa = đúng danh sách ngôn ngữ (không sót thư mục cũ như values-en);
    (5) locales_config.xml và hai mảng ngôn ngữ khớp languages.txt; XML hợp lệ; dấu nháy đơn đã thoát.
GIỚI HẠN (nói thẳng): kiểm được tính ĐẦY ĐỦ và ĐÚNG KHUÔN, KHÔNG kiểm được chất lượng văn phong - bản dịch do mô hình ngôn ngữ viết, cần người bản ngữ đọc lại trước khi phát hành.
"""
import os, re, sys
from collections import Counter
from lxml import etree
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.join(HERE, "..", "..")
RES = os.path.join(ROOT, "app", "src", "main", "res"); I18N = os.path.join(ROOT, "tools", "i18n")
VIET = re.compile("[àáảãạăằắẳẵặâầấẩẫậèéẻẽẹêềếểễệìíỉĩịòóỏõọôồốổỗộơờớởỡợùúủũụưừứửữựỳýỷỹỵđÀÁẢÃẠĂẰẮẲẴẶÂẦẤẨẪẬÈÉẺẼẸÊỀẾỂỄỆÌÍỈĨỊÒÓỎÕỌÔỒỐỔỖỘƠỜỚỞỠỢÙÚỦŨỤƯỪỨỬỮỰỲÝỶỸỴĐ]")
TOKEN = re.compile(r"%(?:\d+\$)?[sdfx%]|\{[A-Za-z]+\}")
# chuỗi được phép GIỐNG HỆT tiếng Anh trong mọi ngôn ngữ: tên định dạng, khổ giấy, ký hiệu, tên riêng (nêu đích danh từng khoá, không đoán theo hình dạng)
ALLOW_SAME = {"ebook_format_epub", "ebook_format_fb2", "convert_source_pdf", "convert_source_epub", "convert_target_pdf", "convert_target_epub", "convert_target_fb2", "convert_target_ebook_group",
              "toc_entry_minus", "toc_entry_plus", "paper_a4", "paper_a5", "paper_a3", "paper_letter", "paper_legal", "textexport_md", "link_url_hint", "webhook_link", "cleanup_biggest_line", "cleanup_cat_pdf", "cleanup_cat_epub",
              "cleanup_cat_office", "attachments_item", "history_action_portfolio", "suffix_portfolio", "portfolio_title", "app_name", "dialog_ok", "dialog_yes"}
# ngoại lệ riêng từng ngôn ngữ (từ vay mượn y nguyên là đúng): {mã: {khoá, ...}}
ALLOW_SAME_LANG = {"vi": {"card_field_email", "card_field_web", "redact_kind_email"},
                   # cognatos / ký hiệu y hệt tiếng Anh là ĐÚNG trong ngôn ngữ đó (không phải chưa dịch): "p. %1$s", "Color", "Wi-Fi: %1$s", tên định dạng
                   "es": {"bm_page", "convert_source_markup", "markup_color_label", "markup_color_title", "qr_wifi_caption", "wifi_color", "wifi_color_rgb"},
                   "pt-BR": {"qr_wifi_caption", "autobackup_keep_n", "bm_page", "convert_slide_n", "convert_source_markup", "history_action_links"},
                   "fr": {"text_size_1", "lock_delay_1m", "lock_delay_5m", "lock_delay_15m", "lock_delay_30m", "annotate_page_indicator", "barcode_kind_sms", "cleanup_cat_image", "convert_source_images", "convert_source_markup", "convert_target_images", "epub_meta_description", "export_page_name", "stamp_urgent"},
                   "de": {"text_size_1", "annotate_tool_text", "barcode_kind_text", "card_field_name", "cleanup_cat_text", "convert_source_markup", "convert_source_txt", "convert_target_txt", "ebook_format_txt", "history_action_links", "history_sort_name", "tag_button", "tag_button_filtered"},
                   "hi": {"convert_source_markup"},
                   "ru": {"convert_source_markup", "qr_wifi_caption"},
                   "ko": {"convert_source_markup", "qr_wifi_caption"},
                   "zh-CN": {"convert_source_markup", "qr_wifi_caption"},
                   "id": {"autobackup_folder", "barcode_kind_email", "card_field_email", "convert_slide_n", "convert_source_markup", "qr_wifi_caption", "redact_kind_email", "tag_button_filtered"}}
# Chữ CHỈ có trong tiếng Việt (ă ơ ư đ ĩ ũ và khối Latin mở rộng U+1EA0-1EF9): các ngôn ngữ Latin khác (es, pt, fr, de...) dùng á é í ó ú â ê ô ã õ ç ñ hợp lệ
VIET_ONLY = re.compile("[ăĂơƠưƯđĐĩĨũŨ\u1ea0-\u1ef9]")
def languages():
    out = []
    for line in open(os.path.join(I18N, "languages.txt"), encoding="utf-8"):
        if line.strip(): tag, folder, name = [x.strip() for x in line.split("|")]; out.append((tag, folder, name))
    assert out[0][:2] == ("en", "values"), "dòng đầu languages.txt phải là: en | values | English"
    return out
def load(tag):
    s, arrays = {}, {}
    path = os.path.join(I18N, f"{tag}_strings.txt")
    for ln, line in enumerate(open(path, encoding="utf-8"), 1):
        line = line.rstrip("\n")
        if not line.strip(): continue
        parts = line.split(" ||| ")
        if parts[0].startswith("@array "): arrays[parts[0][7:].strip()] = parts[1:]
        else:
            if len(parts) != 2: raise SystemExit(f"{path}:{ln}: dòng không có đúng một ' ||| ': {line[:60]}")
            if parts[0] in s: raise SystemExit(f"{path}:{ln}: trùng khoá {parts[0]}")
            s[parts[0]] = parts[1]
    return s, arrays
def android_escape(t):
    t = t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return re.sub(r"(?<!\\)'", r"\\'", t)
def gen_strings(tag):
    master_s, master_a = load("en"); s, arrays = load(tag)
    lines = ['<?xml version="1.0" encoding="utf-8"?>', f"<!-- GENERATED by tools/verify/i18n_check.py (write mode) from tools/i18n/{tag}_strings.txt. Do not edit by hand. -->", "<resources>"]
    for name in master_s:
        if name not in s: raise SystemExit(f"[{tag}] thiếu bản dịch: {name}")
        lines.append(f'    <string name="{name}">{android_escape(s[name])}</string>')
    for name in master_a:
        if name not in arrays: raise SystemExit(f"[{tag}] thiếu mảng: {name}")
        lines.append(f'    <string-array name="{name}">'); lines += [f"        <item>{android_escape(i)}</item>" for i in arrays[name]]; lines.append("    </string-array>")
    lines.append("</resources>"); return "\n".join(lines) + "\n"
def gen_locales(langs):
    return ('<?xml version="1.0" encoding="utf-8"?>\n<!-- GENERATED by tools/verify/i18n_check.py (write mode) from tools/i18n/languages.txt. Do not edit by hand. Android 13+ lists these in system Settings -> App languages. -->\n'
            '<locale-config xmlns:android="http://schemas.android.com/apk/res/android">\n' + "".join(f'    <locale android:name="{t}" />\n' for t, _, _ in langs) + "</locale-config>\n")
def gen_languages_xml(langs):
    return ('<?xml version="1.0" encoding="utf-8"?>\n<!-- GENERATED by tools/verify/i18n_check.py (write mode) from tools/i18n/languages.txt. Do not edit by hand. Native names are NOT translated. -->\n<resources>\n'
            '    <string-array name="app_language_tags" translatable="false">\n' + "".join(f"        <item>{t}</item>\n" for t, _, _ in langs) + "    </string-array>\n"
            '    <string-array name="app_language_names" translatable="false">\n' + "".join(f"        <item>{android_escape(n)}</item>\n" for _, _, n in langs) + "    </string-array>\n</resources>\n")
def outputs(langs):
    out = {os.path.join(RES, f, "strings.xml"): gen_strings(t) for t, f, _ in langs}
    out[os.path.join(RES, "xml", "locales_config.xml")] = gen_locales(langs); out[os.path.join(RES, "values", "languages.xml")] = gen_languages_xml(langs); return out
if "--write" in sys.argv:
    for p, text in outputs(languages()).items():
        os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w", encoding="utf-8").write(text); print("đã ghi", os.path.relpath(p, ROOT))
    sys.exit(0)
FAILS = []
def check(c, w):
    print(("ok  " if c else "LOI"), w)
    if not c: FAILS.append(w)
langs = languages(); master_s, master_a = load("en")
check(len(langs) >= 2 and len({t for t, _, _ in langs}) == len(langs), f"{len(langs)} ngôn ngữ: {', '.join(t for t, _, _ in langs)} (en là mặc định)")
for tag, folder, name in langs:
    s, arrays = load(tag)
    if tag == "en":
        check(not [v for v in list(s.values()) + [i for a in arrays.values() for i in a] if VIET.search(v)], "[en] bản gốc không lẫn chữ có dấu tiếng Việt"); continue
    check(set(s) == set(master_s) and set(arrays) == set(master_a) and all(len(arrays[n]) == len(master_a[n]) for n in master_a if n in arrays),
          f"[{tag}] tập khoá bằng tiếng Anh ({len(master_s)} chuỗi + {len(master_a)} mảng)" + ("" if set(s) == set(master_s) else f" | thiếu {sorted(set(master_s)-set(s))[:4]} thừa {sorted(set(s)-set(master_s))[:4]}"))
    bt, be = [], []
    for n, v in master_s.items():
        if n not in s: continue
        if Counter(TOKEN.findall(v)) != Counter(TOKEN.findall(s[n])): bt.append((n, TOKEN.findall(v), TOKEN.findall(s[n])))
        if v.count("\\n") != s[n].count("\\n") or re.search(r'(?<!\\)"', s[n]): be.append(n)
    for n, v in master_a.items():
        for a, b in zip(v, arrays.get(n, [])):
            if Counter(TOKEN.findall(a)) != Counter(TOKEN.findall(b)): bt.append((n, a, b))
    check(not bt and not be, f"[{tag}] dấu thay thế (%1$s, %d, {{n}}...) giữ nguyên; \\n khớp; dấu nháy kép đã thoát: {bt[:2]} {be[:3]}")
    allv = list(s.values()) + [i for a in arrays.values() for i in a]
    check(all(t.strip() for t in allv), f"[{tag}] không chuỗi rỗng")
    lead = lambda t: t[:len(t) - len(t.lstrip())]; trail = lambda t: t[len(t.rstrip()):]
    sp = [n for n, v in master_s.items() if n in s and (lead(v) != lead(s[n]) or trail(v) != trail(s[n]))]
    check(not sp, f"[{tag}] dấu cách đầu/cuối chuỗi khớp bản Anh (hậu tố tên tệp ' (x)'...): {sp[:4]}")
    if tag != "vi":
        pat = VIET if tag in ("en", "ja") else VIET_ONLY   # en / ja không được có BẤT KỲ chữ có dấu Việt nào; ngôn ngữ Latin khác chỉ cần không có chữ CHỈ của tiếng Việt
        check(not [t for t in allv if pat.search(t)], f"[{tag}] không lẫn chữ có dấu tiếng Việt: {[t[:30] for t in allv if pat.search(t)][:2]}")
    same = {n for n, v in master_s.items() if n in s and s[n] == v}; ok = ALLOW_SAME | ALLOW_SAME_LANG.get(tag, set())
    check(same <= ok, f"[{tag}] chuỗi giống hệt tiếng Anh đều là tên riêng / ký hiệu đã liệt kê ({len(same)} chuỗi); chưa dịch: {sorted(same - ok)[:6]}")
outs = outputs(langs)
for p, text in outs.items():
    try: etree.fromstring(text.encode("utf-8")); xml_ok = True
    except Exception: xml_ok = False
    exists = os.path.exists(p); same_file = exists and open(p, encoding="utf-8").read() == text
    check(xml_ok and same_file, f"{os.path.relpath(p, ROOT)}: hợp lệ XML và khớp bản sinh lại" + ("" if exists else " (CHƯA CÓ - chạy --write)"))
    if p.endswith("strings.xml"): check(not re.search(r"(?<!\\)'", re.sub(r"<!--.*?-->|<[^>]*>", "", text, flags=re.S)), f"{os.path.relpath(p, ROOT)}: mọi dấu nháy đơn đã thoát")
on_disk = sorted(d for d in os.listdir(RES) if d.startswith("values") and os.path.isdir(os.path.join(RES, d)) and os.path.exists(os.path.join(RES, d, "strings.xml")))
check(on_disk == sorted(f for _, f, _ in langs), f"thư mục values* có strings.xml trên đĩa = đúng danh sách ngôn ngữ (không sót values-en cũ): {on_disk}")
print("\nTAT CA DAT" if not FAILS else f"\n{len(FAILS)} LOI"); sys.exit(1 if FAILS else 0)
