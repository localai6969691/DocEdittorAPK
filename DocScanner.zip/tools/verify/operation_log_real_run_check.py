#!/usr/bin/env python3
"""Nhật ký thao tác có chuỗi băm CHẠY THẬT (`util/OperationLog.kt`; phiên 25, TECHNICAL_DOCS.md 4.73; mục 7.6 "audit trail" của PDF).

Mã Kotlin THẬT dựng chuỗi, và bản dựng đó phải GIỐNG TỪNG BYTE bản dựng độc lập viết bằng Python (hashlib.sha256 + cách thoát ký tự viết lại từ đầu theo đặc tả trong chú thích của lớp):
tệp có thể đọc / kiểm bằng công cụ ngoài, không phụ thuộc mã. Rồi kiểm chứng bằng tay những cách làm hỏng nhật ký: sửa nội dung một dòng; sửa rồi tính lại băm của chính dòng đó; xoá dòng giữa;
đổi chỗ hai dòng; chèn dòng giả; dòng rác; dòng đầu có băm trước khác GENESIS. Và NÊU RÕ cái nó KHÔNG làm được (không có khoá bí mật): cắt bớt ĐUÔI vẫn hợp lệ; viết lại TOÀN BỘ rồi tính lại mọi băm
cũng hợp lệ, chỉ lộ ra ở chỗ băm cuối (head) khác với băm người dùng đã ghi lại.
KHÔNG kiểm được: ghi / đọc tệp trên máy (Context), danh sách tệp thư viện thật, màn hình xem nhật ký. Chạy: python3 tools/verify/operation_log_real_run_check.py"""
import hashlib, os, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, os.path.join(HERE, "real_run"))
import toolchain  # noqa: E402

fails = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: fails.append(msg)

tc = toolchain.get(); WORK = tempfile.mkdtemp(prefix="oplog-")
HARNESS = os.path.join(HERE, "real_run", "OperationLogHarness.kt")
cls = tc.compile(["OperationLog.kt"], [HARNESS], os.path.join(WORK, "cls"), None, None)[0]
def run(cmd, lines):
    r = tc.run(cls, "OperationLogHarnessKt", [cmd], stdin="\n".join(lines) + "\n")
    if r.returncode: raise SystemExit("harness crashed: " + r.stderr[-1200:])
    out = r.stdout.split("\n")   # NOT splitlines(): Python also cuts at U+2028 and friends, which the log keeps as they are
    return out[:-1] if out and out[-1] == "" else out

# ---- an INDEPENDENT implementation, from the written format only ----
GENESIS = "0" * 64
def esc(s): return s.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", "\\r")
def h(prev, seq, time, action, detail):
    a, d = action.encode(), detail.encode()
    text = f"{prev}\n{seq}\n{time}\n{len(a)}:{action}\n{len(d)}:{detail}"
    return hashlib.sha256(text.encode()).hexdigest()
def build(events):
    out, prev = [], GENESIS
    for i, (t, a, d) in enumerate(events, 1):
        hh = h(prev, i, t, a, d); out.append("\t".join([str(i), str(t), esc(a), esc(d), prev, hh])); prev = hh
    return out
def rewrite_line(line, detail=None, recompute=False):
    f = line.split("\t")
    if detail is not None: f[3] = detail
    if recompute: f[5] = h(f[4], int(f[0]), int(f[1]), f[2], f[3])
    return "\t".join(f)
def hx(s): return s.encode().hex()
EVENTS = [(1700000000000 + i * 1000, a, d) for i, (a, d) in enumerate([("baseline", "12"), ("created", "scan_001.pdf"), ("created", "báo cáo tháng 11.pdf"), ("shared", "scan_001.pdf"), ("removed", "old.docx"), ("created", "hợp đồng 😀.pdf")])]
LOG = build(EVENTS)
def kotlin_build(events): return run("build", [f"{t}\t{hx(a)}\t{hx(d)}" for t, a, d in events])
def verify(lines):
    s = run("verify", lines)[0].split(); return s[0], int(s[1]), int(s[2]), s[3]

print("== A. dựng chuỗi: giống từng byte bản Python độc lập")
check(kotlin_build(EVENTS) == LOG, "6 dòng (chữ Việt, emoji) giống bản Python" + ("" if kotlin_build(EVENTS) == LOG else f"\n  {kotlin_build(EVENTS)[:2]}\n  {LOG[:2]}"))
NASTY = [(1, "a\tb", "tab\there, new\nline, cr\rhere, back\\slash, \\n literal, unicode ệ ơ 日本 😀 \u2028"), (2, "x", ""), (3, "y", "\\")]
check(kotlin_build(NASTY) == build(NASTY), "ký tự đặc biệt (tab, xuống dòng, \\, \\n chữ, Unicode, dòng trống) thoát đúng như bản Python")
rt = run("roundtrip", build(NASTY))
check(rt[0::2] == build(NASTY) and bytes.fromhex(rt[1]).decode() == NASTY[0][2] and rt[3] == "" and bytes.fromhex(rt[5]).decode() == "\\", "đọc lại rồi ghi lại giữ nguyên từng dòng và nội dung gốc (kể cả chuỗi rỗng và dấu \\)")
check(run("roundtrip", ["not a log line", "1\t2\ta\tb\tzz\tzz", "1\t2\ta\tb\\q\t" + GENESIS + "\t" + GENESIS])[0::2] == ["NULL", "NULL", "NULL"], "dòng rác / băm không phải 64 chữ số hex / thoát sai bị từ chối")

print("== B. nguyên vẹn")
st, n, bad, head = verify(LOG)
check(st == "OK" and n == 6 and bad == -1 and head == h(*(lambda p: p)((LOG[-2].split("\t")[5], 6, EVENTS[5][0], EVENTS[5][1], EVENTS[5][2]))), f"chuỗi nguyên vẹn: OK 6 mục, băm cuối đúng bản Python ({st} {n})")
check(verify([])[0] == "EMPTY", "nhật ký trống -> EMPTY")

print("== C. làm hỏng: PHẢI bị phát hiện, và chỉ ra ĐÚNG mục đầu tiên không khớp")
check(verify(LOG[:2] + [rewrite_line(LOG[2], detail="khong phai ten that")] + LOG[3:])[:3] == ("BROKEN", 2, 3), "sửa nội dung mục 3: hỏng ở mục 3")
check(verify(LOG[:2] + [rewrite_line(LOG[2], detail="khong phai ten that", recompute=True)] + LOG[3:])[:3] == ("BROKEN", 3, 4), "sửa mục 3 rồi tính lại băm của riêng nó: mục 4 không còn nối được, hỏng ở mục 4")
check(verify(LOG[:2] + LOG[3:])[:3] == ("BROKEN", 2, 4), "xoá mục 3 ở giữa: hỏng ở mục 4")
check(verify([LOG[0], LOG[2], LOG[1]] + LOG[3:])[:3] == ("BROKEN", 1, 3), "đổi chỗ mục 2 và 3: hỏng ở mục 3")
def fixed_up_deletion():
    """entry 3 removed AND every later hash recomputed so the hashes chain again; only the numbers (1, 2, 4, 5, 6) still show the gap"""
    out, prev = LOG[:2], LOG[1].split("\t")[5]
    for line in LOG[3:]:
        f = line.split("\t"); f[4] = prev; f[5] = h(prev, int(f[0]), int(f[1]), f[2], f[3]); out.append("\t".join(f)); prev = f[5]
    return out
check(verify(fixed_up_deletion())[:3] == ("BROKEN", 2, 4), "xoá mục 3 RỒI tính lại băm các mục sau (băm nối lại được): số thứ tự 1, 2, 4 vẫn lộ chỗ hổng, hỏng ở mục 4")
forged = rewrite_line(LOG[1], detail="gia", recompute=True)
check(verify(LOG[:2] + [forged] + LOG[2:])[0] == "BROKEN", "chèn một mục giả giữa chuỗi: hỏng")
check(verify(LOG[:3] + ["hello"] + LOG[3:])[:3] == ("BROKEN", 3, -1), "chèn dòng rác: hỏng, không đọc được (-1)")
wrong_first = "\t".join(["1"] + LOG[0].split("\t")[1:4] + ["1" * 64, h("1" * 64, 1, EVENTS[0][0], EVENTS[0][1], EVENTS[0][2])])
check(verify([wrong_first] + LOG[1:])[:3] == ("BROKEN", 0, 1), "mục 1 có băm trước khác GENESIS: hỏng ở mục 1")
check(verify(LOG[:5] + [LOG[5].replace(LOG[5].split("\t")[5], "0" * 64)])[0] == "BROKEN", "sửa băm của mục cuối: hỏng")

print("== D. cái nó KHÔNG làm được (nêu rõ, vì không có khoá bí mật)")
st, n, _, head_cut = verify(LOG[:4])
check(st == "OK" and n == 4 and head_cut != head, "cắt 2 mục ở ĐUÔI: vẫn 'OK' (chuỗi ngắn hơn hợp lệ), nhưng băm cuối KHÁC băm đã ghi lại")
other = build([(t, a, "da bi sua" if i == 2 else d) for i, (t, a, d) in enumerate(EVENTS)])
st, n, _, head_rw = verify(other)
check(st == "OK" and n == 6 and head_rw != head, "viết lại TOÀN BỘ và tính lại mọi băm: vẫn 'OK', nhưng băm cuối KHÁC băm đã ghi lại")

print("== E. cắt bớt đầu (nhật ký dài): chuỗi còn lại vẫn kiểm được")
st, n, bad, _ = verify(LOG[2:])
check(st == "OK" and n == 4, "bỏ 2 mục ĐẦU (như sau khi dọn bớt): mục 3 làm điểm neo, vẫn OK 4 mục")
many = build([(1700000000000 + i, "created", f"f{i}.pdf") for i in range(2001)])
check(run("trim", many) == ["1500 502"], "2001 mục -> giữ 1500 mục MỚI NHẤT (mục 502 trở đi)")
check(run("trim", many[:2000]) == ["2000 1"], "2000 mục: giữ nguyên")
check(verify(many[-1500:])[:2] == ("OK", 1500), "1500 mục sau khi cắt vẫn kiểm được")

print("== F. thử âm tính: mã cố tình sai PHẢI bị bắt (có đối chứng: mã gốc đạt cùng phép thử)")
def probe(class_dir):
    """True when this build builds the same log as Python AND flags a deleted entry, an edited entry and a deletion whose later hashes were recomputed."""
    def runc(cmd, lines):
        out = tc.run(class_dir, "OperationLogHarnessKt", [cmd], stdin="\n".join(lines) + "\n").stdout.split("\n")
        return out[:-1] if out and out[-1] == "" else out
    built = runc("build", [f"{t}\t{hx(a)}\t{hx(d)}" for t, a, d in EVENTS]) == LOG
    deleted = runc("verify", LOG[:2] + LOG[3:])[0].startswith("BROKEN 2 4 ")
    edited = runc("verify", LOG[:2] + [rewrite_line(LOG[2], detail="x")] + LOG[3:])[0].startswith("BROKEN 2 3 ")
    fixed = runc("verify", fixed_up_deletion())[0].startswith("BROKEN 2 4 ")
    return built and deleted and edited and fixed
check(probe(cls), "đối chứng: mã gốc đạt phép thử (dựng đúng; phát hiện mục bị xoá, bị sửa, và xoá rồi tính lại băm)")
MUTANTS = (("băm không gồm băm của mục trước (không nối chuỗi)", r'val text = prev + "\n" + seq', r'val text = "" + "\n" + seq'),
           ("không kiểm số thứ tự liên tiếp", "e.seq == l.seq + 1L && e.prev == l.hash && e.hash == hashOf(e.prev, e.seq, e.time, e.action, e.detail)", "e.prev == l.hash && e.hash == hashOf(e.prev, e.seq, e.time, e.action, e.detail)"),
           ("không kiểm nội dung khớp băm", "e.seq == l.seq + 1L && e.prev == l.hash && e.hash == hashOf(e.prev, e.seq, e.time, e.action, e.detail)", "e.seq == l.seq + 1L && e.prev == l.hash"))
for name, old, new in MUTANTS:
    try:
        mdir = tc.compile(["OperationLog.kt"], [HARNESS], os.path.join(WORK, "mut"), {"OperationLog.kt": (old, new)}, None)[0]
        check(not probe(mdir), f"mã sai bị bắt: {name}")
    except RuntimeError as e:
        check(False, f"mutant không biên dịch được: {name}: {str(e)[:100]}")

print()
print("TAT CA DAT" if not fails else f"{len(fails)} LOI")
sys.exit(1 if fails else 0)
