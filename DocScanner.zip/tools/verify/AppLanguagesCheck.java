import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Ban Java chay duoc cua AppLanguages.checkedIndex (phien 18). Chay: java AppLanguagesCheck.java <tep>: moi dong "current<TAB>tag1,tag2,..." -> vi tri muc dang chon. */
public class AppLanguagesCheck {
    static int checkedIndex(List<String> tags, String current) {
        if (current.isEmpty()) return 0;
        for (int i = 0; i < tags.size(); i++) if (tags.get(i).equalsIgnoreCase(current)) return i + 1;
        String plain = stripScript(current);
        for (int i = 0; i < tags.size(); i++) if (tags.get(i).equalsIgnoreCase(plain)) return i + 1;
        int best = -1;
        for (int i = 0; i < tags.size(); i++) { String t = tags.get(i); if (plain.regionMatches(true, 0, t + "-", 0, t.length() + 1) && (best < 0 || t.length() > tags.get(best).length())) best = i; }
        return best + 1;
    }
    static String stripScript(String tag) {
        String[] parts = tag.split("-", -1); StringBuilder sb = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            boolean script = i > 0 && parts[i].length() == 4 && parts[i].chars().allMatch(Character::isLetter);
            if (!script) { if (sb.length() > 0) sb.append('-'); sb.append(parts[i]); }
        }
        return sb.toString();
    }
    public static void main(String[] a) throws Exception {
        for (String line : Files.readAllLines(Paths.get(a[0]), StandardCharsets.UTF_8)) {
            String[] p = line.split("\t", -1); System.out.println(checkedIndex(Arrays.asList(p[1].split(",")), p[0]));
        }
    }
}
