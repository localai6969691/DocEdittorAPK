#!/usr/bin/env python3
"""Kiểm chứng PdfPoster (phiên 19, mục 4.47.3): một trang phóng to ra nhiều tờ A4 để in, cắt, dán.

  1. PdfPoster.plan (bản Java PosterCheck.java, cùng công thức float) trên 4 000 cỡ trang x 5 số tờ ngang so với các TÍNH CHẤT hình học tính lại độc lập:
     số tờ = cột x hàng; bề rộng trang phóng to = đúng bề rộng phủ của các cột; số hàng là TỐI THIỂU để phủ hết chiều cao; trang nằm trọn trong vùng phủ;
     hai ô kề nhau chồng đúng 10 mm; ô nào cũng nằm trong vùng phủ; tờ dọc cho trang dọc, tờ ngang cho trang ngang.
  2. VỚI POPPLER: dựng trang nguồn (xoay 0/90/180/270, CropBox lệch) có 3 ô màu ở 3 góc + một ô giữa, dựng các tờ theo ĐÚNG phép biến đổi của PdfPoster.kt
     (cửa sổ ô + co vừa + nghịch đảo ma trận hiển thị, cắt theo vùng in), vẽ từng tờ bằng pdftoppm, GHÉP LẠI các tờ theo cửa sổ của chúng, rồi so với bản
     vẽ MỘT TỜ KHỔNG LỒ cùng phép biến đổi: các đường ghép không lệch, không thiếu hàng / cột, chồng 10 mm khớp; và 4 ô màu nằm đúng góc, đúng chiều.
  3. Thử âm tính: bản 'bỏ chồng' (cửa sổ cách nhau pw thay vì pw - 10 mm) và bản 'thiếu một hàng' phải bị bài ghép bắt.
Chạy: python3 poster_check.py  (cần java, pikepdf, numpy, pillow, pdftoppm; ~1-2 phút)
"""
import os, random, subprocess, sys
sys.path.insert(0, os.path.dirname(__file__))
from _common import OUT
import numpy as np
from PIL import Image
import pikepdf
from pikepdf import Name, Dictionary
from page_geometry_check import Geometry
from imposition_check import make_source_pages, inverse

HERE = os.path.dirname(os.path.abspath(__file__))
FAIL = []
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: FAIL.append(msg)
    return ok
A4W, A4H, MARGIN, OVERLAP = 595.276, 841.89, 20.0, 28.35
rnd = random.Random(1905)

def java_plans(cases):
    src = os.path.join(OUT, "poster_in.txt"); dst = os.path.join(OUT, "poster_out.txt")
    open(src, "w").write("\n".join(f"{w} {h} {c}" for w, h, c in cases) + "\n")
    r = subprocess.run(["java", os.path.join(HERE, "PosterCheck.java"), src, dst], capture_output=True, text=True)
    if r.returncode: print(r.stderr[-1500:]); sys.exit(1)
    plans = []
    for ln in open(dst).read().strip().split("\n"):
        head, wins = ln.split(" | ")
        sw, sh, c, rows, s, ox, oy, pw, ph = head.split()
        ws = [tuple(map(float, x.split())) for x in wins.split(";") if x.strip()]
        plans.append(dict(sw=float(sw), sh=float(sh), cols=int(c), rows=int(rows), s=float(s), ox=float(ox), oy=float(oy), pw=float(pw), ph=float(ph), wins=ws))
    return plans

print("== 1. plan(): tính chất hình học trên 4 000 ca ==")
cases = []
for _ in range(800):
    w, h = rnd.choice([(595.0, 842.0), (842.0, 595.0), (400.0, 600.0), (612.0, 792.0), (841.0, 1190.0), (500.0, 500.0), (300.0, 900.0), (900.0, 300.0), (rnd.uniform(50, 2000), rnd.uniform(50, 2000))])
    for c in (2, 3, 4, 5, 6): cases.append((round(w, 2), round(h, 2), c))
plans = java_plans(cases); bad = []
for (w, h, c), p in zip(cases, plans):
    pw, ph = p["sw"] - 2 * MARGIN, p["sh"] - 2 * MARGIN
    totalW = c * pw - (c - 1) * OVERLAP; totalH = p["rows"] * ph - (p["rows"] - 1) * OVERLAP; needed = h * totalW / w
    eps = 1e-2
    why = None
    if (p["sw"] < p["sh"]) != (w <= h): why = "chiều tờ"
    elif len(p["wins"]) != p["cols"] * p["rows"] or p["cols"] != c: why = "số ô"
    elif abs(p["s"] * w - totalW) > eps: why = "bề rộng phủ"
    elif totalH < needed - eps: why = "không phủ hết chiều cao"
    elif p["rows"] > 1 and ((p["rows"] - 1) * ph - (p["rows"] - 2) * OVERLAP) >= needed - 1e-3: why = "thừa một hàng"
    elif p["oy"] < -eps or p["oy"] + needed > totalH + eps: why = "trang ra ngoài vùng phủ"
    else:
        for i, (x, y) in enumerate(p["wins"]):
            r_, c_ = divmod(i, c)
            if abs(x - c_ * (pw - OVERLAP)) > eps or abs(y - (totalH - r_ * (ph - OVERLAP) - ph)) > eps: why = "cửa sổ / chồng 10 mm"; break
            if x < -eps or y < -eps or x + pw > totalW + eps or y + ph > totalH + eps: why = "ô ngoài vùng phủ"; break
    if why: bad.append(((w, h, c), why))
check(not bad, f"{len(cases)} ca (cỡ trang x 2-6 tờ ngang): số ô, bề rộng, số hàng tối thiểu, trang nằm trong vùng phủ, chồng đúng 10 mm ({len(bad)} lệch {bad[:2]})")
big = [p for p in plans if p["rows"] >= 4]; one = [p for p in plans if p["rows"] == 1]
check(len(big) > 50 and len(one) > 50, f"bộ dữ liệu có cả poster 1 hàng ({len(one)}) và từ 4 hàng ({len(big)}) (không kiểm chay)")

# ---------------------------------------------------------------- 2. poppler
R = 100 / 72.0   # điểm ảnh / pt
def render(path, dpi=100):
    base = path[:-4]
    subprocess.run(["pdftoppm", "-r", str(dpi), "-png", "-singlefile", path, base], check=True)
    return np.array(Image.open(base + ".png").convert("RGB")).astype(int)
def form_of(pdf, content, box):
    f = pdf.make_stream(content); f.Type = Name.XObject; f.Subtype = Name.Form; f.BBox = pikepdf.Array(list(box)); f.Resources = Dictionary(); return f
def build_sheets(variant, plan, windows=None):
    """Dựng PDF các tờ đúng như PdfPoster.kt; trả (đường dẫn, geometry, đường dẫn tờ khổng lồ)."""
    mb, cb, rot = variant
    pdf = pikepdf.new(); (pg, g, content, box), = make_source_pages(pdf, [(mb, cb, rot, (0.5, 0.5, 0.5))])
    form = form_of(pdf, content, box)
    a, b, c, d, e, f = inverse(g.matrix()); k = plan["s"]
    pw, ph = plan["pw"], plan["ph"]; wins = windows or plan["wins"]
    for (wx, wy) in wins:
        sheet = pdf.add_blank_page(page_size=(plan["sw"], plan["sh"]))
        sheet.Resources = Dictionary(XObject=Dictionary(F0=form))
        tx, ty = MARGIN - wx + plan["ox"], MARGIN - wy + plan["oy"]
        ops = f"q {MARGIN} {MARGIN} {pw} {ph} re W n {k * a} {k * b} {k * c} {k * d} {k * e + tx} {k * f + ty} cm /F0 Do Q\n"
        sheet.Contents = pdf.make_stream(ops.encode())
    del pdf.pages[0]
    path = os.path.join(OUT, "poster_sheets.pdf"); pdf.save(path)
    # tờ khổng lồ: cùng phép biến đổi, một trang duy nhất
    totalW = plan["cols"] * pw - (plan["cols"] - 1) * OVERLAP; totalH = plan["rows"] * ph - (plan["rows"] - 1) * OVERLAP
    pdf2 = pikepdf.new(); (pg2, g2, content2, box2), = make_source_pages(pdf2, [(mb, cb, rot, (0.5, 0.5, 0.5))])
    form2 = form_of(pdf2, content2, box2); big = pdf2.add_blank_page(page_size=(totalW, totalH)); big.Resources = Dictionary(XObject=Dictionary(F0=form2))
    big.Contents = pdf2.make_stream(f"q {k * a} {k * b} {k * c} {k * d} {k * e + plan['ox']} {k * f + plan['oy']} cm /F0 Do Q\n".encode())
    del pdf2.pages[0]; bigpath = os.path.join(OUT, "poster_big.pdf"); pdf2.save(bigpath)
    return path, g, bigpath, (totalW, totalH)
def render_pages(path, n, dpi=100):
    base = os.path.join(OUT, "poster_pg")
    subprocess.run(["pdftoppm", "-r", str(dpi), "-png", path, base], check=True)
    files = sorted(f for f in os.listdir(OUT) if f.startswith("poster_pg") and f.endswith(".png"))[:n]
    imgs = [np.array(Image.open(os.path.join(OUT, f)).convert("RGB")).astype(int) for f in files]
    for f in os.listdir(OUT):
        if f.startswith("poster_pg"): os.remove(os.path.join(OUT, f))
    return imgs
def stitch(imgs, plan, total, windows=None):
    totalW, totalH = total; pw, ph = plan["pw"], plan["ph"]; wins = windows or plan["wins"]
    canvas = np.full((int(round(totalH * R)), int(round(totalW * R)), 3), 255)
    for img, (wx, wy) in zip(imgs, wins):
        x0, y0 = int(round(MARGIN * R)), int(round((plan["sh"] - MARGIN - ph) * R)); w_, h_ = int(round(pw * R)), int(round(ph * R))
        tile = img[y0:y0 + h_, x0:x0 + w_]
        cx, cy = int(round(wx * R)), int(round((totalH - wy - ph) * R))
        hh, ww = min(tile.shape[0], canvas.shape[0] - cy), min(tile.shape[1], canvas.shape[1] - cx)
        if hh > 0 and ww > 0: canvas[cy:cy + hh, cx:cx + ww] = tile[:hh, :ww]
    return canvas
def agree(a, b):
    """(phần điểm ảnh khớp trên cả trang, phần khớp trên các điểm CÓ MỰC ở một trong hai ảnh, cao, rộng). Trang thử gần như toàn trắng nên số thứ hai mới nhạy với lỗi ghép."""
    h, w = min(a.shape[0], b.shape[0]), min(a.shape[1], b.shape[1])
    a, b = a[:h, :w], b[:h, :w]
    diff = np.abs(a - b).max(axis=2); ink = (a < 250).any(axis=2) | (b < 250).any(axis=2)
    return float((diff <= 40).mean()), float((diff[ink] <= 40).mean()) if ink.any() else 1.0, h, w

print("== 2. poppler: các tờ ghép lại = một tờ khổng lồ; bốn ô màu đúng góc, đúng chiều ==")
variants = []
for rot in (0, 90, 180, 270):
    variants.append(((0, 0, 400, 600), None, rot)); variants.append(((-50, -40, 350, 560), (-30, -10, 330, 540), rot))
allok = True; detail = []
for vi, var in enumerate(variants):
    for cols in (2, 3):
        mb, cb, rot = var; box = cb or mb; g = Geometry(box[0], box[1], box[2] - box[0], box[3] - box[1], rot)
        plan = java_plans([(g.dw, g.dh, cols)])[0]
        path, g, bigpath, total = build_sheets(var, plan)
        imgs = render_pages(path, len(plan["wins"])); big = render(bigpath)
        st = stitch(imgs, plan, total); frac, inkfrac, h, w = agree(st, big)
        # bốn ô màu qua cửa sổ: điểm trong trang hiển thị -> toạ độ poster -> điểm ảnh của ảnh ghép
        def at(dx, dy): return st[int(round((total[1] - (plan["oy"] + dy * plan["s"])) * R)), int(round((plan["ox"] + dx * plan["s"]) * R))]
        near = lambda c, t, tol=45: all(abs(int(c[i]) - t[i]) <= tol for i in range(3))
        colors = near(at(30, 20), (255, 0, 0)) and near(at(30, g.dh - 20), (0, 0, 255)) and near(at(g.dw - 30, g.dh - 20), (0, 255, 0)) and near(at(g.dw / 2, g.dh / 2), (127, 127, 127), 50)
        ok = frac >= 0.995 and inkfrac >= 0.97 and colors and abs(st.shape[0] - big.shape[0]) <= 2 and abs(st.shape[1] - big.shape[1]) <= 2
        allok &= ok; detail.append(f"[rot={rot},{'crop' if cb else 'khong'},{cols}x{plan['rows']}]={'ok' if ok else f'LOI(khop {frac:.3f}, muc {inkfrac:.3f}, mau {colors})'}")
check(allok, "16 tổ hợp (xoay 0/90/180/270 x CropBox lệch x 2-3 tờ ngang): " + " ".join(detail))

print("== 3. thử âm tính ==")
var = ((0, 0, 400, 600), None, 0); plan = java_plans([(400.0, 600.0, 3)])[0]
pw, ph = plan["pw"], plan["ph"]; totalW = plan["cols"] * pw - (plan["cols"] - 1) * OVERLAP; totalH = plan["rows"] * ph - (plan["rows"] - 1) * OVERLAP
path, g, bigpath, total = build_sheets(var, plan); big = render(bigpath); imgs = render_pages(path, len(plan["wins"]))
good_frac = agree(stitch(imgs, plan, total), big)[1]
nooverlap = [(c * pw, totalH - r * ph - ph) for r in range(plan["rows"]) for c in range(plan["cols"])]   # lỗi: cửa sổ cách nhau pw (bỏ chồng) - ghép lại phải lệch
path2, _, _, _ = build_sheets(var, plan, windows=nooverlap); imgs2 = render_pages(path2, len(nooverlap))
bad_frac = agree(stitch(imgs2, plan, total, windows=plan["wins"]), big)[1]
check(good_frac >= 0.97 and bad_frac < 0.8, f"bản 'bỏ chồng 10 mm' bị bắt: khớp trên điểm có mực {good_frac:.4f} (đúng) so với {bad_frac:.4f} (lỗi)")
fewer = dict(plan); fewer["wins"] = plan["wins"][:-plan["cols"]]
imgs3 = render_pages(path, len(plan["wins"]))[:-plan["cols"]]
miss_frac = agree(stitch(imgs3, fewer, total), big)[1]
check(miss_frac < 0.8, f"bản 'thiếu một hàng' bị bắt: khớp trên điểm có mực {miss_frac:.4f} < 0.8")

print()
print("TAT CA DAT" if not FAIL else f"CÓ {len(FAIL)} LỖI")
sys.exit(1 if FAIL else 0)
