import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Java twin of the JSON / XML / Base64 part of app/.../util/TextExporters.kt (phiên 22, 4.49.2): same code, same order. Run by text_formats_check.py.
 *   json|xml  (stdin: documents, each = title line (hex UTF-16 code units), then "P" starts a page and "T <hex units>" adds a paragraph, then a line "=") -> UTF-8 text on stdout, each document followed by U+0001
 *   b64 <lineLength> <file> -> the Base64 text on stdout
 * Strings are passed as hex UTF-16 code units so that LONE surrogates (which UTF-8 cannot carry) can be tested.
 */
public class TextFormatsCheck {
    static String jsonString(String s) {
        StringBuilder sb = new StringBuilder(s.length() + 2);
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"') sb.append("\\\"");
            else if (c == '\\') sb.append("\\\\");
            else if (c == '\n') sb.append("\\n");
            else if (c == '\r') sb.append("\\r");
            else if (c == '\t') sb.append("\\t");
            else if (c == '\b') sb.append("\\b");
            else if (c == (char) 0x0C) sb.append("\\f");
            else if (c < 0x20) { String h = Integer.toHexString(c); while (h.length() < 4) h = "0" + h; sb.append("\\u").append(h); }
            else if (Character.isHighSurrogate(c) && i + 1 < s.length() && Character.isLowSurrogate(s.charAt(i + 1))) { sb.append(c).append(s.charAt(i + 1)); i++; }
            else if (Character.isSurrogate(c)) sb.append('\uFFFD');
            else sb.append(c);
        }
        return sb.append('"').toString();
    }

    static String jsonFromParagraphs(String title, List<List<String>> pages) {
        StringBuilder sb = new StringBuilder();
        sb.append("{\n  \"title\": ").append(jsonString(title)).append(",\n  \"pageCount\": ").append(pages.size()).append(",\n  \"pages\": [");
        for (int i = 0; i < pages.size(); i++) {
            List<String> paras = pages.get(i);
            sb.append(i == 0 ? "\n" : ",\n").append("    {\"page\": ").append(i + 1).append(", \"paragraphs\": [");
            for (int j = 0; j < paras.size(); j++) sb.append(j == 0 ? "\n      " : ",\n      ").append(jsonString(paras.get(j)));
            sb.append(paras.isEmpty() ? "]}" : "\n    ]}");
        }
        sb.append(pages.isEmpty() ? "]\n}\n" : "\n  ]\n}\n");
        return sb.toString();
    }

    /** DocxWriter.escape: drops characters XML 1.0 forbids (by code point), escapes & < >. */
    static String escape(String text) {
        StringBuilder sb = new StringBuilder(text.length() + 16);
        int i = 0;
        while (i < text.length()) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            boolean legal = cp == 0x9 || cp == 0xA || cp == 0xD || (cp >= 0x20 && cp <= 0xD7FF) || (cp >= 0xE000 && cp <= 0xFFFD) || (cp >= 0x10000 && cp <= 0x10FFFF);
            if (!legal) continue;
            if (cp == '&') sb.append("&amp;"); else if (cp == '<') sb.append("&lt;"); else if (cp == '>') sb.append("&gt;"); else sb.appendCodePoint(cp);
        }
        return sb.toString();
    }

    static String xmlAttr(String s) { return escape(s).replace("\"", "&quot;").replace("\r", "&#13;").replace("\n", "&#10;").replace("\t", "&#9;"); }

    static String xmlFromParagraphs(String title, List<List<String>> pages) {
        StringBuilder sb = new StringBuilder();
        sb.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<document title=\"").append(xmlAttr(title)).append("\" pages=\"").append(pages.size()).append("\">\n");
        for (int i = 0; i < pages.size(); i++) {
            sb.append("  <page number=\"").append(i + 1).append("\">\n");
            for (String p : pages.get(i)) sb.append("    <paragraph>").append(escape(p).replace("\r", "&#13;")).append("</paragraph>\n");
            sb.append("  </page>\n");
        }
        sb.append("</document>\n");
        return sb.toString();
    }

    static final String B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    static int col;
    static void put(ByteArrayOutputStream o, int lineLength, char c) {
        if (lineLength > 0 && col == lineLength) { o.write('\n'); col = 0; }
        o.write(c); col++;
    }
    static void base64(InputStream input, OutputStream output, int lineLength) throws IOException {
        byte[] inBuf = new byte[3 * 4096];
        ByteArrayOutputStream outBuf = new ByteArrayOutputStream();
        col = 0;
        while (true) {
            int n = 0;
            while (n < inBuf.length) { int r = input.read(inBuf, n, inBuf.length - n); if (r < 0) break; n += r; }
            int i = 0;
            while (i + 3 <= n) {
                int v = ((inBuf[i] & 0xFF) << 16) | ((inBuf[i + 1] & 0xFF) << 8) | (inBuf[i + 2] & 0xFF);
                put(outBuf, lineLength, B64.charAt(v >>> 18)); put(outBuf, lineLength, B64.charAt((v >>> 12) & 63)); put(outBuf, lineLength, B64.charAt((v >>> 6) & 63)); put(outBuf, lineLength, B64.charAt(v & 63));
                i += 3;
            }
            int rest = n - i;
            if (rest > 0) {
                int v = ((inBuf[i] & 0xFF) << 16) | (rest == 2 ? (inBuf[i + 1] & 0xFF) << 8 : 0);
                put(outBuf, lineLength, B64.charAt(v >>> 18)); put(outBuf, lineLength, B64.charAt((v >>> 12) & 63));
                put(outBuf, lineLength, rest == 2 ? B64.charAt((v >>> 6) & 63) : '='); put(outBuf, lineLength, '=');
            }
            outBuf.writeTo(output); outBuf.reset();
            if (n < inBuf.length) break;
        }
        if (lineLength > 0 && col > 0) output.write('\n');
        output.flush();
    }

    static String unhexUnits(String h) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i + 4 <= h.length(); i += 4) sb.append((char) Integer.parseInt(h.substring(i, i + 4), 16));
        return sb.toString();
    }

    public static void main(String[] a) throws Exception {
        if (a[0].equals("b64multi")) {                    // b64multi <lineLength> <file>... : one encoded text per file, each followed by U+0001
            for (int k = 2; k < a.length; k++) { try (InputStream in = new BufferedInputStream(new FileInputStream(a[k]))) { base64(in, System.out, Integer.parseInt(a[1])); } System.out.write(1); }
            System.out.flush(); return; }
        if (a[0].equals("b64")) { try (InputStream in = new BufferedInputStream(new FileInputStream(a[2]))) { base64(in, System.out, Integer.parseInt(a[1])); } return; }
        BufferedReader r = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.US_ASCII));
        StringBuilder all = new StringBuilder();
        String line; String title = null; List<List<String>> pages = new ArrayList<>();
        PrintStream ps = new PrintStream(System.out, false, "UTF-8");
        boolean json = a[0].equals("json");
        while ((line = r.readLine()) != null) {
            if (line.equals("=")) {                       // end of one document of the batch
                ps.print(json ? jsonFromParagraphs(title, pages) : xmlFromParagraphs(title, pages)); ps.print('\u0001');
                title = null; pages = new ArrayList<>();
            } else if (title == null) title = unhexUnits(line.trim());
            else if (line.equals("P")) pages.add(new ArrayList<>());
            else if (line.startsWith("T")) pages.get(pages.size() - 1).add(unhexUnits(line.length() > 2 ? line.substring(2).trim() : ""));
        }
        ps.flush();
    }
}
