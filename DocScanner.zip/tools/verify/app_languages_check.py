"""Kiểm chứng AppLanguages.checkedIndex (phiên 18): mục nào của bộ chọn ngôn ngữ đang được chọn.

AppLanguagesCheck.java là bản Java chạy được của util/AppLanguages.checkedIndex; so với bản tham chiếu Python viết riêng trên ca viết tay + 2 000 ca ngẫu nhiên:
0 = theo ngôn ngữ của máy (chưa chọn); i + 1 = tags[i]; khớp CHÍNH XÁC (không phân biệt hoa thường) thắng khớp theo tiền tố; tiền tố dài nhất thắng ("pt-BR-x" chọn pt-BR chứ không phải pt);
không khớp gì -> 0. Chạy: python3 app_languages_check.py   (cần java 11+)
"""
import os, random, subprocess, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__)); FAILS = []
def check(c, w):
    print(("ok  " if c else "LOI"), w)
    if not c: FAILS.append(w)
def ref(tags, cur):
    if not cur: return 0
    low = [t.lower() for t in tags]; c = cur.lower()
    if c in low: return low.index(c) + 1
    c = "-".join(p for i, p in enumerate(c.split("-")) if not (i > 0 and len(p) == 4 and p.isalpha()))   # bo chu viet: zh-hans-cn -> zh-cn
    if c in low: return low.index(c) + 1
    cands = [i for i, t in enumerate(low) if c.startswith(t + "-")]
    return (max(cands, key=lambda i: len(low[i])) + 1) if cands else 0
cases = [("", ["en", "vi"]), ("vi", ["en", "vi", "ja"]), ("VI", ["en", "vi"]), ("vi-VN", ["en", "vi"]), ("ja", ["en", "vi", "ja"]), ("pt-BR", ["en", "pt", "pt-BR"]), ("pt-PT", ["en", "pt", "pt-BR"]),
         ("zh-Hans-CN", ["en", "zh-CN", "zh"]), ("zh-CN", ["en", "zh-CN", "zh"]), ("xx", ["en", "vi"]), ("pt-BR-x", ["en", "pt", "pt-BR"]), ("en-US", ["en", "vi"]), ("vix", ["en", "vi"]), ("fr", ["en"]), ("zh-Hans-CN", ["en", "vi", "ja", "es", "pt-BR", "fr", "de", "id", "ko", "zh-CN"]), ("zh-Hant-TW", ["en", "zh-CN"]), ("es-419", ["en", "es"]), ("id", ["en", "id"])]
rnd = random.Random(5); pool = ["en", "vi", "ja", "ko", "pt", "pt-BR", "zh", "zh-CN", "zh-TW", "es", "fr", "de"]
for _ in range(2000):
    tags = rnd.sample(pool, rnd.randint(1, 8)); base = rnd.choice(pool + ["xx", "ar", "th"]); cur = rnd.choice(["", base, base.upper(), base + "-" + rnd.choice(["US", "VN", "BR", "Hans", "Hans-CN", "x"]), base[:2] + rnd.choice(["z", ""])]); cases.append((cur, tags))
p = os.path.join(tempfile.mkdtemp(), "c.txt"); open(p, "w", encoding="utf-8").write("".join(f"{c}\t{','.join(t)}\n" for c, t in cases))
r = subprocess.run(["java", os.path.join(HERE, "AppLanguagesCheck.java"), p], capture_output=True, text=True)
if r.returncode != 0: print(r.stderr[-500:])
got = [int(x) for x in r.stdout.split()]
check(len(got) == len(cases), f"{len(cases)} ca, Java trả đủ kết quả")
bad = [(c, t, g, ref(t, c)) for (c, t), g in zip(cases, got) if g != ref(t, c)]
check(not bad, f"mọi ca khớp bản tham chiếu Python viết riêng {bad[:2]}")
check(got[14] == 10 and got[15] == 0 and got[16] == 2 and got[17] == 2 and got[0] == 0 and got[1] == 2 and got[3] == 2 and got[5] == 3 and got[6] == 2 and got[9] == 0 and got[10] == 3, "ca viết tay: chưa chọn=0; vi=2; vi-VN->vi; pt-BR chính xác=3; pt-PT->pt; xx=0; pt-BR-x->pt-BR; zh-Hans-CN chọn zh-CN; zh-Hant-TW không chọn zh-CN; es-419->es")
print("\nTAT CA DAT" if not FAILS else f"\n{len(FAILS)} LOI"); sys.exit(1 if FAILS else 0)
