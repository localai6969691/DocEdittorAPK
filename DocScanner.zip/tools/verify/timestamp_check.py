"""Kiểm dấu thời gian RFC 3161 (`TimeStamp.kt`, `CmsSigner` unsignedAttrs, `PdfDigitalSigner(tsaUrl)`; phiên 20, 4.48.6) bằng `openssl ts` làm TSA cục bộ.

  A. Yêu cầu: bản Java dựng `TimeStampReq`; `openssl ts -query -in ... -text` đọc lại ĐÚNG (phiên bản 1, SHA-256, băm, nonce, certReq = có).
  B. Trả lời: `openssl ts -reply` (TSA thật, chứng thư có extendedKeyUsage timeStamping) trả lời yêu cầu đó; bản Java đọc `TimeStampResp` (trạng thái, token) và `tokenMatches` = đúng
     với băm + nonce của yêu cầu; sai băm / sai nonce / mã băm khác / BER độ dài không xác định thì SAI.
  C. CMS: `CmsCheck.java` (= CmsSigner.kt) dựng chữ ký có token trong unsignedAttrs; `openssl cms -verify` vẫn đạt (unsignedAttrs không nằm trong phần được ký); token rút ra từ CMS được
     `openssl ts -verify -data <GIÁ TRỊ chữ ký> -CAfile` xác nhận (token phủ đúng chữ ký, không phải nội dung); dùng nhầm nội dung thì `openssl` từ chối.
  D. PDF: PDF ký thật có token (nối vào bộ dựng của signed_pdf_lib): `pdfsig` báo chữ ký HỢP LỆ, token vẫn nằm đúng chỗ trong /Contents.
  E. Bền vững: 300 chuỗi byte ngẫu nhiên + các bản cắt cụt của một trả lời thật không làm sập, không bao giờ được coi là khớp.
  F. Thử âm tính: bản Java bỏ kiểm nonce / bỏ kiểm băm / certReq = FALSE bị bắt.
Chạy: python3 timestamp_check.py   (cần java, openssl, pdfsig, cryptography)"""
import os, random, re, shutil, subprocess, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import OUT
from signed_pdf_lib import Chain, make_cert, pdfsig, HERE

JAVA = os.path.join(HERE, "TimestampCheck.java")
FAIL = []; rnd = random.Random(20261023)
def check(ok, msg):
    print(("ok   " if ok else "LOI  ") + msg)
    if not ok: FAIL.append(msg)
    return ok
def sh(*a, **k):
    r = subprocess.run(list(a), capture_output=True, text=True, **k)
    return r
def jv(lines, java=JAVA):
    r = subprocess.run(["java", java], input="\n".join(lines) + "\n", capture_output=True, text=True)
    if r.returncode: print(r.stderr[-1500:]); sys.exit(1)
    return r.stdout.split("\n")[:len(lines)]

def tlv(d, o):
    first = d[o + 1]
    if first < 128: return d[o], 2, first
    n = first & 0x7F
    return d[o], 2 + n, int.from_bytes(d[o + 2:o + 2 + n], "big")

def cms_parts(cms):
    """(giá trị chữ ký, token trong unsignedAttrs) của SignerInfo đầu tiên của một CMS SignedData."""
    t, h, l = tlv(cms, 0); p = h
    t, h2, l2 = tlv(cms, p); p += h2 + l2            # OID signedData
    t, h2, l2 = tlv(cms, p); p += h2                 # [0]
    t, h2, l2 = tlv(cms, p); p += h2                 # SignedData
    for _ in range(3):                               # version, digestAlgorithms, encapContentInfo
        t, h2, l2 = tlv(cms, p); p += h2 + l2
    t, h2, l2 = tlv(cms, p); p += h2 + l2            # [0] certificates
    t, h2, l2 = tlv(cms, p); p += h2                 # SET OF SignerInfo
    t, h2, l2 = tlv(cms, p); p += h2                 # SignerInfo
    end = p + l2
    for _ in range(5):                               # version, sid, digestAlg, [0] signedAttrs, sigAlg
        t, h2, l2 = tlv(cms, p); p += h2 + l2
    t, h2, sl = tlv(cms, p); sig = cms[p + h2:p + h2 + sl]; p += h2 + sl
    token = None
    if p < end:
        t, h2, l2 = tlv(cms, p)                      # [1] unsignedAttrs
        assert t == 0xA1
        q = p + h2
        t, h3, l3 = tlv(cms, q); q += h3             # Attribute SEQUENCE
        t, h3, l3 = tlv(cms, q); q += h3 + l3        # OID
        t, h3, l3 = tlv(cms, q); q += h3             # SET
        t, h3, l3 = tlv(cms, q); token = cms[q:q + h3 + l3]
    return sig, token

def der_trim(padded):
    """The CMS inside a signature's /Contents is followed by zero padding up to the reserved size. Cut it by the DER length of the outer SEQUENCE,
    NOT with rstrip("0"): that also removes a real trailing zero nibble (e.g. a last byte 0x80), which broke this check in about 1 run out of 16."""
    first = padded[1]
    if first < 128: return padded[:2 + first]
    n = first & 0x7F
    return padded[:2 + n + int.from_bytes(padded[2:2 + n], "big")]


def main():
    tmp = tempfile.mkdtemp(dir=OUT)
    os.chdir(tmp)
    try:
        # ---- TSA cục bộ
        sh("openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", "ca.key", "-out", "ca.crt", "-subj", "/CN=Test TSA CA", "-days", "30")
        sh("openssl", "req", "-newkey", "rsa:2048", "-nodes", "-keyout", "tsa.key", "-out", "tsa.csr", "-subj", "/CN=Test Timestamp Authority")
        open("ext.cnf", "w").write("basicConstraints=CA:FALSE\nkeyUsage=critical,digitalSignature\nextendedKeyUsage=critical,timeStamping\n")
        sh("openssl", "x509", "-req", "-in", "tsa.csr", "-CA", "ca.crt", "-CAkey", "ca.key", "-CAcreateserial", "-out", "tsa.crt", "-days", "30", "-extfile", "ext.cnf")
        open("tsaserial", "w").write("01\n")
        open("tsa.cnf", "w").write("""[tsa]
default_tsa = tsa1
[tsa1]
serial = tsaserial
crypto_device = builtin
signer_cert = tsa.crt
certs = ca.crt
signer_key = tsa.key
default_policy = 1.2.3.4.1
other_policies = 1.2.3.4.5
digests = sha256, sha384
accuracy = secs:1
ordering = yes
tsa_name = yes
ess_cert_id_alg = sha256
signer_digest = sha256
""")
        # ---- A. yêu cầu
        print("== A. TimeStampReq")
        sig = bytes(rnd.getrandbits(8) for _ in range(256))                    # giả làm giá trị chữ ký RSA-2048
        import hashlib
        digest = hashlib.sha256(sig).hexdigest(); nonce = "1a2b3c4d5e6f7081"
        req = bytes.fromhex(jv([f"REQ {digest} {nonce}"])[0]); open("req.tsq", "wb").write(req)
        txt = sh("openssl", "ts", "-query", "-in", "req.tsq", "-text").stdout
        dump = "".join(re.sub(r"[ -]", "", x) for x in re.findall(r"^\s*[0-9a-f]{4} - ((?:[0-9a-f]{2}[ -]){15}[0-9a-f]{2})", txt, re.M))
        check("Version: 1" in txt and "Hash Algorithm: sha256" in txt and "Certificate required: yes" in txt and f"Nonce: 0x{nonce.upper()}" in txt and dump == digest, f"openssl đọc lại yêu cầu của bản Java: phiên bản 1, sha256, băm đúng ({dump[:16]}…), nonce, certReq = yes")
        # ---- B. trả lời
        print("== B. TimeStampResp từ openssl ts (TSA thật)")
        r = sh("openssl", "ts", "-reply", "-queryfile", "req.tsq", "-config", "tsa.cnf", "-out", "resp.tsr"); assert r.returncode == 0, r.stderr
        resp = open("resp.tsr", "rb").read()
        out = jv([f"RESP {resp.hex()}"])[0].split("|")
        status, token_hex = int(out[0]), out[1]
        token = bytes.fromhex(token_hex)
        txt = sh("openssl", "ts", "-reply", "-in", "resp.tsr", "-text").stdout
        check(status == 0 and "Status: Granted." in txt and len(token) > 500, f"bản Java đọc TimeStampResp: trạng thái {status} = 'Granted' của openssl, token {len(token)} byte")
        m = jv([f"MATCH {token_hex} {digest} {nonce}", f"MATCH {token_hex} {hashlib.sha256(b'khac').hexdigest()} {nonce}", f"MATCH {token_hex} {digest} 1a2b3c4d5e6f7082", f"MATCH {token_hex} {digest} 1a2b3c4d5e6f70"])
        check(m == ["true", "false", "false", "false"], f"tokenMatches: đúng băm + nonce = true; sai băm, sai nonce, nonce ngắn hơn = false ({m})")
        # mã băm khác (SHA-384): yêu cầu của openssl rồi so với băm SHA-256 -> false
        sh("openssl", "ts", "-query", "-digest", hashlib.sha384(sig).hexdigest(), "-sha384", "-cert", "-out", "req384.tsq")
        sh("openssl", "ts", "-reply", "-queryfile", "req384.tsq", "-config", "tsa.cnf", "-out", "resp384.tsr")
        r384 = jv([f"RESP {open('resp384.tsr', 'rb').read().hex()}"])[0].split("|")
        check(r384[0] == "0" and jv([f"MATCH {r384[1]} {digest} 1"])[0] == "false", "token cấp cho SHA-384 không bao giờ khớp băm SHA-256 của ta")
        # trạng thái từ chối (2) dựng tay: SEQUENCE { SEQUENCE { INTEGER 2 } }
        rej = bytes.fromhex("3005300302" + "0102")
        check(jv([f"RESP {rej.hex()}"])[0] == "2|-", "trả lời từ chối (status 2) đọc ra '2|-' (không token)")
        # BER độ dài không xác định -> không đọc được -> KHÔNG khớp (từ chối thay vì gắn không kiểm)
        ber = bytes.fromhex(token_hex).replace(b"\xa0\x82", b"\xa0\x80", 1)
        check(jv([f"MATCH {ber.hex()} {digest} {nonce}"])[0] == "false", "token BER độ dài không xác định: bị từ chối (đóng an toàn)")

        # ---- C. CMS
        print("== C. CMS có unsignedAttrs")
        make_cert("signer"); open("content.bin", "wb").write(b"noi dung can ky " * 100); open("token.der", "wb").write(token)
        r = sh("java", os.path.join(HERE, "CmsCheck.java"), "content.bin", "signer.pk8", "signer.der", "cms_ts.der", "1790000000000", "token.der"); assert r.returncode == 0, r.stderr
        r = sh("java", os.path.join(HERE, "CmsCheck.java"), "content.bin", "signer.pk8", "signer.der", "cms_plain.der", "1790000000000"); assert r.returncode == 0, r.stderr
        for name in ("cms_ts.der", "cms_plain.der"):
            v = sh("openssl", "cms", "-verify", "-inform", "DER", "-in", name, "-content", "content.bin", "-binary", "-noverify", "-out", os.devnull)
            check(v.returncode == 0, f"openssl cms -verify: {name} vẫn HỢP LỆ ({v.stderr.strip()[:60]})")
        cms_ts = open("cms_ts.der", "rb").read(); cms_plain = open("cms_plain.der", "rb").read()
        sig_val, tok = cms_parts(cms_ts)
        sig_plain, tok_plain = cms_parts(cms_plain)
        check(tok == token and tok_plain is None and sig_val == sig_plain, f"token nằm đúng trong unsignedAttrs (giống từng byte), CMS không có token thì không có; giá trị chữ ký KHÔNG đổi ({len(cms_ts) - len(cms_plain)} byte thêm)")
        # mở lại: yêu cầu / trả lời cho CHÍNH giá trị chữ ký của CMS này
        d2 = hashlib.sha256(sig_val).hexdigest()
        open("req2.tsq", "wb").write(bytes.fromhex(jv([f"REQ {d2} 77"])[0]))
        sh("openssl", "ts", "-reply", "-queryfile", "req2.tsq", "-config", "tsa.cnf", "-out", "resp2.tsr")
        t2 = bytes.fromhex(jv([f"RESP {open('resp2.tsr', 'rb').read().hex()}"])[0].split("|")[1]); open("token2.der", "wb").write(t2); open("sigval.bin", "wb").write(sig_val)
        r = sh("java", os.path.join(HERE, "CmsCheck.java"), "content.bin", "signer.pk8", "signer.der", "cms_ts2.der", "1790000000000", "token2.der")
        s2, tok2 = cms_parts(open("cms_ts2.der", "rb").read())
        ok = sh("openssl", "ts", "-verify", "-data", "sigval.bin", "-in", "token2.der", "-token_in", "-CAfile", "ca.crt")
        check(s2 == sig_val and tok2 == t2 and ok.returncode == 0 and "Verification: OK" in ok.stdout, f"openssl ts -verify: token rút từ CMS phủ đúng GIÁ TRỊ chữ ký ({ok.stdout.strip()})")
        bad = sh("openssl", "ts", "-verify", "-data", "content.bin", "-in", "token2.der", "-token_in", "-CAfile", "ca.crt")
        check(bad.returncode != 0, "dùng nhầm NỘI DUNG (thay vì giá trị chữ ký) làm dữ liệu băm thì openssl TỪ CHỐI: kiểm này phân biệt được")

        # ---- D. PDF thật
        print("== D. PDF ký thật có dấu thời gian")
        ch = Chain(); ch.add_signature(cap=12000)
        open("c.bin", "wb").write(ch.signed_content())
        sh("java", os.path.join(HERE, "CmsCheck.java"), "c.bin", "signer.pk8", "signer.der", "c0.der", "1790000000000")
        sv, _ = cms_parts(open("c0.der", "rb").read())
        open("r3.tsq", "wb").write(bytes.fromhex(jv([f"REQ {hashlib.sha256(sv).hexdigest()} 99"])[0]))
        sh("openssl", "ts", "-reply", "-queryfile", "r3.tsq", "-config", "tsa.cnf", "-out", "r3.tsr")
        open("t3.der", "wb").write(bytes.fromhex(jv([f"RESP {open('r3.tsr', 'rb').read().hex()}"])[0].split("|")[1]))
        sh("java", os.path.join(HERE, "CmsCheck.java"), "c.bin", "signer.pk8", "signer.der", "c1.der", "1790000000000", "t3.der")
        cms = open("c1.der", "rb").read()
        ch.fill(cms); open("signed_ts.pdf", "wb").write(ch.pdf)
        out = pdfsig("signed_ts.pdf")
        check("Signature is Valid" in out, f"pdfsig: PDF ký thật có token ({len(cms)} byte trong /Contents) vẫn báo chữ ký HỢP LỆ")
        # token vẫn còn nguyên trong PDF
        L = ch.last; raw = der_trim(bytes.fromhex(ch.pdf[L["lt"] + 1:L["gt"]].decode()))
        check(cms_parts(raw)[1] == open("t3.der", "rb").read(), "token đọc lại từ /Contents của PDF giống từng byte")

        # ---- E. bền vững
        print("== E. dữ liệu hỏng")
        junk = [bytes(rnd.getrandbits(8) for _ in range(rnd.randint(0, 80))) for _ in range(300)]
        cuts = [resp[:n] for n in range(0, len(resp), max(1, len(resp) // 120))]
        o = jv([f"RESP {j.hex()}" for j in junk + cuts] + [f"MATCH {j.hex()} {digest} {nonce}" for j in junk] + [f"MATCH {c.hex()} {digest} {nonce}" for c in [bytes.fromhex(token_hex)[:n] for n in range(0, len(token), max(1, len(token) // 120))]])
        n1 = len(junk) + len(cuts)
        badE = [(i, x) for i, x in enumerate(o) if x == "" or (i >= n1 and x != "false")]
        if badE: print("   lệch:", len(o), badE[:3])
        check(all(x != "" for x in o) and all(x == "false" for x in o[n1:]), f"{len(junk)} chuỗi ngẫu nhiên + {len(cuts)} bản cắt cụt của trả lời + {len(o) - n1} lần MATCH trên rác / token cắt cụt: không sập, không bao giờ khớp")

        # ---- F. thử âm tính
        print("== F. thử âm tính")
        src = open(JAVA, encoding="utf-8").read()
        def mut(old, new, tag):
            assert src.count(old) == 1, old
            p = os.path.join(tmp, f"M{tag}.java"); open(p, "w", encoding="utf-8").write(src.replace(old, new).replace("TimestampCheck", f"M{tag}")); return p
        j = mut("return new BigInteger(Arrays.copyOfRange(token, p + h[1], p + h[1] + h[2])).equals(nonce);", "return true;", "A")
        check(jv([f"MATCH {token_hex} {digest} 1a2b3c4d5e6f7082"], j)[0] == "true", "bản hỏng 'bỏ kiểm nonce' chấp nhận token của yêu cầu khác (bài kiểm B bắt được)")
        j = mut("!Arrays.equals(Arrays.copyOfRange(token, hashOff + hash[1], hashOff + hash[1] + hash[2]), digest)", "false", "B")
        check(jv([f"MATCH {token_hex} {hashlib.sha256(b'khac').hexdigest()} {nonce}"], j)[0] == "true", "bản hỏng 'bỏ kiểm băm' chấp nhận token của dữ liệu khác (bài kiểm B bắt được)")
        j = mut("if (ci[0] != 0x30 || ci[1] + ci[2] != token.length) return false;", "if (ci[0] != 0x30) return false;", "D")
        tk = bytes.fromhex(token_hex)
        cutres = jv([f"MATCH {tk[:n].hex()} {digest} {nonce}" for n in range(len(tk) - 1, 200, -97)], j)
        check("true" in cutres, f"bản hỏng 'không kiểm độ dài ngoài cùng' chấp nhận token CẮT CỤT ({cutres.count('true')} lần; bài kiểm E bắt được)")
        j = mut("tlv(0x01, new byte[]{(byte) 0xFF})", "tlv(0x01, new byte[]{(byte) 0x00})", "C")
        rq = bytes.fromhex(jv([f"REQ {digest} {nonce}"], j)[0]); open("reqc.tsq", "wb").write(rq)
        check("Certificate required: no" in sh("openssl", "ts", "-query", "-in", "reqc.tsq", "-text").stdout, "bản hỏng 'certReq = FALSE' bị bắt: openssl đọc ra 'Certificate required: no' (bài kiểm A bắt được)")
    finally:
        os.chdir(HERE); shutil.rmtree(tmp, ignore_errors=True)
    print("TAT CA DAT" if not FAIL else f"CO LOI ({len(FAIL)})")
    return 1 if FAIL else 0

if __name__ == "__main__": sys.exit(main())
