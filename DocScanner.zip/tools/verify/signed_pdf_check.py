"""Kiểm bộ dò chữ ký PDF `PdfSignatureProbe.kt` (phiên 20, cảnh báo trước khi sửa PDF ĐÃ KÝ) bằng PDF ký THẬT.

Bản Java song song `SignatureProbeCheck.java` (cùng thuật toán) chạy trên:
  A. PDF ký THẬT: CMS do `CmsCheck.java` (= CmsSigner.kt) dựng, `pdfsig` xác nhận "Signature is Valid"; một / nhiều chữ ký nối tiếp, /Contents trước / sau
     /ByteRange, chứng nhận DocMDP mức 1-3, chỉnh sửa SAU khi ký. ĐÁP ÁN ĐỘC LẬP = `pdfsig` (poppler): số chữ ký, "Signed Ranges", "Total document signed".
  B. 200 PDF ngẫu nhiên (CMS giả để nhanh): số chữ ký 0-4, thứ tự khoá, đệm, DocMDP, DocTimeStamp, chỉnh sửa sau; kích thước khối quét 997 / 4096 / 1 MiB.
     Đáp án = vị trí do bộ dựng biết chắc; thêm so với pdfsig khi nó liệt kê được.
  C. Ranh giới khối: khoá /ByteRange cắt ngang mép khối ở mọi độ lệch -12..+2 (khối 2048): mỗi chữ ký tìm ĐÚNG MỘT lần.
  D. Không báo nhầm: văn bản có chữ "/ByteRange", chỗ dành sẵn chưa ký (`[0 ****...]`, `[0 0 0 0]`), vùng ký chạy quá cuối tệp; và GIỚI HẠN nói thẳng:
     một vật giả dạng đúng cấu trúc (có `<` và `>` đúng chỗ) bị coi là chữ ký (an toàn: chỉ thừa một cảnh báo).
  E. Bảng hiệu ứng `effect()` theo công cụ x loại chữ ký.
  F. Thử âm tính: (1) bộ dò ngây thơ "có chữ /ByteRange" báo nhầm ở D; (2) bản Java bỏ phần chồng của khối (chunk + key) bỏ sót ở C; (3) bản bỏ kiểm cấu trúc báo nhầm ở D.
Chạy: python3 signed_pdf_check.py   (cần cryptography, pdfsig, java 17+; ~1-2 phút)
"""
import os, random, re, subprocess, sys, tempfile, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import OUT
from signed_pdf_lib import *

JAVA = os.path.join(HERE, "SignatureProbeCheck.java")
FAILS = []


def check(cond, what):
    print(("ok  " if cond else "LOI"), what)
    if not cond:
        FAILS.append(what)
    return cond


def run_java(chunk, paths, java_file=JAVA):
    r = subprocess.run(["java", java_file, str(chunk)] + paths, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout, r.stderr)
        raise SystemExit("SignatureProbeCheck.java thất bại")
    res, cur = {}, None
    for line in r.stdout.splitlines():
        t = line.split(" ")
        if t[0] == "FILE":
            cur = t[1]; res[cur] = (int(t[2]), [])
        elif t[0] == "SIG":
            res[cur][1].append(dict(pos=int(t[1]), a=int(t[2]), b=int(t[3]), c=int(t[4]), d=int(t[5]), sub=None if t[6] == "-" else t[6], ts=t[7] == "1", level=int(t[8])))
    return res


def derive(length, sigs):
    """Bản Python của các thuộc tính suy ra trong PdfSignatureProbe.Result (cùng định nghĩa)."""
    approvals = [s for s in sigs if not s["ts"]]
    levels = [s["level"] for s in approvals if s["level"] > 0]
    return dict(has=bool(sigs), approvals=len(approvals), timestamps=len(sigs) - len(approvals), certify=min(levels) if levels else 0,
                changed=bool(sigs) and max(s["c"] + s["d"] for s in sigs) < length)


def effect(d, tool):
    if not d["has"]:
        return "NONE"
    if tool == "READ_ONLY":
        return "NONE"
    if tool == "REWRITES":
        return "BREAKS"
    return "BREAKS" if d["certify"] == 1 else "KEEPS"


def pdfsig_ranges(path):
    """[(a, a+b, c, c+d)], phần 'Total document signed' của chữ ký cuối, và số chữ ký 'Valid'."""
    out = pdfsig(path)
    rng = [tuple(int(x) for x in m) for m in re.findall(r"Signed Ranges: \[(\d+) - (\d+)\], \[(\d+) - (\d+)\]", out)]
    blocks = out.split("Signature #")[1:]
    total_last = bool(blocks) and "- Total document signed" in blocks[-1]
    valid = sum("Signature is Valid" in b for b in blocks)
    return rng, total_last, valid, out


def as_range(s):
    return (s["a"], s["a"] + s["b"], s["c"], s["c"] + s["d"])


def main():
    wd = tempfile.mkdtemp(dir=OUT)
    try:
        make_cert(os.path.join(wd, "c"))
        cert = os.path.join(wd, "c")

        # ---------------- A. PDF ký thật ----------------
        print("== A. PDF ký THẬT (đáp án: pdfsig)")
        cases = {}

        def real(name, plan, edit_after=False, pad=0):
            ch = Chain(pad)
            for opts in plan:
                ch.add_signature(**opts)
                ch.fill(real_cms(ch, wd, cert))
            if edit_after:
                ch.edit()
            p = os.path.join(wd, name + ".pdf"); open(p, "wb").write(ch.pdf)
            cases[name] = p
        real("a1_single", [dict()])
        real("a2_contents_first", [dict(order="contents_first")])
        real("a3_chain3", [dict(), dict(order="contents_first"), dict()])
        real("a4_chain_edit", [dict(), dict(order="contents_first")], edit_after=True)
        real("a5_certify1", [dict(certify=1)])
        real("a6_certify2_then_sign", [dict(certify=2), dict()])
        real("a7_certify3_contents_first", [dict(certify=3, order="contents_first")], pad=5000)
        real("a8_certify_default_p", [dict(certify=2)])
        res = run_java(1 << 20, list(cases.values()))
        for name, path in cases.items():
            length, sigs = res[path]
            rng, total_last, valid, out = pdfsig_ranges(path)
            check(valid == len(rng) == len(sigs) and len(sigs) > 0, f"{name}: pdfsig thấy {len(rng)} chữ ký, {valid} HỢP LỆ (đây là PDF ký thật); bộ dò thấy {len(sigs)}")
            check([as_range(s) for s in sigs] == rng, f"{name}: vùng đã ký (a,b,c,d) của từng chữ ký KHỚP pdfsig")
            d = derive(length, sigs)
            check(d["changed"] == (not total_last), f"{name}: 'đã đổi sau chữ ký cuối' = {d['changed']} khớp pdfsig ('Total document signed' = {total_last})")
        expect_level = {"a5_certify1": 1, "a6_certify2_then_sign": 2, "a7_certify3_contents_first": 3, "a8_certify_default_p": 2, "a1_single": 0, "a3_chain3": 0}
        for name, lv in expect_level.items():
            check(derive(*res[cases[name]])["certify"] == lv, f"{name}: mức DocMDP = {lv}")
        check(all(s["sub"] == "adbe.pkcs7.detached" for s in res[cases["a3_chain3"]][1]), "SubFilter đọc đúng (adbe.pkcs7.detached)")

        # ---------------- B. ngẫu nhiên ----------------
        print("== B. 200 PDF ngẫu nhiên (CMS giả), 3 cỡ khối")
        rnd = random.Random(2026)
        truth, files = {}, {}
        for i in range(200):
            n = rnd.choice([0, 1, 1, 2, 3, 4])
            pad = rnd.choice([0, 0, 17, 1000, 5555, 20000])
            ch = Chain(pad)
            tr = []
            for k in range(n):
                opts = dict(order=rnd.choice(["br_first", "contents_first"]), cap=rnd.choice([300, 1000, 3000]))
                if k == 0 and rnd.random() < 0.3:
                    opts["certify"] = rnd.choice([1, 2, 3])
                if rnd.random() < 0.15:
                    opts["doc_timestamp"] = True
                    opts.pop("certify", None)   # một dấu thời gian không mang DocMDP trong thực tế
                ch.add_signature(**opts)
                ch.fill(bytes(rnd.getrandbits(8) for _ in range(rnd.randint(100, opts["cap"]))))
                L = ch.last
                tr.append(dict(a=0, b=L["lt"], c=L["c"], d=L["d"], ts=bool(opts.get("doc_timestamp")), level=0 if opts.get("doc_timestamp") else opts.get("certify", 0)))
            if n and rnd.random() < 0.4:
                ch.edit()
            p = os.path.join(wd, f"b{i:03d}.pdf"); open(p, "wb").write(ch.pdf)
            chunk = rnd.choice([997, 4096, 1 << 20])
            files.setdefault(chunk, []).append(p); truth[p] = (len(ch.pdf), tr)
        got = {}
        for chunk, paths in files.items():
            got.update(run_java(chunk, paths))
        bad = 0; compared = 0
        for p, (length, tr) in truth.items():
            glen, gs = got[p]
            ok = glen == length and len(gs) == len(tr) and all((s["a"], s["b"], s["c"], s["d"], s["ts"], s["level"]) == (0, t["b"], t["c"], t["d"], t["ts"], t["level"]) for s, t in zip(gs, tr))
            bad += not ok
            if not ok and bad <= 3:
                print("  lệch:", p, glen, length, gs, tr)
        check(bad == 0, f"200 tệp: số chữ ký, vị trí a/b/c/d, DocTimeStamp, mức DocMDP đúng với bộ dựng ({bad} lệch)")
        # so thêm pdfsig (poppler liệt kê cả DocTimeStamp như một chữ ký)
        mism = 0
        for p, (length, tr) in truth.items():
            rng, total_last, valid, out = pdfsig_ranges(p)
            if rng:
                compared += 1
                mine = [as_range(s) for s in got[p][1]]
                if mine != rng:
                    mism += 1
                    if mism <= 3:
                        print("  lệch pdfsig:", p, "mine=", mine, "pdfsig=", rng, [ (x["ts"], x["sub"]) for x in got[p][1]])
        check(mism == 0 and compared >= 80, f"vùng đã ký khớp pdfsig ở {compared} tệp có chữ ký ({mism} lệch)")

        # ---------------- C. ranh giới khối ----------------
        print("== C. khoá /ByteRange cắt ngang mép khối")
        chunk = 2048
        bpaths = []
        for off in list(range(-12, 3)):
            want_mod = (chunk + off) % chunk
            pad = 2 + chunk
            for _ in range(5):   # độ dài số của `startxref` đổi theo đệm nên lặp tới khi khớp
                ch = Chain(pad); ch.add_signature()
                delta = (want_mod - ch.last["br_pos"]) % chunk
                if delta == 0:
                    break
                pad += delta
            assert ch.last["br_pos"] % chunk == want_mod, (ch.last["br_pos"] % chunk, want_mod)
            ch.fill(b"\x30\x03\x02\x01\x00")
            p = os.path.join(wd, f"c_{off:+03d}.pdf"); open(p, "wb").write(ch.pdf); bpaths.append(p)
        rb = run_java(chunk, bpaths)
        check(all(len(rb[p][1]) == 1 for p in bpaths), f"15 độ lệch -12..+2: mỗi chữ ký thấy ĐÚNG MỘT lần ({[len(rb[p][1]) for p in bpaths]})")

        # ---------------- D. không báo nhầm ----------------
        print("== D. không báo nhầm + giới hạn")
        neg = {}

        def textpdf(name, extra_stream):
            pdf, xr = base_pdf()
            data = pdf.replace(b"0.9 0.2 0.2 rg 20 20 100 60 re f", extra_stream)
            data = data.replace(b"/Length 32", b"/Length %d" % len(extra_stream))
            p = os.path.join(wd, name + ".pdf"); open(p, "wb").write(data); neg[name] = p
        textpdf("d1_text_in_stream", b"% see /ByteRange [0 100 150 100] and /ByteRange [0 20 40 50]\n0 g")
        textpdf("d2_placeholder_stars", b"% /ByteRange [0 ********** ********** **********] /Contents <0000>")
        textpdf("d3_zeros", b"% /ByteRange [0 0 0 0]")
        textpdf("d4_runs_past_eof", b"% /ByteRange [0 20 40 99999999]")
        textpdf("d5_not_zero_start", b"% /ByteRange [5 20 40 50]")
        # vật giả dạng ĐÚNG cấu trúc: '<' tại a+b, '>' tại c-1 (cố tình dựng)
        fake = bytearray(b"%PDF-1.7\n" + b"% /ByteRange [0 0000000200 0000000300 0000000050]\n")
        fake += b" " * 320; fake[200] = ord("<"); fake[299] = ord(">")
        p = os.path.join(wd, "d6_lookalike.pdf"); open(p, "wb").write(bytes(fake)); neg["d6_lookalike"] = p
        rn = run_java(1 << 20, list(neg.values()))
        for name in ["d1_text_in_stream", "d2_placeholder_stars", "d3_zeros", "d4_runs_past_eof", "d5_not_zero_start"]:
            check(len(rn[neg[name]][1]) == 0, f"{name}: KHÔNG coi là chữ ký")
        check(len(rn[neg["d6_lookalike"]][1]) == 1, "d6_lookalike: vật giả dạng đúng cấu trúc BỊ coi là chữ ký (giới hạn đã biết; hướng an toàn = thừa một cảnh báo)")
        check(pdfsig_ranges(neg["d1_text_in_stream"])[0] == [], "pdfsig cũng không thấy chữ ký ở d1")

        # ---------------- E. bảng hiệu ứng ----------------
        print("== E. effect(): công cụ x loại chữ ký")
        none = derive(100, []); one = derive(100, [dict(a=0, b=1, c=2, d=98, ts=False, level=0)])
        c1 = derive(100, [dict(a=0, b=1, c=2, d=98, ts=False, level=1)]); c2 = derive(100, [dict(a=0, b=1, c=2, d=98, ts=False, level=2)])
        tsonly = derive(100, [dict(a=0, b=1, c=2, d=98, ts=True, level=0)])
        table = {("none", t): "NONE" for t in ["READ_ONLY", "REWRITES", "APPENDS_FORM", "APPENDS_SIGNATURE"]}
        exp = [(none, "READ_ONLY", "NONE"), (none, "REWRITES", "NONE"), (one, "READ_ONLY", "NONE"), (one, "REWRITES", "BREAKS"), (one, "APPENDS_FORM", "KEEPS"),
               (one, "APPENDS_SIGNATURE", "KEEPS"), (c1, "APPENDS_FORM", "BREAKS"), (c1, "APPENDS_SIGNATURE", "BREAKS"), (c2, "APPENDS_FORM", "KEEPS"),
               (c2, "REWRITES", "BREAKS"), (tsonly, "REWRITES", "BREAKS"), (tsonly, "APPENDS_FORM", "KEEPS")]
        check(all(effect(d, t) == e for d, t, e in exp), "12 ô của bảng hiệu ứng (chữ ký thường / chứng nhận mức 1, 2 / chỉ dấu thời gian)")

        # ---------------- F. thử âm tính ----------------
        print("== F. thử âm tính")
        naive_fp = sum(1 for n in ["d1_text_in_stream", "d2_placeholder_stars", "d3_zeros", "d4_runs_past_eof", "d5_not_zero_start"] if b"/ByteRange" in open(neg[n], "rb").read())
        check(naive_fp == 5, f"bộ dò ngây thơ ('có chữ /ByteRange') báo nhầm {naive_fp}/5 ca D -> bài kiểm D bắt được lỗi này")
        src = open(JAVA, encoding="utf-8").read()
        m1 = src.replace("byte[] chunk = read.read(base, chunkSize + key.length);", "byte[] chunk = read.read(base, chunkSize);")
        mp = os.path.join(wd, "SignatureProbeCheck.java"); open(mp, "w", encoding="utf-8").write(m1.replace("public class SignatureProbeCheck", "public class SignatureProbeCheck"))
        rm = run_java(chunk, bpaths, mp)
        missed = sum(1 for p in bpaths if len(rm[p][1]) != 1)
        check(missed >= 5, f"bản Java bỏ phần chồng của khối: bỏ sót {missed}/15 ca ở C -> bài kiểm C bắt được lỗi này")
        m2 = src.replace("if (x.length == 0 || x[0] != '<') return null;", "").replace("if (y.length == 0 || y[0] != '>') return null;", "")
        open(mp, "w", encoding="utf-8").write(m2)
        r2 = run_java(1 << 20, list(neg.values()), mp)
        fp2 = sum(1 for n in ["d1_text_in_stream", "d2_placeholder_stars", "d3_zeros", "d4_runs_past_eof", "d5_not_zero_start"] if r2[neg[n]][1])
        check(fp2 >= 1, f"bản Java bỏ kiểm '<' / '>' tại ranh giới: báo nhầm {fp2}/5 ca D -> bài kiểm D bắt được lỗi này")
    finally:
        shutil.rmtree(wd, ignore_errors=True)
    print("TAT CA DAT" if not FAILS else f"CO LOI ({len(FAILS)})")
    return 1 if FAILS else 0


if __name__ == "__main__":
    sys.exit(main())
